#include "l4d2_matchmaking_funcs.4.h"

DEFINE_REX_FUNC(sub_8B090068) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// std r30,-24(r1)
	REX_STORE_U64(ctx.r1.u32 + -24, ctx.r30.u64);
	// std r31,-16(r1)
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.r31.u64);
	// stwu r1,-112(r1)
	ea = -112 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// mullw r31,r3,r4
	ctx.r31.s64 = int64_t(ctx.r3.s32) * int64_t(ctx.r4.s32);
	// lwz r11,1144(r11)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r11.u32 + 1144);
	// lwz r3,0(r11)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r11.u32 + 0);
	// mr r4,r31
	ctx.r4.u64 = ctx.r31.u64;
	// lwz r10,0(r3)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r9,4(r10)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r10.u32 + 4);
	// mtctr r9
	ctx.ctr.u64 = ctx.r9.u64;
	// bctrl 
	ctx.lr = 0x8B0900A0;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// mr r5,r31
	ctx.r5.u64 = ctx.r31.u64;
	// li r4,0
	ctx.r4.s64 = 0;
	// mr r30,r3
	ctx.r30.u64 = ctx.r3.u64;
	// bl 0x8b0cb8e0
	ctx.lr = 0x8B0900B0;
	sub_8B0CB8E0(ctx, base);
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// addi r1,r1,112
	ctx.r1.s64 = ctx.r1.s64 + 112;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// ld r30,-24(r1)
	ctx.r30.u64 = REX_LOAD_U64(ctx.r1.u32 + -24);
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0903A0) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9b4
	ctx.lr = 0x8B0903A8;
	__savegprlr_27(ctx, base);
	// stwu r1,-640(r1)
	ea = -640 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lwz r11,4(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 4);
	// mr r28,r3
	ctx.r28.u64 = ctx.r3.u64;
	// mr r29,r4
	ctx.r29.u64 = ctx.r4.u64;
	// mr r27,r5
	ctx.r27.u64 = ctx.r5.u64;
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// beq cr6,0x8b0904e0
	if (ctx.cr6.eq) goto loc_8B0904E0;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// li r5,0
	ctx.r5.s64 = 0;
	// addi r4,r11,1764
	ctx.r4.s64 = ctx.r11.s64 + 1764;
	// mr r3,r29
	ctx.r3.u64 = ctx.r29.u64;
	// bl 0x8b0c1588
	ctx.lr = 0x8B0903D8;
	sub_8B0C1588(ctx, base);
	// mr r30,r3
	ctx.r30.u64 = ctx.r3.u64;
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0904e0
	if (ctx.cr6.eq) goto loc_8B0904E0;
	// lbz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U8(ctx.r3.u32 + 0);
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// beq cr6,0x8b0904e0
	if (ctx.cr6.eq) goto loc_8B0904E0;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// li r5,0
	ctx.r5.s64 = 0;
	// addi r4,r11,1748
	ctx.r4.s64 = ctx.r11.s64 + 1748;
	// mr r3,r29
	ctx.r3.u64 = ctx.r29.u64;
	// bl 0x8b0c1588
	ctx.lr = 0x8B090404;
	sub_8B0C1588(ctx, base);
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0904e0
	if (ctx.cr6.eq) goto loc_8B0904E0;
	// lbz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U8(ctx.r3.u32 + 0);
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// beq cr6,0x8b0904e0
	if (ctx.cr6.eq) goto loc_8B0904E0;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// li r5,0
	ctx.r5.s64 = 0;
	// addi r4,r11,1732
	ctx.r4.s64 = ctx.r11.s64 + 1732;
	// mr r3,r29
	ctx.r3.u64 = ctx.r29.u64;
	// bl 0x8b0bfc38
	ctx.lr = 0x8B090430;
	sub_8B0BFC38(ctx, base);
	// mr r29,r3
	ctx.r29.u64 = ctx.r3.u64;
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// ble cr6,0x8b0904e0
	if (!ctx.cr6.gt) goto loc_8B0904E0;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// mr r6,r31
	ctx.r6.u64 = ctx.r31.u64;
	// addi r4,r11,1716
	ctx.r4.s64 = ctx.r11.s64 + 1716;
	// mr r5,r30
	ctx.r5.u64 = ctx.r30.u64;
	// addi r3,r1,336
	ctx.r3.s64 = ctx.r1.s64 + 336;
	// bl 0x8b090220
	ctx.lr = 0x8B090454;
	sub_8B090220(ctx, base);
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// li r5,0
	ctx.r5.s64 = 0;
	// lwz r3,4(r28)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r28.u32 + 4);
	// bl 0x8b0bfe68
	ctx.lr = 0x8B090464;
	sub_8B0BFE68(ctx, base);
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0904e0
	if (ctx.cr6.eq) goto loc_8B0904E0;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// mr r5,r30
	ctx.r5.u64 = ctx.r30.u64;
	// addi r4,r11,1696
	ctx.r4.s64 = ctx.r11.s64 + 1696;
	// addi r3,r1,80
	ctx.r3.s64 = ctx.r1.s64 + 80;
	// bl 0x8b090220
	ctx.lr = 0x8B090484;
	sub_8B090220(ctx, base);
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// li r5,0
	ctx.r5.s64 = 0;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0bfc38
	ctx.lr = 0x8B090494;
	sub_8B0BFC38(ctx, base);
	// cmpw cr6,r29,r3
	ctx.cr6.compare<int32_t>(ctx.r29.s32, ctx.r3.s32, ctx.xer);
	// bgt cr6,0x8b0904e0
	if (ctx.cr6.gt) goto loc_8B0904E0;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// mr r6,r29
	ctx.r6.u64 = ctx.r29.u64;
	// addi r4,r11,1684
	ctx.r4.s64 = ctx.r11.s64 + 1684;
	// mr r5,r30
	ctx.r5.u64 = ctx.r30.u64;
	// addi r3,r1,80
	ctx.r3.s64 = ctx.r1.s64 + 80;
	// bl 0x8b090220
	ctx.lr = 0x8B0904B4;
	sub_8B090220(ctx, base);
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// li r5,0
	ctx.r5.s64 = 0;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0bfa88
	ctx.lr = 0x8B0904C4;
	sub_8B0BFA88(ctx, base);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0904e0
	if (ctx.cr6.eq) goto loc_8B0904E0;
	// cmplwi cr6,r27,0
	ctx.cr6.compare<uint32_t>(ctx.r27.u32, 0, ctx.xer);
	// beq cr6,0x8b0904e4
	if (ctx.cr6.eq) goto loc_8B0904E4;
	// stw r31,0(r27)
	REX_STORE_U32(ctx.r27.u32 + 0, ctx.r31.u32);
	// addi r1,r1,640
	ctx.r1.s64 = ctx.r1.s64 + 640;
	// b 0x8b0cba04
	__restgprlr_27(ctx, base);
	return;
loc_8B0904E0:
	// li r3,0
	ctx.r3.s64 = 0;
loc_8B0904E4:
	// addi r1,r1,640
	ctx.r1.s64 = ctx.r1.s64 + 640;
	// b 0x8b0cba04
	__restgprlr_27(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B090910) {
	REX_FUNC_PROLOGUE();
	PPCRegister temp{};
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb980
	ctx.lr = 0x8B090918;
	__savegprlr_14(ctx, base);
	// stwu r1,-1040(r1)
	ea = -1040 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// stw r4,1068(r1)
	REX_STORE_U32(ctx.r1.u32 + 1068, ctx.r4.u32);
	// mr r26,r4
	ctx.r26.u64 = ctx.r4.u64;
	// stw r3,1060(r1)
	REX_STORE_U32(ctx.r1.u32 + 1060, ctx.r3.u32);
	// mr r30,r5
	ctx.r30.u64 = ctx.r5.u64;
	// li r5,0
	ctx.r5.s64 = 0;
	// addi r4,r11,1656
	ctx.r4.s64 = ctx.r11.s64 + 1656;
	// mr r27,r3
	ctx.r27.u64 = ctx.r3.u64;
	// lwz r3,4(r3)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r3.u32 + 4);
	// bl 0x8b0bfa88
	ctx.lr = 0x8B090944;
	sub_8B0BFA88(ctx, base);
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// mr r23,r3
	ctx.r23.u64 = ctx.r3.u64;
	// lwz r3,4(r27)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r27.u32 + 4);
	// li r5,0
	ctx.r5.s64 = 0;
	// addi r4,r10,1624
	ctx.r4.s64 = ctx.r10.s64 + 1624;
	// stw r23,92(r1)
	REX_STORE_U32(ctx.r1.u32 + 92, ctx.r23.u32);
	// bl 0x8b0bfa88
	ctx.lr = 0x8B090960;
	sub_8B0BFA88(ctx, base);
	// stw r3,96(r1)
	REX_STORE_U32(ctx.r1.u32 + 96, ctx.r3.u32);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b090fa8
	if (ctx.cr6.eq) goto loc_8B090FA8;
	// cmplwi cr6,r23,0
	ctx.cr6.compare<uint32_t>(ctx.r23.u32, 0, ctx.xer);
	// beq cr6,0x8b090fa8
	if (ctx.cr6.eq) goto loc_8B090FA8;
	// mr r5,r26
	ctx.r5.u64 = ctx.r26.u64;
	// addi r4,r27,24
	ctx.r4.s64 = ctx.r27.s64 + 24;
	// addi r3,r1,80
	ctx.r3.s64 = ctx.r1.s64 + 80;
	// bl 0x8b0c5770
	ctx.lr = 0x8B090984;
	sub_8B0C5770(ctx, base);
	// lhz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U16(ctx.r3.u32 + 0);
	// cmplwi cr6,r11,65535
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 65535, ctx.xer);
	// bne cr6,0x8b090fa8
	if (!ctx.cr6.eq) goto loc_8B090FA8;
	// addi r3,r27,8
	ctx.r3.s64 = ctx.r27.s64 + 8;
	// mr r4,r26
	ctx.r4.u64 = ctx.r26.u64;
	// bl 0x8b090890
	ctx.lr = 0x8B09099C;
	sub_8B090890(ctx, base);
	// mr r11,r3
	ctx.r11.u64 = ctx.r3.u64;
	// li r25,0
	ctx.r25.s64 = 0;
	// li r3,36
	ctx.r3.s64 = 36;
	// stw r25,0(r11)
	REX_STORE_U32(ctx.r11.u32 + 0, ctx.r25.u32);
	// bl 0x8b0bf448
	ctx.lr = 0x8B0909B0;
	sub_8B0BF448(ctx, base);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0909cc
	if (ctx.cr6.eq) goto loc_8B0909CC;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// addi r4,r11,2852
	ctx.r4.s64 = ctx.r11.s64 + 2852;
	// bl 0x8b0bf9f8
	ctx.lr = 0x8B0909C4;
	sub_8B0BF9F8(ctx, base);
	// mr r14,r3
	ctx.r14.u64 = ctx.r3.u64;
	// b 0x8b0909d0
	goto loc_8B0909D0;
loc_8B0909CC:
	// mr r14,r25
	ctx.r14.u64 = ctx.r25.u64;
loc_8B0909D0:
	// lis r11,-29936
	ctx.r11.s64 = -1961885696;
	// lwz r11,-17852(r11)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r11.u32 + -17852);
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// addi r4,r11,4
	ctx.r4.s64 = ctx.r11.s64 + 4;
	// bne cr6,0x8b0909e8
	if (!ctx.cr6.eq) goto loc_8B0909E8;
	// mr r4,r25
	ctx.r4.u64 = ctx.r25.u64;
loc_8B0909E8:
	// li r6,0
	ctx.r6.s64 = 0;
	// mr r5,r26
	ctx.r5.u64 = ctx.r26.u64;
	// mr r3,r14
	ctx.r3.u64 = ctx.r14.u64;
	// bl 0x8b0c27b0
	ctx.lr = 0x8B0909F8;
	sub_8B0C27B0(ctx, base);
	// clrlwi r11,r3,24
	ctx.r11.u64 = ctx.r3.u32 & 0xFF;
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// bne cr6,0x8b090a10
	if (!ctx.cr6.eq) goto loc_8B090A10;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// addi r3,r11,2784
	ctx.r3.s64 = ctx.r11.s64 + 2784;
	// b 0x8b090f90
	goto loc_8B090F90;
loc_8B090A10:
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// li r5,0
	ctx.r5.s64 = 0;
	// addi r4,r11,2776
	ctx.r4.s64 = ctx.r11.s64 + 2776;
	// mr r3,r14
	ctx.r3.u64 = ctx.r14.u64;
	// bl 0x8b0c1588
	ctx.lr = 0x8B090A24;
	sub_8B0C1588(ctx, base);
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// mr r29,r3
	ctx.r29.u64 = ctx.r3.u64;
	// stw r3,84(r1)
	REX_STORE_U32(ctx.r1.u32 + 84, ctx.r3.u32);
	// addi r4,r10,2768
	ctx.r4.s64 = ctx.r10.s64 + 2768;
	// li r5,0
	ctx.r5.s64 = 0;
	// mr r3,r14
	ctx.r3.u64 = ctx.r14.u64;
	// bl 0x8b0c1588
	ctx.lr = 0x8B090A40;
	sub_8B0C1588(ctx, base);
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// cmplwi cr6,r29,0
	ctx.cr6.compare<uint32_t>(ctx.r29.u32, 0, ctx.xer);
	// stw r3,100(r1)
	REX_STORE_U32(ctx.r1.u32 + 100, ctx.r3.u32);
	// beq cr6,0x8b090f88
	if (ctx.cr6.eq) goto loc_8B090F88;
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b090f88
	if (ctx.cr6.eq) goto loc_8B090F88;
	// lbz r11,0(r29)
	ctx.r11.u64 = REX_LOAD_U8(ctx.r29.u32 + 0);
	// mr r10,r29
	ctx.r10.u64 = ctx.r29.u64;
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// beq cr6,0x8b090aa8
	if (ctx.cr6.eq) goto loc_8B090AA8;
loc_8B090A68:
	// extsb r11,r11
	ctx.r11.s64 = ctx.r11.s8;
	// cmpwi cr6,r11,97
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 97, ctx.xer);
	// blt cr6,0x8b090a7c
	if (ctx.cr6.lt) goto loc_8B090A7C;
	// cmpwi cr6,r11,122
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 122, ctx.xer);
	// ble cr6,0x8b090a9c
	if (!ctx.cr6.gt) goto loc_8B090A9C;
loc_8B090A7C:
	// cmpwi cr6,r11,65
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 65, ctx.xer);
	// blt cr6,0x8b090a8c
	if (ctx.cr6.lt) goto loc_8B090A8C;
	// cmpwi cr6,r11,90
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 90, ctx.xer);
	// ble cr6,0x8b090a9c
	if (!ctx.cr6.gt) goto loc_8B090A9C;
loc_8B090A8C:
	// cmpwi cr6,r11,48
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 48, ctx.xer);
	// blt cr6,0x8b090b08
	if (ctx.cr6.lt) goto loc_8B090B08;
	// cmpwi cr6,r11,57
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 57, ctx.xer);
	// bgt cr6,0x8b090b08
	if (ctx.cr6.gt) goto loc_8B090B08;
loc_8B090A9C:
	// lbzu r11,1(r10)
	ea = 1 + ctx.r10.u32;
	ctx.r11.u64 = REX_LOAD_U8(ea);
	ctx.r10.u32 = ea;
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// bne cr6,0x8b090a68
	if (!ctx.cr6.eq) goto loc_8B090A68;
loc_8B090AA8:
	// lbz r11,0(r31)
	ctx.r11.u64 = REX_LOAD_U8(ctx.r31.u32 + 0);
	// mr r10,r31
	ctx.r10.u64 = ctx.r31.u64;
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// beq cr6,0x8b090ad8
	if (ctx.cr6.eq) goto loc_8B090AD8;
loc_8B090AB8:
	// extsb r11,r11
	ctx.r11.s64 = ctx.r11.s8;
	// cmpwi cr6,r11,48
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 48, ctx.xer);
	// blt cr6,0x8b090b20
	if (ctx.cr6.lt) goto loc_8B090B20;
	// cmpwi cr6,r11,57
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 57, ctx.xer);
	// bgt cr6,0x8b090b20
	if (ctx.cr6.gt) goto loc_8B090B20;
	// lbzu r11,1(r10)
	ea = 1 + ctx.r10.u32;
	ctx.r11.u64 = REX_LOAD_U8(ea);
	ctx.r10.u32 = ea;
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// bne cr6,0x8b090ab8
	if (!ctx.cr6.eq) goto loc_8B090AB8;
loc_8B090AD8:
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// li r5,0
	ctx.r5.s64 = 0;
	// addi r4,r11,2760
	ctx.r4.s64 = ctx.r11.s64 + 2760;
	// mr r3,r14
	ctx.r3.u64 = ctx.r14.u64;
	// bl 0x8b0bfa88
	ctx.lr = 0x8B090AEC;
	sub_8B0BFA88(ctx, base);
	// mr r28,r3
	ctx.r28.u64 = ctx.r3.u64;
	// stw r3,88(r1)
	REX_STORE_U32(ctx.r1.u32 + 88, ctx.r3.u32);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// bne cr6,0x8b090b38
	if (!ctx.cr6.eq) goto loc_8B090B38;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// addi r3,r11,2688
	ctx.r3.s64 = ctx.r11.s64 + 2688;
	// b 0x8b090f90
	goto loc_8B090F90;
loc_8B090B08:
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// mr r5,r26
	ctx.r5.u64 = ctx.r26.u64;
	// addi r3,r11,2600
	ctx.r3.s64 = ctx.r11.s64 + 2600;
	// mr r4,r29
	ctx.r4.u64 = ctx.r29.u64;
	// bl 0x8b0df2a8
	ctx.lr = 0x8B090B1C;
	sub_8B0DF2A8(ctx, base);
	// b 0x8b090f98
	goto loc_8B090F98;
loc_8B090B20:
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// mr r5,r26
	ctx.r5.u64 = ctx.r26.u64;
	// addi r3,r11,2512
	ctx.r3.s64 = ctx.r11.s64 + 2512;
	// mr r4,r31
	ctx.r4.u64 = ctx.r31.u64;
	// bl 0x8b0df2a8
	ctx.lr = 0x8B090B34;
	sub_8B0DF2A8(ctx, base);
	// b 0x8b090f98
	goto loc_8B090F98;
loc_8B090B38:
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// mr r6,r31
	ctx.r6.u64 = ctx.r31.u64;
	// addi r4,r11,2500
	ctx.r4.s64 = ctx.r11.s64 + 2500;
	// mr r5,r29
	ctx.r5.u64 = ctx.r29.u64;
	// addi r3,r1,112
	ctx.r3.s64 = ctx.r1.s64 + 112;
	// bl 0x8b090220
	ctx.lr = 0x8B090B50;
	sub_8B090220(ctx, base);
	// mr r5,r29
	ctx.r5.u64 = ctx.r29.u64;
	// addi r4,r27,92
	ctx.r4.s64 = ctx.r27.s64 + 92;
	// addi r3,r1,80
	ctx.r3.s64 = ctx.r1.s64 + 80;
	// bl 0x8b0c5770
	ctx.lr = 0x8B090B60;
	sub_8B0C5770(ctx, base);
	// lhz r10,0(r3)
	ctx.r10.u64 = REX_LOAD_U16(ctx.r3.u32 + 0);
	// mr r4,r29
	ctx.r4.u64 = ctx.r29.u64;
	// cmplwi cr6,r10,65535
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 65535, ctx.xer);
	// beq cr6,0x8b090bac
	if (ctx.cr6.eq) goto loc_8B090BAC;
	// addi r3,r27,76
	ctx.r3.s64 = ctx.r27.s64 + 76;
	// bl 0x8b090890
	ctx.lr = 0x8B090B78;
	sub_8B090890(ctx, base);
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// lwz r3,0(r3)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// addi r5,r11,1791
	ctx.r5.s64 = ctx.r11.s64 + 1791;
	// addi r4,r10,2492
	ctx.r4.s64 = ctx.r10.s64 + 2492;
	// bl 0x8b0c1588
	ctx.lr = 0x8B090B90;
	sub_8B0C1588(ctx, base);
	// lis r9,-29944
	ctx.r9.s64 = -1962409984;
	// mr r6,r3
	ctx.r6.u64 = ctx.r3.u64;
	// addi r3,r9,2408
	ctx.r3.s64 = ctx.r9.s64 + 2408;
	// mr r5,r26
	ctx.r5.u64 = ctx.r26.u64;
	// mr r4,r29
	ctx.r4.u64 = ctx.r29.u64;
	// bl 0x8b0df2a8
	ctx.lr = 0x8B090BA8;
	sub_8B0DF2A8(ctx, base);
	// b 0x8b090f98
	goto loc_8B090F98;
loc_8B090BAC:
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// mr r5,r31
	ctx.r5.u64 = ctx.r31.u64;
	// addi r3,r11,2376
	ctx.r3.s64 = ctx.r11.s64 + 2376;
	// bl 0x8b0df298
	ctx.lr = 0x8B090BBC;
	sub_8B0DF298(ctx, base);
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// addi r24,r11,1791
	ctx.r24.s64 = ctx.r11.s64 + 1791;
	// addi r31,r10,2360
	ctx.r31.s64 = ctx.r10.s64 + 2360;
	// mr r5,r24
	ctx.r5.u64 = ctx.r24.u64;
	// mr r4,r31
	ctx.r4.u64 = ctx.r31.u64;
	// mr r3,r14
	ctx.r3.u64 = ctx.r14.u64;
	// bl 0x8b0c1588
	ctx.lr = 0x8B090BDC;
	sub_8B0C1588(ctx, base);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b090bf0
	if (ctx.cr6.eq) goto loc_8B090BF0;
	// lbz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U8(ctx.r3.u32 + 0);
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// bne cr6,0x8b090c00
	if (!ctx.cr6.eq) goto loc_8B090C00;
loc_8B090BF0:
	// mr r4,r31
	ctx.r4.u64 = ctx.r31.u64;
	// mr r5,r29
	ctx.r5.u64 = ctx.r29.u64;
	// mr r3,r14
	ctx.r3.u64 = ctx.r14.u64;
	// bl 0x8b0c0010
	ctx.lr = 0x8B090C00;
	sub_8B0C0010(ctx, base);
loc_8B090C00:
	// mr r4,r29
	ctx.r4.u64 = ctx.r29.u64;
	// mr r3,r14
	ctx.r3.u64 = ctx.r14.u64;
	// bl 0x8b0bf328
	ctx.lr = 0x8B090C0C;
	sub_8B0BF328(ctx, base);
	// clrlwi r11,r30,24
	ctx.r11.u64 = ctx.r30.u32 & 0xFF;
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// addic r9,r11,-1
	ctx.xer.ca = ctx.r11.u32 > 0;
	ctx.r9.s64 = ctx.r11.s64 + -1;
	// addi r4,r10,2352
	ctx.r4.s64 = ctx.r10.s64 + 2352;
	// subfe r5,r9,r11
	temp.u8 = (~ctx.r9.u32 + ctx.r11.u32 < ~ctx.r9.u32) | (~ctx.r9.u32 + ctx.r11.u32 + ctx.xer.ca < ctx.xer.ca);
	ctx.r5.u64 = ~ctx.r9.u64 + ctx.r11.u64 + ctx.xer.ca;
	ctx.xer.ca = temp.u8;
	// mr r3,r14
	ctx.r3.u64 = ctx.r14.u64;
	// bl 0x8b0c0148
	ctx.lr = 0x8B090C28;
	sub_8B0C0148(ctx, base);
	// lis r8,-29944
	ctx.r8.s64 = -1962409984;
	// mr r5,r26
	ctx.r5.u64 = ctx.r26.u64;
	// addi r4,r8,2492
	ctx.r4.s64 = ctx.r8.s64 + 2492;
	// mr r3,r14
	ctx.r3.u64 = ctx.r14.u64;
	// bl 0x8b0c0010
	ctx.lr = 0x8B090C3C;
	sub_8B0C0010(ctx, base);
	// lis r7,-29944
	ctx.r7.s64 = -1962409984;
	// addi r5,r1,112
	ctx.r5.s64 = ctx.r1.s64 + 112;
	// addi r4,r7,2344
	ctx.r4.s64 = ctx.r7.s64 + 2344;
	// mr r3,r14
	ctx.r3.u64 = ctx.r14.u64;
	// bl 0x8b0c0010
	ctx.lr = 0x8B090C50;
	sub_8B0C0010(ctx, base);
	// mr r3,r23
	ctx.r3.u64 = ctx.r23.u64;
	// stw r25,80(r1)
	REX_STORE_U32(ctx.r1.u32 + 80, ctx.r25.u32);
	// bl 0x8b0bf248
	ctx.lr = 0x8B090C5C;
	sub_8B0BF248(ctx, base);
	// mr r23,r3
	ctx.r23.u64 = ctx.r3.u64;
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b090ecc
	if (ctx.cr6.eq) goto loc_8B090ECC;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// lis r9,-29944
	ctx.r9.s64 = -1962409984;
	// lis r8,-29944
	ctx.r8.s64 = -1962409984;
	// lis r7,-29944
	ctx.r7.s64 = -1962409984;
	// lis r6,-29944
	ctx.r6.s64 = -1962409984;
	// lis r5,-29944
	ctx.r5.s64 = -1962409984;
	// lis r4,-29944
	ctx.r4.s64 = -1962409984;
	// lis r3,-29944
	ctx.r3.s64 = -1962409984;
	// lis r31,-29944
	ctx.r31.s64 = -1962409984;
	// lis r30,-29944
	ctx.r30.s64 = -1962409984;
	// addi r19,r11,2316
	ctx.r19.s64 = ctx.r11.s64 + 2316;
	// addi r18,r10,1776
	ctx.r18.s64 = ctx.r10.s64 + 1776;
	// addi r16,r9,2240
	ctx.r16.s64 = ctx.r9.s64 + 2240;
	// addi r22,r8,2228
	ctx.r22.s64 = ctx.r8.s64 + 2228;
	// addi r17,r7,2212
	ctx.r17.s64 = ctx.r7.s64 + 2212;
	// addi r25,r6,2204
	ctx.r25.s64 = ctx.r6.s64 + 2204;
	// addi r21,r5,2196
	ctx.r21.s64 = ctx.r5.s64 + 2196;
	// addi r26,r4,2184
	ctx.r26.s64 = ctx.r4.s64 + 2184;
	// addi r15,r3,2104
	ctx.r15.s64 = ctx.r3.s64 + 2104;
	// addi r20,r31,1792
	ctx.r20.s64 = ctx.r31.s64 + 1792;
	// addi r27,r30,1788
	ctx.r27.s64 = ctx.r30.s64 + 1788;
	// b 0x8b090cc8
	goto loc_8B090CC8;
loc_8B090CC4:
	// lwz r28,88(r1)
	ctx.r28.u64 = REX_LOAD_U32(ctx.r1.u32 + 88);
loc_8B090CC8:
	// mr r3,r23
	ctx.r3.u64 = ctx.r23.u64;
	// bl 0x8b0beee8
	ctx.lr = 0x8B090CD0;
	sub_8B0BEEE8(ctx, base);
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// mr r3,r28
	ctx.r3.u64 = ctx.r28.u64;
	// li r5,0
	ctx.r5.s64 = 0;
	// bl 0x8b0bfa88
	ctx.lr = 0x8B090CE0;
	sub_8B0BFA88(ctx, base);
	// mr r28,r3
	ctx.r28.u64 = ctx.r3.u64;
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b090ea8
	if (ctx.cr6.eq) goto loc_8B090EA8;
	// mr r4,r27
	ctx.r4.u64 = ctx.r27.u64;
	// li r5,1
	ctx.r5.s64 = 1;
	// addi r3,r1,368
	ctx.r3.s64 = ctx.r1.s64 + 368;
	// li r29,0
	ctx.r29.s64 = 0;
	// bl 0x8b090220
	ctx.lr = 0x8B090D00;
	sub_8B090220(ctx, base);
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// li r5,0
	ctx.r5.s64 = 0;
	// mr r3,r28
	ctx.r3.u64 = ctx.r28.u64;
	// bl 0x8b0bfa88
	ctx.lr = 0x8B090D10;
	sub_8B0BFA88(ctx, base);
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b090e14
	if (ctx.cr6.eq) goto loc_8B090E14;
	// li r30,1
	ctx.r30.s64 = 1;
loc_8B090D20:
	// mr r5,r24
	ctx.r5.u64 = ctx.r24.u64;
	// mr r4,r20
	ctx.r4.u64 = ctx.r20.u64;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0c1588
	ctx.lr = 0x8B090D30;
	sub_8B0C1588(ctx, base);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b090e44
	if (ctx.cr6.eq) goto loc_8B090E44;
	// lbz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U8(ctx.r3.u32 + 0);
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// beq cr6,0x8b090e44
	if (ctx.cr6.eq) goto loc_8B090E44;
	// mr r5,r24
	ctx.r5.u64 = ctx.r24.u64;
	// mr r4,r26
	ctx.r4.u64 = ctx.r26.u64;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0c1588
	ctx.lr = 0x8B090D54;
	sub_8B0C1588(ctx, base);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b090d68
	if (ctx.cr6.eq) goto loc_8B090D68;
	// lbz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U8(ctx.r3.u32 + 0);
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// bne cr6,0x8b090d94
	if (!ctx.cr6.eq) goto loc_8B090D94;
loc_8B090D68:
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0beee8
	ctx.lr = 0x8B090D70;
	sub_8B0BEEE8(ctx, base);
	// mr r6,r3
	ctx.r6.u64 = ctx.r3.u64;
	// mr r4,r21
	ctx.r4.u64 = ctx.r21.u64;
	// lwz r5,84(r1)
	ctx.r5.u64 = REX_LOAD_U32(ctx.r1.u32 + 84);
	// addi r3,r1,624
	ctx.r3.s64 = ctx.r1.s64 + 624;
	// bl 0x8b090220
	ctx.lr = 0x8B090D84;
	sub_8B090220(ctx, base);
	// mr r5,r3
	ctx.r5.u64 = ctx.r3.u64;
	// mr r4,r26
	ctx.r4.u64 = ctx.r26.u64;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0c0010
	ctx.lr = 0x8B090D94;
	sub_8B0C0010(ctx, base);
loc_8B090D94:
	// mr r5,r24
	ctx.r5.u64 = ctx.r24.u64;
	// mr r4,r25
	ctx.r4.u64 = ctx.r25.u64;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0c1588
	ctx.lr = 0x8B090DA4;
	sub_8B0C1588(ctx, base);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b090db8
	if (ctx.cr6.eq) goto loc_8B090DB8;
	// lbz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U8(ctx.r3.u32 + 0);
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// bne cr6,0x8b090dc8
	if (!ctx.cr6.eq) goto loc_8B090DC8;
loc_8B090DB8:
	// mr r5,r17
	ctx.r5.u64 = ctx.r17.u64;
	// mr r4,r25
	ctx.r4.u64 = ctx.r25.u64;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0c0010
	ctx.lr = 0x8B090DC8;
	sub_8B0C0010(ctx, base);
loc_8B090DC8:
	// mr r5,r30
	ctx.r5.u64 = ctx.r30.u64;
	// mr r4,r22
	ctx.r4.u64 = ctx.r22.u64;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0c0148
	ctx.lr = 0x8B090DD8;
	sub_8B0C0148(ctx, base);
	// addi r30,r30,1
	ctx.r30.s64 = ctx.r30.s64 + 1;
	// mr r4,r27
	ctx.r4.u64 = ctx.r27.u64;
	// mr r5,r30
	ctx.r5.u64 = ctx.r30.u64;
	// addi r3,r1,368
	ctx.r3.s64 = ctx.r1.s64 + 368;
	// addi r29,r29,1
	ctx.r29.s64 = ctx.r29.s64 + 1;
	// bl 0x8b090220
	ctx.lr = 0x8B090DF0;
	sub_8B090220(ctx, base);
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// li r5,0
	ctx.r5.s64 = 0;
	// mr r3,r28
	ctx.r3.u64 = ctx.r28.u64;
	// bl 0x8b0bfa88
	ctx.lr = 0x8B090E00;
	sub_8B0BFA88(ctx, base);
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// bne cr6,0x8b090d20
	if (!ctx.cr6.eq) goto loc_8B090D20;
	// cmpwi cr6,r29,0
	ctx.cr6.compare<int32_t>(ctx.r29.s32, 0, ctx.xer);
	// bne cr6,0x8b090e70
	if (!ctx.cr6.eq) goto loc_8B090E70;
loc_8B090E14:
	// mr r4,r28
	ctx.r4.u64 = ctx.r28.u64;
	// lwz r3,88(r1)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r1.u32 + 88);
	// bl 0x8b0bf1a0
	ctx.lr = 0x8B090E20;
	sub_8B0BF1A0(ctx, base);
	// mr r3,r28
	ctx.r3.u64 = ctx.r28.u64;
	// bl 0x8b0c04f0
	ctx.lr = 0x8B090E28;
	sub_8B0C04F0(ctx, base);
	// mr r3,r23
	ctx.r3.u64 = ctx.r23.u64;
	// bl 0x8b0beee8
	ctx.lr = 0x8B090E30;
	sub_8B0BEEE8(ctx, base);
	// mr r5,r3
	ctx.r5.u64 = ctx.r3.u64;
	// mr r3,r16
	ctx.r3.u64 = ctx.r16.u64;
	// lwz r4,1068(r1)
	ctx.r4.u64 = REX_LOAD_U32(ctx.r1.u32 + 1068);
	// bl 0x8b0df2a8
	ctx.lr = 0x8B090E40;
	sub_8B0DF2A8(ctx, base);
	// b 0x8b090ea4
	goto loc_8B090EA4;
loc_8B090E44:
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0beee8
	ctx.lr = 0x8B090E4C;
	sub_8B0BEEE8(ctx, base);
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// mr r3,r23
	ctx.r3.u64 = ctx.r23.u64;
	// bl 0x8b0beee8
	ctx.lr = 0x8B090E58;
	sub_8B0BEEE8(ctx, base);
	// mr r5,r3
	ctx.r5.u64 = ctx.r3.u64;
	// mr r3,r15
	ctx.r3.u64 = ctx.r15.u64;
	// lwz r4,1068(r1)
	ctx.r4.u64 = REX_LOAD_U32(ctx.r1.u32 + 1068);
	// mr r6,r31
	ctx.r6.u64 = ctx.r31.u64;
	// bl 0x8b0df2a8
	ctx.lr = 0x8B090E6C;
	sub_8B0DF2A8(ctx, base);
	// b 0x8b090e14
	goto loc_8B090E14;
loc_8B090E70:
	// mr r4,r18
	ctx.r4.u64 = ctx.r18.u64;
	// mr r5,r29
	ctx.r5.u64 = ctx.r29.u64;
	// mr r3,r28
	ctx.r3.u64 = ctx.r28.u64;
	// bl 0x8b0c0148
	ctx.lr = 0x8B090E80;
	sub_8B0C0148(ctx, base);
	// mr r3,r23
	ctx.r3.u64 = ctx.r23.u64;
	// bl 0x8b0beee8
	ctx.lr = 0x8B090E88;
	sub_8B0BEEE8(ctx, base);
	// mr r5,r3
	ctx.r5.u64 = ctx.r3.u64;
	// mr r4,r29
	ctx.r4.u64 = ctx.r29.u64;
	// mr r3,r19
	ctx.r3.u64 = ctx.r19.u64;
	// bl 0x8b0df298
	ctx.lr = 0x8B090E98;
	sub_8B0DF298(ctx, base);
	// lwz r11,80(r1)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r1.u32 + 80);
	// addi r10,r11,1
	ctx.r10.s64 = ctx.r11.s64 + 1;
	// stw r10,80(r1)
	REX_STORE_U32(ctx.r1.u32 + 80, ctx.r10.u32);
loc_8B090EA4:
	// lwz r29,84(r1)
	ctx.r29.u64 = REX_LOAD_U32(ctx.r1.u32 + 84);
loc_8B090EA8:
	// mr r3,r23
	ctx.r3.u64 = ctx.r23.u64;
	// bl 0x8b0bf280
	ctx.lr = 0x8B090EB0;
	sub_8B0BF280(ctx, base);
	// mr r23,r3
	ctx.r23.u64 = ctx.r3.u64;
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// bne cr6,0x8b090cc4
	if (!ctx.cr6.eq) goto loc_8B090CC4;
	// lwz r30,80(r1)
	ctx.r30.u64 = REX_LOAD_U32(ctx.r1.u32 + 80);
	// cmpwi cr6,r30,0
	ctx.cr6.compare<int32_t>(ctx.r30.s32, 0, ctx.xer);
	// bne cr6,0x8b090ed8
	if (!ctx.cr6.eq) goto loc_8B090ED8;
	// lwz r26,1068(r1)
	ctx.r26.u64 = REX_LOAD_U32(ctx.r1.u32 + 1068);
loc_8B090ECC:
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// addi r3,r11,2008
	ctx.r3.s64 = ctx.r11.s64 + 2008;
	// b 0x8b090f90
	goto loc_8B090F90;
loc_8B090ED8:
	// lwz r31,1060(r1)
	ctx.r31.u64 = REX_LOAD_U32(ctx.r1.u32 + 1060);
	// lwz r4,1068(r1)
	ctx.r4.u64 = REX_LOAD_U32(ctx.r1.u32 + 1068);
	// addi r3,r31,8
	ctx.r3.s64 = ctx.r31.s64 + 8;
	// bl 0x8b090890
	ctx.lr = 0x8B090EE8;
	sub_8B090890(ctx, base);
	// mr r11,r3
	ctx.r11.u64 = ctx.r3.u64;
	// mr r4,r29
	ctx.r4.u64 = ctx.r29.u64;
	// addi r3,r31,76
	ctx.r3.s64 = ctx.r31.s64 + 76;
	// stw r14,0(r11)
	REX_STORE_U32(ctx.r11.u32 + 0, ctx.r14.u32);
	// bl 0x8b090890
	ctx.lr = 0x8B090EFC;
	sub_8B090890(ctx, base);
	// mr r10,r3
	ctx.r10.u64 = ctx.r3.u64;
	// mr r4,r14
	ctx.r4.u64 = ctx.r14.u64;
	// lwz r3,96(r1)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r1.u32 + 96);
	// stw r14,0(r10)
	REX_STORE_U32(ctx.r10.u32 + 0, ctx.r14.u32);
	// bl 0x8b0bfc00
	ctx.lr = 0x8B090F10;
	sub_8B0BFC00(ctx, base);
	// lwz r3,92(r1)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r1.u32 + 92);
	// bl 0x8b0bf248
	ctx.lr = 0x8B090F18;
	sub_8B0BF248(ctx, base);
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b090f68
	if (ctx.cr6.eq) goto loc_8B090F68;
loc_8B090F24:
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0beee8
	ctx.lr = 0x8B090F2C;
	sub_8B0BEEE8(ctx, base);
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// li r5,0
	ctx.r5.s64 = 0;
	// lwz r3,88(r1)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r1.u32 + 88);
	// bl 0x8b0bfa88
	ctx.lr = 0x8B090F3C;
	sub_8B0BFA88(ctx, base);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b090f54
	if (ctx.cr6.eq) goto loc_8B090F54;
	// mr r5,r14
	ctx.r5.u64 = ctx.r14.u64;
	// mr r4,r29
	ctx.r4.u64 = ctx.r29.u64;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0c0250
	ctx.lr = 0x8B090F54;
	sub_8B0C0250(ctx, base);
loc_8B090F54:
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0bf280
	ctx.lr = 0x8B090F5C;
	sub_8B0BF280(ctx, base);
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// bne cr6,0x8b090f24
	if (!ctx.cr6.eq) goto loc_8B090F24;
loc_8B090F68:
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lwz r5,100(r1)
	ctx.r5.u64 = REX_LOAD_U32(ctx.r1.u32 + 100);
	// mr r6,r30
	ctx.r6.u64 = ctx.r30.u64;
	// addi r3,r11,1960
	ctx.r3.s64 = ctx.r11.s64 + 1960;
	// mr r4,r29
	ctx.r4.u64 = ctx.r29.u64;
	// bl 0x8b0df298
	ctx.lr = 0x8B090F80;
	sub_8B0DF298(ctx, base);
	// addi r1,r1,1040
	ctx.r1.s64 = ctx.r1.s64 + 1040;
	// b 0x8b0cb9d0
	__restgprlr_14(ctx, base);
	return;
loc_8B090F88:
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// addi r3,r11,1896
	ctx.r3.s64 = ctx.r11.s64 + 1896;
loc_8B090F90:
	// mr r4,r26
	ctx.r4.u64 = ctx.r26.u64;
	// bl 0x8b0df2a8
	ctx.lr = 0x8B090F98;
	sub_8B0DF2A8(ctx, base);
loc_8B090F98:
	// cmplwi cr6,r14,0
	ctx.cr6.compare<uint32_t>(ctx.r14.u32, 0, ctx.xer);
	// beq cr6,0x8b090fa8
	if (ctx.cr6.eq) goto loc_8B090FA8;
	// mr r3,r14
	ctx.r3.u64 = ctx.r14.u64;
	// bl 0x8b0c04f0
	ctx.lr = 0x8B090FA8;
	sub_8B0C04F0(ctx, base);
loc_8B090FA8:
	// addi r1,r1,1040
	ctx.r1.s64 = ctx.r1.s64 + 1040;
	// b 0x8b0cb9d0
	__restgprlr_14(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B092EE0) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9a4
	ctx.lr = 0x8B092EE8;
	__savegprlr_23(ctx, base);
	// stwu r1,-688(r1)
	ea = -688 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// mr r27,r4
	ctx.r27.u64 = ctx.r4.u64;
	// mr r31,r5
	ctx.r31.u64 = ctx.r5.u64;
	// mr r23,r6
	ctx.r23.u64 = ctx.r6.u64;
	// cmplwi cr6,r4,0
	ctx.cr6.compare<uint32_t>(ctx.r4.u32, 0, ctx.xer);
	// bne cr6,0x8b09300c
	if (!ctx.cr6.eq) goto loc_8B09300C;
	// cmplwi cr6,r5,0
	ctx.cr6.compare<uint32_t>(ctx.r5.u32, 0, ctx.xer);
	// bne cr6,0x8b092f14
	if (!ctx.cr6.eq) goto loc_8B092F14;
loc_8B092F08:
	// li r3,0
	ctx.r3.s64 = 0;
	// addi r1,r1,688
	ctx.r1.s64 = ctx.r1.s64 + 688;
	// b 0x8b0cb9f4
	__restgprlr_23(ctx, base);
	return;
loc_8B092F14:
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// li r5,0
	ctx.r5.s64 = 0;
	// addi r4,r11,4656
	ctx.r4.s64 = ctx.r11.s64 + 4656;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0bfc38
	ctx.lr = 0x8B092F28;
	sub_8B0BFC38(ctx, base);
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// bne cr6,0x8b092f08
	if (!ctx.cr6.eq) goto loc_8B092F08;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// li r5,0
	ctx.r5.s64 = 0;
	// addi r4,r11,5292
	ctx.r4.s64 = ctx.r11.s64 + 5292;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0c1588
	ctx.lr = 0x8B092F44;
	sub_8B0C1588(ctx, base);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b092f08
	if (ctx.cr6.eq) goto loc_8B092F08;
	// lbz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U8(ctx.r3.u32 + 0);
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// beq cr6,0x8b092f08
	if (ctx.cr6.eq) goto loc_8B092F08;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// addi r5,r11,1791
	ctx.r5.s64 = ctx.r11.s64 + 1791;
	// addi r4,r10,1748
	ctx.r4.s64 = ctx.r10.s64 + 1748;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0c1588
	ctx.lr = 0x8B092F70;
	sub_8B0C1588(ctx, base);
	// lis r9,-29944
	ctx.r9.s64 = -1962409984;
	// mr r5,r3
	ctx.r5.u64 = ctx.r3.u64;
	// addi r4,r9,5280
	ctx.r4.s64 = ctx.r9.s64 + 5280;
	// addi r3,r1,352
	ctx.r3.s64 = ctx.r1.s64 + 352;
	// bl 0x8b090220
	ctx.lr = 0x8B092F84;
	sub_8B090220(ctx, base);
	// lis r8,-29938
	ctx.r8.s64 = -1962016768;
	// mr r30,r3
	ctx.r30.u64 = ctx.r3.u64;
	// lwz r3,540(r8)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r8.u32 + 540);
	// lwz r7,0(r3)
	ctx.r7.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r6,0(r7)
	ctx.r6.u64 = REX_LOAD_U32(ctx.r7.u32 + 0);
	// mtctr r6
	ctx.ctr.u64 = ctx.r6.u64;
	// bctrl 
	ctx.lr = 0x8B092FA0;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// mr r4,r30
	ctx.r4.u64 = ctx.r30.u64;
	// li r5,-1
	ctx.r5.s64 = -1;
	// bl 0x8b0bfc38
	ctx.lr = 0x8B092FAC;
	sub_8B0BFC38(ctx, base);
	// lis r5,-29944
	ctx.r5.s64 = -1962409984;
	// mr r30,r3
	ctx.r30.u64 = ctx.r3.u64;
	// addi r4,r5,5252
	ctx.r4.s64 = ctx.r5.s64 + 5252;
	// li r5,0
	ctx.r5.s64 = 0;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0bfc38
	ctx.lr = 0x8B092FC4;
	sub_8B0BFC38(ctx, base);
	// cmpw cr6,r3,r30
	ctx.cr6.compare<int32_t>(ctx.r3.s32, ctx.r30.s32, ctx.xer);
	// ble cr6,0x8b092f08
	if (!ctx.cr6.gt) goto loc_8B092F08;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// li r5,0
	ctx.r5.s64 = 0;
	// addi r4,r11,5244
	ctx.r4.s64 = ctx.r11.s64 + 5244;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0bfa88
	ctx.lr = 0x8B092FE0;
	sub_8B0BFA88(ctx, base);
	// mr r30,r3
	ctx.r30.u64 = ctx.r3.u64;
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b09336c
	if (ctx.cr6.eq) goto loc_8B09336C;
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0bf1a0
	ctx.lr = 0x8B092FF8;
	sub_8B0BF1A0(ctx, base);
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// bl 0x8b0c04f0
	ctx.lr = 0x8B093000;
	sub_8B0C04F0(ctx, base);
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// addi r1,r1,688
	ctx.r1.s64 = ctx.r1.s64 + 688;
	// b 0x8b0cb9f4
	__restgprlr_23(ctx, base);
	return;
loc_8B09300C:
	// cmplwi cr6,r31,0
	ctx.cr6.compare<uint32_t>(ctx.r31.u32, 0, ctx.xer);
	// bne cr6,0x8b093280
	if (!ctx.cr6.eq) goto loc_8B093280;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// addi r31,r11,1791
	ctx.r31.s64 = ctx.r11.s64 + 1791;
	// addi r25,r10,1764
	ctx.r25.s64 = ctx.r10.s64 + 1764;
	// mr r5,r31
	ctx.r5.u64 = ctx.r31.u64;
	// mr r4,r25
	ctx.r4.u64 = ctx.r25.u64;
	// mr r3,r27
	ctx.r3.u64 = ctx.r27.u64;
	// bl 0x8b0c1588
	ctx.lr = 0x8B093034;
	sub_8B0C1588(ctx, base);
	// mr r29,r3
	ctx.r29.u64 = ctx.r3.u64;
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b092f08
	if (ctx.cr6.eq) goto loc_8B092F08;
	// lbz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U8(ctx.r3.u32 + 0);
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// beq cr6,0x8b092f08
	if (ctx.cr6.eq) goto loc_8B092F08;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// addi r3,r11,4460
	ctx.r3.s64 = ctx.r11.s64 + 4460;
	// bl 0x8b0cea10
	ctx.lr = 0x8B09305C;
	sub_8B0CEA10(ctx, base);
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// beq cr6,0x8b093080
	if (ctx.cr6.eq) goto loc_8B093080;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// mr r4,r29
	ctx.r4.u64 = ctx.r29.u64;
	// addi r3,r11,2908
	ctx.r3.s64 = ctx.r11.s64 + 2908;
	// bl 0x8b0cea10
	ctx.lr = 0x8B093074;
	sub_8B0CEA10(ctx, base);
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// li r11,0
	ctx.r11.s64 = 0;
	// bne cr6,0x8b093084
	if (!ctx.cr6.eq) goto loc_8B093084;
loc_8B093080:
	// li r11,1
	ctx.r11.s64 = 1;
loc_8B093084:
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// mr r4,r29
	ctx.r4.u64 = ctx.r29.u64;
	// addi r3,r10,2892
	ctx.r3.s64 = ctx.r10.s64 + 2892;
	// clrlwi r26,r11,24
	ctx.r26.u64 = ctx.r11.u32 & 0xFF;
	// bl 0x8b0cea10
	ctx.lr = 0x8B093098;
	sub_8B0CEA10(ctx, base);
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// beq cr6,0x8b0930bc
	if (ctx.cr6.eq) goto loc_8B0930BC;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// mr r4,r29
	ctx.r4.u64 = ctx.r29.u64;
	// addi r3,r11,2900
	ctx.r3.s64 = ctx.r11.s64 + 2900;
	// bl 0x8b0cea10
	ctx.lr = 0x8B0930B0;
	sub_8B0CEA10(ctx, base);
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// li r10,0
	ctx.r10.s64 = 0;
	// bne cr6,0x8b0930c0
	if (!ctx.cr6.eq) goto loc_8B0930C0;
loc_8B0930BC:
	// li r10,1
	ctx.r10.s64 = 1;
loc_8B0930C0:
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// mr r5,r31
	ctx.r5.u64 = ctx.r31.u64;
	// addi r30,r11,1748
	ctx.r30.s64 = ctx.r11.s64 + 1748;
	// mr r3,r27
	ctx.r3.u64 = ctx.r27.u64;
	// mr r4,r30
	ctx.r4.u64 = ctx.r30.u64;
	// clrlwi r24,r10,24
	ctx.r24.u64 = ctx.r10.u32 & 0xFF;
	// bl 0x8b0c1588
	ctx.lr = 0x8B0930DC;
	sub_8B0C1588(ctx, base);
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b092f08
	if (ctx.cr6.eq) goto loc_8B092F08;
	// lbz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U8(ctx.r3.u32 + 0);
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// beq cr6,0x8b092f08
	if (ctx.cr6.eq) goto loc_8B092F08;
	// li r3,36
	ctx.r3.s64 = 36;
	// bl 0x8b0bf448
	ctx.lr = 0x8B0930FC;
	sub_8B0BF448(ctx, base);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b093118
	if (ctx.cr6.eq) goto loc_8B093118;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// addi r4,r11,5244
	ctx.r4.s64 = ctx.r11.s64 + 5244;
	// bl 0x8b0bf9f8
	ctx.lr = 0x8B093110;
	sub_8B0BF9F8(ctx, base);
	// mr r28,r3
	ctx.r28.u64 = ctx.r3.u64;
	// b 0x8b09311c
	goto loc_8B09311C;
loc_8B093118:
	// li r28,0
	ctx.r28.s64 = 0;
loc_8B09311C:
	// li r11,0
	ctx.r11.s64 = 0;
	// addi r3,r1,80
	ctx.r3.s64 = ctx.r1.s64 + 80;
	// stw r11,80(r1)
	REX_STORE_U32(ctx.r1.u32 + 80, ctx.r11.u32);
	// bl 0x8b0c73c0
	ctx.lr = 0x8B09312C;
	sub_8B0C73C0(ctx, base);
	// mr r4,r25
	ctx.r4.u64 = ctx.r25.u64;
	// mr r5,r29
	ctx.r5.u64 = ctx.r29.u64;
	// mr r3,r28
	ctx.r3.u64 = ctx.r28.u64;
	// bl 0x8b0c0010
	ctx.lr = 0x8B09313C;
	sub_8B0C0010(ctx, base);
	// addi r4,r1,80
	ctx.r4.s64 = ctx.r1.s64 + 80;
	// mr r3,r29
	ctx.r3.u64 = ctx.r29.u64;
	// bl 0x8b0928f0
	ctx.lr = 0x8B093148;
	sub_8B0928F0(ctx, base);
	// mr r4,r30
	ctx.r4.u64 = ctx.r30.u64;
	// mr r5,r31
	ctx.r5.u64 = ctx.r31.u64;
	// mr r3,r28
	ctx.r3.u64 = ctx.r28.u64;
	// bl 0x8b0c0010
	ctx.lr = 0x8B093158;
	sub_8B0C0010(ctx, base);
	// addi r4,r1,80
	ctx.r4.s64 = ctx.r1.s64 + 80;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0928f0
	ctx.lr = 0x8B093164;
	sub_8B0928F0(ctx, base);
	// clrlwi r10,r26,24
	ctx.r10.u64 = ctx.r26.u32 & 0xFF;
	// cmplwi cr6,r10,0
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 0, ctx.xer);
	// beq cr6,0x8b0931b4
	if (ctx.cr6.eq) goto loc_8B0931B4;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// li r5,-1
	ctx.r5.s64 = -1;
	// addi r31,r11,1732
	ctx.r31.s64 = ctx.r11.s64 + 1732;
	// mr r3,r27
	ctx.r3.u64 = ctx.r27.u64;
	// mr r4,r31
	ctx.r4.u64 = ctx.r31.u64;
	// bl 0x8b0bfc38
	ctx.lr = 0x8B093188;
	sub_8B0BFC38(ctx, base);
	// mr r5,r3
	ctx.r5.u64 = ctx.r3.u64;
	// stw r3,84(r1)
	REX_STORE_U32(ctx.r1.u32 + 84, ctx.r3.u32);
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// ble cr6,0x8b0931b4
	if (!ctx.cr6.gt) goto loc_8B0931B4;
	// mr r4,r31
	ctx.r4.u64 = ctx.r31.u64;
	// mr r3,r28
	ctx.r3.u64 = ctx.r28.u64;
	// bl 0x8b0c0148
	ctx.lr = 0x8B0931A4;
	sub_8B0C0148(ctx, base);
	// li r5,4
	ctx.r5.s64 = 4;
	// addi r4,r1,84
	ctx.r4.s64 = ctx.r1.s64 + 84;
	// addi r3,r1,80
	ctx.r3.s64 = ctx.r1.s64 + 80;
	// bl 0x8b0c73e0
	ctx.lr = 0x8B0931B4;
	sub_8B0C73E0(ctx, base);
loc_8B0931B4:
	// clrlwi r11,r24,24
	ctx.r11.u64 = ctx.r24.u32 & 0xFF;
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// beq cr6,0x8b09320c
	if (ctx.cr6.eq) goto loc_8B09320C;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// li r5,0
	ctx.r5.s64 = 0;
	// addi r30,r11,5148
	ctx.r30.s64 = ctx.r11.s64 + 5148;
	// mr r3,r27
	ctx.r3.u64 = ctx.r27.u64;
	// mr r4,r30
	ctx.r4.u64 = ctx.r30.u64;
	// bl 0x8b0c1588
	ctx.lr = 0x8B0931D8;
	sub_8B0C1588(ctx, base);
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b09320c
	if (ctx.cr6.eq) goto loc_8B09320C;
	// lbz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U8(ctx.r3.u32 + 0);
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// beq cr6,0x8b09320c
	if (ctx.cr6.eq) goto loc_8B09320C;
	// mr r5,r3
	ctx.r5.u64 = ctx.r3.u64;
	// mr r4,r30
	ctx.r4.u64 = ctx.r30.u64;
	// mr r3,r28
	ctx.r3.u64 = ctx.r28.u64;
	// bl 0x8b0c0010
	ctx.lr = 0x8B093200;
	sub_8B0C0010(ctx, base);
	// addi r4,r1,80
	ctx.r4.s64 = ctx.r1.s64 + 80;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0928f0
	ctx.lr = 0x8B09320C;
	sub_8B0928F0(ctx, base);
loc_8B09320C:
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// li r5,0
	ctx.r5.s64 = 0;
	// addi r31,r11,4624
	ctx.r31.s64 = ctx.r11.s64 + 4624;
	// mr r3,r23
	ctx.r3.u64 = ctx.r23.u64;
	// mr r4,r31
	ctx.r4.u64 = ctx.r31.u64;
	// bl 0x8b0c1588
	ctx.lr = 0x8B093224;
	sub_8B0C1588(ctx, base);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b093260
	if (ctx.cr6.eq) goto loc_8B093260;
	// mr r4,r31
	ctx.r4.u64 = ctx.r31.u64;
	// li r5,0
	ctx.r5.s64 = 0;
	// mr r3,r27
	ctx.r3.u64 = ctx.r27.u64;
	// bl 0x8b0c1588
	ctx.lr = 0x8B09323C;
	sub_8B0C1588(ctx, base);
	// mr r5,r3
	ctx.r5.u64 = ctx.r3.u64;
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b093260
	if (ctx.cr6.eq) goto loc_8B093260;
	// lbz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U8(ctx.r3.u32 + 0);
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// beq cr6,0x8b093260
	if (ctx.cr6.eq) goto loc_8B093260;
	// mr r4,r31
	ctx.r4.u64 = ctx.r31.u64;
	// mr r3,r28
	ctx.r3.u64 = ctx.r28.u64;
	// bl 0x8b0c0010
	ctx.lr = 0x8B093260;
	sub_8B0C0010(ctx, base);
loc_8B093260:
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// lwz r5,80(r1)
	ctx.r5.u64 = REX_LOAD_U32(ctx.r1.u32 + 80);
	// mr r3,r28
	ctx.r3.u64 = ctx.r28.u64;
	// addi r4,r10,5232
	ctx.r4.s64 = ctx.r10.s64 + 5232;
	// bl 0x8b0c0190
	ctx.lr = 0x8B093274;
	sub_8B0C0190(ctx, base);
	// mr r3,r28
	ctx.r3.u64 = ctx.r28.u64;
	// addi r1,r1,688
	ctx.r1.s64 = ctx.r1.s64 + 688;
	// b 0x8b0cb9f4
	__restgprlr_23(ctx, base);
	return;
loc_8B093280:
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// li r5,-1
	ctx.r5.s64 = -1;
	// addi r30,r11,5252
	ctx.r30.s64 = ctx.r11.s64 + 5252;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// mr r4,r30
	ctx.r4.u64 = ctx.r30.u64;
	// bl 0x8b0bfc38
	ctx.lr = 0x8B093298;
	sub_8B0BFC38(ctx, base);
	// mr r29,r3
	ctx.r29.u64 = ctx.r3.u64;
	// mr r4,r30
	ctx.r4.u64 = ctx.r30.u64;
	// li r5,0
	ctx.r5.s64 = 0;
	// mr r3,r27
	ctx.r3.u64 = ctx.r27.u64;
	// bl 0x8b0bfc38
	ctx.lr = 0x8B0932AC;
	sub_8B0BFC38(ctx, base);
	// cmpw cr6,r3,r29
	ctx.cr6.compare<int32_t>(ctx.r3.s32, ctx.r29.s32, ctx.xer);
	// ble cr6,0x8b0932ec
	if (!ctx.cr6.gt) goto loc_8B0932EC;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// li r5,0
	ctx.r5.s64 = 0;
	// addi r30,r11,5180
	ctx.r30.s64 = ctx.r11.s64 + 5180;
	// mr r3,r27
	ctx.r3.u64 = ctx.r27.u64;
	// mr r4,r30
	ctx.r4.u64 = ctx.r30.u64;
	// bl 0x8b0bfa88
	ctx.lr = 0x8B0932CC;
	sub_8B0BFA88(ctx, base);
	// mr r29,r3
	ctx.r29.u64 = ctx.r3.u64;
	// mr r4,r30
	ctx.r4.u64 = ctx.r30.u64;
	// li r5,1
	ctx.r5.s64 = 1;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0bfa88
	ctx.lr = 0x8B0932E0;
	sub_8B0BFA88(ctx, base);
	// mr r4,r29
	ctx.r4.u64 = ctx.r29.u64;
	// li r5,1
	ctx.r5.s64 = 1;
	// bl 0x8b0c0668
	ctx.lr = 0x8B0932EC;
	sub_8B0C0668(ctx, base);
loc_8B0932EC:
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// addi r29,r11,5212
	ctx.r29.s64 = ctx.r11.s64 + 5212;
	// addi r4,r10,4624
	ctx.r4.s64 = ctx.r10.s64 + 4624;
	// mr r5,r29
	ctx.r5.u64 = ctx.r29.u64;
	// mr r3,r27
	ctx.r3.u64 = ctx.r27.u64;
	// bl 0x8b0c1588
	ctx.lr = 0x8B093308;
	sub_8B0C1588(ctx, base);
	// lis r9,-29944
	ctx.r9.s64 = -1962409984;
	// mr r30,r3
	ctx.r30.u64 = ctx.r3.u64;
	// addi r4,r9,4636
	ctx.r4.s64 = ctx.r9.s64 + 4636;
	// bl 0x8b0cea10
	ctx.lr = 0x8B093318;
	sub_8B0CEA10(ctx, base);
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// beq cr6,0x8b093338
	if (ctx.cr6.eq) goto loc_8B093338;
	// mr r4,r29
	ctx.r4.u64 = ctx.r29.u64;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// bl 0x8b0cea10
	ctx.lr = 0x8B09332C;
	sub_8B0CEA10(ctx, base);
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// beq cr6,0x8b093338
	if (ctx.cr6.eq) goto loc_8B093338;
	// mr r30,r29
	ctx.r30.u64 = ctx.r29.u64;
loc_8B093338:
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// mr r5,r30
	ctx.r5.u64 = ctx.r30.u64;
	// addi r4,r11,5220
	ctx.r4.s64 = ctx.r11.s64 + 5220;
	// addi r3,r1,96
	ctx.r3.s64 = ctx.r1.s64 + 96;
	// bl 0x8b090220
	ctx.lr = 0x8B09334C;
	sub_8B090220(ctx, base);
	// li r5,0
	ctx.r5.s64 = 0;
	// addi r4,r1,96
	ctx.r4.s64 = ctx.r1.s64 + 96;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0bfc38
	ctx.lr = 0x8B09335C;
	sub_8B0BFC38(ctx, base);
	// addi r5,r3,1
	ctx.r5.s64 = ctx.r3.s64 + 1;
	// addi r4,r1,96
	ctx.r4.s64 = ctx.r1.s64 + 96;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0c0148
	ctx.lr = 0x8B09336C;
	sub_8B0C0148(ctx, base);
loc_8B09336C:
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// addi r1,r1,688
	ctx.r1.s64 = ctx.r1.s64 + 688;
	// b 0x8b0cb9f4
	__restgprlr_23(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0947E0) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb988
	ctx.lr = 0x8B0947E8;
	__savegprlr_16(ctx, base);
	// stwu r1,-736(r1)
	ea = -736 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// mr r31,r4
	ctx.r31.u64 = ctx.r4.u64;
	// mr r16,r5
	ctx.r16.u64 = ctx.r5.u64;
	// addi r4,r11,3616
	ctx.r4.s64 = ctx.r11.s64 + 3616;
	// li r5,0
	ctx.r5.s64 = 0;
	// mr r29,r3
	ctx.r29.u64 = ctx.r3.u64;
	// bl 0x8b0bfd30
	ctx.lr = 0x8B094808;
	sub_8B0BFD30(ctx, base);
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// addi r28,r11,1791
	ctx.r28.s64 = ctx.r11.s64 + 1791;
	// addi r19,r10,3824
	ctx.r19.s64 = ctx.r10.s64 + 3824;
	// mr r30,r3
	ctx.r30.u64 = ctx.r3.u64;
	// mr r5,r28
	ctx.r5.u64 = ctx.r28.u64;
	// mr r4,r19
	ctx.r4.u64 = ctx.r19.u64;
	// mr r3,r29
	ctx.r3.u64 = ctx.r29.u64;
	// bl 0x8b0c1588
	ctx.lr = 0x8B09482C;
	sub_8B0C1588(ctx, base);
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// mr r26,r3
	ctx.r26.u64 = ctx.r3.u64;
	// addi r4,r10,3636
	ctx.r4.s64 = ctx.r10.s64 + 3636;
	// li r5,0
	ctx.r5.s64 = 0;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0bfa88
	ctx.lr = 0x8B094844;
	sub_8B0BFA88(ctx, base);
	// mr r23,r3
	ctx.r23.u64 = ctx.r3.u64;
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0949d4
	if (ctx.cr6.eq) goto loc_8B0949D4;
	// li r5,0
	ctx.r5.s64 = 0;
	// mr r4,r30
	ctx.r4.u64 = ctx.r30.u64;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b091540
	ctx.lr = 0x8B094860;
	sub_8B091540(ctx, base);
	// mr r17,r3
	ctx.r17.u64 = ctx.r3.u64;
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0949d4
	if (ctx.cr6.eq) goto loc_8B0949D4;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// mr r5,r28
	ctx.r5.u64 = ctx.r28.u64;
	// addi r4,r11,3876
	ctx.r4.s64 = ctx.r11.s64 + 3876;
	// bl 0x8b0c1588
	ctx.lr = 0x8B09487C;
	sub_8B0C1588(ctx, base);
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// mr r3,r26
	ctx.r3.u64 = ctx.r26.u64;
	// bl 0x8b0cea10
	ctx.lr = 0x8B094888;
	sub_8B0CEA10(ctx, base);
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// beq cr6,0x8b0949d4
	if (ctx.cr6.eq) goto loc_8B0949D4;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// li r5,1
	ctx.r5.s64 = 1;
	// addi r4,r11,5596
	ctx.r4.s64 = ctx.r11.s64 + 5596;
	// mr r3,r17
	ctx.r3.u64 = ctx.r17.u64;
	// bl 0x8b0bfa88
	ctx.lr = 0x8B0948A4;
	sub_8B0BFA88(ctx, base);
	// mr r18,r3
	ctx.r18.u64 = ctx.r3.u64;
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0949d4
	if (ctx.cr6.eq) goto loc_8B0949D4;
	// lbz r11,0(r26)
	ctx.r11.u64 = REX_LOAD_U8(ctx.r26.u32 + 0);
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// bne cr6,0x8b0948c4
	if (!ctx.cr6.eq) goto loc_8B0948C4;
	// mr r5,r28
	ctx.r5.u64 = ctx.r28.u64;
	// b 0x8b0949c4
	goto loc_8B0949C4;
loc_8B0948C4:
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// li r5,0
	ctx.r5.s64 = 0;
	// addi r4,r11,3624
	ctx.r4.s64 = ctx.r11.s64 + 3624;
	// mr r3,r23
	ctx.r3.u64 = ctx.r23.u64;
	// li r21,0
	ctx.r21.s64 = 0;
	// bl 0x8b0bfc38
	ctx.lr = 0x8B0948DC;
	sub_8B0BFC38(ctx, base);
	// mr r20,r3
	ctx.r20.u64 = ctx.r3.u64;
	// li r25,0
	ctx.r25.s64 = 0;
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// ble cr6,0x8b094998
	if (!ctx.cr6.gt) goto loc_8B094998;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// lis r9,-29944
	ctx.r9.s64 = -1962409984;
	// addi r27,r11,5612
	ctx.r27.s64 = ctx.r11.s64 + 5612;
	// addi r24,r10,3592
	ctx.r24.s64 = ctx.r10.s64 + 3592;
	// addi r22,r9,3580
	ctx.r22.s64 = ctx.r9.s64 + 3580;
loc_8B094904:
	// mr r4,r22
	ctx.r4.u64 = ctx.r22.u64;
	// mr r5,r25
	ctx.r5.u64 = ctx.r25.u64;
	// addi r3,r1,80
	ctx.r3.s64 = ctx.r1.s64 + 80;
	// bl 0x8b090220
	ctx.lr = 0x8B094914;
	sub_8B090220(ctx, base);
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// li r5,0
	ctx.r5.s64 = 0;
	// mr r3,r23
	ctx.r3.u64 = ctx.r23.u64;
	// bl 0x8b0bfa88
	ctx.lr = 0x8B094924;
	sub_8B0BFA88(ctx, base);
	// mr r30,r3
	ctx.r30.u64 = ctx.r3.u64;
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b09498c
	if (ctx.cr6.eq) goto loc_8B09498C;
	// mr r4,r24
	ctx.r4.u64 = ctx.r24.u64;
	// li r5,0
	ctx.r5.s64 = 0;
	// bl 0x8b0bfc38
	ctx.lr = 0x8B09493C;
	sub_8B0BFC38(ctx, base);
	// mr r29,r3
	ctx.r29.u64 = ctx.r3.u64;
	// li r31,0
	ctx.r31.s64 = 0;
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// ble cr6,0x8b09498c
	if (!ctx.cr6.gt) goto loc_8B09498C;
loc_8B09494C:
	// mr r4,r27
	ctx.r4.u64 = ctx.r27.u64;
	// mr r5,r31
	ctx.r5.u64 = ctx.r31.u64;
	// addi r3,r1,336
	ctx.r3.s64 = ctx.r1.s64 + 336;
	// bl 0x8b090220
	ctx.lr = 0x8B09495C;
	sub_8B090220(ctx, base);
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// mr r5,r28
	ctx.r5.u64 = ctx.r28.u64;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// bl 0x8b0c1588
	ctx.lr = 0x8B09496C;
	sub_8B0C1588(ctx, base);
	// mr r4,r26
	ctx.r4.u64 = ctx.r26.u64;
	// bl 0x8b0cea10
	ctx.lr = 0x8B094974;
	sub_8B0CEA10(ctx, base);
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// bne cr6,0x8b094980
	if (!ctx.cr6.eq) goto loc_8B094980;
	// addi r21,r21,1
	ctx.r21.s64 = ctx.r21.s64 + 1;
loc_8B094980:
	// addi r31,r31,1
	ctx.r31.s64 = ctx.r31.s64 + 1;
	// cmpw cr6,r31,r29
	ctx.cr6.compare<int32_t>(ctx.r31.s32, ctx.r29.s32, ctx.xer);
	// blt cr6,0x8b09494c
	if (ctx.cr6.lt) goto loc_8B09494C;
loc_8B09498C:
	// addi r25,r25,1
	ctx.r25.s64 = ctx.r25.s64 + 1;
	// cmpw cr6,r25,r20
	ctx.cr6.compare<int32_t>(ctx.r25.s32, ctx.r20.s32, ctx.xer);
	// blt cr6,0x8b094904
	if (ctx.cr6.lt) goto loc_8B094904;
loc_8B094998:
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// mr r3,r26
	ctx.r3.u64 = ctx.r26.u64;
	// addi r4,r11,3864
	ctx.r4.s64 = ctx.r11.s64 + 3864;
	// bl 0x8b0cea10
	ctx.lr = 0x8B0949A8;
	sub_8B0CEA10(ctx, base);
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// bne cr6,0x8b0949b8
	if (!ctx.cr6.eq) goto loc_8B0949B8;
	// cmpwi cr6,r21,4
	ctx.cr6.compare<int32_t>(ctx.r21.s32, 4, ctx.xer);
	// b 0x8b0949bc
	goto loc_8B0949BC;
loc_8B0949B8:
	// cmpwi cr6,r21,1
	ctx.cr6.compare<int32_t>(ctx.r21.s32, 1, ctx.xer);
loc_8B0949BC:
	// bge cr6,0x8b0949d4
	if (!ctx.cr6.lt) goto loc_8B0949D4;
	// mr r5,r26
	ctx.r5.u64 = ctx.r26.u64;
loc_8B0949C4:
	// mr r4,r19
	ctx.r4.u64 = ctx.r19.u64;
	// mr r3,r18
	ctx.r3.u64 = ctx.r18.u64;
	// bl 0x8b0c0010
	ctx.lr = 0x8B0949D0;
	sub_8B0C0010(ctx, base);
	// stw r17,0(r16)
	REX_STORE_U32(ctx.r16.u32 + 0, ctx.r17.u32);
loc_8B0949D4:
	// addi r1,r1,736
	ctx.r1.s64 = ctx.r1.s64 + 736;
	// b 0x8b0cb9d8
	__restgprlr_16(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B095398) {
	REX_FUNC_PROLOGUE();
	// li r6,0
	ctx.r6.s64 = 0;
	// b 0x8b095308
	sub_8B095308(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0953A0) {
	REX_FUNC_PROLOGUE();
	PPCRegister temp{};
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// std r31,-16(r1)
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.r31.u64);
	// stwu r1,-128(r1)
	ea = -128 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// li r11,0
	ctx.r11.s64 = 0;
	// stw r4,96(r1)
	REX_STORE_U32(ctx.r1.u32 + 96, ctx.r4.u32);
	// stw r3,80(r1)
	REX_STORE_U32(ctx.r1.u32 + 80, ctx.r3.u32);
	// mr r31,r7
	ctx.r31.u64 = ctx.r7.u64;
	// stw r5,100(r1)
	REX_STORE_U32(ctx.r1.u32 + 100, ctx.r5.u32);
	// lis r4,11
	ctx.r4.s64 = 720896;
	// stw r6,104(r1)
	REX_STORE_U32(ctx.r1.u32 + 104, ctx.r6.u32);
	// li r7,32
	ctx.r7.s64 = 32;
	// std r11,88(r1)
	REX_STORE_U64(ctx.r1.u32 + 88, ctx.r11.u64);
	// addi r6,r1,80
	ctx.r6.s64 = ctx.r1.s64 + 80;
	// mr r5,r31
	ctx.r5.u64 = ctx.r31.u64;
	// ori r4,r4,7
	ctx.r4.u64 = ctx.r4.u64 | 7;
	// li r3,251
	ctx.r3.s64 = 251;
	// bl 0x8b0df178
	ctx.lr = 0x8B0953E8;
	__imp__XMsgStartIORequest(ctx, base);
	// cmpwi r3,0
	ctx.cr0.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// bge 0x8b0953f8
	if (!ctx.cr0.lt) goto loc_8B0953F8;
	// li r3,1627
	ctx.r3.s64 = 1627;
	// b 0x8b09541c
	goto loc_8B09541C;
loc_8B0953F8:
	// cmplwi cr6,r31,0
	ctx.cr6.compare<uint32_t>(ctx.r31.u32, 0, ctx.xer);
	// bne cr6,0x8b095418
	if (!ctx.cr6.eq) goto loc_8B095418;
	// bl 0x8b095650
	ctx.lr = 0x8B095404;
	sub_8B095650(ctx, base);
	// subfic r11,r3,0
	ctx.xer.ca = ctx.r3.u32 <= 0;
	ctx.r11.u64 = static_cast<uint64_t>(0) - ctx.r3.u64;
	// li r10,1627
	ctx.r10.s64 = 1627;
	// subfe r11,r11,r11
	temp.u8 = (~ctx.r11.u32 + ctx.r11.u32 < ~ctx.r11.u32) | (~ctx.r11.u32 + ctx.r11.u32 + ctx.xer.ca < ctx.xer.ca);
	ctx.r11.u64 = ~ctx.r11.u64 + ctx.r11.u64 + ctx.xer.ca;
	ctx.xer.ca = temp.u8;
	// and r3,r11,r10
	ctx.r3.u64 = ctx.r11.u64 & ctx.r10.u64;
	// b 0x8b09541c
	goto loc_8B09541C;
loc_8B095418:
	// li r3,997
	ctx.r3.s64 = 997;
loc_8B09541C:
	// addi r1,r1,128
	ctx.r1.s64 = ctx.r1.s64 + 128;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B095448) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9b8
	ctx.lr = 0x8B095450;
	__savegprlr_28(ctx, base);
	// stwu r1,-128(r1)
	ea = -128 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// mr r30,r3
	ctx.r30.u64 = ctx.r3.u64;
	// mr r28,r4
	ctx.r28.u64 = ctx.r4.u64;
	// mr r29,r5
	ctx.r29.u64 = ctx.r5.u64;
	// bl 0x8b0df1c8
	ctx.lr = 0x8B095464;
	__imp__XamGetSystemVersion(ctx, base);
	// lis r11,8201
	ctx.r11.s64 = 537460736;
	// ori r11,r11,27392
	ctx.r11.u64 = ctx.r11.u64 | 27392;
	// cmplw cr6,r3,r11
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, ctx.r11.u32, ctx.xer);
	// bge cr6,0x8b0954c0
	if (!ctx.cr6.lt) goto loc_8B0954C0;
	// cmplwi cr6,r30,255
	ctx.cr6.compare<uint32_t>(ctx.r30.u32, 255, ctx.xer);
	// bne cr6,0x8b0954b0
	if (!ctx.cr6.eq) goto loc_8B0954B0;
	// li r31,0
	ctx.r31.s64 = 0;
loc_8B095480:
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0df198
	ctx.lr = 0x8B095488;
	__imp__XamUserGetSigninState(ctx, base);
	// cmpwi cr6,r3,1
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 1, ctx.xer);
	// beq cr6,0x8b0954a0
	if (ctx.cr6.eq) goto loc_8B0954A0;
	// addi r31,r31,1
	ctx.r31.s64 = ctx.r31.s64 + 1;
	// cmplwi cr6,r31,4
	ctx.cr6.compare<uint32_t>(ctx.r31.u32, 4, ctx.xer);
	// blt cr6,0x8b095480
	if (ctx.cr6.lt) goto loc_8B095480;
	// b 0x8b0954c0
	goto loc_8B0954C0;
loc_8B0954A0:
	// li r11,0
	ctx.r11.s64 = 0;
	// li r3,1245
	ctx.r3.s64 = 1245;
	// stw r11,0(r29)
	REX_STORE_U32(ctx.r29.u32 + 0, ctx.r11.u32);
	// b 0x8b0954d0
	goto loc_8B0954D0;
loc_8B0954B0:
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// bl 0x8b0df198
	ctx.lr = 0x8B0954B8;
	__imp__XamUserGetSigninState(ctx, base);
	// cmpwi cr6,r3,1
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 1, ctx.xer);
	// beq cr6,0x8b0954a0
	if (ctx.cr6.eq) goto loc_8B0954A0;
loc_8B0954C0:
	// mr r5,r29
	ctx.r5.u64 = ctx.r29.u64;
	// mr r4,r28
	ctx.r4.u64 = ctx.r28.u64;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// bl 0x8b0df1b8
	ctx.lr = 0x8B0954D0;
	__imp__XamUserCheckPrivilege(ctx, base);
loc_8B0954D0:
	// addi r1,r1,128
	ctx.r1.s64 = ctx.r1.s64 + 128;
	// b 0x8b0cba08
	__restgprlr_28(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0955B0) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// stwu r1,-96(r1)
	ea = -96 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// mr r5,r4
	ctx.r5.u64 = ctx.r4.u64;
	// li r4,7
	ctx.r4.s64 = 7;
	// bl 0x8b0df1d8
	ctx.lr = 0x8B0955C8;
	__imp__XamUserGetXUID(ctx, base);
	// cmpwi r3,0
	ctx.cr0.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// blt 0x8b0955d8
	if (ctx.cr0.lt) goto loc_8B0955D8;
	// li r3,0
	ctx.r3.s64 = 0;
	// b 0x8b0955f0
	goto loc_8B0955F0;
loc_8B0955D8:
	// rlwinm r11,r3,0,3,15
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r3.u32 | (ctx.r3.u64 << 32), 0) & 0x1FFF0000;
	// lis r10,7
	ctx.r10.s64 = 458752;
	// clrlwi r3,r3,16
	ctx.r3.u64 = ctx.r3.u32 & 0xFFFF;
	// cmpw cr6,r11,r10
	ctx.cr6.compare<int32_t>(ctx.r11.s32, ctx.r10.s32, ctx.xer);
	// beq cr6,0x8b0955f0
	if (ctx.cr6.eq) goto loc_8B0955F0;
	// li r3,1627
	ctx.r3.s64 = 1627;
loc_8B0955F0:
	// addi r1,r1,96
	ctx.r1.s64 = ctx.r1.s64 + 96;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B095650) {
	REX_FUNC_PROLOGUE();
	// lwz r11,336(r13)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r13.u32 + 336);
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// bne cr6,0x8b095668
	if (!ctx.cr6.eq) goto loc_8B095668;
	// lwz r11,256(r13)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r13.u32 + 256);
	// lwz r3,352(r11)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r11.u32 + 352);
	// blr 
	return;
loc_8B095668:
	// li r3,0
	ctx.r3.s64 = 0;
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B095848) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9b8
	ctx.lr = 0x8B095850;
	__savegprlr_28(ctx, base);
	// stwu r1,-128(r1)
	ea = -128 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lwz r11,56(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 56);
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// mr r29,r4
	ctx.r29.u64 = ctx.r4.u64;
	// mr r30,r5
	ctx.r30.u64 = ctx.r5.u64;
	// addi r28,r3,56
	ctx.r28.s64 = ctx.r3.s64 + 56;
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// beq cr6,0x8b0958ec
	if (ctx.cr6.eq) goto loc_8B0958EC;
	// li r8,0
	ctx.r8.s64 = 0;
loc_8B095874:
	// lwz r10,4(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 4);
	// cmplw cr6,r10,r29
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, ctx.r29.u32, ctx.xer);
	// bgt cr6,0x8b095934
	if (ctx.cr6.gt) goto loc_8B095934;
	// lwz r9,8(r11)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r11.u32 + 8);
	// add r7,r9,r10
	ctx.r7.u64 = ctx.r9.u64 + ctx.r10.u64;
	// cmplw cr6,r7,r29
	ctx.cr6.compare<uint32_t>(ctx.r7.u32, ctx.r29.u32, ctx.xer);
	// bne cr6,0x8b0958dc
	if (!ctx.cr6.eq) goto loc_8B0958DC;
	// lwz r7,0(r11)
	ctx.r7.u64 = REX_LOAD_U32(ctx.r11.u32 + 0);
	// mr r29,r10
	ctx.r29.u64 = ctx.r10.u64;
	// add r30,r9,r30
	ctx.r30.u64 = ctx.r9.u64 + ctx.r30.u64;
	// stw r7,0(r28)
	REX_STORE_U32(ctx.r28.u32 + 0, ctx.r7.u32);
	// lwz r10,24(r31)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r31.u32 + 24);
	// lwz r10,76(r10)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r10.u32 + 76);
	// stw r10,0(r11)
	REX_STORE_U32(ctx.r11.u32 + 0, ctx.r10.u32);
	// lwz r10,24(r31)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r31.u32 + 24);
	// stw r11,76(r10)
	REX_STORE_U32(ctx.r10.u32 + 76, ctx.r11.u32);
	// stw r8,4(r11)
	REX_STORE_U32(ctx.r11.u32 + 4, ctx.r8.u32);
	// stw r8,8(r11)
	REX_STORE_U32(ctx.r11.u32 + 8, ctx.r8.u32);
	// lwz r10,28(r31)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r31.u32 + 28);
	// lwz r11,52(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 52);
	// addi r11,r11,-1
	ctx.r11.s64 = ctx.r11.s64 + -1;
	// cmplw cr6,r30,r10
	ctx.cr6.compare<uint32_t>(ctx.r30.u32, ctx.r10.u32, ctx.xer);
	// stw r11,52(r31)
	REX_STORE_U32(ctx.r31.u32 + 52, ctx.r11.u32);
	// ble cr6,0x8b0958e0
	if (!ctx.cr6.gt) goto loc_8B0958E0;
	// stw r30,28(r31)
	REX_STORE_U32(ctx.r31.u32 + 28, ctx.r30.u32);
	// b 0x8b0958e0
	goto loc_8B0958E0;
loc_8B0958DC:
	// mr r28,r11
	ctx.r28.u64 = ctx.r11.u64;
loc_8B0958E0:
	// lwz r11,0(r28)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r28.u32 + 0);
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// bne cr6,0x8b095874
	if (!ctx.cr6.eq) goto loc_8B095874;
loc_8B0958EC:
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b095670
	ctx.lr = 0x8B0958F4;
	sub_8B095670(ctx, base);
	// cmplwi r3,0
	ctx.cr0.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq 0x8b09592c
	if (ctx.cr0.eq) goto loc_8B09592C;
	// stw r30,8(r3)
	REX_STORE_U32(ctx.r3.u32 + 8, ctx.r30.u32);
	// stw r29,4(r3)
	REX_STORE_U32(ctx.r3.u32 + 4, ctx.r29.u32);
	// lwz r11,0(r28)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r28.u32 + 0);
	// stw r11,0(r3)
	REX_STORE_U32(ctx.r3.u32 + 0, ctx.r11.u32);
	// stw r3,0(r28)
	REX_STORE_U32(ctx.r28.u32 + 0, ctx.r3.u32);
	// lwz r10,28(r31)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r31.u32 + 28);
	// lwz r11,52(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 52);
	// addi r11,r11,1
	ctx.r11.s64 = ctx.r11.s64 + 1;
	// cmplw cr6,r30,r10
	ctx.cr6.compare<uint32_t>(ctx.r30.u32, ctx.r10.u32, ctx.xer);
	// stw r11,52(r31)
	REX_STORE_U32(ctx.r31.u32 + 52, ctx.r11.u32);
	// blt cr6,0x8b09592c
	if (ctx.cr6.lt) goto loc_8B09592C;
	// stw r30,28(r31)
	REX_STORE_U32(ctx.r31.u32 + 28, ctx.r30.u32);
loc_8B09592C:
	// addi r1,r1,128
	ctx.r1.s64 = ctx.r1.s64 + 128;
	// b 0x8b0cba08
	__restgprlr_28(ctx, base);
	return;
loc_8B095934:
	// add r9,r29,r30
	ctx.r9.u64 = ctx.r29.u64 + ctx.r30.u64;
	// cmplw cr6,r9,r10
	ctx.cr6.compare<uint32_t>(ctx.r9.u32, ctx.r10.u32, ctx.xer);
	// bne cr6,0x8b0958ec
	if (!ctx.cr6.eq) goto loc_8B0958EC;
	// lwz r10,8(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 8);
	// stw r29,4(r11)
	REX_STORE_U32(ctx.r11.u32 + 4, ctx.r29.u32);
	// add r10,r30,r10
	ctx.r10.u64 = ctx.r30.u64 + ctx.r10.u64;
	// stw r10,8(r11)
	REX_STORE_U32(ctx.r11.u32 + 8, ctx.r10.u32);
	// lwz r11,28(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 28);
	// cmplw cr6,r10,r11
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, ctx.r11.u32, ctx.xer);
	// ble cr6,0x8b09592c
	if (!ctx.cr6.gt) goto loc_8B09592C;
	// stw r10,28(r31)
	REX_STORE_U32(ctx.r31.u32 + 28, ctx.r10.u32);
	// b 0x8b09592c
	goto loc_8B09592C;
}

DEFINE_REX_FUNC(sub_8B095AF8) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9b8
	ctx.lr = 0x8B095B00;
	__savegprlr_28(ctx, base);
	// stwu r1,-128(r1)
	ea = -128 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b095c00
	if (ctx.cr6.eq) goto loc_8B095C00;
	// lwz r11,20(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 20);
	// rlwinm. r11,r11,0,13,13
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 0) & 0x40000;
	ctx.cr0.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// beq 0x8b095b44
	if (ctx.cr0.eq) goto loc_8B095B44;
	// bl 0x8b0df238
	ctx.lr = 0x8B095B20;
	__imp__KeGetCurrentProcessType(ctx, base);
	// lbz r11,379(r31)
	ctx.r11.u64 = REX_LOAD_U8(ctx.r31.u32 + 379);
	// cmpw cr6,r11,r3
	ctx.cr6.compare<int32_t>(ctx.r11.s32, ctx.r3.s32, ctx.xer);
	// beq cr6,0x8b095b44
	if (ctx.cr6.eq) goto loc_8B095B44;
	// li r7,0
	ctx.r7.s64 = 0;
	// lwz r5,120(r1)
	ctx.r5.u64 = REX_LOAD_U32(ctx.r1.u32 + 120);
	// li r6,1295
	ctx.r6.s64 = 1295;
	// mr r4,r31
	ctx.r4.u64 = ctx.r31.u64;
	// li r3,244
	ctx.r3.s64 = 244;
	// bl 0x8b0df228
	ctx.lr = 0x8B095B44;
	__imp__KeBugCheckEx(ctx, base);
loc_8B095B44:
	// lwz r30,88(r31)
	ctx.r30.u64 = REX_LOAD_U32(ctx.r31.u32 + 88);
	// addi r29,r31,88
	ctx.r29.s64 = ctx.r31.s64 + 88;
	// li r28,0
	ctx.r28.s64 = 0;
	// b 0x8b095b78
	goto loc_8B095B78;
loc_8B095B54:
	// stw r30,80(r1)
	REX_STORE_U32(ctx.r1.u32 + 80, ctx.r30.u32);
	// lis r5,0
	ctx.r5.s64 = 0;
	// lwz r30,0(r30)
	ctx.r30.u64 = REX_LOAD_U32(ctx.r30.u32 + 0);
	// addi r4,r1,84
	ctx.r4.s64 = ctx.r1.s64 + 84;
	// stw r28,84(r1)
	REX_STORE_U32(ctx.r1.u32 + 84, ctx.r28.u32);
	// ori r5,r5,32768
	ctx.r5.u64 = ctx.r5.u64 | 32768;
	// addi r3,r1,80
	ctx.r3.s64 = ctx.r1.s64 + 80;
	// lwz r6,1424(r31)
	ctx.r6.u64 = REX_LOAD_U32(ctx.r31.u32 + 1424);
	// bl 0x8b0df258
	ctx.lr = 0x8B095B78;
	__imp__NtFreeVirtualMemory(ctx, base);
loc_8B095B78:
	// cmplw cr6,r29,r30
	ctx.cr6.compare<uint32_t>(ctx.r29.u32, ctx.r30.u32, ctx.xer);
	// bne cr6,0x8b095b54
	if (!ctx.cr6.eq) goto loc_8B095B54;
	// lwz r11,20(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 20);
	// clrlwi. r11,r11,31
	ctx.r11.u64 = ctx.r11.u32 & 0x1;
	ctx.cr0.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// bne 0x8b095b90
	if (!ctx.cr0.eq) goto loc_8B095B90;
	// stw r28,1408(r31)
	REX_STORE_U32(ctx.r31.u32 + 1408, ctx.r28.u32);
loc_8B095B90:
	// lwz r30,72(r31)
	ctx.r30.u64 = REX_LOAD_U32(ctx.r31.u32 + 72);
	// stw r28,72(r31)
	REX_STORE_U32(ctx.r31.u32 + 72, ctx.r28.u32);
	// b 0x8b095bc0
	goto loc_8B095BC0;
loc_8B095B9C:
	// stw r30,80(r1)
	REX_STORE_U32(ctx.r1.u32 + 80, ctx.r30.u32);
	// lis r5,0
	ctx.r5.s64 = 0;
	// lwz r30,0(r30)
	ctx.r30.u64 = REX_LOAD_U32(ctx.r30.u32 + 0);
	// addi r4,r1,84
	ctx.r4.s64 = ctx.r1.s64 + 84;
	// stw r28,84(r1)
	REX_STORE_U32(ctx.r1.u32 + 84, ctx.r28.u32);
	// ori r5,r5,32768
	ctx.r5.u64 = ctx.r5.u64 | 32768;
	// addi r3,r1,80
	ctx.r3.s64 = ctx.r1.s64 + 80;
	// lwz r6,1424(r31)
	ctx.r6.u64 = REX_LOAD_U32(ctx.r31.u32 + 1424);
	// bl 0x8b0df258
	ctx.lr = 0x8B095BC0;
	__imp__NtFreeVirtualMemory(ctx, base);
loc_8B095BC0:
	// cmplwi cr6,r30,0
	ctx.cr6.compare<uint32_t>(ctx.r30.u32, 0, ctx.xer);
	// bne cr6,0x8b095b9c
	if (!ctx.cr6.eq) goto loc_8B095B9C;
	// lwz r29,1424(r31)
	ctx.r29.u64 = REX_LOAD_U32(ctx.r31.u32 + 1424);
	// li r30,64
	ctx.r30.s64 = 64;
loc_8B095BD0:
	// addi r11,r30,255
	ctx.r11.s64 = ctx.r30.s64 + 255;
	// clrlwi r11,r11,24
	ctx.r11.u64 = ctx.r11.u32 & 0xFF;
	// addi r10,r11,24
	ctx.r10.s64 = ctx.r11.s64 + 24;
	// mr r30,r11
	ctx.r30.u64 = ctx.r11.u64;
	// rlwinm r11,r10,2,0,29
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r10.u32 | (ctx.r10.u64 << 32), 2) & 0xFFFFFFFC;
	// lwzx r3,r11,r31
	ctx.r3.u64 = REX_LOAD_U32(ctx.r11.u32 + ctx.r31.u32);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b095bf8
	if (ctx.cr6.eq) goto loc_8B095BF8;
	// mr r4,r29
	ctx.r4.u64 = ctx.r29.u64;
	// bl 0x8b095968
	ctx.lr = 0x8B095BF8;
	sub_8B095968(ctx, base);
loc_8B095BF8:
	// cmplwi cr6,r30,0
	ctx.cr6.compare<uint32_t>(ctx.r30.u32, 0, ctx.xer);
	// bne cr6,0x8b095bd0
	if (!ctx.cr6.eq) goto loc_8B095BD0;
loc_8B095C00:
	// li r3,0
	ctx.r3.s64 = 0;
	// addi r1,r1,128
	ctx.r1.s64 = ctx.r1.s64 + 128;
	// b 0x8b0cba08
	__restgprlr_28(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0963C0) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9b8
	ctx.lr = 0x8B0963C8;
	__savegprlr_28(ctx, base);
	// stwu r1,-128(r1)
	ea = -128 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// mr r30,r3
	ctx.r30.u64 = ctx.r3.u64;
	// mr r29,r4
	ctx.r29.u64 = ctx.r4.u64;
	// mr r31,r5
	ctx.r31.u64 = ctx.r5.u64;
	// mr r28,r6
	ctx.r28.u64 = ctx.r6.u64;
	// cmpwi cr6,r5,0
	ctx.cr6.compare<int32_t>(ctx.r5.s32, 0, ctx.xer);
	// beq cr6,0x8b0964a4
	if (ctx.cr6.eq) goto loc_8B0964A4;
	// lwz r10,12(r3)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r3.u32 + 12);
	// lwz r11,4(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 4);
	// add r9,r10,r5
	ctx.r9.u64 = ctx.r10.u64 + ctx.r5.u64;
	// cmpw cr6,r9,r11
	ctx.cr6.compare<int32_t>(ctx.r9.s32, ctx.r11.s32, ctx.xer);
	// ble cr6,0x8b096404
	if (!ctx.cr6.gt) goto loc_8B096404;
	// subf r11,r11,r10
	ctx.r11.u64 = ctx.r10.u64 - ctx.r11.u64;
	// add r4,r11,r5
	ctx.r4.u64 = ctx.r11.u64 + ctx.r5.u64;
	// bl 0x8b09d398
	ctx.lr = 0x8B096404;
	sub_8B09D398(ctx, base);
loc_8B096404:
	// lwz r11,12(r30)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r30.u32 + 12);
	// add r11,r11,r31
	ctx.r11.u64 = ctx.r11.u64 + ctx.r31.u64;
	// subf r10,r29,r11
	ctx.r10.u64 = ctx.r11.u64 - ctx.r29.u64;
	// stw r11,12(r30)
	REX_STORE_U32(ctx.r30.u32 + 12, ctx.r11.u32);
	// subf. r10,r31,r10
	ctx.r10.u64 = ctx.r10.u64 - ctx.r31.u64;
	ctx.cr0.compare<int32_t>(ctx.r10.s32, 0, ctx.xer);
	// ble 0x8b096444
	if (!ctx.cr0.gt) goto loc_8B096444;
	// cmpwi cr6,r31,0
	ctx.cr6.compare<int32_t>(ctx.r31.s32, 0, ctx.xer);
	// ble cr6,0x8b096474
	if (!ctx.cr6.gt) goto loc_8B096474;
	// add r9,r29,r31
	ctx.r9.u64 = ctx.r29.u64 + ctx.r31.u64;
	// lwz r11,0(r30)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r30.u32 + 0);
	// rlwinm r8,r29,3,0,28
	ctx.r8.u64 = __builtin_rotateleft64(ctx.r29.u32 | (ctx.r29.u64 << 32), 3) & 0xFFFFFFF8;
	// rlwinm r9,r9,3,0,28
	ctx.r9.u64 = __builtin_rotateleft64(ctx.r9.u32 | (ctx.r9.u64 << 32), 3) & 0xFFFFFFF8;
	// rlwinm r5,r10,3,0,28
	ctx.r5.u64 = __builtin_rotateleft64(ctx.r10.u32 | (ctx.r10.u64 << 32), 3) & 0xFFFFFFF8;
	// add r4,r8,r11
	ctx.r4.u64 = ctx.r8.u64 + ctx.r11.u64;
	// add r3,r9,r11
	ctx.r3.u64 = ctx.r9.u64 + ctx.r11.u64;
	// bl 0x8b0cc060
	ctx.lr = 0x8B096444;
	sub_8B0CC060(ctx, base);
loc_8B096444:
	// cmpwi cr6,r31,0
	ctx.cr6.compare<int32_t>(ctx.r31.s32, 0, ctx.xer);
	// ble cr6,0x8b096474
	if (!ctx.cr6.gt) goto loc_8B096474;
	// rlwinm r10,r29,3,0,28
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r29.u32 | (ctx.r29.u64 << 32), 3) & 0xFFFFFFF8;
	// mtctr r31
	ctx.ctr.u64 = ctx.r31.u64;
	// li r9,0
	ctx.r9.s64 = 0;
loc_8B096458:
	// lwz r11,0(r30)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r30.u32 + 0);
	// add. r11,r10,r11
	ctx.r11.u64 = ctx.r10.u64 + ctx.r11.u64;
	ctx.cr0.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// beq 0x8b09646c
	if (ctx.cr0.eq) goto loc_8B09646C;
	// stw r9,0(r11)
	REX_STORE_U32(ctx.r11.u32 + 0, ctx.r9.u32);
	// stw r9,4(r11)
	REX_STORE_U32(ctx.r11.u32 + 4, ctx.r9.u32);
loc_8B09646C:
	// addi r10,r10,8
	ctx.r10.s64 = ctx.r10.s64 + 8;
	// bdnz 0x8b096458
	--ctx.ctr.u64;
	if (ctx.ctr.u32 != 0) goto loc_8B096458;
loc_8B096474:
	// cmplwi cr6,r28,0
	ctx.cr6.compare<uint32_t>(ctx.r28.u32, 0, ctx.xer);
	// beq cr6,0x8b0964a4
	if (ctx.cr6.eq) goto loc_8B0964A4;
	// cmpwi cr6,r31,0
	ctx.cr6.compare<int32_t>(ctx.r31.s32, 0, ctx.xer);
	// ble cr6,0x8b0964a4
	if (!ctx.cr6.gt) goto loc_8B0964A4;
	// addi r10,r28,-8
	ctx.r10.s64 = ctx.r28.s64 + -8;
	// mtctr r31
	ctx.ctr.u64 = ctx.r31.u64;
	// rlwinm r11,r29,3,0,28
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r29.u32 | (ctx.r29.u64 << 32), 3) & 0xFFFFFFF8;
loc_8B096490:
	// ldu r9,8(r10)
	ea = 8 + ctx.r10.u32;
	ctx.r9.u64 = REX_LOAD_U64(ea);
	ctx.r10.u32 = ea;
	// lwz r8,0(r30)
	ctx.r8.u64 = REX_LOAD_U32(ctx.r30.u32 + 0);
	// stdx r9,r11,r8
	REX_STORE_U64(ctx.r11.u32 + ctx.r8.u32, ctx.r9.u64);
	// addi r11,r11,8
	ctx.r11.s64 = ctx.r11.s64 + 8;
	// bdnz 0x8b096490
	--ctx.ctr.u64;
	if (ctx.ctr.u32 != 0) goto loc_8B096490;
loc_8B0964A4:
	// mr r3,r29
	ctx.r3.u64 = ctx.r29.u64;
	// addi r1,r1,128
	ctx.r1.s64 = ctx.r1.s64 + 128;
	// b 0x8b0cba08
	__restgprlr_28(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B096708) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9b8
	ctx.lr = 0x8B096710;
	__savegprlr_28(ctx, base);
	// stwu r1,-128(r1)
	ea = -128 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// mr r28,r4
	ctx.r28.u64 = ctx.r4.u64;
	// li r29,0
	ctx.r29.s64 = 0;
	// addi r30,r3,8
	ctx.r30.s64 = ctx.r3.s64 + 8;
loc_8B096720:
	// lwz r31,0(r30)
	ctx.r31.u64 = REX_LOAD_U32(ctx.r30.u32 + 0);
	// cmplwi cr6,r31,0
	ctx.cr6.compare<uint32_t>(ctx.r31.u32, 0, ctx.xer);
	// beq cr6,0x8b096748
	if (ctx.cr6.eq) goto loc_8B096748;
	// lwz r11,0(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 0);
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// lwz r10,0(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 0);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B096740;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// cmpld cr6,r3,r28
	ctx.cr6.compare<uint64_t>(ctx.r3.u64, ctx.r28.u64, ctx.xer);
	// beq cr6,0x8b096764
	if (ctx.cr6.eq) goto loc_8B096764;
loc_8B096748:
	// addi r29,r29,1
	ctx.r29.s64 = ctx.r29.s64 + 1;
	// addi r30,r30,4
	ctx.r30.s64 = ctx.r30.s64 + 4;
	// cmplwi cr6,r29,4
	ctx.cr6.compare<uint32_t>(ctx.r29.u32, 4, ctx.xer);
	// blt cr6,0x8b096720
	if (ctx.cr6.lt) goto loc_8B096720;
	// li r3,0
	ctx.r3.s64 = 0;
	// addi r1,r1,128
	ctx.r1.s64 = ctx.r1.s64 + 128;
	// b 0x8b0cba08
	__restgprlr_28(ctx, base);
	return;
loc_8B096764:
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// addi r1,r1,128
	ctx.r1.s64 = ctx.r1.s64 + 128;
	// b 0x8b0cba08
	__restgprlr_28(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B096A70) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9b4
	ctx.lr = 0x8B096A78;
	__savegprlr_27(ctx, base);
	// stwu r1,-128(r1)
	ea = -128 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lwz r11,36(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 36);
	// mr r29,r3
	ctx.r29.u64 = ctx.r3.u64;
	// mr r27,r4
	ctx.r27.u64 = ctx.r4.u64;
	// li r28,0
	ctx.r28.s64 = 0;
	// cmpwi cr6,r11,0
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// ble cr6,0x8b096ad8
	if (!ctx.cr6.gt) goto loc_8B096AD8;
	// li r30,0
	ctx.r30.s64 = 0;
loc_8B096A98:
	// lwz r11,24(r29)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r29.u32 + 24);
	// lwzx r31,r11,r30
	ctx.r31.u64 = REX_LOAD_U32(ctx.r11.u32 + ctx.r30.u32);
	// cmplwi cr6,r31,0
	ctx.cr6.compare<uint32_t>(ctx.r31.u32, 0, ctx.xer);
	// beq cr6,0x8b096ac4
	if (ctx.cr6.eq) goto loc_8B096AC4;
	// lwz r11,0(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 0);
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// lwz r10,0(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 0);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B096ABC;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// cmpld cr6,r3,r27
	ctx.cr6.compare<uint64_t>(ctx.r3.u64, ctx.r27.u64, ctx.xer);
	// beq cr6,0x8b096ae4
	if (ctx.cr6.eq) goto loc_8B096AE4;
loc_8B096AC4:
	// lwz r11,36(r29)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r29.u32 + 36);
	// addi r28,r28,1
	ctx.r28.s64 = ctx.r28.s64 + 1;
	// addi r30,r30,4
	ctx.r30.s64 = ctx.r30.s64 + 4;
	// cmpw cr6,r28,r11
	ctx.cr6.compare<int32_t>(ctx.r28.s32, ctx.r11.s32, ctx.xer);
	// blt cr6,0x8b096a98
	if (ctx.cr6.lt) goto loc_8B096A98;
loc_8B096AD8:
	// li r3,0
	ctx.r3.s64 = 0;
	// addi r1,r1,128
	ctx.r1.s64 = ctx.r1.s64 + 128;
	// b 0x8b0cba04
	__restgprlr_27(ctx, base);
	return;
loc_8B096AE4:
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// addi r1,r1,128
	ctx.r1.s64 = ctx.r1.s64 + 128;
	// b 0x8b0cba04
	__restgprlr_27(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B096B50) {
	REX_FUNC_PROLOGUE();
	// b 0x8b096a70
	sub_8B096A70(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B096B58) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// std r30,-24(r1)
	REX_STORE_U64(ctx.r1.u32 + -24, ctx.r30.u64);
	// std r31,-16(r1)
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.r31.u64);
	// stwu r1,-112(r1)
	ea = -112 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// mr r30,r4
	ctx.r30.u64 = ctx.r4.u64;
	// bl 0x8b096708
	ctx.lr = 0x8B096B78;
	sub_8B096708(ctx, base);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// bne cr6,0x8b096b8c
	if (!ctx.cr6.eq) goto loc_8B096B8C;
	// mr r4,r30
	ctx.r4.u64 = ctx.r30.u64;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b096a70
	ctx.lr = 0x8B096B8C;
	sub_8B096A70(ctx, base);
loc_8B096B8C:
	// addi r1,r1,112
	ctx.r1.s64 = ctx.r1.s64 + 112;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// ld r30,-24(r1)
	ctx.r30.u64 = REX_LOAD_U64(ctx.r1.u32 + -24);
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B096C70) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9b0
	ctx.lr = 0x8B096C78;
	__savegprlr_26(ctx, base);
	// stwu r1,-144(r1)
	ea = -144 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lwz r11,36(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 36);
	// mr r26,r3
	ctx.r26.u64 = ctx.r3.u64;
	// li r28,0
	ctx.r28.s64 = 0;
	// cmpwi cr6,r11,0
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// ble cr6,0x8b096d34
	if (!ctx.cr6.gt) goto loc_8B096D34;
	// li r11,1
	ctx.r11.s64 = 1;
	// addi r30,r3,24
	ctx.r30.s64 = ctx.r3.s64 + 24;
	// slw r10,r11,r4
	ctx.r10.u64 = ctx.r4.u8 & 0x20 ? 0 : (ctx.r11.u32 << (ctx.r4.u8 & 0x3F));
	// not r27,r10
	ctx.r27.u64 = ~ctx.r10.u64;
	// li r31,0
	ctx.r31.s64 = 0;
loc_8B096CA4:
	// lwz r11,0(r30)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r30.u32 + 0);
	// lwzx r29,r31,r11
	ctx.r29.u64 = REX_LOAD_U32(ctx.r31.u32 + ctx.r11.u32);
	// mr r3,r29
	ctx.r3.u64 = ctx.r29.u64;
	// bl 0x8b09bfe8
	ctx.lr = 0x8B096CB4;
	sub_8B09BFE8(ctx, base);
	// and r4,r3,r27
	ctx.r4.u64 = ctx.r3.u64 & ctx.r27.u64;
	// cmplwi cr6,r4,0
	ctx.cr6.compare<uint32_t>(ctx.r4.u32, 0, ctx.xer);
	// bne cr6,0x8b096d18
	if (!ctx.cr6.eq) goto loc_8B096D18;
	// lwz r10,12(r30)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r30.u32 + 12);
	// cmpwi cr6,r10,0
	ctx.cr6.compare<int32_t>(ctx.r10.s32, 0, ctx.xer);
	// ble cr6,0x8b096cf8
	if (!ctx.cr6.gt) goto loc_8B096CF8;
	// addi r11,r10,-1
	ctx.r11.s64 = ctx.r10.s64 + -1;
	// cmpw cr6,r28,r11
	ctx.cr6.compare<int32_t>(ctx.r28.s32, ctx.r11.s32, ctx.xer);
	// beq cr6,0x8b096cec
	if (ctx.cr6.eq) goto loc_8B096CEC;
	// lwz r11,0(r30)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r30.u32 + 0);
	// rlwinm r10,r10,2,0,29
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r10.u32 | (ctx.r10.u64 << 32), 2) & 0xFFFFFFFC;
	// add r10,r10,r11
	ctx.r10.u64 = ctx.r10.u64 + ctx.r11.u64;
	// lwz r9,-4(r10)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r10.u32 + -4);
	// stwx r9,r31,r11
	REX_STORE_U32(ctx.r31.u32 + ctx.r11.u32, ctx.r9.u32);
loc_8B096CEC:
	// lwz r11,12(r30)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r30.u32 + 12);
	// addi r11,r11,-1
	ctx.r11.s64 = ctx.r11.s64 + -1;
	// stw r11,12(r30)
	REX_STORE_U32(ctx.r30.u32 + 12, ctx.r11.u32);
loc_8B096CF8:
	// lwz r11,0(r29)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r29.u32 + 0);
	// mr r3,r29
	ctx.r3.u64 = ctx.r29.u64;
	// addi r28,r28,-1
	ctx.r28.s64 = ctx.r28.s64 + -1;
	// addi r31,r31,-4
	ctx.r31.s64 = ctx.r31.s64 + -4;
	// lwz r10,40(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 40);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B096D14;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// b 0x8b096d20
	goto loc_8B096D20;
loc_8B096D18:
	// mr r3,r29
	ctx.r3.u64 = ctx.r29.u64;
	// bl 0x8b09bfe0
	ctx.lr = 0x8B096D20;
	sub_8B09BFE0(ctx, base);
loc_8B096D20:
	// lwz r11,36(r26)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r26.u32 + 36);
	// addi r28,r28,1
	ctx.r28.s64 = ctx.r28.s64 + 1;
	// addi r31,r31,4
	ctx.r31.s64 = ctx.r31.s64 + 4;
	// cmpw cr6,r28,r11
	ctx.cr6.compare<int32_t>(ctx.r28.s32, ctx.r11.s32, ctx.xer);
	// blt cr6,0x8b096ca4
	if (ctx.cr6.lt) goto loc_8B096CA4;
loc_8B096D34:
	// addi r1,r1,144
	ctx.r1.s64 = ctx.r1.s64 + 144;
	// b 0x8b0cba00
	__restgprlr_26(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B097648) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9a4
	ctx.lr = 0x8B097650;
	__savegprlr_23(ctx, base);
	// stwu r1,-480(r1)
	ea = -480 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// mr r28,r3
	ctx.r28.u64 = ctx.r3.u64;
	// mr r3,r4
	ctx.r3.u64 = ctx.r4.u64;
	// mr r29,r4
	ctx.r29.u64 = ctx.r4.u64;
	// bl 0x8b0beee8
	ctx.lr = 0x8B097664;
	sub_8B0BEEE8(ctx, base);
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// addi r4,r11,9244
	ctx.r4.s64 = ctx.r11.s64 + 9244;
	// bl 0x8b0cea10
	ctx.lr = 0x8B097674;
	sub_8B0CEA10(ctx, base);
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// bne cr6,0x8b09791c
	if (!ctx.cr6.eq) goto loc_8B09791C;
	// bl 0x8b0992c8
	ctx.lr = 0x8B097680;
	sub_8B0992C8(ctx, base);
	// clrlwi r11,r3,24
	ctx.r11.u64 = ctx.r3.u32 & 0xFF;
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// bne cr6,0x8b097af0
	if (!ctx.cr6.eq) goto loc_8B097AF0;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// li r5,0
	ctx.r5.s64 = 0;
	// addi r4,r11,9224
	ctx.r4.s64 = ctx.r11.s64 + 9224;
	// mr r3,r29
	ctx.r3.u64 = ctx.r29.u64;
	// bl 0x8b0bfa88
	ctx.lr = 0x8B0976A0;
	sub_8B0BFA88(ctx, base);
	// mr r25,r3
	ctx.r25.u64 = ctx.r3.u64;
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b097af0
	if (ctx.cr6.eq) goto loc_8B097AF0;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// li r5,0
	ctx.r5.s64 = 0;
	// addi r4,r11,9204
	ctx.r4.s64 = ctx.r11.s64 + 9204;
	// bl 0x8b0bfd30
	ctx.lr = 0x8B0976BC;
	sub_8B0BFD30(ctx, base);
	// mr r27,r3
	ctx.r27.u64 = ctx.r3.u64;
	// cmpldi cr6,r3,0
	ctx.cr6.compare<uint64_t>(ctx.r3.u64, 0, ctx.xer);
	// bne cr6,0x8b0976e8
	if (!ctx.cr6.eq) goto loc_8B0976E8;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// li r5,0
	ctx.r5.s64 = 0;
	// addi r4,r11,9192
	ctx.r4.s64 = ctx.r11.s64 + 9192;
	// mr r3,r25
	ctx.r3.u64 = ctx.r25.u64;
	// bl 0x8b0bfd30
	ctx.lr = 0x8B0976DC;
	sub_8B0BFD30(ctx, base);
	// mr r27,r3
	ctx.r27.u64 = ctx.r3.u64;
	// cmpldi cr6,r3,0
	ctx.cr6.compare<uint64_t>(ctx.r3.u64, 0, ctx.xer);
	// beq cr6,0x8b097af0
	if (ctx.cr6.eq) goto loc_8B097AF0;
loc_8B0976E8:
	// li r23,0
	ctx.r23.s64 = 0;
	// addi r31,r28,4
	ctx.r31.s64 = ctx.r28.s64 + 4;
	// mr r30,r23
	ctx.r30.u64 = ctx.r23.u64;
loc_8B0976F4:
	// lwz r11,0(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 0);
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// beq cr6,0x8b09771c
	if (ctx.cr6.eq) goto loc_8B09771C;
	// rotlwi r3,r11,0
	ctx.r3.u64 = __builtin_rotateleft32(ctx.r11.u32, 0);
	// lwz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r10,0(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 0);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B097714;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// cmpld cr6,r3,r27
	ctx.cr6.compare<uint64_t>(ctx.r3.u64, ctx.r27.u64, ctx.xer);
	// beq cr6,0x8b097af0
	if (ctx.cr6.eq) goto loc_8B097AF0;
loc_8B09771C:
	// addi r30,r30,1
	ctx.r30.s64 = ctx.r30.s64 + 1;
	// addi r31,r31,4
	ctx.r31.s64 = ctx.r31.s64 + 4;
	// cmplwi cr6,r30,4
	ctx.cr6.compare<uint32_t>(ctx.r30.u32, 4, ctx.xer);
	// blt cr6,0x8b0976f4
	if (ctx.cr6.lt) goto loc_8B0976F4;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// li r5,0
	ctx.r5.s64 = 0;
	// addi r4,r11,9180
	ctx.r4.s64 = ctx.r11.s64 + 9180;
	// mr r3,r25
	ctx.r3.u64 = ctx.r25.u64;
	// bl 0x8b0bfe68
	ctx.lr = 0x8B097740;
	sub_8B0BFE68(ctx, base);
	// stw r3,88(r1)
	REX_STORE_U32(ctx.r1.u32 + 88, ctx.r3.u32);
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// li r5,0
	ctx.r5.s64 = 0;
	// addi r4,r10,9168
	ctx.r4.s64 = ctx.r10.s64 + 9168;
	// mr r3,r25
	ctx.r3.u64 = ctx.r25.u64;
	// bl 0x8b0bfc38
	ctx.lr = 0x8B097758;
	sub_8B0BFC38(ctx, base);
	// stw r3,92(r1)
	REX_STORE_U32(ctx.r1.u32 + 92, ctx.r3.u32);
	// stw r23,96(r1)
	REX_STORE_U32(ctx.r1.u32 + 96, ctx.r23.u32);
	// lis r9,-29936
	ctx.r9.s64 = -1961885696;
	// lwz r3,-17796(r9)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r9.u32 + -17796);
	// lwz r8,0(r3)
	ctx.r8.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r7,40(r8)
	ctx.r7.u64 = REX_LOAD_U32(ctx.r8.u32 + 40);
	// mtctr r7
	ctx.ctr.u64 = ctx.r7.u64;
	// bctrl 
	ctx.lr = 0x8B097778;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// lwz r6,0(r3)
	ctx.r6.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r5,8(r6)
	ctx.r5.u64 = REX_LOAD_U32(ctx.r6.u32 + 8);
	// addi r4,r1,88
	ctx.r4.s64 = ctx.r1.s64 + 88;
	// mtctr r5
	ctx.ctr.u64 = ctx.r5.u64;
	// bctrl 
	ctx.lr = 0x8B09778C;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// lbz r4,268(r28)
	ctx.r4.u64 = REX_LOAD_U8(ctx.r28.u32 + 268);
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// mr r29,r3
	ctx.r29.u64 = ctx.r3.u64;
	// cmplwi cr6,r4,0
	ctx.cr6.compare<uint32_t>(ctx.r4.u32, 0, ctx.xer);
	// addi r24,r11,1791
	ctx.r24.s64 = ctx.r11.s64 + 1791;
	// bne cr6,0x8b0977cc
	if (!ctx.cr6.eq) goto loc_8B0977CC;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// mr r5,r24
	ctx.r5.u64 = ctx.r24.u64;
	// addi r4,r11,3720
	ctx.r4.s64 = ctx.r11.s64 + 3720;
	// bl 0x8b0c1588
	ctx.lr = 0x8B0977B4;
	sub_8B0C1588(ctx, base);
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// addi r3,r10,9164
	ctx.r3.s64 = ctx.r10.s64 + 9164;
	// bl 0x8b0cea10
	ctx.lr = 0x8B0977C4;
	sub_8B0CEA10(ctx, base);
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// bne cr6,0x8b097904
	if (!ctx.cr6.eq) goto loc_8B097904;
loc_8B0977CC:
	// mr r4,r27
	ctx.r4.u64 = ctx.r27.u64;
	// addi r3,r28,-4
	ctx.r3.s64 = ctx.r28.s64 + -4;
	// bl 0x8b096a70
	ctx.lr = 0x8B0977D8;
	sub_8B096A70(ctx, base);
	// mr r26,r3
	ctx.r26.u64 = ctx.r3.u64;
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// bne cr6,0x8b097820
	if (!ctx.cr6.eq) goto loc_8B097820;
	// li r3,424
	ctx.r3.s64 = 424;
	// bl 0x8b090000
	ctx.lr = 0x8B0977EC;
	sub_8B090000(ctx, base);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b097808
	if (ctx.cr6.eq) goto loc_8B097808;
	// li r5,0
	ctx.r5.s64 = 0;
	// mr r4,r27
	ctx.r4.u64 = ctx.r27.u64;
	// bl 0x8b09e750
	ctx.lr = 0x8B097800;
	sub_8B09E750(ctx, base);
	// mr r26,r3
	ctx.r26.u64 = ctx.r3.u64;
	// b 0x8b09780c
	goto loc_8B09780C;
loc_8B097808:
	// mr r26,r23
	ctx.r26.u64 = ctx.r23.u64;
loc_8B09780C:
	// stw r26,80(r1)
	REX_STORE_U32(ctx.r1.u32 + 80, ctx.r26.u32);
	// addi r3,r28,20
	ctx.r3.s64 = ctx.r28.s64 + 20;
	// addi r5,r1,80
	ctx.r5.s64 = ctx.r1.s64 + 80;
	// lwz r4,32(r28)
	ctx.r4.u64 = REX_LOAD_U32(ctx.r28.u32 + 32);
	// bl 0x8b09f3f8
	ctx.lr = 0x8B097820;
	sub_8B09F3F8(ctx, base);
loc_8B097820:
	// li r4,0
	ctx.r4.s64 = 0;
	// mr r3,r26
	ctx.r3.u64 = ctx.r26.u64;
	// bl 0x8b09bff0
	ctx.lr = 0x8B09782C;
	sub_8B09BFF0(ctx, base);
	// li r4,-1
	ctx.r4.s64 = -1;
	// mr r3,r26
	ctx.r3.u64 = ctx.r26.u64;
	// bl 0x8b09bfe0
	ctx.lr = 0x8B097838;
	sub_8B09BFE0(ctx, base);
	// cmplwi cr6,r29,0
	ctx.cr6.compare<uint32_t>(ctx.r29.u32, 0, ctx.xer);
	// beq cr6,0x8b0978c0
	if (ctx.cr6.eq) goto loc_8B0978C0;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// li r5,0
	ctx.r5.s64 = 0;
	// addi r31,r11,9156
	ctx.r31.s64 = ctx.r11.s64 + 9156;
	// mr r3,r25
	ctx.r3.u64 = ctx.r25.u64;
	// mr r4,r31
	ctx.r4.u64 = ctx.r31.u64;
	// bl 0x8b0bfa88
	ctx.lr = 0x8B097858;
	sub_8B0BFA88(ctx, base);
	// mr r30,r3
	ctx.r30.u64 = ctx.r3.u64;
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b097880
	if (ctx.cr6.eq) goto loc_8B097880;
	// mr r4,r31
	ctx.r4.u64 = ctx.r31.u64;
	// li r5,1
	ctx.r5.s64 = 1;
	// mr r3,r29
	ctx.r3.u64 = ctx.r29.u64;
	// bl 0x8b0bfa88
	ctx.lr = 0x8B097874;
	sub_8B0BFA88(ctx, base);
	// mr r4,r30
	ctx.r4.u64 = ctx.r30.u64;
	// li r5,1
	ctx.r5.s64 = 1;
	// bl 0x8b0c0668
	ctx.lr = 0x8B097880;
	sub_8B0C0668(ctx, base);
loc_8B097880:
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// li r5,0
	ctx.r5.s64 = 0;
	// addi r31,r11,9148
	ctx.r31.s64 = ctx.r11.s64 + 9148;
	// mr r3,r25
	ctx.r3.u64 = ctx.r25.u64;
	// mr r4,r31
	ctx.r4.u64 = ctx.r31.u64;
	// bl 0x8b0bfa88
	ctx.lr = 0x8B097898;
	sub_8B0BFA88(ctx, base);
	// mr r30,r3
	ctx.r30.u64 = ctx.r3.u64;
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0978c0
	if (ctx.cr6.eq) goto loc_8B0978C0;
	// mr r4,r31
	ctx.r4.u64 = ctx.r31.u64;
	// li r5,1
	ctx.r5.s64 = 1;
	// mr r3,r29
	ctx.r3.u64 = ctx.r29.u64;
	// bl 0x8b0bfa88
	ctx.lr = 0x8B0978B4;
	sub_8B0BFA88(ctx, base);
	// mr r4,r30
	ctx.r4.u64 = ctx.r30.u64;
	// li r5,1
	ctx.r5.s64 = 1;
	// bl 0x8b0c0668
	ctx.lr = 0x8B0978C0;
	sub_8B0C0668(ctx, base);
loc_8B0978C0:
	// li r10,7
	ctx.r10.s64 = 7;
	// addi r11,r1,112
	ctx.r11.s64 = ctx.r1.s64 + 112;
	// stw r23,112(r1)
	REX_STORE_U32(ctx.r1.u32 + 112, ctx.r23.u32);
	// mr r9,r23
	ctx.r9.u64 = ctx.r23.u64;
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
loc_8B0978D4:
	// stwu r9,4(r11)
	ea = 4 + ctx.r11.u32;
	REX_STORE_U32(ea, ctx.r9.u32);
	ctx.r11.u32 = ea;
	// bdnz 0x8b0978d4
	--ctx.ctr.u64;
	if (ctx.ctr.u32 != 0) goto loc_8B0978D4;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// mr r5,r24
	ctx.r5.u64 = ctx.r24.u64;
	// addi r4,r11,9136
	ctx.r4.s64 = ctx.r11.s64 + 9136;
	// mr r3,r25
	ctx.r3.u64 = ctx.r25.u64;
	// bl 0x8b0c1588
	ctx.lr = 0x8B0978F0;
	sub_8B0C1588(ctx, base);
	// stw r3,112(r1)
	REX_STORE_U32(ctx.r1.u32 + 112, ctx.r3.u32);
	// stw r29,136(r1)
	REX_STORE_U32(ctx.r1.u32 + 136, ctx.r29.u32);
	// addi r4,r1,112
	ctx.r4.s64 = ctx.r1.s64 + 112;
	// mr r3,r26
	ctx.r3.u64 = ctx.r26.u64;
	// bl 0x8b09e4f8
	ctx.lr = 0x8B097904;
	sub_8B09E4F8(ctx, base);
loc_8B097904:
	// cmplwi cr6,r29,0
	ctx.cr6.compare<uint32_t>(ctx.r29.u32, 0, ctx.xer);
	// beq cr6,0x8b097af0
	if (ctx.cr6.eq) goto loc_8B097AF0;
	// mr r3,r29
	ctx.r3.u64 = ctx.r29.u64;
	// bl 0x8b0c04f0
	ctx.lr = 0x8B097914;
	sub_8B0C04F0(ctx, base);
	// addi r1,r1,480
	ctx.r1.s64 = ctx.r1.s64 + 480;
	// b 0x8b0cb9f4
	__restgprlr_23(ctx, base);
	return;
loc_8B09791C:
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// addi r4,r11,9116
	ctx.r4.s64 = ctx.r11.s64 + 9116;
	// bl 0x8b0cea10
	ctx.lr = 0x8B09792C;
	sub_8B0CEA10(ctx, base);
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// bne cr6,0x8b097948
	if (!ctx.cr6.eq) goto loc_8B097948;
	// mr r4,r29
	ctx.r4.u64 = ctx.r29.u64;
	// addi r3,r28,-4
	ctx.r3.s64 = ctx.r28.s64 + -4;
	// bl 0x8b096d40
	ctx.lr = 0x8B097940;
	sub_8B096D40(ctx, base);
	// addi r1,r1,480
	ctx.r1.s64 = ctx.r1.s64 + 480;
	// b 0x8b0cb9f4
	__restgprlr_23(ctx, base);
	return;
loc_8B097948:
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// addi r4,r11,8800
	ctx.r4.s64 = ctx.r11.s64 + 8800;
	// bl 0x8b0cea10
	ctx.lr = 0x8B097958;
	sub_8B0CEA10(ctx, base);
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// bne cr6,0x8b097970
	if (!ctx.cr6.eq) goto loc_8B097970;
	// addi r3,r28,-4
	ctx.r3.s64 = ctx.r28.s64 + -4;
	// bl 0x8b097390
	ctx.lr = 0x8B097968;
	sub_8B097390(ctx, base);
	// addi r1,r1,480
	ctx.r1.s64 = ctx.r1.s64 + 480;
	// b 0x8b0cb9f4
	__restgprlr_23(ctx, base);
	return;
loc_8B097970:
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// addi r4,r11,9088
	ctx.r4.s64 = ctx.r11.s64 + 9088;
	// bl 0x8b0cea10
	ctx.lr = 0x8B097980;
	sub_8B0CEA10(ctx, base);
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// bne cr6,0x8b097a18
	if (!ctx.cr6.eq) goto loc_8B097A18;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// addi r30,r28,4
	ctx.r30.s64 = ctx.r28.s64 + 4;
	// li r31,0
	ctx.r31.s64 = 0;
	// addi r28,r11,9040
	ctx.r28.s64 = ctx.r11.s64 + 9040;
	// addi r27,r10,8900
	ctx.r27.s64 = ctx.r10.s64 + 8900;
loc_8B0979A0:
	// lwz r11,0(r30)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r30.u32 + 0);
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// beq cr6,0x8b097a00
	if (ctx.cr6.eq) goto loc_8B097A00;
	// mr r4,r27
	ctx.r4.u64 = ctx.r27.u64;
	// mr r5,r31
	ctx.r5.u64 = ctx.r31.u64;
	// addi r3,r1,144
	ctx.r3.s64 = ctx.r1.s64 + 144;
	// bl 0x8b090220
	ctx.lr = 0x8B0979BC;
	sub_8B090220(ctx, base);
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// li r5,0
	ctx.r5.s64 = 0;
	// mr r3,r29
	ctx.r3.u64 = ctx.r29.u64;
	// bl 0x8b0bfc38
	ctx.lr = 0x8B0979CC;
	sub_8B0BFC38(ctx, base);
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// beq cr6,0x8b097a00
	if (ctx.cr6.eq) goto loc_8B097A00;
	// lwz r3,0(r30)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r30.u32 + 0);
	// lwz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r10,8(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 8);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B0979E8;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// mr r5,r3
	ctx.r5.u64 = ctx.r3.u64;
	// mr r4,r31
	ctx.r4.u64 = ctx.r31.u64;
	// mr r3,r28
	ctx.r3.u64 = ctx.r28.u64;
	// bl 0x8b0df298
	ctx.lr = 0x8B0979F8;
	sub_8B0DF298(ctx, base);
	// lwz r3,0(r30)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r30.u32 + 0);
	// bl 0x8b09c170
	ctx.lr = 0x8B097A00;
	sub_8B09C170(ctx, base);
loc_8B097A00:
	// addi r31,r31,1
	ctx.r31.s64 = ctx.r31.s64 + 1;
	// addi r30,r30,4
	ctx.r30.s64 = ctx.r30.s64 + 4;
	// cmplwi cr6,r31,4
	ctx.cr6.compare<uint32_t>(ctx.r31.u32, 4, ctx.xer);
	// blt cr6,0x8b0979a0
	if (ctx.cr6.lt) goto loc_8B0979A0;
	// addi r1,r1,480
	ctx.r1.s64 = ctx.r1.s64 + 480;
	// b 0x8b0cb9f4
	__restgprlr_23(ctx, base);
	return;
loc_8B097A18:
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// addi r4,r11,4472
	ctx.r4.s64 = ctx.r11.s64 + 4472;
	// bl 0x8b0cea10
	ctx.lr = 0x8B097A28;
	sub_8B0CEA10(ctx, base);
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// bne cr6,0x8b097af0
	if (!ctx.cr6.eq) goto loc_8B097AF0;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// addi r31,r11,1791
	ctx.r31.s64 = ctx.r11.s64 + 1791;
	// addi r30,r10,4500
	ctx.r30.s64 = ctx.r10.s64 + 4500;
	// mr r5,r31
	ctx.r5.u64 = ctx.r31.u64;
	// mr r4,r30
	ctx.r4.u64 = ctx.r30.u64;
	// mr r3,r29
	ctx.r3.u64 = ctx.r29.u64;
	// li r28,0
	ctx.r28.s64 = 0;
	// bl 0x8b0c1588
	ctx.lr = 0x8B097A54;
	sub_8B0C1588(ctx, base);
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// addi r3,r11,4508
	ctx.r3.s64 = ctx.r11.s64 + 4508;
	// bl 0x8b0cea10
	ctx.lr = 0x8B097A64;
	sub_8B0CEA10(ctx, base);
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// bne cr6,0x8b097a80
	if (!ctx.cr6.eq) goto loc_8B097A80;
	// li r28,2
	ctx.r28.s64 = 2;
	// mr r3,r28
	ctx.r3.u64 = ctx.r28.u64;
	// bl 0x8b09cfd0
	ctx.lr = 0x8B097A78;
	sub_8B09CFD0(ctx, base);
	// addi r1,r1,480
	ctx.r1.s64 = ctx.r1.s64 + 480;
	// b 0x8b0cb9f4
	__restgprlr_23(ctx, base);
	return;
loc_8B097A80:
	// mr r5,r31
	ctx.r5.u64 = ctx.r31.u64;
	// mr r4,r30
	ctx.r4.u64 = ctx.r30.u64;
	// mr r3,r29
	ctx.r3.u64 = ctx.r29.u64;
	// bl 0x8b0c1588
	ctx.lr = 0x8B097A90;
	sub_8B0C1588(ctx, base);
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// addi r3,r11,9024
	ctx.r3.s64 = ctx.r11.s64 + 9024;
	// bl 0x8b0cea10
	ctx.lr = 0x8B097AA0;
	sub_8B0CEA10(ctx, base);
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// bne cr6,0x8b097abc
	if (!ctx.cr6.eq) goto loc_8B097ABC;
	// li r28,1
	ctx.r28.s64 = 1;
	// mr r3,r28
	ctx.r3.u64 = ctx.r28.u64;
	// bl 0x8b09cfd0
	ctx.lr = 0x8B097AB4;
	sub_8B09CFD0(ctx, base);
	// addi r1,r1,480
	ctx.r1.s64 = ctx.r1.s64 + 480;
	// b 0x8b0cb9f4
	__restgprlr_23(ctx, base);
	return;
loc_8B097ABC:
	// mr r5,r31
	ctx.r5.u64 = ctx.r31.u64;
	// mr r4,r30
	ctx.r4.u64 = ctx.r30.u64;
	// mr r3,r29
	ctx.r3.u64 = ctx.r29.u64;
	// bl 0x8b0c1588
	ctx.lr = 0x8B097ACC;
	sub_8B0C1588(ctx, base);
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// addi r3,r11,9012
	ctx.r3.s64 = ctx.r11.s64 + 9012;
	// bl 0x8b0cea10
	ctx.lr = 0x8B097ADC;
	sub_8B0CEA10(ctx, base);
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// bne cr6,0x8b097ae8
	if (!ctx.cr6.eq) goto loc_8B097AE8;
	// li r28,3
	ctx.r28.s64 = 3;
loc_8B097AE8:
	// mr r3,r28
	ctx.r3.u64 = ctx.r28.u64;
	// bl 0x8b09cfd0
	ctx.lr = 0x8B097AF0;
	sub_8B09CFD0(ctx, base);
loc_8B097AF0:
	// addi r1,r1,480
	ctx.r1.s64 = ctx.r1.s64 + 480;
	// b 0x8b0cb9f4
	__restgprlr_23(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0986D0) {
	REX_FUNC_PROLOGUE();
	PPCRegister temp{};
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9bc
	ctx.lr = 0x8B0986D8;
	__savegprlr_29(ctx, base);
	// stwu r1,-176(r1)
	ea = -176 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// mr r29,r3
	ctx.r29.u64 = ctx.r3.u64;
	// bl 0x8b0980d0
	ctx.lr = 0x8B0986E4;
	sub_8B0980D0(ctx, base);
	// li r3,88
	ctx.r3.s64 = 88;
	// bl 0x8b090000
	ctx.lr = 0x8B0986EC;
	sub_8B090000(ctx, base);
	// lis r31,-29938
	ctx.r31.s64 = -1962016768;
	// li r5,88
	ctx.r5.s64 = 88;
	// li r4,0
	ctx.r4.s64 = 0;
	// stw r3,17464(r31)
	REX_STORE_U32(ctx.r31.u32 + 17464, ctx.r3.u32);
	// bl 0x8b0cb8e0
	ctx.lr = 0x8B098700;
	sub_8B0CB8E0(ctx, base);
	// lwz r11,17464(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 17464);
	// lis r10,-29936
	ctx.r10.s64 = -1961885696;
	// lwz r9,0(r29)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r29.u32 + 0);
	// stw r9,72(r11)
	REX_STORE_U32(ctx.r11.u32 + 72, ctx.r9.u32);
	// lwz r3,-17796(r10)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r10.u32 + -17796);
	// lwz r8,0(r3)
	ctx.r8.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r7,32(r8)
	ctx.r7.u64 = REX_LOAD_U32(ctx.r8.u32 + 32);
	// mtctr r7
	ctx.ctr.u64 = ctx.r7.u64;
	// bctrl 
	ctx.lr = 0x8B098724;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// lwz r6,0(r3)
	ctx.r6.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r5,4(r6)
	ctx.r5.u64 = REX_LOAD_U32(ctx.r6.u32 + 4);
	// mtctr r5
	ctx.ctr.u64 = ctx.r5.u64;
	// bctrl 
	ctx.lr = 0x8B098734;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// lwz r11,17464(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 17464);
	// stw r3,76(r11)
	REX_STORE_U32(ctx.r11.u32 + 76, ctx.r3.u32);
	// bl 0x8b0df2f8
	ctx.lr = 0x8B098740;
	sub_8B0DF2F8(ctx, base);
	// lwz r10,17464(r31)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r31.u32 + 17464);
	// li r11,255
	ctx.r11.s64 = 255;
	// frsp f0,f1
	ctx.fpscr.disableFlushMode();
	ctx.f0.f64 = double(float(ctx.f1.f64));
	// li r30,0
	ctx.r30.s64 = 0;
	// lis r9,-29944
	ctx.r9.s64 = -1962409984;
	// addi r3,r1,128
	ctx.r3.s64 = ctx.r1.s64 + 128;
	// stfs f0,84(r10)
	temp.f32 = float(ctx.f0.f64);
	REX_STORE_U32(ctx.r10.u32 + 84, temp.u32);
	// stb r11,128(r1)
	REX_STORE_U8(ctx.r1.u32 + 128, ctx.r11.u8);
	// stb r30,129(r1)
	REX_STORE_U8(ctx.r1.u32 + 129, ctx.r30.u8);
	// addi r4,r9,9816
	ctx.r4.s64 = ctx.r9.s64 + 9816;
	// stb r11,130(r1)
	REX_STORE_U8(ctx.r1.u32 + 130, ctx.r11.u8);
	// stb r11,131(r1)
	REX_STORE_U8(ctx.r1.u32 + 131, ctx.r11.u8);
	// lwz r5,0(r29)
	ctx.r5.u64 = REX_LOAD_U32(ctx.r29.u32 + 0);
	// bl 0x8b0df368
	ctx.lr = 0x8B098778;
	sub_8B0DF368(ctx, base);
	// lis r8,-29938
	ctx.r8.s64 = -1962016768;
	// lwz r10,2364(r8)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r8.u32 + 2364);
	// li r4,2
	ctx.r4.s64 = 2;
	// stw r30,108(r1)
	REX_STORE_U32(ctx.r1.u32 + 108, ctx.r30.u32);
	// li r8,1
	ctx.r8.s64 = 1;
	// stw r30,100(r1)
	REX_STORE_U32(ctx.r1.u32 + 100, ctx.r30.u32);
	// li r7,0
	ctx.r7.s64 = 0;
	// stw r30,92(r1)
	REX_STORE_U32(ctx.r1.u32 + 92, ctx.r30.u32);
	// li r6,0
	ctx.r6.s64 = 0;
	// lwz r11,17464(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 17464);
	// li r5,0
	ctx.r5.s64 = 0;
	// lwz r30,104(r10)
	ctx.r30.u64 = REX_LOAD_U32(ctx.r10.u32 + 104);
	// addi r3,r11,80
	ctx.r3.s64 = ctx.r11.s64 + 80;
	// stw r4,84(r1)
	REX_STORE_U32(ctx.r1.u32 + 84, ctx.r4.u32);
	// addi r9,r11,72
	ctx.r9.s64 = ctx.r11.s64 + 72;
	// addi r10,r11,76
	ctx.r10.s64 = ctx.r11.s64 + 76;
	// stw r3,116(r1)
	REX_STORE_U32(ctx.r1.u32 + 116, ctx.r3.u32);
	// li r4,0
	ctx.r4.s64 = 0;
	// lwz r11,0(r30)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r30.u32 + 0);
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// lwz r11,28(r11)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r11.u32 + 28);
	// mtctr r11
	ctx.ctr.u64 = ctx.r11.u64;
	// bctrl 
	ctx.lr = 0x8B0987D4;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// beq cr6,0x8b0987ec
	if (ctx.cr6.eq) goto loc_8B0987EC;
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// lwz r11,17464(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 17464);
	// lfs f0,8492(r10)
	ctx.fpscr.disableFlushMode();
	temp.u32 = REX_LOAD_U32(ctx.r10.u32 + 8492);
	ctx.f0.f64 = double(temp.f32);
	// stfs f0,84(r11)
	temp.f32 = float(ctx.f0.f64);
	REX_STORE_U32(ctx.r11.u32 + 84, temp.u32);
loc_8B0987EC:
	// addi r1,r1,176
	ctx.r1.s64 = ctx.r1.s64 + 176;
	// b 0x8b0cba0c
	__restgprlr_29(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B098E70) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9b8
	ctx.lr = 0x8B098E78;
	__savegprlr_28(ctx, base);
	// stwu r1,-128(r1)
	ea = -128 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// clrlwi r11,r6,28
	ctx.r11.u64 = ctx.r6.u32 & 0xF;
	// mr r30,r3
	ctx.r30.u64 = ctx.r3.u64;
	// rlwinm r11,r11,0,31,28
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 0) & 0xFFFFFFFFFFFFFFF9;
	// mr r28,r4
	ctx.r28.u64 = ctx.r4.u64;
	// mr r29,r5
	ctx.r29.u64 = ctx.r5.u64;
	// mr r31,r6
	ctx.r31.u64 = ctx.r6.u64;
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// beq cr6,0x8b098ec0
	if (ctx.cr6.eq) goto loc_8B098EC0;
	// mr r5,r6
	ctx.r5.u64 = ctx.r6.u64;
	// mr r4,r29
	ctx.r4.u64 = ctx.r29.u64;
	// bl 0x8b098950
	ctx.lr = 0x8B098EA8;
	sub_8B098950(ctx, base);
	// clrlwi r11,r3,24
	ctx.r11.u64 = ctx.r3.u32 & 0xFF;
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// bne cr6,0x8b098ec0
	if (!ctx.cr6.eq) goto loc_8B098EC0;
	// li r3,0
	ctx.r3.s64 = 0;
	// addi r1,r1,128
	ctx.r1.s64 = ctx.r1.s64 + 128;
	// b 0x8b0cba08
	__restgprlr_28(ctx, base);
	return;
loc_8B098EC0:
	// rlwinm r11,r31,0,30,30
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r31.u32 | (ctx.r31.u64 << 32), 0) & 0x2;
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// beq cr6,0x8b098ef0
	if (ctx.cr6.eq) goto loc_8B098EF0;
	// mr r6,r31
	ctx.r6.u64 = ctx.r31.u64;
	// mr r5,r29
	ctx.r5.u64 = ctx.r29.u64;
	// mr r4,r28
	ctx.r4.u64 = ctx.r28.u64;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// bl 0x8b098b50
	ctx.lr = 0x8B098EE0;
	sub_8B098B50(ctx, base);
	// clrlwi r11,r3,24
	ctx.r11.u64 = ctx.r3.u32 & 0xFF;
	// li r3,0
	ctx.r3.s64 = 0;
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// beq cr6,0x8b098ef4
	if (ctx.cr6.eq) goto loc_8B098EF4;
loc_8B098EF0:
	// li r3,1
	ctx.r3.s64 = 1;
loc_8B098EF4:
	// addi r1,r1,128
	ctx.r1.s64 = ctx.r1.s64 + 128;
	// b 0x8b0cba08
	__restgprlr_28(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B098F00) {
	REX_FUNC_PROLOGUE();
	// lwz r3,80(r3)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r3.u32 + 80);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B098F08) {
	REX_FUNC_PROLOGUE();
	// lwz r3,100(r3)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r3.u32 + 100);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B098F10) {
	REX_FUNC_PROLOGUE();
	// lis r11,-29938
	ctx.r11.s64 = -1962016768;
	// addi r3,r11,18240
	ctx.r3.s64 = ctx.r11.s64 + 18240;
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B098FC8) {
	REX_FUNC_PROLOGUE();
	PPCRegister temp{};
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9b8
	ctx.lr = 0x8B098FD0;
	__savegprlr_28(ctx, base);
	// stwu r1,-128(r1)
	ea = -128 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lis r10,-29942
	ctx.r10.s64 = -1962278912;
	// lis r28,-29938
	ctx.r28.s64 = -1962016768;
	// mr r11,r4
	ctx.r11.u64 = ctx.r4.u64;
	// addi r9,r10,-28896
	ctx.r9.s64 = ctx.r10.s64 + -28896;
	// li r4,1
	ctx.r4.s64 = 1;
	// stw r9,80(r1)
	REX_STORE_U32(ctx.r1.u32 + 80, ctx.r9.u32);
	// addi r3,r1,80
	ctx.r3.s64 = ctx.r1.s64 + 80;
	// stw r11,18212(r28)
	REX_STORE_U32(ctx.r28.u32 + 18212, ctx.r11.u32);
	// bl 0x8b0c7688
	ctx.lr = 0x8B098FF8;
	sub_8B0C7688(ctx, base);
	// li r4,1
	ctx.r4.s64 = 1;
	// addi r3,r1,80
	ctx.r3.s64 = ctx.r1.s64 + 80;
	// bl 0x8b0cb200
	ctx.lr = 0x8B099004;
	sub_8B0CB200(ctx, base);
	// li r4,0
	ctx.r4.s64 = 0;
	// li r3,0
	ctx.r3.s64 = 0;
	// bl 0x8b0c5d38
	ctx.lr = 0x8B099010;
	sub_8B0C5D38(ctx, base);
	// lis r8,-29938
	ctx.r8.s64 = -1962016768;
	// addi r31,r8,3040
	ctx.r31.s64 = ctx.r8.s64 + 3040;
	// lwz r11,3040(r8)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r8.u32 + 3040);
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// beq cr6,0x8b099084
	if (ctx.cr6.eq) goto loc_8B099084;
	// lis r30,-29938
	ctx.r30.s64 = -1962016768;
	// li r29,1
	ctx.r29.s64 = 1;
loc_8B09902C:
	// lbz r10,8(r31)
	ctx.r10.u64 = REX_LOAD_U8(ctx.r31.u32 + 8);
	// cmplwi cr6,r10,0
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 0, ctx.xer);
	// bne cr6,0x8b099078
	if (!ctx.cr6.eq) goto loc_8B099078;
	// lwz r11,80(r1)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r1.u32 + 80);
	// li r4,0
	ctx.r4.s64 = 0;
	// lwz r3,0(r31)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r31.u32 + 0);
	// mtctr r11
	ctx.ctr.u64 = ctx.r11.u64;
	// bctrl 
	ctx.lr = 0x8B09904C;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// mr r5,r3
	ctx.r5.u64 = ctx.r3.u64;
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b099078
	if (ctx.cr6.eq) goto loc_8B099078;
	// lwz r11,2364(r30)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r30.u32 + 2364);
	// lwz r4,0(r31)
	ctx.r4.u64 = REX_LOAD_U32(ctx.r31.u32 + 0);
	// mr r3,r11
	ctx.r3.u64 = ctx.r11.u64;
	// lwz r10,0(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 0);
	// lwz r9,0(r10)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r10.u32 + 0);
	// mtctr r9
	ctx.ctr.u64 = ctx.r9.u64;
	// bctrl 
	ctx.lr = 0x8B099074;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// stb r29,8(r31)
	REX_STORE_U8(ctx.r31.u32 + 8, ctx.r29.u8);
loc_8B099078:
	// lwzu r11,12(r31)
	ea = 12 + ctx.r31.u32;
	ctx.r11.u64 = REX_LOAD_U32(ea);
	ctx.r31.u32 = ea;
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// bne cr6,0x8b09902c
	if (!ctx.cr6.eq) goto loc_8B09902C;
loc_8B099084:
	// li r11,0
	ctx.r11.s64 = 0;
	// lis r7,-29944
	ctx.r7.s64 = -1962409984;
	// stw r11,18212(r28)
	REX_STORE_U32(ctx.r28.u32 + 18212, ctx.r11.u32);
	// lis r6,-29944
	ctx.r6.s64 = -1962409984;
	// li r10,1
	ctx.r10.s64 = 1;
	// li r9,1
	ctx.r9.s64 = 1;
	// li r8,1
	ctx.r8.s64 = 1;
	// lfs f2,11088(r7)
	ctx.fpscr.disableFlushMode();
	temp.u32 = REX_LOAD_U32(ctx.r7.u32 + 11088);
	ctx.f2.f64 = double(temp.f32);
	// li r7,1
	ctx.r7.s64 = 1;
	// lfs f3,8492(r6)
	temp.u32 = REX_LOAD_U32(ctx.r6.u32 + 8492);
	ctx.f3.f64 = double(temp.f32);
	// li r6,2
	ctx.r6.s64 = 2;
	// fmr f1,f2
	ctx.f1.f64 = ctx.f2.f64;
	// bl 0x8b0bde00
	ctx.lr = 0x8B0990B8;
	sub_8B0BDE00(ctx, base);
	// bl 0x8b0a6e90
	ctx.lr = 0x8B0990BC;
	sub_8B0A6E90(ctx, base);
	// li r3,1
	ctx.r3.s64 = 1;
	// addi r1,r1,128
	ctx.r1.s64 = ctx.r1.s64 + 128;
	// b 0x8b0cba08
	__restgprlr_28(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B099380) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9b8
	ctx.lr = 0x8B099388;
	__savegprlr_28(ctx, base);
	// stwu r1,-176(r1)
	ea = -176 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// mr r29,r3
	ctx.r29.u64 = ctx.r3.u64;
	// cmpldi cr6,r3,0
	ctx.cr6.compare<uint64_t>(ctx.r3.u64, 0, ctx.xer);
	// beq cr6,0x8b099430
	if (ctx.cr6.eq) goto loc_8B099430;
	// li r28,0
	ctx.r28.s64 = 0;
	// mr r30,r28
	ctx.r30.u64 = ctx.r28.u64;
	// bl 0x8b0df2c8
	ctx.lr = 0x8B0993A4;
	sub_8B0DF2C8(ctx, base);
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// ble cr6,0x8b099430
	if (!ctx.cr6.gt) goto loc_8B099430;
loc_8B0993AC:
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// bl 0x8b0df2b8
	ctx.lr = 0x8B0993B4;
	sub_8B0DF2B8(ctx, base);
	// std r28,80(r1)
	REX_STORE_U64(ctx.r1.u32 + 80, ctx.r28.u64);
	// addi r4,r1,80
	ctx.r4.s64 = ctx.r1.s64 + 80;
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// bl 0x8b0955b0
	ctx.lr = 0x8B0993C4;
	sub_8B0955B0(ctx, base);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// bne cr6,0x8b0993d8
	if (!ctx.cr6.eq) goto loc_8B0993D8;
	// ld r11,80(r1)
	ctx.r11.u64 = REX_LOAD_U64(ctx.r1.u32 + 80);
	// cmpld cr6,r11,r29
	ctx.cr6.compare<uint64_t>(ctx.r11.u64, ctx.r29.u64, ctx.xer);
	// beq cr6,0x8b09943c
	if (ctx.cr6.eq) goto loc_8B09943C;
loc_8B0993D8:
	// addi r5,r1,96
	ctx.r5.s64 = ctx.r1.s64 + 96;
	// li r4,2
	ctx.r4.s64 = 2;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0dbdc8
	ctx.lr = 0x8B0993E8;
	sub_8B0DBDC8(ctx, base);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// bne cr6,0x8b0993fc
	if (!ctx.cr6.eq) goto loc_8B0993FC;
	// ld r11,96(r1)
	ctx.r11.u64 = REX_LOAD_U64(ctx.r1.u32 + 96);
	// cmpld cr6,r11,r29
	ctx.cr6.compare<uint64_t>(ctx.r11.u64, ctx.r29.u64, ctx.xer);
	// beq cr6,0x8b09943c
	if (ctx.cr6.eq) goto loc_8B09943C;
loc_8B0993FC:
	// addi r5,r1,96
	ctx.r5.s64 = ctx.r1.s64 + 96;
	// li r4,1
	ctx.r4.s64 = 1;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0dbdc8
	ctx.lr = 0x8B09940C;
	sub_8B0DBDC8(ctx, base);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// bne cr6,0x8b099420
	if (!ctx.cr6.eq) goto loc_8B099420;
	// ld r11,96(r1)
	ctx.r11.u64 = REX_LOAD_U64(ctx.r1.u32 + 96);
	// cmpld cr6,r11,r29
	ctx.cr6.compare<uint64_t>(ctx.r11.u64, ctx.r29.u64, ctx.xer);
	// beq cr6,0x8b09943c
	if (ctx.cr6.eq) goto loc_8B09943C;
loc_8B099420:
	// addi r30,r30,1
	ctx.r30.s64 = ctx.r30.s64 + 1;
	// bl 0x8b0df2c8
	ctx.lr = 0x8B099428;
	sub_8B0DF2C8(ctx, base);
	// cmpw cr6,r30,r3
	ctx.cr6.compare<int32_t>(ctx.r30.s32, ctx.r3.s32, ctx.xer);
	// blt cr6,0x8b0993ac
	if (ctx.cr6.lt) goto loc_8B0993AC;
loc_8B099430:
	// li r3,-1
	ctx.r3.s64 = -1;
	// addi r1,r1,176
	ctx.r1.s64 = ctx.r1.s64 + 176;
	// b 0x8b0cba08
	__restgprlr_28(ctx, base);
	return;
loc_8B09943C:
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// addi r1,r1,176
	ctx.r1.s64 = ctx.r1.s64 + 176;
	// b 0x8b0cba08
	__restgprlr_28(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B099558) {
	REX_FUNC_PROLOGUE();
	// mr r5,r4
	ctx.r5.u64 = ctx.r4.u64;
	// li r4,36
	ctx.r4.s64 = 36;
	// b 0x8b099448
	sub_8B099448(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B099568) {
	REX_FUNC_PROLOGUE();
	PPCRegister temp{};
	// lwz r10,8(r3)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r3.u32 + 8);
	// li r11,2
	ctx.r11.s64 = 2;
	// srawi r9,r10,31
	ctx.xer.ca = (ctx.r10.s32 < 0) & ((ctx.r10.u32 & 0x7FFFFFFF) != 0);
	ctx.r9.s64 = ctx.r10.s32 >> 31;
	// rlwinm r8,r11,1,31,31
	ctx.r8.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 1) & 0x1;
	// subfc r7,r11,r10
	ctx.xer.ca = ctx.r10.u32 >= ctx.r11.u32;
	ctx.r7.u64 = ctx.r10.u64 - ctx.r11.u64;
	// adde r11,r8,r9
	temp.u8 = (ctx.r8.u32 + ctx.r9.u32 < ctx.r8.u32) | (ctx.r8.u32 + ctx.r9.u32 + ctx.xer.ca < ctx.xer.ca);
	ctx.r11.u64 = ctx.r8.u64 + ctx.r9.u64 + ctx.xer.ca;
	ctx.xer.ca = temp.u8;
	// clrlwi r3,r11,24
	ctx.r3.u64 = ctx.r11.u32 & 0xFF;
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0996D8) {
	REX_FUNC_PROLOGUE();
	// clrldi r11,r5,32
	ctx.r11.u64 = ctx.r5.u64 & 0xFFFFFFFF;
	// std r11,40(r3)
	REX_STORE_U64(ctx.r3.u32 + 40, ctx.r11.u64);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B099908) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// std r31,-16(r1)
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.r31.u64);
	// stwu r1,-96(r1)
	ea = -96 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lwz r11,0(r4)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r4.u32 + 0);
	// mr r31,r4
	ctx.r31.u64 = ctx.r4.u64;
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// beq cr6,0x8b099958
	if (ctx.cr6.eq) goto loc_8B099958;
	// li r5,0
	ctx.r5.s64 = 0;
	// addi r4,r11,4
	ctx.r4.s64 = ctx.r11.s64 + 4;
	// bl 0x8b0dbe70
	ctx.lr = 0x8B099934;
	sub_8B0DBE70(ctx, base);
	// lwz r11,0(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 0);
	// addi r4,r31,4
	ctx.r4.s64 = ctx.r31.s64 + 4;
	// li r5,60
	ctx.r5.s64 = 60;
	// lwz r11,0(r11)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r11.u32 + 0);
	// addi r3,r11,16
	ctx.r3.s64 = ctx.r11.s64 + 16;
	// bl 0x8b0cbb30
	ctx.lr = 0x8B09994C;
	sub_8B0CBB30(ctx, base);
	// lwz r9,0(r31)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r31.u32 + 0);
	// li r10,1
	ctx.r10.s64 = 1;
	// stb r10,8(r9)
	REX_STORE_U8(ctx.r9.u32 + 8, ctx.r10.u8);
loc_8B099958:
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b090020
	ctx.lr = 0x8B099960;
	sub_8B090020(ctx, base);
	// addi r1,r1,96
	ctx.r1.s64 = ctx.r1.s64 + 96;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B099B58) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// std r31,-16(r1)
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.r31.u64);
	// stwu r1,-96(r1)
	ea = -96 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// addi r3,r3,4
	ctx.r3.s64 = ctx.r3.s64 + 4;
	// bl 0x8b0df398
	ctx.lr = 0x8B099B74;
	sub_8B0DF398(ctx, base);
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// bne cr6,0x8b099bb8
	if (!ctx.cr6.eq) goto loc_8B099BB8;
	// lwz r11,0(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 0);
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// lwz r10,4(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 4);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B099B90;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// clrlwi r9,r3,24
	ctx.r9.u64 = ctx.r3.u32 & 0xFF;
	// cmplwi cr6,r9,0
	ctx.cr6.compare<uint32_t>(ctx.r9.u32, 0, ctx.xer);
	// beq cr6,0x8b099bb4
	if (ctx.cr6.eq) goto loc_8B099BB4;
	// lwz r11,0(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 0);
	// li r4,1
	ctx.r4.s64 = 1;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// lwz r10,0(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 0);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B099BB4;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
loc_8B099BB4:
	// li r3,0
	ctx.r3.s64 = 0;
loc_8B099BB8:
	// addi r1,r1,96
	ctx.r1.s64 = ctx.r1.s64 + 96;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B099DA8) {
	REX_FUNC_PROLOGUE();
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// addi r3,r11,11412
	ctx.r3.s64 = ctx.r11.s64 + 11412;
	// b 0x8b0df2e8
	sub_8B0DF2E8(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B099DB8) {
	REX_FUNC_PROLOGUE();
	// clrldi r11,r5,32
	ctx.r11.u64 = ctx.r5.u64 & 0xFFFFFFFF;
	// std r11,40(r3)
	REX_STORE_U64(ctx.r3.u32 + 40, ctx.r11.u64);
	// lwz r3,48(r3)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r3.u32 + 48);
	// b 0x8b0dbe10
	sub_8B0DBE10(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B099DC8) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9a4
	ctx.lr = 0x8B099DD0;
	__savegprlr_23(ctx, base);
	// stwu r1,-176(r1)
	ea = -176 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// li r29,0
	ctx.r29.s64 = 0;
	// addi r28,r3,48
	ctx.r28.s64 = ctx.r3.s64 + 48;
	// mr r30,r4
	ctx.r30.u64 = ctx.r4.u64;
	// stw r29,8(r3)
	REX_STORE_U32(ctx.r3.u32 + 8, ctx.r29.u32);
	// li r5,144
	ctx.r5.s64 = 144;
	// li r4,0
	ctx.r4.s64 = 0;
	// std r29,40(r31)
	REX_STORE_U64(ctx.r31.u32 + 40, ctx.r29.u64);
	// mr r3,r28
	ctx.r3.u64 = ctx.r28.u64;
	// bl 0x8b0cb8e0
	ctx.lr = 0x8B099DFC;
	sub_8B0CB8E0(ctx, base);
	// li r10,7
	ctx.r10.s64 = 7;
	// addi r27,r31,12
	ctx.r27.s64 = ctx.r31.s64 + 12;
	// stw r29,192(r31)
	REX_STORE_U32(ctx.r31.u32 + 192, ctx.r29.u32);
	// mr r9,r29
	ctx.r9.u64 = ctx.r29.u64;
	// addi r11,r27,-4
	ctx.r11.s64 = ctx.r27.s64 + -4;
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
loc_8B099E14:
	// stwu r9,4(r11)
	ea = 4 + ctx.r11.u32;
	REX_STORE_U32(ea, ctx.r9.u32);
	ctx.r11.u32 = ea;
	// bdnz 0x8b099e14
	--ctx.ctr.u64;
	if (ctx.ctr.u32 != 0) goto loc_8B099E14;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// addi r9,r11,11500
	ctx.r9.s64 = ctx.r11.s64 + 11500;
	// addi r8,r10,11492
	ctx.r8.s64 = ctx.r10.s64 + 11492;
	// stw r9,0(r31)
	REX_STORE_U32(ctx.r31.u32 + 0, ctx.r9.u32);
	// stw r8,4(r31)
	REX_STORE_U32(ctx.r31.u32 + 4, ctx.r8.u32);
	// bl 0x8b0df2c8
	ctx.lr = 0x8B099E38;
	sub_8B0DF2C8(ctx, base);
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// ble cr6,0x8b099e68
	if (!ctx.cr6.gt) goto loc_8B099E68;
loc_8B099E40:
	// mr r3,r29
	ctx.r3.u64 = ctx.r29.u64;
	// bl 0x8b0df2b8
	ctx.lr = 0x8B099E48;
	sub_8B0DF2B8(ctx, base);
	// lis r4,0
	ctx.r4.s64 = 0;
	// lwz r5,4(r30)
	ctx.r5.u64 = REX_LOAD_U32(ctx.r30.u32 + 4);
	// ori r4,r4,32778
	ctx.r4.u64 = ctx.r4.u64 | 32778;
	// bl 0x8b095398
	ctx.lr = 0x8B099E58;
	sub_8B095398(ctx, base);
	// addi r29,r29,1
	ctx.r29.s64 = ctx.r29.s64 + 1;
	// bl 0x8b0df2c8
	ctx.lr = 0x8B099E60;
	sub_8B0DF2C8(ctx, base);
	// cmpw cr6,r29,r3
	ctx.cr6.compare<int32_t>(ctx.r29.s32, ctx.r3.s32, ctx.xer);
	// blt cr6,0x8b099e40
	if (ctx.cr6.lt) goto loc_8B099E40;
loc_8B099E68:
	// lis r11,-29938
	ctx.r11.s64 = -1962016768;
	// lwz r26,12(r30)
	ctx.r26.u64 = REX_LOAD_U32(ctx.r30.u32 + 12);
	// lwz r25,8(r30)
	ctx.r25.u64 = REX_LOAD_U32(ctx.r30.u32 + 8);
	// addi r24,r31,64
	ctx.r24.s64 = ctx.r31.s64 + 64;
	// lwz r11,2364(r11)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r11.u32 + 2364);
	// lwz r23,104(r11)
	ctx.r23.u64 = REX_LOAD_U32(ctx.r11.u32 + 104);
	// lwz r29,0(r23)
	ctx.r29.u64 = REX_LOAD_U32(ctx.r23.u32 + 0);
	// bl 0x8b0df318
	ctx.lr = 0x8B099E88;
	sub_8B0DF318(ctx, base);
	// lwz r10,80(r29)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r29.u32 + 80);
	// mr r5,r3
	ctx.r5.u64 = ctx.r3.u64;
	// mr r3,r23
	ctx.r3.u64 = ctx.r23.u64;
	// lwz r4,0(r30)
	ctx.r4.u64 = REX_LOAD_U32(ctx.r30.u32 + 0);
	// mr r6,r25
	ctx.r6.u64 = ctx.r25.u64;
	// stw r28,84(r1)
	REX_STORE_U32(ctx.r1.u32 + 84, ctx.r28.u32);
	// mr r7,r26
	ctx.r7.u64 = ctx.r26.u64;
	// addi r8,r31,56
	ctx.r8.s64 = ctx.r31.s64 + 56;
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// mr r9,r24
	ctx.r9.u64 = ctx.r24.u64;
	// mr r10,r27
	ctx.r10.u64 = ctx.r27.u64;
	// bctrl 
	ctx.lr = 0x8B099EB8;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// mr r30,r3
	ctx.r30.u64 = ctx.r3.u64;
	// cmplwi cr6,r3,997
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 997, ctx.xer);
	// beq cr6,0x8b099ee4
	if (ctx.cr6.eq) goto loc_8B099EE4;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// addi r3,r11,11448
	ctx.r3.s64 = ctx.r11.s64 + 11448;
	// bl 0x8b0df2e8
	ctx.lr = 0x8B099ED4;
	sub_8B0DF2E8(ctx, base);
	// li r10,3
	ctx.r10.s64 = 3;
	// clrldi r9,r30,32
	ctx.r9.u64 = ctx.r30.u64 & 0xFFFFFFFF;
	// stw r10,8(r31)
	REX_STORE_U32(ctx.r31.u32 + 8, ctx.r10.u32);
	// std r9,40(r31)
	REX_STORE_U64(ctx.r31.u32 + 40, ctx.r9.u64);
loc_8B099EE4:
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// addi r1,r1,176
	ctx.r1.s64 = ctx.r1.s64 + 176;
	// b 0x8b0cb9f4
	__restgprlr_23(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B09A1D8) {
	REX_FUNC_PROLOGUE();
	PPCRegister temp{};
	// lwz r11,200(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 200);
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// beq cr6,0x8b09a1f8
	if (ctx.cr6.eq) goto loc_8B09A1F8;
	// rotlwi r3,r11,0
	ctx.r3.u64 = __builtin_rotateleft32(ctx.r11.u32, 0);
	// lwz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r10,0(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 0);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctr 
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	return;
loc_8B09A1F8:
	// lwz r10,8(r3)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r3.u32 + 8);
	// li r11,2
	ctx.r11.s64 = 2;
	// srawi r9,r10,31
	ctx.xer.ca = (ctx.r10.s32 < 0) & ((ctx.r10.u32 & 0x7FFFFFFF) != 0);
	ctx.r9.s64 = ctx.r10.s32 >> 31;
	// rlwinm r8,r11,1,31,31
	ctx.r8.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 1) & 0x1;
	// subfc r7,r11,r10
	ctx.xer.ca = ctx.r10.u32 >= ctx.r11.u32;
	ctx.r7.u64 = ctx.r10.u64 - ctx.r11.u64;
	// adde r3,r8,r9
	temp.u8 = (ctx.r8.u32 + ctx.r9.u32 < ctx.r8.u32) | (ctx.r8.u32 + ctx.r9.u32 + ctx.xer.ca < ctx.xer.ca);
	ctx.r3.u64 = ctx.r8.u64 + ctx.r9.u64 + ctx.xer.ca;
	ctx.xer.ca = temp.u8;
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B09A330) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// std r31,-16(r1)
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.r31.u64);
	// stwu r1,-96(r1)
	ea = -96 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// clrlwi r11,r4,31
	ctx.r11.u64 = ctx.r4.u32 & 0x1;
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// beq cr6,0x8b09a358
	if (ctx.cr6.eq) goto loc_8B09A358;
	// bl 0x8b090020
	ctx.lr = 0x8B09A354;
	sub_8B090020(ctx, base);
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
loc_8B09A358:
	// addi r1,r1,96
	ctx.r1.s64 = ctx.r1.s64 + 96;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B09A638) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9bc
	ctx.lr = 0x8B09A640;
	__savegprlr_29(ctx, base);
	// stwu r1,-112(r1)
	ea = -112 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lwz r10,12(r3)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r3.u32 + 12);
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// lwz r11,4(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 4);
	// mr r30,r4
	ctx.r30.u64 = ctx.r4.u64;
	// addi r9,r10,1
	ctx.r9.s64 = ctx.r10.s64 + 1;
	// mr r29,r5
	ctx.r29.u64 = ctx.r5.u64;
	// cmpw cr6,r9,r11
	ctx.cr6.compare<int32_t>(ctx.r9.s32, ctx.r11.s32, ctx.xer);
	// ble cr6,0x8b09a670
	if (!ctx.cr6.gt) goto loc_8B09A670;
	// subf r11,r11,r10
	ctx.r11.u64 = ctx.r10.u64 - ctx.r11.u64;
	// addi r4,r11,1
	ctx.r4.s64 = ctx.r11.s64 + 1;
	// bl 0x8b099bf8
	ctx.lr = 0x8B09A670;
	sub_8B099BF8(ctx, base);
loc_8B09A670:
	// lwz r11,12(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 12);
	// addi r11,r11,1
	ctx.r11.s64 = ctx.r11.s64 + 1;
	// subf r10,r30,r11
	ctx.r10.u64 = ctx.r11.u64 - ctx.r30.u64;
	// stw r11,12(r31)
	REX_STORE_U32(ctx.r31.u32 + 12, ctx.r11.u32);
	// addic. r11,r10,-1
	ctx.xer.ca = ctx.r10.u32 > 0;
	ctx.r11.s64 = ctx.r10.s64 + -1;
	ctx.cr0.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// ble 0x8b09a6b0
	if (!ctx.cr0.gt) goto loc_8B09A6B0;
	// rlwinm r8,r30,1,0,30
	ctx.r8.u64 = __builtin_rotateleft64(ctx.r30.u32 | (ctx.r30.u64 << 32), 1) & 0xFFFFFFFE;
	// lwz r10,0(r31)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r31.u32 + 0);
	// rlwinm r9,r11,1,0,30
	ctx.r9.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 1) & 0xFFFFFFFE;
	// add r8,r30,r8
	ctx.r8.u64 = ctx.r30.u64 + ctx.r8.u64;
	// add r7,r11,r9
	ctx.r7.u64 = ctx.r11.u64 + ctx.r9.u64;
	// rlwinm r11,r8,2,0,29
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r8.u32 | (ctx.r8.u64 << 32), 2) & 0xFFFFFFFC;
	// rlwinm r5,r7,2,0,29
	ctx.r5.u64 = __builtin_rotateleft64(ctx.r7.u32 | (ctx.r7.u64 << 32), 2) & 0xFFFFFFFC;
	// add r4,r11,r10
	ctx.r4.u64 = ctx.r11.u64 + ctx.r10.u64;
	// addi r3,r4,12
	ctx.r3.s64 = ctx.r4.s64 + 12;
	// bl 0x8b0cc060
	ctx.lr = 0x8B09A6B0;
	sub_8B0CC060(ctx, base);
loc_8B09A6B0:
	// rlwinm r11,r30,1,0,30
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r30.u32 | (ctx.r30.u64 << 32), 1) & 0xFFFFFFFE;
	// lwz r10,0(r31)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r31.u32 + 0);
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// add r11,r30,r11
	ctx.r11.u64 = ctx.r30.u64 + ctx.r11.u64;
	// rlwinm r11,r11,2,0,29
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 2) & 0xFFFFFFFC;
	// add. r11,r11,r10
	ctx.r11.u64 = ctx.r11.u64 + ctx.r10.u64;
	ctx.cr0.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// beq 0x8b09a6e4
	if (ctx.cr0.eq) goto loc_8B09A6E4;
	// lwz r10,0(r29)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r29.u32 + 0);
	// stw r10,0(r11)
	REX_STORE_U32(ctx.r11.u32 + 0, ctx.r10.u32);
	// lwz r9,4(r29)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r29.u32 + 4);
	// stw r9,4(r11)
	REX_STORE_U32(ctx.r11.u32 + 4, ctx.r9.u32);
	// lwz r8,8(r29)
	ctx.r8.u64 = REX_LOAD_U32(ctx.r29.u32 + 8);
	// stw r8,8(r11)
	REX_STORE_U32(ctx.r11.u32 + 8, ctx.r8.u32);
loc_8B09A6E4:
	// addi r1,r1,112
	ctx.r1.s64 = ctx.r1.s64 + 112;
	// b 0x8b0cba0c
	__restgprlr_29(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B09AA30) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9b8
	ctx.lr = 0x8B09AA38;
	__savegprlr_28(ctx, base);
	// stwu r1,-272(r1)
	ea = -272 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// mr r28,r4
	ctx.r28.u64 = ctx.r4.u64;
	// cmplwi cr6,r4,0
	ctx.cr6.compare<uint32_t>(ctx.r4.u32, 0, ctx.xer);
	// beq cr6,0x8b09aba4
	if (ctx.cr6.eq) goto loc_8B09ABA4;
	// li r30,0
	ctx.r30.s64 = 0;
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// stw r30,0(r4)
	REX_STORE_U32(ctx.r4.u32 + 0, ctx.r30.u32);
	// beq cr6,0x8b09aba4
	if (ctx.cr6.eq) goto loc_8B09ABA4;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// li r5,0
	ctx.r5.s64 = 0;
	// addi r4,r11,11968
	ctx.r4.s64 = ctx.r11.s64 + 11968;
	// bl 0x8b0bfd30
	ctx.lr = 0x8B09AA6C;
	sub_8B0BFD30(ctx, base);
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// mr r29,r3
	ctx.r29.u64 = ctx.r3.u64;
	// std r3,80(r1)
	REX_STORE_U64(ctx.r1.u32 + 80, ctx.r3.u64);
	// addi r4,r10,11948
	ctx.r4.s64 = ctx.r10.s64 + 11948;
	// li r5,0
	ctx.r5.s64 = 0;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0c1588
	ctx.lr = 0x8B09AA88;
	sub_8B0C1588(ctx, base);
	// li r10,7
	ctx.r10.s64 = 7;
	// addi r11,r1,160
	ctx.r11.s64 = ctx.r1.s64 + 160;
	// stb r30,160(r1)
	REX_STORE_U8(ctx.r1.u32 + 160, ctx.r30.u8);
	// mr r5,r3
	ctx.r5.u64 = ctx.r3.u64;
	// mr r9,r30
	ctx.r9.u64 = ctx.r30.u64;
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
loc_8B09AAA0:
	// stbu r9,1(r11)
	ea = 1 + ctx.r11.u32;
	REX_STORE_U8(ea, ctx.r9.u8);
	ctx.r11.u32 = ea;
	// bdnz 0x8b09aaa0
	--ctx.ctr.u64;
	if (ctx.ctr.u32 != 0) goto loc_8B09AAA0;
	// li r9,6
	ctx.r9.s64 = 6;
	// addi r11,r1,160
	ctx.r11.s64 = ctx.r1.s64 + 160;
	// mr r10,r30
	ctx.r10.u64 = ctx.r30.u64;
	// mtctr r9
	ctx.ctr.u64 = ctx.r9.u64;
loc_8B09AAB8:
	// stdu r10,8(r11)
	ea = 8 + ctx.r11.u32;
	REX_STORE_U64(ea, ctx.r10.u64);
	ctx.r11.u32 = ea;
	// bdnz 0x8b09aab8
	--ctx.ctr.u64;
	if (ctx.ctr.u32 != 0) goto loc_8B09AAB8;
	// stw r10,8(r11)
	REX_STORE_U32(ctx.r11.u32 + 8, ctx.r10.u32);
	// cmplwi cr6,r5,0
	ctx.cr6.compare<uint32_t>(ctx.r5.u32, 0, ctx.xer);
	// beq cr6,0x8b09aad8
	if (ctx.cr6.eq) goto loc_8B09AAD8;
	// li r4,60
	ctx.r4.s64 = 60;
	// addi r3,r1,160
	ctx.r3.s64 = ctx.r1.s64 + 160;
	// bl 0x8b099448
	ctx.lr = 0x8B09AAD8;
	sub_8B099448(ctx, base);
loc_8B09AAD8:
	// li r6,1
	ctx.r6.s64 = 1;
	// li r5,0
	ctx.r5.s64 = 0;
	// mr r4,r31
	ctx.r4.u64 = ctx.r31.u64;
	// addi r3,r1,128
	ctx.r3.s64 = ctx.r1.s64 + 128;
	// bl 0x8b0996e8
	ctx.lr = 0x8B09AAEC;
	sub_8B0996E8(ctx, base);
	// li r9,5
	ctx.r9.s64 = 5;
	// addi r10,r1,92
	ctx.r10.s64 = ctx.r1.s64 + 92;
	// addi r11,r3,-4
	ctx.r11.s64 = ctx.r3.s64 + -4;
	// mtctr r9
	ctx.ctr.u64 = ctx.r9.u64;
loc_8B09AAFC:
	// lwzu r9,4(r11)
	ea = 4 + ctx.r11.u32;
	ctx.r9.u64 = REX_LOAD_U32(ea);
	ctx.r11.u32 = ea;
	// stwu r9,4(r10)
	ea = 4 + ctx.r10.u32;
	REX_STORE_U32(ea, ctx.r9.u32);
	ctx.r10.u32 = ea;
	// bdnz 0x8b09aafc
	--ctx.ctr.u64;
	if (ctx.ctr.u32 != 0) goto loc_8B09AAFC;
	// lis r11,-29938
	ctx.r11.s64 = -1962016768;
	// lwz r3,3036(r11)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r11.u32 + 3036);
	// lwz r10,0(r3)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r9,64(r10)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r10.u32 + 64);
	// mtctr r9
	ctx.ctr.u64 = ctx.r9.u64;
	// bctrl 
	ctx.lr = 0x8B09AB20;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// lwz r8,0(r3)
	ctx.r8.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// mr r4,r31
	ctx.r4.u64 = ctx.r31.u64;
	// lwz r7,32(r8)
	ctx.r7.u64 = REX_LOAD_U32(ctx.r8.u32 + 32);
	// mtctr r7
	ctx.ctr.u64 = ctx.r7.u64;
	// bctrl 
	ctx.lr = 0x8B09AB34;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b09ab40
	if (ctx.cr6.eq) goto loc_8B09AB40;
	// bl 0x8b0c04f0
	ctx.lr = 0x8B09AB40;
	sub_8B0C04F0(ctx, base);
loc_8B09AB40:
	// ld r11,160(r1)
	ctx.r11.u64 = REX_LOAD_U64(ctx.r1.u32 + 160);
	// cmpld cr6,r11,r29
	ctx.cr6.compare<uint64_t>(ctx.r11.u64, ctx.r29.u64, ctx.xer);
	// beq cr6,0x8b09ab74
	if (ctx.cr6.eq) goto loc_8B09AB74;
	// li r3,280
	ctx.r3.s64 = 280;
	// bl 0x8b090000
	ctx.lr = 0x8B09AB54;
	sub_8B090000(ctx, base);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b09ab9c
	if (ctx.cr6.eq) goto loc_8B09AB9C;
	// addi r5,r1,80
	ctx.r5.s64 = ctx.r1.s64 + 80;
	// addi r4,r1,96
	ctx.r4.s64 = ctx.r1.s64 + 96;
	// bl 0x8b09a788
	ctx.lr = 0x8B09AB68;
	sub_8B09A788(ctx, base);
	// stw r3,0(r28)
	REX_STORE_U32(ctx.r28.u32 + 0, ctx.r3.u32);
	// addi r1,r1,272
	ctx.r1.s64 = ctx.r1.s64 + 272;
	// b 0x8b0cba08
	__restgprlr_28(ctx, base);
	return;
loc_8B09AB74:
	// li r3,200
	ctx.r3.s64 = 200;
	// bl 0x8b090000
	ctx.lr = 0x8B09AB7C;
	sub_8B090000(ctx, base);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b09ab9c
	if (ctx.cr6.eq) goto loc_8B09AB9C;
	// addi r5,r1,160
	ctx.r5.s64 = ctx.r1.s64 + 160;
	// addi r4,r1,96
	ctx.r4.s64 = ctx.r1.s64 + 96;
	// bl 0x8b09a040
	ctx.lr = 0x8B09AB90;
	sub_8B09A040(ctx, base);
	// stw r3,0(r28)
	REX_STORE_U32(ctx.r28.u32 + 0, ctx.r3.u32);
	// addi r1,r1,272
	ctx.r1.s64 = ctx.r1.s64 + 272;
	// b 0x8b0cba08
	__restgprlr_28(ctx, base);
	return;
loc_8B09AB9C:
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// stw r30,0(r28)
	REX_STORE_U32(ctx.r28.u32 + 0, ctx.r30.u32);
loc_8B09ABA4:
	// addi r1,r1,272
	ctx.r1.s64 = ctx.r1.s64 + 272;
	// b 0x8b0cba08
	__restgprlr_28(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B09B0A0) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9b0
	ctx.lr = 0x8B09B0A8;
	__savegprlr_26(ctx, base);
	// stwu r1,-144(r1)
	ea = -144 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lbz r11,16(r3)
	ctx.r11.u64 = REX_LOAD_U8(ctx.r3.u32 + 16);
	// mr r28,r3
	ctx.r28.u64 = ctx.r3.u64;
	// mr r31,r4
	ctx.r31.u64 = ctx.r4.u64;
	// rlwinm r11,r11,0,0,26
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 0) & 0xFFFFFFE0;
	// addi r29,r3,16
	ctx.r29.s64 = ctx.r3.s64 + 16;
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// beq cr6,0x8b09b184
	if (ctx.cr6.eq) goto loc_8B09B184;
	// cmplwi cr6,r11,64
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 64, ctx.xer);
	// beq cr6,0x8b09b184
	if (ctx.cr6.eq) goto loc_8B09B184;
	// li r3,64
	ctx.r3.s64 = 64;
	// bl 0x8b090000
	ctx.lr = 0x8B09B0D8;
	sub_8B090000(ctx, base);
	// stw r31,0(r3)
	REX_STORE_U32(ctx.r3.u32 + 0, ctx.r31.u32);
	// mr r4,r29
	ctx.r4.u64 = ctx.r29.u64;
	// addi r29,r3,4
	ctx.r29.s64 = ctx.r3.s64 + 4;
	// mr r30,r3
	ctx.r30.u64 = ctx.r3.u64;
	// li r5,60
	ctx.r5.s64 = 60;
	// mr r3,r29
	ctx.r3.u64 = ctx.r29.u64;
	// bl 0x8b0cbb30
	ctx.lr = 0x8B09B0F4;
	sub_8B0CBB30(ctx, base);
	// cmplwi cr6,r31,0
	ctx.cr6.compare<uint32_t>(ctx.r31.u32, 0, ctx.xer);
	// beq cr6,0x8b09b110
	if (ctx.cr6.eq) goto loc_8B09B110;
	// li r11,0
	ctx.r11.s64 = 0;
	// stw r28,0(r31)
	REX_STORE_U32(ctx.r31.u32 + 0, ctx.r28.u32);
	// li r10,997
	ctx.r10.s64 = 997;
	// stb r11,8(r31)
	REX_STORE_U8(ctx.r31.u32 + 8, ctx.r11.u8);
	// stw r10,4(r31)
	REX_STORE_U32(ctx.r31.u32 + 4, ctx.r10.u32);
loc_8B09B110:
	// lis r11,-29938
	ctx.r11.s64 = -1962016768;
	// lis r10,-29942
	ctx.r10.s64 = -1962278912;
	// mr r4,r30
	ctx.r4.u64 = ctx.r30.u64;
	// addi r3,r10,-26360
	ctx.r3.s64 = ctx.r10.s64 + -26360;
	// lwz r11,2364(r11)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r11.u32 + 2364);
	// lwz r27,104(r11)
	ctx.r27.u64 = REX_LOAD_U32(ctx.r11.u32 + 104);
	// lwz r31,0(r27)
	ctx.r31.u64 = REX_LOAD_U32(ctx.r27.u32 + 0);
	// bl 0x8b09abd8
	ctx.lr = 0x8B09B130;
	sub_8B09ABD8(ctx, base);
	// mr r26,r3
	ctx.r26.u64 = ctx.r3.u64;
	// bl 0x8b0df318
	ctx.lr = 0x8B09B138;
	sub_8B0DF318(ctx, base);
	// lwz r9,88(r31)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r31.u32 + 88);
	// mr r5,r3
	ctx.r5.u64 = ctx.r3.u64;
	// mr r3,r27
	ctx.r3.u64 = ctx.r27.u64;
	// lwz r4,0(r28)
	ctx.r4.u64 = REX_LOAD_U32(ctx.r28.u32 + 0);
	// mr r6,r29
	ctx.r6.u64 = ctx.r29.u64;
	// mr r7,r26
	ctx.r7.u64 = ctx.r26.u64;
	// mtctr r9
	ctx.ctr.u64 = ctx.r9.u64;
	// bctrl 
	ctx.lr = 0x8B09B158;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b09b178
	if (ctx.cr6.eq) goto loc_8B09B178;
	// cmplwi cr6,r3,997
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 997, ctx.xer);
	// beq cr6,0x8b09b178
	if (ctx.cr6.eq) goto loc_8B09B178;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// addi r3,r11,12212
	ctx.r3.s64 = ctx.r11.s64 + 12212;
	// bl 0x8b0df2e8
	ctx.lr = 0x8B09B178;
	sub_8B0DF2E8(ctx, base);
loc_8B09B178:
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// addi r1,r1,144
	ctx.r1.s64 = ctx.r1.s64 + 144;
	// b 0x8b0cba00
	__restgprlr_26(ctx, base);
	return;
loc_8B09B184:
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// addi r3,r11,12136
	ctx.r3.s64 = ctx.r11.s64 + 12136;
	// bl 0x8b0df2e8
	ctx.lr = 0x8B09B190;
	sub_8B0DF2E8(ctx, base);
	// li r3,0
	ctx.r3.s64 = 0;
	// addi r1,r1,144
	ctx.r1.s64 = ctx.r1.s64 + 144;
	// b 0x8b0cba00
	__restgprlr_26(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B09B4B0) {
	REX_FUNC_PROLOGUE();
	// lis r11,-29942
	ctx.r11.s64 = -1962278912;
	// mr r7,r6
	ctx.r7.u64 = ctx.r6.u64;
	// mr r6,r5
	ctx.r6.u64 = ctx.r5.u64;
	// addi r5,r11,-19816
	ctx.r5.s64 = ctx.r11.s64 + -19816;
	// b 0x8b0999e8
	sub_8B0999E8(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B09B4E0) {
	REX_FUNC_PROLOGUE();
	PPCRegister temp{};
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9b0
	ctx.lr = 0x8B09B4E8;
	__savegprlr_26(ctx, base);
	// stwu r1,-160(r1)
	ea = -160 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lbz r11,140(r3)
	ctx.r11.u64 = REX_LOAD_U8(ctx.r3.u32 + 140);
	// clrlwi r26,r4,24
	ctx.r26.u64 = ctx.r4.u32 & 0xFF;
	// mr r28,r3
	ctx.r28.u64 = ctx.r3.u64;
	// mr r27,r4
	ctx.r27.u64 = ctx.r4.u64;
	// mr r30,r5
	ctx.r30.u64 = ctx.r5.u64;
	// cmplw cr6,r26,r11
	ctx.cr6.compare<uint32_t>(ctx.r26.u32, ctx.r11.u32, ctx.xer);
	// bne cr6,0x8b09b550
	if (!ctx.cr6.eq) goto loc_8B09B550;
	// cmplwi cr6,r26,0
	ctx.cr6.compare<uint32_t>(ctx.r26.u32, 0, ctx.xer);
	// beq cr6,0x8b09b530
	if (ctx.cr6.eq) goto loc_8B09B530;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// addi r4,r11,12628
	ctx.r4.s64 = ctx.r11.s64 + 12628;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// addi r3,r11,12560
	ctx.r3.s64 = ctx.r11.s64 + 12560;
	// bl 0x8b0df2e8
	ctx.lr = 0x8B09B524;
	sub_8B0DF2E8(ctx, base);
	// li r3,0
	ctx.r3.s64 = 0;
	// addi r1,r1,160
	ctx.r1.s64 = ctx.r1.s64 + 160;
	// b 0x8b0cba00
	__restgprlr_26(ctx, base);
	return;
loc_8B09B530:
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// addi r4,r11,12548
	ctx.r4.s64 = ctx.r11.s64 + 12548;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// addi r3,r11,12560
	ctx.r3.s64 = ctx.r11.s64 + 12560;
	// bl 0x8b0df2e8
	ctx.lr = 0x8B09B544;
	sub_8B0DF2E8(ctx, base);
	// li r3,0
	ctx.r3.s64 = 0;
	// addi r1,r1,160
	ctx.r1.s64 = ctx.r1.s64 + 160;
	// b 0x8b0cba00
	__restgprlr_26(ctx, base);
	return;
loc_8B09B550:
	// cmplwi cr6,r26,0
	ctx.cr6.compare<uint32_t>(ctx.r26.u32, 0, ctx.xer);
	// li r3,36
	ctx.r3.s64 = 36;
	// beq cr6,0x8b09b654
	if (ctx.cr6.eq) goto loc_8B09B654;
	// bl 0x8b0bf448
	ctx.lr = 0x8B09B560;
	sub_8B0BF448(ctx, base);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b09b58c
	if (ctx.cr6.eq) goto loc_8B09B58C;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// lis r9,-29944
	ctx.r9.s64 = -1962409984;
	// addi r6,r11,9024
	ctx.r6.s64 = ctx.r11.s64 + 9024;
	// addi r5,r10,4500
	ctx.r5.s64 = ctx.r10.s64 + 4500;
	// addi r4,r9,4472
	ctx.r4.s64 = ctx.r9.s64 + 4472;
	// bl 0x8b0c1300
	ctx.lr = 0x8B09B584;
	sub_8B0C1300(ctx, base);
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// b 0x8b09b590
	goto loc_8B09B590;
loc_8B09B58C:
	// li r31,0
	ctx.r31.s64 = 0;
loc_8B09B590:
	// lis r11,-29936
	ctx.r11.s64 = -1961885696;
	// lwz r3,-17796(r11)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r11.u32 + -17796);
	// lwz r10,0(r3)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r9,28(r10)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r10.u32 + 28);
	// mtctr r9
	ctx.ctr.u64 = ctx.r9.u64;
	// bctrl 
	ctx.lr = 0x8B09B5A8;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// lwz r8,0(r3)
	ctx.r8.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// mr r4,r31
	ctx.r4.u64 = ctx.r31.u64;
	// lwz r7,8(r8)
	ctx.r7.u64 = REX_LOAD_U32(ctx.r8.u32 + 8);
	// mtctr r7
	ctx.ctr.u64 = ctx.r7.u64;
	// bctrl 
	ctx.lr = 0x8B09B5BC;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// lis r6,-29938
	ctx.r6.s64 = -1962016768;
	// li r4,0
	ctx.r4.s64 = 0;
	// li r3,0
	ctx.r3.s64 = 0;
	// lwz r11,2364(r6)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r6.u32 + 2364);
	// lwz r29,104(r11)
	ctx.r29.u64 = REX_LOAD_U32(ctx.r11.u32 + 104);
	// lwz r31,0(r29)
	ctx.r31.u64 = REX_LOAD_U32(ctx.r29.u32 + 0);
	// bl 0x8b09abd8
	ctx.lr = 0x8B09B5D8;
	sub_8B09ABD8(ctx, base);
	// lwz r11,112(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 112);
	// mr r6,r3
	ctx.r6.u64 = ctx.r3.u64;
	// li r5,0
	ctx.r5.s64 = 0;
	// lwz r4,0(r28)
	ctx.r4.u64 = REX_LOAD_U32(ctx.r28.u32 + 0);
	// mr r3,r29
	ctx.r3.u64 = ctx.r29.u64;
	// mtctr r11
	ctx.ctr.u64 = ctx.r11.u64;
	// bctrl 
	ctx.lr = 0x8B09B5F4;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// mr r29,r3
	ctx.r29.u64 = ctx.r3.u64;
	// cmplwi cr6,r30,0
	ctx.cr6.compare<uint32_t>(ctx.r30.u32, 0, ctx.xer);
	// beq cr6,0x8b09b764
	if (ctx.cr6.eq) goto loc_8B09B764;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// addi r4,r11,12532
	ctx.r4.s64 = ctx.r11.s64 + 12532;
	// bl 0x8b0c3c50
	ctx.lr = 0x8B09B610;
	sub_8B0C3C50(ctx, base);
	// mr r5,r3
	ctx.r5.u64 = ctx.r3.u64;
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b09b62c
	if (ctx.cr6.eq) goto loc_8B09B62C;
	// li r4,60
	ctx.r4.s64 = 60;
	// addi r3,r28,80
	ctx.r3.s64 = ctx.r28.s64 + 80;
	// bl 0x8b099448
	ctx.lr = 0x8B09B628;
	sub_8B099448(ctx, base);
	// b 0x8b09b764
	goto loc_8B09B764;
loc_8B09B62C:
	// addi r3,r1,80
	ctx.r3.s64 = ctx.r1.s64 + 80;
	// bl 0x8b0925c0
	ctx.lr = 0x8B09B634;
	sub_8B0925C0(ctx, base);
	// li r5,0
	ctx.r5.s64 = 0;
	// mr r4,r30
	ctx.r4.u64 = ctx.r30.u64;
	// addi r3,r1,80
	ctx.r3.s64 = ctx.r1.s64 + 80;
	// bl 0x8b0c72d8
	ctx.lr = 0x8B09B644;
	sub_8B0C72D8(ctx, base);
	// addi r3,r1,80
	ctx.r3.s64 = ctx.r1.s64 + 80;
	// bl 0x8b0c72c8
	ctx.lr = 0x8B09B64C;
	sub_8B0C72C8(ctx, base);
	// stw r3,76(r28)
	REX_STORE_U32(ctx.r28.u32 + 76, ctx.r3.u32);
	// b 0x8b09b764
	goto loc_8B09B764;
loc_8B09B654:
	// bl 0x8b0bf448
	ctx.lr = 0x8B09B658;
	sub_8B0BF448(ctx, base);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b09b684
	if (ctx.cr6.eq) goto loc_8B09B684;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// lis r9,-29944
	ctx.r9.s64 = -1962409984;
	// addi r6,r11,9012
	ctx.r6.s64 = ctx.r11.s64 + 9012;
	// addi r5,r10,4500
	ctx.r5.s64 = ctx.r10.s64 + 4500;
	// addi r4,r9,4472
	ctx.r4.s64 = ctx.r9.s64 + 4472;
	// bl 0x8b0c1300
	ctx.lr = 0x8B09B67C;
	sub_8B0C1300(ctx, base);
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// b 0x8b09b688
	goto loc_8B09B688;
loc_8B09B684:
	// li r31,0
	ctx.r31.s64 = 0;
loc_8B09B688:
	// lis r11,-29936
	ctx.r11.s64 = -1961885696;
	// lwz r3,-17796(r11)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r11.u32 + -17796);
	// lwz r10,0(r3)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r9,28(r10)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r10.u32 + 28);
	// mtctr r9
	ctx.ctr.u64 = ctx.r9.u64;
	// bctrl 
	ctx.lr = 0x8B09B6A0;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// lwz r8,0(r3)
	ctx.r8.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// mr r4,r31
	ctx.r4.u64 = ctx.r31.u64;
	// lwz r7,8(r8)
	ctx.r7.u64 = REX_LOAD_U32(ctx.r8.u32 + 8);
	// mtctr r7
	ctx.ctr.u64 = ctx.r7.u64;
	// bctrl 
	ctx.lr = 0x8B09B6B4;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// lis r31,-29938
	ctx.r31.s64 = -1962016768;
	// li r4,0
	ctx.r4.s64 = 0;
	// li r3,0
	ctx.r3.s64 = 0;
	// lwz r11,2364(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 2364);
	// lwz r29,104(r11)
	ctx.r29.u64 = REX_LOAD_U32(ctx.r11.u32 + 104);
	// lwz r30,0(r29)
	ctx.r30.u64 = REX_LOAD_U32(ctx.r29.u32 + 0);
	// bl 0x8b09abd8
	ctx.lr = 0x8B09B6D0;
	sub_8B09ABD8(ctx, base);
	// lwz r6,108(r30)
	ctx.r6.u64 = REX_LOAD_U32(ctx.r30.u32 + 108);
	// mr r5,r3
	ctx.r5.u64 = ctx.r3.u64;
	// mr r3,r29
	ctx.r3.u64 = ctx.r29.u64;
	// lwz r4,0(r28)
	ctx.r4.u64 = REX_LOAD_U32(ctx.r28.u32 + 0);
	// mtctr r6
	ctx.ctr.u64 = ctx.r6.u64;
	// bctrl 
	ctx.lr = 0x8B09B6E8;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// lwz r5,76(r28)
	ctx.r5.u64 = REX_LOAD_U32(ctx.r28.u32 + 76);
	// mr r29,r3
	ctx.r29.u64 = ctx.r3.u64;
	// cmplwi cr6,r5,0
	ctx.cr6.compare<uint32_t>(ctx.r5.u32, 0, ctx.xer);
	// beq cr6,0x8b09b71c
	if (ctx.cr6.eq) goto loc_8B09B71C;
	// lwz r11,2364(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 2364);
	// rotlwi r4,r5,0
	ctx.r4.u64 = __builtin_rotateleft32(ctx.r5.u32, 0);
	// lwz r3,104(r11)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r11.u32 + 104);
	// lwz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r10,32(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 32);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B09B714;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// li r9,0
	ctx.r9.s64 = 0;
	// stw r9,76(r28)
	REX_STORE_U32(ctx.r28.u32 + 76, ctx.r9.u32);
loc_8B09B71C:
	// ld r11,80(r28)
	ctx.r11.u64 = REX_LOAD_U64(ctx.r28.u32 + 80);
	// addi r30,r28,80
	ctx.r30.s64 = ctx.r28.s64 + 80;
	// cmpldi cr6,r11,0
	ctx.cr6.compare<uint64_t>(ctx.r11.u64, 0, ctx.xer);
	// beq cr6,0x8b09b764
	if (ctx.cr6.eq) goto loc_8B09B764;
	// lwz r11,2364(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 2364);
	// mr r4,r30
	ctx.r4.u64 = ctx.r30.u64;
	// lwz r3,104(r11)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r11.u32 + 104);
	// lwz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r10,64(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 64);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B09B748;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// li r10,7
	ctx.r10.s64 = 7;
	// addi r11,r30,-8
	ctx.r11.s64 = ctx.r30.s64 + -8;
	// li r9,0
	ctx.r9.s64 = 0;
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
loc_8B09B758:
	// stdu r9,8(r11)
	ea = 8 + ctx.r11.u32;
	REX_STORE_U64(ea, ctx.r9.u64);
	ctx.r11.u32 = ea;
	// bdnz 0x8b09b758
	--ctx.ctr.u64;
	if (ctx.ctr.u32 != 0) goto loc_8B09B758;
	// stw r9,8(r11)
	REX_STORE_U32(ctx.r11.u32 + 8, ctx.r9.u32);
loc_8B09B764:
	// cmplwi cr6,r29,0
	ctx.cr6.compare<uint32_t>(ctx.r29.u32, 0, ctx.xer);
	// beq cr6,0x8b09b7ac
	if (ctx.cr6.eq) goto loc_8B09B7AC;
	// cmplwi cr6,r29,997
	ctx.cr6.compare<uint32_t>(ctx.r29.u32, 997, ctx.xer);
	// beq cr6,0x8b09b7ac
	if (ctx.cr6.eq) goto loc_8B09B7AC;
	// cmplwi cr6,r26,0
	ctx.cr6.compare<uint32_t>(ctx.r26.u32, 0, ctx.xer);
	// beq cr6,0x8b09b788
	if (ctx.cr6.eq) goto loc_8B09B788;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// addi r4,r11,12628
	ctx.r4.s64 = ctx.r11.s64 + 12628;
	// b 0x8b09b790
	goto loc_8B09B790;
loc_8B09B788:
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// addi r4,r11,12548
	ctx.r4.s64 = ctx.r11.s64 + 12548;
loc_8B09B790:
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// mr r5,r29
	ctx.r5.u64 = ctx.r29.u64;
	// addi r3,r11,12464
	ctx.r3.s64 = ctx.r11.s64 + 12464;
	// bl 0x8b0df2e8
	ctx.lr = 0x8B09B7A0;
	sub_8B0DF2E8(ctx, base);
	// li r3,0
	ctx.r3.s64 = 0;
	// addi r1,r1,160
	ctx.r1.s64 = ctx.r1.s64 + 160;
	// b 0x8b0cba00
	__restgprlr_26(ctx, base);
	return;
loc_8B09B7AC:
	// stb r27,140(r28)
	REX_STORE_U8(ctx.r28.u32 + 140, ctx.r27.u8);
	// lwz r27,0(r28)
	ctx.r27.u64 = REX_LOAD_U32(ctx.r28.u32 + 0);
	// stw r27,80(r1)
	REX_STORE_U32(ctx.r1.u32 + 80, ctx.r27.u32);
	// bl 0x8b0df2f8
	ctx.lr = 0x8B09B7BC;
	sub_8B0DF2F8(ctx, base);
	// lis r11,-29938
	ctx.r11.s64 = -1962016768;
	// li r10,0
	ctx.r10.s64 = 0;
	// frsp f0,f1
	ctx.fpscr.disableFlushMode();
	ctx.f0.f64 = double(float(ctx.f1.f64));
	// addi r31,r11,18576
	ctx.r31.s64 = ctx.r11.s64 + 18576;
	// stfs f0,84(r1)
	temp.f32 = float(ctx.f0.f64);
	REX_STORE_U32(ctx.r1.u32 + 84, temp.u32);
	// stb r10,88(r1)
	REX_STORE_U8(ctx.r1.u32 + 88, ctx.r10.u8);
	// li r30,0
	ctx.r30.s64 = 0;
	// lwz r4,12(r31)
	ctx.r4.u64 = REX_LOAD_U32(ctx.r31.u32 + 12);
	// cmpwi cr6,r4,0
	ctx.cr6.compare<int32_t>(ctx.r4.s32, 0, ctx.xer);
	// ble cr6,0x8b09b840
	if (!ctx.cr6.gt) goto loc_8B09B840;
	// li r29,0
	ctx.r29.s64 = 0;
loc_8B09B7E8:
	// lwz r11,0(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 0);
	// add r3,r29,r11
	ctx.r3.u64 = ctx.r29.u64 + ctx.r11.u64;
	// lwzx r11,r29,r11
	ctx.r11.u64 = REX_LOAD_U32(ctx.r29.u32 + ctx.r11.u32);
	// cmplw cr6,r11,r27
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, ctx.r27.u32, ctx.xer);
	// bne cr6,0x8b09b830
	if (!ctx.cr6.eq) goto loc_8B09B830;
	// subf r11,r30,r4
	ctx.r11.u64 = ctx.r4.u64 - ctx.r30.u64;
	// addic. r11,r11,-1
	ctx.xer.ca = ctx.r11.u32 > 0;
	ctx.r11.s64 = ctx.r11.s64 + -1;
	ctx.cr0.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// ble 0x8b09b820
	if (!ctx.cr0.gt) goto loc_8B09B820;
	// rlwinm r10,r11,1,0,30
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 1) & 0xFFFFFFFE;
	// addi r4,r3,12
	ctx.r4.s64 = ctx.r3.s64 + 12;
	// add r11,r11,r10
	ctx.r11.u64 = ctx.r11.u64 + ctx.r10.u64;
	// rlwinm r5,r11,2,0,29
	ctx.r5.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 2) & 0xFFFFFFFC;
	// bl 0x8b0cc060
	ctx.lr = 0x8B09B81C;
	sub_8B0CC060(ctx, base);
	// lwz r4,12(r31)
	ctx.r4.u64 = REX_LOAD_U32(ctx.r31.u32 + 12);
loc_8B09B820:
	// addi r4,r4,-1
	ctx.r4.s64 = ctx.r4.s64 + -1;
	// addi r30,r30,-1
	ctx.r30.s64 = ctx.r30.s64 + -1;
	// stw r4,12(r31)
	REX_STORE_U32(ctx.r31.u32 + 12, ctx.r4.u32);
	// addi r29,r29,-12
	ctx.r29.s64 = ctx.r29.s64 + -12;
loc_8B09B830:
	// addi r30,r30,1
	ctx.r30.s64 = ctx.r30.s64 + 1;
	// addi r29,r29,12
	ctx.r29.s64 = ctx.r29.s64 + 12;
	// cmpw cr6,r30,r4
	ctx.cr6.compare<int32_t>(ctx.r30.s32, ctx.r4.s32, ctx.xer);
	// blt cr6,0x8b09b7e8
	if (ctx.cr6.lt) goto loc_8B09B7E8;
loc_8B09B840:
	// lbz r11,140(r28)
	ctx.r11.u64 = REX_LOAD_U8(ctx.r28.u32 + 140);
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// beq cr6,0x8b09b858
	if (ctx.cr6.eq) goto loc_8B09B858;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// addi r5,r1,80
	ctx.r5.s64 = ctx.r1.s64 + 80;
	// bl 0x8b09a638
	ctx.lr = 0x8B09B858;
	sub_8B09A638(ctx, base);
loc_8B09B858:
	// li r3,1
	ctx.r3.s64 = 1;
	// addi r1,r1,160
	ctx.r1.s64 = ctx.r1.s64 + 160;
	// b 0x8b0cba00
	__restgprlr_26(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B09CF20) {
	REX_FUNC_PROLOGUE();
	// ld r3,8(r3)
	ctx.r3.u64 = REX_LOAD_U64(ctx.r3.u32 + 8);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B09CF28) {
	REX_FUNC_PROLOGUE();
	// lwz r3,16(r3)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r3.u32 + 16);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B09CF30) {
	REX_FUNC_PROLOGUE();
	// addi r3,r3,24
	ctx.r3.s64 = ctx.r3.s64 + 24;
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B09CF38) {
	REX_FUNC_PROLOGUE();
	// lwz r3,20(r3)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r3.u32 + 20);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B09CF40) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// std r31,-16(r1)
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.r31.u64);
	// stwu r1,-96(r1)
	ea = -96 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// clrlwi r10,r4,31
	ctx.r10.u64 = ctx.r4.u32 & 0x1;
	// addi r9,r11,14616
	ctx.r9.s64 = ctx.r11.s64 + 14616;
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// cmplwi cr6,r10,0
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 0, ctx.xer);
	// stw r9,0(r3)
	REX_STORE_U32(ctx.r3.u32 + 0, ctx.r9.u32);
	// beq cr6,0x8b09cf74
	if (ctx.cr6.eq) goto loc_8B09CF74;
	// bl 0x8b090020
	ctx.lr = 0x8B09CF70;
	sub_8B090020(ctx, base);
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
loc_8B09CF74:
	// addi r1,r1,96
	ctx.r1.s64 = ctx.r1.s64 + 96;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B09CFD0) {
	REX_FUNC_PROLOGUE();
	PPCRegister temp{};
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9b4
	ctx.lr = 0x8B09CFD8;
	__savegprlr_27(ctx, base);
	// stwu r1,-128(r1)
	ea = -128 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// bne cr6,0x8b09cffc
	if (!ctx.cr6.eq) goto loc_8B09CFFC;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// addi r3,r11,14744
	ctx.r3.s64 = ctx.r11.s64 + 14744;
	// bl 0x8b0df2a8
	ctx.lr = 0x8B09CFF4;
	sub_8B0DF2A8(ctx, base);
	// addi r1,r1,128
	ctx.r1.s64 = ctx.r1.s64 + 128;
	// b 0x8b0cba04
	__restgprlr_27(ctx, base);
	return;
loc_8B09CFFC:
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// mr r4,r31
	ctx.r4.u64 = ctx.r31.u64;
	// addi r3,r11,14712
	ctx.r3.s64 = ctx.r11.s64 + 14712;
	// bl 0x8b0df3b8
	ctx.lr = 0x8B09D00C;
	sub_8B0DF3B8(ctx, base);
	// cmpwi cr6,r31,1
	ctx.cr6.compare<int32_t>(ctx.r31.s32, 1, ctx.xer);
	// bne cr6,0x8b09d084
	if (!ctx.cr6.eq) goto loc_8B09D084;
	// lis r11,-29938
	ctx.r11.s64 = -1962016768;
	// lis r10,-29938
	ctx.r10.s64 = -1962016768;
	// li r27,0
	ctx.r27.s64 = 0;
	// lis r28,-29938
	ctx.r28.s64 = -1962016768;
	// addi r30,r11,4224
	ctx.r30.s64 = ctx.r11.s64 + 4224;
	// addi r29,r10,4252
	ctx.r29.s64 = ctx.r10.s64 + 4252;
loc_8B09D02C:
	// lwz r3,2548(r28)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r28.u32 + 2548);
	// mr r4,r27
	ctx.r4.u64 = ctx.r27.u64;
	// lwz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r10,4(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 4);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B09D044;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// mr r6,r29
	ctx.r6.u64 = ctx.r29.u64;
	// mr r5,r30
	ctx.r5.u64 = ctx.r30.u64;
	// li r7,0
	ctx.r7.s64 = 0;
	// li r4,0
	ctx.r4.s64 = 0;
	// bl 0x8b0ccd08
	ctx.lr = 0x8B09D058;
	sub_8B0CCD08(ctx, base);
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b09d070
	if (ctx.cr6.eq) goto loc_8B09D070;
	// bl 0x8b0df2f8
	ctx.lr = 0x8B09D068;
	sub_8B0DF2F8(ctx, base);
	// frsp f0,f1
	ctx.fpscr.disableFlushMode();
	ctx.f0.f64 = double(float(ctx.f1.f64));
	// stfs f0,60(r31)
	temp.f32 = float(ctx.f0.f64);
	REX_STORE_U32(ctx.r31.u32 + 60, temp.u32);
loc_8B09D070:
	// addi r27,r27,1
	ctx.r27.s64 = ctx.r27.s64 + 1;
	// cmpwi cr6,r27,4
	ctx.cr6.compare<int32_t>(ctx.r27.s32, 4, ctx.xer);
	// blt cr6,0x8b09d02c
	if (ctx.cr6.lt) goto loc_8B09D02C;
	// addi r1,r1,128
	ctx.r1.s64 = ctx.r1.s64 + 128;
	// b 0x8b0cba04
	__restgprlr_27(ctx, base);
	return;
loc_8B09D084:
	// li r10,4
	ctx.r10.s64 = 4;
	// lis r11,-29938
	ctx.r11.s64 = -1962016768;
	// addi r11,r11,18624
	ctx.r11.s64 = ctx.r11.s64 + 18624;
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
loc_8B09D094:
	// lwz r10,0(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 0);
	// cmpw cr6,r10,r31
	ctx.cr6.compare<int32_t>(ctx.r10.s32, ctx.r31.s32, ctx.xer);
	// bge cr6,0x8b09d0a4
	if (!ctx.cr6.lt) goto loc_8B09D0A4;
	// stw r31,0(r11)
	REX_STORE_U32(ctx.r11.u32 + 0, ctx.r31.u32);
loc_8B09D0A4:
	// addi r11,r11,4
	ctx.r11.s64 = ctx.r11.s64 + 4;
	// bdnz 0x8b09d094
	--ctx.ctr.u64;
	if (ctx.ctr.u32 != 0) goto loc_8B09D094;
	// addi r1,r1,128
	ctx.r1.s64 = ctx.r1.s64 + 128;
	// b 0x8b0cba04
	__restgprlr_27(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B09D398) {
	REX_FUNC_PROLOGUE();
	PPCRegister temp{};
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// std r30,-24(r1)
	REX_STORE_U64(ctx.r1.u32 + -24, ctx.r30.u64);
	// std r31,-16(r1)
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.r31.u64);
	// stwu r1,-112(r1)
	ea = -112 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// mr r11,r4
	ctx.r11.u64 = ctx.r4.u64;
	// lwz r4,8(r3)
	ctx.r4.u64 = REX_LOAD_U32(ctx.r3.u32 + 8);
	// mr r30,r3
	ctx.r30.u64 = ctx.r3.u64;
	// cmpwi cr6,r4,0
	ctx.cr6.compare<int32_t>(ctx.r4.s32, 0, ctx.xer);
	// blt cr6,0x8b09d458
	if (ctx.cr6.lt) goto loc_8B09D458;
	// lwz r3,4(r3)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r3.u32 + 4);
	// li r6,8
	ctx.r6.s64 = 8;
	// add r31,r3,r11
	ctx.r31.u64 = ctx.r3.u64 + ctx.r11.u64;
	// mr r5,r31
	ctx.r5.u64 = ctx.r31.u64;
	// bl 0x8b090160
	ctx.lr = 0x8B09D3D4;
	sub_8B090160(ctx, base);
	// cmpw cr6,r3,r31
	ctx.cr6.compare<int32_t>(ctx.r3.s32, ctx.r31.s32, ctx.xer);
	// bge cr6,0x8b09d408
	if (!ctx.cr6.lt) goto loc_8B09D408;
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// bne cr6,0x8b09d3f4
	if (!ctx.cr6.eq) goto loc_8B09D3F4;
	// cmpwi cr6,r31,-1
	ctx.cr6.compare<int32_t>(ctx.r31.s32, -1, ctx.xer);
	// bgt cr6,0x8b09d3f4
	if (ctx.cr6.gt) goto loc_8B09D3F4;
	// li r3,-1
	ctx.r3.s64 = -1;
	// b 0x8b09d408
	goto loc_8B09D408;
loc_8B09D3F4:
	// add r11,r3,r31
	ctx.r11.u64 = ctx.r3.u64 + ctx.r31.u64;
	// srawi r10,r11,1
	ctx.xer.ca = (ctx.r11.s32 < 0) & ((ctx.r11.u32 & 0x1) != 0);
	ctx.r10.s64 = ctx.r11.s32 >> 1;
	// addze r3,r10
	temp.s64 = ctx.r10.s64 + ctx.xer.ca;
	ctx.xer.ca = temp.u32 < ctx.r10.u32;
	ctx.r3.s64 = temp.s64;
	// cmpw cr6,r3,r31
	ctx.cr6.compare<int32_t>(ctx.r3.s32, ctx.r31.s32, ctx.xer);
	// blt cr6,0x8b09d3f4
	if (ctx.cr6.lt) goto loc_8B09D3F4;
loc_8B09D408:
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lwz r4,0(r30)
	ctx.r4.u64 = REX_LOAD_U32(ctx.r30.u32 + 0);
	// stw r3,4(r30)
	REX_STORE_U32(ctx.r30.u32 + 4, ctx.r3.u32);
	// cmplwi cr6,r4,0
	ctx.cr6.compare<uint32_t>(ctx.r4.u32, 0, ctx.xer);
	// lwz r11,1144(r11)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r11.u32 + 1144);
	// beq cr6,0x8b09d43c
	if (ctx.cr6.eq) goto loc_8B09D43C;
	// rlwinm r5,r3,3,0,28
	ctx.r5.u64 = __builtin_rotateleft64(ctx.r3.u32 | (ctx.r3.u64 << 32), 3) & 0xFFFFFFF8;
	// lwz r3,0(r11)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r11.u32 + 0);
	// lwz r10,0(r3)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r9,12(r10)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r10.u32 + 12);
	// mtctr r9
	ctx.ctr.u64 = ctx.r9.u64;
	// bctrl 
	ctx.lr = 0x8B09D438;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// b 0x8b09d454
	goto loc_8B09D454;
loc_8B09D43C:
	// rlwinm r4,r3,3,0,28
	ctx.r4.u64 = __builtin_rotateleft64(ctx.r3.u32 | (ctx.r3.u64 << 32), 3) & 0xFFFFFFF8;
	// lwz r3,0(r11)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r11.u32 + 0);
	// lwz r10,0(r3)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r9,4(r10)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r10.u32 + 4);
	// mtctr r9
	ctx.ctr.u64 = ctx.r9.u64;
	// bctrl 
	ctx.lr = 0x8B09D454;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
loc_8B09D454:
	// stw r3,0(r30)
	REX_STORE_U32(ctx.r30.u32 + 0, ctx.r3.u32);
loc_8B09D458:
	// addi r1,r1,112
	ctx.r1.s64 = ctx.r1.s64 + 112;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// ld r30,-24(r1)
	ctx.r30.u64 = REX_LOAD_U64(ctx.r1.u32 + -24);
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B09D698) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9bc
	ctx.lr = 0x8B09D6A0;
	__savegprlr_29(ctx, base);
	// stwu r1,-112(r1)
	ea = -112 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lis r11,-29938
	ctx.r11.s64 = -1962016768;
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// addi r29,r3,8
	ctx.r29.s64 = ctx.r3.s64 + 8;
	// addi r30,r11,18780
	ctx.r30.s64 = ctx.r11.s64 + 18780;
loc_8B09D6B4:
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// mr r4,r29
	ctx.r4.u64 = ctx.r29.u64;
	// bl 0x8b09d548
	ctx.lr = 0x8B09D6C0;
	sub_8B09D548(ctx, base);
	// clrlwi r11,r3,24
	ctx.r11.u64 = ctx.r3.u32 & 0xFF;
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// bne cr6,0x8b09d6b4
	if (!ctx.cr6.eq) goto loc_8B09D6B4;
	// lwz r10,264(r31)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r31.u32 + 264);
	// li r30,0
	ctx.r30.s64 = 0;
	// mr r11,r30
	ctx.r11.u64 = ctx.r30.u64;
	// cmpwi cr6,r10,2
	ctx.cr6.compare<int32_t>(ctx.r10.s32, 2, ctx.xer);
	// beq cr6,0x8b09d71c
	if (ctx.cr6.eq) goto loc_8B09D71C;
	// cmpwi cr6,r10,3
	ctx.cr6.compare<int32_t>(ctx.r10.s32, 3, ctx.xer);
	// beq cr6,0x8b09d6f4
	if (ctx.cr6.eq) goto loc_8B09D6F4;
	// cmpwi cr6,r10,4
	ctx.cr6.compare<int32_t>(ctx.r10.s32, 4, ctx.xer);
	// bne cr6,0x8b09d728
	if (!ctx.cr6.eq) goto loc_8B09D728;
	// b 0x8b09d724
	goto loc_8B09D724;
loc_8B09D6F4:
	// lis r11,-29938
	ctx.r11.s64 = -1962016768;
	// lwz r4,340(r31)
	ctx.r4.u64 = REX_LOAD_U32(ctx.r31.u32 + 340);
	// lwz r11,2364(r11)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r11.u32 + 2364);
	// lwz r3,104(r11)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r11.u32 + 104);
	// lwz r10,0(r3)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r9,12(r10)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r10.u32 + 12);
	// mtctr r9
	ctx.ctr.u64 = ctx.r9.u64;
	// bctrl 
	ctx.lr = 0x8B09D714;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// stw r30,340(r31)
	REX_STORE_U32(ctx.r31.u32 + 340, ctx.r30.u32);
	// b 0x8b09d724
	goto loc_8B09D724;
loc_8B09D71C:
	// addi r3,r31,344
	ctx.r3.s64 = ctx.r31.s64 + 344;
	// bl 0x8b0999c0
	ctx.lr = 0x8B09D724;
	sub_8B0999C0(ctx, base);
loc_8B09D724:
	// li r11,1
	ctx.r11.s64 = 1;
loc_8B09D728:
	// clrlwi r11,r11,24
	ctx.r11.u64 = ctx.r11.u32 & 0xFF;
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// beq cr6,0x8b09d748
	if (ctx.cr6.eq) goto loc_8B09D748;
	// lis r10,-29938
	ctx.r10.s64 = -1962016768;
	// lwz r11,18640(r10)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r10.u32 + 18640);
	// addi r11,r11,-1
	ctx.r11.s64 = ctx.r11.s64 + -1;
	// stw r11,18640(r10)
	REX_STORE_U32(ctx.r10.u32 + 18640, ctx.r11.u32);
	// bl 0x8b09d600
	ctx.lr = 0x8B09D748;
	sub_8B09D600(ctx, base);
loc_8B09D748:
	// lwz r3,260(r31)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r31.u32 + 260);
	// stw r30,264(r31)
	REX_STORE_U32(ctx.r31.u32 + 264, ctx.r30.u32);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b09d75c
	if (ctx.cr6.eq) goto loc_8B09D75C;
	// bl 0x8b0c04f0
	ctx.lr = 0x8B09D75C;
	sub_8B0C04F0(ctx, base);
loc_8B09D75C:
	// stw r30,260(r31)
	REX_STORE_U32(ctx.r31.u32 + 260, ctx.r30.u32);
	// addi r1,r1,112
	ctx.r1.s64 = ctx.r1.s64 + 112;
	// b 0x8b0cba0c
	__restgprlr_29(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B09DA10) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9bc
	ctx.lr = 0x8B09DA18;
	__savegprlr_29(ctx, base);
	// stwu r1,-112(r1)
	ea = -112 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lwz r10,12(r3)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r3.u32 + 12);
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// lwz r11,4(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 4);
	// mr r30,r4
	ctx.r30.u64 = ctx.r4.u64;
	// addi r9,r10,1
	ctx.r9.s64 = ctx.r10.s64 + 1;
	// mr r29,r5
	ctx.r29.u64 = ctx.r5.u64;
	// cmpw cr6,r9,r11
	ctx.cr6.compare<int32_t>(ctx.r9.s32, ctx.r11.s32, ctx.xer);
	// ble cr6,0x8b09da48
	if (!ctx.cr6.gt) goto loc_8B09DA48;
	// subf r11,r11,r10
	ctx.r11.u64 = ctx.r10.u64 - ctx.r11.u64;
	// addi r4,r11,1
	ctx.r4.s64 = ctx.r11.s64 + 1;
	// bl 0x8b09d470
	ctx.lr = 0x8B09DA48;
	sub_8B09D470(ctx, base);
loc_8B09DA48:
	// lwz r11,12(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 12);
	// addi r11,r11,1
	ctx.r11.s64 = ctx.r11.s64 + 1;
	// subf r10,r30,r11
	ctx.r10.u64 = ctx.r11.u64 - ctx.r30.u64;
	// stw r11,12(r31)
	REX_STORE_U32(ctx.r31.u32 + 12, ctx.r11.u32);
	// addic. r11,r10,-1
	ctx.xer.ca = ctx.r10.u32 > 0;
	ctx.r11.s64 = ctx.r10.s64 + -1;
	ctx.cr0.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// ble 0x8b09da88
	if (!ctx.cr0.gt) goto loc_8B09DA88;
	// rlwinm r8,r30,2,0,29
	ctx.r8.u64 = __builtin_rotateleft64(ctx.r30.u32 | (ctx.r30.u64 << 32), 2) & 0xFFFFFFFC;
	// lwz r10,0(r31)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r31.u32 + 0);
	// rlwinm r9,r11,2,0,29
	ctx.r9.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 2) & 0xFFFFFFFC;
	// add r8,r30,r8
	ctx.r8.u64 = ctx.r30.u64 + ctx.r8.u64;
	// add r7,r11,r9
	ctx.r7.u64 = ctx.r11.u64 + ctx.r9.u64;
	// rlwinm r11,r8,3,0,28
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r8.u32 | (ctx.r8.u64 << 32), 3) & 0xFFFFFFF8;
	// rlwinm r5,r7,3,0,28
	ctx.r5.u64 = __builtin_rotateleft64(ctx.r7.u32 | (ctx.r7.u64 << 32), 3) & 0xFFFFFFF8;
	// add r4,r11,r10
	ctx.r4.u64 = ctx.r11.u64 + ctx.r10.u64;
	// addi r3,r4,40
	ctx.r3.s64 = ctx.r4.s64 + 40;
	// bl 0x8b0cc060
	ctx.lr = 0x8B09DA88;
	sub_8B0CC060(ctx, base);
loc_8B09DA88:
	// rlwinm r11,r30,2,0,29
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r30.u32 | (ctx.r30.u64 << 32), 2) & 0xFFFFFFFC;
	// lwz r10,0(r31)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r31.u32 + 0);
	// add r11,r30,r11
	ctx.r11.u64 = ctx.r30.u64 + ctx.r11.u64;
	// rlwinm r11,r11,3,0,28
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 3) & 0xFFFFFFF8;
	// add. r11,r11,r10
	ctx.r11.u64 = ctx.r11.u64 + ctx.r10.u64;
	ctx.cr0.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// beq 0x8b09dabc
	if (ctx.cr0.eq) goto loc_8B09DABC;
	// li r9,5
	ctx.r9.s64 = 5;
	// addi r10,r29,-8
	ctx.r10.s64 = ctx.r29.s64 + -8;
	// addi r11,r11,-8
	ctx.r11.s64 = ctx.r11.s64 + -8;
	// mtctr r9
	ctx.ctr.u64 = ctx.r9.u64;
loc_8B09DAB0:
	// ldu r9,8(r10)
	ea = 8 + ctx.r10.u32;
	ctx.r9.u64 = REX_LOAD_U64(ea);
	ctx.r10.u32 = ea;
	// stdu r9,8(r11)
	ea = 8 + ctx.r11.u32;
	REX_STORE_U64(ea, ctx.r9.u64);
	ctx.r11.u32 = ea;
	// bdnz 0x8b09dab0
	--ctx.ctr.u64;
	if (ctx.ctr.u32 != 0) goto loc_8B09DAB0;
loc_8B09DABC:
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// addi r1,r1,112
	ctx.r1.s64 = ctx.r1.s64 + 112;
	// b 0x8b0cba0c
	__restgprlr_29(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B09E020) {
	REX_FUNC_PROLOGUE();
	PPCRegister temp{};
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb994
	ctx.lr = 0x8B09E028;
	__savegprlr_19(ctx, base);
	// stfd f31,-120(r1)
	ctx.fpscr.disableFlushMode();
	REX_STORE_U64(ctx.r1.u32 + -120, ctx.f31.u64);
	// stwu r1,-256(r1)
	ea = -256 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// ld r11,8(r3)
	ctx.r11.u64 = REX_LOAD_U64(ctx.r3.u32 + 8);
	// mr r28,r3
	ctx.r28.u64 = ctx.r3.u64;
	// cmpldi cr6,r11,0
	ctx.cr6.compare<uint64_t>(ctx.r11.u64, 0, ctx.xer);
	// beq cr6,0x8b09e360
	if (ctx.cr6.eq) goto loc_8B09E360;
	// lwz r11,16(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 16);
	// cmpwi cr6,r11,0
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// blt cr6,0x8b09e070
	if (ctx.cr6.lt) goto loc_8B09E070;
	// cmplwi cr6,r11,4
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 4, ctx.xer);
	// bge cr6,0x8b09e070
	if (!ctx.cr6.lt) goto loc_8B09E070;
	// lis r9,-29938
	ctx.r9.s64 = -1962016768;
	// rlwinm r10,r11,2,0,29
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 2) & 0xFFFFFFFC;
	// addi r11,r9,18624
	ctx.r11.s64 = ctx.r9.s64 + 18624;
	// li r31,0
	ctx.r31.s64 = 0;
	// lwzx r29,r10,r11
	ctx.r29.u64 = REX_LOAD_U32(ctx.r10.u32 + ctx.r11.u32);
	// stwx r31,r10,r11
	REX_STORE_U32(ctx.r10.u32 + ctx.r11.u32, ctx.r31.u32);
	// b 0x8b09e078
	goto loc_8B09E078;
loc_8B09E070:
	// li r31,0
	ctx.r31.s64 = 0;
	// mr r29,r31
	ctx.r29.u64 = ctx.r31.u64;
loc_8B09E078:
	// lbz r10,3132(r28)
	ctx.r10.u64 = REX_LOAD_U8(ctx.r28.u32 + 3132);
	// addi r20,r28,3132
	ctx.r20.s64 = ctx.r28.s64 + 3132;
	// mr r11,r31
	ctx.r11.u64 = ctx.r31.u64;
	// cmplwi cr6,r10,0
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 0, ctx.xer);
	// beq cr6,0x8b09e090
	if (ctx.cr6.eq) goto loc_8B09E090;
	// li r11,1
	ctx.r11.s64 = 1;
loc_8B09E090:
	// lbz r10,3133(r28)
	ctx.r10.u64 = REX_LOAD_U8(ctx.r28.u32 + 3133);
	// cmplwi cr6,r10,0
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 0, ctx.xer);
	// beq cr6,0x8b09e0a0
	if (ctx.cr6.eq) goto loc_8B09E0A0;
	// addi r11,r11,1
	ctx.r11.s64 = ctx.r11.s64 + 1;
loc_8B09E0A0:
	// lbz r10,3134(r28)
	ctx.r10.u64 = REX_LOAD_U8(ctx.r28.u32 + 3134);
	// cmplwi cr6,r10,0
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 0, ctx.xer);
	// beq cr6,0x8b09e0b0
	if (ctx.cr6.eq) goto loc_8B09E0B0;
	// addi r11,r11,1
	ctx.r11.s64 = ctx.r11.s64 + 1;
loc_8B09E0B0:
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// beq cr6,0x8b09e360
	if (ctx.cr6.eq) goto loc_8B09E360;
	// lwz r11,0(r28)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r28.u32 + 0);
	// mr r3,r28
	ctx.r3.u64 = ctx.r28.u64;
	// lwz r10,12(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 12);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B09E0CC;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// cntlzw r9,r3
	ctx.r9.u64 = ctx.r3.u32 == 0 ? 32 : __builtin_clz(ctx.r3.u32);
	// lwz r8,56(r28)
	ctx.r8.u64 = REX_LOAD_U32(ctx.r28.u32 + 56);
	// rlwinm r7,r9,27,31,31
	ctx.r7.u64 = __builtin_rotateleft64(ctx.r9.u32 | (ctx.r9.u64 << 32), 27) & 0x1;
	// xori r11,r7,1
	ctx.r11.u64 = ctx.r7.u64 ^ 1;
	// addi r11,r11,1
	ctx.r11.s64 = ctx.r11.s64 + 1;
	// cmpw cr6,r8,r11
	ctx.cr6.compare<int32_t>(ctx.r8.s32, ctx.r11.s32, ctx.xer);
	// blt cr6,0x8b09e360
	if (ctx.cr6.lt) goto loc_8B09E360;
	// li r30,1
	ctx.r30.s64 = 1;
	// bl 0x8b0df2f8
	ctx.lr = 0x8B09E0F0;
	sub_8B0DF2F8(ctx, base);
	// lfs f0,60(r28)
	ctx.fpscr.disableFlushMode();
	temp.u32 = REX_LOAD_U32(ctx.r28.u32 + 60);
	ctx.f0.f64 = double(temp.f32);
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// fsub f13,f1,f0
	ctx.f13.f64 = ctx.f1.f64 - ctx.f0.f64;
	// lfd f0,15392(r11)
	ctx.f0.u64 = REX_LOAD_U64(ctx.r11.u32 + 15392);
	// fcmpu cr6,f13,f0
	ctx.cr6.compare(ctx.f13.f64, ctx.f0.f64);
	// bge cr6,0x8b09e10c
	if (!ctx.cr6.lt) goto loc_8B09E10C;
	// mr r30,r31
	ctx.r30.u64 = ctx.r31.u64;
loc_8B09E10C:
	// cmpwi cr6,r29,2
	ctx.cr6.compare<int32_t>(ctx.r29.s32, 2, ctx.xer);
	// beq cr6,0x8b09e120
	if (ctx.cr6.eq) goto loc_8B09E120;
	// addi r11,r29,-3
	ctx.r11.s64 = ctx.r29.s64 + -3;
	// cntlzw r10,r11
	ctx.r10.u64 = ctx.r11.u32 == 0 ? 32 : __builtin_clz(ctx.r11.u32);
	// rlwinm r30,r10,27,31,31
	ctx.r30.u64 = __builtin_rotateleft64(ctx.r10.u32 | (ctx.r10.u64 << 32), 27) & 0x1;
loc_8B09E120:
	// clrlwi r11,r30,24
	ctx.r11.u64 = ctx.r30.u32 & 0xFF;
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// beq cr6,0x8b09e360
	if (ctx.cr6.eq) goto loc_8B09E360;
	// bl 0x8b0df2f8
	ctx.lr = 0x8B09E130;
	sub_8B0DF2F8(ctx, base);
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lwz r4,16(r28)
	ctx.r4.u64 = REX_LOAD_U32(ctx.r28.u32 + 16);
	// frsp f31,f1
	ctx.fpscr.disableFlushMode();
	ctx.f31.f64 = double(float(ctx.f1.f64));
	// addi r3,r11,15344
	ctx.r3.s64 = ctx.r11.s64 + 15344;
	// bl 0x8b0df3b8
	ctx.lr = 0x8B09E144;
	sub_8B0DF3B8(ctx, base);
	// li r3,3000
	ctx.r3.s64 = 3000;
	// mr r25,r31
	ctx.r25.u64 = ctx.r31.u64;
	// stw r31,80(r1)
	REX_STORE_U32(ctx.r1.u32 + 80, ctx.r31.u32);
	// stw r31,84(r1)
	REX_STORE_U32(ctx.r1.u32 + 84, ctx.r31.u32);
	// stw r31,92(r1)
	REX_STORE_U32(ctx.r1.u32 + 92, ctx.r31.u32);
	// stw r31,88(r1)
	REX_STORE_U32(ctx.r1.u32 + 88, ctx.r31.u32);
	// bl 0x8b090000
	ctx.lr = 0x8B09E160;
	sub_8B090000(ctx, base);
	// li r5,3000
	ctx.r5.s64 = 3000;
	// li r4,0
	ctx.r4.s64 = 0;
	// mr r19,r3
	ctx.r19.u64 = ctx.r3.u64;
	// bl 0x8b0cb8e0
	ctx.lr = 0x8B09E170;
	sub_8B0CB8E0(ctx, base);
	// lis r11,-29938
	ctx.r11.s64 = -1962016768;
	// mr r30,r31
	ctx.r30.u64 = ctx.r31.u64;
	// addi r26,r11,4080
	ctx.r26.s64 = ctx.r11.s64 + 4080;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// mr r29,r19
	ctx.r29.u64 = ctx.r19.u64;
	// addi r27,r28,132
	ctx.r27.s64 = ctx.r28.s64 + 132;
	// li r21,-1
	ctx.r21.s64 = -1;
	// li r23,6
	ctx.r23.s64 = 6;
	// li r24,1000
	ctx.r24.s64 = 1000;
	// addi r22,r11,15288
	ctx.r22.s64 = ctx.r11.s64 + 15288;
loc_8B09E198:
	// lbzx r11,r20,r30
	ctx.r11.u64 = REX_LOAD_U8(ctx.r20.u32 + ctx.r30.u32);
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// beq cr6,0x8b09e21c
	if (ctx.cr6.eq) goto loc_8B09E21C;
	// mr r3,r22
	ctx.r3.u64 = ctx.r22.u64;
	// lwz r4,16(r28)
	ctx.r4.u64 = REX_LOAD_U32(ctx.r28.u32 + 16);
	// addi r5,r30,1
	ctx.r5.s64 = ctx.r30.s64 + 1;
	// bl 0x8b0df3b8
	ctx.lr = 0x8B09E1B4;
	sub_8B0DF3B8(ctx, base);
	// addi r11,r1,96
	ctx.r11.s64 = ctx.r1.s64 + 96;
	// cmpwi cr6,r30,0
	ctx.cr6.compare<int32_t>(ctx.r30.s32, 0, ctx.xer);
	// std r31,0(r11)
	REX_STORE_U64(ctx.r11.u32 + 0, ctx.r31.u64);
	// std r31,8(r11)
	REX_STORE_U64(ctx.r11.u32 + 8, ctx.r31.u64);
	// std r31,16(r11)
	REX_STORE_U64(ctx.r11.u32 + 16, ctx.r31.u64);
	// std r31,24(r11)
	REX_STORE_U64(ctx.r11.u32 + 24, ctx.r31.u64);
	// std r31,32(r11)
	REX_STORE_U64(ctx.r11.u32 + 32, ctx.r31.u64);
	// blt cr6,0x8b09e1e4
	if (ctx.cr6.lt) goto loc_8B09E1E4;
	// cmplwi cr6,r30,3
	ctx.cr6.compare<uint32_t>(ctx.r30.u32, 3, ctx.xer);
	// bge cr6,0x8b09e1e4
	if (!ctx.cr6.lt) goto loc_8B09E1E4;
	// lwz r11,0(r26)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r26.u32 + 0);
	// b 0x8b09e1e8
	goto loc_8B09E1E8;
loc_8B09E1E4:
	// mr r11,r21
	ctx.r11.u64 = ctx.r21.u64;
loc_8B09E1E8:
	// li r5,1000
	ctx.r5.s64 = 1000;
	// stw r11,112(r1)
	REX_STORE_U32(ctx.r1.u32 + 112, ctx.r11.u32);
	// mr r4,r27
	ctx.r4.u64 = ctx.r27.u64;
	// stw r29,132(r1)
	REX_STORE_U32(ctx.r1.u32 + 132, ctx.r29.u32);
	// mr r3,r29
	ctx.r3.u64 = ctx.r29.u64;
	// stb r23,120(r1)
	REX_STORE_U8(ctx.r1.u32 + 120, ctx.r23.u8);
	// stw r24,128(r1)
	REX_STORE_U32(ctx.r1.u32 + 128, ctx.r24.u32);
	// bl 0x8b0cbb30
	ctx.lr = 0x8B09E208;
	sub_8B0CBB30(ctx, base);
	// addi r5,r1,96
	ctx.r5.s64 = ctx.r1.s64 + 96;
	// mr r4,r25
	ctx.r4.u64 = ctx.r25.u64;
	// addi r3,r1,80
	ctx.r3.s64 = ctx.r1.s64 + 80;
	// bl 0x8b09da10
	ctx.lr = 0x8B09E218;
	sub_8B09DA10(ctx, base);
	// lwz r25,92(r1)
	ctx.r25.u64 = REX_LOAD_U32(ctx.r1.u32 + 92);
loc_8B09E21C:
	// addi r30,r30,1
	ctx.r30.s64 = ctx.r30.s64 + 1;
	// addi r26,r26,4
	ctx.r26.s64 = ctx.r26.s64 + 4;
	// addi r29,r29,1000
	ctx.r29.s64 = ctx.r29.s64 + 1000;
	// addi r27,r27,1000
	ctx.r27.s64 = ctx.r27.s64 + 1000;
	// cmplwi cr6,r30,3
	ctx.cr6.compare<uint32_t>(ctx.r30.u32, 3, ctx.xer);
	// blt cr6,0x8b09e198
	if (ctx.cr6.lt) goto loc_8B09E198;
	// stb r31,0(r20)
	REX_STORE_U8(ctx.r20.u32 + 0, ctx.r31.u8);
	// stb r31,1(r20)
	REX_STORE_U8(ctx.r20.u32 + 1, ctx.r31.u8);
	// stb r31,2(r20)
	REX_STORE_U8(ctx.r20.u32 + 2, ctx.r31.u8);
	// bl 0x8b0df2f8
	ctx.lr = 0x8B09E244;
	sub_8B0DF2F8(ctx, base);
	// frsp f0,f1
	ctx.fpscr.disableFlushMode();
	ctx.f0.f64 = double(float(ctx.f1.f64));
	// stfs f0,60(r28)
	temp.f32 = float(ctx.f0.f64);
	REX_STORE_U32(ctx.r28.u32 + 60, temp.u32);
	// lis r11,-29938
	ctx.r11.s64 = -1962016768;
	// lwz r29,80(r1)
	ctx.r29.u64 = REX_LOAD_U32(ctx.r1.u32 + 80);
	// li r7,0
	ctx.r7.s64 = 0;
	// mr r5,r25
	ctx.r5.u64 = ctx.r25.u64;
	// lwz r4,16(r28)
	ctx.r4.u64 = REX_LOAD_U32(ctx.r28.u32 + 16);
	// mr r6,r29
	ctx.r6.u64 = ctx.r29.u64;
	// lwz r11,2364(r11)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r11.u32 + 2364);
	// lwz r3,104(r11)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r11.u32 + 104);
	// lwz r10,0(r3)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r9,140(r10)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r10.u32 + 140);
	// mtctr r9
	ctx.ctr.u64 = ctx.r9.u64;
	// bctrl 
	ctx.lr = 0x8B09E27C;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// mr r30,r3
	ctx.r30.u64 = ctx.r3.u64;
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b09e2fc
	if (ctx.cr6.eq) goto loc_8B09E2FC;
	// bl 0x8b0df2f8
	ctx.lr = 0x8B09E28C;
	sub_8B0DF2F8(ctx, base);
	// fsub f1,f1,f31
	ctx.fpscr.disableFlushMode();
	ctx.f1.f64 = ctx.f1.f64 - ctx.f31.f64;
	// stfd f1,32(r1)
	REX_STORE_U64(ctx.r1.u32 + 32, ctx.f1.u64);
	// ld r5,32(r1)
	ctx.r5.u64 = REX_LOAD_U64(ctx.r1.u32 + 32);
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lwz r4,16(r28)
	ctx.r4.u64 = REX_LOAD_U32(ctx.r28.u32 + 16);
	// mr r6,r30
	ctx.r6.u64 = ctx.r30.u64;
	// addi r3,r11,15228
	ctx.r3.s64 = ctx.r11.s64 + 15228;
	// bl 0x8b0df2a8
	ctx.lr = 0x8B09E2AC;
	sub_8B0DF2A8(ctx, base);
	// li r3,36
	ctx.r3.s64 = 36;
	// bl 0x8b0bf448
	ctx.lr = 0x8B09E2B4;
	sub_8B0BF448(ctx, base);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b09e2dc
	if (ctx.cr6.eq) goto loc_8B09E2DC;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lwz r6,16(r28)
	ctx.r6.u64 = REX_LOAD_U32(ctx.r28.u32 + 16);
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// addi r5,r11,14412
	ctx.r5.s64 = ctx.r11.s64 + 14412;
	// addi r4,r10,15204
	ctx.r4.s64 = ctx.r10.s64 + 15204;
	// bl 0x8b0c1390
	ctx.lr = 0x8B09E2D4;
	sub_8B0C1390(ctx, base);
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// b 0x8b09e2e0
	goto loc_8B09E2E0;
loc_8B09E2DC:
	// mr r4,r31
	ctx.r4.u64 = ctx.r31.u64;
loc_8B09E2E0:
	// lis r11,-29938
	ctx.r11.s64 = -1962016768;
	// lwz r3,4480(r11)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r11.u32 + 4480);
	// lwz r10,0(r3)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r9,8(r10)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r10.u32 + 8);
	// mtctr r9
	ctx.ctr.u64 = ctx.r9.u64;
	// bctrl 
	ctx.lr = 0x8B09E2F8;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// b 0x8b09e31c
	goto loc_8B09E31C;
loc_8B09E2FC:
	// bl 0x8b0df2f8
	ctx.lr = 0x8B09E300;
	sub_8B0DF2F8(ctx, base);
	// fsub f1,f1,f31
	ctx.fpscr.disableFlushMode();
	ctx.f1.f64 = ctx.f1.f64 - ctx.f31.f64;
	// stfd f1,32(r1)
	REX_STORE_U64(ctx.r1.u32 + 32, ctx.f1.u64);
	// ld r5,32(r1)
	ctx.r5.u64 = REX_LOAD_U64(ctx.r1.u32 + 32);
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lwz r4,16(r28)
	ctx.r4.u64 = REX_LOAD_U32(ctx.r28.u32 + 16);
	// addi r3,r11,15152
	ctx.r3.s64 = ctx.r11.s64 + 15152;
	// bl 0x8b0df3b8
	ctx.lr = 0x8B09E31C;
	sub_8B0DF3B8(ctx, base);
loc_8B09E31C:
	// mr r3,r19
	ctx.r3.u64 = ctx.r19.u64;
	// bl 0x8b090020
	ctx.lr = 0x8B09E324;
	sub_8B090020(ctx, base);
	// li r3,0
	ctx.r3.s64 = 0;
	// bl 0x8b090020
	ctx.lr = 0x8B09E32C;
	sub_8B090020(ctx, base);
	// lwz r11,88(r1)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r1.u32 + 88);
	// cmpwi cr6,r11,0
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// blt cr6,0x8b09e360
	if (ctx.cr6.lt) goto loc_8B09E360;
	// cmplwi cr6,r29,0
	ctx.cr6.compare<uint32_t>(ctx.r29.u32, 0, ctx.xer);
	// beq cr6,0x8b09e360
	if (ctx.cr6.eq) goto loc_8B09E360;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// mr r4,r29
	ctx.r4.u64 = ctx.r29.u64;
	// lwz r11,1144(r11)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r11.u32 + 1144);
	// lwz r3,0(r11)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r11.u32 + 0);
	// lwz r10,0(r3)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r9,20(r10)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r10.u32 + 20);
	// mtctr r9
	ctx.ctr.u64 = ctx.r9.u64;
	// bctrl 
	ctx.lr = 0x8B09E360;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
loc_8B09E360:
	// addi r1,r1,256
	ctx.r1.s64 = ctx.r1.s64 + 256;
	// lfd f31,-120(r1)
	ctx.fpscr.disableFlushMode();
	ctx.f31.u64 = REX_LOAD_U64(ctx.r1.u32 + -120);
	// b 0x8b0cb9e4
	__restgprlr_19(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B09F260) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// std r30,-24(r1)
	REX_STORE_U64(ctx.r1.u32 + -24, ctx.r30.u64);
	// std r31,-16(r1)
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.r31.u64);
	// stwu r1,-112(r1)
	ea = -112 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// addi r3,r3,4
	ctx.r3.s64 = ctx.r3.s64 + 4;
	// addi r10,r11,15632
	ctx.r10.s64 = ctx.r11.s64 + 15632;
	// mr r30,r4
	ctx.r30.u64 = ctx.r4.u64;
	// stw r10,0(r31)
	REX_STORE_U32(ctx.r31.u32 + 0, ctx.r10.u32);
	// bl 0x8b0906a8
	ctx.lr = 0x8B09F290;
	sub_8B0906A8(ctx, base);
	// lis r9,-29944
	ctx.r9.s64 = -1962409984;
	// clrlwi r8,r30,31
	ctx.r8.u64 = ctx.r30.u32 & 0x1;
	// addi r7,r9,15612
	ctx.r7.s64 = ctx.r9.s64 + 15612;
	// cmplwi cr6,r8,0
	ctx.cr6.compare<uint32_t>(ctx.r8.u32, 0, ctx.xer);
	// stw r7,0(r31)
	REX_STORE_U32(ctx.r31.u32 + 0, ctx.r7.u32);
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// beq cr6,0x8b09f2b4
	if (ctx.cr6.eq) goto loc_8B09F2B4;
	// bl 0x8b090020
	ctx.lr = 0x8B09F2B0;
	sub_8B090020(ctx, base);
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
loc_8B09F2B4:
	// addi r1,r1,112
	ctx.r1.s64 = ctx.r1.s64 + 112;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// ld r30,-24(r1)
	ctx.r30.u64 = REX_LOAD_U64(ctx.r1.u32 + -24);
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B09F398) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// std r31,-16(r1)
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.r31.u64);
	// stwu r1,-96(r1)
	ea = -96 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lwz r11,12(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 12);
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// subf r10,r4,r11
	ctx.r10.u64 = ctx.r11.u64 - ctx.r4.u64;
	// addic. r11,r10,-1
	ctx.xer.ca = ctx.r10.u32 > 0;
	ctx.r11.s64 = ctx.r10.s64 + -1;
	ctx.cr0.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// ble 0x8b09f3d4
	if (!ctx.cr0.gt) goto loc_8B09F3D4;
	// lwz r9,0(r3)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// rlwinm r10,r4,2,0,29
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r4.u32 | (ctx.r4.u64 << 32), 2) & 0xFFFFFFFC;
	// rlwinm r5,r11,2,0,29
	ctx.r5.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 2) & 0xFFFFFFFC;
	// add r3,r10,r9
	ctx.r3.u64 = ctx.r10.u64 + ctx.r9.u64;
	// addi r4,r3,4
	ctx.r4.s64 = ctx.r3.s64 + 4;
	// bl 0x8b0cc060
	ctx.lr = 0x8B09F3D4;
	sub_8B0CC060(ctx, base);
loc_8B09F3D4:
	// lwz r11,12(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 12);
	// addi r11,r11,-1
	ctx.r11.s64 = ctx.r11.s64 + -1;
	// stw r11,12(r31)
	REX_STORE_U32(ctx.r31.u32 + 12, ctx.r11.u32);
	// addi r1,r1,96
	ctx.r1.s64 = ctx.r1.s64 + 96;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B09F590) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9bc
	ctx.lr = 0x8B09F598;
	__savegprlr_29(ctx, base);
	// stwu r1,-112(r1)
	ea = -112 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// li r30,0
	ctx.r30.s64 = 0;
	// addi r10,r11,15692
	ctx.r10.s64 = ctx.r11.s64 + 15692;
	// addi r29,r3,88
	ctx.r29.s64 = ctx.r3.s64 + 88;
	// stw r10,0(r3)
	REX_STORE_U32(ctx.r3.u32 + 0, ctx.r10.u32);
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// stw r30,100(r3)
	REX_STORE_U32(ctx.r3.u32 + 100, ctx.r30.u32);
	// mr r3,r29
	ctx.r3.u64 = ctx.r29.u64;
	// bl 0x8b0906a8
	ctx.lr = 0x8B09F5C0;
	sub_8B0906A8(ctx, base);
	// mr r3,r29
	ctx.r3.u64 = ctx.r29.u64;
	// bl 0x8b0906a8
	ctx.lr = 0x8B09F5C8;
	sub_8B0906A8(ctx, base);
	// stw r30,84(r31)
	REX_STORE_U32(ctx.r31.u32 + 84, ctx.r30.u32);
	// addi r29,r31,72
	ctx.r29.s64 = ctx.r31.s64 + 72;
	// mr r3,r29
	ctx.r3.u64 = ctx.r29.u64;
	// bl 0x8b0906a8
	ctx.lr = 0x8B09F5D8;
	sub_8B0906A8(ctx, base);
	// mr r3,r29
	ctx.r3.u64 = ctx.r29.u64;
	// bl 0x8b0906a8
	ctx.lr = 0x8B09F5E0;
	sub_8B0906A8(ctx, base);
	// stw r30,68(r31)
	REX_STORE_U32(ctx.r31.u32 + 68, ctx.r30.u32);
	// addi r29,r31,56
	ctx.r29.s64 = ctx.r31.s64 + 56;
	// mr r3,r29
	ctx.r3.u64 = ctx.r29.u64;
	// bl 0x8b0906a8
	ctx.lr = 0x8B09F5F0;
	sub_8B0906A8(ctx, base);
	// mr r3,r29
	ctx.r3.u64 = ctx.r29.u64;
	// bl 0x8b0906a8
	ctx.lr = 0x8B09F5F8;
	sub_8B0906A8(ctx, base);
	// stw r30,48(r31)
	REX_STORE_U32(ctx.r31.u32 + 48, ctx.r30.u32);
	// addi r29,r31,36
	ctx.r29.s64 = ctx.r31.s64 + 36;
	// mr r3,r29
	ctx.r3.u64 = ctx.r29.u64;
	// bl 0x8b0906a8
	ctx.lr = 0x8B09F608;
	sub_8B0906A8(ctx, base);
	// mr r3,r29
	ctx.r3.u64 = ctx.r29.u64;
	// bl 0x8b0906a8
	ctx.lr = 0x8B09F610;
	sub_8B0906A8(ctx, base);
	// stw r30,32(r31)
	REX_STORE_U32(ctx.r31.u32 + 32, ctx.r30.u32);
	// addi r29,r31,20
	ctx.r29.s64 = ctx.r31.s64 + 20;
	// mr r3,r29
	ctx.r3.u64 = ctx.r29.u64;
	// bl 0x8b0906a8
	ctx.lr = 0x8B09F620;
	sub_8B0906A8(ctx, base);
	// mr r3,r29
	ctx.r3.u64 = ctx.r29.u64;
	// bl 0x8b0906a8
	ctx.lr = 0x8B09F628;
	sub_8B0906A8(ctx, base);
	// stw r30,16(r31)
	REX_STORE_U32(ctx.r31.u32 + 16, ctx.r30.u32);
	// addi r29,r31,4
	ctx.r29.s64 = ctx.r31.s64 + 4;
	// mr r3,r29
	ctx.r3.u64 = ctx.r29.u64;
	// bl 0x8b0906a8
	ctx.lr = 0x8B09F638;
	sub_8B0906A8(ctx, base);
	// mr r3,r29
	ctx.r3.u64 = ctx.r29.u64;
	// bl 0x8b0906a8
	ctx.lr = 0x8B09F640;
	sub_8B0906A8(ctx, base);
	// addi r1,r1,112
	ctx.r1.s64 = ctx.r1.s64 + 112;
	// b 0x8b0cba0c
	__restgprlr_29(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B09F700) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// std r31,-16(r1)
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.r31.u64);
	// stwu r1,-112(r1)
	ea = -112 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// stw r4,140(r1)
	REX_STORE_U32(ctx.r1.u32 + 140, ctx.r4.u32);
	// cmplwi cr6,r4,0
	ctx.cr6.compare<uint32_t>(ctx.r4.u32, 0, ctx.xer);
	// beq cr6,0x8b09f7d4
	if (ctx.cr6.eq) goto loc_8B09F7D4;
	// lwz r9,16(r3)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r3.u32 + 16);
	// addi r3,r3,4
	ctx.r3.s64 = ctx.r3.s64 + 4;
	// li r11,0
	ctx.r11.s64 = 0;
	// cmpwi cr6,r9,0
	ctx.cr6.compare<int32_t>(ctx.r9.s32, 0, ctx.xer);
	// ble cr6,0x8b09f754
	if (!ctx.cr6.gt) goto loc_8B09F754;
	// lwz r10,0(r3)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
loc_8B09F738:
	// lwz r8,0(r10)
	ctx.r8.u64 = REX_LOAD_U32(ctx.r10.u32 + 0);
	// cmplw cr6,r8,r4
	ctx.cr6.compare<uint32_t>(ctx.r8.u32, ctx.r4.u32, ctx.xer);
	// beq cr6,0x8b09f75c
	if (ctx.cr6.eq) goto loc_8B09F75C;
	// addi r11,r11,1
	ctx.r11.s64 = ctx.r11.s64 + 1;
	// addi r10,r10,4
	ctx.r10.s64 = ctx.r10.s64 + 4;
	// cmpw cr6,r11,r9
	ctx.cr6.compare<int32_t>(ctx.r11.s32, ctx.r9.s32, ctx.xer);
	// blt cr6,0x8b09f738
	if (ctx.cr6.lt) goto loc_8B09F738;
loc_8B09F754:
	// li r9,-1
	ctx.r9.s64 = -1;
	// b 0x8b09f778
	goto loc_8B09F778;
loc_8B09F75C:
	// mr r9,r11
	ctx.r9.u64 = ctx.r11.u64;
	// cmpwi cr6,r11,0
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// blt cr6,0x8b09f778
	if (ctx.cr6.lt) goto loc_8B09F778;
	// lwz r10,16(r31)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r31.u32 + 16);
	// cmpw cr6,r11,r10
	ctx.cr6.compare<int32_t>(ctx.r11.s32, ctx.r10.s32, ctx.xer);
	// li r11,1
	ctx.r11.s64 = 1;
	// blt cr6,0x8b09f77c
	if (ctx.cr6.lt) goto loc_8B09F77C;
loc_8B09F778:
	// li r11,0
	ctx.r11.s64 = 0;
loc_8B09F77C:
	// clrlwi r11,r11,24
	ctx.r11.u64 = ctx.r11.u32 & 0xFF;
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// beq cr6,0x8b09f7b0
	if (ctx.cr6.eq) goto loc_8B09F7B0;
	// lwz r10,20(r31)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r31.u32 + 20);
	// rlwinm r11,r9,2,0,29
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r9.u32 | (ctx.r9.u64 << 32), 2) & 0xFFFFFFFC;
	// lwzx r9,r11,r10
	ctx.r9.u64 = REX_LOAD_U32(ctx.r11.u32 + ctx.r10.u32);
	// addi r9,r9,1
	ctx.r9.s64 = ctx.r9.s64 + 1;
	// stwx r9,r11,r10
	REX_STORE_U32(ctx.r11.u32 + ctx.r10.u32, ctx.r9.u32);
	// addi r1,r1,112
	ctx.r1.s64 = ctx.r1.s64 + 112;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
loc_8B09F7B0:
	// addi r5,r1,140
	ctx.r5.s64 = ctx.r1.s64 + 140;
	// lwz r4,12(r3)
	ctx.r4.u64 = REX_LOAD_U32(ctx.r3.u32 + 12);
	// bl 0x8b09f3f8
	ctx.lr = 0x8B09F7BC;
	sub_8B09F3F8(ctx, base);
	// li r11,1
	ctx.r11.s64 = 1;
	// addi r3,r31,20
	ctx.r3.s64 = ctx.r31.s64 + 20;
	// lwz r4,32(r31)
	ctx.r4.u64 = REX_LOAD_U32(ctx.r31.u32 + 32);
	// stw r11,80(r1)
	REX_STORE_U32(ctx.r1.u32 + 80, ctx.r11.u32);
	// addi r5,r1,80
	ctx.r5.s64 = ctx.r1.s64 + 80;
	// bl 0x8b09f3f8
	ctx.lr = 0x8B09F7D4;
	sub_8B09F3F8(ctx, base);
loc_8B09F7D4:
	// addi r1,r1,112
	ctx.r1.s64 = ctx.r1.s64 + 112;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B09FC88) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// std r31,-16(r1)
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.r31.u64);
	// stwu r1,-96(r1)
	ea = -96 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lwz r11,8(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 8);
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// beq cr6,0x8b09fd34
	if (ctx.cr6.eq) goto loc_8B09FD34;
	// lis r11,-29938
	ctx.r11.s64 = -1962016768;
	// lis r10,-29938
	ctx.r10.s64 = -1962016768;
	// addi r6,r11,4764
	ctx.r6.s64 = ctx.r11.s64 + 4764;
	// addi r5,r10,2964
	ctx.r5.s64 = ctx.r10.s64 + 2964;
	// li r7,0
	ctx.r7.s64 = 0;
	// li r4,0
	ctx.r4.s64 = 0;
	// bl 0x8b0ccd08
	ctx.lr = 0x8B09FCC4;
	sub_8B0CCD08(ctx, base);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b09fd34
	if (ctx.cr6.eq) goto loc_8B09FD34;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lwz r3,180(r31)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r31.u32 + 180);
	// li r5,0
	ctx.r5.s64 = 0;
	// addi r4,r11,4888
	ctx.r4.s64 = ctx.r11.s64 + 4888;
	// bl 0x8b0bfc38
	ctx.lr = 0x8B09FCE0;
	sub_8B0BFC38(ctx, base);
	// cmpwi cr6,r3,1
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 1, ctx.xer);
	// ble cr6,0x8b09fd18
	if (!ctx.cr6.gt) goto loc_8B09FD18;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lwz r3,180(r31)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r31.u32 + 180);
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// addi r5,r11,1791
	ctx.r5.s64 = ctx.r11.s64 + 1791;
	// addi r4,r10,3720
	ctx.r4.s64 = ctx.r10.s64 + 3720;
	// bl 0x8b0c1588
	ctx.lr = 0x8B09FD00;
	sub_8B0C1588(ctx, base);
	// lis r9,-29944
	ctx.r9.s64 = -1962409984;
	// addi r4,r9,5604
	ctx.r4.s64 = ctx.r9.s64 + 5604;
	// bl 0x8b0cea10
	ctx.lr = 0x8B09FD0C;
	sub_8B0CEA10(ctx, base);
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// li r11,1
	ctx.r11.s64 = 1;
	// beq cr6,0x8b09fd1c
	if (ctx.cr6.eq) goto loc_8B09FD1C;
loc_8B09FD18:
	// li r11,0
	ctx.r11.s64 = 0;
loc_8B09FD1C:
	// clrlwi r3,r11,24
	ctx.r3.u64 = ctx.r11.u32 & 0xFF;
	// addi r1,r1,96
	ctx.r1.s64 = ctx.r1.s64 + 96;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
loc_8B09FD34:
	// li r3,0
	ctx.r3.s64 = 0;
	// addi r1,r1,96
	ctx.r1.s64 = ctx.r1.s64 + 96;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B09FFA8) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9b0
	ctx.lr = 0x8B09FFB0;
	__savegprlr_26(ctx, base);
	// stwu r1,-144(r1)
	ea = -144 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// mr r29,r3
	ctx.r29.u64 = ctx.r3.u64;
	// mr r3,r4
	ctx.r3.u64 = ctx.r4.u64;
	// mr r26,r4
	ctx.r26.u64 = ctx.r4.u64;
	// bl 0x8b0beee8
	ctx.lr = 0x8B09FFC4;
	sub_8B0BEEE8(ctx, base);
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// addi r3,r11,16240
	ctx.r3.s64 = ctx.r11.s64 + 16240;
	// bl 0x8b0cea10
	ctx.lr = 0x8B09FFD8;
	sub_8B0CEA10(ctx, base);
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// bne cr6,0x8b0a0014
	if (!ctx.cr6.eq) goto loc_8B0A0014;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// li r5,0
	ctx.r5.s64 = 0;
	// addi r4,r11,16356
	ctx.r4.s64 = ctx.r11.s64 + 16356;
	// mr r3,r26
	ctx.r3.u64 = ctx.r26.u64;
	// bl 0x8b0bfd30
	ctx.lr = 0x8B09FFF4;
	sub_8B0BFD30(ctx, base);
	// lwz r10,0(r29)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r29.u32 + 0);
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// mr r3,r29
	ctx.r3.u64 = ctx.r29.u64;
	// lwz r9,40(r10)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r10.u32 + 40);
	// mtctr r9
	ctx.ctr.u64 = ctx.r9.u64;
	// bctrl 
	ctx.lr = 0x8B0A000C;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// addi r1,r1,144
	ctx.r1.s64 = ctx.r1.s64 + 144;
	// b 0x8b0cba00
	__restgprlr_26(ctx, base);
	return;
loc_8B0A0014:
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// mr r4,r31
	ctx.r4.u64 = ctx.r31.u64;
	// addi r3,r11,16336
	ctx.r3.s64 = ctx.r11.s64 + 16336;
	// bl 0x8b0cea10
	ctx.lr = 0x8B0A0024;
	sub_8B0CEA10(ctx, base);
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// bne cr6,0x8b0a01ac
	if (!ctx.cr6.eq) goto loc_8B0A01AC;
	// mr r3,r26
	ctx.r3.u64 = ctx.r26.u64;
	// bl 0x8b0bf248
	ctx.lr = 0x8B0A0034;
	sub_8B0BF248(ctx, base);
	// mr r28,r3
	ctx.r28.u64 = ctx.r3.u64;
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0a01dc
	if (ctx.cr6.eq) goto loc_8B0A01DC;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// addi r5,r11,1791
	ctx.r5.s64 = ctx.r11.s64 + 1791;
	// addi r4,r10,3900
	ctx.r4.s64 = ctx.r10.s64 + 3900;
	// bl 0x8b0c1588
	ctx.lr = 0x8B0A0054;
	sub_8B0C1588(ctx, base);
	// lis r9,-29944
	ctx.r9.s64 = -1962409984;
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// addi r4,r9,16332
	ctx.r4.s64 = ctx.r9.s64 + 16332;
	// li r27,0
	ctx.r27.s64 = 0;
	// bl 0x8b0cea10
	ctx.lr = 0x8B0A0068;
	sub_8B0CEA10(ctx, base);
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// beq cr6,0x8b0a0128
	if (ctx.cr6.eq) goto loc_8B0A0128;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// addi r4,r11,3904
	ctx.r4.s64 = ctx.r11.s64 + 3904;
	// bl 0x8b0cea10
	ctx.lr = 0x8B0A0080;
	sub_8B0CEA10(ctx, base);
	// lis r11,-29938
	ctx.r11.s64 = -1962016768;
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// addi r30,r11,2964
	ctx.r30.s64 = ctx.r11.s64 + 2964;
	// bne cr6,0x8b0a00b4
	if (!ctx.cr6.eq) goto loc_8B0A00B4;
	// lis r11,-29938
	ctx.r11.s64 = -1962016768;
	// mr r5,r30
	ctx.r5.u64 = ctx.r30.u64;
	// addi r6,r11,4764
	ctx.r6.s64 = ctx.r11.s64 + 4764;
	// li r7,0
	ctx.r7.s64 = 0;
	// li r4,0
	ctx.r4.s64 = 0;
	// mr r3,r29
	ctx.r3.u64 = ctx.r29.u64;
	// bl 0x8b0ccd08
	ctx.lr = 0x8B0A00AC;
	sub_8B0CCD08(ctx, base);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// bne cr6,0x8b0a0128
	if (!ctx.cr6.eq) goto loc_8B0A0128;
loc_8B0A00B4:
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// addi r4,r11,16324
	ctx.r4.s64 = ctx.r11.s64 + 16324;
	// bl 0x8b0cea10
	ctx.lr = 0x8B0A00C4;
	sub_8B0CEA10(ctx, base);
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// bne cr6,0x8b0a00f0
	if (!ctx.cr6.eq) goto loc_8B0A00F0;
	// lis r11,-29938
	ctx.r11.s64 = -1962016768;
	// mr r5,r30
	ctx.r5.u64 = ctx.r30.u64;
	// addi r6,r11,2996
	ctx.r6.s64 = ctx.r11.s64 + 2996;
	// li r7,0
	ctx.r7.s64 = 0;
	// li r4,0
	ctx.r4.s64 = 0;
	// mr r3,r29
	ctx.r3.u64 = ctx.r29.u64;
	// bl 0x8b0ccd08
	ctx.lr = 0x8B0A00E8;
	sub_8B0CCD08(ctx, base);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// bne cr6,0x8b0a0128
	if (!ctx.cr6.eq) goto loc_8B0A0128;
loc_8B0A00F0:
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// addi r4,r11,3616
	ctx.r4.s64 = ctx.r11.s64 + 3616;
	// bl 0x8b0cea10
	ctx.lr = 0x8B0A0100;
	sub_8B0CEA10(ctx, base);
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// bne cr6,0x8b0a012c
	if (!ctx.cr6.eq) goto loc_8B0A012C;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// li r5,0
	ctx.r5.s64 = 0;
	// addi r4,r11,16316
	ctx.r4.s64 = ctx.r11.s64 + 16316;
	// mr r3,r28
	ctx.r3.u64 = ctx.r28.u64;
	// bl 0x8b0bfd30
	ctx.lr = 0x8B0A011C;
	sub_8B0BFD30(ctx, base);
	// ld r10,184(r29)
	ctx.r10.u64 = REX_LOAD_U64(ctx.r29.u32 + 184);
	// cmpld cr6,r10,r3
	ctx.cr6.compare<uint64_t>(ctx.r10.u64, ctx.r3.u64, ctx.xer);
	// bne cr6,0x8b0a012c
	if (!ctx.cr6.eq) goto loc_8B0A012C;
loc_8B0A0128:
	// li r27,1
	ctx.r27.s64 = 1;
loc_8B0A012C:
	// clrlwi r11,r27,24
	ctx.r11.u64 = ctx.r27.u32 & 0xFF;
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// beq cr6,0x8b0a01dc
	if (ctx.cr6.eq) goto loc_8B0A01DC;
	// li r3,36
	ctx.r3.s64 = 36;
	// bl 0x8b0bf448
	ctx.lr = 0x8B0A0140;
	sub_8B0BF448(ctx, base);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0a015c
	if (ctx.cr6.eq) goto loc_8B0A015C;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// addi r4,r11,16292
	ctx.r4.s64 = ctx.r11.s64 + 16292;
	// bl 0x8b0bf9f8
	ctx.lr = 0x8B0A0154;
	sub_8B0BF9F8(ctx, base);
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// b 0x8b0a0160
	goto loc_8B0A0160;
loc_8B0A015C:
	// li r31,0
	ctx.r31.s64 = 0;
loc_8B0A0160:
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// mr r5,r29
	ctx.r5.u64 = ctx.r29.u64;
	// addi r4,r11,16280
	ctx.r4.s64 = ctx.r11.s64 + 16280;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0c0250
	ctx.lr = 0x8B0A0174;
	sub_8B0C0250(ctx, base);
	// mr r4,r28
	ctx.r4.u64 = ctx.r28.u64;
	// mr r3,r26
	ctx.r3.u64 = ctx.r26.u64;
	// bl 0x8b0bf1a0
	ctx.lr = 0x8B0A0180;
	sub_8B0BF1A0(ctx, base);
	// mr r4,r28
	ctx.r4.u64 = ctx.r28.u64;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0bfc00
	ctx.lr = 0x8B0A018C;
	sub_8B0BFC00(ctx, base);
	// lwz r10,0(r29)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r29.u32 + 0);
	// mr r4,r31
	ctx.r4.u64 = ctx.r31.u64;
	// mr r3,r29
	ctx.r3.u64 = ctx.r29.u64;
	// lwz r9,48(r10)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r10.u32 + 48);
	// mtctr r9
	ctx.ctr.u64 = ctx.r9.u64;
	// bctrl 
	ctx.lr = 0x8B0A01A4;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// addi r1,r1,144
	ctx.r1.s64 = ctx.r1.s64 + 144;
	// b 0x8b0cba00
	__restgprlr_26(ctx, base);
	return;
loc_8B0A01AC:
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// mr r4,r31
	ctx.r4.u64 = ctx.r31.u64;
	// addi r3,r11,16260
	ctx.r3.s64 = ctx.r11.s64 + 16260;
	// bl 0x8b0cea10
	ctx.lr = 0x8B0A01BC;
	sub_8B0CEA10(ctx, base);
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// bne cr6,0x8b0a01dc
	if (!ctx.cr6.eq) goto loc_8B0A01DC;
	// lwz r11,0(r29)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r29.u32 + 0);
	// mr r4,r26
	ctx.r4.u64 = ctx.r26.u64;
	// mr r3,r29
	ctx.r3.u64 = ctx.r29.u64;
	// lwz r10,72(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 72);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B0A01DC;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
loc_8B0A01DC:
	// addi r1,r1,144
	ctx.r1.s64 = ctx.r1.s64 + 144;
	// b 0x8b0cba00
	__restgprlr_26(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0A0668) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9b8
	ctx.lr = 0x8B0A0670;
	__savegprlr_28(ctx, base);
	// stwu r1,-128(r1)
	ea = -128 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// mr r30,r3
	ctx.r30.u64 = ctx.r3.u64;
	// li r3,36
	ctx.r3.s64 = 36;
	// mr r29,r4
	ctx.r29.u64 = ctx.r4.u64;
	// bl 0x8b0bf448
	ctx.lr = 0x8B0A0684;
	sub_8B0BF448(ctx, base);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0a06a0
	if (ctx.cr6.eq) goto loc_8B0A06A0;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// addi r4,r11,4104
	ctx.r4.s64 = ctx.r11.s64 + 4104;
	// bl 0x8b0bf9f8
	ctx.lr = 0x8B0A0698;
	sub_8B0BF9F8(ctx, base);
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// b 0x8b0a06a4
	goto loc_8B0A06A4;
loc_8B0A06A0:
	// li r31,0
	ctx.r31.s64 = 0;
loc_8B0A06A4:
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// li r5,0
	ctx.r5.s64 = 0;
	// addi r28,r11,3616
	ctx.r28.s64 = ctx.r11.s64 + 3616;
	// mr r3,r29
	ctx.r3.u64 = ctx.r29.u64;
	// mr r4,r28
	ctx.r4.u64 = ctx.r28.u64;
	// bl 0x8b0bfd30
	ctx.lr = 0x8B0A06BC;
	sub_8B0BFD30(ctx, base);
	// mr r5,r3
	ctx.r5.u64 = ctx.r3.u64;
	// mr r4,r28
	ctx.r4.u64 = ctx.r28.u64;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0c0190
	ctx.lr = 0x8B0A06CC;
	sub_8B0C0190(ctx, base);
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// mr r5,r29
	ctx.r5.u64 = ctx.r29.u64;
	// addi r4,r10,16580
	ctx.r4.s64 = ctx.r10.s64 + 16580;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0c0250
	ctx.lr = 0x8B0A06E0;
	sub_8B0C0250(ctx, base);
	// lwz r9,0(r30)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r30.u32 + 0);
	// mr r4,r31
	ctx.r4.u64 = ctx.r31.u64;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// lwz r8,48(r9)
	ctx.r8.u64 = REX_LOAD_U32(ctx.r9.u32 + 48);
	// mtctr r8
	ctx.ctr.u64 = ctx.r8.u64;
	// bctrl 
	ctx.lr = 0x8B0A06F8;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// li r3,36
	ctx.r3.s64 = 36;
	// bl 0x8b0bf448
	ctx.lr = 0x8B0A0700;
	sub_8B0BF448(ctx, base);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0a071c
	if (ctx.cr6.eq) goto loc_8B0A071C;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// addi r4,r11,16552
	ctx.r4.s64 = ctx.r11.s64 + 16552;
	// bl 0x8b0bf9f8
	ctx.lr = 0x8B0A0714;
	sub_8B0BF9F8(ctx, base);
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// b 0x8b0a0720
	goto loc_8B0A0720;
loc_8B0A071C:
	// li r31,0
	ctx.r31.s64 = 0;
loc_8B0A0720:
	// li r5,1
	ctx.r5.s64 = 1;
	// mr r4,r29
	ctx.r4.u64 = ctx.r29.u64;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0c0668
	ctx.lr = 0x8B0A0730;
	sub_8B0C0668(ctx, base);
	// mr r4,r31
	ctx.r4.u64 = ctx.r31.u64;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// bl 0x8b09ff28
	ctx.lr = 0x8B0A073C;
	sub_8B09FF28(ctx, base);
	// cmplwi cr6,r31,0
	ctx.cr6.compare<uint32_t>(ctx.r31.u32, 0, ctx.xer);
	// beq cr6,0x8b0a074c
	if (ctx.cr6.eq) goto loc_8B0A074C;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0c04f0
	ctx.lr = 0x8B0A074C;
	sub_8B0C04F0(ctx, base);
loc_8B0A074C:
	// addi r1,r1,128
	ctx.r1.s64 = ctx.r1.s64 + 128;
	// b 0x8b0cba08
	__restgprlr_28(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0A09F0) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// std r30,-24(r1)
	REX_STORE_U64(ctx.r1.u32 + -24, ctx.r30.u64);
	// std r31,-16(r1)
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.r31.u64);
	// stwu r1,-112(r1)
	ea = -112 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lwz r11,248(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 248);
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// mr r30,r4
	ctx.r30.u64 = ctx.r4.u64;
	// cmpwi cr6,r11,6
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 6, ctx.xer);
	// beq cr6,0x8b0a0a58
	if (ctx.cr6.eq) goto loc_8B0A0A58;
	// lwz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r10,28(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 28);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B0A0A28;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// cmpld cr6,r30,r3
	ctx.cr6.compare<uint64_t>(ctx.r30.u64, ctx.r3.u64, ctx.xer);
	// mr r4,r30
	ctx.r4.u64 = ctx.r30.u64;
	// beq cr6,0x8b0a0a44
	if (ctx.cr6.eq) goto loc_8B0A0A44;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// addi r3,r11,16888
	ctx.r3.s64 = ctx.r11.s64 + 16888;
	// bl 0x8b0df298
	ctx.lr = 0x8B0A0A40;
	sub_8B0DF298(ctx, base);
	// b 0x8b0a0a58
	goto loc_8B0A0A58;
loc_8B0A0A44:
	// lwz r11,0(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 0);
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// lwz r10,40(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 40);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B0A0A58;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
loc_8B0A0A58:
	// addi r1,r1,112
	ctx.r1.s64 = ctx.r1.s64 + 112;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// ld r30,-24(r1)
	ctx.r30.u64 = REX_LOAD_U64(ctx.r1.u32 + -24);
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0A0D18) {
	REX_FUNC_PROLOGUE();
	PPCRegister temp{};
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// std r31,-16(r1)
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.r31.u64);
	// stfd f30,-32(r1)
	ctx.fpscr.disableFlushMode();
	REX_STORE_U64(ctx.r1.u32 + -32, ctx.f30.u64);
	// stfd f31,-24(r1)
	REX_STORE_U64(ctx.r1.u32 + -24, ctx.f31.u64);
	// stwu r1,-112(r1)
	ea = -112 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lis r11,-29938
	ctx.r11.s64 = -1962016768;
	// addi r10,r11,19100
	ctx.r10.s64 = ctx.r11.s64 + 19100;
	// lwz r11,12(r10)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r10.u32 + 12);
	// cmpwi cr6,r11,0
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// bne cr6,0x8b0a0db0
	if (!ctx.cr6.eq) goto loc_8B0A0DB0;
	// lis r11,-29938
	ctx.r11.s64 = -1962016768;
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// addi r9,r11,19188
	ctx.r9.s64 = ctx.r11.s64 + 19188;
	// lfs f31,8492(r10)
	temp.u32 = REX_LOAD_U32(ctx.r10.u32 + 8492);
	ctx.f31.f64 = double(temp.f32);
	// lwz r11,28(r9)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r9.u32 + 28);
	// lfs f30,44(r11)
	temp.u32 = REX_LOAD_U32(ctx.r11.u32 + 44);
	ctx.f30.f64 = double(temp.f32);
	// fcmpu cr6,f30,f31
	ctx.cr6.compare(ctx.f30.f64, ctx.f31.f64);
	// bgt cr6,0x8b0a0d74
	if (ctx.cr6.gt) goto loc_8B0A0D74;
	// lis r11,-29938
	ctx.r11.s64 = -1962016768;
	// li r3,1
	ctx.r3.s64 = 1;
	// stfs f31,19068(r11)
	temp.f32 = float(ctx.f31.f64);
	REX_STORE_U32(ctx.r11.u32 + 19068, temp.u32);
	// b 0x8b0a0db4
	goto loc_8B0A0DB4;
loc_8B0A0D74:
	// lis r31,-29938
	ctx.r31.s64 = -1962016768;
	// lfs f0,19068(r31)
	ctx.fpscr.disableFlushMode();
	temp.u32 = REX_LOAD_U32(ctx.r31.u32 + 19068);
	ctx.f0.f64 = double(temp.f32);
	// fcmpu cr6,f0,f31
	ctx.cr6.compare(ctx.f0.f64, ctx.f31.f64);
	// ble cr6,0x8b0a0da0
	if (!ctx.cr6.gt) goto loc_8B0A0DA0;
	// bl 0x8b0df2f8
	ctx.lr = 0x8B0A0D88;
	sub_8B0DF2F8(ctx, base);
	// lfs f0,19068(r31)
	ctx.fpscr.disableFlushMode();
	temp.u32 = REX_LOAD_U32(ctx.r31.u32 + 19068);
	ctx.f0.f64 = double(temp.f32);
	// fcmpu cr6,f1,f0
	ctx.cr6.compare(ctx.f1.f64, ctx.f0.f64);
	// blt cr6,0x8b0a0db0
	if (ctx.cr6.lt) goto loc_8B0A0DB0;
	// stfs f31,19068(r31)
	temp.f32 = float(ctx.f31.f64);
	REX_STORE_U32(ctx.r31.u32 + 19068, temp.u32);
	// li r3,1
	ctx.r3.s64 = 1;
	// b 0x8b0a0db4
	goto loc_8B0A0DB4;
loc_8B0A0DA0:
	// bl 0x8b0df2f8
	ctx.lr = 0x8B0A0DA4;
	sub_8B0DF2F8(ctx, base);
	// fadd f0,f1,f30
	ctx.fpscr.disableFlushMode();
	ctx.f0.f64 = ctx.f1.f64 + ctx.f30.f64;
	// frsp f0,f0
	ctx.f0.f64 = double(float(ctx.f0.f64));
	// stfs f0,19068(r31)
	temp.f32 = float(ctx.f0.f64);
	REX_STORE_U32(ctx.r31.u32 + 19068, temp.u32);
loc_8B0A0DB0:
	// li r3,0
	ctx.r3.s64 = 0;
loc_8B0A0DB4:
	// addi r1,r1,112
	ctx.r1.s64 = ctx.r1.s64 + 112;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// lfd f30,-32(r1)
	ctx.fpscr.disableFlushMode();
	ctx.f30.u64 = REX_LOAD_U64(ctx.r1.u32 + -32);
	// lfd f31,-24(r1)
	ctx.f31.u64 = REX_LOAD_U64(ctx.r1.u32 + -24);
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0A1578) {
	REX_FUNC_PROLOGUE();
	PPCRegister temp{};
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb994
	ctx.lr = 0x8B0A1580;
	__savegprlr_19(ctx, base);
	// stwu r1,-960(r1)
	ea = -960 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// mr r24,r4
	ctx.r24.u64 = ctx.r4.u64;
	// li r5,0
	ctx.r5.s64 = 0;
	// addi r4,r11,3636
	ctx.r4.s64 = ctx.r11.s64 + 3636;
	// mr r19,r3
	ctx.r19.u64 = ctx.r3.u64;
	// lwz r3,180(r3)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r3.u32 + 180);
	// bl 0x8b0bfa88
	ctx.lr = 0x8B0A15A0;
	sub_8B0BFA88(ctx, base);
	// mr r29,r3
	ctx.r29.u64 = ctx.r3.u64;
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0a1684
	if (ctx.cr6.eq) goto loc_8B0A1684;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// li r5,0
	ctx.r5.s64 = 0;
	// addi r22,r11,3624
	ctx.r22.s64 = ctx.r11.s64 + 3624;
	// mr r4,r22
	ctx.r4.u64 = ctx.r22.u64;
	// bl 0x8b0bfc38
	ctx.lr = 0x8B0A15C0;
	sub_8B0BFC38(ctx, base);
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// mr r26,r3
	ctx.r26.u64 = ctx.r3.u64;
	// addi r23,r11,3592
	ctx.r23.s64 = ctx.r11.s64 + 3592;
	// li r5,0
	ctx.r5.s64 = 0;
	// mr r4,r23
	ctx.r4.u64 = ctx.r23.u64;
	// mr r3,r29
	ctx.r3.u64 = ctx.r29.u64;
	// bl 0x8b0bfc38
	ctx.lr = 0x8B0A15DC;
	sub_8B0BFC38(ctx, base);
	// mr r20,r3
	ctx.r20.u64 = ctx.r3.u64;
	// li r30,0
	ctx.r30.s64 = 0;
	// cmpwi cr6,r26,0
	ctx.cr6.compare<int32_t>(ctx.r26.s32, 0, ctx.xer);
	// ble cr6,0x8b0a1684
	if (!ctx.cr6.gt) goto loc_8B0A1684;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// addi r28,r11,17184
	ctx.r28.s64 = ctx.r11.s64 + 17184;
	// addi r25,r10,3580
	ctx.r25.s64 = ctx.r10.s64 + 3580;
loc_8B0A15FC:
	// mr r4,r25
	ctx.r4.u64 = ctx.r25.u64;
	// mr r5,r30
	ctx.r5.u64 = ctx.r30.u64;
	// addi r3,r1,592
	ctx.r3.s64 = ctx.r1.s64 + 592;
	// bl 0x8b090220
	ctx.lr = 0x8B0A160C;
	sub_8B090220(ctx, base);
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// li r5,0
	ctx.r5.s64 = 0;
	// mr r3,r29
	ctx.r3.u64 = ctx.r29.u64;
	// bl 0x8b0bfa88
	ctx.lr = 0x8B0A161C;
	sub_8B0BFA88(ctx, base);
	// mr r27,r3
	ctx.r27.u64 = ctx.r3.u64;
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0a1678
	if (ctx.cr6.eq) goto loc_8B0A1678;
	// mr r4,r23
	ctx.r4.u64 = ctx.r23.u64;
	// li r5,0
	ctx.r5.s64 = 0;
	// bl 0x8b0bfc38
	ctx.lr = 0x8B0A1634;
	sub_8B0BFC38(ctx, base);
	// mr r21,r3
	ctx.r21.u64 = ctx.r3.u64;
	// li r31,0
	ctx.r31.s64 = 0;
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// ble cr6,0x8b0a1678
	if (!ctx.cr6.gt) goto loc_8B0A1678;
loc_8B0A1644:
	// mr r4,r28
	ctx.r4.u64 = ctx.r28.u64;
	// mr r5,r31
	ctx.r5.u64 = ctx.r31.u64;
	// addi r3,r1,80
	ctx.r3.s64 = ctx.r1.s64 + 80;
	// bl 0x8b090220
	ctx.lr = 0x8B0A1654;
	sub_8B090220(ctx, base);
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// li r5,0
	ctx.r5.s64 = 0;
	// mr r3,r27
	ctx.r3.u64 = ctx.r27.u64;
	// bl 0x8b0bfd30
	ctx.lr = 0x8B0A1664;
	sub_8B0BFD30(ctx, base);
	// cmpld cr6,r3,r24
	ctx.cr6.compare<uint64_t>(ctx.r3.u64, ctx.r24.u64, ctx.xer);
	// beq cr6,0x8b0a1690
	if (ctx.cr6.eq) goto loc_8B0A1690;
	// addi r31,r31,1
	ctx.r31.s64 = ctx.r31.s64 + 1;
	// cmpw cr6,r31,r21
	ctx.cr6.compare<int32_t>(ctx.r31.s32, ctx.r21.s32, ctx.xer);
	// blt cr6,0x8b0a1644
	if (ctx.cr6.lt) goto loc_8B0A1644;
loc_8B0A1678:
	// addi r30,r30,1
	ctx.r30.s64 = ctx.r30.s64 + 1;
	// cmpw cr6,r30,r26
	ctx.cr6.compare<int32_t>(ctx.r30.s32, ctx.r26.s32, ctx.xer);
	// blt cr6,0x8b0a15fc
	if (ctx.cr6.lt) goto loc_8B0A15FC;
loc_8B0A1684:
	// li r3,0
	ctx.r3.s64 = 0;
	// addi r1,r1,960
	ctx.r1.s64 = ctx.r1.s64 + 960;
	// b 0x8b0cb9e4
	__restgprlr_19(ctx, base);
	return;
loc_8B0A1690:
	// mr r6,r30
	ctx.r6.u64 = ctx.r30.u64;
	// lwz r3,180(r19)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r19.u32 + 180);
	// mr r5,r30
	ctx.r5.u64 = ctx.r30.u64;
	// addi r4,r19,8
	ctx.r4.s64 = ctx.r19.s64 + 8;
	// bl 0x8b09b4c8
	ctx.lr = 0x8B0A16A4;
	sub_8B09B4C8(ctx, base);
	// lwz r11,0(r19)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r19.u32 + 0);
	// li r5,0
	ctx.r5.s64 = 0;
	// mr r4,r27
	ctx.r4.u64 = ctx.r27.u64;
	// mr r3,r19
	ctx.r3.u64 = ctx.r19.u64;
	// lwz r10,64(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 64);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B0A16C0;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// mr r4,r27
	ctx.r4.u64 = ctx.r27.u64;
	// mr r3,r29
	ctx.r3.u64 = ctx.r29.u64;
	// bl 0x8b0bf1a0
	ctx.lr = 0x8B0A16CC;
	sub_8B0BF1A0(ctx, base);
	// addi r31,r30,1
	ctx.r31.s64 = ctx.r30.s64 + 1;
	// cmpw cr6,r31,r26
	ctx.cr6.compare<int32_t>(ctx.r31.s32, ctx.r26.s32, ctx.xer);
	// bge cr6,0x8b0a172c
	if (!ctx.cr6.lt) goto loc_8B0A172C;
loc_8B0A16D8:
	// mr r4,r25
	ctx.r4.u64 = ctx.r25.u64;
	// mr r5,r31
	ctx.r5.u64 = ctx.r31.u64;
	// addi r3,r1,80
	ctx.r3.s64 = ctx.r1.s64 + 80;
	// bl 0x8b090220
	ctx.lr = 0x8B0A16E8;
	sub_8B090220(ctx, base);
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// li r5,0
	ctx.r5.s64 = 0;
	// mr r3,r29
	ctx.r3.u64 = ctx.r29.u64;
	// bl 0x8b0bfa88
	ctx.lr = 0x8B0A16F8;
	sub_8B0BFA88(ctx, base);
	// mr r30,r3
	ctx.r30.u64 = ctx.r3.u64;
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0a1720
	if (ctx.cr6.eq) goto loc_8B0A1720;
	// mr r4,r25
	ctx.r4.u64 = ctx.r25.u64;
	// addi r5,r31,-1
	ctx.r5.s64 = ctx.r31.s64 + -1;
	// addi r3,r1,336
	ctx.r3.s64 = ctx.r1.s64 + 336;
	// bl 0x8b090220
	ctx.lr = 0x8B0A1714;
	sub_8B090220(ctx, base);
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// bl 0x8b0bf328
	ctx.lr = 0x8B0A1720;
	sub_8B0BF328(ctx, base);
loc_8B0A1720:
	// addi r31,r31,1
	ctx.r31.s64 = ctx.r31.s64 + 1;
	// cmpw cr6,r31,r26
	ctx.cr6.compare<int32_t>(ctx.r31.s32, ctx.r26.s32, ctx.xer);
	// blt cr6,0x8b0a16d8
	if (ctx.cr6.lt) goto loc_8B0A16D8;
loc_8B0A172C:
	// addi r11,r26,-1
	ctx.r11.s64 = ctx.r26.s64 + -1;
	// li r10,0
	ctx.r10.s64 = 0;
	// mr r4,r22
	ctx.r4.u64 = ctx.r22.u64;
	// xoris r9,r10,32768
	ctx.r9.u64 = ctx.r10.u64 ^ 2147483648;
	// subf r8,r10,r11
	ctx.r8.u64 = ctx.r11.u64 - ctx.r10.u64;
	// mr r3,r29
	ctx.r3.u64 = ctx.r29.u64;
	// addc r7,r8,r9
	ctx.xer.ca = ctx.r8.u32 + ctx.r9.u32 < ctx.r8.u32;
	ctx.r7.u64 = ctx.r8.u64 + ctx.r9.u64;
	// subfe r5,r6,r6
	temp.u8 = (~ctx.r6.u32 + ctx.r6.u32 < ~ctx.r6.u32) | (~ctx.r6.u32 + ctx.r6.u32 + ctx.xer.ca < ctx.xer.ca);
	ctx.r5.u64 = ~ctx.r6.u64 + ctx.r6.u64 + ctx.xer.ca;
	ctx.xer.ca = temp.u8;
	// and r5,r5,r11
	ctx.r5.u64 = ctx.r5.u64 & ctx.r11.u64;
	// bl 0x8b0c0148
	ctx.lr = 0x8B0A1754;
	sub_8B0C0148(ctx, base);
	// li r11,0
	ctx.r11.s64 = 0;
	// subf r10,r21,r20
	ctx.r10.u64 = ctx.r20.u64 - ctx.r21.u64;
	// xoris r9,r11,32768
	ctx.r9.u64 = ctx.r11.u64 ^ 2147483648;
	// subf r8,r11,r10
	ctx.r8.u64 = ctx.r10.u64 - ctx.r11.u64;
	// mr r4,r23
	ctx.r4.u64 = ctx.r23.u64;
	// addc r7,r8,r9
	ctx.xer.ca = ctx.r8.u32 + ctx.r9.u32 < ctx.r8.u32;
	ctx.r7.u64 = ctx.r8.u64 + ctx.r9.u64;
	// mr r3,r29
	ctx.r3.u64 = ctx.r29.u64;
	// subfe r5,r6,r6
	temp.u8 = (~ctx.r6.u32 + ctx.r6.u32 < ~ctx.r6.u32) | (~ctx.r6.u32 + ctx.r6.u32 + ctx.xer.ca < ctx.xer.ca);
	ctx.r5.u64 = ~ctx.r6.u64 + ctx.r6.u64 + ctx.xer.ca;
	ctx.xer.ca = temp.u8;
	// and r5,r5,r10
	ctx.r5.u64 = ctx.r5.u64 & ctx.r10.u64;
	// bl 0x8b0c0148
	ctx.lr = 0x8B0A177C;
	sub_8B0C0148(ctx, base);
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// lis r9,-29944
	ctx.r9.s64 = -1962409984;
	// lis r8,-29944
	ctx.r8.s64 = -1962409984;
	// lis r7,-29944
	ctx.r7.s64 = -1962409984;
	// li r29,0
	ctx.r29.s64 = 0;
	// addi r24,r11,17348
	ctx.r24.s64 = ctx.r11.s64 + 17348;
	// addi r23,r10,16580
	ctx.r23.s64 = ctx.r10.s64 + 16580;
	// addi r22,r9,4120
	ctx.r22.s64 = ctx.r9.s64 + 4120;
	// addi r26,r8,3616
	ctx.r26.s64 = ctx.r8.s64 + 3616;
	// addi r25,r7,3604
	ctx.r25.s64 = ctx.r7.s64 + 3604;
loc_8B0A17A8:
	// mr r4,r25
	ctx.r4.u64 = ctx.r25.u64;
	// mr r5,r29
	ctx.r5.u64 = ctx.r29.u64;
	// addi r3,r1,336
	ctx.r3.s64 = ctx.r1.s64 + 336;
	// bl 0x8b090220
	ctx.lr = 0x8B0A17B8;
	sub_8B090220(ctx, base);
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// li r5,0
	ctx.r5.s64 = 0;
	// mr r3,r27
	ctx.r3.u64 = ctx.r27.u64;
	// bl 0x8b0bfa88
	ctx.lr = 0x8B0A17C8;
	sub_8B0BFA88(ctx, base);
	// mr r4,r26
	ctx.r4.u64 = ctx.r26.u64;
	// li r5,0
	ctx.r5.s64 = 0;
	// mr r30,r3
	ctx.r30.u64 = ctx.r3.u64;
	// bl 0x8b0bfd30
	ctx.lr = 0x8B0A17D8;
	sub_8B0BFD30(ctx, base);
	// mr r28,r3
	ctx.r28.u64 = ctx.r3.u64;
	// li r3,36
	ctx.r3.s64 = 36;
	// bl 0x8b0bf448
	ctx.lr = 0x8B0A17E4;
	sub_8B0BF448(ctx, base);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0a17fc
	if (ctx.cr6.eq) goto loc_8B0A17FC;
	// mr r4,r22
	ctx.r4.u64 = ctx.r22.u64;
	// bl 0x8b0bf9f8
	ctx.lr = 0x8B0A17F4;
	sub_8B0BF9F8(ctx, base);
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// b 0x8b0a1800
	goto loc_8B0A1800;
loc_8B0A17FC:
	// li r31,0
	ctx.r31.s64 = 0;
loc_8B0A1800:
	// mr r4,r26
	ctx.r4.u64 = ctx.r26.u64;
	// mr r5,r28
	ctx.r5.u64 = ctx.r28.u64;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0c0190
	ctx.lr = 0x8B0A1810;
	sub_8B0C0190(ctx, base);
	// cmplwi cr6,r30,0
	ctx.cr6.compare<uint32_t>(ctx.r30.u32, 0, ctx.xer);
	// beq cr6,0x8b0a1838
	if (ctx.cr6.eq) goto loc_8B0A1838;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// bl 0x8b0c0298
	ctx.lr = 0x8B0A1820;
	sub_8B0C0298(ctx, base);
	// mr r4,r23
	ctx.r4.u64 = ctx.r23.u64;
	// mr r30,r3
	ctx.r30.u64 = ctx.r3.u64;
	// bl 0x8b0bf328
	ctx.lr = 0x8B0A182C;
	sub_8B0BF328(ctx, base);
	// mr r4,r30
	ctx.r4.u64 = ctx.r30.u64;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0bfc00
	ctx.lr = 0x8B0A1838;
	sub_8B0BFC00(ctx, base);
loc_8B0A1838:
	// mr r3,r27
	ctx.r3.u64 = ctx.r27.u64;
	// bl 0x8b0c0298
	ctx.lr = 0x8B0A1840;
	sub_8B0C0298(ctx, base);
	// mr r4,r24
	ctx.r4.u64 = ctx.r24.u64;
	// mr r30,r3
	ctx.r30.u64 = ctx.r3.u64;
	// bl 0x8b0bf328
	ctx.lr = 0x8B0A184C;
	sub_8B0BF328(ctx, base);
	// mr r4,r30
	ctx.r4.u64 = ctx.r30.u64;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0bfc00
	ctx.lr = 0x8B0A1858;
	sub_8B0BFC00(ctx, base);
	// lwz r11,0(r19)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r19.u32 + 0);
	// mr r4,r31
	ctx.r4.u64 = ctx.r31.u64;
	// mr r3,r19
	ctx.r3.u64 = ctx.r19.u64;
	// lwz r10,48(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 48);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B0A1870;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// addi r29,r29,1
	ctx.r29.s64 = ctx.r29.s64 + 1;
	// cmpw cr6,r29,r21
	ctx.cr6.compare<int32_t>(ctx.r29.s32, ctx.r21.s32, ctx.xer);
	// blt cr6,0x8b0a17a8
	if (ctx.cr6.lt) goto loc_8B0A17A8;
	// mr r3,r27
	ctx.r3.u64 = ctx.r27.u64;
	// bl 0x8b0c04f0
	ctx.lr = 0x8B0A1884;
	sub_8B0C04F0(ctx, base);
	// li r3,1
	ctx.r3.s64 = 1;
	// addi r1,r1,960
	ctx.r1.s64 = ctx.r1.s64 + 960;
	// b 0x8b0cb9e4
	__restgprlr_19(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0A25D0) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// std r31,-16(r1)
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.r31.u64);
	// stwu r1,-96(r1)
	ea = -96 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// clrlwi r10,r4,31
	ctx.r10.u64 = ctx.r4.u32 & 0x1;
	// addi r9,r11,15732
	ctx.r9.s64 = ctx.r11.s64 + 15732;
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// cmplwi cr6,r10,0
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 0, ctx.xer);
	// stw r9,0(r3)
	REX_STORE_U32(ctx.r3.u32 + 0, ctx.r9.u32);
	// beq cr6,0x8b0a2604
	if (ctx.cr6.eq) goto loc_8B0A2604;
	// bl 0x8b090020
	ctx.lr = 0x8B0A2600;
	sub_8B090020(ctx, base);
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
loc_8B0A2604:
	// addi r1,r1,96
	ctx.r1.s64 = ctx.r1.s64 + 96;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0A2740) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9ac
	ctx.lr = 0x8B0A2748;
	__savegprlr_25(ctx, base);
	// stwu r1,-400(r1)
	ea = -400 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// mr r26,r4
	ctx.r26.u64 = ctx.r4.u64;
	// li r5,0
	ctx.r5.s64 = 0;
	// addi r4,r11,4888
	ctx.r4.s64 = ctx.r11.s64 + 4888;
	// mr r30,r3
	ctx.r30.u64 = ctx.r3.u64;
	// lwz r3,180(r3)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r3.u32 + 180);
	// bl 0x8b0bfc38
	ctx.lr = 0x8B0A2768;
	sub_8B0BFC38(ctx, base);
	// mr r25,r3
	ctx.r25.u64 = ctx.r3.u64;
	// li r29,0
	ctx.r29.s64 = 0;
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// ble cr6,0x8b0a27fc
	if (!ctx.cr6.gt) goto loc_8B0A27FC;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// addi r28,r11,16356
	ctx.r28.s64 = ctx.r11.s64 + 16356;
	// addi r27,r10,17200
	ctx.r27.s64 = ctx.r10.s64 + 17200;
loc_8B0A2788:
	// mr r4,r27
	ctx.r4.u64 = ctx.r27.u64;
	// mr r5,r29
	ctx.r5.u64 = ctx.r29.u64;
	// addi r3,r1,80
	ctx.r3.s64 = ctx.r1.s64 + 80;
	// bl 0x8b090220
	ctx.lr = 0x8B0A2798;
	sub_8B090220(ctx, base);
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// li r5,0
	ctx.r5.s64 = 0;
	// lwz r3,180(r30)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r30.u32 + 180);
	// bl 0x8b0bfa88
	ctx.lr = 0x8B0A27A8;
	sub_8B0BFA88(ctx, base);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0a27f0
	if (ctx.cr6.eq) goto loc_8B0A27F0;
	// mr r4,r28
	ctx.r4.u64 = ctx.r28.u64;
	// li r5,0
	ctx.r5.s64 = 0;
	// bl 0x8b0bfd30
	ctx.lr = 0x8B0A27BC;
	sub_8B0BFD30(ctx, base);
	// ld r11,184(r30)
	ctx.r11.u64 = REX_LOAD_U64(ctx.r30.u32 + 184);
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// cmpld cr6,r3,r11
	ctx.cr6.compare<uint64_t>(ctx.r3.u64, ctx.r11.u64, ctx.xer);
	// beq cr6,0x8b0a2808
	if (ctx.cr6.eq) goto loc_8B0A2808;
	// cmpldi cr6,r26,0
	ctx.cr6.compare<uint64_t>(ctx.r26.u64, 0, ctx.xer);
	// beq cr6,0x8b0a27dc
	if (ctx.cr6.eq) goto loc_8B0A27DC;
	// cmpld cr6,r3,r26
	ctx.cr6.compare<uint64_t>(ctx.r3.u64, ctx.r26.u64, ctx.xer);
	// beq cr6,0x8b0a2814
	if (ctx.cr6.eq) goto loc_8B0A2814;
loc_8B0A27DC:
	// mr r4,r31
	ctx.r4.u64 = ctx.r31.u64;
	// lwz r3,152(r30)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r30.u32 + 152);
	// bl 0x8b0aa500
	ctx.lr = 0x8B0A27E8;
	sub_8B0AA500(ctx, base);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// bne cr6,0x8b0a2814
	if (!ctx.cr6.eq) goto loc_8B0A2814;
loc_8B0A27F0:
	// addi r29,r29,1
	ctx.r29.s64 = ctx.r29.s64 + 1;
	// cmpw cr6,r29,r25
	ctx.cr6.compare<int32_t>(ctx.r29.s32, ctx.r25.s32, ctx.xer);
	// blt cr6,0x8b0a2788
	if (ctx.cr6.lt) goto loc_8B0A2788;
loc_8B0A27FC:
	// ld r3,184(r30)
	ctx.r3.u64 = REX_LOAD_U64(ctx.r30.u32 + 184);
	// addi r1,r1,400
	ctx.r1.s64 = ctx.r1.s64 + 400;
	// b 0x8b0cb9fc
	__restgprlr_25(ctx, base);
	return;
loc_8B0A2808:
	// mr r3,r11
	ctx.r3.u64 = ctx.r11.u64;
	// addi r1,r1,400
	ctx.r1.s64 = ctx.r1.s64 + 400;
	// b 0x8b0cb9fc
	__restgprlr_25(ctx, base);
	return;
loc_8B0A2814:
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// addi r1,r1,400
	ctx.r1.s64 = ctx.r1.s64 + 400;
	// b 0x8b0cb9fc
	__restgprlr_25(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0A2CA0) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb980
	ctx.lr = 0x8B0A2CA8;
	__savegprlr_14(ctx, base);
	// stwu r1,-752(r1)
	ea = -752 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// mr r28,r3
	ctx.r28.u64 = ctx.r3.u64;
	// mr r31,r4
	ctx.r31.u64 = ctx.r4.u64;
	// mr r3,r4
	ctx.r3.u64 = ctx.r4.u64;
	// addi r4,r11,17076
	ctx.r4.s64 = ctx.r11.s64 + 17076;
	// li r5,0
	ctx.r5.s64 = 0;
	// bl 0x8b0c1588
	ctx.lr = 0x8B0A2CC8;
	sub_8B0C1588(ctx, base);
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// mr r30,r3
	ctx.r30.u64 = ctx.r3.u64;
	// addi r4,r10,4952
	ctx.r4.s64 = ctx.r10.s64 + 4952;
	// li r5,0
	ctx.r5.s64 = 0;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0bfa88
	ctx.lr = 0x8B0A2CE0;
	sub_8B0BFA88(ctx, base);
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0a2f08
	if (ctx.cr6.eq) goto loc_8B0A2F08;
	// cmplwi cr6,r30,0
	ctx.cr6.compare<uint32_t>(ctx.r30.u32, 0, ctx.xer);
	// bne cr6,0x8b0a2f08
	if (!ctx.cr6.eq) goto loc_8B0A2F08;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// li r5,0
	ctx.r5.s64 = 0;
	// addi r4,r11,3636
	ctx.r4.s64 = ctx.r11.s64 + 3636;
	// bl 0x8b0bfa88
	ctx.lr = 0x8B0A2D04;
	sub_8B0BFA88(ctx, base);
	// mr r14,r3
	ctx.r14.u64 = ctx.r3.u64;
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0a2f08
	if (ctx.cr6.eq) goto loc_8B0A2F08;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lwz r3,180(r28)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r28.u32 + 180);
	// li r5,0
	ctx.r5.s64 = 0;
	// addi r29,r11,4888
	ctx.r29.s64 = ctx.r11.s64 + 4888;
	// mr r4,r29
	ctx.r4.u64 = ctx.r29.u64;
	// bl 0x8b0bfc38
	ctx.lr = 0x8B0A2D28;
	sub_8B0BFC38(ctx, base);
	// mr r30,r3
	ctx.r30.u64 = ctx.r3.u64;
	// lwz r3,180(r28)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r28.u32 + 180);
	// bl 0x8b0c0440
	ctx.lr = 0x8B0A2D34;
	sub_8B0C0440(ctx, base);
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0beee8
	ctx.lr = 0x8B0A2D3C;
	sub_8B0BEEE8(ctx, base);
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// lwz r3,180(r28)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r28.u32 + 180);
	// bl 0x8b0bf328
	ctx.lr = 0x8B0A2D48;
	sub_8B0BF328(ctx, base);
	// li r5,1
	ctx.r5.s64 = 1;
	// mr r4,r31
	ctx.r4.u64 = ctx.r31.u64;
	// lwz r3,180(r28)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r28.u32 + 180);
	// bl 0x8b0c0668
	ctx.lr = 0x8B0A2D58;
	sub_8B0C0668(ctx, base);
	// li r6,-1
	ctx.r6.s64 = -1;
	// mr r5,r30
	ctx.r5.u64 = ctx.r30.u64;
	// addi r4,r28,8
	ctx.r4.s64 = ctx.r28.s64 + 8;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b09b4b0
	ctx.lr = 0x8B0A2D6C;
	sub_8B09B4B0(ctx, base);
	// mr r4,r29
	ctx.r4.u64 = ctx.r29.u64;
	// li r5,0
	ctx.r5.s64 = 0;
	// lwz r3,180(r28)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r28.u32 + 180);
	// bl 0x8b0bfc38
	ctx.lr = 0x8B0A2D7C;
	sub_8B0BFC38(ctx, base);
	// mr r15,r3
	ctx.r15.u64 = ctx.r3.u64;
	// mr r16,r30
	ctx.r16.u64 = ctx.r30.u64;
	// cmpw cr6,r30,r3
	ctx.cr6.compare<int32_t>(ctx.r30.s32, ctx.r3.s32, ctx.xer);
	// bge cr6,0x8b0a2ef4
	if (!ctx.cr6.lt) goto loc_8B0A2EF4;
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// lis r9,-29944
	ctx.r9.s64 = -1962409984;
	// lis r8,-29944
	ctx.r8.s64 = -1962409984;
	// lis r7,-29944
	ctx.r7.s64 = -1962409984;
	// lis r6,-29944
	ctx.r6.s64 = -1962409984;
	// lis r5,-29944
	ctx.r5.s64 = -1962409984;
	// lis r4,-29944
	ctx.r4.s64 = -1962409984;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// addi r24,r10,16580
	ctx.r24.s64 = ctx.r10.s64 + 16580;
	// addi r23,r9,4072
	ctx.r23.s64 = ctx.r9.s64 + 4072;
	// addi r22,r8,17680
	ctx.r22.s64 = ctx.r8.s64 + 17680;
	// addi r19,r7,4104
	ctx.r19.s64 = ctx.r7.s64 + 4104;
	// addi r27,r6,3616
	ctx.r27.s64 = ctx.r6.s64 + 3616;
	// addi r21,r5,3604
	ctx.r21.s64 = ctx.r5.s64 + 3604;
	// addi r18,r4,3592
	ctx.r18.s64 = ctx.r4.s64 + 3592;
	// addi r17,r11,3580
	ctx.r17.s64 = ctx.r11.s64 + 3580;
loc_8B0A2DCC:
	// mr r4,r17
	ctx.r4.u64 = ctx.r17.u64;
	// mr r5,r16
	ctx.r5.u64 = ctx.r16.u64;
	// addi r3,r1,80
	ctx.r3.s64 = ctx.r1.s64 + 80;
	// bl 0x8b090220
	ctx.lr = 0x8B0A2DDC;
	sub_8B090220(ctx, base);
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// li r5,0
	ctx.r5.s64 = 0;
	// mr r3,r14
	ctx.r3.u64 = ctx.r14.u64;
	// bl 0x8b0bfa88
	ctx.lr = 0x8B0A2DEC;
	sub_8B0BFA88(ctx, base);
	// mr r25,r3
	ctx.r25.u64 = ctx.r3.u64;
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0a2ee8
	if (ctx.cr6.eq) goto loc_8B0A2EE8;
	// lwz r11,0(r28)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r28.u32 + 0);
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// li r5,1
	ctx.r5.s64 = 1;
	// mr r3,r28
	ctx.r3.u64 = ctx.r28.u64;
	// lwz r10,64(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 64);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B0A2E14;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// mr r4,r18
	ctx.r4.u64 = ctx.r18.u64;
	// li r5,0
	ctx.r5.s64 = 0;
	// mr r3,r25
	ctx.r3.u64 = ctx.r25.u64;
	// bl 0x8b0bfc38
	ctx.lr = 0x8B0A2E24;
	sub_8B0BFC38(ctx, base);
	// mr r20,r3
	ctx.r20.u64 = ctx.r3.u64;
	// li r26,0
	ctx.r26.s64 = 0;
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// ble cr6,0x8b0a2ee8
	if (!ctx.cr6.gt) goto loc_8B0A2EE8;
loc_8B0A2E34:
	// mr r4,r21
	ctx.r4.u64 = ctx.r21.u64;
	// mr r5,r26
	ctx.r5.u64 = ctx.r26.u64;
	// addi r3,r1,336
	ctx.r3.s64 = ctx.r1.s64 + 336;
	// bl 0x8b090220
	ctx.lr = 0x8B0A2E44;
	sub_8B090220(ctx, base);
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// li r5,0
	ctx.r5.s64 = 0;
	// mr r3,r25
	ctx.r3.u64 = ctx.r25.u64;
	// bl 0x8b0bfa88
	ctx.lr = 0x8B0A2E54;
	sub_8B0BFA88(ctx, base);
	// mr r4,r27
	ctx.r4.u64 = ctx.r27.u64;
	// li r5,0
	ctx.r5.s64 = 0;
	// mr r30,r3
	ctx.r30.u64 = ctx.r3.u64;
	// bl 0x8b0bfd30
	ctx.lr = 0x8B0A2E64;
	sub_8B0BFD30(ctx, base);
	// mr r29,r3
	ctx.r29.u64 = ctx.r3.u64;
	// cmpldi cr6,r3,0
	ctx.cr6.compare<uint64_t>(ctx.r3.u64, 0, ctx.xer);
	// beq cr6,0x8b0a2edc
	if (ctx.cr6.eq) goto loc_8B0A2EDC;
	// li r3,36
	ctx.r3.s64 = 36;
	// bl 0x8b0bf448
	ctx.lr = 0x8B0A2E78;
	sub_8B0BF448(ctx, base);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0a2e90
	if (ctx.cr6.eq) goto loc_8B0A2E90;
	// mr r4,r19
	ctx.r4.u64 = ctx.r19.u64;
	// bl 0x8b0bf9f8
	ctx.lr = 0x8B0A2E88;
	sub_8B0BF9F8(ctx, base);
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// b 0x8b0a2e94
	goto loc_8B0A2E94;
loc_8B0A2E90:
	// li r31,0
	ctx.r31.s64 = 0;
loc_8B0A2E94:
	// mr r5,r22
	ctx.r5.u64 = ctx.r22.u64;
	// mr r4,r23
	ctx.r4.u64 = ctx.r23.u64;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0c0010
	ctx.lr = 0x8B0A2EA4;
	sub_8B0C0010(ctx, base);
	// mr r4,r27
	ctx.r4.u64 = ctx.r27.u64;
	// mr r5,r29
	ctx.r5.u64 = ctx.r29.u64;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0c0190
	ctx.lr = 0x8B0A2EB4;
	sub_8B0C0190(ctx, base);
	// mr r4,r24
	ctx.r4.u64 = ctx.r24.u64;
	// mr r5,r30
	ctx.r5.u64 = ctx.r30.u64;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0c0250
	ctx.lr = 0x8B0A2EC4;
	sub_8B0C0250(ctx, base);
	// lwz r11,0(r28)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r28.u32 + 0);
	// mr r4,r31
	ctx.r4.u64 = ctx.r31.u64;
	// mr r3,r28
	ctx.r3.u64 = ctx.r28.u64;
	// lwz r10,48(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 48);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B0A2EDC;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
loc_8B0A2EDC:
	// addi r26,r26,1
	ctx.r26.s64 = ctx.r26.s64 + 1;
	// cmpw cr6,r26,r20
	ctx.cr6.compare<int32_t>(ctx.r26.s32, ctx.r20.s32, ctx.xer);
	// blt cr6,0x8b0a2e34
	if (ctx.cr6.lt) goto loc_8B0A2E34;
loc_8B0A2EE8:
	// addi r16,r16,1
	ctx.r16.s64 = ctx.r16.s64 + 1;
	// cmpw cr6,r16,r15
	ctx.cr6.compare<int32_t>(ctx.r16.s32, ctx.r15.s32, ctx.xer);
	// blt cr6,0x8b0a2dcc
	if (ctx.cr6.lt) goto loc_8B0A2DCC;
loc_8B0A2EF4:
	// lwz r11,0(r28)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r28.u32 + 0);
	// mr r3,r28
	ctx.r3.u64 = ctx.r28.u64;
	// lwz r10,80(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 80);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B0A2F08;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
loc_8B0A2F08:
	// addi r1,r1,752
	ctx.r1.s64 = ctx.r1.s64 + 752;
	// b 0x8b0cb9d0
	__restgprlr_14(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0A34F0) {
	REX_FUNC_PROLOGUE();
	// lwz r7,12(r3)
	ctx.r7.u64 = REX_LOAD_U32(ctx.r3.u32 + 12);
	// li r10,0
	ctx.r10.s64 = 0;
	// cmpwi cr6,r7,0
	ctx.cr6.compare<int32_t>(ctx.r7.s32, 0, ctx.xer);
	// ble cr6,0x8b0a352c
	if (!ctx.cr6.gt) goto loc_8B0A352C;
	// lwz r8,0(r3)
	ctx.r8.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r9,0(r4)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r4.u32 + 0);
	// mr r11,r8
	ctx.r11.u64 = ctx.r8.u64;
loc_8B0A350C:
	// lwz r6,0(r11)
	ctx.r6.u64 = REX_LOAD_U32(ctx.r11.u32 + 0);
	// cmplw cr6,r6,r9
	ctx.cr6.compare<uint32_t>(ctx.r6.u32, ctx.r9.u32, ctx.xer);
	// beq cr6,0x8b0a3534
	if (ctx.cr6.eq) goto loc_8B0A3534;
	// lwz r6,12(r3)
	ctx.r6.u64 = REX_LOAD_U32(ctx.r3.u32 + 12);
	// addi r10,r10,1
	ctx.r10.s64 = ctx.r10.s64 + 1;
	// addi r11,r11,4
	ctx.r11.s64 = ctx.r11.s64 + 4;
	// cmpw cr6,r10,r6
	ctx.cr6.compare<int32_t>(ctx.r10.s32, ctx.r6.s32, ctx.xer);
	// blt cr6,0x8b0a350c
	if (ctx.cr6.lt) goto loc_8B0A350C;
loc_8B0A352C:
	// li r3,0
	ctx.r3.s64 = 0;
	// blr 
	return;
loc_8B0A3534:
	// cmpwi cr6,r10,-1
	ctx.cr6.compare<int32_t>(ctx.r10.s32, -1, ctx.xer);
	// beq cr6,0x8b0a352c
	if (ctx.cr6.eq) goto loc_8B0A352C;
	// cmpwi cr6,r7,0
	ctx.cr6.compare<int32_t>(ctx.r7.s32, 0, ctx.xer);
	// ble cr6,0x8b0a3570
	if (!ctx.cr6.gt) goto loc_8B0A3570;
	// addi r11,r7,-1
	ctx.r11.s64 = ctx.r7.s64 + -1;
	// cmpw cr6,r10,r11
	ctx.cr6.compare<int32_t>(ctx.r10.s32, ctx.r11.s32, ctx.xer);
	// beq cr6,0x8b0a3564
	if (ctx.cr6.eq) goto loc_8B0A3564;
	// rlwinm r9,r7,2,0,29
	ctx.r9.u64 = __builtin_rotateleft64(ctx.r7.u32 | (ctx.r7.u64 << 32), 2) & 0xFFFFFFFC;
	// rlwinm r11,r10,2,0,29
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r10.u32 | (ctx.r10.u64 << 32), 2) & 0xFFFFFFFC;
	// add r10,r9,r8
	ctx.r10.u64 = ctx.r9.u64 + ctx.r8.u64;
	// lwz r9,-4(r10)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r10.u32 + -4);
	// stwx r9,r11,r8
	REX_STORE_U32(ctx.r11.u32 + ctx.r8.u32, ctx.r9.u32);
loc_8B0A3564:
	// lwz r11,12(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 12);
	// addi r11,r11,-1
	ctx.r11.s64 = ctx.r11.s64 + -1;
	// stw r11,12(r3)
	REX_STORE_U32(ctx.r3.u32 + 12, ctx.r11.u32);
loc_8B0A3570:
	// li r3,1
	ctx.r3.s64 = 1;
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0A3880) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// std r31,-16(r1)
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.r31.u64);
	// stwu r1,-144(r1)
	ea = -144 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// cmplwi cr6,r4,0
	ctx.cr6.compare<uint32_t>(ctx.r4.u32, 0, ctx.xer);
	// beq cr6,0x8b0a3934
	if (ctx.cr6.eq) goto loc_8B0A3934;
	// bl 0x8b0a01f8
	ctx.lr = 0x8B0A38A0;
	sub_8B0A01F8(ctx, base);
	// lwz r11,160(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 160);
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// bne cr6,0x8b0a3934
	if (!ctx.cr6.eq) goto loc_8B0A3934;
	// li r6,0
	ctx.r6.s64 = 0;
	// li r5,0
	ctx.r5.s64 = 0;
	// li r4,0
	ctx.r4.s64 = 0;
	// addi r3,r1,80
	ctx.r3.s64 = ctx.r1.s64 + 80;
	// bl 0x8b0c8820
	ctx.lr = 0x8B0A38C0;
	sub_8B0C8820(ctx, base);
	// li r4,0
	ctx.r4.s64 = 0;
	// addi r3,r1,80
	ctx.r3.s64 = ctx.r1.s64 + 80;
	// bl 0x8b0c79c8
	ctx.lr = 0x8B0A38CC;
	sub_8B0C79C8(ctx, base);
	// lis r11,-29936
	ctx.r11.s64 = -1961885696;
	// lwz r3,-17796(r11)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r11.u32 + -17796);
	// lwz r10,0(r3)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r9,40(r10)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r10.u32 + 40);
	// mtctr r9
	ctx.ctr.u64 = ctx.r9.u64;
	// bctrl 
	ctx.lr = 0x8B0A38E4;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// lwz r8,0(r3)
	ctx.r8.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// addi r5,r1,80
	ctx.r5.s64 = ctx.r1.s64 + 80;
	// lwz r4,180(r31)
	ctx.r4.u64 = REX_LOAD_U32(ctx.r31.u32 + 180);
	// lwz r7,16(r8)
	ctx.r7.u64 = REX_LOAD_U32(ctx.r8.u32 + 16);
	// mtctr r7
	ctx.ctr.u64 = ctx.r7.u64;
	// bctrl 
	ctx.lr = 0x8B0A38FC;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// lis r3,-29938
	ctx.r3.s64 = -1962016768;
	// lwz r6,108(r1)
	ctx.r6.u64 = REX_LOAD_U32(ctx.r1.u32 + 108);
	// li r8,4
	ctx.r8.s64 = 4;
	// lwz r5,80(r1)
	ctx.r5.u64 = REX_LOAD_U32(ctx.r1.u32 + 80);
	// li r7,0
	ctx.r7.s64 = 0;
	// addi r4,r31,24
	ctx.r4.s64 = ctx.r31.s64 + 24;
	// lwz r11,2364(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 2364);
	// lwz r3,104(r11)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r11.u32 + 104);
	// lwz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r10,48(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 48);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B0A392C;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// addi r3,r1,80
	ctx.r3.s64 = ctx.r1.s64 + 80;
	// bl 0x8b0906a8
	ctx.lr = 0x8B0A3934;
	sub_8B0906A8(ctx, base);
loc_8B0A3934:
	// addi r1,r1,144
	ctx.r1.s64 = ctx.r1.s64 + 144;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0A3A68) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9b8
	ctx.lr = 0x8B0A3A70;
	__savegprlr_28(ctx, base);
	// stwu r1,-128(r1)
	ea = -128 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lbz r11,148(r3)
	ctx.r11.u64 = REX_LOAD_U8(ctx.r3.u32 + 148);
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// beq cr6,0x8b0a3aa0
	if (ctx.cr6.eq) goto loc_8B0A3AA0;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// addi r3,r11,18560
	ctx.r3.s64 = ctx.r11.s64 + 18560;
	// bl 0x8b0df2e8
	ctx.lr = 0x8B0A3A90;
	sub_8B0DF2E8(ctx, base);
	// li r5,0
	ctx.r5.s64 = 0;
	// li r4,0
	ctx.r4.s64 = 0;
	// addi r3,r31,8
	ctx.r3.s64 = ctx.r31.s64 + 8;
	// bl 0x8b09b4e0
	ctx.lr = 0x8B0A3AA0;
	sub_8B09B4E0(ctx, base);
loc_8B0A3AA0:
	// lwz r3,160(r31)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r31.u32 + 160);
	// li r29,0
	ctx.r29.s64 = 0;
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0a3abc
	if (ctx.cr6.eq) goto loc_8B0A3ABC;
	// li r4,0
	ctx.r4.s64 = 0;
	// bl 0x8b099978
	ctx.lr = 0x8B0A3AB8;
	sub_8B099978(ctx, base);
	// stw r29,160(r31)
	REX_STORE_U32(ctx.r31.u32 + 160, ctx.r29.u32);
loc_8B0A3ABC:
	// lwz r11,0(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 0);
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// lwz r10,56(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 56);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B0A3AD0;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// mr r28,r3
	ctx.r28.u64 = ctx.r3.u64;
	// li r3,36
	ctx.r3.s64 = 36;
	// bl 0x8b0bf448
	ctx.lr = 0x8B0A3ADC;
	sub_8B0BF448(ctx, base);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0a3b20
	if (ctx.cr6.eq) goto loc_8B0A3B20;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// addi r4,r11,16240
	ctx.r4.s64 = ctx.r11.s64 + 16240;
	// bl 0x8b0bf9f8
	ctx.lr = 0x8B0A3AF0;
	sub_8B0BF9F8(ctx, base);
	// mr r30,r3
	ctx.r30.u64 = ctx.r3.u64;
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0a3b20
	if (ctx.cr6.eq) goto loc_8B0A3B20;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// ld r5,184(r31)
	ctx.r5.u64 = REX_LOAD_U64(ctx.r31.u32 + 184);
	// addi r4,r11,16356
	ctx.r4.s64 = ctx.r11.s64 + 16356;
	// bl 0x8b0c0190
	ctx.lr = 0x8B0A3B0C;
	sub_8B0C0190(ctx, base);
	// mr r4,r30
	ctx.r4.u64 = ctx.r30.u64;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b09ff28
	ctx.lr = 0x8B0A3B18;
	sub_8B09FF28(ctx, base);
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// bl 0x8b0c04f0
	ctx.lr = 0x8B0A3B20;
	sub_8B0C04F0(ctx, base);
loc_8B0A3B20:
	// lwz r3,152(r31)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r31.u32 + 152);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0a3b40
	if (ctx.cr6.eq) goto loc_8B0A3B40;
	// clrlwi r11,r28,24
	ctx.r11.u64 = ctx.r28.u32 & 0xFF;
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// bne cr6,0x8b0a3b40
	if (!ctx.cr6.eq) goto loc_8B0A3B40;
	// bl 0x8b0aaf48
	ctx.lr = 0x8B0A3B3C;
	sub_8B0AAF48(ctx, base);
	// stw r29,152(r31)
	REX_STORE_U32(ctx.r31.u32 + 152, ctx.r29.u32);
loc_8B0A3B40:
	// lwz r3,156(r31)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r31.u32 + 156);
	// addi r30,r31,156
	ctx.r30.s64 = ctx.r31.s64 + 156;
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0a3b64
	if (ctx.cr6.eq) goto loc_8B0A3B64;
	// lwz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r10,16(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 16);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B0A3B60;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// stw r29,0(r30)
	REX_STORE_U32(ctx.r30.u32 + 0, ctx.r29.u32);
loc_8B0A3B64:
	// lwz r11,0(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 0);
	// li r5,0
	ctx.r5.s64 = 0;
	// li r4,0
	ctx.r4.s64 = 0;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// lwz r10,64(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 64);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B0A3B80;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// clrlwi r9,r28,24
	ctx.r9.u64 = ctx.r28.u32 & 0xFF;
	// cmplwi cr6,r9,0
	ctx.cr6.compare<uint32_t>(ctx.r9.u32, 0, ctx.xer);
	// bne cr6,0x8b0a3bd4
	if (!ctx.cr6.eq) goto loc_8B0A3BD4;
	// lwz r11,8(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 8);
	// addi r3,r31,8
	ctx.r3.s64 = ctx.r31.s64 + 8;
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// beq cr6,0x8b0a3bb8
	if (ctx.cr6.eq) goto loc_8B0A3BB8;
	// mr r4,r30
	ctx.r4.u64 = ctx.r30.u64;
	// bl 0x8b09ba10
	ctx.lr = 0x8B0A3BA4;
	sub_8B09BA10(ctx, base);
	// stw r29,180(r31)
	REX_STORE_U32(ctx.r31.u32 + 180, ctx.r29.u32);
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0a3948
	ctx.lr = 0x8B0A3BB0;
	sub_8B0A3948(ctx, base);
	// addi r1,r1,128
	ctx.r1.s64 = ctx.r1.s64 + 128;
	// b 0x8b0cba08
	__restgprlr_28(ctx, base);
	return;
loc_8B0A3BB8:
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0a3948
	ctx.lr = 0x8B0A3BC0;
	sub_8B0A3948(ctx, base);
	// stw r29,180(r31)
	REX_STORE_U32(ctx.r31.u32 + 180, ctx.r29.u32);
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0a3948
	ctx.lr = 0x8B0A3BCC;
	sub_8B0A3948(ctx, base);
	// addi r1,r1,128
	ctx.r1.s64 = ctx.r1.s64 + 128;
	// b 0x8b0cba08
	__restgprlr_28(ctx, base);
	return;
loc_8B0A3BD4:
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// addi r3,r11,18496
	ctx.r3.s64 = ctx.r11.s64 + 18496;
	// bl 0x8b0df298
	ctx.lr = 0x8B0A3BE0;
	sub_8B0DF298(ctx, base);
	// stw r29,180(r31)
	REX_STORE_U32(ctx.r31.u32 + 180, ctx.r29.u32);
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0a3948
	ctx.lr = 0x8B0A3BEC;
	sub_8B0A3948(ctx, base);
	// addi r1,r1,128
	ctx.r1.s64 = ctx.r1.s64 + 128;
	// b 0x8b0cba08
	__restgprlr_28(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0A4C90) {
	REX_FUNC_PROLOGUE();
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// addi r9,r11,19156
	ctx.r9.s64 = ctx.r11.s64 + 19156;
	// addi r8,r10,19148
	ctx.r8.s64 = ctx.r10.s64 + 19148;
	// stw r9,0(r3)
	REX_STORE_U32(ctx.r3.u32 + 0, ctx.r9.u32);
	// stw r8,4(r3)
	REX_STORE_U32(ctx.r3.u32 + 4, ctx.r8.u32);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0A4CB0) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// stwu r1,-96(r1)
	ea = -96 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// bl 0x8b094ae8
	ctx.lr = 0x8B0A4CC0;
	sub_8B094AE8(ctx, base);
	// cmpwi cr6,r3,1
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 1, ctx.xer);
	// bne cr6,0x8b0a4cc8
	if (!ctx.cr6.eq) goto loc_8B0A4CC8;
loc_8B0A4CC8:
	// addi r1,r1,96
	ctx.r1.s64 = ctx.r1.s64 + 96;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0A4CD8) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// stwu r1,-96(r1)
	ea = -96 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// bl 0x8b094b00
	ctx.lr = 0x8B0A4CE8;
	sub_8B094B00(ctx, base);
	// lis r11,-29938
	ctx.r11.s64 = -1962016768;
	// li r4,0
	ctx.r4.s64 = 0;
	// lwz r3,5756(r11)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r11.u32 + 5756);
	// lwz r10,0(r3)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r9,0(r10)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r10.u32 + 0);
	// mtctr r9
	ctx.ctr.u64 = ctx.r9.u64;
	// bctrl 
	ctx.lr = 0x8B0A4D04;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// lis r8,-29938
	ctx.r8.s64 = -1962016768;
	// li r4,0
	ctx.r4.s64 = 0;
	// lwz r3,5624(r8)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r8.u32 + 5624);
	// lwz r7,0(r3)
	ctx.r7.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r6,8(r7)
	ctx.r6.u64 = REX_LOAD_U32(ctx.r7.u32 + 8);
	// mtctr r6
	ctx.ctr.u64 = ctx.r6.u64;
	// bctrl 
	ctx.lr = 0x8B0A4D20;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// addi r1,r1,96
	ctx.r1.s64 = ctx.r1.s64 + 96;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0A4D30) {
	REX_FUNC_PROLOGUE();
	// lis r11,-29938
	ctx.r11.s64 = -1962016768;
	// lwz r3,2364(r11)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r11.u32 + 2364);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0A4D40) {
	REX_FUNC_PROLOGUE();
	// lis r11,-29938
	ctx.r11.s64 = -1962016768;
	// lwz r3,4480(r11)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r11.u32 + 4480);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0A4D50) {
	REX_FUNC_PROLOGUE();
	// lis r11,-29938
	ctx.r11.s64 = -1962016768;
	// lwz r3,16928(r11)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r11.u32 + 16928);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0A4D60) {
	REX_FUNC_PROLOGUE();
	// lis r11,-29938
	ctx.r11.s64 = -1962016768;
	// lwz r3,912(r11)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r11.u32 + 912);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0A4D70) {
	REX_FUNC_PROLOGUE();
	// lis r11,-29938
	ctx.r11.s64 = -1962016768;
	// lwz r3,5936(r11)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r11.u32 + 5936);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0A4D80) {
	REX_FUNC_PROLOGUE();
	// lis r11,-29938
	ctx.r11.s64 = -1962016768;
	// lwz r3,6068(r11)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r11.u32 + 6068);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0A4D90) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9bc
	ctx.lr = 0x8B0A4D98;
	__savegprlr_29(ctx, base);
	// stwu r1,-176(r1)
	ea = -176 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// mr r29,r3
	ctx.r29.u64 = ctx.r3.u64;
	// bl 0x8b095438
	ctx.lr = 0x8B0A4DA4;
	sub_8B095438(ctx, base);
	// addi r11,r1,104
	ctx.r11.s64 = ctx.r1.s64 + 104;
	// li r31,0
	ctx.r31.s64 = 0;
	// mr r30,r3
	ctx.r30.u64 = ctx.r3.u64;
	// std r31,96(r1)
	REX_STORE_U64(ctx.r1.u32 + 96, ctx.r31.u64);
	// cmpwi cr6,r3,2
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 2, ctx.xer);
	// std r31,0(r11)
	REX_STORE_U64(ctx.r11.u32 + 0, ctx.r31.u64);
	// std r31,8(r11)
	REX_STORE_U64(ctx.r11.u32 + 8, ctx.r31.u64);
	// std r31,16(r11)
	REX_STORE_U64(ctx.r11.u32 + 16, ctx.r31.u64);
	// std r31,24(r11)
	REX_STORE_U64(ctx.r11.u32 + 24, ctx.r31.u64);
	// bne cr6,0x8b0a4e5c
	if (!ctx.cr6.eq) goto loc_8B0A4E5C;
	// addi r5,r1,96
	ctx.r5.s64 = ctx.r1.s64 + 96;
	// li r4,1
	ctx.r4.s64 = 1;
	// mr r3,r29
	ctx.r3.u64 = ctx.r29.u64;
	// bl 0x8b0dbdc8
	ctx.lr = 0x8B0A4DDC;
	sub_8B0DBDC8(ctx, base);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// bne cr6,0x8b0a4e5c
	if (!ctx.cr6.eq) goto loc_8B0A4E5C;
	// lwz r11,104(r1)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r1.u32 + 104);
	// clrlwi r10,r11,31
	ctx.r10.u64 = ctx.r11.u32 & 0x1;
	// cmplwi cr6,r10,0
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 0, ctx.xer);
	// beq cr6,0x8b0a4e5c
	if (ctx.cr6.eq) goto loc_8B0A4E5C;
	// stw r31,80(r1)
	REX_STORE_U32(ctx.r1.u32 + 80, ctx.r31.u32);
	// addi r5,r1,80
	ctx.r5.s64 = ctx.r1.s64 + 80;
	// li r4,254
	ctx.r4.s64 = 254;
	// mr r3,r29
	ctx.r3.u64 = ctx.r29.u64;
	// bl 0x8b095448
	ctx.lr = 0x8B0A4E08;
	sub_8B095448(ctx, base);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// bne cr6,0x8b0a4e28
	if (!ctx.cr6.eq) goto loc_8B0A4E28;
	// lwz r11,80(r1)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r1.u32 + 80);
	// cmpwi cr6,r11,0
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// beq cr6,0x8b0a4e28
	if (ctx.cr6.eq) goto loc_8B0A4E28;
	// li r3,1
	ctx.r3.s64 = 1;
	// addi r1,r1,176
	ctx.r1.s64 = ctx.r1.s64 + 176;
	// b 0x8b0cba0c
	__restgprlr_29(ctx, base);
	return;
loc_8B0A4E28:
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// ld r6,96(r1)
	ctx.r6.u64 = REX_LOAD_U64(ctx.r1.u32 + 96);
	// li r4,2
	ctx.r4.s64 = 2;
	// lwz r5,104(r1)
	ctx.r5.u64 = REX_LOAD_U32(ctx.r1.u32 + 104);
	// addi r3,r11,19360
	ctx.r3.s64 = ctx.r11.s64 + 19360;
	// bl 0x8b0df2e8
	ctx.lr = 0x8B0A4E40;
	sub_8B0DF2E8(ctx, base);
	// li r3,36
	ctx.r3.s64 = 36;
	// bl 0x8b0bf448
	ctx.lr = 0x8B0A4E48;
	sub_8B0BF448(ctx, base);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0a4ee4
	if (ctx.cr6.eq) goto loc_8B0A4EE4;
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// addi r8,r10,19340
	ctx.r8.s64 = ctx.r10.s64 + 19340;
	// b 0x8b0a4e8c
	goto loc_8B0A4E8C;
loc_8B0A4E5C:
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// ld r6,96(r1)
	ctx.r6.u64 = REX_LOAD_U64(ctx.r1.u32 + 96);
	// mr r4,r30
	ctx.r4.u64 = ctx.r30.u64;
	// lwz r5,104(r1)
	ctx.r5.u64 = REX_LOAD_U32(ctx.r1.u32 + 104);
	// addi r3,r11,19256
	ctx.r3.s64 = ctx.r11.s64 + 19256;
	// bl 0x8b0df2e8
	ctx.lr = 0x8B0A4E74;
	sub_8B0DF2E8(ctx, base);
	// li r3,36
	ctx.r3.s64 = 36;
	// bl 0x8b0bf448
	ctx.lr = 0x8B0A4E7C;
	sub_8B0BF448(ctx, base);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0a4ee4
	if (ctx.cr6.eq) goto loc_8B0A4EE4;
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// addi r8,r10,19244
	ctx.r8.s64 = ctx.r10.s64 + 19244;
loc_8B0A4E8C:
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lis r9,-29944
	ctx.r9.s64 = -1962409984;
	// addi r6,r11,17076
	ctx.r6.s64 = ctx.r11.s64 + 17076;
	// lis r4,-29944
	ctx.r4.s64 = -1962409984;
	// mr r7,r6
	ctx.r7.u64 = ctx.r6.u64;
	// addi r5,r9,8928
	ctx.r5.s64 = ctx.r9.s64 + 8928;
	// addi r4,r4,19232
	ctx.r4.s64 = ctx.r4.s64 + 19232;
	// bl 0x8b0c1438
	ctx.lr = 0x8B0A4EAC;
	sub_8B0C1438(ctx, base);
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0a4ee4
	if (ctx.cr6.eq) goto loc_8B0A4EE4;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// mr r5,r29
	ctx.r5.u64 = ctx.r29.u64;
	// addi r4,r11,19224
	ctx.r4.s64 = ctx.r11.s64 + 19224;
	// bl 0x8b0c0148
	ctx.lr = 0x8B0A4EC8;
	sub_8B0C0148(ctx, base);
	// lis r10,-29938
	ctx.r10.s64 = -1962016768;
	// mr r4,r31
	ctx.r4.u64 = ctx.r31.u64;
	// lwz r3,4480(r10)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r10.u32 + 4480);
	// lwz r9,0(r3)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r8,8(r9)
	ctx.r8.u64 = REX_LOAD_U32(ctx.r9.u32 + 8);
	// mtctr r8
	ctx.ctr.u64 = ctx.r8.u64;
	// bctrl 
	ctx.lr = 0x8B0A4EE4;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
loc_8B0A4EE4:
	// li r3,0
	ctx.r3.s64 = 0;
	// addi r1,r1,176
	ctx.r1.s64 = ctx.r1.s64 + 176;
	// b 0x8b0cba0c
	__restgprlr_29(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0A4F68) {
	REX_FUNC_PROLOGUE();
	PPCRegister temp{};
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9b8
	ctx.lr = 0x8B0A4F70;
	__savegprlr_28(ctx, base);
	// stwu r1,-272(r1)
	ea = -272 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lis r11,-29938
	ctx.r11.s64 = -1962016768;
	// li r31,0
	ctx.r31.s64 = 0;
	// addi r30,r11,19288
	ctx.r30.s64 = ctx.r11.s64 + 19288;
loc_8B0A4F80:
	// addi r4,r1,80
	ctx.r4.s64 = ctx.r1.s64 + 80;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0955b0
	ctx.lr = 0x8B0A4F8C;
	sub_8B0955B0(ctx, base);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// bne cr6,0x8b0a4fa4
	if (!ctx.cr6.eq) goto loc_8B0A4FA4;
	// ld r11,8(r30)
	ctx.r11.u64 = REX_LOAD_U64(ctx.r30.u32 + 8);
	// ld r10,80(r1)
	ctx.r10.u64 = REX_LOAD_U64(ctx.r1.u32 + 80);
	// cmpld cr6,r10,r11
	ctx.cr6.compare<uint64_t>(ctx.r10.u64, ctx.r11.u64, ctx.xer);
	// beq cr6,0x8b0a5000
	if (ctx.cr6.eq) goto loc_8B0A5000;
loc_8B0A4FA4:
	// addi r31,r31,1
	ctx.r31.s64 = ctx.r31.s64 + 1;
	// cmpwi cr6,r31,4
	ctx.cr6.compare<int32_t>(ctx.r31.s32, 4, ctx.xer);
	// blt cr6,0x8b0a4f80
	if (ctx.cr6.lt) goto loc_8B0A4F80;
	// li r29,0
	ctx.r29.s64 = 0;
	// li r31,0
	ctx.r31.s64 = 0;
	// bl 0x8b0df2c8
	ctx.lr = 0x8B0A4FBC;
	sub_8B0DF2C8(ctx, base);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0a506c
	if (ctx.cr6.eq) goto loc_8B0A506C;
loc_8B0A4FC4:
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0df2b8
	ctx.lr = 0x8B0A4FCC;
	sub_8B0DF2B8(ctx, base);
	// mr r28,r3
	ctx.r28.u64 = ctx.r3.u64;
	// bl 0x8b0df328
	ctx.lr = 0x8B0A4FD4;
	sub_8B0DF328(ctx, base);
	// cmplw cr6,r3,r28
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, ctx.r28.u32, ctx.xer);
	// bne cr6,0x8b0a4fec
	if (!ctx.cr6.eq) goto loc_8B0A4FEC;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0df2d8
	ctx.lr = 0x8B0A4FE4;
	sub_8B0DF2D8(ctx, base);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0a5068
	if (ctx.cr6.eq) goto loc_8B0A5068;
loc_8B0A4FEC:
	// addi r31,r31,1
	ctx.r31.s64 = ctx.r31.s64 + 1;
	// bl 0x8b0df2c8
	ctx.lr = 0x8B0A4FF4;
	sub_8B0DF2C8(ctx, base);
	// cmplw cr6,r31,r3
	ctx.cr6.compare<uint32_t>(ctx.r31.u32, ctx.r3.u32, ctx.xer);
	// blt cr6,0x8b0a4fc4
	if (ctx.cr6.lt) goto loc_8B0A4FC4;
	// b 0x8b0a506c
	goto loc_8B0A506C;
loc_8B0A5000:
	// li r3,36
	ctx.r3.s64 = 36;
	// bl 0x8b0bf448
	ctx.lr = 0x8B0A5008;
	sub_8B0BF448(ctx, base);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0a5040
	if (ctx.cr6.eq) goto loc_8B0A5040;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// addi r6,r11,17076
	ctx.r6.s64 = ctx.r11.s64 + 17076;
	// lis r9,-29944
	ctx.r9.s64 = -1962409984;
	// lis r4,-29944
	ctx.r4.s64 = -1962409984;
	// mr r7,r6
	ctx.r7.u64 = ctx.r6.u64;
	// addi r8,r10,19536
	ctx.r8.s64 = ctx.r10.s64 + 19536;
	// addi r5,r9,8928
	ctx.r5.s64 = ctx.r9.s64 + 8928;
	// addi r4,r4,19232
	ctx.r4.s64 = ctx.r4.s64 + 19232;
	// bl 0x8b0c1438
	ctx.lr = 0x8B0A5038;
	sub_8B0C1438(ctx, base);
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// b 0x8b0a5044
	goto loc_8B0A5044;
loc_8B0A5040:
	// li r4,0
	ctx.r4.s64 = 0;
loc_8B0A5044:
	// lis r11,-29938
	ctx.r11.s64 = -1962016768;
	// lwz r3,4480(r11)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r11.u32 + 4480);
	// lwz r10,0(r3)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r9,8(r10)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r10.u32 + 8);
	// mtctr r9
	ctx.ctr.u64 = ctx.r9.u64;
	// bctrl 
	ctx.lr = 0x8B0A505C;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// li r3,0
	ctx.r3.s64 = 0;
	// addi r1,r1,272
	ctx.r1.s64 = ctx.r1.s64 + 272;
	// b 0x8b0cba08
	__restgprlr_28(ctx, base);
	return;
loc_8B0A5068:
	// li r29,1
	ctx.r29.s64 = 1;
loc_8B0A506C:
	// li r11,0
	ctx.r11.s64 = 0;
	// li r5,120
	ctx.r5.s64 = 120;
	// li r4,0
	ctx.r4.s64 = 0;
	// stb r11,96(r1)
	REX_STORE_U8(ctx.r1.u32 + 96, ctx.r11.u8);
	// addi r3,r1,97
	ctx.r3.s64 = ctx.r1.s64 + 97;
	// bl 0x8b0cb8e0
	ctx.lr = 0x8B0A5084;
	sub_8B0CB8E0(ctx, base);
	// addi r4,r1,96
	ctx.r4.s64 = ctx.r1.s64 + 96;
	// addi r3,r30,20
	ctx.r3.s64 = ctx.r30.s64 + 20;
	// bl 0x8b0994a8
	ctx.lr = 0x8B0A5090;
	sub_8B0994A8(ctx, base);
	// lis r10,-29936
	ctx.r10.s64 = -1961885696;
	// lwz r3,-17796(r10)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r10.u32 + -17796);
	// lwz r9,0(r3)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r8,36(r9)
	ctx.r8.u64 = REX_LOAD_U32(ctx.r9.u32 + 36);
	// mtctr r8
	ctx.ctr.u64 = ctx.r8.u64;
	// bctrl 
	ctx.lr = 0x8B0A50A8;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0a50f4
	if (ctx.cr6.eq) goto loc_8B0A50F4;
	// lwz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// addi r4,r1,96
	ctx.r4.s64 = ctx.r1.s64 + 96;
	// lwz r10,28(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 28);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B0A50C4;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// clrlwi r9,r3,24
	ctx.r9.u64 = ctx.r3.u32 & 0xFF;
	// cmplwi cr6,r9,0
	ctx.cr6.compare<uint32_t>(ctx.r9.u32, 0, ctx.xer);
	// bne cr6,0x8b0a50f4
	if (!ctx.cr6.eq) goto loc_8B0A50F4;
	// clrlwi r11,r29,24
	ctx.r11.u64 = ctx.r29.u32 & 0xFF;
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// beq cr6,0x8b0a50f4
	if (ctx.cr6.eq) goto loc_8B0A50F4;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// addi r3,r11,19472
	ctx.r3.s64 = ctx.r11.s64 + 19472;
	// bl 0x8b0df2a8
	ctx.lr = 0x8B0A50E8;
	sub_8B0DF2A8(ctx, base);
	// li r3,0
	ctx.r3.s64 = 0;
	// addi r1,r1,272
	ctx.r1.s64 = ctx.r1.s64 + 272;
	// b 0x8b0cba08
	__restgprlr_28(ctx, base);
	return;
loc_8B0A50F4:
	// clrlwi r11,r29,24
	ctx.r11.u64 = ctx.r29.u32 & 0xFF;
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// beq cr6,0x8b0a5118
	if (ctx.cr6.eq) goto loc_8B0A5118;
	// bl 0x8b0df2c8
	ctx.lr = 0x8B0A5104;
	sub_8B0DF2C8(ctx, base);
	// cmplwi cr6,r3,2
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 2, ctx.xer);
	// blt cr6,0x8b0a5118
	if (ctx.cr6.lt) goto loc_8B0A5118;
	// bl 0x8b0a4ef0
	ctx.lr = 0x8B0A5110;
	sub_8B0A4EF0(ctx, base);
	// addi r1,r1,272
	ctx.r1.s64 = ctx.r1.s64 + 272;
	// b 0x8b0cba08
	__restgprlr_28(ctx, base);
	return;
loc_8B0A5118:
	// bl 0x8b0df328
	ctx.lr = 0x8B0A511C;
	sub_8B0DF328(ctx, base);
	// bl 0x8b0a4d90
	ctx.lr = 0x8B0A5120;
	sub_8B0A4D90(ctx, base);
	// clrlwi r11,r3,24
	ctx.r11.u64 = ctx.r3.u32 & 0xFF;
	// addic r10,r11,-1
	ctx.xer.ca = ctx.r11.u32 > 0;
	ctx.r10.s64 = ctx.r11.s64 + -1;
	// subfe r3,r10,r11
	temp.u8 = (~ctx.r10.u32 + ctx.r11.u32 < ~ctx.r10.u32) | (~ctx.r10.u32 + ctx.r11.u32 + ctx.xer.ca < ctx.xer.ca);
	ctx.r3.u64 = ~ctx.r10.u64 + ctx.r11.u64 + ctx.xer.ca;
	ctx.xer.ca = temp.u8;
	// addi r1,r1,272
	ctx.r1.s64 = ctx.r1.s64 + 272;
	// b 0x8b0cba08
	__restgprlr_28(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0A5A10) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// std r30,-24(r1)
	REX_STORE_U64(ctx.r1.u32 + -24, ctx.r30.u64);
	// std r31,-16(r1)
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.r31.u64);
	// stwu r1,-240(r1)
	ea = -240 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// addi r3,r11,20208
	ctx.r3.s64 = ctx.r11.s64 + 20208;
	// bl 0x8b0df298
	ctx.lr = 0x8B0A5A30;
	sub_8B0DF298(ctx, base);
	// bl 0x8b0a4f68
	ctx.lr = 0x8B0A5A34;
	sub_8B0A4F68(ctx, base);
	// clrlwi r10,r3,24
	ctx.r10.u64 = ctx.r3.u32 & 0xFF;
	// cmplwi cr6,r10,0
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 0, ctx.xer);
	// beq cr6,0x8b0a5b48
	if (ctx.cr6.eq) goto loc_8B0A5B48;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// addi r3,r11,20172
	ctx.r3.s64 = ctx.r11.s64 + 20172;
	// bl 0x8b0df298
	ctx.lr = 0x8B0A5A4C;
	sub_8B0DF298(ctx, base);
	// lis r10,-29938
	ctx.r10.s64 = -1962016768;
	// li r11,-1
	ctx.r11.s64 = -1;
	// addi r30,r10,19288
	ctx.r30.s64 = ctx.r10.s64 + 19288;
	// li r3,36
	ctx.r3.s64 = 36;
	// stw r11,84(r30)
	REX_STORE_U32(ctx.r30.u32 + 84, ctx.r11.u32);
	// bl 0x8b0bf448
	ctx.lr = 0x8B0A5A64;
	sub_8B0BF448(ctx, base);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0a5b38
	if (ctx.cr6.eq) goto loc_8B0A5B38;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// addi r4,r11,19232
	ctx.r4.s64 = ctx.r11.s64 + 19232;
	// bl 0x8b0bf9f8
	ctx.lr = 0x8B0A5A78;
	sub_8B0BF9F8(ctx, base);
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0a5b38
	if (ctx.cr6.eq) goto loc_8B0A5B38;
	// li r11,0
	ctx.r11.s64 = 0;
	// li r5,120
	ctx.r5.s64 = 120;
	// li r4,0
	ctx.r4.s64 = 0;
	// stb r11,80(r1)
	REX_STORE_U8(ctx.r1.u32 + 80, ctx.r11.u8);
	// addi r3,r1,81
	ctx.r3.s64 = ctx.r1.s64 + 81;
	// bl 0x8b0cb8e0
	ctx.lr = 0x8B0A5A9C;
	sub_8B0CB8E0(ctx, base);
	// addi r4,r1,80
	ctx.r4.s64 = ctx.r1.s64 + 80;
	// addi r3,r30,20
	ctx.r3.s64 = ctx.r30.s64 + 20;
	// bl 0x8b0994a8
	ctx.lr = 0x8B0A5AA8;
	sub_8B0994A8(ctx, base);
	// bl 0x8b0df328
	ctx.lr = 0x8B0A5AAC;
	sub_8B0DF328(ctx, base);
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// mr r5,r3
	ctx.r5.u64 = ctx.r3.u64;
	// addi r4,r10,19224
	ctx.r4.s64 = ctx.r10.s64 + 19224;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0c0148
	ctx.lr = 0x8B0A5AC0;
	sub_8B0C0148(ctx, base);
	// lis r9,-29944
	ctx.r9.s64 = -1962409984;
	// addi r5,r1,80
	ctx.r5.s64 = ctx.r1.s64 + 80;
	// addi r4,r9,13248
	ctx.r4.s64 = ctx.r9.s64 + 13248;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0c0010
	ctx.lr = 0x8B0A5AD4;
	sub_8B0C0010(ctx, base);
	// lis r8,-29944
	ctx.r8.s64 = -1962409984;
	// lis r7,-29944
	ctx.r7.s64 = -1962409984;
	// addi r5,r8,20160
	ctx.r5.s64 = ctx.r8.s64 + 20160;
	// addi r4,r7,8928
	ctx.r4.s64 = ctx.r7.s64 + 8928;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0c0010
	ctx.lr = 0x8B0A5AEC;
	sub_8B0C0010(ctx, base);
	// lis r6,-29944
	ctx.r6.s64 = -1962409984;
	// addi r5,r30,84
	ctx.r5.s64 = ctx.r30.s64 + 84;
	// addi r4,r6,19912
	ctx.r4.s64 = ctx.r6.s64 + 19912;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0c0250
	ctx.lr = 0x8B0A5B00;
	sub_8B0C0250(ctx, base);
	// lis r5,-29938
	ctx.r5.s64 = -1962016768;
	// mr r4,r31
	ctx.r4.u64 = ctx.r31.u64;
	// lwz r3,4480(r5)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r5.u32 + 4480);
	// lwz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r10,8(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 8);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B0A5B1C;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// lwz r11,84(r30)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r30.u32 + 84);
	// cmpwi cr6,r11,-1
	ctx.cr6.compare<int32_t>(ctx.r11.s32, -1, ctx.xer);
	// beq cr6,0x8b0a5b38
	if (ctx.cr6.eq) goto loc_8B0A5B38;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// addi r3,r11,20112
	ctx.r3.s64 = ctx.r11.s64 + 20112;
	// bl 0x8b0df298
	ctx.lr = 0x8B0A5B34;
	sub_8B0DF298(ctx, base);
	// b 0x8b0a5b48
	goto loc_8B0A5B48;
loc_8B0A5B38:
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// addi r3,r11,20080
	ctx.r3.s64 = ctx.r11.s64 + 20080;
	// bl 0x8b0df298
	ctx.lr = 0x8B0A5B44;
	sub_8B0DF298(ctx, base);
	// bl 0x8b0a55c0
	ctx.lr = 0x8B0A5B48;
	sub_8B0A55C0(ctx, base);
loc_8B0A5B48:
	// addi r1,r1,240
	ctx.r1.s64 = ctx.r1.s64 + 240;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// ld r30,-24(r1)
	ctx.r30.u64 = REX_LOAD_U64(ctx.r1.u32 + -24);
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0A5E98) {
	REX_FUNC_PROLOGUE();
	PPCRegister temp{};
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// std r30,-24(r1)
	REX_STORE_U64(ctx.r1.u32 + -24, ctx.r30.u64);
	// std r31,-16(r1)
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.r31.u64);
	// stwu r1,-112(r1)
	ea = -112 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// mr r11,r4
	ctx.r11.u64 = ctx.r4.u64;
	// lwz r4,8(r3)
	ctx.r4.u64 = REX_LOAD_U32(ctx.r3.u32 + 8);
	// mr r30,r3
	ctx.r30.u64 = ctx.r3.u64;
	// cmpwi cr6,r4,0
	ctx.cr6.compare<int32_t>(ctx.r4.s32, 0, ctx.xer);
	// blt cr6,0x8b0a5f58
	if (ctx.cr6.lt) goto loc_8B0A5F58;
	// lwz r3,4(r3)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r3.u32 + 4);
	// li r6,136
	ctx.r6.s64 = 136;
	// add r31,r3,r11
	ctx.r31.u64 = ctx.r3.u64 + ctx.r11.u64;
	// mr r5,r31
	ctx.r5.u64 = ctx.r31.u64;
	// bl 0x8b090160
	ctx.lr = 0x8B0A5ED4;
	sub_8B090160(ctx, base);
	// cmpw cr6,r3,r31
	ctx.cr6.compare<int32_t>(ctx.r3.s32, ctx.r31.s32, ctx.xer);
	// bge cr6,0x8b0a5f08
	if (!ctx.cr6.lt) goto loc_8B0A5F08;
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// bne cr6,0x8b0a5ef4
	if (!ctx.cr6.eq) goto loc_8B0A5EF4;
	// cmpwi cr6,r31,-1
	ctx.cr6.compare<int32_t>(ctx.r31.s32, -1, ctx.xer);
	// bgt cr6,0x8b0a5ef4
	if (ctx.cr6.gt) goto loc_8B0A5EF4;
	// li r3,-1
	ctx.r3.s64 = -1;
	// b 0x8b0a5f08
	goto loc_8B0A5F08;
loc_8B0A5EF4:
	// add r11,r3,r31
	ctx.r11.u64 = ctx.r3.u64 + ctx.r31.u64;
	// srawi r10,r11,1
	ctx.xer.ca = (ctx.r11.s32 < 0) & ((ctx.r11.u32 & 0x1) != 0);
	ctx.r10.s64 = ctx.r11.s32 >> 1;
	// addze r3,r10
	temp.s64 = ctx.r10.s64 + ctx.xer.ca;
	ctx.xer.ca = temp.u32 < ctx.r10.u32;
	ctx.r3.s64 = temp.s64;
	// cmpw cr6,r3,r31
	ctx.cr6.compare<int32_t>(ctx.r3.s32, ctx.r31.s32, ctx.xer);
	// blt cr6,0x8b0a5ef4
	if (ctx.cr6.lt) goto loc_8B0A5EF4;
loc_8B0A5F08:
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lwz r4,0(r30)
	ctx.r4.u64 = REX_LOAD_U32(ctx.r30.u32 + 0);
	// stw r3,4(r30)
	REX_STORE_U32(ctx.r30.u32 + 4, ctx.r3.u32);
	// cmplwi cr6,r4,0
	ctx.cr6.compare<uint32_t>(ctx.r4.u32, 0, ctx.xer);
	// lwz r11,1144(r11)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r11.u32 + 1144);
	// beq cr6,0x8b0a5f3c
	if (ctx.cr6.eq) goto loc_8B0A5F3C;
	// mulli r5,r3,136
	ctx.r5.s64 = static_cast<int64_t>(ctx.r3.u64 * static_cast<uint64_t>(136));
	// lwz r3,0(r11)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r11.u32 + 0);
	// lwz r10,0(r3)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r9,12(r10)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r10.u32 + 12);
	// mtctr r9
	ctx.ctr.u64 = ctx.r9.u64;
	// bctrl 
	ctx.lr = 0x8B0A5F38;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// b 0x8b0a5f54
	goto loc_8B0A5F54;
loc_8B0A5F3C:
	// mulli r4,r3,136
	ctx.r4.s64 = static_cast<int64_t>(ctx.r3.u64 * static_cast<uint64_t>(136));
	// lwz r3,0(r11)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r11.u32 + 0);
	// lwz r10,0(r3)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r9,4(r10)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r10.u32 + 4);
	// mtctr r9
	ctx.ctr.u64 = ctx.r9.u64;
	// bctrl 
	ctx.lr = 0x8B0A5F54;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
loc_8B0A5F54:
	// stw r3,0(r30)
	REX_STORE_U32(ctx.r30.u32 + 0, ctx.r3.u32);
loc_8B0A5F58:
	// addi r1,r1,112
	ctx.r1.s64 = ctx.r1.s64 + 112;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// ld r30,-24(r1)
	ctx.r30.u64 = REX_LOAD_U64(ctx.r1.u32 + -24);
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0A6490) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// std r30,-24(r1)
	REX_STORE_U64(ctx.r1.u32 + -24, ctx.r30.u64);
	// std r31,-16(r1)
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.r31.u64);
	// stwu r1,-112(r1)
	ea = -112 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// li r30,0
	ctx.r30.s64 = 0;
	// addi r10,r11,20812
	ctx.r10.s64 = ctx.r11.s64 + 20812;
	// addi r3,r3,60
	ctx.r3.s64 = ctx.r3.s64 + 60;
	// stw r10,0(r31)
	REX_STORE_U32(ctx.r31.u32 + 0, ctx.r10.u32);
	// li r6,0
	ctx.r6.s64 = 0;
	// stw r30,4(r31)
	REX_STORE_U32(ctx.r31.u32 + 4, ctx.r30.u32);
	// li r5,0
	ctx.r5.s64 = 0;
	// stw r30,8(r31)
	REX_STORE_U32(ctx.r31.u32 + 8, ctx.r30.u32);
	// li r4,0
	ctx.r4.s64 = 0;
	// stw r30,12(r31)
	REX_STORE_U32(ctx.r31.u32 + 12, ctx.r30.u32);
	// stw r30,16(r31)
	REX_STORE_U32(ctx.r31.u32 + 16, ctx.r30.u32);
	// stb r30,20(r31)
	REX_STORE_U8(ctx.r31.u32 + 20, ctx.r30.u8);
	// stw r30,24(r31)
	REX_STORE_U32(ctx.r31.u32 + 24, ctx.r30.u32);
	// stw r30,28(r31)
	REX_STORE_U32(ctx.r31.u32 + 28, ctx.r30.u32);
	// stw r30,32(r31)
	REX_STORE_U32(ctx.r31.u32 + 32, ctx.r30.u32);
	// stw r30,36(r31)
	REX_STORE_U32(ctx.r31.u32 + 36, ctx.r30.u32);
	// stw r30,40(r31)
	REX_STORE_U32(ctx.r31.u32 + 40, ctx.r30.u32);
	// stw r30,44(r31)
	REX_STORE_U32(ctx.r31.u32 + 44, ctx.r30.u32);
	// stw r30,48(r31)
	REX_STORE_U32(ctx.r31.u32 + 48, ctx.r30.u32);
	// stw r30,52(r31)
	REX_STORE_U32(ctx.r31.u32 + 52, ctx.r30.u32);
	// stw r30,56(r31)
	REX_STORE_U32(ctx.r31.u32 + 56, ctx.r30.u32);
	// bl 0x8b0c8820
	ctx.lr = 0x8B0A6504;
	sub_8B0C8820(ctx, base);
	// stw r30,136(r31)
	REX_STORE_U32(ctx.r31.u32 + 136, ctx.r30.u32);
	// stw r30,140(r31)
	REX_STORE_U32(ctx.r31.u32 + 140, ctx.r30.u32);
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// stw r30,144(r31)
	REX_STORE_U32(ctx.r31.u32 + 144, ctx.r30.u32);
	// stw r30,148(r31)
	REX_STORE_U32(ctx.r31.u32 + 148, ctx.r30.u32);
	// addi r1,r1,112
	ctx.r1.s64 = ctx.r1.s64 + 112;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// ld r30,-24(r1)
	ctx.r30.u64 = REX_LOAD_U64(ctx.r1.u32 + -24);
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0A6650) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9b4
	ctx.lr = 0x8B0A6658;
	__savegprlr_27(ctx, base);
	// stwu r1,-448(r1)
	ea = -448 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lwz r4,60(r3)
	ctx.r4.u64 = REX_LOAD_U32(ctx.r3.u32 + 60);
	// mr r29,r3
	ctx.r29.u64 = ctx.r3.u64;
	// cmplwi cr6,r4,0
	ctx.cr6.compare<uint32_t>(ctx.r4.u32, 0, ctx.xer);
	// beq cr6,0x8b0a6688
	if (ctx.cr6.eq) goto loc_8B0A6688;
	// lwz r11,0(r4)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r4.u32 + 0);
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// ble cr6,0x8b0a6688
	if (!ctx.cr6.gt) goto loc_8B0A6688;
	// lwz r11,4(r4)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r4.u32 + 4);
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// beq cr6,0x8b0a6688
	if (ctx.cr6.eq) goto loc_8B0A6688;
	// bl 0x8b0a6228
	ctx.lr = 0x8B0A6688;
	sub_8B0A6228(ctx, base);
loc_8B0A6688:
	// li r30,0
	ctx.r30.s64 = 0;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// stb r30,20(r29)
	REX_STORE_U8(ctx.r29.u32 + 20, ctx.r30.u8);
	// addi r3,r11,20864
	ctx.r3.s64 = ctx.r11.s64 + 20864;
	// bl 0x8b0df298
	ctx.lr = 0x8B0A669C;
	sub_8B0DF298(ctx, base);
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// li r9,1
	ctx.r9.s64 = 1;
	// lwz r3,24(r29)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r29.u32 + 24);
	// addi r8,r10,1800
	ctx.r8.s64 = ctx.r10.s64 + 1800;
	// stw r9,84(r1)
	REX_STORE_U32(ctx.r1.u32 + 84, ctx.r9.u32);
	// li r5,1
	ctx.r5.s64 = 1;
	// stw r8,80(r1)
	REX_STORE_U32(ctx.r1.u32 + 80, ctx.r8.u32);
	// addi r4,r1,80
	ctx.r4.s64 = ctx.r1.s64 + 80;
	// bl 0x8b0bf510
	ctx.lr = 0x8B0A66C0;
	sub_8B0BF510(ctx, base);
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lis r27,-29938
	ctx.r27.s64 = -1962016768;
	// addi r28,r11,20856
	ctx.r28.s64 = ctx.r11.s64 + 20856;
loc_8B0A66CC:
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// bl 0x8b095438
	ctx.lr = 0x8B0A66D4;
	sub_8B095438(ctx, base);
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// beq cr6,0x8b0a6760
	if (ctx.cr6.eq) goto loc_8B0A6760;
	// addi r5,r1,96
	ctx.r5.s64 = ctx.r1.s64 + 96;
	// li r4,1
	ctx.r4.s64 = 1;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// bl 0x8b0dbdc8
	ctx.lr = 0x8B0A66EC;
	sub_8B0DBDC8(ctx, base);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// bne cr6,0x8b0a6760
	if (!ctx.cr6.eq) goto loc_8B0A6760;
	// lwz r11,104(r1)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r1.u32 + 104);
	// rlwinm r10,r11,0,30,30
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 0) & 0x2;
	// cmplwi cr6,r10,0
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 0, ctx.xer);
	// bne cr6,0x8b0a6760
	if (!ctx.cr6.eq) goto loc_8B0A6760;
	// ld r5,96(r1)
	ctx.r5.u64 = REX_LOAD_U64(ctx.r1.u32 + 96);
	// cmpldi cr6,r5,0
	ctx.cr6.compare<uint64_t>(ctx.r5.u64, 0, ctx.xer);
	// beq cr6,0x8b0a6760
	if (ctx.cr6.eq) goto loc_8B0A6760;
	// mr r4,r28
	ctx.r4.u64 = ctx.r28.u64;
	// addi r3,r1,144
	ctx.r3.s64 = ctx.r1.s64 + 144;
	// bl 0x8b090220
	ctx.lr = 0x8B0A671C;
	sub_8B090220(ctx, base);
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// li r5,0
	ctx.r5.s64 = 0;
	// lwz r3,24(r29)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r29.u32 + 24);
	// bl 0x8b0bfa88
	ctx.lr = 0x8B0A672C;
	sub_8B0BFA88(ctx, base);
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0a6760
	if (ctx.cr6.eq) goto loc_8B0A6760;
	// lwz r3,2548(r27)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r27.u32 + 2548);
	// mr r4,r30
	ctx.r4.u64 = ctx.r30.u64;
	// lwz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r10,4(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 4);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B0A6750;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0a6760
	if (ctx.cr6.eq) goto loc_8B0A6760;
	// mr r4,r31
	ctx.r4.u64 = ctx.r31.u64;
	// bl 0x8b09cde0
	ctx.lr = 0x8B0A6760;
	sub_8B09CDE0(ctx, base);
loc_8B0A6760:
	// addi r30,r30,1
	ctx.r30.s64 = ctx.r30.s64 + 1;
	// cmpwi cr6,r30,4
	ctx.cr6.compare<int32_t>(ctx.r30.s32, 4, ctx.xer);
	// blt cr6,0x8b0a66cc
	if (ctx.cr6.lt) goto loc_8B0A66CC;
	// addi r1,r1,448
	ctx.r1.s64 = ctx.r1.s64 + 448;
	// b 0x8b0cba04
	__restgprlr_27(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0A6BE0) {
	REX_FUNC_PROLOGUE();
	PPCRegister temp{};
	// lfs f0,0(r5)
	ctx.fpscr.disableFlushMode();
	temp.u32 = REX_LOAD_U32(ctx.r5.u32 + 0);
	ctx.f0.f64 = double(temp.f32);
	// li r11,1
	ctx.r11.s64 = 1;
	// fcmpu cr6,f0,f1
	ctx.cr6.compare(ctx.f0.f64, ctx.f1.f64);
	// bgt cr6,0x8b0a6bf4
	if (ctx.cr6.gt) goto loc_8B0A6BF4;
	// li r11,0
	ctx.r11.s64 = 0;
loc_8B0A6BF4:
	// clrlwi r3,r11,24
	ctx.r3.u64 = ctx.r11.u32 & 0xFF;
	// fcmpu cr6,f0,f1
	ctx.fpscr.disableFlushMode();
	ctx.cr6.compare(ctx.f0.f64, ctx.f1.f64);
	// ble cr6,0x8b0a6c08
	if (!ctx.cr6.gt) goto loc_8B0A6C08;
	// stfs f0,0(r5)
	temp.f32 = float(ctx.f0.f64);
	REX_STORE_U32(ctx.r5.u32 + 0, temp.u32);
	// blr 
	return;
loc_8B0A6C08:
	// stfs f1,0(r5)
	ctx.fpscr.disableFlushMode();
	temp.f32 = float(ctx.f1.f64);
	REX_STORE_U32(ctx.r5.u32 + 0, temp.u32);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0A6D48) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// std r30,-24(r1)
	REX_STORE_U64(ctx.r1.u32 + -24, ctx.r30.u64);
	// std r31,-16(r1)
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.r31.u64);
	// stwu r1,-112(r1)
	ea = -112 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lwz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// mr r30,r4
	ctx.r30.u64 = ctx.r4.u64;
	// cmpw cr6,r11,r4
	ctx.cr6.compare<int32_t>(ctx.r11.s32, ctx.r4.s32, ctx.xer);
	// bge cr6,0x8b0a6d88
	if (!ctx.cr6.lt) goto loc_8B0A6D88;
	// lwz r3,4(r3)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r3.u32 + 4);
	// bl 0x8b090020
	ctx.lr = 0x8B0A6D78;
	sub_8B090020(ctx, base);
	// stw r30,0(r31)
	REX_STORE_U32(ctx.r31.u32 + 0, ctx.r30.u32);
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// bl 0x8b090000
	ctx.lr = 0x8B0A6D84;
	sub_8B090000(ctx, base);
	// stw r3,4(r31)
	REX_STORE_U32(ctx.r31.u32 + 4, ctx.r3.u32);
loc_8B0A6D88:
	// addi r1,r1,112
	ctx.r1.s64 = ctx.r1.s64 + 112;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// ld r30,-24(r1)
	ctx.r30.u64 = REX_LOAD_U64(ctx.r1.u32 + -24);
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0A6E30) {
	REX_FUNC_PROLOGUE();
	// lwz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r10,36(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 36);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctr 
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	return;
}

DEFINE_REX_FUNC(sub_8B0A6E58) {
	REX_FUNC_PROLOGUE();
	// li r3,12
	ctx.r3.s64 = 12;
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0A6E80) {
	REX_FUNC_PROLOGUE();
	// lwz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r10,8(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 8);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctr 
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	return;
}

DEFINE_REX_FUNC(sub_8B0A6E90) {
	REX_FUNC_PROLOGUE();
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0A6E98) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// std r31,-16(r1)
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.r31.u64);
	// stwu r1,-96(r1)
	ea = -96 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// clrlwi r10,r4,31
	ctx.r10.u64 = ctx.r4.u32 & 0x1;
	// addi r9,r11,21128
	ctx.r9.s64 = ctx.r11.s64 + 21128;
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// cmplwi cr6,r10,0
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 0, ctx.xer);
	// stw r9,0(r3)
	REX_STORE_U32(ctx.r3.u32 + 0, ctx.r9.u32);
	// beq cr6,0x8b0a6ecc
	if (ctx.cr6.eq) goto loc_8B0A6ECC;
	// bl 0x8b090020
	ctx.lr = 0x8B0A6EC8;
	sub_8B090020(ctx, base);
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
loc_8B0A6ECC:
	// addi r1,r1,96
	ctx.r1.s64 = ctx.r1.s64 + 96;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0A7048) {
	REX_FUNC_PROLOGUE();
	PPCRegister temp{};
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// std r30,-24(r1)
	REX_STORE_U64(ctx.r1.u32 + -24, ctx.r30.u64);
	// std r31,-16(r1)
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.r31.u64);
	// stwu r1,-112(r1)
	ea = -112 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// mr r11,r4
	ctx.r11.u64 = ctx.r4.u64;
	// lwz r4,8(r3)
	ctx.r4.u64 = REX_LOAD_U32(ctx.r3.u32 + 8);
	// mr r30,r3
	ctx.r30.u64 = ctx.r3.u64;
	// cmpwi cr6,r4,0
	ctx.cr6.compare<int32_t>(ctx.r4.s32, 0, ctx.xer);
	// blt cr6,0x8b0a7128
	if (ctx.cr6.lt) goto loc_8B0A7128;
	// lwz r3,4(r3)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r3.u32 + 4);
	// li r6,72
	ctx.r6.s64 = 72;
	// add r31,r3,r11
	ctx.r31.u64 = ctx.r3.u64 + ctx.r11.u64;
	// mr r5,r31
	ctx.r5.u64 = ctx.r31.u64;
	// bl 0x8b090160
	ctx.lr = 0x8B0A7084;
	sub_8B090160(ctx, base);
	// clrlwi r11,r3,16
	ctx.r11.u64 = ctx.r3.u32 & 0xFFFF;
	// cmpw cr6,r11,r31
	ctx.cr6.compare<int32_t>(ctx.r11.s32, ctx.r31.s32, ctx.xer);
	// bge cr6,0x8b0a70d8
	if (!ctx.cr6.lt) goto loc_8B0A70D8;
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// bne cr6,0x8b0a70b4
	if (!ctx.cr6.eq) goto loc_8B0A70B4;
	// addis r11,r3,1
	ctx.r11.s64 = ctx.r3.s64 + 65536;
	// addi r11,r11,-1
	ctx.r11.s64 = ctx.r11.s64 + -1;
	// clrlwi r10,r11,16
	ctx.r10.u64 = ctx.r11.u32 & 0xFFFF;
	// cmpw cr6,r10,r31
	ctx.cr6.compare<int32_t>(ctx.r10.s32, ctx.r31.s32, ctx.xer);
	// blt cr6,0x8b0a70b4
	if (ctx.cr6.lt) goto loc_8B0A70B4;
	// addi r3,r3,-1
	ctx.r3.s64 = ctx.r3.s64 + -1;
	// b 0x8b0a70d8
	goto loc_8B0A70D8;
loc_8B0A70B4:
	// clrlwi r11,r31,16
	ctx.r11.u64 = ctx.r31.u32 & 0xFFFF;
	// cmpw cr6,r11,r31
	ctx.cr6.compare<int32_t>(ctx.r11.s32, ctx.r31.s32, ctx.xer);
	// bne cr6,0x8b0a7128
	if (!ctx.cr6.eq) goto loc_8B0A7128;
loc_8B0A70C0:
	// add r11,r3,r31
	ctx.r11.u64 = ctx.r3.u64 + ctx.r31.u64;
	// srawi r10,r11,1
	ctx.xer.ca = (ctx.r11.s32 < 0) & ((ctx.r11.u32 & 0x1) != 0);
	ctx.r10.s64 = ctx.r11.s32 >> 1;
	// addze r3,r10
	temp.s64 = ctx.r10.s64 + ctx.xer.ca;
	ctx.xer.ca = temp.u32 < ctx.r10.u32;
	ctx.r3.s64 = temp.s64;
	// clrlwi r9,r3,16
	ctx.r9.u64 = ctx.r3.u32 & 0xFFFF;
	// cmpw cr6,r9,r31
	ctx.cr6.compare<int32_t>(ctx.r9.s32, ctx.r31.s32, ctx.xer);
	// blt cr6,0x8b0a70c0
	if (ctx.cr6.lt) goto loc_8B0A70C0;
loc_8B0A70D8:
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// stw r3,4(r30)
	REX_STORE_U32(ctx.r30.u32 + 4, ctx.r3.u32);
	// rlwinm r11,r3,3,0,28
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r3.u32 | (ctx.r3.u64 << 32), 3) & 0xFFFFFFF8;
	// lwz r4,0(r30)
	ctx.r4.u64 = REX_LOAD_U32(ctx.r30.u32 + 0);
	// add r9,r3,r11
	ctx.r9.u64 = ctx.r3.u64 + ctx.r11.u64;
	// cmplwi cr6,r4,0
	ctx.cr6.compare<uint32_t>(ctx.r4.u32, 0, ctx.xer);
	// lwz r11,1144(r10)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r10.u32 + 1144);
	// lwz r3,0(r11)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r11.u32 + 0);
	// lwz r8,0(r3)
	ctx.r8.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// beq cr6,0x8b0a7114
	if (ctx.cr6.eq) goto loc_8B0A7114;
	// lwz r7,12(r8)
	ctx.r7.u64 = REX_LOAD_U32(ctx.r8.u32 + 12);
	// rlwinm r5,r9,3,0,28
	ctx.r5.u64 = __builtin_rotateleft64(ctx.r9.u32 | (ctx.r9.u64 << 32), 3) & 0xFFFFFFF8;
	// mtctr r7
	ctx.ctr.u64 = ctx.r7.u64;
	// bctrl 
	ctx.lr = 0x8B0A7110;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// b 0x8b0a7124
	goto loc_8B0A7124;
loc_8B0A7114:
	// lwz r7,4(r8)
	ctx.r7.u64 = REX_LOAD_U32(ctx.r8.u32 + 4);
	// rlwinm r4,r9,3,0,28
	ctx.r4.u64 = __builtin_rotateleft64(ctx.r9.u32 | (ctx.r9.u64 << 32), 3) & 0xFFFFFFF8;
	// mtctr r7
	ctx.ctr.u64 = ctx.r7.u64;
	// bctrl 
	ctx.lr = 0x8B0A7124;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
loc_8B0A7124:
	// stw r3,0(r30)
	REX_STORE_U32(ctx.r30.u32 + 0, ctx.r3.u32);
loc_8B0A7128:
	// addi r1,r1,112
	ctx.r1.s64 = ctx.r1.s64 + 112;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// ld r30,-24(r1)
	ctx.r30.u64 = REX_LOAD_U64(ctx.r1.u32 + -24);
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0A74C0) {
	REX_FUNC_PROLOGUE();
	PPCRegister temp{};
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9bc
	ctx.lr = 0x8B0A74C8;
	__savegprlr_29(ctx, base);
	// stwu r1,-128(r1)
	ea = -128 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lhz r8,20(r3)
	ctx.r8.u64 = REX_LOAD_U16(ctx.r3.u32 + 20);
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// mr r11,r8
	ctx.r11.u64 = ctx.r8.u64;
	// cmplwi cr6,r8,65535
	ctx.cr6.compare<uint32_t>(ctx.r8.u32, 65535, ctx.xer);
	// bne cr6,0x8b0a76cc
	if (!ctx.cr6.eq) goto loc_8B0A76CC;
	// lhz r11,22(r3)
	ctx.r11.u64 = REX_LOAD_U16(ctx.r3.u32 + 22);
	// cmpwi cr6,r11,0
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// blt cr6,0x8b0a74fc
	if (ctx.cr6.lt) goto loc_8B0A74FC;
	// lwz r10,8(r3)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r3.u32 + 8);
	// cmpw cr6,r11,r10
	ctx.cr6.compare<int32_t>(ctx.r11.s32, ctx.r10.s32, ctx.xer);
	// li r11,1
	ctx.r11.s64 = 1;
	// blt cr6,0x8b0a7500
	if (ctx.cr6.lt) goto loc_8B0A7500;
loc_8B0A74FC:
	// li r11,0
	ctx.r11.s64 = 0;
loc_8B0A7500:
	// clrlwi r11,r11,24
	ctx.r11.u64 = ctx.r11.u32 & 0xFF;
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// beq cr6,0x8b0a755c
	if (ctx.cr6.eq) goto loc_8B0A755C;
	// lhz r11,22(r31)
	ctx.r11.u64 = REX_LOAD_U16(ctx.r31.u32 + 22);
	// addi r10,r11,1
	ctx.r10.s64 = ctx.r11.s64 + 1;
	// clrlwi r11,r10,16
	ctx.r11.u64 = ctx.r10.u32 & 0xFFFF;
	// cmpwi cr6,r11,0
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// blt cr6,0x8b0a7530
	if (ctx.cr6.lt) goto loc_8B0A7530;
	// lwz r9,8(r31)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r31.u32 + 8);
	// cmpw cr6,r11,r9
	ctx.cr6.compare<int32_t>(ctx.r11.s32, ctx.r9.s32, ctx.xer);
	// li r11,1
	ctx.r11.s64 = 1;
	// blt cr6,0x8b0a7534
	if (ctx.cr6.lt) goto loc_8B0A7534;
loc_8B0A7530:
	// li r11,0
	ctx.r11.s64 = 0;
loc_8B0A7534:
	// clrlwi r11,r11,24
	ctx.r11.u64 = ctx.r11.u32 & 0xFF;
	// lis r9,0
	ctx.r9.s64 = 0;
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// ori r29,r9,65535
	ctx.r29.u64 = ctx.r9.u64 | 65535;
	// mr r11,r10
	ctx.r11.u64 = ctx.r10.u64;
	// bne cr6,0x8b0a7550
	if (!ctx.cr6.eq) goto loc_8B0A7550;
	// mr r11,r29
	ctx.r11.u64 = ctx.r29.u64;
loc_8B0A7550:
	// mr r10,r11
	ctx.r10.u64 = ctx.r11.u64;
	// sth r11,80(r1)
	REX_STORE_U16(ctx.r1.u32 + 80, ctx.r11.u16);
	// b 0x8b0a7590
	goto loc_8B0A7590;
loc_8B0A755C:
	// lwz r10,8(r31)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r31.u32 + 8);
	// li r11,0
	ctx.r11.s64 = 0;
	// lis r9,0
	ctx.r9.s64 = 0;
	// subfc r8,r10,r11
	ctx.xer.ca = ctx.r11.u32 >= ctx.r10.u32;
	ctx.r8.u64 = ctx.r11.u64 - ctx.r10.u64;
	// eqv r7,r10,r11
	ctx.r7.u64 = ~(ctx.r10.u64 ^ ctx.r11.u64);
	// ori r29,r9,65535
	ctx.r29.u64 = ctx.r9.u64 | 65535;
	// rlwinm r6,r7,1,31,31
	ctx.r6.u64 = __builtin_rotateleft64(ctx.r7.u32 | (ctx.r7.u64 << 32), 1) & 0x1;
	// addze r5,r6
	temp.s64 = ctx.r6.s64 + ctx.xer.ca;
	ctx.xer.ca = temp.u32 < ctx.r6.u32;
	ctx.r5.s64 = temp.s64;
	// clrlwi r4,r5,31
	ctx.r4.u64 = ctx.r5.u32 & 0x1;
	// addic r3,r4,-1
	ctx.xer.ca = ctx.r4.u32 > 0;
	ctx.r3.s64 = ctx.r4.s64 + -1;
	// subfe r9,r10,r10
	temp.u8 = (~ctx.r10.u32 + ctx.r10.u32 < ~ctx.r10.u32) | (~ctx.r10.u32 + ctx.r10.u32 + ctx.xer.ca < ctx.xer.ca);
	ctx.r9.u64 = ~ctx.r10.u64 + ctx.r10.u64 + ctx.xer.ca;
	ctx.xer.ca = temp.u8;
	// and r8,r9,r29
	ctx.r8.u64 = ctx.r9.u64 & ctx.r29.u64;
	// sth r8,80(r1)
	REX_STORE_U16(ctx.r1.u32 + 80, ctx.r8.u16);
loc_8B0A7590:
	// addi r11,r1,80
	ctx.r11.s64 = ctx.r1.s64 + 80;
	// lhz r30,0(r11)
	ctx.r30.u64 = REX_LOAD_U16(ctx.r11.u32 + 0);
	// mr r11,r30
	ctx.r11.u64 = ctx.r30.u64;
	// cmpwi cr6,r30,0
	ctx.cr6.compare<int32_t>(ctx.r30.s32, 0, ctx.xer);
	// blt cr6,0x8b0a75b4
	if (ctx.cr6.lt) goto loc_8B0A75B4;
	// lwz r10,8(r31)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r31.u32 + 8);
	// li r11,1
	ctx.r11.s64 = 1;
	// cmpw cr6,r30,r10
	ctx.cr6.compare<int32_t>(ctx.r30.s32, ctx.r10.s32, ctx.xer);
	// blt cr6,0x8b0a75b8
	if (ctx.cr6.lt) goto loc_8B0A75B8;
loc_8B0A75B4:
	// li r11,0
	ctx.r11.s64 = 0;
loc_8B0A75B8:
	// clrlwi r11,r11,24
	ctx.r11.u64 = ctx.r11.u32 & 0xFF;
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// bne cr6,0x8b0a76b0
	if (!ctx.cr6.eq) goto loc_8B0A76B0;
	// li r4,1
	ctx.r4.s64 = 1;
	// addi r3,r31,4
	ctx.r3.s64 = ctx.r31.s64 + 4;
	// bl 0x8b0a7048
	ctx.lr = 0x8B0A75D0;
	sub_8B0A7048(ctx, base);
	// lhz r11,22(r31)
	ctx.r11.u64 = REX_LOAD_U16(ctx.r31.u32 + 22);
	// cmpwi cr6,r11,0
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// blt cr6,0x8b0a75ec
	if (ctx.cr6.lt) goto loc_8B0A75EC;
	// lwz r10,8(r31)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r31.u32 + 8);
	// cmpw cr6,r11,r10
	ctx.cr6.compare<int32_t>(ctx.r11.s32, ctx.r10.s32, ctx.xer);
	// li r11,1
	ctx.r11.s64 = 1;
	// blt cr6,0x8b0a75f0
	if (ctx.cr6.lt) goto loc_8B0A75F0;
loc_8B0A75EC:
	// li r11,0
	ctx.r11.s64 = 0;
loc_8B0A75F0:
	// clrlwi r11,r11,24
	ctx.r11.u64 = ctx.r11.u32 & 0xFF;
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// beq cr6,0x8b0a7644
	if (ctx.cr6.eq) goto loc_8B0A7644;
	// lhz r11,22(r31)
	ctx.r11.u64 = REX_LOAD_U16(ctx.r31.u32 + 22);
	// addi r10,r11,1
	ctx.r10.s64 = ctx.r11.s64 + 1;
	// clrlwi r11,r10,16
	ctx.r11.u64 = ctx.r10.u32 & 0xFFFF;
	// cmpwi cr6,r11,0
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// blt cr6,0x8b0a7620
	if (ctx.cr6.lt) goto loc_8B0A7620;
	// lwz r9,8(r31)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r31.u32 + 8);
	// cmpw cr6,r11,r9
	ctx.cr6.compare<int32_t>(ctx.r11.s32, ctx.r9.s32, ctx.xer);
	// li r11,1
	ctx.r11.s64 = 1;
	// blt cr6,0x8b0a7624
	if (ctx.cr6.lt) goto loc_8B0A7624;
loc_8B0A7620:
	// li r11,0
	ctx.r11.s64 = 0;
loc_8B0A7624:
	// clrlwi r11,r11,24
	ctx.r11.u64 = ctx.r11.u32 & 0xFF;
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// mr r11,r10
	ctx.r11.u64 = ctx.r10.u64;
	// bne cr6,0x8b0a7638
	if (!ctx.cr6.eq) goto loc_8B0A7638;
	// mr r11,r29
	ctx.r11.u64 = ctx.r29.u64;
loc_8B0A7638:
	// mr r10,r11
	ctx.r10.u64 = ctx.r11.u64;
	// sth r11,80(r1)
	REX_STORE_U16(ctx.r1.u32 + 80, ctx.r11.u16);
	// b 0x8b0a7670
	goto loc_8B0A7670;
loc_8B0A7644:
	// lwz r10,8(r31)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r31.u32 + 8);
	// li r11,0
	ctx.r11.s64 = 0;
	// subfc r9,r10,r11
	ctx.xer.ca = ctx.r11.u32 >= ctx.r10.u32;
	ctx.r9.u64 = ctx.r11.u64 - ctx.r10.u64;
	// eqv r8,r10,r11
	ctx.r8.u64 = ~(ctx.r10.u64 ^ ctx.r11.u64);
	// rlwinm r7,r8,1,31,31
	ctx.r7.u64 = __builtin_rotateleft64(ctx.r8.u32 | (ctx.r8.u64 << 32), 1) & 0x1;
	// addze r6,r7
	temp.s64 = ctx.r7.s64 + ctx.xer.ca;
	ctx.xer.ca = temp.u32 < ctx.r7.u32;
	ctx.r6.s64 = temp.s64;
	// clrlwi r5,r6,31
	ctx.r5.u64 = ctx.r6.u32 & 0x1;
	// addic r4,r5,-1
	ctx.xer.ca = ctx.r5.u32 > 0;
	ctx.r4.s64 = ctx.r5.s64 + -1;
	// subfe r10,r3,r3
	temp.u8 = (~ctx.r3.u32 + ctx.r3.u32 < ~ctx.r3.u32) | (~ctx.r3.u32 + ctx.r3.u32 + ctx.xer.ca < ctx.xer.ca);
	ctx.r10.u64 = ~ctx.r3.u64 + ctx.r3.u64 + ctx.xer.ca;
	ctx.xer.ca = temp.u8;
	// and r9,r10,r29
	ctx.r9.u64 = ctx.r10.u64 & ctx.r29.u64;
	// sth r9,80(r1)
	REX_STORE_U16(ctx.r1.u32 + 80, ctx.r9.u16);
loc_8B0A7670:
	// addi r11,r1,80
	ctx.r11.s64 = ctx.r1.s64 + 80;
	// lhz r30,0(r11)
	ctx.r30.u64 = REX_LOAD_U16(ctx.r11.u32 + 0);
	// mr r11,r30
	ctx.r11.u64 = ctx.r30.u64;
	// cmpwi cr6,r30,0
	ctx.cr6.compare<int32_t>(ctx.r30.s32, 0, ctx.xer);
	// blt cr6,0x8b0a7694
	if (ctx.cr6.lt) goto loc_8B0A7694;
	// lwz r10,8(r31)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r31.u32 + 8);
	// li r11,1
	ctx.r11.s64 = 1;
	// cmpw cr6,r30,r10
	ctx.cr6.compare<int32_t>(ctx.r30.s32, ctx.r10.s32, ctx.xer);
	// blt cr6,0x8b0a7698
	if (ctx.cr6.lt) goto loc_8B0A7698;
loc_8B0A7694:
	// li r11,0
	ctx.r11.s64 = 0;
loc_8B0A7698:
	// clrlwi r11,r11,24
	ctx.r11.u64 = ctx.r11.u32 & 0xFF;
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// bne cr6,0x8b0a76b0
	if (!ctx.cr6.eq) goto loc_8B0A76B0;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// addi r3,r11,21528
	ctx.r3.s64 = ctx.r11.s64 + 21528;
	// bl 0x8b0df3c8
	ctx.lr = 0x8B0A76B0;
	sub_8B0DF3C8(ctx, base);
loc_8B0A76B0:
	// lwz r11,4(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 4);
	// mr r8,r30
	ctx.r8.u64 = ctx.r30.u64;
	// sth r30,22(r31)
	REX_STORE_U16(ctx.r31.u32 + 22, ctx.r30.u16);
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// stw r11,24(r31)
	REX_STORE_U32(ctx.r31.u32 + 24, ctx.r11.u32);
	// addi r1,r1,128
	ctx.r1.s64 = ctx.r1.s64 + 128;
	// b 0x8b0cba0c
	__restgprlr_29(ctx, base);
	return;
loc_8B0A76CC:
	// rlwinm r10,r11,3,0,28
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 3) & 0xFFFFFFF8;
	// lwz r9,4(r31)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r31.u32 + 4);
	// mr r3,r8
	ctx.r3.u64 = ctx.r8.u64;
	// add r11,r11,r10
	ctx.r11.u64 = ctx.r11.u64 + ctx.r10.u64;
	// rlwinm r11,r11,3,0,28
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 3) & 0xFFFFFFF8;
	// add r10,r11,r9
	ctx.r10.u64 = ctx.r11.u64 + ctx.r9.u64;
	// lwz r11,4(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 4);
	// lhz r9,2(r10)
	ctx.r9.u64 = REX_LOAD_U16(ctx.r10.u32 + 2);
	// stw r11,24(r31)
	REX_STORE_U32(ctx.r31.u32 + 24, ctx.r11.u32);
	// sth r9,20(r31)
	REX_STORE_U16(ctx.r31.u32 + 20, ctx.r9.u16);
	// addi r1,r1,128
	ctx.r1.s64 = ctx.r1.s64 + 128;
	// b 0x8b0cba0c
	__restgprlr_29(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0A8978) {
	REX_FUNC_PROLOGUE();
	// std r31,-8(r1)
	REX_STORE_U64(ctx.r1.u32 + -8, ctx.r31.u64);
	// lis r4,-29938
	ctx.r4.s64 = -1962016768;
	// lis r10,0
	ctx.r10.s64 = 0;
	// lis r11,-29938
	ctx.r11.s64 = -1962016768;
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// lhz r3,16(r3)
	ctx.r3.u64 = REX_LOAD_U16(ctx.r3.u32 + 16);
	// ori r9,r10,65535
	ctx.r9.u64 = ctx.r10.u64 | 65535;
	// lwz r10,19648(r4)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r4.u32 + 19648);
	// addi r11,r11,19640
	ctx.r11.s64 = ctx.r11.s64 + 19640;
loc_8B0A899C:
	// clrlwi r8,r10,31
	ctx.r8.u64 = ctx.r10.u32 & 0x1;
	// cmplwi cr6,r8,0
	ctx.cr6.compare<uint32_t>(ctx.r8.u32, 0, ctx.xer);
	// bne cr6,0x8b0a89cc
	if (!ctx.cr6.eq) goto loc_8B0A89CC;
	// ori r10,r10,1
	ctx.r10.u64 = ctx.r10.u64 | 1;
	// sth r9,0(r11)
	REX_STORE_U16(ctx.r11.u32 + 0, ctx.r9.u16);
	// li r6,1
	ctx.r6.s64 = 1;
	// sth r9,2(r11)
	REX_STORE_U16(ctx.r11.u32 + 2, ctx.r9.u16);
	// mr r8,r9
	ctx.r8.u64 = ctx.r9.u64;
	// stw r10,19648(r4)
	REX_STORE_U32(ctx.r4.u32 + 19648, ctx.r10.u32);
	// mr r7,r9
	ctx.r7.u64 = ctx.r9.u64;
	// sth r9,4(r11)
	REX_STORE_U16(ctx.r11.u32 + 4, ctx.r9.u16);
	// sth r6,6(r11)
	REX_STORE_U16(ctx.r11.u32 + 6, ctx.r6.u16);
loc_8B0A89CC:
	// clrlwi r5,r3,16
	ctx.r5.u64 = ctx.r3.u32 & 0xFFFF;
	// cmplwi cr6,r5,65535
	ctx.cr6.compare<uint32_t>(ctx.r5.u32, 65535, ctx.xer);
	// beq cr6,0x8b0a89f0
	if (ctx.cr6.eq) goto loc_8B0A89F0;
	// rlwinm r8,r5,3,0,28
	ctx.r8.u64 = __builtin_rotateleft64(ctx.r5.u32 | (ctx.r5.u64 << 32), 3) & 0xFFFFFFF8;
	// lwz r7,4(r31)
	ctx.r7.u64 = REX_LOAD_U32(ctx.r31.u32 + 4);
	// add r8,r5,r8
	ctx.r8.u64 = ctx.r5.u64 + ctx.r8.u64;
	// rlwinm r8,r8,3,0,28
	ctx.r8.u64 = __builtin_rotateleft64(ctx.r8.u32 | (ctx.r8.u64 << 32), 3) & 0xFFFFFFF8;
	// add r8,r8,r7
	ctx.r8.u64 = ctx.r8.u64 + ctx.r7.u64;
	// b 0x8b0a89f4
	goto loc_8B0A89F4;
loc_8B0A89F0:
	// mr r8,r11
	ctx.r8.u64 = ctx.r11.u64;
loc_8B0A89F4:
	// lhz r8,0(r8)
	ctx.r8.u64 = REX_LOAD_U16(ctx.r8.u32 + 0);
	// cmplwi cr6,r8,65535
	ctx.cr6.compare<uint32_t>(ctx.r8.u32, 65535, ctx.xer);
	// beq cr6,0x8b0a8a60
	if (ctx.cr6.eq) goto loc_8B0A8A60;
	// clrlwi r8,r10,31
	ctx.r8.u64 = ctx.r10.u32 & 0x1;
	// cmplwi cr6,r8,0
	ctx.cr6.compare<uint32_t>(ctx.r8.u32, 0, ctx.xer);
	// bne cr6,0x8b0a8a30
	if (!ctx.cr6.eq) goto loc_8B0A8A30;
	// ori r10,r10,1
	ctx.r10.u64 = ctx.r10.u64 | 1;
	// sth r9,0(r11)
	REX_STORE_U16(ctx.r11.u32 + 0, ctx.r9.u16);
	// li r6,1
	ctx.r6.s64 = 1;
	// sth r9,2(r11)
	REX_STORE_U16(ctx.r11.u32 + 2, ctx.r9.u16);
	// mr r8,r9
	ctx.r8.u64 = ctx.r9.u64;
	// stw r10,19648(r4)
	REX_STORE_U32(ctx.r4.u32 + 19648, ctx.r10.u32);
	// mr r7,r9
	ctx.r7.u64 = ctx.r9.u64;
	// sth r9,4(r11)
	REX_STORE_U16(ctx.r11.u32 + 4, ctx.r9.u16);
	// sth r6,6(r11)
	REX_STORE_U16(ctx.r11.u32 + 6, ctx.r6.u16);
loc_8B0A8A30:
	// cmplwi cr6,r5,65535
	ctx.cr6.compare<uint32_t>(ctx.r5.u32, 65535, ctx.xer);
	// beq cr6,0x8b0a8a54
	if (ctx.cr6.eq) goto loc_8B0A8A54;
	// rlwinm r8,r5,3,0,28
	ctx.r8.u64 = __builtin_rotateleft64(ctx.r5.u32 | (ctx.r5.u64 << 32), 3) & 0xFFFFFFF8;
	// lwz r7,4(r31)
	ctx.r7.u64 = REX_LOAD_U32(ctx.r31.u32 + 4);
	// add r8,r5,r8
	ctx.r8.u64 = ctx.r5.u64 + ctx.r8.u64;
	// rlwinm r8,r8,3,0,28
	ctx.r8.u64 = __builtin_rotateleft64(ctx.r8.u32 | (ctx.r8.u64 << 32), 3) & 0xFFFFFFF8;
	// add r8,r8,r7
	ctx.r8.u64 = ctx.r8.u64 + ctx.r7.u64;
	// lhz r3,0(r8)
	ctx.r3.u64 = REX_LOAD_U16(ctx.r8.u32 + 0);
	// b 0x8b0a899c
	goto loc_8B0A899C;
loc_8B0A8A54:
	// lhz r3,0(r11)
	ctx.r3.u64 = REX_LOAD_U16(ctx.r11.u32 + 0);
	// mr r8,r11
	ctx.r8.u64 = ctx.r11.u64;
	// b 0x8b0a899c
	goto loc_8B0A899C;
loc_8B0A8A60:
	// ld r31,-8(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -8);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0A8E20) {
	REX_FUNC_PROLOGUE();
	// lis r11,0
	ctx.r11.s64 = 0;
	// rlwinm r10,r4,3,13,28
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r4.u32 | (ctx.r4.u64 << 32), 3) & 0x7FFF8;
	// clrlwi r9,r4,16
	ctx.r9.u64 = ctx.r4.u32 & 0xFFFF;
	// ori r11,r11,65535
	ctx.r11.u64 = ctx.r11.u64 | 65535;
	// add r9,r9,r10
	ctx.r9.u64 = ctx.r9.u64 + ctx.r10.u64;
	// lwz r10,4(r3)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r3.u32 + 4);
	// mr r7,r11
	ctx.r7.u64 = ctx.r11.u64;
	// mr r8,r11
	ctx.r8.u64 = ctx.r11.u64;
	// rlwinm r11,r9,3,0,28
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r9.u32 | (ctx.r9.u64 << 32), 3) & 0xFFFFFFF8;
	// li r9,0
	ctx.r9.s64 = 0;
	// add r11,r11,r10
	ctx.r11.u64 = ctx.r11.u64 + ctx.r10.u64;
	// clrlwi r10,r5,16
	ctx.r10.u64 = ctx.r5.u32 & 0xFFFF;
	// cmplwi cr6,r10,65535
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 65535, ctx.xer);
	// sth r5,4(r11)
	REX_STORE_U16(ctx.r11.u32 + 4, ctx.r5.u16);
	// sth r7,2(r11)
	REX_STORE_U16(ctx.r11.u32 + 2, ctx.r7.u16);
	// sth r7,0(r11)
	REX_STORE_U16(ctx.r11.u32 + 0, ctx.r7.u16);
	// sth r9,6(r11)
	REX_STORE_U16(ctx.r11.u32 + 6, ctx.r9.u16);
	// beq cr6,0x8b0a8ea0
	if (ctx.cr6.eq) goto loc_8B0A8EA0;
	// clrlwi r11,r6,24
	ctx.r11.u64 = ctx.r6.u32 & 0xFF;
	// lwz r9,4(r3)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r3.u32 + 4);
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// rlwinm r11,r10,3,0,28
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r10.u32 | (ctx.r10.u64 << 32), 3) & 0xFFFFFFF8;
	// beq cr6,0x8b0a8e8c
	if (ctx.cr6.eq) goto loc_8B0A8E8C;
	// add r8,r10,r11
	ctx.r8.u64 = ctx.r10.u64 + ctx.r11.u64;
	// rlwinm r7,r8,3,0,28
	ctx.r7.u64 = __builtin_rotateleft64(ctx.r8.u32 | (ctx.r8.u64 << 32), 3) & 0xFFFFFFF8;
	// sthx r4,r7,r9
	REX_STORE_U16(ctx.r7.u32 + ctx.r9.u32, ctx.r4.u16);
	// b 0x8b0a8ea4
	goto loc_8B0A8EA4;
loc_8B0A8E8C:
	// add r11,r10,r11
	ctx.r11.u64 = ctx.r10.u64 + ctx.r11.u64;
	// rlwinm r11,r11,3,0,28
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 3) & 0xFFFFFFF8;
	// add r10,r11,r9
	ctx.r10.u64 = ctx.r11.u64 + ctx.r9.u64;
	// sth r4,2(r10)
	REX_STORE_U16(ctx.r10.u32 + 2, ctx.r4.u16);
	// b 0x8b0a8ea4
	goto loc_8B0A8EA4;
loc_8B0A8EA0:
	// sth r4,16(r3)
	REX_STORE_U16(ctx.r3.u32 + 16, ctx.r4.u16);
loc_8B0A8EA4:
	// b 0x8b0a79f0
	sub_8B0A79F0(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0A8EA8) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9ac
	ctx.lr = 0x8B0A8EB0;
	__savegprlr_25(ctx, base);
	// stwu r1,-144(r1)
	ea = -144 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lhz r11,16(r3)
	ctx.r11.u64 = REX_LOAD_U16(ctx.r3.u32 + 16);
	// clrlwi r26,r4,16
	ctx.r26.u64 = ctx.r4.u32 & 0xFFFF;
	// mr r28,r3
	ctx.r28.u64 = ctx.r3.u64;
	// li r27,1
	ctx.r27.s64 = 1;
	// cmplw cr6,r26,r11
	ctx.cr6.compare<uint32_t>(ctx.r26.u32, ctx.r11.u32, ctx.xer);
	// beq cr6,0x8b0a9d4c
	if (ctx.cr6.eq) goto loc_8B0A9D4C;
	// lis r29,-29938
	ctx.r29.s64 = -1962016768;
	// lis r11,-29938
	ctx.r11.s64 = -1962016768;
	// lis r10,0
	ctx.r10.s64 = 0;
	// addi r31,r11,19640
	ctx.r31.s64 = ctx.r11.s64 + 19640;
	// ori r30,r10,65535
	ctx.r30.u64 = ctx.r10.u64 | 65535;
	// lwz r11,19648(r29)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r29.u32 + 19648);
	// li r25,0
	ctx.r25.s64 = 0;
loc_8B0A8EE8:
	// clrlwi r10,r11,31
	ctx.r10.u64 = ctx.r11.u32 & 0x1;
	// cmplwi cr6,r10,0
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 0, ctx.xer);
	// bne cr6,0x8b0a8f1c
	if (!ctx.cr6.eq) goto loc_8B0A8F1C;
	// ori r11,r11,1
	ctx.r11.u64 = ctx.r11.u64 | 1;
	// sth r30,0(r31)
	REX_STORE_U16(ctx.r31.u32 + 0, ctx.r30.u16);
	// mr r10,r30
	ctx.r10.u64 = ctx.r30.u64;
	// sth r30,2(r31)
	REX_STORE_U16(ctx.r31.u32 + 2, ctx.r30.u16);
	// mr r9,r30
	ctx.r9.u64 = ctx.r30.u64;
	// stw r11,19648(r29)
	REX_STORE_U32(ctx.r29.u32 + 19648, ctx.r11.u32);
	// mr r8,r30
	ctx.r8.u64 = ctx.r30.u64;
	// sth r30,4(r31)
	REX_STORE_U16(ctx.r31.u32 + 4, ctx.r30.u16);
	// mr r10,r27
	ctx.r10.u64 = ctx.r27.u64;
	// sth r27,6(r31)
	REX_STORE_U16(ctx.r31.u32 + 6, ctx.r27.u16);
loc_8B0A8F1C:
	// cmplwi cr6,r26,65535
	ctx.cr6.compare<uint32_t>(ctx.r26.u32, 65535, ctx.xer);
	// beq cr6,0x8b0a8f3c
	if (ctx.cr6.eq) goto loc_8B0A8F3C;
	// rlwinm r10,r26,3,0,28
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r26.u32 | (ctx.r26.u64 << 32), 3) & 0xFFFFFFF8;
	// lwz r9,4(r28)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r28.u32 + 4);
	// add r10,r26,r10
	ctx.r10.u64 = ctx.r26.u64 + ctx.r10.u64;
	// rlwinm r10,r10,3,0,28
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r10.u32 | (ctx.r10.u64 << 32), 3) & 0xFFFFFFF8;
	// add r10,r10,r9
	ctx.r10.u64 = ctx.r10.u64 + ctx.r9.u64;
	// b 0x8b0a8f40
	goto loc_8B0A8F40;
loc_8B0A8F3C:
	// mr r10,r31
	ctx.r10.u64 = ctx.r31.u64;
loc_8B0A8F40:
	// lhz r10,6(r10)
	ctx.r10.u64 = REX_LOAD_U16(ctx.r10.u32 + 6);
	// cmplwi cr6,r10,1
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 1, ctx.xer);
	// bne cr6,0x8b0a9d4c
	if (!ctx.cr6.eq) goto loc_8B0A9D4C;
	// clrlwi r10,r11,31
	ctx.r10.u64 = ctx.r11.u32 & 0x1;
	// cmplwi cr6,r10,0
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 0, ctx.xer);
	// bne cr6,0x8b0a8f80
	if (!ctx.cr6.eq) goto loc_8B0A8F80;
	// ori r11,r11,1
	ctx.r11.u64 = ctx.r11.u64 | 1;
	// sth r30,0(r31)
	REX_STORE_U16(ctx.r31.u32 + 0, ctx.r30.u16);
	// mr r10,r30
	ctx.r10.u64 = ctx.r30.u64;
	// sth r30,2(r31)
	REX_STORE_U16(ctx.r31.u32 + 2, ctx.r30.u16);
	// mr r9,r30
	ctx.r9.u64 = ctx.r30.u64;
	// stw r11,19648(r29)
	REX_STORE_U32(ctx.r29.u32 + 19648, ctx.r11.u32);
	// mr r8,r30
	ctx.r8.u64 = ctx.r30.u64;
	// sth r30,4(r31)
	REX_STORE_U16(ctx.r31.u32 + 4, ctx.r30.u16);
	// mr r10,r27
	ctx.r10.u64 = ctx.r27.u64;
	// sth r27,6(r31)
	REX_STORE_U16(ctx.r31.u32 + 6, ctx.r27.u16);
loc_8B0A8F80:
	// cmplwi cr6,r26,65535
	ctx.cr6.compare<uint32_t>(ctx.r26.u32, 65535, ctx.xer);
	// beq cr6,0x8b0a8fa0
	if (ctx.cr6.eq) goto loc_8B0A8FA0;
	// rlwinm r10,r26,3,0,28
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r26.u32 | (ctx.r26.u64 << 32), 3) & 0xFFFFFFF8;
	// lwz r9,4(r28)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r28.u32 + 4);
	// add r10,r26,r10
	ctx.r10.u64 = ctx.r26.u64 + ctx.r10.u64;
	// rlwinm r10,r10,3,0,28
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r10.u32 | (ctx.r10.u64 << 32), 3) & 0xFFFFFFF8;
	// add r10,r10,r9
	ctx.r10.u64 = ctx.r10.u64 + ctx.r9.u64;
	// b 0x8b0a8fa4
	goto loc_8B0A8FA4;
loc_8B0A8FA0:
	// mr r10,r31
	ctx.r10.u64 = ctx.r31.u64;
loc_8B0A8FA4:
	// clrlwi r9,r11,31
	ctx.r9.u64 = ctx.r11.u32 & 0x1;
	// lhz r4,4(r10)
	ctx.r4.u64 = REX_LOAD_U16(ctx.r10.u32 + 4);
	// cmplwi cr6,r9,0
	ctx.cr6.compare<uint32_t>(ctx.r9.u32, 0, ctx.xer);
	// bne cr6,0x8b0a8fdc
	if (!ctx.cr6.eq) goto loc_8B0A8FDC;
	// ori r11,r11,1
	ctx.r11.u64 = ctx.r11.u64 | 1;
	// sth r30,0(r31)
	REX_STORE_U16(ctx.r31.u32 + 0, ctx.r30.u16);
	// mr r10,r30
	ctx.r10.u64 = ctx.r30.u64;
	// sth r30,2(r31)
	REX_STORE_U16(ctx.r31.u32 + 2, ctx.r30.u16);
	// mr r9,r30
	ctx.r9.u64 = ctx.r30.u64;
	// stw r11,19648(r29)
	REX_STORE_U32(ctx.r29.u32 + 19648, ctx.r11.u32);
	// mr r8,r30
	ctx.r8.u64 = ctx.r30.u64;
	// sth r30,4(r31)
	REX_STORE_U16(ctx.r31.u32 + 4, ctx.r30.u16);
	// mr r10,r27
	ctx.r10.u64 = ctx.r27.u64;
	// sth r27,6(r31)
	REX_STORE_U16(ctx.r31.u32 + 6, ctx.r27.u16);
loc_8B0A8FDC:
	// clrlwi r5,r4,16
	ctx.r5.u64 = ctx.r4.u32 & 0xFFFF;
	// cmplwi cr6,r5,65535
	ctx.cr6.compare<uint32_t>(ctx.r5.u32, 65535, ctx.xer);
	// beq cr6,0x8b0a9000
	if (ctx.cr6.eq) goto loc_8B0A9000;
	// rlwinm r10,r5,3,0,28
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r5.u32 | (ctx.r5.u64 << 32), 3) & 0xFFFFFFF8;
	// lwz r9,4(r28)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r28.u32 + 4);
	// add r10,r5,r10
	ctx.r10.u64 = ctx.r5.u64 + ctx.r10.u64;
	// rlwinm r10,r10,3,0,28
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r10.u32 | (ctx.r10.u64 << 32), 3) & 0xFFFFFFF8;
	// add r10,r10,r9
	ctx.r10.u64 = ctx.r10.u64 + ctx.r9.u64;
	// b 0x8b0a9004
	goto loc_8B0A9004;
loc_8B0A9000:
	// mr r10,r31
	ctx.r10.u64 = ctx.r31.u64;
loc_8B0A9004:
	// lhz r10,0(r10)
	ctx.r10.u64 = REX_LOAD_U16(ctx.r10.u32 + 0);
	// cmplw cr6,r26,r10
	ctx.cr6.compare<uint32_t>(ctx.r26.u32, ctx.r10.u32, ctx.xer);
	// clrlwi r10,r11,31
	ctx.r10.u64 = ctx.r11.u32 & 0x1;
	// bne cr6,0x8b0a96a4
	if (!ctx.cr6.eq) goto loc_8B0A96A4;
	// cmplwi cr6,r10,0
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 0, ctx.xer);
	// bne cr6,0x8b0a9044
	if (!ctx.cr6.eq) goto loc_8B0A9044;
	// ori r11,r11,1
	ctx.r11.u64 = ctx.r11.u64 | 1;
	// sth r30,0(r31)
	REX_STORE_U16(ctx.r31.u32 + 0, ctx.r30.u16);
	// mr r10,r30
	ctx.r10.u64 = ctx.r30.u64;
	// sth r30,2(r31)
	REX_STORE_U16(ctx.r31.u32 + 2, ctx.r30.u16);
	// mr r9,r30
	ctx.r9.u64 = ctx.r30.u64;
	// stw r11,19648(r29)
	REX_STORE_U32(ctx.r29.u32 + 19648, ctx.r11.u32);
	// mr r8,r30
	ctx.r8.u64 = ctx.r30.u64;
	// sth r30,4(r31)
	REX_STORE_U16(ctx.r31.u32 + 4, ctx.r30.u16);
	// mr r10,r27
	ctx.r10.u64 = ctx.r27.u64;
	// sth r27,6(r31)
	REX_STORE_U16(ctx.r31.u32 + 6, ctx.r27.u16);
loc_8B0A9044:
	// cmplwi cr6,r5,65535
	ctx.cr6.compare<uint32_t>(ctx.r5.u32, 65535, ctx.xer);
	// beq cr6,0x8b0a9064
	if (ctx.cr6.eq) goto loc_8B0A9064;
	// rlwinm r10,r5,3,0,28
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r5.u32 | (ctx.r5.u64 << 32), 3) & 0xFFFFFFF8;
	// lwz r9,4(r28)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r28.u32 + 4);
	// add r10,r5,r10
	ctx.r10.u64 = ctx.r5.u64 + ctx.r10.u64;
	// rlwinm r10,r10,3,0,28
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r10.u32 | (ctx.r10.u64 << 32), 3) & 0xFFFFFFF8;
	// add r10,r10,r9
	ctx.r10.u64 = ctx.r10.u64 + ctx.r9.u64;
	// b 0x8b0a9068
	goto loc_8B0A9068;
loc_8B0A9064:
	// mr r10,r31
	ctx.r10.u64 = ctx.r31.u64;
loc_8B0A9068:
	// clrlwi r9,r11,31
	ctx.r9.u64 = ctx.r11.u32 & 0x1;
	// lhz r3,2(r10)
	ctx.r3.u64 = REX_LOAD_U16(ctx.r10.u32 + 2);
	// cmplwi cr6,r9,0
	ctx.cr6.compare<uint32_t>(ctx.r9.u32, 0, ctx.xer);
	// bne cr6,0x8b0a90a0
	if (!ctx.cr6.eq) goto loc_8B0A90A0;
	// ori r11,r11,1
	ctx.r11.u64 = ctx.r11.u64 | 1;
	// sth r30,0(r31)
	REX_STORE_U16(ctx.r31.u32 + 0, ctx.r30.u16);
	// mr r10,r30
	ctx.r10.u64 = ctx.r30.u64;
	// sth r30,2(r31)
	REX_STORE_U16(ctx.r31.u32 + 2, ctx.r30.u16);
	// mr r9,r30
	ctx.r9.u64 = ctx.r30.u64;
	// stw r11,19648(r29)
	REX_STORE_U32(ctx.r29.u32 + 19648, ctx.r11.u32);
	// mr r8,r30
	ctx.r8.u64 = ctx.r30.u64;
	// sth r30,4(r31)
	REX_STORE_U16(ctx.r31.u32 + 4, ctx.r30.u16);
	// mr r10,r27
	ctx.r10.u64 = ctx.r27.u64;
	// sth r27,6(r31)
	REX_STORE_U16(ctx.r31.u32 + 6, ctx.r27.u16);
loc_8B0A90A0:
	// clrlwi r10,r3,16
	ctx.r10.u64 = ctx.r3.u32 & 0xFFFF;
	// cmplwi cr6,r10,65535
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 65535, ctx.xer);
	// beq cr6,0x8b0a90c4
	if (ctx.cr6.eq) goto loc_8B0A90C4;
	// rlwinm r9,r10,3,0,28
	ctx.r9.u64 = __builtin_rotateleft64(ctx.r10.u32 | (ctx.r10.u64 << 32), 3) & 0xFFFFFFF8;
	// lwz r8,4(r28)
	ctx.r8.u64 = REX_LOAD_U32(ctx.r28.u32 + 4);
	// add r9,r10,r9
	ctx.r9.u64 = ctx.r10.u64 + ctx.r9.u64;
	// rlwinm r9,r9,3,0,28
	ctx.r9.u64 = __builtin_rotateleft64(ctx.r9.u32 | (ctx.r9.u64 << 32), 3) & 0xFFFFFFF8;
	// add r9,r9,r8
	ctx.r9.u64 = ctx.r9.u64 + ctx.r8.u64;
	// b 0x8b0a90c8
	goto loc_8B0A90C8;
loc_8B0A90C4:
	// mr r9,r31
	ctx.r9.u64 = ctx.r31.u64;
loc_8B0A90C8:
	// lhz r9,6(r9)
	ctx.r9.u64 = REX_LOAD_U16(ctx.r9.u32 + 6);
	// cmplwi cr6,r9,0
	ctx.cr6.compare<uint32_t>(ctx.r9.u32, 0, ctx.xer);
	// bne cr6,0x8b0a91cc
	if (!ctx.cr6.eq) goto loc_8B0A91CC;
	// rlwinm r11,r10,3,0,28
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r10.u32 | (ctx.r10.u64 << 32), 3) & 0xFFFFFFF8;
	// rlwinm r9,r5,3,0,28
	ctx.r9.u64 = __builtin_rotateleft64(ctx.r5.u32 | (ctx.r5.u64 << 32), 3) & 0xFFFFFFF8;
	// add r11,r10,r11
	ctx.r11.u64 = ctx.r10.u64 + ctx.r11.u64;
	// lwz r10,4(r28)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r28.u32 + 4);
	// add r9,r5,r9
	ctx.r9.u64 = ctx.r5.u64 + ctx.r9.u64;
	// rlwinm r11,r11,3,0,28
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 3) & 0xFFFFFFF8;
	// mr r3,r28
	ctx.r3.u64 = ctx.r28.u64;
	// add r8,r11,r10
	ctx.r8.u64 = ctx.r11.u64 + ctx.r10.u64;
	// rlwinm r11,r9,3,0,28
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r9.u32 | (ctx.r9.u64 << 32), 3) & 0xFFFFFFF8;
	// sth r27,6(r8)
	REX_STORE_U16(ctx.r8.u32 + 6, ctx.r27.u16);
	// lwz r10,4(r28)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r28.u32 + 4);
	// add r7,r11,r10
	ctx.r7.u64 = ctx.r11.u64 + ctx.r10.u64;
	// sth r25,6(r7)
	REX_STORE_U16(ctx.r7.u32 + 6, ctx.r25.u16);
	// bl 0x8b0a7700
	ctx.lr = 0x8B0A910C;
	sub_8B0A7700(ctx, base);
	// lwz r11,19648(r29)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r29.u32 + 19648);
	// clrlwi r6,r11,31
	ctx.r6.u64 = ctx.r11.u32 & 0x1;
	// cmplwi cr6,r6,0
	ctx.cr6.compare<uint32_t>(ctx.r6.u32, 0, ctx.xer);
	// bne cr6,0x8b0a9144
	if (!ctx.cr6.eq) goto loc_8B0A9144;
	// ori r11,r11,1
	ctx.r11.u64 = ctx.r11.u64 | 1;
	// sth r30,0(r31)
	REX_STORE_U16(ctx.r31.u32 + 0, ctx.r30.u16);
	// mr r10,r30
	ctx.r10.u64 = ctx.r30.u64;
	// sth r30,2(r31)
	REX_STORE_U16(ctx.r31.u32 + 2, ctx.r30.u16);
	// mr r9,r30
	ctx.r9.u64 = ctx.r30.u64;
	// stw r11,19648(r29)
	REX_STORE_U32(ctx.r29.u32 + 19648, ctx.r11.u32);
	// mr r8,r30
	ctx.r8.u64 = ctx.r30.u64;
	// sth r30,4(r31)
	REX_STORE_U16(ctx.r31.u32 + 4, ctx.r30.u16);
	// mr r10,r27
	ctx.r10.u64 = ctx.r27.u64;
	// sth r27,6(r31)
	REX_STORE_U16(ctx.r31.u32 + 6, ctx.r27.u16);
loc_8B0A9144:
	// cmplwi cr6,r26,65535
	ctx.cr6.compare<uint32_t>(ctx.r26.u32, 65535, ctx.xer);
	// beq cr6,0x8b0a9164
	if (ctx.cr6.eq) goto loc_8B0A9164;
	// rlwinm r10,r26,3,0,28
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r26.u32 | (ctx.r26.u64 << 32), 3) & 0xFFFFFFF8;
	// lwz r9,4(r28)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r28.u32 + 4);
	// add r10,r26,r10
	ctx.r10.u64 = ctx.r26.u64 + ctx.r10.u64;
	// rlwinm r10,r10,3,0,28
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r10.u32 | (ctx.r10.u64 << 32), 3) & 0xFFFFFFF8;
	// add r10,r10,r9
	ctx.r10.u64 = ctx.r10.u64 + ctx.r9.u64;
	// b 0x8b0a9168
	goto loc_8B0A9168;
loc_8B0A9164:
	// mr r10,r31
	ctx.r10.u64 = ctx.r31.u64;
loc_8B0A9168:
	// clrlwi r9,r11,31
	ctx.r9.u64 = ctx.r11.u32 & 0x1;
	// lhz r4,4(r10)
	ctx.r4.u64 = REX_LOAD_U16(ctx.r10.u32 + 4);
	// cmplwi cr6,r9,0
	ctx.cr6.compare<uint32_t>(ctx.r9.u32, 0, ctx.xer);
	// bne cr6,0x8b0a91a0
	if (!ctx.cr6.eq) goto loc_8B0A91A0;
	// ori r11,r11,1
	ctx.r11.u64 = ctx.r11.u64 | 1;
	// sth r30,0(r31)
	REX_STORE_U16(ctx.r31.u32 + 0, ctx.r30.u16);
	// mr r10,r30
	ctx.r10.u64 = ctx.r30.u64;
	// sth r30,2(r31)
	REX_STORE_U16(ctx.r31.u32 + 2, ctx.r30.u16);
	// mr r9,r30
	ctx.r9.u64 = ctx.r30.u64;
	// stw r11,19648(r29)
	REX_STORE_U32(ctx.r29.u32 + 19648, ctx.r11.u32);
	// mr r8,r30
	ctx.r8.u64 = ctx.r30.u64;
	// sth r30,4(r31)
	REX_STORE_U16(ctx.r31.u32 + 4, ctx.r30.u16);
	// mr r10,r27
	ctx.r10.u64 = ctx.r27.u64;
	// sth r27,6(r31)
	REX_STORE_U16(ctx.r31.u32 + 6, ctx.r27.u16);
loc_8B0A91A0:
	// clrlwi r5,r4,16
	ctx.r5.u64 = ctx.r4.u32 & 0xFFFF;
	// cmplwi cr6,r5,65535
	ctx.cr6.compare<uint32_t>(ctx.r5.u32, 65535, ctx.xer);
	// beq cr6,0x8b0a91c4
	if (ctx.cr6.eq) goto loc_8B0A91C4;
	// rlwinm r10,r5,3,0,28
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r5.u32 | (ctx.r5.u64 << 32), 3) & 0xFFFFFFF8;
	// lwz r9,4(r28)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r28.u32 + 4);
	// add r10,r5,r10
	ctx.r10.u64 = ctx.r5.u64 + ctx.r10.u64;
	// rlwinm r10,r10,3,0,28
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r10.u32 | (ctx.r10.u64 << 32), 3) & 0xFFFFFFF8;
	// add r10,r10,r9
	ctx.r10.u64 = ctx.r10.u64 + ctx.r9.u64;
	// b 0x8b0a91c8
	goto loc_8B0A91C8;
loc_8B0A91C4:
	// mr r10,r31
	ctx.r10.u64 = ctx.r31.u64;
loc_8B0A91C8:
	// lhz r3,2(r10)
	ctx.r3.u64 = REX_LOAD_U16(ctx.r10.u32 + 2);
loc_8B0A91CC:
	// clrlwi r10,r11,31
	ctx.r10.u64 = ctx.r11.u32 & 0x1;
	// cmplwi cr6,r10,0
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 0, ctx.xer);
	// bne cr6,0x8b0a9200
	if (!ctx.cr6.eq) goto loc_8B0A9200;
	// ori r11,r11,1
	ctx.r11.u64 = ctx.r11.u64 | 1;
	// sth r30,0(r31)
	REX_STORE_U16(ctx.r31.u32 + 0, ctx.r30.u16);
	// mr r10,r30
	ctx.r10.u64 = ctx.r30.u64;
	// sth r30,2(r31)
	REX_STORE_U16(ctx.r31.u32 + 2, ctx.r30.u16);
	// mr r9,r30
	ctx.r9.u64 = ctx.r30.u64;
	// stw r11,19648(r29)
	REX_STORE_U32(ctx.r29.u32 + 19648, ctx.r11.u32);
	// mr r8,r30
	ctx.r8.u64 = ctx.r30.u64;
	// sth r30,4(r31)
	REX_STORE_U16(ctx.r31.u32 + 4, ctx.r30.u16);
	// mr r10,r27
	ctx.r10.u64 = ctx.r27.u64;
	// sth r27,6(r31)
	REX_STORE_U16(ctx.r31.u32 + 6, ctx.r27.u16);
loc_8B0A9200:
	// clrlwi r6,r3,16
	ctx.r6.u64 = ctx.r3.u32 & 0xFFFF;
	// cmplwi cr6,r6,65535
	ctx.cr6.compare<uint32_t>(ctx.r6.u32, 65535, ctx.xer);
	// beq cr6,0x8b0a9224
	if (ctx.cr6.eq) goto loc_8B0A9224;
	// rlwinm r10,r6,3,0,28
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r6.u32 | (ctx.r6.u64 << 32), 3) & 0xFFFFFFF8;
	// lwz r9,4(r28)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r28.u32 + 4);
	// add r10,r6,r10
	ctx.r10.u64 = ctx.r6.u64 + ctx.r10.u64;
	// rlwinm r10,r10,3,0,28
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r10.u32 | (ctx.r10.u64 << 32), 3) & 0xFFFFFFF8;
	// add r10,r10,r9
	ctx.r10.u64 = ctx.r10.u64 + ctx.r9.u64;
	// b 0x8b0a9228
	goto loc_8B0A9228;
loc_8B0A9224:
	// mr r10,r31
	ctx.r10.u64 = ctx.r31.u64;
loc_8B0A9228:
	// clrlwi r9,r11,31
	ctx.r9.u64 = ctx.r11.u32 & 0x1;
	// lhz r7,0(r10)
	ctx.r7.u64 = REX_LOAD_U16(ctx.r10.u32 + 0);
	// cmplwi cr6,r9,0
	ctx.cr6.compare<uint32_t>(ctx.r9.u32, 0, ctx.xer);
	// bne cr6,0x8b0a9260
	if (!ctx.cr6.eq) goto loc_8B0A9260;
	// ori r11,r11,1
	ctx.r11.u64 = ctx.r11.u64 | 1;
	// sth r30,0(r31)
	REX_STORE_U16(ctx.r31.u32 + 0, ctx.r30.u16);
	// mr r10,r30
	ctx.r10.u64 = ctx.r30.u64;
	// sth r30,2(r31)
	REX_STORE_U16(ctx.r31.u32 + 2, ctx.r30.u16);
	// mr r9,r30
	ctx.r9.u64 = ctx.r30.u64;
	// stw r11,19648(r29)
	REX_STORE_U32(ctx.r29.u32 + 19648, ctx.r11.u32);
	// mr r8,r30
	ctx.r8.u64 = ctx.r30.u64;
	// sth r30,4(r31)
	REX_STORE_U16(ctx.r31.u32 + 4, ctx.r30.u16);
	// mr r10,r27
	ctx.r10.u64 = ctx.r27.u64;
	// sth r27,6(r31)
	REX_STORE_U16(ctx.r31.u32 + 6, ctx.r27.u16);
loc_8B0A9260:
	// clrlwi r10,r7,16
	ctx.r10.u64 = ctx.r7.u32 & 0xFFFF;
	// cmplwi cr6,r10,65535
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 65535, ctx.xer);
	// beq cr6,0x8b0a9284
	if (ctx.cr6.eq) goto loc_8B0A9284;
	// rlwinm r8,r10,3,0,28
	ctx.r8.u64 = __builtin_rotateleft64(ctx.r10.u32 | (ctx.r10.u64 << 32), 3) & 0xFFFFFFF8;
	// lwz r9,4(r28)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r28.u32 + 4);
	// add r10,r10,r8
	ctx.r10.u64 = ctx.r10.u64 + ctx.r8.u64;
	// rlwinm r10,r10,3,0,28
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r10.u32 | (ctx.r10.u64 << 32), 3) & 0xFFFFFFF8;
	// add r10,r10,r9
	ctx.r10.u64 = ctx.r10.u64 + ctx.r9.u64;
	// b 0x8b0a9288
	goto loc_8B0A9288;
loc_8B0A9284:
	// mr r10,r31
	ctx.r10.u64 = ctx.r31.u64;
loc_8B0A9288:
	// lhz r10,6(r10)
	ctx.r10.u64 = REX_LOAD_U16(ctx.r10.u32 + 6);
	// cmplwi cr6,r10,1
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 1, ctx.xer);
	// bne cr6,0x8b0a9380
	if (!ctx.cr6.eq) goto loc_8B0A9380;
	// clrlwi r10,r11,31
	ctx.r10.u64 = ctx.r11.u32 & 0x1;
	// cmplwi cr6,r10,0
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 0, ctx.xer);
	// bne cr6,0x8b0a92c8
	if (!ctx.cr6.eq) goto loc_8B0A92C8;
	// ori r11,r11,1
	ctx.r11.u64 = ctx.r11.u64 | 1;
	// sth r30,0(r31)
	REX_STORE_U16(ctx.r31.u32 + 0, ctx.r30.u16);
	// mr r10,r30
	ctx.r10.u64 = ctx.r30.u64;
	// sth r30,2(r31)
	REX_STORE_U16(ctx.r31.u32 + 2, ctx.r30.u16);
	// mr r9,r30
	ctx.r9.u64 = ctx.r30.u64;
	// stw r11,19648(r29)
	REX_STORE_U32(ctx.r29.u32 + 19648, ctx.r11.u32);
	// mr r8,r30
	ctx.r8.u64 = ctx.r30.u64;
	// sth r30,4(r31)
	REX_STORE_U16(ctx.r31.u32 + 4, ctx.r30.u16);
	// mr r10,r27
	ctx.r10.u64 = ctx.r27.u64;
	// sth r27,6(r31)
	REX_STORE_U16(ctx.r31.u32 + 6, ctx.r27.u16);
loc_8B0A92C8:
	// cmplwi cr6,r6,65535
	ctx.cr6.compare<uint32_t>(ctx.r6.u32, 65535, ctx.xer);
	// beq cr6,0x8b0a92e8
	if (ctx.cr6.eq) goto loc_8B0A92E8;
	// rlwinm r10,r6,3,0,28
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r6.u32 | (ctx.r6.u64 << 32), 3) & 0xFFFFFFF8;
	// lwz r9,4(r28)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r28.u32 + 4);
	// add r10,r6,r10
	ctx.r10.u64 = ctx.r6.u64 + ctx.r10.u64;
	// rlwinm r10,r10,3,0,28
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r10.u32 | (ctx.r10.u64 << 32), 3) & 0xFFFFFFF8;
	// add r10,r10,r9
	ctx.r10.u64 = ctx.r10.u64 + ctx.r9.u64;
	// b 0x8b0a92ec
	goto loc_8B0A92EC;
loc_8B0A92E8:
	// mr r10,r31
	ctx.r10.u64 = ctx.r31.u64;
loc_8B0A92EC:
	// clrlwi r9,r11,31
	ctx.r9.u64 = ctx.r11.u32 & 0x1;
	// lhz r7,2(r10)
	ctx.r7.u64 = REX_LOAD_U16(ctx.r10.u32 + 2);
	// cmplwi cr6,r9,0
	ctx.cr6.compare<uint32_t>(ctx.r9.u32, 0, ctx.xer);
	// bne cr6,0x8b0a9324
	if (!ctx.cr6.eq) goto loc_8B0A9324;
	// ori r11,r11,1
	ctx.r11.u64 = ctx.r11.u64 | 1;
	// sth r30,0(r31)
	REX_STORE_U16(ctx.r31.u32 + 0, ctx.r30.u16);
	// mr r10,r30
	ctx.r10.u64 = ctx.r30.u64;
	// sth r30,2(r31)
	REX_STORE_U16(ctx.r31.u32 + 2, ctx.r30.u16);
	// mr r9,r30
	ctx.r9.u64 = ctx.r30.u64;
	// stw r11,19648(r29)
	REX_STORE_U32(ctx.r29.u32 + 19648, ctx.r11.u32);
	// mr r8,r30
	ctx.r8.u64 = ctx.r30.u64;
	// sth r30,4(r31)
	REX_STORE_U16(ctx.r31.u32 + 4, ctx.r30.u16);
	// mr r10,r27
	ctx.r10.u64 = ctx.r27.u64;
	// sth r27,6(r31)
	REX_STORE_U16(ctx.r31.u32 + 6, ctx.r27.u16);
loc_8B0A9324:
	// clrlwi r10,r7,16
	ctx.r10.u64 = ctx.r7.u32 & 0xFFFF;
	// cmplwi cr6,r10,65535
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 65535, ctx.xer);
	// beq cr6,0x8b0a9348
	if (ctx.cr6.eq) goto loc_8B0A9348;
	// rlwinm r8,r10,3,0,28
	ctx.r8.u64 = __builtin_rotateleft64(ctx.r10.u32 | (ctx.r10.u64 << 32), 3) & 0xFFFFFFF8;
	// lwz r9,4(r28)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r28.u32 + 4);
	// add r10,r10,r8
	ctx.r10.u64 = ctx.r10.u64 + ctx.r8.u64;
	// rlwinm r10,r10,3,0,28
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r10.u32 | (ctx.r10.u64 << 32), 3) & 0xFFFFFFF8;
	// add r10,r10,r9
	ctx.r10.u64 = ctx.r10.u64 + ctx.r9.u64;
	// b 0x8b0a934c
	goto loc_8B0A934C;
loc_8B0A9348:
	// mr r10,r31
	ctx.r10.u64 = ctx.r31.u64;
loc_8B0A934C:
	// lhz r10,6(r10)
	ctx.r10.u64 = REX_LOAD_U16(ctx.r10.u32 + 6);
	// cmplwi cr6,r10,1
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 1, ctx.xer);
	// bne cr6,0x8b0a9380
	if (!ctx.cr6.eq) goto loc_8B0A9380;
	// cmplwi cr6,r6,65535
	ctx.cr6.compare<uint32_t>(ctx.r6.u32, 65535, ctx.xer);
	// beq cr6,0x8b0a9a0c
	if (ctx.cr6.eq) goto loc_8B0A9A0C;
	// rlwinm r11,r6,3,0,28
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r6.u32 | (ctx.r6.u64 << 32), 3) & 0xFFFFFFF8;
	// lwz r10,4(r28)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r28.u32 + 4);
	// add r11,r6,r11
	ctx.r11.u64 = ctx.r6.u64 + ctx.r11.u64;
	// rlwinm r11,r11,3,0,28
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 3) & 0xFFFFFFF8;
	// add r10,r11,r10
	ctx.r10.u64 = ctx.r11.u64 + ctx.r10.u64;
	// sth r25,6(r10)
	REX_STORE_U16(ctx.r10.u32 + 6, ctx.r25.u16);
	// mr r10,r4
	ctx.r10.u64 = ctx.r4.u64;
	// b 0x8b0a9d38
	goto loc_8B0A9D38;
loc_8B0A9380:
	// clrlwi r10,r11,31
	ctx.r10.u64 = ctx.r11.u32 & 0x1;
	// cmplwi cr6,r10,0
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 0, ctx.xer);
	// bne cr6,0x8b0a93b4
	if (!ctx.cr6.eq) goto loc_8B0A93B4;
	// ori r11,r11,1
	ctx.r11.u64 = ctx.r11.u64 | 1;
	// sth r30,0(r31)
	REX_STORE_U16(ctx.r31.u32 + 0, ctx.r30.u16);
	// mr r10,r30
	ctx.r10.u64 = ctx.r30.u64;
	// sth r30,2(r31)
	REX_STORE_U16(ctx.r31.u32 + 2, ctx.r30.u16);
	// mr r9,r30
	ctx.r9.u64 = ctx.r30.u64;
	// stw r11,19648(r29)
	REX_STORE_U32(ctx.r29.u32 + 19648, ctx.r11.u32);
	// mr r8,r30
	ctx.r8.u64 = ctx.r30.u64;
	// sth r30,4(r31)
	REX_STORE_U16(ctx.r31.u32 + 4, ctx.r30.u16);
	// mr r10,r27
	ctx.r10.u64 = ctx.r27.u64;
	// sth r27,6(r31)
	REX_STORE_U16(ctx.r31.u32 + 6, ctx.r27.u16);
loc_8B0A93B4:
	// cmplwi cr6,r6,65535
	ctx.cr6.compare<uint32_t>(ctx.r6.u32, 65535, ctx.xer);
	// beq cr6,0x8b0a93d4
	if (ctx.cr6.eq) goto loc_8B0A93D4;
	// rlwinm r10,r6,3,0,28
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r6.u32 | (ctx.r6.u64 << 32), 3) & 0xFFFFFFF8;
	// lwz r9,4(r28)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r28.u32 + 4);
	// add r10,r6,r10
	ctx.r10.u64 = ctx.r6.u64 + ctx.r10.u64;
	// rlwinm r10,r10,3,0,28
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r10.u32 | (ctx.r10.u64 << 32), 3) & 0xFFFFFFF8;
	// add r10,r10,r9
	ctx.r10.u64 = ctx.r10.u64 + ctx.r9.u64;
	// b 0x8b0a93d8
	goto loc_8B0A93D8;
loc_8B0A93D4:
	// mr r10,r31
	ctx.r10.u64 = ctx.r31.u64;
loc_8B0A93D8:
	// clrlwi r9,r11,31
	ctx.r9.u64 = ctx.r11.u32 & 0x1;
	// lhz r7,2(r10)
	ctx.r7.u64 = REX_LOAD_U16(ctx.r10.u32 + 2);
	// cmplwi cr6,r9,0
	ctx.cr6.compare<uint32_t>(ctx.r9.u32, 0, ctx.xer);
	// bne cr6,0x8b0a9410
	if (!ctx.cr6.eq) goto loc_8B0A9410;
	// ori r11,r11,1
	ctx.r11.u64 = ctx.r11.u64 | 1;
	// sth r30,0(r31)
	REX_STORE_U16(ctx.r31.u32 + 0, ctx.r30.u16);
	// mr r10,r30
	ctx.r10.u64 = ctx.r30.u64;
	// sth r30,2(r31)
	REX_STORE_U16(ctx.r31.u32 + 2, ctx.r30.u16);
	// mr r9,r30
	ctx.r9.u64 = ctx.r30.u64;
	// stw r11,19648(r29)
	REX_STORE_U32(ctx.r29.u32 + 19648, ctx.r11.u32);
	// mr r8,r30
	ctx.r8.u64 = ctx.r30.u64;
	// sth r30,4(r31)
	REX_STORE_U16(ctx.r31.u32 + 4, ctx.r30.u16);
	// mr r10,r27
	ctx.r10.u64 = ctx.r27.u64;
	// sth r27,6(r31)
	REX_STORE_U16(ctx.r31.u32 + 6, ctx.r27.u16);
loc_8B0A9410:
	// clrlwi r10,r7,16
	ctx.r10.u64 = ctx.r7.u32 & 0xFFFF;
	// cmplwi cr6,r10,65535
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 65535, ctx.xer);
	// beq cr6,0x8b0a9434
	if (ctx.cr6.eq) goto loc_8B0A9434;
	// rlwinm r8,r10,3,0,28
	ctx.r8.u64 = __builtin_rotateleft64(ctx.r10.u32 | (ctx.r10.u64 << 32), 3) & 0xFFFFFFF8;
	// lwz r9,4(r28)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r28.u32 + 4);
	// add r10,r10,r8
	ctx.r10.u64 = ctx.r10.u64 + ctx.r8.u64;
	// rlwinm r10,r10,3,0,28
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r10.u32 | (ctx.r10.u64 << 32), 3) & 0xFFFFFFF8;
	// add r10,r10,r9
	ctx.r10.u64 = ctx.r10.u64 + ctx.r9.u64;
	// b 0x8b0a9438
	goto loc_8B0A9438;
loc_8B0A9434:
	// mr r10,r31
	ctx.r10.u64 = ctx.r31.u64;
loc_8B0A9438:
	// lhz r10,6(r10)
	ctx.r10.u64 = REX_LOAD_U16(ctx.r10.u32 + 6);
	// cmplwi cr6,r10,1
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 1, ctx.xer);
	// bne cr6,0x8b0a959c
	if (!ctx.cr6.eq) goto loc_8B0A959C;
	// clrlwi r10,r11,31
	ctx.r10.u64 = ctx.r11.u32 & 0x1;
	// cmplwi cr6,r10,0
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 0, ctx.xer);
	// bne cr6,0x8b0a9478
	if (!ctx.cr6.eq) goto loc_8B0A9478;
	// ori r11,r11,1
	ctx.r11.u64 = ctx.r11.u64 | 1;
	// sth r30,0(r31)
	REX_STORE_U16(ctx.r31.u32 + 0, ctx.r30.u16);
	// mr r10,r30
	ctx.r10.u64 = ctx.r30.u64;
	// sth r30,2(r31)
	REX_STORE_U16(ctx.r31.u32 + 2, ctx.r30.u16);
	// stw r11,19648(r29)
	REX_STORE_U32(ctx.r29.u32 + 19648, ctx.r11.u32);
	// mr r9,r30
	ctx.r9.u64 = ctx.r30.u64;
	// mr r11,r30
	ctx.r11.u64 = ctx.r30.u64;
	// sth r30,4(r31)
	REX_STORE_U16(ctx.r31.u32 + 4, ctx.r30.u16);
	// mr r10,r27
	ctx.r10.u64 = ctx.r27.u64;
	// sth r27,6(r31)
	REX_STORE_U16(ctx.r31.u32 + 6, ctx.r27.u16);
loc_8B0A9478:
	// cmplwi cr6,r6,65535
	ctx.cr6.compare<uint32_t>(ctx.r6.u32, 65535, ctx.xer);
	// beq cr6,0x8b0a9498
	if (ctx.cr6.eq) goto loc_8B0A9498;
	// rlwinm r11,r6,3,0,28
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r6.u32 | (ctx.r6.u64 << 32), 3) & 0xFFFFFFF8;
	// lwz r10,4(r28)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r28.u32 + 4);
	// add r11,r6,r11
	ctx.r11.u64 = ctx.r6.u64 + ctx.r11.u64;
	// rlwinm r11,r11,3,0,28
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 3) & 0xFFFFFFF8;
	// add r11,r11,r10
	ctx.r11.u64 = ctx.r11.u64 + ctx.r10.u64;
	// b 0x8b0a949c
	goto loc_8B0A949C;
loc_8B0A9498:
	// mr r11,r31
	ctx.r11.u64 = ctx.r31.u64;
loc_8B0A949C:
	// lhz r11,0(r11)
	ctx.r11.u64 = REX_LOAD_U16(ctx.r11.u32 + 0);
	// rlwinm r8,r6,3,0,28
	ctx.r8.u64 = __builtin_rotateleft64(ctx.r6.u32 | (ctx.r6.u64 << 32), 3) & 0xFFFFFFF8;
	// lwz r9,4(r28)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r28.u32 + 4);
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// rotlwi r10,r11,3
	ctx.r10.u64 = __builtin_rotateleft32(ctx.r11.u32, 3);
	// add r8,r6,r8
	ctx.r8.u64 = ctx.r6.u64 + ctx.r8.u64;
	// add r7,r11,r10
	ctx.r7.u64 = ctx.r11.u64 + ctx.r10.u64;
	// rlwinm r11,r8,3,0,28
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r8.u32 | (ctx.r8.u64 << 32), 3) & 0xFFFFFFF8;
	// rlwinm r10,r7,3,0,28
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r7.u32 | (ctx.r7.u64 << 32), 3) & 0xFFFFFFF8;
	// mr r3,r28
	ctx.r3.u64 = ctx.r28.u64;
	// add r6,r10,r9
	ctx.r6.u64 = ctx.r10.u64 + ctx.r9.u64;
	// sth r27,6(r6)
	REX_STORE_U16(ctx.r6.u32 + 6, ctx.r27.u16);
	// lwz r10,4(r28)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r28.u32 + 4);
	// add r5,r11,r10
	ctx.r5.u64 = ctx.r11.u64 + ctx.r10.u64;
	// sth r25,6(r5)
	REX_STORE_U16(ctx.r5.u32 + 6, ctx.r25.u16);
	// bl 0x8b0a7878
	ctx.lr = 0x8B0A94DC;
	sub_8B0A7878(ctx, base);
	// lwz r11,19648(r29)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r29.u32 + 19648);
	// clrlwi r4,r11,31
	ctx.r4.u64 = ctx.r11.u32 & 0x1;
	// cmplwi cr6,r4,0
	ctx.cr6.compare<uint32_t>(ctx.r4.u32, 0, ctx.xer);
	// bne cr6,0x8b0a9514
	if (!ctx.cr6.eq) goto loc_8B0A9514;
	// ori r11,r11,1
	ctx.r11.u64 = ctx.r11.u64 | 1;
	// sth r30,0(r31)
	REX_STORE_U16(ctx.r31.u32 + 0, ctx.r30.u16);
	// mr r10,r30
	ctx.r10.u64 = ctx.r30.u64;
	// sth r30,2(r31)
	REX_STORE_U16(ctx.r31.u32 + 2, ctx.r30.u16);
	// mr r9,r30
	ctx.r9.u64 = ctx.r30.u64;
	// stw r11,19648(r29)
	REX_STORE_U32(ctx.r29.u32 + 19648, ctx.r11.u32);
	// mr r8,r30
	ctx.r8.u64 = ctx.r30.u64;
	// sth r30,4(r31)
	REX_STORE_U16(ctx.r31.u32 + 4, ctx.r30.u16);
	// mr r10,r27
	ctx.r10.u64 = ctx.r27.u64;
	// sth r27,6(r31)
	REX_STORE_U16(ctx.r31.u32 + 6, ctx.r27.u16);
loc_8B0A9514:
	// cmplwi cr6,r26,65535
	ctx.cr6.compare<uint32_t>(ctx.r26.u32, 65535, ctx.xer);
	// beq cr6,0x8b0a9534
	if (ctx.cr6.eq) goto loc_8B0A9534;
	// rlwinm r10,r26,3,0,28
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r26.u32 | (ctx.r26.u64 << 32), 3) & 0xFFFFFFF8;
	// lwz r9,4(r28)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r28.u32 + 4);
	// add r10,r26,r10
	ctx.r10.u64 = ctx.r26.u64 + ctx.r10.u64;
	// rlwinm r10,r10,3,0,28
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r10.u32 | (ctx.r10.u64 << 32), 3) & 0xFFFFFFF8;
	// add r10,r10,r9
	ctx.r10.u64 = ctx.r10.u64 + ctx.r9.u64;
	// b 0x8b0a9538
	goto loc_8B0A9538;
loc_8B0A9534:
	// mr r10,r31
	ctx.r10.u64 = ctx.r31.u64;
loc_8B0A9538:
	// clrlwi r9,r11,31
	ctx.r9.u64 = ctx.r11.u32 & 0x1;
	// lhz r4,4(r10)
	ctx.r4.u64 = REX_LOAD_U16(ctx.r10.u32 + 4);
	// cmplwi cr6,r9,0
	ctx.cr6.compare<uint32_t>(ctx.r9.u32, 0, ctx.xer);
	// bne cr6,0x8b0a9570
	if (!ctx.cr6.eq) goto loc_8B0A9570;
	// ori r11,r11,1
	ctx.r11.u64 = ctx.r11.u64 | 1;
	// sth r30,0(r31)
	REX_STORE_U16(ctx.r31.u32 + 0, ctx.r30.u16);
	// mr r10,r30
	ctx.r10.u64 = ctx.r30.u64;
	// sth r30,2(r31)
	REX_STORE_U16(ctx.r31.u32 + 2, ctx.r30.u16);
	// mr r9,r30
	ctx.r9.u64 = ctx.r30.u64;
	// stw r11,19648(r29)
	REX_STORE_U32(ctx.r29.u32 + 19648, ctx.r11.u32);
	// mr r8,r30
	ctx.r8.u64 = ctx.r30.u64;
	// sth r30,4(r31)
	REX_STORE_U16(ctx.r31.u32 + 4, ctx.r30.u16);
	// mr r10,r27
	ctx.r10.u64 = ctx.r27.u64;
	// sth r27,6(r31)
	REX_STORE_U16(ctx.r31.u32 + 6, ctx.r27.u16);
loc_8B0A9570:
	// clrlwi r5,r4,16
	ctx.r5.u64 = ctx.r4.u32 & 0xFFFF;
	// cmplwi cr6,r5,65535
	ctx.cr6.compare<uint32_t>(ctx.r5.u32, 65535, ctx.xer);
	// beq cr6,0x8b0a9594
	if (ctx.cr6.eq) goto loc_8B0A9594;
	// rlwinm r10,r5,3,0,28
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r5.u32 | (ctx.r5.u64 << 32), 3) & 0xFFFFFFF8;
	// lwz r9,4(r28)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r28.u32 + 4);
	// add r10,r5,r10
	ctx.r10.u64 = ctx.r5.u64 + ctx.r10.u64;
	// rlwinm r10,r10,3,0,28
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r10.u32 | (ctx.r10.u64 << 32), 3) & 0xFFFFFFF8;
	// add r10,r10,r9
	ctx.r10.u64 = ctx.r10.u64 + ctx.r9.u64;
	// b 0x8b0a9598
	goto loc_8B0A9598;
loc_8B0A9594:
	// mr r10,r31
	ctx.r10.u64 = ctx.r31.u64;
loc_8B0A9598:
	// lhz r3,2(r10)
	ctx.r3.u64 = REX_LOAD_U16(ctx.r10.u32 + 2);
loc_8B0A959C:
	// clrlwi r10,r11,31
	ctx.r10.u64 = ctx.r11.u32 & 0x1;
	// cmplwi cr6,r10,0
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 0, ctx.xer);
	// bne cr6,0x8b0a95d0
	if (!ctx.cr6.eq) goto loc_8B0A95D0;
	// ori r11,r11,1
	ctx.r11.u64 = ctx.r11.u64 | 1;
	// sth r30,0(r31)
	REX_STORE_U16(ctx.r31.u32 + 0, ctx.r30.u16);
	// mr r10,r30
	ctx.r10.u64 = ctx.r30.u64;
	// sth r30,2(r31)
	REX_STORE_U16(ctx.r31.u32 + 2, ctx.r30.u16);
	// stw r11,19648(r29)
	REX_STORE_U32(ctx.r29.u32 + 19648, ctx.r11.u32);
	// mr r9,r30
	ctx.r9.u64 = ctx.r30.u64;
	// mr r11,r30
	ctx.r11.u64 = ctx.r30.u64;
	// sth r30,4(r31)
	REX_STORE_U16(ctx.r31.u32 + 4, ctx.r30.u16);
	// mr r10,r27
	ctx.r10.u64 = ctx.r27.u64;
	// sth r27,6(r31)
	REX_STORE_U16(ctx.r31.u32 + 6, ctx.r27.u16);
loc_8B0A95D0:
	// cmplwi cr6,r5,65535
	ctx.cr6.compare<uint32_t>(ctx.r5.u32, 65535, ctx.xer);
	// beq cr6,0x8b0a95f0
	if (ctx.cr6.eq) goto loc_8B0A95F0;
	// rlwinm r11,r5,3,0,28
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r5.u32 | (ctx.r5.u64 << 32), 3) & 0xFFFFFFF8;
	// lwz r10,4(r28)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r28.u32 + 4);
	// add r11,r5,r11
	ctx.r11.u64 = ctx.r5.u64 + ctx.r11.u64;
	// rlwinm r11,r11,3,0,28
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 3) & 0xFFFFFFF8;
	// add r11,r11,r10
	ctx.r11.u64 = ctx.r11.u64 + ctx.r10.u64;
	// b 0x8b0a95f4
	goto loc_8B0A95F4;
loc_8B0A95F0:
	// mr r11,r31
	ctx.r11.u64 = ctx.r31.u64;
loc_8B0A95F4:
	// rlwinm r10,r3,3,13,28
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r3.u32 | (ctx.r3.u64 << 32), 3) & 0x7FFF8;
	// lhz r8,6(r11)
	ctx.r8.u64 = REX_LOAD_U16(ctx.r11.u32 + 6);
	// clrlwi r7,r3,16
	ctx.r7.u64 = ctx.r3.u32 & 0xFFFF;
	// rlwinm r11,r5,3,0,28
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r5.u32 | (ctx.r5.u64 << 32), 3) & 0xFFFFFFF8;
	// add r6,r7,r10
	ctx.r6.u64 = ctx.r7.u64 + ctx.r10.u64;
	// lwz r10,4(r28)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r28.u32 + 4);
	// add r5,r5,r11
	ctx.r5.u64 = ctx.r5.u64 + ctx.r11.u64;
	// rlwinm r9,r6,3,0,28
	ctx.r9.u64 = __builtin_rotateleft64(ctx.r6.u32 | (ctx.r6.u64 << 32), 3) & 0xFFFFFFF8;
	// rlwinm r11,r5,3,0,28
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r5.u32 | (ctx.r5.u64 << 32), 3) & 0xFFFFFFF8;
	// add r3,r10,r9
	ctx.r3.u64 = ctx.r10.u64 + ctx.r9.u64;
	// sth r8,6(r3)
	REX_STORE_U16(ctx.r3.u32 + 6, ctx.r8.u16);
	// lwz r10,4(r28)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r28.u32 + 4);
	// add r11,r11,r10
	ctx.r11.u64 = ctx.r11.u64 + ctx.r10.u64;
	// sth r27,6(r11)
	REX_STORE_U16(ctx.r11.u32 + 6, ctx.r27.u16);
	// lwz r11,19648(r29)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r29.u32 + 19648);
	// clrlwi r10,r11,31
	ctx.r10.u64 = ctx.r11.u32 & 0x1;
	// cmplwi cr6,r10,0
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 0, ctx.xer);
	// bne cr6,0x8b0a9664
	if (!ctx.cr6.eq) goto loc_8B0A9664;
	// ori r11,r11,1
	ctx.r11.u64 = ctx.r11.u64 | 1;
	// sth r30,0(r31)
	REX_STORE_U16(ctx.r31.u32 + 0, ctx.r30.u16);
	// mr r10,r30
	ctx.r10.u64 = ctx.r30.u64;
	// sth r30,2(r31)
	REX_STORE_U16(ctx.r31.u32 + 2, ctx.r30.u16);
	// stw r11,19648(r29)
	REX_STORE_U32(ctx.r29.u32 + 19648, ctx.r11.u32);
	// mr r8,r30
	ctx.r8.u64 = ctx.r30.u64;
	// mr r11,r30
	ctx.r11.u64 = ctx.r30.u64;
	// sth r30,4(r31)
	REX_STORE_U16(ctx.r31.u32 + 4, ctx.r30.u16);
	// mr r10,r27
	ctx.r10.u64 = ctx.r27.u64;
	// sth r27,6(r31)
	REX_STORE_U16(ctx.r31.u32 + 6, ctx.r27.u16);
loc_8B0A9664:
	// cmplwi cr6,r7,65535
	ctx.cr6.compare<uint32_t>(ctx.r7.u32, 65535, ctx.xer);
	// beq cr6,0x8b0a9678
	if (ctx.cr6.eq) goto loc_8B0A9678;
	// lwz r11,4(r28)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r28.u32 + 4);
	// add r11,r11,r9
	ctx.r11.u64 = ctx.r11.u64 + ctx.r9.u64;
	// b 0x8b0a967c
	goto loc_8B0A967C;
loc_8B0A9678:
	// mr r11,r31
	ctx.r11.u64 = ctx.r31.u64;
loc_8B0A967C:
	// lhz r11,2(r11)
	ctx.r11.u64 = REX_LOAD_U16(ctx.r11.u32 + 2);
	// mr r3,r28
	ctx.r3.u64 = ctx.r28.u64;
	// lwz r10,4(r28)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r28.u32 + 4);
	// rotlwi r9,r11,3
	ctx.r9.u64 = __builtin_rotateleft32(ctx.r11.u32, 3);
	// add r11,r11,r9
	ctx.r11.u64 = ctx.r11.u64 + ctx.r9.u64;
	// rlwinm r11,r11,3,0,28
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 3) & 0xFFFFFFF8;
	// add r10,r11,r10
	ctx.r10.u64 = ctx.r11.u64 + ctx.r10.u64;
	// sth r27,6(r10)
	REX_STORE_U16(ctx.r10.u32 + 6, ctx.r27.u16);
	// bl 0x8b0a7700
	ctx.lr = 0x8B0A96A0;
	sub_8B0A7700(ctx, base);
	// b 0x8b0a9d34
	goto loc_8B0A9D34;
loc_8B0A96A4:
	// cmplwi cr6,r10,0
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 0, ctx.xer);
	// bne cr6,0x8b0a96d4
	if (!ctx.cr6.eq) goto loc_8B0A96D4;
	// ori r11,r11,1
	ctx.r11.u64 = ctx.r11.u64 | 1;
	// sth r30,0(r31)
	REX_STORE_U16(ctx.r31.u32 + 0, ctx.r30.u16);
	// mr r10,r30
	ctx.r10.u64 = ctx.r30.u64;
	// sth r30,2(r31)
	REX_STORE_U16(ctx.r31.u32 + 2, ctx.r30.u16);
	// mr r9,r30
	ctx.r9.u64 = ctx.r30.u64;
	// stw r11,19648(r29)
	REX_STORE_U32(ctx.r29.u32 + 19648, ctx.r11.u32);
	// mr r8,r30
	ctx.r8.u64 = ctx.r30.u64;
	// sth r30,4(r31)
	REX_STORE_U16(ctx.r31.u32 + 4, ctx.r30.u16);
	// mr r10,r27
	ctx.r10.u64 = ctx.r27.u64;
	// sth r27,6(r31)
	REX_STORE_U16(ctx.r31.u32 + 6, ctx.r27.u16);
loc_8B0A96D4:
	// cmplwi cr6,r5,65535
	ctx.cr6.compare<uint32_t>(ctx.r5.u32, 65535, ctx.xer);
	// beq cr6,0x8b0a96f4
	if (ctx.cr6.eq) goto loc_8B0A96F4;
	// rlwinm r10,r5,3,0,28
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r5.u32 | (ctx.r5.u64 << 32), 3) & 0xFFFFFFF8;
	// lwz r9,4(r28)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r28.u32 + 4);
	// add r10,r5,r10
	ctx.r10.u64 = ctx.r5.u64 + ctx.r10.u64;
	// rlwinm r10,r10,3,0,28
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r10.u32 | (ctx.r10.u64 << 32), 3) & 0xFFFFFFF8;
	// add r10,r10,r9
	ctx.r10.u64 = ctx.r10.u64 + ctx.r9.u64;
	// b 0x8b0a96f8
	goto loc_8B0A96F8;
loc_8B0A96F4:
	// mr r10,r31
	ctx.r10.u64 = ctx.r31.u64;
loc_8B0A96F8:
	// clrlwi r9,r11,31
	ctx.r9.u64 = ctx.r11.u32 & 0x1;
	// lhz r3,0(r10)
	ctx.r3.u64 = REX_LOAD_U16(ctx.r10.u32 + 0);
	// cmplwi cr6,r9,0
	ctx.cr6.compare<uint32_t>(ctx.r9.u32, 0, ctx.xer);
	// bne cr6,0x8b0a9730
	if (!ctx.cr6.eq) goto loc_8B0A9730;
	// ori r11,r11,1
	ctx.r11.u64 = ctx.r11.u64 | 1;
	// sth r30,0(r31)
	REX_STORE_U16(ctx.r31.u32 + 0, ctx.r30.u16);
	// mr r10,r30
	ctx.r10.u64 = ctx.r30.u64;
	// sth r30,2(r31)
	REX_STORE_U16(ctx.r31.u32 + 2, ctx.r30.u16);
	// mr r9,r30
	ctx.r9.u64 = ctx.r30.u64;
	// stw r11,19648(r29)
	REX_STORE_U32(ctx.r29.u32 + 19648, ctx.r11.u32);
	// mr r8,r30
	ctx.r8.u64 = ctx.r30.u64;
	// sth r30,4(r31)
	REX_STORE_U16(ctx.r31.u32 + 4, ctx.r30.u16);
	// mr r10,r27
	ctx.r10.u64 = ctx.r27.u64;
	// sth r27,6(r31)
	REX_STORE_U16(ctx.r31.u32 + 6, ctx.r27.u16);
loc_8B0A9730:
	// clrlwi r10,r3,16
	ctx.r10.u64 = ctx.r3.u32 & 0xFFFF;
	// cmplwi cr6,r10,65535
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 65535, ctx.xer);
	// beq cr6,0x8b0a9754
	if (ctx.cr6.eq) goto loc_8B0A9754;
	// rlwinm r9,r10,3,0,28
	ctx.r9.u64 = __builtin_rotateleft64(ctx.r10.u32 | (ctx.r10.u64 << 32), 3) & 0xFFFFFFF8;
	// lwz r8,4(r28)
	ctx.r8.u64 = REX_LOAD_U32(ctx.r28.u32 + 4);
	// add r9,r10,r9
	ctx.r9.u64 = ctx.r10.u64 + ctx.r9.u64;
	// rlwinm r9,r9,3,0,28
	ctx.r9.u64 = __builtin_rotateleft64(ctx.r9.u32 | (ctx.r9.u64 << 32), 3) & 0xFFFFFFF8;
	// add r9,r9,r8
	ctx.r9.u64 = ctx.r9.u64 + ctx.r8.u64;
	// b 0x8b0a9758
	goto loc_8B0A9758;
loc_8B0A9754:
	// mr r9,r31
	ctx.r9.u64 = ctx.r31.u64;
loc_8B0A9758:
	// lhz r9,6(r9)
	ctx.r9.u64 = REX_LOAD_U16(ctx.r9.u32 + 6);
	// cmplwi cr6,r9,0
	ctx.cr6.compare<uint32_t>(ctx.r9.u32, 0, ctx.xer);
	// bne cr6,0x8b0a985c
	if (!ctx.cr6.eq) goto loc_8B0A985C;
	// rlwinm r11,r10,3,0,28
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r10.u32 | (ctx.r10.u64 << 32), 3) & 0xFFFFFFF8;
	// rlwinm r9,r5,3,0,28
	ctx.r9.u64 = __builtin_rotateleft64(ctx.r5.u32 | (ctx.r5.u64 << 32), 3) & 0xFFFFFFF8;
	// add r11,r10,r11
	ctx.r11.u64 = ctx.r10.u64 + ctx.r11.u64;
	// lwz r10,4(r28)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r28.u32 + 4);
	// add r9,r5,r9
	ctx.r9.u64 = ctx.r5.u64 + ctx.r9.u64;
	// rlwinm r11,r11,3,0,28
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 3) & 0xFFFFFFF8;
	// mr r3,r28
	ctx.r3.u64 = ctx.r28.u64;
	// add r8,r11,r10
	ctx.r8.u64 = ctx.r11.u64 + ctx.r10.u64;
	// rlwinm r11,r9,3,0,28
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r9.u32 | (ctx.r9.u64 << 32), 3) & 0xFFFFFFF8;
	// sth r27,6(r8)
	REX_STORE_U16(ctx.r8.u32 + 6, ctx.r27.u16);
	// lwz r10,4(r28)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r28.u32 + 4);
	// add r7,r11,r10
	ctx.r7.u64 = ctx.r11.u64 + ctx.r10.u64;
	// sth r25,6(r7)
	REX_STORE_U16(ctx.r7.u32 + 6, ctx.r25.u16);
	// bl 0x8b0a7878
	ctx.lr = 0x8B0A979C;
	sub_8B0A7878(ctx, base);
	// lwz r11,19648(r29)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r29.u32 + 19648);
	// clrlwi r6,r11,31
	ctx.r6.u64 = ctx.r11.u32 & 0x1;
	// cmplwi cr6,r6,0
	ctx.cr6.compare<uint32_t>(ctx.r6.u32, 0, ctx.xer);
	// bne cr6,0x8b0a97d4
	if (!ctx.cr6.eq) goto loc_8B0A97D4;
	// ori r11,r11,1
	ctx.r11.u64 = ctx.r11.u64 | 1;
	// sth r30,0(r31)
	REX_STORE_U16(ctx.r31.u32 + 0, ctx.r30.u16);
	// mr r10,r30
	ctx.r10.u64 = ctx.r30.u64;
	// sth r30,2(r31)
	REX_STORE_U16(ctx.r31.u32 + 2, ctx.r30.u16);
	// mr r9,r30
	ctx.r9.u64 = ctx.r30.u64;
	// stw r11,19648(r29)
	REX_STORE_U32(ctx.r29.u32 + 19648, ctx.r11.u32);
	// mr r8,r30
	ctx.r8.u64 = ctx.r30.u64;
	// sth r30,4(r31)
	REX_STORE_U16(ctx.r31.u32 + 4, ctx.r30.u16);
	// mr r10,r27
	ctx.r10.u64 = ctx.r27.u64;
	// sth r27,6(r31)
	REX_STORE_U16(ctx.r31.u32 + 6, ctx.r27.u16);
loc_8B0A97D4:
	// cmplwi cr6,r26,65535
	ctx.cr6.compare<uint32_t>(ctx.r26.u32, 65535, ctx.xer);
	// beq cr6,0x8b0a97f4
	if (ctx.cr6.eq) goto loc_8B0A97F4;
	// rlwinm r10,r26,3,0,28
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r26.u32 | (ctx.r26.u64 << 32), 3) & 0xFFFFFFF8;
	// lwz r9,4(r28)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r28.u32 + 4);
	// add r10,r26,r10
	ctx.r10.u64 = ctx.r26.u64 + ctx.r10.u64;
	// rlwinm r10,r10,3,0,28
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r10.u32 | (ctx.r10.u64 << 32), 3) & 0xFFFFFFF8;
	// add r10,r10,r9
	ctx.r10.u64 = ctx.r10.u64 + ctx.r9.u64;
	// b 0x8b0a97f8
	goto loc_8B0A97F8;
loc_8B0A97F4:
	// mr r10,r31
	ctx.r10.u64 = ctx.r31.u64;
loc_8B0A97F8:
	// clrlwi r9,r11,31
	ctx.r9.u64 = ctx.r11.u32 & 0x1;
	// lhz r4,4(r10)
	ctx.r4.u64 = REX_LOAD_U16(ctx.r10.u32 + 4);
	// cmplwi cr6,r9,0
	ctx.cr6.compare<uint32_t>(ctx.r9.u32, 0, ctx.xer);
	// bne cr6,0x8b0a9830
	if (!ctx.cr6.eq) goto loc_8B0A9830;
	// ori r11,r11,1
	ctx.r11.u64 = ctx.r11.u64 | 1;
	// sth r30,0(r31)
	REX_STORE_U16(ctx.r31.u32 + 0, ctx.r30.u16);
	// mr r10,r30
	ctx.r10.u64 = ctx.r30.u64;
	// sth r30,2(r31)
	REX_STORE_U16(ctx.r31.u32 + 2, ctx.r30.u16);
	// mr r9,r30
	ctx.r9.u64 = ctx.r30.u64;
	// stw r11,19648(r29)
	REX_STORE_U32(ctx.r29.u32 + 19648, ctx.r11.u32);
	// mr r8,r30
	ctx.r8.u64 = ctx.r30.u64;
	// sth r30,4(r31)
	REX_STORE_U16(ctx.r31.u32 + 4, ctx.r30.u16);
	// mr r10,r27
	ctx.r10.u64 = ctx.r27.u64;
	// sth r27,6(r31)
	REX_STORE_U16(ctx.r31.u32 + 6, ctx.r27.u16);
loc_8B0A9830:
	// clrlwi r5,r4,16
	ctx.r5.u64 = ctx.r4.u32 & 0xFFFF;
	// cmplwi cr6,r5,65535
	ctx.cr6.compare<uint32_t>(ctx.r5.u32, 65535, ctx.xer);
	// beq cr6,0x8b0a9854
	if (ctx.cr6.eq) goto loc_8B0A9854;
	// rlwinm r10,r5,3,0,28
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r5.u32 | (ctx.r5.u64 << 32), 3) & 0xFFFFFFF8;
	// lwz r9,4(r28)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r28.u32 + 4);
	// add r10,r5,r10
	ctx.r10.u64 = ctx.r5.u64 + ctx.r10.u64;
	// rlwinm r10,r10,3,0,28
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r10.u32 | (ctx.r10.u64 << 32), 3) & 0xFFFFFFF8;
	// add r10,r10,r9
	ctx.r10.u64 = ctx.r10.u64 + ctx.r9.u64;
	// b 0x8b0a9858
	goto loc_8B0A9858;
loc_8B0A9854:
	// mr r10,r31
	ctx.r10.u64 = ctx.r31.u64;
loc_8B0A9858:
	// lhz r3,0(r10)
	ctx.r3.u64 = REX_LOAD_U16(ctx.r10.u32 + 0);
loc_8B0A985C:
	// clrlwi r10,r11,31
	ctx.r10.u64 = ctx.r11.u32 & 0x1;
	// cmplwi cr6,r10,0
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 0, ctx.xer);
	// bne cr6,0x8b0a9890
	if (!ctx.cr6.eq) goto loc_8B0A9890;
	// ori r11,r11,1
	ctx.r11.u64 = ctx.r11.u64 | 1;
	// sth r30,0(r31)
	REX_STORE_U16(ctx.r31.u32 + 0, ctx.r30.u16);
	// mr r10,r30
	ctx.r10.u64 = ctx.r30.u64;
	// sth r30,2(r31)
	REX_STORE_U16(ctx.r31.u32 + 2, ctx.r30.u16);
	// mr r9,r30
	ctx.r9.u64 = ctx.r30.u64;
	// stw r11,19648(r29)
	REX_STORE_U32(ctx.r29.u32 + 19648, ctx.r11.u32);
	// mr r8,r30
	ctx.r8.u64 = ctx.r30.u64;
	// sth r30,4(r31)
	REX_STORE_U16(ctx.r31.u32 + 4, ctx.r30.u16);
	// mr r10,r27
	ctx.r10.u64 = ctx.r27.u64;
	// sth r27,6(r31)
	REX_STORE_U16(ctx.r31.u32 + 6, ctx.r27.u16);
loc_8B0A9890:
	// clrlwi r6,r3,16
	ctx.r6.u64 = ctx.r3.u32 & 0xFFFF;
	// cmplwi cr6,r6,65535
	ctx.cr6.compare<uint32_t>(ctx.r6.u32, 65535, ctx.xer);
	// beq cr6,0x8b0a98b4
	if (ctx.cr6.eq) goto loc_8B0A98B4;
	// rlwinm r10,r6,3,0,28
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r6.u32 | (ctx.r6.u64 << 32), 3) & 0xFFFFFFF8;
	// lwz r9,4(r28)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r28.u32 + 4);
	// add r10,r6,r10
	ctx.r10.u64 = ctx.r6.u64 + ctx.r10.u64;
	// rlwinm r10,r10,3,0,28
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r10.u32 | (ctx.r10.u64 << 32), 3) & 0xFFFFFFF8;
	// add r10,r10,r9
	ctx.r10.u64 = ctx.r10.u64 + ctx.r9.u64;
	// b 0x8b0a98b8
	goto loc_8B0A98B8;
loc_8B0A98B4:
	// mr r10,r31
	ctx.r10.u64 = ctx.r31.u64;
loc_8B0A98B8:
	// clrlwi r9,r11,31
	ctx.r9.u64 = ctx.r11.u32 & 0x1;
	// lhz r7,2(r10)
	ctx.r7.u64 = REX_LOAD_U16(ctx.r10.u32 + 2);
	// cmplwi cr6,r9,0
	ctx.cr6.compare<uint32_t>(ctx.r9.u32, 0, ctx.xer);
	// bne cr6,0x8b0a98f0
	if (!ctx.cr6.eq) goto loc_8B0A98F0;
	// ori r11,r11,1
	ctx.r11.u64 = ctx.r11.u64 | 1;
	// sth r30,0(r31)
	REX_STORE_U16(ctx.r31.u32 + 0, ctx.r30.u16);
	// mr r10,r30
	ctx.r10.u64 = ctx.r30.u64;
	// sth r30,2(r31)
	REX_STORE_U16(ctx.r31.u32 + 2, ctx.r30.u16);
	// mr r9,r30
	ctx.r9.u64 = ctx.r30.u64;
	// stw r11,19648(r29)
	REX_STORE_U32(ctx.r29.u32 + 19648, ctx.r11.u32);
	// mr r8,r30
	ctx.r8.u64 = ctx.r30.u64;
	// sth r30,4(r31)
	REX_STORE_U16(ctx.r31.u32 + 4, ctx.r30.u16);
	// mr r10,r27
	ctx.r10.u64 = ctx.r27.u64;
	// sth r27,6(r31)
	REX_STORE_U16(ctx.r31.u32 + 6, ctx.r27.u16);
loc_8B0A98F0:
	// clrlwi r10,r7,16
	ctx.r10.u64 = ctx.r7.u32 & 0xFFFF;
	// cmplwi cr6,r10,65535
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 65535, ctx.xer);
	// beq cr6,0x8b0a9914
	if (ctx.cr6.eq) goto loc_8B0A9914;
	// rlwinm r8,r10,3,0,28
	ctx.r8.u64 = __builtin_rotateleft64(ctx.r10.u32 | (ctx.r10.u64 << 32), 3) & 0xFFFFFFF8;
	// lwz r9,4(r28)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r28.u32 + 4);
	// add r10,r10,r8
	ctx.r10.u64 = ctx.r10.u64 + ctx.r8.u64;
	// rlwinm r10,r10,3,0,28
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r10.u32 | (ctx.r10.u64 << 32), 3) & 0xFFFFFFF8;
	// add r10,r10,r9
	ctx.r10.u64 = ctx.r10.u64 + ctx.r9.u64;
	// b 0x8b0a9918
	goto loc_8B0A9918;
loc_8B0A9914:
	// mr r10,r31
	ctx.r10.u64 = ctx.r31.u64;
loc_8B0A9918:
	// lhz r10,6(r10)
	ctx.r10.u64 = REX_LOAD_U16(ctx.r10.u32 + 6);
	// cmplwi cr6,r10,1
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 1, ctx.xer);
	// bne cr6,0x8b0a9a14
	if (!ctx.cr6.eq) goto loc_8B0A9A14;
	// clrlwi r10,r11,31
	ctx.r10.u64 = ctx.r11.u32 & 0x1;
	// cmplwi cr6,r10,0
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 0, ctx.xer);
	// bne cr6,0x8b0a9958
	if (!ctx.cr6.eq) goto loc_8B0A9958;
	// ori r11,r11,1
	ctx.r11.u64 = ctx.r11.u64 | 1;
	// sth r30,0(r31)
	REX_STORE_U16(ctx.r31.u32 + 0, ctx.r30.u16);
	// mr r10,r30
	ctx.r10.u64 = ctx.r30.u64;
	// sth r30,2(r31)
	REX_STORE_U16(ctx.r31.u32 + 2, ctx.r30.u16);
	// mr r9,r30
	ctx.r9.u64 = ctx.r30.u64;
	// stw r11,19648(r29)
	REX_STORE_U32(ctx.r29.u32 + 19648, ctx.r11.u32);
	// mr r8,r30
	ctx.r8.u64 = ctx.r30.u64;
	// sth r30,4(r31)
	REX_STORE_U16(ctx.r31.u32 + 4, ctx.r30.u16);
	// mr r10,r27
	ctx.r10.u64 = ctx.r27.u64;
	// sth r27,6(r31)
	REX_STORE_U16(ctx.r31.u32 + 6, ctx.r27.u16);
loc_8B0A9958:
	// cmplwi cr6,r6,65535
	ctx.cr6.compare<uint32_t>(ctx.r6.u32, 65535, ctx.xer);
	// beq cr6,0x8b0a9978
	if (ctx.cr6.eq) goto loc_8B0A9978;
	// rlwinm r10,r6,3,0,28
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r6.u32 | (ctx.r6.u64 << 32), 3) & 0xFFFFFFF8;
	// lwz r9,4(r28)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r28.u32 + 4);
	// add r10,r6,r10
	ctx.r10.u64 = ctx.r6.u64 + ctx.r10.u64;
	// rlwinm r10,r10,3,0,28
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r10.u32 | (ctx.r10.u64 << 32), 3) & 0xFFFFFFF8;
	// add r10,r10,r9
	ctx.r10.u64 = ctx.r10.u64 + ctx.r9.u64;
	// b 0x8b0a997c
	goto loc_8B0A997C;
loc_8B0A9978:
	// mr r10,r31
	ctx.r10.u64 = ctx.r31.u64;
loc_8B0A997C:
	// clrlwi r9,r11,31
	ctx.r9.u64 = ctx.r11.u32 & 0x1;
	// lhz r7,0(r10)
	ctx.r7.u64 = REX_LOAD_U16(ctx.r10.u32 + 0);
	// cmplwi cr6,r9,0
	ctx.cr6.compare<uint32_t>(ctx.r9.u32, 0, ctx.xer);
	// bne cr6,0x8b0a99b4
	if (!ctx.cr6.eq) goto loc_8B0A99B4;
	// ori r11,r11,1
	ctx.r11.u64 = ctx.r11.u64 | 1;
	// sth r30,0(r31)
	REX_STORE_U16(ctx.r31.u32 + 0, ctx.r30.u16);
	// mr r10,r30
	ctx.r10.u64 = ctx.r30.u64;
	// sth r30,2(r31)
	REX_STORE_U16(ctx.r31.u32 + 2, ctx.r30.u16);
	// mr r9,r30
	ctx.r9.u64 = ctx.r30.u64;
	// stw r11,19648(r29)
	REX_STORE_U32(ctx.r29.u32 + 19648, ctx.r11.u32);
	// mr r8,r30
	ctx.r8.u64 = ctx.r30.u64;
	// sth r30,4(r31)
	REX_STORE_U16(ctx.r31.u32 + 4, ctx.r30.u16);
	// mr r10,r27
	ctx.r10.u64 = ctx.r27.u64;
	// sth r27,6(r31)
	REX_STORE_U16(ctx.r31.u32 + 6, ctx.r27.u16);
loc_8B0A99B4:
	// clrlwi r10,r7,16
	ctx.r10.u64 = ctx.r7.u32 & 0xFFFF;
	// cmplwi cr6,r10,65535
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 65535, ctx.xer);
	// beq cr6,0x8b0a99d8
	if (ctx.cr6.eq) goto loc_8B0A99D8;
	// rlwinm r8,r10,3,0,28
	ctx.r8.u64 = __builtin_rotateleft64(ctx.r10.u32 | (ctx.r10.u64 << 32), 3) & 0xFFFFFFF8;
	// lwz r9,4(r28)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r28.u32 + 4);
	// add r10,r10,r8
	ctx.r10.u64 = ctx.r10.u64 + ctx.r8.u64;
	// rlwinm r10,r10,3,0,28
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r10.u32 | (ctx.r10.u64 << 32), 3) & 0xFFFFFFF8;
	// add r10,r10,r9
	ctx.r10.u64 = ctx.r10.u64 + ctx.r9.u64;
	// b 0x8b0a99dc
	goto loc_8B0A99DC;
loc_8B0A99D8:
	// mr r10,r31
	ctx.r10.u64 = ctx.r31.u64;
loc_8B0A99DC:
	// lhz r10,6(r10)
	ctx.r10.u64 = REX_LOAD_U16(ctx.r10.u32 + 6);
	// cmplwi cr6,r10,1
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 1, ctx.xer);
	// bne cr6,0x8b0a9a14
	if (!ctx.cr6.eq) goto loc_8B0A9A14;
	// cmplwi cr6,r6,65535
	ctx.cr6.compare<uint32_t>(ctx.r6.u32, 65535, ctx.xer);
	// beq cr6,0x8b0a9a0c
	if (ctx.cr6.eq) goto loc_8B0A9A0C;
	// rlwinm r11,r6,3,0,28
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r6.u32 | (ctx.r6.u64 << 32), 3) & 0xFFFFFFF8;
	// lwz r10,4(r28)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r28.u32 + 4);
	// add r11,r6,r11
	ctx.r11.u64 = ctx.r6.u64 + ctx.r11.u64;
	// rlwinm r11,r11,3,0,28
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 3) & 0xFFFFFFF8;
	// add r10,r11,r10
	ctx.r10.u64 = ctx.r11.u64 + ctx.r10.u64;
	// sth r25,6(r10)
	REX_STORE_U16(ctx.r10.u32 + 6, ctx.r25.u16);
	// lwz r11,19648(r29)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r29.u32 + 19648);
loc_8B0A9A0C:
	// mr r10,r4
	ctx.r10.u64 = ctx.r4.u64;
	// b 0x8b0a9d3c
	goto loc_8B0A9D3C;
loc_8B0A9A14:
	// clrlwi r10,r11,31
	ctx.r10.u64 = ctx.r11.u32 & 0x1;
	// cmplwi cr6,r10,0
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 0, ctx.xer);
	// bne cr6,0x8b0a9a48
	if (!ctx.cr6.eq) goto loc_8B0A9A48;
	// ori r11,r11,1
	ctx.r11.u64 = ctx.r11.u64 | 1;
	// sth r30,0(r31)
	REX_STORE_U16(ctx.r31.u32 + 0, ctx.r30.u16);
	// mr r10,r30
	ctx.r10.u64 = ctx.r30.u64;
	// sth r30,2(r31)
	REX_STORE_U16(ctx.r31.u32 + 2, ctx.r30.u16);
	// mr r9,r30
	ctx.r9.u64 = ctx.r30.u64;
	// stw r11,19648(r29)
	REX_STORE_U32(ctx.r29.u32 + 19648, ctx.r11.u32);
	// mr r8,r30
	ctx.r8.u64 = ctx.r30.u64;
	// sth r30,4(r31)
	REX_STORE_U16(ctx.r31.u32 + 4, ctx.r30.u16);
	// mr r10,r27
	ctx.r10.u64 = ctx.r27.u64;
	// sth r27,6(r31)
	REX_STORE_U16(ctx.r31.u32 + 6, ctx.r27.u16);
loc_8B0A9A48:
	// cmplwi cr6,r6,65535
	ctx.cr6.compare<uint32_t>(ctx.r6.u32, 65535, ctx.xer);
	// beq cr6,0x8b0a9a68
	if (ctx.cr6.eq) goto loc_8B0A9A68;
	// rlwinm r10,r6,3,0,28
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r6.u32 | (ctx.r6.u64 << 32), 3) & 0xFFFFFFF8;
	// lwz r9,4(r28)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r28.u32 + 4);
	// add r10,r6,r10
	ctx.r10.u64 = ctx.r6.u64 + ctx.r10.u64;
	// rlwinm r10,r10,3,0,28
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r10.u32 | (ctx.r10.u64 << 32), 3) & 0xFFFFFFF8;
	// add r10,r10,r9
	ctx.r10.u64 = ctx.r10.u64 + ctx.r9.u64;
	// b 0x8b0a9a6c
	goto loc_8B0A9A6C;
loc_8B0A9A68:
	// mr r10,r31
	ctx.r10.u64 = ctx.r31.u64;
loc_8B0A9A6C:
	// clrlwi r9,r11,31
	ctx.r9.u64 = ctx.r11.u32 & 0x1;
	// lhz r7,0(r10)
	ctx.r7.u64 = REX_LOAD_U16(ctx.r10.u32 + 0);
	// cmplwi cr6,r9,0
	ctx.cr6.compare<uint32_t>(ctx.r9.u32, 0, ctx.xer);
	// bne cr6,0x8b0a9aa4
	if (!ctx.cr6.eq) goto loc_8B0A9AA4;
	// ori r11,r11,1
	ctx.r11.u64 = ctx.r11.u64 | 1;
	// sth r30,0(r31)
	REX_STORE_U16(ctx.r31.u32 + 0, ctx.r30.u16);
	// mr r10,r30
	ctx.r10.u64 = ctx.r30.u64;
	// sth r30,2(r31)
	REX_STORE_U16(ctx.r31.u32 + 2, ctx.r30.u16);
	// mr r9,r30
	ctx.r9.u64 = ctx.r30.u64;
	// stw r11,19648(r29)
	REX_STORE_U32(ctx.r29.u32 + 19648, ctx.r11.u32);
	// mr r8,r30
	ctx.r8.u64 = ctx.r30.u64;
	// sth r30,4(r31)
	REX_STORE_U16(ctx.r31.u32 + 4, ctx.r30.u16);
	// mr r10,r27
	ctx.r10.u64 = ctx.r27.u64;
	// sth r27,6(r31)
	REX_STORE_U16(ctx.r31.u32 + 6, ctx.r27.u16);
loc_8B0A9AA4:
	// clrlwi r10,r7,16
	ctx.r10.u64 = ctx.r7.u32 & 0xFFFF;
	// cmplwi cr6,r10,65535
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 65535, ctx.xer);
	// beq cr6,0x8b0a9ac8
	if (ctx.cr6.eq) goto loc_8B0A9AC8;
	// rlwinm r8,r10,3,0,28
	ctx.r8.u64 = __builtin_rotateleft64(ctx.r10.u32 | (ctx.r10.u64 << 32), 3) & 0xFFFFFFF8;
	// lwz r9,4(r28)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r28.u32 + 4);
	// add r10,r10,r8
	ctx.r10.u64 = ctx.r10.u64 + ctx.r8.u64;
	// rlwinm r10,r10,3,0,28
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r10.u32 | (ctx.r10.u64 << 32), 3) & 0xFFFFFFF8;
	// add r10,r10,r9
	ctx.r10.u64 = ctx.r10.u64 + ctx.r9.u64;
	// b 0x8b0a9acc
	goto loc_8B0A9ACC;
loc_8B0A9AC8:
	// mr r10,r31
	ctx.r10.u64 = ctx.r31.u64;
loc_8B0A9ACC:
	// lhz r10,6(r10)
	ctx.r10.u64 = REX_LOAD_U16(ctx.r10.u32 + 6);
	// cmplwi cr6,r10,1
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 1, ctx.xer);
	// bne cr6,0x8b0a9c30
	if (!ctx.cr6.eq) goto loc_8B0A9C30;
	// clrlwi r10,r11,31
	ctx.r10.u64 = ctx.r11.u32 & 0x1;
	// cmplwi cr6,r10,0
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 0, ctx.xer);
	// bne cr6,0x8b0a9b0c
	if (!ctx.cr6.eq) goto loc_8B0A9B0C;
	// ori r11,r11,1
	ctx.r11.u64 = ctx.r11.u64 | 1;
	// sth r30,0(r31)
	REX_STORE_U16(ctx.r31.u32 + 0, ctx.r30.u16);
	// mr r10,r30
	ctx.r10.u64 = ctx.r30.u64;
	// sth r30,2(r31)
	REX_STORE_U16(ctx.r31.u32 + 2, ctx.r30.u16);
	// stw r11,19648(r29)
	REX_STORE_U32(ctx.r29.u32 + 19648, ctx.r11.u32);
	// mr r9,r30
	ctx.r9.u64 = ctx.r30.u64;
	// mr r11,r30
	ctx.r11.u64 = ctx.r30.u64;
	// sth r30,4(r31)
	REX_STORE_U16(ctx.r31.u32 + 4, ctx.r30.u16);
	// mr r10,r27
	ctx.r10.u64 = ctx.r27.u64;
	// sth r27,6(r31)
	REX_STORE_U16(ctx.r31.u32 + 6, ctx.r27.u16);
loc_8B0A9B0C:
	// cmplwi cr6,r6,65535
	ctx.cr6.compare<uint32_t>(ctx.r6.u32, 65535, ctx.xer);
	// beq cr6,0x8b0a9b2c
	if (ctx.cr6.eq) goto loc_8B0A9B2C;
	// rlwinm r11,r6,3,0,28
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r6.u32 | (ctx.r6.u64 << 32), 3) & 0xFFFFFFF8;
	// lwz r10,4(r28)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r28.u32 + 4);
	// add r11,r6,r11
	ctx.r11.u64 = ctx.r6.u64 + ctx.r11.u64;
	// rlwinm r11,r11,3,0,28
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 3) & 0xFFFFFFF8;
	// add r11,r11,r10
	ctx.r11.u64 = ctx.r11.u64 + ctx.r10.u64;
	// b 0x8b0a9b30
	goto loc_8B0A9B30;
loc_8B0A9B2C:
	// mr r11,r31
	ctx.r11.u64 = ctx.r31.u64;
loc_8B0A9B30:
	// lhz r11,2(r11)
	ctx.r11.u64 = REX_LOAD_U16(ctx.r11.u32 + 2);
	// rlwinm r8,r6,3,0,28
	ctx.r8.u64 = __builtin_rotateleft64(ctx.r6.u32 | (ctx.r6.u64 << 32), 3) & 0xFFFFFFF8;
	// lwz r9,4(r28)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r28.u32 + 4);
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// rotlwi r10,r11,3
	ctx.r10.u64 = __builtin_rotateleft32(ctx.r11.u32, 3);
	// add r8,r6,r8
	ctx.r8.u64 = ctx.r6.u64 + ctx.r8.u64;
	// add r7,r11,r10
	ctx.r7.u64 = ctx.r11.u64 + ctx.r10.u64;
	// rlwinm r11,r8,3,0,28
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r8.u32 | (ctx.r8.u64 << 32), 3) & 0xFFFFFFF8;
	// rlwinm r10,r7,3,0,28
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r7.u32 | (ctx.r7.u64 << 32), 3) & 0xFFFFFFF8;
	// mr r3,r28
	ctx.r3.u64 = ctx.r28.u64;
	// add r6,r10,r9
	ctx.r6.u64 = ctx.r10.u64 + ctx.r9.u64;
	// sth r27,6(r6)
	REX_STORE_U16(ctx.r6.u32 + 6, ctx.r27.u16);
	// lwz r10,4(r28)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r28.u32 + 4);
	// add r5,r11,r10
	ctx.r5.u64 = ctx.r11.u64 + ctx.r10.u64;
	// sth r25,6(r5)
	REX_STORE_U16(ctx.r5.u32 + 6, ctx.r25.u16);
	// bl 0x8b0a7700
	ctx.lr = 0x8B0A9B70;
	sub_8B0A7700(ctx, base);
	// lwz r11,19648(r29)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r29.u32 + 19648);
	// clrlwi r4,r11,31
	ctx.r4.u64 = ctx.r11.u32 & 0x1;
	// cmplwi cr6,r4,0
	ctx.cr6.compare<uint32_t>(ctx.r4.u32, 0, ctx.xer);
	// bne cr6,0x8b0a9ba8
	if (!ctx.cr6.eq) goto loc_8B0A9BA8;
	// ori r11,r11,1
	ctx.r11.u64 = ctx.r11.u64 | 1;
	// sth r30,0(r31)
	REX_STORE_U16(ctx.r31.u32 + 0, ctx.r30.u16);
	// mr r10,r30
	ctx.r10.u64 = ctx.r30.u64;
	// sth r30,2(r31)
	REX_STORE_U16(ctx.r31.u32 + 2, ctx.r30.u16);
	// mr r9,r30
	ctx.r9.u64 = ctx.r30.u64;
	// stw r11,19648(r29)
	REX_STORE_U32(ctx.r29.u32 + 19648, ctx.r11.u32);
	// mr r8,r30
	ctx.r8.u64 = ctx.r30.u64;
	// sth r30,4(r31)
	REX_STORE_U16(ctx.r31.u32 + 4, ctx.r30.u16);
	// mr r10,r27
	ctx.r10.u64 = ctx.r27.u64;
	// sth r27,6(r31)
	REX_STORE_U16(ctx.r31.u32 + 6, ctx.r27.u16);
loc_8B0A9BA8:
	// cmplwi cr6,r26,65535
	ctx.cr6.compare<uint32_t>(ctx.r26.u32, 65535, ctx.xer);
	// beq cr6,0x8b0a9bc8
	if (ctx.cr6.eq) goto loc_8B0A9BC8;
	// rlwinm r10,r26,3,0,28
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r26.u32 | (ctx.r26.u64 << 32), 3) & 0xFFFFFFF8;
	// lwz r9,4(r28)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r28.u32 + 4);
	// add r10,r26,r10
	ctx.r10.u64 = ctx.r26.u64 + ctx.r10.u64;
	// rlwinm r10,r10,3,0,28
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r10.u32 | (ctx.r10.u64 << 32), 3) & 0xFFFFFFF8;
	// add r10,r10,r9
	ctx.r10.u64 = ctx.r10.u64 + ctx.r9.u64;
	// b 0x8b0a9bcc
	goto loc_8B0A9BCC;
loc_8B0A9BC8:
	// mr r10,r31
	ctx.r10.u64 = ctx.r31.u64;
loc_8B0A9BCC:
	// clrlwi r9,r11,31
	ctx.r9.u64 = ctx.r11.u32 & 0x1;
	// lhz r4,4(r10)
	ctx.r4.u64 = REX_LOAD_U16(ctx.r10.u32 + 4);
	// cmplwi cr6,r9,0
	ctx.cr6.compare<uint32_t>(ctx.r9.u32, 0, ctx.xer);
	// bne cr6,0x8b0a9c04
	if (!ctx.cr6.eq) goto loc_8B0A9C04;
	// ori r11,r11,1
	ctx.r11.u64 = ctx.r11.u64 | 1;
	// sth r30,0(r31)
	REX_STORE_U16(ctx.r31.u32 + 0, ctx.r30.u16);
	// mr r10,r30
	ctx.r10.u64 = ctx.r30.u64;
	// sth r30,2(r31)
	REX_STORE_U16(ctx.r31.u32 + 2, ctx.r30.u16);
	// mr r9,r30
	ctx.r9.u64 = ctx.r30.u64;
	// stw r11,19648(r29)
	REX_STORE_U32(ctx.r29.u32 + 19648, ctx.r11.u32);
	// mr r8,r30
	ctx.r8.u64 = ctx.r30.u64;
	// sth r30,4(r31)
	REX_STORE_U16(ctx.r31.u32 + 4, ctx.r30.u16);
	// mr r10,r27
	ctx.r10.u64 = ctx.r27.u64;
	// sth r27,6(r31)
	REX_STORE_U16(ctx.r31.u32 + 6, ctx.r27.u16);
loc_8B0A9C04:
	// clrlwi r5,r4,16
	ctx.r5.u64 = ctx.r4.u32 & 0xFFFF;
	// cmplwi cr6,r5,65535
	ctx.cr6.compare<uint32_t>(ctx.r5.u32, 65535, ctx.xer);
	// beq cr6,0x8b0a9c28
	if (ctx.cr6.eq) goto loc_8B0A9C28;
	// rlwinm r10,r5,3,0,28
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r5.u32 | (ctx.r5.u64 << 32), 3) & 0xFFFFFFF8;
	// lwz r9,4(r28)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r28.u32 + 4);
	// add r10,r5,r10
	ctx.r10.u64 = ctx.r5.u64 + ctx.r10.u64;
	// rlwinm r10,r10,3,0,28
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r10.u32 | (ctx.r10.u64 << 32), 3) & 0xFFFFFFF8;
	// add r10,r10,r9
	ctx.r10.u64 = ctx.r10.u64 + ctx.r9.u64;
	// b 0x8b0a9c2c
	goto loc_8B0A9C2C;
loc_8B0A9C28:
	// mr r10,r31
	ctx.r10.u64 = ctx.r31.u64;
loc_8B0A9C2C:
	// lhz r3,0(r10)
	ctx.r3.u64 = REX_LOAD_U16(ctx.r10.u32 + 0);
loc_8B0A9C30:
	// clrlwi r10,r11,31
	ctx.r10.u64 = ctx.r11.u32 & 0x1;
	// cmplwi cr6,r10,0
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 0, ctx.xer);
	// bne cr6,0x8b0a9c64
	if (!ctx.cr6.eq) goto loc_8B0A9C64;
	// ori r11,r11,1
	ctx.r11.u64 = ctx.r11.u64 | 1;
	// sth r30,0(r31)
	REX_STORE_U16(ctx.r31.u32 + 0, ctx.r30.u16);
	// mr r10,r30
	ctx.r10.u64 = ctx.r30.u64;
	// sth r30,2(r31)
	REX_STORE_U16(ctx.r31.u32 + 2, ctx.r30.u16);
	// stw r11,19648(r29)
	REX_STORE_U32(ctx.r29.u32 + 19648, ctx.r11.u32);
	// mr r9,r30
	ctx.r9.u64 = ctx.r30.u64;
	// mr r11,r30
	ctx.r11.u64 = ctx.r30.u64;
	// sth r30,4(r31)
	REX_STORE_U16(ctx.r31.u32 + 4, ctx.r30.u16);
	// mr r10,r27
	ctx.r10.u64 = ctx.r27.u64;
	// sth r27,6(r31)
	REX_STORE_U16(ctx.r31.u32 + 6, ctx.r27.u16);
loc_8B0A9C64:
	// cmplwi cr6,r5,65535
	ctx.cr6.compare<uint32_t>(ctx.r5.u32, 65535, ctx.xer);
	// beq cr6,0x8b0a9c84
	if (ctx.cr6.eq) goto loc_8B0A9C84;
	// rlwinm r11,r5,3,0,28
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r5.u32 | (ctx.r5.u64 << 32), 3) & 0xFFFFFFF8;
	// lwz r10,4(r28)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r28.u32 + 4);
	// add r11,r5,r11
	ctx.r11.u64 = ctx.r5.u64 + ctx.r11.u64;
	// rlwinm r11,r11,3,0,28
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 3) & 0xFFFFFFF8;
	// add r11,r11,r10
	ctx.r11.u64 = ctx.r11.u64 + ctx.r10.u64;
	// b 0x8b0a9c88
	goto loc_8B0A9C88;
loc_8B0A9C84:
	// mr r11,r31
	ctx.r11.u64 = ctx.r31.u64;
loc_8B0A9C88:
	// rlwinm r10,r3,3,13,28
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r3.u32 | (ctx.r3.u64 << 32), 3) & 0x7FFF8;
	// lhz r8,6(r11)
	ctx.r8.u64 = REX_LOAD_U16(ctx.r11.u32 + 6);
	// clrlwi r7,r3,16
	ctx.r7.u64 = ctx.r3.u32 & 0xFFFF;
	// rlwinm r11,r5,3,0,28
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r5.u32 | (ctx.r5.u64 << 32), 3) & 0xFFFFFFF8;
	// add r6,r7,r10
	ctx.r6.u64 = ctx.r7.u64 + ctx.r10.u64;
	// lwz r10,4(r28)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r28.u32 + 4);
	// add r5,r5,r11
	ctx.r5.u64 = ctx.r5.u64 + ctx.r11.u64;
	// rlwinm r9,r6,3,0,28
	ctx.r9.u64 = __builtin_rotateleft64(ctx.r6.u32 | (ctx.r6.u64 << 32), 3) & 0xFFFFFFF8;
	// rlwinm r11,r5,3,0,28
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r5.u32 | (ctx.r5.u64 << 32), 3) & 0xFFFFFFF8;
	// add r3,r10,r9
	ctx.r3.u64 = ctx.r10.u64 + ctx.r9.u64;
	// sth r8,6(r3)
	REX_STORE_U16(ctx.r3.u32 + 6, ctx.r8.u16);
	// lwz r10,4(r28)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r28.u32 + 4);
	// add r11,r11,r10
	ctx.r11.u64 = ctx.r11.u64 + ctx.r10.u64;
	// sth r27,6(r11)
	REX_STORE_U16(ctx.r11.u32 + 6, ctx.r27.u16);
	// lwz r11,19648(r29)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r29.u32 + 19648);
	// clrlwi r10,r11,31
	ctx.r10.u64 = ctx.r11.u32 & 0x1;
	// cmplwi cr6,r10,0
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 0, ctx.xer);
	// bne cr6,0x8b0a9cf8
	if (!ctx.cr6.eq) goto loc_8B0A9CF8;
	// ori r11,r11,1
	ctx.r11.u64 = ctx.r11.u64 | 1;
	// sth r30,0(r31)
	REX_STORE_U16(ctx.r31.u32 + 0, ctx.r30.u16);
	// mr r10,r30
	ctx.r10.u64 = ctx.r30.u64;
	// sth r30,2(r31)
	REX_STORE_U16(ctx.r31.u32 + 2, ctx.r30.u16);
	// stw r11,19648(r29)
	REX_STORE_U32(ctx.r29.u32 + 19648, ctx.r11.u32);
	// mr r8,r30
	ctx.r8.u64 = ctx.r30.u64;
	// mr r11,r30
	ctx.r11.u64 = ctx.r30.u64;
	// sth r30,4(r31)
	REX_STORE_U16(ctx.r31.u32 + 4, ctx.r30.u16);
	// mr r10,r27
	ctx.r10.u64 = ctx.r27.u64;
	// sth r27,6(r31)
	REX_STORE_U16(ctx.r31.u32 + 6, ctx.r27.u16);
loc_8B0A9CF8:
	// cmplwi cr6,r7,65535
	ctx.cr6.compare<uint32_t>(ctx.r7.u32, 65535, ctx.xer);
	// beq cr6,0x8b0a9d0c
	if (ctx.cr6.eq) goto loc_8B0A9D0C;
	// lwz r11,4(r28)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r28.u32 + 4);
	// add r11,r11,r9
	ctx.r11.u64 = ctx.r11.u64 + ctx.r9.u64;
	// b 0x8b0a9d10
	goto loc_8B0A9D10;
loc_8B0A9D0C:
	// mr r11,r31
	ctx.r11.u64 = ctx.r31.u64;
loc_8B0A9D10:
	// lhz r11,0(r11)
	ctx.r11.u64 = REX_LOAD_U16(ctx.r11.u32 + 0);
	// mr r3,r28
	ctx.r3.u64 = ctx.r28.u64;
	// lwz r10,4(r28)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r28.u32 + 4);
	// rotlwi r9,r11,3
	ctx.r9.u64 = __builtin_rotateleft32(ctx.r11.u32, 3);
	// add r11,r11,r9
	ctx.r11.u64 = ctx.r11.u64 + ctx.r9.u64;
	// rlwinm r11,r11,3,0,28
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 3) & 0xFFFFFFF8;
	// add r10,r11,r10
	ctx.r10.u64 = ctx.r11.u64 + ctx.r10.u64;
	// sth r27,6(r10)
	REX_STORE_U16(ctx.r10.u32 + 6, ctx.r27.u16);
	// bl 0x8b0a7878
	ctx.lr = 0x8B0A9D34;
	sub_8B0A7878(ctx, base);
loc_8B0A9D34:
	// lhz r10,16(r28)
	ctx.r10.u64 = REX_LOAD_U16(ctx.r28.u32 + 16);
loc_8B0A9D38:
	// lwz r11,19648(r29)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r29.u32 + 19648);
loc_8B0A9D3C:
	// lhz r9,16(r28)
	ctx.r9.u64 = REX_LOAD_U16(ctx.r28.u32 + 16);
	// clrlwi r26,r10,16
	ctx.r26.u64 = ctx.r10.u32 & 0xFFFF;
	// cmplw cr6,r26,r9
	ctx.cr6.compare<uint32_t>(ctx.r26.u32, ctx.r9.u32, ctx.xer);
	// bne cr6,0x8b0a8ee8
	if (!ctx.cr6.eq) goto loc_8B0A8EE8;
loc_8B0A9D4C:
	// rlwinm r11,r26,3,0,28
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r26.u32 | (ctx.r26.u64 << 32), 3) & 0xFFFFFFF8;
	// lwz r10,4(r28)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r28.u32 + 4);
	// add r11,r26,r11
	ctx.r11.u64 = ctx.r26.u64 + ctx.r11.u64;
	// rlwinm r11,r11,3,0,28
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 3) & 0xFFFFFFF8;
	// add r10,r11,r10
	ctx.r10.u64 = ctx.r11.u64 + ctx.r10.u64;
	// sth r27,6(r10)
	REX_STORE_U16(ctx.r10.u32 + 6, ctx.r27.u16);
	// addi r1,r1,144
	ctx.r1.s64 = ctx.r1.s64 + 144;
	// b 0x8b0cb9fc
	__restgprlr_25(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0AD9E0) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// std r30,-24(r1)
	REX_STORE_U64(ctx.r1.u32 + -24, ctx.r30.u64);
	// std r31,-16(r1)
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.r31.u64);
	// stwu r1,-112(r1)
	ea = -112 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// mr r30,r4
	ctx.r30.u64 = ctx.r4.u64;
	// bl 0x8b0ad848
	ctx.lr = 0x8B0ADA00;
	sub_8B0AD848(ctx, base);
	// clrlwi r11,r30,31
	ctx.r11.u64 = ctx.r30.u32 & 0x1;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// beq cr6,0x8b0ada18
	if (ctx.cr6.eq) goto loc_8B0ADA18;
	// bl 0x8b090020
	ctx.lr = 0x8B0ADA14;
	sub_8B090020(ctx, base);
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
loc_8B0ADA18:
	// addi r1,r1,112
	ctx.r1.s64 = ctx.r1.s64 + 112;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// ld r30,-24(r1)
	ctx.r30.u64 = REX_LOAD_U64(ctx.r1.u32 + -24);
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0ADA90) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// std r31,-16(r1)
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.r31.u64);
	// stwu r1,-128(r1)
	ea = -128 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// addi r3,r1,80
	ctx.r3.s64 = ctx.r1.s64 + 80;
	// bl 0x8b0b81e0
	ctx.lr = 0x8B0ADAAC;
	sub_8B0B81E0(ctx, base);
	// li r9,5
	ctx.r9.s64 = 5;
	// addi r10,r31,-4
	ctx.r10.s64 = ctx.r31.s64 + -4;
	// addi r11,r3,-4
	ctx.r11.s64 = ctx.r3.s64 + -4;
	// mtctr r9
	ctx.ctr.u64 = ctx.r9.u64;
loc_8B0ADABC:
	// lwzu r9,4(r11)
	ea = 4 + ctx.r11.u32;
	ctx.r9.u64 = REX_LOAD_U32(ea);
	ctx.r11.u32 = ea;
	// stwu r9,4(r10)
	ea = 4 + ctx.r10.u32;
	REX_STORE_U32(ea, ctx.r9.u32);
	ctx.r10.u32 = ea;
	// bdnz 0x8b0adabc
	--ctx.ctr.u64;
	if (ctx.ctr.u32 != 0) goto loc_8B0ADABC;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// addi r1,r1,128
	ctx.r1.s64 = ctx.r1.s64 + 128;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0ADB88) {
	REX_FUNC_PROLOGUE();
	PPCRegister temp{};
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9bc
	ctx.lr = 0x8B0ADB90;
	__savegprlr_29(ctx, base);
	// stwu r1,-160(r1)
	ea = -160 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// addi r3,r1,80
	ctx.r3.s64 = ctx.r1.s64 + 80;
	// mr r29,r4
	ctx.r29.u64 = ctx.r4.u64;
	// bl 0x8b0927a0
	ctx.lr = 0x8B0ADBA0;
	sub_8B0927A0(ctx, base);
	// lis r31,-29938
	ctx.r31.s64 = -1962016768;
	// addi r4,r1,80
	ctx.r4.s64 = ctx.r1.s64 + 80;
	// lwz r11,2364(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 2364);
	// lwz r3,76(r11)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r11.u32 + 76);
	// lwz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r10,24(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 24);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B0ADBC0;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// lbz r8,106(r1)
	ctx.r8.u64 = REX_LOAD_U8(ctx.r1.u32 + 106);
	// lis r30,-29938
	ctx.r30.s64 = -1962016768;
	// cmplwi cr6,r8,0
	ctx.cr6.compare<uint32_t>(ctx.r8.u32, 0, ctx.xer);
	// beq cr6,0x8b0add60
	if (ctx.cr6.eq) goto loc_8B0ADD60;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// addi r4,r11,26624
	ctx.r4.s64 = ctx.r11.s64 + 26624;
	// addi r3,r10,26600
	ctx.r3.s64 = ctx.r10.s64 + 26600;
	// li r5,0
	ctx.r5.s64 = 0;
	// bl 0x8b0c0c70
	ctx.lr = 0x8B0ADBE8;
	sub_8B0C0C70(ctx, base);
	// lis r9,-29944
	ctx.r9.s64 = -1962409984;
	// lwz r5,112(r1)
	ctx.r5.u64 = REX_LOAD_U32(ctx.r1.u32 + 112);
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// addi r4,r9,26588
	ctx.r4.s64 = ctx.r9.s64 + 26588;
	// bl 0x8b0c0010
	ctx.lr = 0x8B0ADBFC;
	sub_8B0C0010(ctx, base);
	// lbz r7,107(r1)
	ctx.r7.u64 = REX_LOAD_U8(ctx.r1.u32 + 107);
	// cmplwi cr6,r7,0
	ctx.cr6.compare<uint32_t>(ctx.r7.u32, 0, ctx.xer);
	// beq cr6,0x8b0adc14
	if (ctx.cr6.eq) goto loc_8B0ADC14;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// addi r5,r11,26576
	ctx.r5.s64 = ctx.r11.s64 + 26576;
	// b 0x8b0adc1c
	goto loc_8B0ADC1C;
loc_8B0ADC14:
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// addi r5,r11,10100
	ctx.r5.s64 = ctx.r11.s64 + 10100;
loc_8B0ADC1C:
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// addi r4,r11,4588
	ctx.r4.s64 = ctx.r11.s64 + 4588;
	// bl 0x8b0c0010
	ctx.lr = 0x8B0ADC2C;
	sub_8B0C0010(ctx, base);
	// li r4,0
	ctx.r4.s64 = 0;
	// addi r3,r1,92
	ctx.r3.s64 = ctx.r1.s64 + 92;
	// bl 0x8b0c7198
	ctx.lr = 0x8B0ADC38;
	sub_8B0C7198(ctx, base);
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// mr r5,r3
	ctx.r5.u64 = ctx.r3.u64;
	// addi r4,r10,26556
	ctx.r4.s64 = ctx.r10.s64 + 26556;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0c0010
	ctx.lr = 0x8B0ADC4C;
	sub_8B0C0010(ctx, base);
	// li r4,0
	ctx.r4.s64 = 0;
	// addi r3,r1,80
	ctx.r3.s64 = ctx.r1.s64 + 80;
	// bl 0x8b0c7198
	ctx.lr = 0x8B0ADC58;
	sub_8B0C7198(ctx, base);
	// lis r9,-29944
	ctx.r9.s64 = -1962409984;
	// mr r5,r3
	ctx.r5.u64 = ctx.r3.u64;
	// addi r4,r9,26540
	ctx.r4.s64 = ctx.r9.s64 + 26540;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0c0010
	ctx.lr = 0x8B0ADC6C;
	sub_8B0C0010(ctx, base);
	// lbz r7,107(r1)
	ctx.r7.u64 = REX_LOAD_U8(ctx.r1.u32 + 107);
	// cmplwi cr6,r7,0
	ctx.cr6.compare<uint32_t>(ctx.r7.u32, 0, ctx.xer);
	// beq cr6,0x8b0adca8
	if (ctx.cr6.eq) goto loc_8B0ADCA8;
	// lbz r10,108(r1)
	ctx.r10.u64 = REX_LOAD_U8(ctx.r1.u32 + 108);
	// cmplwi cr6,r10,0
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 0, ctx.xer);
	// beq cr6,0x8b0adca8
	if (ctx.cr6.eq) goto loc_8B0ADCA8;
	// lbz r10,109(r1)
	ctx.r10.u64 = REX_LOAD_U8(ctx.r1.u32 + 109);
	// cmplwi cr6,r10,0
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 0, ctx.xer);
	// beq cr6,0x8b0adca8
	if (ctx.cr6.eq) goto loc_8B0ADCA8;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// addi r5,r11,5780
	ctx.r5.s64 = ctx.r11.s64 + 5780;
	// addi r4,r10,5920
	ctx.r4.s64 = ctx.r10.s64 + 5920;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0c0010
	ctx.lr = 0x8B0ADCA8;
	sub_8B0C0010(ctx, base);
loc_8B0ADCA8:
	// lwz r3,3036(r30)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r30.u32 + 3036);
	// lwz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r10,32(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 32);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B0ADCBC;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// lwz r9,0(r3)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r8,16(r9)
	ctx.r8.u64 = REX_LOAD_U32(ctx.r9.u32 + 16);
	// mtctr r8
	ctx.ctr.u64 = ctx.r8.u64;
	// bctrl 
	ctx.lr = 0x8B0ADCCC;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// lwz r11,120(r1)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r1.u32 + 120);
	// lis r6,-29944
	ctx.r6.s64 = -1962409984;
	// mr r7,r3
	ctx.r7.u64 = ctx.r3.u64;
	// rlwinm r5,r11,1,31,31
	ctx.r5.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 1) & 0x1;
	// subfc r4,r11,r3
	ctx.xer.ca = ctx.r3.u32 >= ctx.r11.u32;
	ctx.r4.u64 = ctx.r3.u64 - ctx.r11.u64;
	// xori r10,r5,1
	ctx.r10.u64 = ctx.r5.u64 ^ 1;
	// subfe r9,r3,r3
	temp.u8 = (~ctx.r3.u32 + ctx.r3.u32 < ~ctx.r3.u32) | (~ctx.r3.u32 + ctx.r3.u32 + ctx.xer.ca < ctx.xer.ca);
	ctx.r9.u64 = ~ctx.r3.u64 + ctx.r3.u64 + ctx.xer.ca;
	ctx.xer.ca = temp.u8;
	// addi r8,r10,-1
	ctx.r8.s64 = ctx.r10.s64 + -1;
	// clrlwi r10,r9,31
	ctx.r10.u64 = ctx.r9.u32 & 0x1;
	// addi r4,r6,5468
	ctx.r4.s64 = ctx.r6.s64 + 5468;
	// addi r10,r10,-1
	ctx.r10.s64 = ctx.r10.s64 + -1;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// nor r6,r8,r10
	ctx.r6.u64 = ~(ctx.r8.u64 | ctx.r10.u64);
	// and r5,r10,r11
	ctx.r5.u64 = ctx.r10.u64 & ctx.r11.u64;
	// and r11,r6,r7
	ctx.r11.u64 = ctx.r6.u64 & ctx.r7.u64;
	// or r5,r11,r5
	ctx.r5.u64 = ctx.r11.u64 | ctx.r5.u64;
	// stw r5,120(r1)
	REX_STORE_U32(ctx.r1.u32 + 120, ctx.r5.u32);
	// bl 0x8b0c0148
	ctx.lr = 0x8B0ADD14;
	sub_8B0C0148(ctx, base);
	// lwz r11,124(r1)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r1.u32 + 124);
	// lwz r9,120(r1)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r1.u32 + 120);
	// lis r7,-29944
	ctx.r7.s64 = -1962409984;
	// rlwinm r6,r11,1,31,31
	ctx.r6.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 1) & 0x1;
	// subfc r5,r11,r9
	ctx.xer.ca = ctx.r9.u32 >= ctx.r11.u32;
	ctx.r5.u64 = ctx.r9.u64 - ctx.r11.u64;
	// xori r8,r6,1
	ctx.r8.u64 = ctx.r6.u64 ^ 1;
	// subfe r3,r4,r4
	temp.u8 = (~ctx.r4.u32 + ctx.r4.u32 < ~ctx.r4.u32) | (~ctx.r4.u32 + ctx.r4.u32 + ctx.xer.ca < ctx.xer.ca);
	ctx.r3.u64 = ~ctx.r4.u64 + ctx.r4.u64 + ctx.xer.ca;
	ctx.xer.ca = temp.u8;
	// addi r8,r8,-1
	ctx.r8.s64 = ctx.r8.s64 + -1;
	// clrlwi r10,r3,31
	ctx.r10.u64 = ctx.r3.u32 & 0x1;
	// addi r4,r7,5432
	ctx.r4.s64 = ctx.r7.s64 + 5432;
	// addi r10,r10,-1
	ctx.r10.s64 = ctx.r10.s64 + -1;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// nor r7,r8,r10
	ctx.r7.u64 = ~(ctx.r8.u64 | ctx.r10.u64);
	// and r6,r10,r11
	ctx.r6.u64 = ctx.r10.u64 & ctx.r11.u64;
	// and r5,r7,r9
	ctx.r5.u64 = ctx.r7.u64 & ctx.r9.u64;
	// or r5,r5,r6
	ctx.r5.u64 = ctx.r5.u64 | ctx.r6.u64;
	// stw r5,124(r1)
	REX_STORE_U32(ctx.r1.u32 + 124, ctx.r5.u32);
	// bl 0x8b0c0148
	ctx.lr = 0x8B0ADD5C;
	sub_8B0C0148(ctx, base);
	// b 0x8b0adde4
	goto loc_8B0ADDE4;
loc_8B0ADD60:
	// lwz r11,2364(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 2364);
	// lwz r31,84(r11)
	ctx.r31.u64 = REX_LOAD_U32(ctx.r11.u32 + 84);
	// cmplwi cr6,r31,0
	ctx.cr6.compare<uint32_t>(ctx.r31.u32, 0, ctx.xer);
	// beq cr6,0x8b0add90
	if (ctx.cr6.eq) goto loc_8B0ADD90;
	// lwz r11,0(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 0);
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// lwz r10,360(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 360);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B0ADD84;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// clrlwi r9,r3,24
	ctx.r9.u64 = ctx.r3.u32 & 0xFF;
	// cmplwi cr6,r9,0
	ctx.cr6.compare<uint32_t>(ctx.r9.u32, 0, ctx.xer);
	// beq cr6,0x8b0add9c
	if (ctx.cr6.eq) goto loc_8B0ADD9C;
loc_8B0ADD90:
	// li r3,0
	ctx.r3.s64 = 0;
	// addi r1,r1,160
	ctx.r1.s64 = ctx.r1.s64 + 160;
	// b 0x8b0cba0c
	__restgprlr_29(ctx, base);
	return;
loc_8B0ADD9C:
	// lwz r11,0(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 0);
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// lwz r10,212(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 212);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B0ADDB0;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0add90
	if (ctx.cr6.eq) goto loc_8B0ADD90;
	// lbz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U8(ctx.r3.u32 + 0);
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// beq cr6,0x8b0add90
	if (ctx.cr6.eq) goto loc_8B0ADD90;
	// li r3,36
	ctx.r3.s64 = 36;
	// bl 0x8b0bf448
	ctx.lr = 0x8B0ADDCC;
	sub_8B0BF448(ctx, base);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0add90
	if (ctx.cr6.eq) goto loc_8B0ADD90;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// addi r4,r11,26520
	ctx.r4.s64 = ctx.r11.s64 + 26520;
	// bl 0x8b0bf9f8
	ctx.lr = 0x8B0ADDE0;
	sub_8B0BF9F8(ctx, base);
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
loc_8B0ADDE4:
	// cmplwi cr6,r31,0
	ctx.cr6.compare<uint32_t>(ctx.r31.u32, 0, ctx.xer);
	// beq cr6,0x8b0add90
	if (ctx.cr6.eq) goto loc_8B0ADD90;
	// lwz r3,3036(r30)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r30.u32 + 3036);
	// lwz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r10,64(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 64);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B0ADE00;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// lwz r9,0(r3)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// mr r5,r29
	ctx.r5.u64 = ctx.r29.u64;
	// mr r4,r31
	ctx.r4.u64 = ctx.r31.u64;
	// lwz r8,0(r9)
	ctx.r8.u64 = REX_LOAD_U32(ctx.r9.u32 + 0);
	// mtctr r8
	ctx.ctr.u64 = ctx.r8.u64;
	// bctrl 
	ctx.lr = 0x8B0ADE18;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// addi r1,r1,160
	ctx.r1.s64 = ctx.r1.s64 + 160;
	// b 0x8b0cba0c
	__restgprlr_29(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0AE640) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9b4
	ctx.lr = 0x8B0AE648;
	__savegprlr_27(ctx, base);
	// stwu r1,-128(r1)
	ea = -128 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lis r11,-29936
	ctx.r11.s64 = -1961885696;
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// lwz r3,-17796(r11)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r11.u32 + -17796);
	// lwz r10,0(r3)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r9,36(r10)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r10.u32 + 36);
	// mtctr r9
	ctx.ctr.u64 = ctx.r9.u64;
	// bctrl 
	ctx.lr = 0x8B0AE668;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// cmplw cr6,r3,r31
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, ctx.r31.u32, ctx.xer);
	// beq cr6,0x8b0ae684
	if (ctx.cr6.eq) goto loc_8B0AE684;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// addi r3,r11,27224
	ctx.r3.s64 = ctx.r11.s64 + 27224;
	// bl 0x8b0df2e8
	ctx.lr = 0x8B0AE67C;
	sub_8B0DF2E8(ctx, base);
	// addi r1,r1,128
	ctx.r1.s64 = ctx.r1.s64 + 128;
	// b 0x8b0cba04
	__restgprlr_27(ctx, base);
	return;
loc_8B0AE684:
	// lwz r11,24(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 24);
	// cmpwi cr6,r11,2
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 2, ctx.xer);
	// beq cr6,0x8b0ae6c4
	if (ctx.cr6.eq) goto loc_8B0AE6C4;
	// cmpwi cr6,r11,8
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 8, ctx.xer);
	// bne cr6,0x8b0ae7b8
	if (!ctx.cr6.eq) goto loc_8B0AE7B8;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// addi r4,r11,27152
	ctx.r4.s64 = ctx.r11.s64 + 27152;
	// addi r3,r10,27136
	ctx.r3.s64 = ctx.r10.s64 + 27136;
	// li r5,0
	ctx.r5.s64 = 0;
	// bl 0x8b0c0c70
	ctx.lr = 0x8B0AE6B0;
	sub_8B0C0C70(ctx, base);
	// lwz r9,0(r31)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r31.u32 + 0);
	// mr r30,r3
	ctx.r30.u64 = ctx.r3.u64;
	// lwz r8,8(r9)
	ctx.r8.u64 = REX_LOAD_U32(ctx.r9.u32 + 8);
	// mtctr r8
	ctx.ctr.u64 = ctx.r8.u64;
	// b 0x8b0ae79c
	goto loc_8B0AE79C;
loc_8B0AE6C4:
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lwz r3,8(r31)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r31.u32 + 8);
	// li r5,0
	ctx.r5.s64 = 0;
	// addi r4,r11,4588
	ctx.r4.s64 = ctx.r11.s64 + 4588;
	// bl 0x8b0c1588
	ctx.lr = 0x8B0AE6D8;
	sub_8B0C1588(ctx, base);
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// lis r9,-29944
	ctx.r9.s64 = -1962409984;
	// addi r5,r10,1791
	ctx.r5.s64 = ctx.r10.s64 + 1791;
	// addi r4,r9,4576
	ctx.r4.s64 = ctx.r9.s64 + 4576;
	// mr r28,r3
	ctx.r28.u64 = ctx.r3.u64;
	// lwz r3,8(r31)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r31.u32 + 8);
	// bl 0x8b0c1588
	ctx.lr = 0x8B0AE6F4;
	sub_8B0C1588(ctx, base);
	// lis r8,-29944
	ctx.r8.s64 = -1962409984;
	// lis r7,-29944
	ctx.r7.s64 = -1962409984;
	// addi r6,r8,27136
	ctx.r6.s64 = ctx.r8.s64 + 27136;
	// mr r29,r3
	ctx.r29.u64 = ctx.r3.u64;
	// addi r4,r7,27064
	ctx.r4.s64 = ctx.r7.s64 + 27064;
	// li r5,0
	ctx.r5.s64 = 0;
	// mr r3,r6
	ctx.r3.u64 = ctx.r6.u64;
	// bl 0x8b0c0c70
	ctx.lr = 0x8B0AE714;
	sub_8B0C0C70(ctx, base);
	// mr r30,r3
	ctx.r30.u64 = ctx.r3.u64;
	// cmplwi cr6,r28,0
	ctx.cr6.compare<uint32_t>(ctx.r28.u32, 0, ctx.xer);
	// bne cr6,0x8b0ae73c
	if (!ctx.cr6.eq) goto loc_8B0AE73C;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// mr r3,r29
	ctx.r3.u64 = ctx.r29.u64;
	// addi r4,r11,16460
	ctx.r4.s64 = ctx.r11.s64 + 16460;
	// bl 0x8b0cea10
	ctx.lr = 0x8B0AE730;
	sub_8B0CEA10(ctx, base);
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// li r29,0
	ctx.r29.s64 = 0;
	// bne cr6,0x8b0ae740
	if (!ctx.cr6.eq) goto loc_8B0AE740;
loc_8B0AE73C:
	// li r29,1
	ctx.r29.s64 = 1;
loc_8B0AE740:
	// lis r11,-29938
	ctx.r11.s64 = -1962016768;
	// lwz r3,3036(r11)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r11.u32 + 3036);
	// lwz r10,0(r3)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r9,64(r10)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r10.u32 + 64);
	// mtctr r9
	ctx.ctr.u64 = ctx.r9.u64;
	// bctrl 
	ctx.lr = 0x8B0AE758;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// mr r28,r3
	ctx.r28.u64 = ctx.r3.u64;
	// lis r8,-29944
	ctx.r8.s64 = -1962409984;
	// li r5,0
	ctx.r5.s64 = 0;
	// addi r4,r8,4056
	ctx.r4.s64 = ctx.r8.s64 + 4056;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// lwz r27,0(r28)
	ctx.r27.u64 = REX_LOAD_U32(ctx.r28.u32 + 0);
	// bl 0x8b0bfa88
	ctx.lr = 0x8B0AE774;
	sub_8B0BFA88(ctx, base);
	// lwz r7,8(r27)
	ctx.r7.u64 = REX_LOAD_U32(ctx.r27.u32 + 8);
	// mr r5,r3
	ctx.r5.u64 = ctx.r3.u64;
	// lwz r4,8(r31)
	ctx.r4.u64 = REX_LOAD_U32(ctx.r31.u32 + 8);
	// mr r3,r28
	ctx.r3.u64 = ctx.r28.u64;
	// clrlwi r6,r29,24
	ctx.r6.u64 = ctx.r29.u32 & 0xFF;
	// mtctr r7
	ctx.ctr.u64 = ctx.r7.u64;
	// bctrl 
	ctx.lr = 0x8B0AE790;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// lwz r6,0(r31)
	ctx.r6.u64 = REX_LOAD_U32(ctx.r31.u32 + 0);
	// lwz r5,8(r6)
	ctx.r5.u64 = REX_LOAD_U32(ctx.r6.u32 + 8);
	// mtctr r5
	ctx.ctr.u64 = ctx.r5.u64;
loc_8B0AE79C:
	// mr r4,r30
	ctx.r4.u64 = ctx.r30.u64;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bctrl 
	ctx.lr = 0x8B0AE7A8;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// cmplwi cr6,r30,0
	ctx.cr6.compare<uint32_t>(ctx.r30.u32, 0, ctx.xer);
	// beq cr6,0x8b0ae7b8
	if (ctx.cr6.eq) goto loc_8B0AE7B8;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// bl 0x8b0c04f0
	ctx.lr = 0x8B0AE7B8;
	sub_8B0C04F0(ctx, base);
loc_8B0AE7B8:
	// addi r1,r1,128
	ctx.r1.s64 = ctx.r1.s64 + 128;
	// b 0x8b0cba04
	__restgprlr_27(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0AEE98) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// std r30,-24(r1)
	REX_STORE_U64(ctx.r1.u32 + -24, ctx.r30.u64);
	// std r31,-16(r1)
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.r31.u64);
	// stwu r1,-112(r1)
	ea = -112 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// addi r4,r11,27656
	ctx.r4.s64 = ctx.r11.s64 + 27656;
	// addi r3,r10,4056
	ctx.r3.s64 = ctx.r10.s64 + 4056;
	// li r5,0
	ctx.r5.s64 = 0;
	// bl 0x8b0c0c70
	ctx.lr = 0x8B0AEEC8;
	sub_8B0C0C70(ctx, base);
	// lwz r9,0(r31)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r31.u32 + 0);
	// mr r30,r3
	ctx.r30.u64 = ctx.r3.u64;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// mr r4,r30
	ctx.r4.u64 = ctx.r30.u64;
	// lwz r8,8(r9)
	ctx.r8.u64 = REX_LOAD_U32(ctx.r9.u32 + 8);
	// mtctr r8
	ctx.ctr.u64 = ctx.r8.u64;
	// bctrl 
	ctx.lr = 0x8B0AEEE4;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// cmplwi cr6,r30,0
	ctx.cr6.compare<uint32_t>(ctx.r30.u32, 0, ctx.xer);
	// beq cr6,0x8b0aeef4
	if (ctx.cr6.eq) goto loc_8B0AEEF4;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// bl 0x8b0c04f0
	ctx.lr = 0x8B0AEEF4;
	sub_8B0C04F0(ctx, base);
loc_8B0AEEF4:
	// lwz r3,8(r31)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r31.u32 + 8);
	// bl 0x8b098228
	ctx.lr = 0x8B0AEEFC;
	sub_8B098228(ctx, base);
	// lis r11,-29936
	ctx.r11.s64 = -1961885696;
	// lwz r3,-17796(r11)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r11.u32 + -17796);
	// lwz r10,0(r3)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r9,32(r10)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r10.u32 + 32);
	// mtctr r9
	ctx.ctr.u64 = ctx.r9.u64;
	// bctrl 
	ctx.lr = 0x8B0AEF14;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// lwz r8,0(r3)
	ctx.r8.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r4,8(r31)
	ctx.r4.u64 = REX_LOAD_U32(ctx.r31.u32 + 8);
	// lwz r7,44(r8)
	ctx.r7.u64 = REX_LOAD_U32(ctx.r8.u32 + 44);
	// mtctr r7
	ctx.ctr.u64 = ctx.r7.u64;
	// bctrl 
	ctx.lr = 0x8B0AEF28;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// clrlwi r6,r3,24
	ctx.r6.u64 = ctx.r3.u32 & 0xFF;
	// cmplwi cr6,r6,0
	ctx.cr6.compare<uint32_t>(ctx.r6.u32, 0, ctx.xer);
	// bne cr6,0x8b0aefc0
	if (!ctx.cr6.eq) goto loc_8B0AEFC0;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// addi r3,r11,27620
	ctx.r3.s64 = ctx.r11.s64 + 27620;
	// bl 0x8b0df2a8
	ctx.lr = 0x8B0AEF40;
	sub_8B0DF2A8(ctx, base);
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// li r9,1
	ctx.r9.s64 = 1;
	// lwz r3,8(r31)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r31.u32 + 8);
	// addi r8,r10,1800
	ctx.r8.s64 = ctx.r10.s64 + 1800;
	// stw r9,84(r1)
	REX_STORE_U32(ctx.r1.u32 + 84, ctx.r9.u32);
	// li r5,1
	ctx.r5.s64 = 1;
	// stw r8,80(r1)
	REX_STORE_U32(ctx.r1.u32 + 80, ctx.r8.u32);
	// addi r4,r1,80
	ctx.r4.s64 = ctx.r1.s64 + 80;
	// bl 0x8b0bf510
	ctx.lr = 0x8B0AEF64;
	sub_8B0BF510(ctx, base);
	// li r3,36
	ctx.r3.s64 = 36;
	// bl 0x8b0bf448
	ctx.lr = 0x8B0AEF6C;
	sub_8B0BF448(ctx, base);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0aefa4
	if (ctx.cr6.eq) goto loc_8B0AEFA4;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// addi r6,r11,17076
	ctx.r6.s64 = ctx.r11.s64 + 17076;
	// lis r9,-29944
	ctx.r9.s64 = -1962409984;
	// lis r4,-29944
	ctx.r4.s64 = -1962409984;
	// mr r7,r6
	ctx.r7.u64 = ctx.r6.u64;
	// addi r8,r10,27612
	ctx.r8.s64 = ctx.r10.s64 + 27612;
	// addi r5,r9,4072
	ctx.r5.s64 = ctx.r9.s64 + 4072;
	// addi r4,r4,4080
	ctx.r4.s64 = ctx.r4.s64 + 4080;
	// bl 0x8b0c1438
	ctx.lr = 0x8B0AEF9C;
	sub_8B0C1438(ctx, base);
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// b 0x8b0aefa8
	goto loc_8B0AEFA8;
loc_8B0AEFA4:
	// li r4,0
	ctx.r4.s64 = 0;
loc_8B0AEFA8:
	// lis r11,-29938
	ctx.r11.s64 = -1962016768;
	// lwz r3,4480(r11)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r11.u32 + 4480);
	// lwz r10,0(r3)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r9,8(r10)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r10.u32 + 8);
	// mtctr r9
	ctx.ctr.u64 = ctx.r9.u64;
	// bctrl 
	ctx.lr = 0x8B0AEFC0;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
loc_8B0AEFC0:
	// addi r1,r1,112
	ctx.r1.s64 = ctx.r1.s64 + 112;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// ld r30,-24(r1)
	ctx.r30.u64 = REX_LOAD_U64(ctx.r1.u32 + -24);
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0AF840) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// std r31,-16(r1)
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.r31.u64);
	// stwu r1,-96(r1)
	ea = -96 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lwz r11,24(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 24);
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// cmplwi cr6,r11,5
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 5, ctx.xer);
	// bgt cr6,0x8b0af98c
	if (ctx.cr6.gt) goto loc_8B0AF98C;
	// mtctr r11
	ctx.ctr.u64 = ctx.r11.u64;
	// cmpwi cr6,r11,0
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// bdzf 4*cr6+eq,0x8b0af98c
	--ctx.ctr.u64;
	if (ctx.ctr.u32 == 0 && !ctx.cr6.eq) goto loc_8B0AF98C;
	// bdzf 4*cr6+eq,0x8b0af98c
	--ctx.ctr.u64;
	if (ctx.ctr.u32 == 0 && !ctx.cr6.eq) goto loc_8B0AF98C;
	// bdzf 4*cr6+eq,0x8b0af964
	--ctx.ctr.u64;
	if (ctx.ctr.u32 == 0 && !ctx.cr6.eq) goto loc_8B0AF964;
	// bdzf 4*cr6+eq,0x8b0af984
	--ctx.ctr.u64;
	if (ctx.ctr.u32 == 0 && !ctx.cr6.eq) goto loc_8B0AF984;
	// bne cr6,0x8b0af90c
	if (!ctx.cr6.eq) goto loc_8B0AF90C;
	// li r11,1
	ctx.r11.s64 = 1;
	// li r3,36
	ctx.r3.s64 = 36;
	// stw r11,24(r31)
	REX_STORE_U32(ctx.r31.u32 + 24, ctx.r11.u32);
	// bl 0x8b0bf448
	ctx.lr = 0x8B0AF88C;
	sub_8B0BF448(ctx, base);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0af8c4
	if (ctx.cr6.eq) goto loc_8B0AF8C4;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// addi r6,r11,28164
	ctx.r6.s64 = ctx.r11.s64 + 28164;
	// lis r9,-29944
	ctx.r9.s64 = -1962409984;
	// lis r4,-29944
	ctx.r4.s64 = -1962409984;
	// mr r7,r6
	ctx.r7.u64 = ctx.r6.u64;
	// addi r8,r10,28152
	ctx.r8.s64 = ctx.r10.s64 + 28152;
	// addi r5,r9,4072
	ctx.r5.s64 = ctx.r9.s64 + 4072;
	// addi r4,r4,4080
	ctx.r4.s64 = ctx.r4.s64 + 4080;
	// bl 0x8b0c1438
	ctx.lr = 0x8B0AF8BC;
	sub_8B0C1438(ctx, base);
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// b 0x8b0af8c8
	goto loc_8B0AF8C8;
loc_8B0AF8C4:
	// li r4,0
	ctx.r4.s64 = 0;
loc_8B0AF8C8:
	// lis r11,-29938
	ctx.r11.s64 = -1962016768;
	// lwz r3,4480(r11)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r11.u32 + 4480);
	// lwz r10,0(r3)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r9,8(r10)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r10.u32 + 8);
	// mtctr r9
	ctx.ctr.u64 = ctx.r9.u64;
	// bctrl 
	ctx.lr = 0x8B0AF8E0;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// li r3,200
	ctx.r3.s64 = 200;
	// bl 0x8b090000
	ctx.lr = 0x8B0AF8E8;
	sub_8B090000(ctx, base);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0af900
	if (ctx.cr6.eq) goto loc_8B0AF900;
	// lwz r4,8(r31)
	ctx.r4.u64 = REX_LOAD_U32(ctx.r31.u32 + 8);
	// bl 0x8b0a1890
	ctx.lr = 0x8B0AF8F8;
	sub_8B0A1890(ctx, base);
	// stw r3,28(r31)
	REX_STORE_U32(ctx.r31.u32 + 28, ctx.r3.u32);
	// b 0x8b0af98c
	goto loc_8B0AF98C;
loc_8B0AF900:
	// li r3,0
	ctx.r3.s64 = 0;
	// stw r3,28(r31)
	REX_STORE_U32(ctx.r31.u32 + 28, ctx.r3.u32);
	// b 0x8b0af98c
	goto loc_8B0AF98C;
loc_8B0AF90C:
	// lwz r3,32(r31)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r31.u32 + 32);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0af98c
	if (ctx.cr6.eq) goto loc_8B0AF98C;
	// lwz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r10,8(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 8);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B0AF928;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// lwz r3,32(r31)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r31.u32 + 32);
	// lwz r9,0(r3)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r8,16(r9)
	ctx.r8.u64 = REX_LOAD_U32(ctx.r9.u32 + 16);
	// mtctr r8
	ctx.ctr.u64 = ctx.r8.u64;
	// bctrl 
	ctx.lr = 0x8B0AF93C;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// clrlwi r7,r3,24
	ctx.r7.u64 = ctx.r3.u32 & 0xFF;
	// cmplwi cr6,r7,0
	ctx.cr6.compare<uint32_t>(ctx.r7.u32, 0, ctx.xer);
	// beq cr6,0x8b0af98c
	if (ctx.cr6.eq) goto loc_8B0AF98C;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0af698
	ctx.lr = 0x8B0AF950;
	sub_8B0AF698(ctx, base);
	// addi r1,r1,96
	ctx.r1.s64 = ctx.r1.s64 + 96;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
loc_8B0AF964:
	// lwz r3,36(r31)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r31.u32 + 36);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0af98c
	if (ctx.cr6.eq) goto loc_8B0AF98C;
	// lwz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r10,16(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 16);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B0AF980;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// b 0x8b0af98c
	goto loc_8B0AF98C;
loc_8B0AF984:
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0ae368
	ctx.lr = 0x8B0AF98C;
	sub_8B0AE368(ctx, base);
loc_8B0AF98C:
	// lwz r3,28(r31)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r31.u32 + 28);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0af9a8
	if (ctx.cr6.eq) goto loc_8B0AF9A8;
	// lwz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r10,16(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 16);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B0AF9A8;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
loc_8B0AF9A8:
	// addi r1,r1,96
	ctx.r1.s64 = ctx.r1.s64 + 96;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0AFEE8) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9bc
	ctx.lr = 0x8B0AFEF0;
	__savegprlr_29(ctx, base);
	// stwu r1,-128(r1)
	ea = -128 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lwz r11,24(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 24);
	// mr r30,r3
	ctx.r30.u64 = ctx.r3.u64;
	// cmpwi cr6,r11,7
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 7, ctx.xer);
	// bne cr6,0x8b0aff9c
	if (!ctx.cr6.eq) goto loc_8B0AFF9C;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lwz r3,8(r3)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r3.u32 + 8);
	// li r31,0
	ctx.r31.s64 = 0;
	// addi r4,r11,5432
	ctx.r4.s64 = ctx.r11.s64 + 5432;
	// li r5,0
	ctx.r5.s64 = 0;
	// stw r31,80(r1)
	REX_STORE_U32(ctx.r1.u32 + 80, ctx.r31.u32);
	// stw r31,84(r1)
	REX_STORE_U32(ctx.r1.u32 + 84, ctx.r31.u32);
	// stw r31,88(r1)
	REX_STORE_U32(ctx.r1.u32 + 88, ctx.r31.u32);
	// bl 0x8b0bfc38
	ctx.lr = 0x8B0AFF28;
	sub_8B0BFC38(ctx, base);
	// stw r31,92(r1)
	REX_STORE_U32(ctx.r1.u32 + 92, ctx.r31.u32);
	// mr r5,r3
	ctx.r5.u64 = ctx.r3.u64;
	// li r6,0
	ctx.r6.s64 = 0;
	// li r4,0
	ctx.r4.s64 = 0;
	// addi r3,r1,80
	ctx.r3.s64 = ctx.r1.s64 + 80;
	// bl 0x8b0bcb60
	ctx.lr = 0x8B0AFF40;
	sub_8B0BCB60(ctx, base);
	// lwz r10,92(r1)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r1.u32 + 92);
	// li r4,0
	ctx.r4.s64 = 0;
	// rlwinm r5,r10,2,0,29
	ctx.r5.u64 = __builtin_rotateleft64(ctx.r10.u32 | (ctx.r10.u64 << 32), 2) & 0xFFFFFFFC;
	// lwz r29,80(r1)
	ctx.r29.u64 = REX_LOAD_U32(ctx.r1.u32 + 80);
	// mr r3,r29
	ctx.r3.u64 = ctx.r29.u64;
	// bl 0x8b0cb8e0
	ctx.lr = 0x8B0AFF58;
	sub_8B0CB8E0(ctx, base);
	// lis r9,-29938
	ctx.r9.s64 = -1962016768;
	// lwz r3,3036(r9)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r9.u32 + 3036);
	// lwz r8,0(r3)
	ctx.r8.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r7,64(r8)
	ctx.r7.u64 = REX_LOAD_U32(ctx.r8.u32 + 64);
	// mtctr r7
	ctx.ctr.u64 = ctx.r7.u64;
	// bctrl 
	ctx.lr = 0x8B0AFF70;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// lwz r6,0(r3)
	ctx.r6.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// mr r5,r29
	ctx.r5.u64 = ctx.r29.u64;
	// lwz r4,8(r30)
	ctx.r4.u64 = REX_LOAD_U32(ctx.r30.u32 + 8);
	// lwz r11,40(r6)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r6.u32 + 40);
	// mtctr r11
	ctx.ctr.u64 = ctx.r11.u64;
	// bctrl 
	ctx.lr = 0x8B0AFF88;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// stw r31,92(r1)
	REX_STORE_U32(ctx.r1.u32 + 92, ctx.r31.u32);
	// addi r3,r1,80
	ctx.r3.s64 = ctx.r1.s64 + 80;
	// bl 0x8b0906a8
	ctx.lr = 0x8B0AFF94;
	sub_8B0906A8(ctx, base);
	// addi r3,r1,80
	ctx.r3.s64 = ctx.r1.s64 + 80;
	// bl 0x8b0906a8
	ctx.lr = 0x8B0AFF9C;
	sub_8B0906A8(ctx, base);
loc_8B0AFF9C:
	// addi r1,r1,128
	ctx.r1.s64 = ctx.r1.s64 + 128;
	// b 0x8b0cba0c
	__restgprlr_29(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0B09E0) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// stwu r1,-96(r1)
	ea = -96 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lwz r10,16(r3)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r3.u32 + 16);
	// mr r11,r3
	ctx.r11.u64 = ctx.r3.u64;
	// cmpwi cr6,r10,0
	ctx.cr6.compare<int32_t>(ctx.r10.s32, 0, ctx.xer);
	// bne cr6,0x8b0b0a54
	if (!ctx.cr6.eq) goto loc_8B0B0A54;
	// li r10,1
	ctx.r10.s64 = 1;
	// li r3,36
	ctx.r3.s64 = 36;
	// stw r10,16(r11)
	REX_STORE_U32(ctx.r11.u32 + 16, ctx.r10.u32);
	// bl 0x8b0bf448
	ctx.lr = 0x8B0B0A0C;
	sub_8B0BF448(ctx, base);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0b0a38
	if (ctx.cr6.eq) goto loc_8B0B0A38;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// lis r9,-29944
	ctx.r9.s64 = -1962409984;
	// addi r6,r11,4040
	ctx.r6.s64 = ctx.r11.s64 + 4040;
	// addi r5,r10,4072
	ctx.r5.s64 = ctx.r10.s64 + 4072;
	// addi r4,r9,4080
	ctx.r4.s64 = ctx.r9.s64 + 4080;
	// bl 0x8b0c1300
	ctx.lr = 0x8B0B0A30;
	sub_8B0C1300(ctx, base);
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// b 0x8b0b0a3c
	goto loc_8B0B0A3C;
loc_8B0B0A38:
	// li r4,0
	ctx.r4.s64 = 0;
loc_8B0B0A3C:
	// lis r11,-29938
	ctx.r11.s64 = -1962016768;
	// lwz r3,4480(r11)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r11.u32 + 4480);
	// lwz r10,0(r3)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r9,8(r10)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r10.u32 + 8);
	// mtctr r9
	ctx.ctr.u64 = ctx.r9.u64;
	// bctrl 
	ctx.lr = 0x8B0B0A54;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
loc_8B0B0A54:
	// addi r1,r1,96
	ctx.r1.s64 = ctx.r1.s64 + 96;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0B0BB0) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// std r31,-16(r1)
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.r31.u64);
	// stwu r1,-112(r1)
	ea = -112 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// addi r9,r11,28756
	ctx.r9.s64 = ctx.r11.s64 + 28756;
	// addi r8,r10,28748
	ctx.r8.s64 = ctx.r10.s64 + 28748;
	// stw r9,0(r3)
	REX_STORE_U32(ctx.r3.u32 + 0, ctx.r9.u32);
	// lis r7,-29944
	ctx.r7.s64 = -1962409984;
	// stw r8,4(r3)
	REX_STORE_U32(ctx.r3.u32 + 4, ctx.r8.u32);
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// addi r3,r7,28704
	ctx.r3.s64 = ctx.r7.s64 + 28704;
	// bl 0x8b0df298
	ctx.lr = 0x8B0B0BE8;
	sub_8B0DF298(ctx, base);
	// lis r6,-29944
	ctx.r6.s64 = -1962409984;
	// li r5,1
	ctx.r5.s64 = 1;
	// lwz r3,8(r31)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r31.u32 + 8);
	// addi r4,r6,1800
	ctx.r4.s64 = ctx.r6.s64 + 1800;
	// stw r5,84(r1)
	REX_STORE_U32(ctx.r1.u32 + 84, ctx.r5.u32);
	// stw r4,80(r1)
	REX_STORE_U32(ctx.r1.u32 + 80, ctx.r4.u32);
	// addi r4,r1,80
	ctx.r4.s64 = ctx.r1.s64 + 80;
	// bl 0x8b0bf510
	ctx.lr = 0x8B0B0C08;
	sub_8B0BF510(ctx, base);
	// lwz r3,12(r31)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r31.u32 + 12);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0b0c18
	if (ctx.cr6.eq) goto loc_8B0B0C18;
	// bl 0x8b0c04f0
	ctx.lr = 0x8B0B0C18;
	sub_8B0C04F0(ctx, base);
loc_8B0B0C18:
	// addi r1,r1,112
	ctx.r1.s64 = ctx.r1.s64 + 112;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0B0C90) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9a0
	ctx.lr = 0x8B0B0C98;
	__savegprlr_22(ctx, base);
	// stwu r1,-448(r1)
	ea = -448 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// li r5,1
	ctx.r5.s64 = 1;
	// addi r4,r11,28036
	ctx.r4.s64 = ctx.r11.s64 + 28036;
	// mr r23,r3
	ctx.r23.u64 = ctx.r3.u64;
	// lwz r3,8(r3)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r3.u32 + 8);
	// bl 0x8b0bfa88
	ctx.lr = 0x8B0B0CB4;
	sub_8B0BFA88(ctx, base);
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0b0cec
	if (ctx.cr6.eq) goto loc_8B0B0CEC;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// addi r5,r11,3712
	ctx.r5.s64 = ctx.r11.s64 + 3712;
	// addi r4,r10,28020
	ctx.r4.s64 = ctx.r10.s64 + 28020;
	// bl 0x8b0c0010
	ctx.lr = 0x8B0B0CD4;
	sub_8B0C0010(ctx, base);
	// lis r9,-29944
	ctx.r9.s64 = -1962409984;
	// lis r8,-29944
	ctx.r8.s64 = -1962409984;
	// addi r5,r9,5788
	ctx.r5.s64 = ctx.r9.s64 + 5788;
	// addi r4,r8,28012
	ctx.r4.s64 = ctx.r8.s64 + 28012;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0c0010
	ctx.lr = 0x8B0B0CEC;
	sub_8B0C0010(ctx, base);
loc_8B0B0CEC:
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lwz r3,8(r23)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r23.u32 + 8);
	// li r5,1
	ctx.r5.s64 = 1;
	// addi r4,r11,9156
	ctx.r4.s64 = ctx.r11.s64 + 9156;
	// bl 0x8b0bfa88
	ctx.lr = 0x8B0B0D00;
	sub_8B0BFA88(ctx, base);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0b0d1c
	if (ctx.cr6.eq) goto loc_8B0B0D1C;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// addi r5,r11,10100
	ctx.r5.s64 = ctx.r11.s64 + 10100;
	// addi r4,r10,28004
	ctx.r4.s64 = ctx.r10.s64 + 28004;
	// bl 0x8b0c0010
	ctx.lr = 0x8B0B0D1C;
	sub_8B0C0010(ctx, base);
loc_8B0B0D1C:
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lwz r3,8(r23)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r23.u32 + 8);
	// li r5,1
	ctx.r5.s64 = 1;
	// addi r4,r11,3636
	ctx.r4.s64 = ctx.r11.s64 + 3636;
	// bl 0x8b0bfa88
	ctx.lr = 0x8B0B0D30;
	sub_8B0BFA88(ctx, base);
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0b0f04
	if (ctx.cr6.eq) goto loc_8B0B0F04;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// li r5,1
	ctx.r5.s64 = 1;
	// addi r4,r11,3624
	ctx.r4.s64 = ctx.r11.s64 + 3624;
	// bl 0x8b0c0148
	ctx.lr = 0x8B0B0D4C;
	sub_8B0C0148(ctx, base);
	// bl 0x8b0df2c8
	ctx.lr = 0x8B0B0D50;
	sub_8B0DF2C8(ctx, base);
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// mr r27,r3
	ctx.r27.u64 = ctx.r3.u64;
	// addi r29,r11,3592
	ctx.r29.s64 = ctx.r11.s64 + 3592;
	// mr r5,r3
	ctx.r5.u64 = ctx.r3.u64;
	// mr r4,r29
	ctx.r4.u64 = ctx.r29.u64;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0c0148
	ctx.lr = 0x8B0B0D6C;
	sub_8B0C0148(ctx, base);
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// mr r5,r27
	ctx.r5.u64 = ctx.r27.u64;
	// addi r4,r10,27992
	ctx.r4.s64 = ctx.r10.s64 + 27992;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0c0148
	ctx.lr = 0x8B0B0D80;
	sub_8B0C0148(ctx, base);
	// lis r9,-29944
	ctx.r9.s64 = -1962409984;
	// li r5,1
	ctx.r5.s64 = 1;
	// addi r4,r9,27980
	ctx.r4.s64 = ctx.r9.s64 + 27980;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0bfa88
	ctx.lr = 0x8B0B0D94;
	sub_8B0BFA88(ctx, base);
	// mr r30,r3
	ctx.r30.u64 = ctx.r3.u64;
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0b0f04
	if (ctx.cr6.eq) goto loc_8B0B0F04;
	// lis r28,-29938
	ctx.r28.s64 = -1962016768;
	// lwz r11,2548(r28)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r28.u32 + 2548);
	// lwz r31,0(r11)
	ctx.r31.u64 = REX_LOAD_U32(ctx.r11.u32 + 0);
	// bl 0x8b0df318
	ctx.lr = 0x8B0B0DB0;
	sub_8B0DF318(ctx, base);
	// lwz r11,4(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 4);
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// lwz r3,2548(r28)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r28.u32 + 2548);
	// mtctr r11
	ctx.ctr.u64 = ctx.r11.u64;
	// bctrl 
	ctx.lr = 0x8B0B0DC4;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// lwz r10,0(r3)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r9,0(r10)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r10.u32 + 0);
	// mtctr r9
	ctx.ctr.u64 = ctx.r9.u64;
	// bctrl 
	ctx.lr = 0x8B0B0DD4;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// lis r8,-29944
	ctx.r8.s64 = -1962409984;
	// mr r5,r3
	ctx.r5.u64 = ctx.r3.u64;
	// addi r4,r8,16356
	ctx.r4.s64 = ctx.r8.s64 + 16356;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// bl 0x8b0c0190
	ctx.lr = 0x8B0B0DE8;
	sub_8B0C0190(ctx, base);
	// mr r4,r29
	ctx.r4.u64 = ctx.r29.u64;
	// mr r5,r27
	ctx.r5.u64 = ctx.r27.u64;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// bl 0x8b0c0148
	ctx.lr = 0x8B0B0DF8;
	sub_8B0C0148(ctx, base);
	// bl 0x8b0982e0
	ctx.lr = 0x8B0B0DFC;
	sub_8B0982E0(ctx, base);
	// lis r7,-29944
	ctx.r7.s64 = -1962409984;
	// mr r5,r3
	ctx.r5.u64 = ctx.r3.u64;
	// addi r4,r7,3816
	ctx.r4.s64 = ctx.r7.s64 + 3816;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// bl 0x8b0c0190
	ctx.lr = 0x8B0B0E10;
	sub_8B0C0190(ctx, base);
	// bl 0x8b098428
	ctx.lr = 0x8B0B0E14;
	sub_8B098428(ctx, base);
	// lis r6,-29944
	ctx.r6.s64 = -1962409984;
	// mr r5,r3
	ctx.r5.u64 = ctx.r3.u64;
	// addi r4,r6,17688
	ctx.r4.s64 = ctx.r6.s64 + 17688;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// bl 0x8b0c0010
	ctx.lr = 0x8B0B0E28;
	sub_8B0C0010(ctx, base);
	// lis r4,-29944
	ctx.r4.s64 = -1962409984;
	// li r5,0
	ctx.r5.s64 = 0;
	// addi r4,r4,27972
	ctx.r4.s64 = ctx.r4.s64 + 27972;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// bl 0x8b0c0148
	ctx.lr = 0x8B0B0E3C;
	sub_8B0C0148(ctx, base);
	// li r29,0
	ctx.r29.s64 = 0;
	// cmpwi cr6,r27,0
	ctx.cr6.compare<int32_t>(ctx.r27.s32, 0, ctx.xer);
	// ble cr6,0x8b0b0f04
	if (!ctx.cr6.gt) goto loc_8B0B0F04;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// lis r9,-29944
	ctx.r9.s64 = -1962409984;
	// addi r26,r11,2776
	ctx.r26.s64 = ctx.r11.s64 + 2776;
	// addi r25,r10,3616
	ctx.r25.s64 = ctx.r10.s64 + 3616;
	// addi r24,r9,3604
	ctx.r24.s64 = ctx.r9.s64 + 3604;
loc_8B0B0E60:
	// mr r4,r24
	ctx.r4.u64 = ctx.r24.u64;
	// mr r5,r29
	ctx.r5.u64 = ctx.r29.u64;
	// addi r3,r1,96
	ctx.r3.s64 = ctx.r1.s64 + 96;
	// bl 0x8b090220
	ctx.lr = 0x8B0B0E70;
	sub_8B090220(ctx, base);
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// li r5,1
	ctx.r5.s64 = 1;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// bl 0x8b0bfa88
	ctx.lr = 0x8B0B0E80;
	sub_8B0BFA88(ctx, base);
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0b0ef8
	if (ctx.cr6.eq) goto loc_8B0B0EF8;
	// mr r3,r29
	ctx.r3.u64 = ctx.r29.u64;
	// bl 0x8b0df2b8
	ctx.lr = 0x8B0B0E94;
	sub_8B0DF2B8(ctx, base);
	// lwz r11,2548(r28)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r28.u32 + 2548);
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// mr r3,r11
	ctx.r3.u64 = ctx.r11.u64;
	// lwz r10,0(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 0);
	// lwz r9,4(r10)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r10.u32 + 4);
	// mtctr r9
	ctx.ctr.u64 = ctx.r9.u64;
	// bctrl 
	ctx.lr = 0x8B0B0EB0;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// lwz r8,0(r3)
	ctx.r8.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// mr r22,r3
	ctx.r22.u64 = ctx.r3.u64;
	// lwz r7,0(r8)
	ctx.r7.u64 = REX_LOAD_U32(ctx.r8.u32 + 0);
	// mtctr r7
	ctx.ctr.u64 = ctx.r7.u64;
	// bctrl 
	ctx.lr = 0x8B0B0EC4;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// mr r5,r3
	ctx.r5.u64 = ctx.r3.u64;
	// mr r4,r25
	ctx.r4.u64 = ctx.r25.u64;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0c0190
	ctx.lr = 0x8B0B0ED4;
	sub_8B0C0190(ctx, base);
	// lwz r6,0(r22)
	ctx.r6.u64 = REX_LOAD_U32(ctx.r22.u32 + 0);
	// mr r3,r22
	ctx.r3.u64 = ctx.r22.u64;
	// lwz r5,8(r6)
	ctx.r5.u64 = REX_LOAD_U32(ctx.r6.u32 + 8);
	// mtctr r5
	ctx.ctr.u64 = ctx.r5.u64;
	// bctrl 
	ctx.lr = 0x8B0B0EE8;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// mr r5,r3
	ctx.r5.u64 = ctx.r3.u64;
	// mr r4,r26
	ctx.r4.u64 = ctx.r26.u64;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0c0010
	ctx.lr = 0x8B0B0EF8;
	sub_8B0C0010(ctx, base);
loc_8B0B0EF8:
	// addi r29,r29,1
	ctx.r29.s64 = ctx.r29.s64 + 1;
	// cmpw cr6,r29,r27
	ctx.cr6.compare<int32_t>(ctx.r29.s32, ctx.r27.s32, ctx.xer);
	// blt cr6,0x8b0b0e60
	if (ctx.cr6.lt) goto loc_8B0B0E60;
loc_8B0B0F04:
	// lis r11,-29938
	ctx.r11.s64 = -1962016768;
	// lwz r3,3036(r11)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r11.u32 + 3036);
	// lwz r10,0(r3)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r9,64(r10)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r10.u32 + 64);
	// mtctr r9
	ctx.ctr.u64 = ctx.r9.u64;
	// bctrl 
	ctx.lr = 0x8B0B0F1C;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// lwz r8,0(r3)
	ctx.r8.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r4,8(r23)
	ctx.r4.u64 = REX_LOAD_U32(ctx.r23.u32 + 8);
	// lwz r7,24(r8)
	ctx.r7.u64 = REX_LOAD_U32(ctx.r8.u32 + 24);
	// mtctr r7
	ctx.ctr.u64 = ctx.r7.u64;
	// bctrl 
	ctx.lr = 0x8B0B0F30;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// lis r6,-29944
	ctx.r6.s64 = -1962409984;
	// addi r3,r6,28832
	ctx.r3.s64 = ctx.r6.s64 + 28832;
	// bl 0x8b0df298
	ctx.lr = 0x8B0B0F3C;
	sub_8B0DF298(ctx, base);
	// lis r5,-29944
	ctx.r5.s64 = -1962409984;
	// li r4,1
	ctx.r4.s64 = 1;
	// lwz r3,8(r23)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r23.u32 + 8);
	// addi r11,r5,1800
	ctx.r11.s64 = ctx.r5.s64 + 1800;
	// stw r4,84(r1)
	REX_STORE_U32(ctx.r1.u32 + 84, ctx.r4.u32);
	// li r5,1
	ctx.r5.s64 = 1;
	// stw r11,80(r1)
	REX_STORE_U32(ctx.r1.u32 + 80, ctx.r11.u32);
	// addi r4,r1,80
	ctx.r4.s64 = ctx.r1.s64 + 80;
	// bl 0x8b0bf510
	ctx.lr = 0x8B0B0F60;
	sub_8B0BF510(ctx, base);
	// addi r1,r1,448
	ctx.r1.s64 = ctx.r1.s64 + 448;
	// b 0x8b0cb9f0
	__restgprlr_22(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0B1A18) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// std r30,-24(r1)
	REX_STORE_U64(ctx.r1.u32 + -24, ctx.r30.u64);
	// std r31,-16(r1)
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.r31.u64);
	// stwu r1,-112(r1)
	ea = -112 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// mr r30,r3
	ctx.r30.u64 = ctx.r3.u64;
	// li r3,36
	ctx.r3.s64 = 36;
	// bl 0x8b0bf448
	ctx.lr = 0x8B0B1A38;
	sub_8B0BF448(ctx, base);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0b1a64
	if (ctx.cr6.eq) goto loc_8B0B1A64;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// lis r9,-29944
	ctx.r9.s64 = -1962409984;
	// addi r6,r11,9012
	ctx.r6.s64 = ctx.r11.s64 + 9012;
	// addi r5,r10,4500
	ctx.r5.s64 = ctx.r10.s64 + 4500;
	// addi r4,r9,4472
	ctx.r4.s64 = ctx.r9.s64 + 4472;
	// bl 0x8b0c1300
	ctx.lr = 0x8B0B1A5C;
	sub_8B0C1300(ctx, base);
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// b 0x8b0b1a68
	goto loc_8B0B1A68;
loc_8B0B1A64:
	// li r31,0
	ctx.r31.s64 = 0;
loc_8B0B1A68:
	// lis r11,-29936
	ctx.r11.s64 = -1961885696;
	// lwz r3,-17796(r11)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r11.u32 + -17796);
	// lwz r10,0(r3)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r9,28(r10)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r10.u32 + 28);
	// mtctr r9
	ctx.ctr.u64 = ctx.r9.u64;
	// bctrl 
	ctx.lr = 0x8B0B1A80;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// lwz r8,0(r3)
	ctx.r8.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// mr r4,r31
	ctx.r4.u64 = ctx.r31.u64;
	// lwz r7,8(r8)
	ctx.r7.u64 = REX_LOAD_U32(ctx.r8.u32 + 8);
	// mtctr r7
	ctx.ctr.u64 = ctx.r7.u64;
	// bctrl 
	ctx.lr = 0x8B0B1A94;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// lis r6,-29938
	ctx.r6.s64 = -1962016768;
	// lis r5,-29944
	ctx.r5.s64 = -1962409984;
	// addi r4,r5,27560
	ctx.r4.s64 = ctx.r5.s64 + 27560;
	// lwz r11,2364(r6)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r6.u32 + 2364);
	// lwz r3,84(r11)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r11.u32 + 84);
	// lwz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r10,28(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 28);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B0B1AB8;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// cmplwi cr6,r30,0
	ctx.cr6.compare<uint32_t>(ctx.r30.u32, 0, ctx.xer);
	// beq cr6,0x8b0b1ad0
	if (ctx.cr6.eq) goto loc_8B0B1AD0;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// bl 0x8b0b1758
	ctx.lr = 0x8B0B1AC8;
	sub_8B0B1758(ctx, base);
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// bl 0x8b090020
	ctx.lr = 0x8B0B1AD0;
	sub_8B090020(ctx, base);
loc_8B0B1AD0:
	// addi r1,r1,112
	ctx.r1.s64 = ctx.r1.s64 + 112;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// ld r30,-24(r1)
	ctx.r30.u64 = REX_LOAD_U64(ctx.r1.u32 + -24);
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0B1B98) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// std r30,-24(r1)
	REX_STORE_U64(ctx.r1.u32 + -24, ctx.r30.u64);
	// std r31,-16(r1)
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.r31.u64);
	// stwu r1,-112(r1)
	ea = -112 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// mr r3,r4
	ctx.r3.u64 = ctx.r4.u64;
	// mr r30,r4
	ctx.r30.u64 = ctx.r4.u64;
	// bl 0x8b0beee8
	ctx.lr = 0x8B0B1BBC;
	sub_8B0BEEE8(ctx, base);
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// addi r3,r11,17092
	ctx.r3.s64 = ctx.r11.s64 + 17092;
	// bl 0x8b0cea10
	ctx.lr = 0x8B0B1BCC;
	sub_8B0CEA10(ctx, base);
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// bne cr6,0x8b0b1c84
	if (!ctx.cr6.eq) goto loc_8B0B1C84;
	// lwz r11,36(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 36);
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// beq cr6,0x8b0b1c84
	if (ctx.cr6.eq) goto loc_8B0B1C84;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// li r5,0
	ctx.r5.s64 = 0;
	// addi r4,r11,16280
	ctx.r4.s64 = ctx.r11.s64 + 16280;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// bl 0x8b0bfe68
	ctx.lr = 0x8B0B1BF4;
	sub_8B0BFE68(ctx, base);
	// lwz r10,36(r31)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r31.u32 + 36);
	// cmplw cr6,r3,r10
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, ctx.r10.u32, ctx.xer);
	// bne cr6,0x8b0b1c84
	if (!ctx.cr6.eq) goto loc_8B0B1C84;
	// lwz r11,16(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 16);
	// cmpwi cr6,r11,3
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 3, ctx.xer);
	// bne cr6,0x8b0b1c84
	if (!ctx.cr6.eq) goto loc_8B0B1C84;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// li r5,0
	ctx.r5.s64 = 0;
	// addi r4,r11,17076
	ctx.r4.s64 = ctx.r11.s64 + 17076;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// bl 0x8b0c1588
	ctx.lr = 0x8B0B1C20;
	sub_8B0C1588(ctx, base);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0b1c50
	if (ctx.cr6.eq) goto loc_8B0B1C50;
	// lwz r3,36(r31)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r31.u32 + 36);
	// lwz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r10,20(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 20);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B0B1C3C;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// li r9,0
	ctx.r9.s64 = 0;
	// li r8,2
	ctx.r8.s64 = 2;
	// stw r9,36(r31)
	REX_STORE_U32(ctx.r31.u32 + 36, ctx.r9.u32);
	// stw r8,16(r31)
	REX_STORE_U32(ctx.r31.u32 + 16, ctx.r8.u32);
	// b 0x8b0b1c84
	goto loc_8B0B1C84;
loc_8B0B1C50:
	// li r11,0
	ctx.r11.s64 = 0;
	// lwz r4,36(r31)
	ctx.r4.u64 = REX_LOAD_U32(ctx.r31.u32 + 36);
	// li r10,4
	ctx.r10.s64 = 4;
	// lwz r5,4(r31)
	ctx.r5.u64 = REX_LOAD_U32(ctx.r31.u32 + 4);
	// stw r11,36(r31)
	REX_STORE_U32(ctx.r31.u32 + 36, ctx.r11.u32);
	// addi r3,r31,-4
	ctx.r3.s64 = ctx.r31.s64 + -4;
	// stw r10,16(r31)
	REX_STORE_U32(ctx.r31.u32 + 16, ctx.r10.u32);
	// stw r11,4(r31)
	REX_STORE_U32(ctx.r31.u32 + 4, ctx.r11.u32);
	// stw r11,8(r31)
	REX_STORE_U32(ctx.r31.u32 + 8, ctx.r11.u32);
	// lwz r9,-4(r31)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r31.u32 + -4);
	// lwz r8,44(r9)
	ctx.r8.u64 = REX_LOAD_U32(ctx.r9.u32 + 44);
	// mtctr r8
	ctx.ctr.u64 = ctx.r8.u64;
	// bctrl 
	ctx.lr = 0x8B0B1C84;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
loc_8B0B1C84:
	// addi r1,r1,112
	ctx.r1.s64 = ctx.r1.s64 + 112;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// ld r30,-24(r1)
	ctx.r30.u64 = REX_LOAD_U64(ctx.r1.u32 + -24);
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0B1E80) {
	REX_FUNC_PROLOGUE();
	// lwz r3,180(r3)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r3.u32 + 180);
	// lwz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r10,48(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 48);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctr 
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	return;
}

DEFINE_REX_FUNC(sub_8B0B1E98) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// std r30,-24(r1)
	REX_STORE_U64(ctx.r1.u32 + -24, ctx.r30.u64);
	// std r31,-16(r1)
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.r31.u64);
	// stwu r1,-112(r1)
	ea = -112 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// mr r30,r3
	ctx.r30.u64 = ctx.r3.u64;
	// li r3,184
	ctx.r3.s64 = 184;
	// bl 0x8b090000
	ctx.lr = 0x8B0B1EB8;
	sub_8B090000(ctx, base);
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0b1ee4
	if (ctx.cr6.eq) goto loc_8B0B1EE4;
	// lwz r4,8(r30)
	ctx.r4.u64 = REX_LOAD_U32(ctx.r30.u32 + 8);
	// bl 0x8b0bcd70
	ctx.lr = 0x8B0B1ECC;
	sub_8B0BCD70(ctx, base);
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// stw r30,180(r31)
	REX_STORE_U32(ctx.r31.u32 + 180, ctx.r30.u32);
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// addi r10,r11,29492
	ctx.r10.s64 = ctx.r11.s64 + 29492;
	// stw r10,0(r31)
	REX_STORE_U32(ctx.r31.u32 + 0, ctx.r10.u32);
	// b 0x8b0b1ee8
	goto loc_8B0B1EE8;
loc_8B0B1EE4:
	// li r3,0
	ctx.r3.s64 = 0;
loc_8B0B1EE8:
	// addi r1,r1,112
	ctx.r1.s64 = ctx.r1.s64 + 112;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// ld r30,-24(r1)
	ctx.r30.u64 = REX_LOAD_U64(ctx.r1.u32 + -24);
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0B2190) {
	REX_FUNC_PROLOGUE();
	// lis r8,-29938
	ctx.r8.s64 = -1962016768;
	// lis r11,-29938
	ctx.r11.s64 = -1962016768;
	// addi r11,r11,20792
	ctx.r11.s64 = ctx.r11.s64 + 20792;
	// lwz r9,20800(r8)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r8.u32 + 20800);
	// clrlwi r10,r9,31
	ctx.r10.u64 = ctx.r9.u32 & 0x1;
	// cmplwi cr6,r10,0
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 0, ctx.xer);
	// bne cr6,0x8b0b21d8
	if (!ctx.cr6.eq) goto loc_8B0B21D8;
	// ori r9,r9,1
	ctx.r9.u64 = ctx.r9.u64 | 1;
	// lis r10,0
	ctx.r10.s64 = 0;
	// stw r9,20800(r8)
	REX_STORE_U32(ctx.r8.u32 + 20800, ctx.r9.u32);
	// li r9,1
	ctx.r9.s64 = 1;
	// ori r10,r10,65535
	ctx.r10.u64 = ctx.r10.u64 | 65535;
	// sth r9,6(r11)
	REX_STORE_U16(ctx.r11.u32 + 6, ctx.r9.u16);
	// mr r7,r10
	ctx.r7.u64 = ctx.r10.u64;
	// sth r10,0(r11)
	REX_STORE_U16(ctx.r11.u32 + 0, ctx.r10.u16);
	// mr r6,r10
	ctx.r6.u64 = ctx.r10.u64;
	// sth r10,2(r11)
	REX_STORE_U16(ctx.r11.u32 + 2, ctx.r10.u16);
	// sth r10,4(r11)
	REX_STORE_U16(ctx.r11.u32 + 4, ctx.r10.u16);
loc_8B0B21D8:
	// clrlwi r9,r4,16
	ctx.r9.u64 = ctx.r4.u32 & 0xFFFF;
	// cmplwi cr6,r9,65535
	ctx.cr6.compare<uint32_t>(ctx.r9.u32, 65535, ctx.xer);
	// beq cr6,0x8b0b21f0
	if (ctx.cr6.eq) goto loc_8B0B21F0;
	// lwz r10,4(r3)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r3.u32 + 4);
	// rlwinm r11,r9,5,0,26
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r9.u32 | (ctx.r9.u64 << 32), 5) & 0xFFFFFFE0;
	// add r11,r11,r10
	ctx.r11.u64 = ctx.r11.u64 + ctx.r10.u64;
loc_8B0B21F0:
	// lhz r3,4(r11)
	ctx.r3.u64 = REX_LOAD_U16(ctx.r11.u32 + 4);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0B2268) {
	REX_FUNC_PROLOGUE();
	// lis r8,-29938
	ctx.r8.s64 = -1962016768;
	// lis r11,-29938
	ctx.r11.s64 = -1962016768;
	// addi r11,r11,20792
	ctx.r11.s64 = ctx.r11.s64 + 20792;
	// lwz r9,20800(r8)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r8.u32 + 20800);
	// clrlwi r10,r9,31
	ctx.r10.u64 = ctx.r9.u32 & 0x1;
	// cmplwi cr6,r10,0
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 0, ctx.xer);
	// bne cr6,0x8b0b22b0
	if (!ctx.cr6.eq) goto loc_8B0B22B0;
	// ori r9,r9,1
	ctx.r9.u64 = ctx.r9.u64 | 1;
	// lis r10,0
	ctx.r10.s64 = 0;
	// stw r9,20800(r8)
	REX_STORE_U32(ctx.r8.u32 + 20800, ctx.r9.u32);
	// li r9,1
	ctx.r9.s64 = 1;
	// ori r10,r10,65535
	ctx.r10.u64 = ctx.r10.u64 | 65535;
	// sth r9,6(r11)
	REX_STORE_U16(ctx.r11.u32 + 6, ctx.r9.u16);
	// mr r7,r10
	ctx.r7.u64 = ctx.r10.u64;
	// sth r10,0(r11)
	REX_STORE_U16(ctx.r11.u32 + 0, ctx.r10.u16);
	// mr r6,r10
	ctx.r6.u64 = ctx.r10.u64;
	// sth r10,2(r11)
	REX_STORE_U16(ctx.r11.u32 + 2, ctx.r10.u16);
	// sth r10,4(r11)
	REX_STORE_U16(ctx.r11.u32 + 4, ctx.r10.u16);
loc_8B0B22B0:
	// clrlwi r9,r4,16
	ctx.r9.u64 = ctx.r4.u32 & 0xFFFF;
	// cmplwi cr6,r9,65535
	ctx.cr6.compare<uint32_t>(ctx.r9.u32, 65535, ctx.xer);
	// beq cr6,0x8b0b22c8
	if (ctx.cr6.eq) goto loc_8B0B22C8;
	// lwz r10,4(r3)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r3.u32 + 4);
	// rlwinm r11,r9,5,0,26
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r9.u32 | (ctx.r9.u64 << 32), 5) & 0xFFFFFFE0;
	// add r11,r11,r10
	ctx.r11.u64 = ctx.r11.u64 + ctx.r10.u64;
loc_8B0B22C8:
	// lhz r3,2(r11)
	ctx.r3.u64 = REX_LOAD_U16(ctx.r11.u32 + 2);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0B24E8) {
	REX_FUNC_PROLOGUE();
	// lis r8,-29938
	ctx.r8.s64 = -1962016768;
	// lis r10,0
	ctx.r10.s64 = 0;
	// lis r11,-29938
	ctx.r11.s64 = -1962016768;
	// ori r9,r10,65535
	ctx.r9.u64 = ctx.r10.u64 | 65535;
	// addi r11,r11,20792
	ctx.r11.s64 = ctx.r11.s64 + 20792;
	// lwz r10,20800(r8)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r8.u32 + 20800);
	// clrlwi r7,r10,31
	ctx.r7.u64 = ctx.r10.u32 & 0x1;
	// cmplwi cr6,r7,0
	ctx.cr6.compare<uint32_t>(ctx.r7.u32, 0, ctx.xer);
	// bne cr6,0x8b0b2530
	if (!ctx.cr6.eq) goto loc_8B0B2530;
	// ori r10,r10,1
	ctx.r10.u64 = ctx.r10.u64 | 1;
	// sth r9,0(r11)
	REX_STORE_U16(ctx.r11.u32 + 0, ctx.r9.u16);
	// li r5,1
	ctx.r5.s64 = 1;
	// sth r9,2(r11)
	REX_STORE_U16(ctx.r11.u32 + 2, ctx.r9.u16);
	// mr r7,r9
	ctx.r7.u64 = ctx.r9.u64;
	// stw r10,20800(r8)
	REX_STORE_U32(ctx.r8.u32 + 20800, ctx.r10.u32);
	// mr r6,r9
	ctx.r6.u64 = ctx.r9.u64;
	// sth r9,4(r11)
	REX_STORE_U16(ctx.r11.u32 + 4, ctx.r9.u16);
	// sth r5,6(r11)
	REX_STORE_U16(ctx.r11.u32 + 6, ctx.r5.u16);
loc_8B0B2530:
	// clrlwi r4,r4,16
	ctx.r4.u64 = ctx.r4.u32 & 0xFFFF;
	// cmplwi cr6,r4,65535
	ctx.cr6.compare<uint32_t>(ctx.r4.u32, 65535, ctx.xer);
	// beq cr6,0x8b0b254c
	if (ctx.cr6.eq) goto loc_8B0B254C;
	// lwz r6,4(r3)
	ctx.r6.u64 = REX_LOAD_U32(ctx.r3.u32 + 4);
	// rlwinm r7,r4,5,0,26
	ctx.r7.u64 = __builtin_rotateleft64(ctx.r4.u32 | (ctx.r4.u64 << 32), 5) & 0xFFFFFFE0;
	// add r7,r7,r6
	ctx.r7.u64 = ctx.r7.u64 + ctx.r6.u64;
	// b 0x8b0b2550
	goto loc_8B0B2550;
loc_8B0B254C:
	// mr r7,r11
	ctx.r7.u64 = ctx.r11.u64;
loc_8B0B2550:
	// clrlwi r6,r10,31
	ctx.r6.u64 = ctx.r10.u32 & 0x1;
	// lhz r5,4(r7)
	ctx.r5.u64 = REX_LOAD_U16(ctx.r7.u32 + 4);
	// cmplwi cr6,r6,0
	ctx.cr6.compare<uint32_t>(ctx.r6.u32, 0, ctx.xer);
	// bne cr6,0x8b0b2584
	if (!ctx.cr6.eq) goto loc_8B0B2584;
	// ori r10,r10,1
	ctx.r10.u64 = ctx.r10.u64 | 1;
	// sth r9,0(r11)
	REX_STORE_U16(ctx.r11.u32 + 0, ctx.r9.u16);
	// mr r7,r9
	ctx.r7.u64 = ctx.r9.u64;
	// sth r9,2(r11)
	REX_STORE_U16(ctx.r11.u32 + 2, ctx.r9.u16);
	// stw r10,20800(r8)
	REX_STORE_U32(ctx.r8.u32 + 20800, ctx.r10.u32);
	// li r10,1
	ctx.r10.s64 = 1;
	// mr r6,r9
	ctx.r6.u64 = ctx.r9.u64;
	// sth r9,4(r11)
	REX_STORE_U16(ctx.r11.u32 + 4, ctx.r9.u16);
	// sth r10,6(r11)
	REX_STORE_U16(ctx.r11.u32 + 6, ctx.r10.u16);
loc_8B0B2584:
	// clrlwi r9,r5,16
	ctx.r9.u64 = ctx.r5.u32 & 0xFFFF;
	// cmplwi cr6,r9,65535
	ctx.cr6.compare<uint32_t>(ctx.r9.u32, 65535, ctx.xer);
	// beq cr6,0x8b0b259c
	if (ctx.cr6.eq) goto loc_8B0B259C;
	// lwz r10,4(r3)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r3.u32 + 4);
	// rlwinm r11,r9,5,0,26
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r9.u32 | (ctx.r9.u64 << 32), 5) & 0xFFFFFFE0;
	// add r11,r11,r10
	ctx.r11.u64 = ctx.r11.u64 + ctx.r10.u64;
loc_8B0B259C:
	// lhz r11,0(r11)
	ctx.r11.u64 = REX_LOAD_U16(ctx.r11.u32 + 0);
	// subf r10,r11,r4
	ctx.r10.u64 = ctx.r4.u64 - ctx.r11.u64;
	// cntlzw r9,r10
	ctx.r9.u64 = ctx.r10.u32 == 0 ? 32 : __builtin_clz(ctx.r10.u32);
	// rlwinm r3,r9,27,31,31
	ctx.r3.u64 = __builtin_rotateleft64(ctx.r9.u32 | (ctx.r9.u64 << 32), 27) & 0x1;
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0B29E8) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9b0
	ctx.lr = 0x8B0B29F0;
	__savegprlr_26(ctx, base);
	// stwu r1,-144(r1)
	ea = -144 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lis r8,-29938
	ctx.r8.s64 = -1962016768;
	// lis r10,0
	ctx.r10.s64 = 0;
	// lis r11,-29938
	ctx.r11.s64 = -1962016768;
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// mr r29,r4
	ctx.r29.u64 = ctx.r4.u64;
	// lwz r9,20800(r8)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r8.u32 + 20800);
	// ori r10,r10,65535
	ctx.r10.u64 = ctx.r10.u64 | 65535;
	// addi r11,r11,20792
	ctx.r11.s64 = ctx.r11.s64 + 20792;
	// clrlwi r7,r9,31
	ctx.r7.u64 = ctx.r9.u32 & 0x1;
	// cmplwi cr6,r7,0
	ctx.cr6.compare<uint32_t>(ctx.r7.u32, 0, ctx.xer);
	// bne cr6,0x8b0b2a44
	if (!ctx.cr6.eq) goto loc_8B0B2A44;
	// ori r9,r9,1
	ctx.r9.u64 = ctx.r9.u64 | 1;
	// sth r10,0(r11)
	REX_STORE_U16(ctx.r11.u32 + 0, ctx.r10.u16);
	// li r5,1
	ctx.r5.s64 = 1;
	// sth r10,2(r11)
	REX_STORE_U16(ctx.r11.u32 + 2, ctx.r10.u16);
	// mr r7,r10
	ctx.r7.u64 = ctx.r10.u64;
	// stw r9,20800(r8)
	REX_STORE_U32(ctx.r8.u32 + 20800, ctx.r9.u32);
	// mr r6,r10
	ctx.r6.u64 = ctx.r10.u64;
	// sth r10,4(r11)
	REX_STORE_U16(ctx.r11.u32 + 4, ctx.r10.u16);
	// sth r5,6(r11)
	REX_STORE_U16(ctx.r11.u32 + 6, ctx.r5.u16);
loc_8B0B2A44:
	// clrlwi r26,r29,16
	ctx.r26.u64 = ctx.r29.u32 & 0xFFFF;
	// cmplwi cr6,r26,65535
	ctx.cr6.compare<uint32_t>(ctx.r26.u32, 65535, ctx.xer);
	// beq cr6,0x8b0b2a60
	if (ctx.cr6.eq) goto loc_8B0B2A60;
	// lwz r7,4(r31)
	ctx.r7.u64 = REX_LOAD_U32(ctx.r31.u32 + 4);
	// rlwinm r6,r26,5,0,26
	ctx.r6.u64 = __builtin_rotateleft64(ctx.r26.u32 | (ctx.r26.u64 << 32), 5) & 0xFFFFFFE0;
	// add r7,r6,r7
	ctx.r7.u64 = ctx.r6.u64 + ctx.r7.u64;
	// b 0x8b0b2a64
	goto loc_8B0B2A64;
loc_8B0B2A60:
	// mr r7,r11
	ctx.r7.u64 = ctx.r11.u64;
loc_8B0B2A64:
	// clrlwi r6,r9,31
	ctx.r6.u64 = ctx.r9.u32 & 0x1;
	// lhz r27,0(r7)
	ctx.r27.u64 = REX_LOAD_U16(ctx.r7.u32 + 0);
	// cmplwi cr6,r6,0
	ctx.cr6.compare<uint32_t>(ctx.r6.u32, 0, ctx.xer);
	// bne cr6,0x8b0b2a98
	if (!ctx.cr6.eq) goto loc_8B0B2A98;
	// ori r9,r9,1
	ctx.r9.u64 = ctx.r9.u64 | 1;
	// sth r10,0(r11)
	REX_STORE_U16(ctx.r11.u32 + 0, ctx.r10.u16);
	// li r6,1
	ctx.r6.s64 = 1;
	// sth r10,2(r11)
	REX_STORE_U16(ctx.r11.u32 + 2, ctx.r10.u16);
	// stw r9,20800(r8)
	REX_STORE_U32(ctx.r8.u32 + 20800, ctx.r9.u32);
	// mr r7,r10
	ctx.r7.u64 = ctx.r10.u64;
	// mr r9,r10
	ctx.r9.u64 = ctx.r10.u64;
	// sth r6,6(r11)
	REX_STORE_U16(ctx.r11.u32 + 6, ctx.r6.u16);
	// sth r10,4(r11)
	REX_STORE_U16(ctx.r11.u32 + 4, ctx.r10.u16);
loc_8B0B2A98:
	// clrlwi r30,r27,16
	ctx.r30.u64 = ctx.r27.u32 & 0xFFFF;
	// cmplwi cr6,r30,65535
	ctx.cr6.compare<uint32_t>(ctx.r30.u32, 65535, ctx.xer);
	// beq cr6,0x8b0b2ab4
	if (ctx.cr6.eq) goto loc_8B0B2AB4;
	// lwz r7,4(r31)
	ctx.r7.u64 = REX_LOAD_U32(ctx.r31.u32 + 4);
	// rlwinm r9,r30,5,0,26
	ctx.r9.u64 = __builtin_rotateleft64(ctx.r30.u32 | (ctx.r30.u64 << 32), 5) & 0xFFFFFFE0;
	// add r9,r9,r7
	ctx.r9.u64 = ctx.r9.u64 + ctx.r7.u64;
	// b 0x8b0b2ab8
	goto loc_8B0B2AB8;
loc_8B0B2AB4:
	// mr r9,r11
	ctx.r9.u64 = ctx.r11.u64;
loc_8B0B2AB8:
	// lhz r9,2(r9)
	ctx.r9.u64 = REX_LOAD_U16(ctx.r9.u32 + 2);
	// rlwinm r28,r26,5,0,26
	ctx.r28.u64 = __builtin_rotateleft64(ctx.r26.u32 | (ctx.r26.u64 << 32), 5) & 0xFFFFFFE0;
	// lwz r7,4(r31)
	ctx.r7.u64 = REX_LOAD_U32(ctx.r31.u32 + 4);
	// sthx r9,r7,r28
	REX_STORE_U16(ctx.r7.u32 + ctx.r28.u32, ctx.r9.u16);
	// lwz r9,20800(r8)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r8.u32 + 20800);
	// clrlwi r6,r9,31
	ctx.r6.u64 = ctx.r9.u32 & 0x1;
	// cmplwi cr6,r6,0
	ctx.cr6.compare<uint32_t>(ctx.r6.u32, 0, ctx.xer);
	// bne cr6,0x8b0b2afc
	if (!ctx.cr6.eq) goto loc_8B0B2AFC;
	// ori r9,r9,1
	ctx.r9.u64 = ctx.r9.u64 | 1;
	// sth r10,0(r11)
	REX_STORE_U16(ctx.r11.u32 + 0, ctx.r10.u16);
	// mr r7,r10
	ctx.r7.u64 = ctx.r10.u64;
	// sth r10,2(r11)
	REX_STORE_U16(ctx.r11.u32 + 2, ctx.r10.u16);
	// stw r9,20800(r8)
	REX_STORE_U32(ctx.r8.u32 + 20800, ctx.r9.u32);
	// li r9,1
	ctx.r9.s64 = 1;
	// mr r6,r10
	ctx.r6.u64 = ctx.r10.u64;
	// sth r10,4(r11)
	REX_STORE_U16(ctx.r11.u32 + 4, ctx.r10.u16);
	// sth r9,6(r11)
	REX_STORE_U16(ctx.r11.u32 + 6, ctx.r9.u16);
loc_8B0B2AFC:
	// cmplwi cr6,r30,65535
	ctx.cr6.compare<uint32_t>(ctx.r30.u32, 65535, ctx.xer);
	// beq cr6,0x8b0b2b10
	if (ctx.cr6.eq) goto loc_8B0B2B10;
	// lwz r10,4(r31)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r31.u32 + 4);
	// rlwinm r11,r30,5,0,26
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r30.u32 | (ctx.r30.u64 << 32), 5) & 0xFFFFFFE0;
	// add r11,r11,r10
	ctx.r11.u64 = ctx.r11.u64 + ctx.r10.u64;
loc_8B0B2B10:
	// lhz r11,2(r11)
	ctx.r11.u64 = REX_LOAD_U16(ctx.r11.u32 + 2);
	// cmplwi cr6,r11,65535
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 65535, ctx.xer);
	// beq cr6,0x8b0b2b38
	if (ctx.cr6.eq) goto loc_8B0B2B38;
	// mr r4,r27
	ctx.r4.u64 = ctx.r27.u64;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0b2268
	ctx.lr = 0x8B0B2B28;
	sub_8B0B2268(ctx, base);
	// lwz r10,4(r31)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r31.u32 + 4);
	// rlwinm r11,r3,5,11,26
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r3.u32 | (ctx.r3.u64 << 32), 5) & 0x1FFFE0;
	// add r11,r11,r10
	ctx.r11.u64 = ctx.r11.u64 + ctx.r10.u64;
	// sth r29,4(r11)
	REX_STORE_U16(ctx.r11.u32 + 4, ctx.r29.u16);
loc_8B0B2B38:
	// cmplwi cr6,r30,65535
	ctx.cr6.compare<uint32_t>(ctx.r30.u32, 65535, ctx.xer);
	// beq cr6,0x8b0b2b5c
	if (ctx.cr6.eq) goto loc_8B0B2B5C;
	// mr r4,r29
	ctx.r4.u64 = ctx.r29.u64;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0b2190
	ctx.lr = 0x8B0B2B4C;
	sub_8B0B2190(ctx, base);
	// lwz r10,4(r31)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r31.u32 + 4);
	// rlwinm r11,r30,5,0,26
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r30.u32 | (ctx.r30.u64 << 32), 5) & 0xFFFFFFE0;
	// add r11,r11,r10
	ctx.r11.u64 = ctx.r11.u64 + ctx.r10.u64;
	// sth r3,4(r11)
	REX_STORE_U16(ctx.r11.u32 + 4, ctx.r3.u16);
loc_8B0B2B5C:
	// lhz r11,16(r31)
	ctx.r11.u64 = REX_LOAD_U16(ctx.r31.u32 + 16);
	// cmplw cr6,r26,r11
	ctx.cr6.compare<uint32_t>(ctx.r26.u32, ctx.r11.u32, ctx.xer);
	// beq cr6,0x8b0b2bb4
	if (ctx.cr6.eq) goto loc_8B0B2BB4;
	// mr r4,r29
	ctx.r4.u64 = ctx.r29.u64;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0b22d0
	ctx.lr = 0x8B0B2B74;
	sub_8B0B22D0(ctx, base);
	// clrlwi r11,r3,24
	ctx.r11.u64 = ctx.r3.u32 & 0xFF;
	// mr r4,r29
	ctx.r4.u64 = ctx.r29.u64;
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// beq cr6,0x8b0b2ba0
	if (ctx.cr6.eq) goto loc_8B0B2BA0;
	// bl 0x8b0b2190
	ctx.lr = 0x8B0B2B8C;
	sub_8B0B2190(ctx, base);
	// lwz r10,4(r31)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r31.u32 + 4);
	// rlwinm r11,r3,5,11,26
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r3.u32 | (ctx.r3.u64 << 32), 5) & 0x1FFFE0;
	// add r11,r11,r10
	ctx.r11.u64 = ctx.r11.u64 + ctx.r10.u64;
	// sth r27,2(r11)
	REX_STORE_U16(ctx.r11.u32 + 2, ctx.r27.u16);
	// b 0x8b0b2bb8
	goto loc_8B0B2BB8;
loc_8B0B2BA0:
	// bl 0x8b0b2190
	ctx.lr = 0x8B0B2BA4;
	sub_8B0B2190(ctx, base);
	// lwz r11,4(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 4);
	// rlwinm r10,r3,5,11,26
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r3.u32 | (ctx.r3.u64 << 32), 5) & 0x1FFFE0;
	// sthx r27,r10,r11
	REX_STORE_U16(ctx.r10.u32 + ctx.r11.u32, ctx.r27.u16);
	// b 0x8b0b2bb8
	goto loc_8B0B2BB8;
loc_8B0B2BB4:
	// sth r27,16(r31)
	REX_STORE_U16(ctx.r31.u32 + 16, ctx.r27.u16);
loc_8B0B2BB8:
	// lwz r10,4(r31)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r31.u32 + 4);
	// rlwinm r11,r30,5,0,26
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r30.u32 | (ctx.r30.u64 << 32), 5) & 0xFFFFFFE0;
	// cmplwi cr6,r26,65535
	ctx.cr6.compare<uint32_t>(ctx.r26.u32, 65535, ctx.xer);
	// add r11,r11,r10
	ctx.r11.u64 = ctx.r11.u64 + ctx.r10.u64;
	// sth r29,2(r11)
	REX_STORE_U16(ctx.r11.u32 + 2, ctx.r29.u16);
	// beq cr6,0x8b0b2bdc
	if (ctx.cr6.eq) goto loc_8B0B2BDC;
	// lwz r11,4(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 4);
	// add r11,r11,r28
	ctx.r11.u64 = ctx.r11.u64 + ctx.r28.u64;
	// sth r27,4(r11)
	REX_STORE_U16(ctx.r11.u32 + 4, ctx.r27.u16);
loc_8B0B2BDC:
	// addi r1,r1,144
	ctx.r1.s64 = ctx.r1.s64 + 144;
	// b 0x8b0cba00
	__restgprlr_26(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0B3728) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// std r31,-16(r1)
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.r31.u64);
	// stwu r1,-96(r1)
	ea = -96 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lis r11,0
	ctx.r11.s64 = 0;
	// rlwinm r9,r4,5,11,26
	ctx.r9.u64 = __builtin_rotateleft64(ctx.r4.u32 | (ctx.r4.u64 << 32), 5) & 0x1FFFE0;
	// ori r11,r11,65535
	ctx.r11.u64 = ctx.r11.u64 | 65535;
	// li r8,0
	ctx.r8.s64 = 0;
	// mr r31,r11
	ctx.r31.u64 = ctx.r11.u64;
	// mr r7,r11
	ctx.r7.u64 = ctx.r11.u64;
	// lwz r11,4(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 4);
	// clrlwi r10,r5,16
	ctx.r10.u64 = ctx.r5.u32 & 0xFFFF;
	// add r11,r9,r11
	ctx.r11.u64 = ctx.r9.u64 + ctx.r11.u64;
	// cmplwi cr6,r10,65535
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 65535, ctx.xer);
	// sth r5,4(r11)
	REX_STORE_U16(ctx.r11.u32 + 4, ctx.r5.u16);
	// sth r31,2(r11)
	REX_STORE_U16(ctx.r11.u32 + 2, ctx.r31.u16);
	// sth r31,0(r11)
	REX_STORE_U16(ctx.r11.u32 + 0, ctx.r31.u16);
	// sth r8,6(r11)
	REX_STORE_U16(ctx.r11.u32 + 6, ctx.r8.u16);
	// beq cr6,0x8b0b37a4
	if (ctx.cr6.eq) goto loc_8B0B37A4;
	// clrlwi r11,r6,24
	ctx.r11.u64 = ctx.r6.u32 & 0xFF;
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// beq cr6,0x8b0b3790
	if (ctx.cr6.eq) goto loc_8B0B3790;
	// lwz r11,4(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 4);
	// rlwinm r10,r10,5,0,26
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r10.u32 | (ctx.r10.u64 << 32), 5) & 0xFFFFFFE0;
	// sthx r4,r10,r11
	REX_STORE_U16(ctx.r10.u32 + ctx.r11.u32, ctx.r4.u16);
	// b 0x8b0b37a8
	goto loc_8B0B37A8;
loc_8B0B3790:
	// lwz r9,4(r3)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r3.u32 + 4);
	// rlwinm r11,r10,5,0,26
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r10.u32 | (ctx.r10.u64 << 32), 5) & 0xFFFFFFE0;
	// add r11,r11,r9
	ctx.r11.u64 = ctx.r11.u64 + ctx.r9.u64;
	// sth r4,2(r11)
	REX_STORE_U16(ctx.r11.u32 + 2, ctx.r4.u16);
	// b 0x8b0b37a8
	goto loc_8B0B37A8;
loc_8B0B37A4:
	// sth r4,16(r3)
	REX_STORE_U16(ctx.r3.u32 + 16, ctx.r4.u16);
loc_8B0B37A8:
	// bl 0x8b0b2be8
	ctx.lr = 0x8B0B37AC;
	sub_8B0B2BE8(ctx, base);
	// addi r1,r1,96
	ctx.r1.s64 = ctx.r1.s64 + 96;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0B4508) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// std r31,-16(r1)
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.r31.u64);
	// stwu r1,-112(r1)
	ea = -112 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// addi r9,r11,29660
	ctx.r9.s64 = ctx.r11.s64 + 29660;
	// addi r8,r10,29652
	ctx.r8.s64 = ctx.r10.s64 + 29652;
	// stw r9,0(r3)
	REX_STORE_U32(ctx.r3.u32 + 0, ctx.r9.u32);
	// mr r3,r4
	ctx.r3.u64 = ctx.r4.u64;
	// stw r8,4(r31)
	REX_STORE_U32(ctx.r31.u32 + 4, ctx.r8.u32);
	// bl 0x8b0c0298
	ctx.lr = 0x8B0B453C;
	sub_8B0C0298(ctx, base);
	// li r11,0
	ctx.r11.s64 = 0;
	// stw r3,8(r31)
	REX_STORE_U32(ctx.r31.u32 + 8, ctx.r3.u32);
	// lis r7,-29944
	ctx.r7.s64 = -1962409984;
	// stw r3,12(r31)
	REX_STORE_U32(ctx.r31.u32 + 12, ctx.r3.u32);
	// stw r11,16(r31)
	REX_STORE_U32(ctx.r31.u32 + 16, ctx.r11.u32);
	// addi r3,r7,29612
	ctx.r3.s64 = ctx.r7.s64 + 29612;
	// stw r11,20(r31)
	REX_STORE_U32(ctx.r31.u32 + 20, ctx.r11.u32);
	// stw r11,24(r31)
	REX_STORE_U32(ctx.r31.u32 + 24, ctx.r11.u32);
	// stw r11,28(r31)
	REX_STORE_U32(ctx.r31.u32 + 28, ctx.r11.u32);
	// stw r11,32(r31)
	REX_STORE_U32(ctx.r31.u32 + 32, ctx.r11.u32);
	// stw r11,36(r31)
	REX_STORE_U32(ctx.r31.u32 + 36, ctx.r11.u32);
	// stw r11,40(r31)
	REX_STORE_U32(ctx.r31.u32 + 40, ctx.r11.u32);
	// bl 0x8b0df298
	ctx.lr = 0x8B0B4570;
	sub_8B0DF298(ctx, base);
	// lis r6,-29944
	ctx.r6.s64 = -1962409984;
	// li r5,1
	ctx.r5.s64 = 1;
	// lwz r3,8(r31)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r31.u32 + 8);
	// addi r4,r6,1800
	ctx.r4.s64 = ctx.r6.s64 + 1800;
	// stw r5,84(r1)
	REX_STORE_U32(ctx.r1.u32 + 84, ctx.r5.u32);
	// stw r4,80(r1)
	REX_STORE_U32(ctx.r1.u32 + 80, ctx.r4.u32);
	// addi r4,r1,80
	ctx.r4.s64 = ctx.r1.s64 + 80;
	// bl 0x8b0bf510
	ctx.lr = 0x8B0B4590;
	sub_8B0BF510(ctx, base);
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// addi r1,r1,112
	ctx.r1.s64 = ctx.r1.s64 + 112;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0B46A0) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9a8
	ctx.lr = 0x8B0B46A8;
	__savegprlr_24(ctx, base);
	// stwu r1,-160(r1)
	ea = -160 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// clrlwi r24,r4,16
	ctx.r24.u64 = ctx.r4.u32 & 0xFFFF;
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// mr r25,r4
	ctx.r25.u64 = ctx.r4.u64;
	// cmplwi cr6,r24,65535
	ctx.cr6.compare<uint32_t>(ctx.r24.u32, 65535, ctx.xer);
	// beq cr6,0x8b0b49e0
	if (ctx.cr6.eq) goto loc_8B0B49E0;
	// bl 0x8b0b21f8
	ctx.lr = 0x8B0B46C4;
	sub_8B0B21F8(ctx, base);
	// clrlwi r11,r3,16
	ctx.r11.u64 = ctx.r3.u32 & 0xFFFF;
	// cmplwi cr6,r11,65535
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 65535, ctx.xer);
	// beq cr6,0x8b0b47c4
	if (ctx.cr6.eq) goto loc_8B0B47C4;
	// mr r4,r25
	ctx.r4.u64 = ctx.r25.u64;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0b2268
	ctx.lr = 0x8B0B46DC;
	sub_8B0B2268(ctx, base);
	// clrlwi r11,r3,16
	ctx.r11.u64 = ctx.r3.u32 & 0xFFFF;
	// cmplwi cr6,r11,65535
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 65535, ctx.xer);
	// beq cr6,0x8b0b47c4
	if (ctx.cr6.eq) goto loc_8B0B47C4;
	// mr r4,r25
	ctx.r4.u64 = ctx.r25.u64;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0b2268
	ctx.lr = 0x8B0B46F4;
	sub_8B0B2268(ctx, base);
	// lis r4,-29938
	ctx.r4.s64 = -1962016768;
	// lis r10,0
	ctx.r10.s64 = 0;
	// lis r11,-29938
	ctx.r11.s64 = -1962016768;
	// ori r9,r10,65535
	ctx.r9.u64 = ctx.r10.u64 | 65535;
	// mr r30,r3
	ctx.r30.u64 = ctx.r3.u64;
	// lwz r10,20800(r4)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r4.u32 + 20800);
	// addi r11,r11,20792
	ctx.r11.s64 = ctx.r11.s64 + 20792;
loc_8B0B4710:
	// clrlwi r8,r10,31
	ctx.r8.u64 = ctx.r10.u32 & 0x1;
	// cmplwi cr6,r8,0
	ctx.cr6.compare<uint32_t>(ctx.r8.u32, 0, ctx.xer);
	// bne cr6,0x8b0b4740
	if (!ctx.cr6.eq) goto loc_8B0B4740;
	// ori r10,r10,1
	ctx.r10.u64 = ctx.r10.u64 | 1;
	// sth r9,0(r11)
	REX_STORE_U16(ctx.r11.u32 + 0, ctx.r9.u16);
	// li r6,1
	ctx.r6.s64 = 1;
	// sth r9,2(r11)
	REX_STORE_U16(ctx.r11.u32 + 2, ctx.r9.u16);
	// mr r8,r9
	ctx.r8.u64 = ctx.r9.u64;
	// stw r10,20800(r4)
	REX_STORE_U32(ctx.r4.u32 + 20800, ctx.r10.u32);
	// mr r7,r9
	ctx.r7.u64 = ctx.r9.u64;
	// sth r9,4(r11)
	REX_STORE_U16(ctx.r11.u32 + 4, ctx.r9.u16);
	// sth r6,6(r11)
	REX_STORE_U16(ctx.r11.u32 + 6, ctx.r6.u16);
loc_8B0B4740:
	// clrlwi r5,r30,16
	ctx.r5.u64 = ctx.r30.u32 & 0xFFFF;
	// cmplwi cr6,r5,65535
	ctx.cr6.compare<uint32_t>(ctx.r5.u32, 65535, ctx.xer);
	// beq cr6,0x8b0b475c
	if (ctx.cr6.eq) goto loc_8B0B475C;
	// lwz r8,4(r31)
	ctx.r8.u64 = REX_LOAD_U32(ctx.r31.u32 + 4);
	// rlwinm r7,r5,5,0,26
	ctx.r7.u64 = __builtin_rotateleft64(ctx.r5.u32 | (ctx.r5.u64 << 32), 5) & 0xFFFFFFE0;
	// add r8,r7,r8
	ctx.r8.u64 = ctx.r7.u64 + ctx.r8.u64;
	// b 0x8b0b4760
	goto loc_8B0B4760;
loc_8B0B475C:
	// mr r8,r11
	ctx.r8.u64 = ctx.r11.u64;
loc_8B0B4760:
	// lhz r8,0(r8)
	ctx.r8.u64 = REX_LOAD_U16(ctx.r8.u32 + 0);
	// cmplwi cr6,r8,65535
	ctx.cr6.compare<uint32_t>(ctx.r8.u32, 65535, ctx.xer);
	// beq cr6,0x8b0b47c8
	if (ctx.cr6.eq) goto loc_8B0B47C8;
	// clrlwi r8,r10,31
	ctx.r8.u64 = ctx.r10.u32 & 0x1;
	// cmplwi cr6,r8,0
	ctx.cr6.compare<uint32_t>(ctx.r8.u32, 0, ctx.xer);
	// bne cr6,0x8b0b479c
	if (!ctx.cr6.eq) goto loc_8B0B479C;
	// ori r10,r10,1
	ctx.r10.u64 = ctx.r10.u64 | 1;
	// sth r9,0(r11)
	REX_STORE_U16(ctx.r11.u32 + 0, ctx.r9.u16);
	// li r6,1
	ctx.r6.s64 = 1;
	// sth r9,2(r11)
	REX_STORE_U16(ctx.r11.u32 + 2, ctx.r9.u16);
	// mr r8,r9
	ctx.r8.u64 = ctx.r9.u64;
	// stw r10,20800(r4)
	REX_STORE_U32(ctx.r4.u32 + 20800, ctx.r10.u32);
	// mr r7,r9
	ctx.r7.u64 = ctx.r9.u64;
	// sth r9,4(r11)
	REX_STORE_U16(ctx.r11.u32 + 4, ctx.r9.u16);
	// sth r6,6(r11)
	REX_STORE_U16(ctx.r11.u32 + 6, ctx.r6.u16);
loc_8B0B479C:
	// cmplwi cr6,r5,65535
	ctx.cr6.compare<uint32_t>(ctx.r5.u32, 65535, ctx.xer);
	// beq cr6,0x8b0b47b8
	if (ctx.cr6.eq) goto loc_8B0B47B8;
	// lwz r8,4(r31)
	ctx.r8.u64 = REX_LOAD_U32(ctx.r31.u32 + 4);
	// rlwinm r7,r5,5,0,26
	ctx.r7.u64 = __builtin_rotateleft64(ctx.r5.u32 | (ctx.r5.u64 << 32), 5) & 0xFFFFFFE0;
	// add r8,r7,r8
	ctx.r8.u64 = ctx.r7.u64 + ctx.r8.u64;
	// lhz r30,0(r8)
	ctx.r30.u64 = REX_LOAD_U16(ctx.r8.u32 + 0);
	// b 0x8b0b4710
	goto loc_8B0B4710;
loc_8B0B47B8:
	// lhz r30,0(r11)
	ctx.r30.u64 = REX_LOAD_U16(ctx.r11.u32 + 0);
	// mr r8,r11
	ctx.r8.u64 = ctx.r11.u64;
	// b 0x8b0b4710
	goto loc_8B0B4710;
loc_8B0B47C4:
	// mr r30,r25
	ctx.r30.u64 = ctx.r25.u64;
loc_8B0B47C8:
	// mr r4,r30
	ctx.r4.u64 = ctx.r30.u64;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0b21f8
	ctx.lr = 0x8B0B47D4;
	sub_8B0B21F8(ctx, base);
	// clrlwi r11,r3,16
	ctx.r11.u64 = ctx.r3.u32 & 0xFFFF;
	// mr r4,r30
	ctx.r4.u64 = ctx.r30.u64;
	// cmplwi cr6,r11,65535
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 65535, ctx.xer);
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// beq cr6,0x8b0b47f0
	if (ctx.cr6.eq) goto loc_8B0B47F0;
	// bl 0x8b0b21f8
	ctx.lr = 0x8B0B47EC;
	sub_8B0B21F8(ctx, base);
	// b 0x8b0b47f4
	goto loc_8B0B47F4;
loc_8B0B47F0:
	// bl 0x8b0b2268
	ctx.lr = 0x8B0B47F4;
	sub_8B0B2268(ctx, base);
loc_8B0B47F4:
	// clrlwi r26,r3,16
	ctx.r26.u64 = ctx.r3.u32 & 0xFFFF;
	// mr r27,r3
	ctx.r27.u64 = ctx.r3.u64;
	// cmplwi cr6,r26,65535
	ctx.cr6.compare<uint32_t>(ctx.r26.u32, 65535, ctx.xer);
	// beq cr6,0x8b0b4820
	if (ctx.cr6.eq) goto loc_8B0B4820;
	// mr r4,r30
	ctx.r4.u64 = ctx.r30.u64;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0b2190
	ctx.lr = 0x8B0B4810;
	sub_8B0B2190(ctx, base);
	// lwz r11,4(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 4);
	// rlwinm r10,r26,5,0,26
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r26.u32 | (ctx.r26.u64 << 32), 5) & 0xFFFFFFE0;
	// add r11,r10,r11
	ctx.r11.u64 = ctx.r10.u64 + ctx.r11.u64;
	// sth r3,4(r11)
	REX_STORE_U16(ctx.r11.u32 + 4, ctx.r3.u16);
loc_8B0B4820:
	// lhz r11,16(r31)
	ctx.r11.u64 = REX_LOAD_U16(ctx.r31.u32 + 16);
	// clrlwi r29,r30,16
	ctx.r29.u64 = ctx.r30.u32 & 0xFFFF;
	// cmplw cr6,r29,r11
	ctx.cr6.compare<uint32_t>(ctx.r29.u32, ctx.r11.u32, ctx.xer);
	// beq cr6,0x8b0b487c
	if (ctx.cr6.eq) goto loc_8B0B487C;
	// mr r4,r30
	ctx.r4.u64 = ctx.r30.u64;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0b24e8
	ctx.lr = 0x8B0B483C;
	sub_8B0B24E8(ctx, base);
	// clrlwi r11,r3,24
	ctx.r11.u64 = ctx.r3.u32 & 0xFF;
	// mr r4,r30
	ctx.r4.u64 = ctx.r30.u64;
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// beq cr6,0x8b0b4864
	if (ctx.cr6.eq) goto loc_8B0B4864;
	// bl 0x8b0b2190
	ctx.lr = 0x8B0B4854;
	sub_8B0B2190(ctx, base);
	// lwz r11,4(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 4);
	// rlwinm r10,r3,5,11,26
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r3.u32 | (ctx.r3.u64 << 32), 5) & 0x1FFFE0;
	// sthx r27,r10,r11
	REX_STORE_U16(ctx.r10.u32 + ctx.r11.u32, ctx.r27.u16);
	// b 0x8b0b4880
	goto loc_8B0B4880;
loc_8B0B4864:
	// bl 0x8b0b2190
	ctx.lr = 0x8B0B4868;
	sub_8B0B2190(ctx, base);
	// lwz r11,4(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 4);
	// rlwinm r10,r3,5,11,26
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r3.u32 | (ctx.r3.u64 << 32), 5) & 0x1FFFE0;
	// add r11,r10,r11
	ctx.r11.u64 = ctx.r10.u64 + ctx.r11.u64;
	// sth r27,2(r11)
	REX_STORE_U16(ctx.r11.u32 + 2, ctx.r27.u16);
	// b 0x8b0b4880
	goto loc_8B0B4880;
loc_8B0B487C:
	// sth r27,16(r31)
	REX_STORE_U16(ctx.r31.u32 + 16, ctx.r27.u16);
loc_8B0B4880:
	// mr r4,r30
	ctx.r4.u64 = ctx.r30.u64;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0b1f50
	ctx.lr = 0x8B0B488C;
	sub_8B0B1F50(ctx, base);
	// mr r28,r3
	ctx.r28.u64 = ctx.r3.u64;
	// cmplw cr6,r29,r24
	ctx.cr6.compare<uint32_t>(ctx.r29.u32, ctx.r24.u32, ctx.xer);
	// beq cr6,0x8b0b49c4
	if (ctx.cr6.eq) goto loc_8B0B49C4;
	// mr r4,r25
	ctx.r4.u64 = ctx.r25.u64;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0b2190
	ctx.lr = 0x8B0B48A4;
	sub_8B0B2190(ctx, base);
	// lwz r11,4(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 4);
	// rlwinm r29,r29,5,0,26
	ctx.r29.u64 = __builtin_rotateleft64(ctx.r29.u32 | (ctx.r29.u64 << 32), 5) & 0xFFFFFFE0;
	// mr r10,r3
	ctx.r10.u64 = ctx.r3.u64;
	// add r9,r29,r11
	ctx.r9.u64 = ctx.r29.u64 + ctx.r11.u64;
	// mr r4,r25
	ctx.r4.u64 = ctx.r25.u64;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// sth r10,4(r9)
	REX_STORE_U16(ctx.r9.u32 + 4, ctx.r10.u16);
	// bl 0x8b0b2268
	ctx.lr = 0x8B0B48C4;
	sub_8B0B2268(ctx, base);
	// lwz r11,4(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 4);
	// mr r8,r3
	ctx.r8.u64 = ctx.r3.u64;
	// add r7,r29,r11
	ctx.r7.u64 = ctx.r29.u64 + ctx.r11.u64;
	// mr r4,r25
	ctx.r4.u64 = ctx.r25.u64;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// sth r8,2(r7)
	REX_STORE_U16(ctx.r7.u32 + 2, ctx.r8.u16);
	// bl 0x8b0b21f8
	ctx.lr = 0x8B0B48E0;
	sub_8B0B21F8(ctx, base);
	// lwz r6,4(r31)
	ctx.r6.u64 = REX_LOAD_U32(ctx.r31.u32 + 4);
	// sthx r3,r29,r6
	REX_STORE_U16(ctx.r29.u32 + ctx.r6.u32, ctx.r3.u16);
	// lhz r5,16(r31)
	ctx.r5.u64 = REX_LOAD_U16(ctx.r31.u32 + 16);
	// cmplw cr6,r24,r5
	ctx.cr6.compare<uint32_t>(ctx.r24.u32, ctx.r5.u32, ctx.xer);
	// beq cr6,0x8b0b4940
	if (ctx.cr6.eq) goto loc_8B0B4940;
	// mr r4,r25
	ctx.r4.u64 = ctx.r25.u64;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0b24e8
	ctx.lr = 0x8B0B4900;
	sub_8B0B24E8(ctx, base);
	// clrlwi r11,r3,24
	ctx.r11.u64 = ctx.r3.u32 & 0xFF;
	// mr r4,r25
	ctx.r4.u64 = ctx.r25.u64;
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// beq cr6,0x8b0b4928
	if (ctx.cr6.eq) goto loc_8B0B4928;
	// bl 0x8b0b2190
	ctx.lr = 0x8B0B4918;
	sub_8B0B2190(ctx, base);
	// lwz r11,4(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 4);
	// rlwinm r10,r3,5,11,26
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r3.u32 | (ctx.r3.u64 << 32), 5) & 0x1FFFE0;
	// sthx r30,r10,r11
	REX_STORE_U16(ctx.r10.u32 + ctx.r11.u32, ctx.r30.u16);
	// b 0x8b0b4944
	goto loc_8B0B4944;
loc_8B0B4928:
	// bl 0x8b0b2190
	ctx.lr = 0x8B0B492C;
	sub_8B0B2190(ctx, base);
	// lwz r10,4(r31)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r31.u32 + 4);
	// rlwinm r11,r3,5,11,26
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r3.u32 | (ctx.r3.u64 << 32), 5) & 0x1FFFE0;
	// add r11,r11,r10
	ctx.r11.u64 = ctx.r11.u64 + ctx.r10.u64;
	// sth r30,2(r11)
	REX_STORE_U16(ctx.r11.u32 + 2, ctx.r30.u16);
	// b 0x8b0b4944
	goto loc_8B0B4944;
loc_8B0B4940:
	// sth r30,16(r31)
	REX_STORE_U16(ctx.r31.u32 + 16, ctx.r30.u16);
loc_8B0B4944:
	// mr r4,r30
	ctx.r4.u64 = ctx.r30.u64;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0b21f8
	ctx.lr = 0x8B0B4950;
	sub_8B0B21F8(ctx, base);
	// clrlwi r11,r3,16
	ctx.r11.u64 = ctx.r3.u32 & 0xFFFF;
	// cmplwi cr6,r11,65535
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 65535, ctx.xer);
	// beq cr6,0x8b0b4978
	if (ctx.cr6.eq) goto loc_8B0B4978;
	// mr r4,r30
	ctx.r4.u64 = ctx.r30.u64;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0b21f8
	ctx.lr = 0x8B0B4968;
	sub_8B0B21F8(ctx, base);
	// lwz r10,4(r31)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r31.u32 + 4);
	// rlwinm r11,r3,5,11,26
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r3.u32 | (ctx.r3.u64 << 32), 5) & 0x1FFFE0;
	// add r11,r11,r10
	ctx.r11.u64 = ctx.r11.u64 + ctx.r10.u64;
	// sth r30,4(r11)
	REX_STORE_U16(ctx.r11.u32 + 4, ctx.r30.u16);
loc_8B0B4978:
	// mr r4,r30
	ctx.r4.u64 = ctx.r30.u64;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0b2268
	ctx.lr = 0x8B0B4984;
	sub_8B0B2268(ctx, base);
	// clrlwi r11,r3,16
	ctx.r11.u64 = ctx.r3.u32 & 0xFFFF;
	// cmplwi cr6,r11,65535
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 65535, ctx.xer);
	// beq cr6,0x8b0b49ac
	if (ctx.cr6.eq) goto loc_8B0B49AC;
	// mr r4,r30
	ctx.r4.u64 = ctx.r30.u64;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0b2268
	ctx.lr = 0x8B0B499C;
	sub_8B0B2268(ctx, base);
	// lwz r10,4(r31)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r31.u32 + 4);
	// rlwinm r11,r3,5,11,26
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r3.u32 | (ctx.r3.u64 << 32), 5) & 0x1FFFE0;
	// add r11,r11,r10
	ctx.r11.u64 = ctx.r11.u64 + ctx.r10.u64;
	// sth r30,4(r11)
	REX_STORE_U16(ctx.r11.u32 + 4, ctx.r30.u16);
loc_8B0B49AC:
	// mr r4,r25
	ctx.r4.u64 = ctx.r25.u64;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0b1f50
	ctx.lr = 0x8B0B49B8;
	sub_8B0B1F50(ctx, base);
	// lwz r11,4(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 4);
	// add r9,r29,r11
	ctx.r9.u64 = ctx.r29.u64 + ctx.r11.u64;
	// sth r3,6(r9)
	REX_STORE_U16(ctx.r9.u32 + 6, ctx.r3.u16);
loc_8B0B49C4:
	// cmplwi cr6,r26,65535
	ctx.cr6.compare<uint32_t>(ctx.r26.u32, 65535, ctx.xer);
	// beq cr6,0x8b0b49e0
	if (ctx.cr6.eq) goto loc_8B0B49E0;
	// cmpwi cr6,r28,1
	ctx.cr6.compare<int32_t>(ctx.r28.s32, 1, ctx.xer);
	// bne cr6,0x8b0b49e0
	if (!ctx.cr6.eq) goto loc_8B0B49E0;
	// mr r4,r27
	ctx.r4.u64 = ctx.r27.u64;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0b37c0
	ctx.lr = 0x8B0B49E0;
	sub_8B0B37C0(ctx, base);
loc_8B0B49E0:
	// addi r1,r1,160
	ctx.r1.s64 = ctx.r1.s64 + 160;
	// b 0x8b0cb9f8
	__restgprlr_24(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0B5220) {
	REX_FUNC_PROLOGUE();
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lwz r4,24(r3)
	ctx.r4.u64 = REX_LOAD_U32(ctx.r3.u32 + 24);
	// addi r3,r11,29952
	ctx.r3.s64 = ctx.r11.s64 + 29952;
	// b 0x8b0df2a8
	sub_8B0DF2A8(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0B5230) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// std r31,-16(r1)
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.r31.u64);
	// stwu r1,-96(r1)
	ea = -96 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lwz r11,24(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 24);
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// cmpwi cr6,r11,0
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// bne cr6,0x8b0b52d8
	if (!ctx.cr6.eq) goto loc_8B0B52D8;
	// li r11,1
	ctx.r11.s64 = 1;
	// li r3,36
	ctx.r3.s64 = 36;
	// stw r11,24(r31)
	REX_STORE_U32(ctx.r31.u32 + 24, ctx.r11.u32);
	// bl 0x8b0bf448
	ctx.lr = 0x8B0B5260;
	sub_8B0BF448(ctx, base);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0b5298
	if (ctx.cr6.eq) goto loc_8B0B5298;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// addi r6,r11,28164
	ctx.r6.s64 = ctx.r11.s64 + 28164;
	// lis r9,-29944
	ctx.r9.s64 = -1962409984;
	// lis r4,-29944
	ctx.r4.s64 = -1962409984;
	// mr r7,r6
	ctx.r7.u64 = ctx.r6.u64;
	// addi r8,r10,30032
	ctx.r8.s64 = ctx.r10.s64 + 30032;
	// addi r5,r9,4072
	ctx.r5.s64 = ctx.r9.s64 + 4072;
	// addi r4,r4,4080
	ctx.r4.s64 = ctx.r4.s64 + 4080;
	// bl 0x8b0c1438
	ctx.lr = 0x8B0B5290;
	sub_8B0C1438(ctx, base);
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// b 0x8b0b529c
	goto loc_8B0B529C;
loc_8B0B5298:
	// li r4,0
	ctx.r4.s64 = 0;
loc_8B0B529C:
	// lis r11,-29938
	ctx.r11.s64 = -1962016768;
	// lwz r3,4480(r11)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r11.u32 + 4480);
	// lwz r10,0(r3)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r9,8(r10)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r10.u32 + 8);
	// mtctr r9
	ctx.ctr.u64 = ctx.r9.u64;
	// bctrl 
	ctx.lr = 0x8B0B52B4;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// li r3,256
	ctx.r3.s64 = 256;
	// bl 0x8b090000
	ctx.lr = 0x8B0B52BC;
	sub_8B090000(ctx, base);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0b52d0
	if (ctx.cr6.eq) goto loc_8B0B52D0;
	// lwz r4,8(r31)
	ctx.r4.u64 = REX_LOAD_U32(ctx.r31.u32 + 8);
	// bl 0x8b0a2578
	ctx.lr = 0x8B0B52CC;
	sub_8B0A2578(ctx, base);
	// b 0x8b0b52d4
	goto loc_8B0B52D4;
loc_8B0B52D0:
	// li r3,0
	ctx.r3.s64 = 0;
loc_8B0B52D4:
	// stw r3,28(r31)
	REX_STORE_U32(ctx.r31.u32 + 28, ctx.r3.u32);
loc_8B0B52D8:
	// lwz r3,28(r31)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r31.u32 + 28);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0b52f4
	if (ctx.cr6.eq) goto loc_8B0B52F4;
	// lwz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r10,16(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 16);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B0B52F4;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
loc_8B0B52F4:
	// addi r1,r1,96
	ctx.r1.s64 = ctx.r1.s64 + 96;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0B5400) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// std r30,-24(r1)
	REX_STORE_U64(ctx.r1.u32 + -24, ctx.r30.u64);
	// std r31,-16(r1)
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.r31.u64);
	// stwu r1,-896(r1)
	ea = -896 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// lwz r3,8(r3)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r3.u32 + 8);
	// li r11,3
	ctx.r11.s64 = 3;
	// stw r11,24(r31)
	REX_STORE_U32(ctx.r31.u32 + 24, ctx.r11.u32);
	// bl 0x8b098228
	ctx.lr = 0x8B0B5428;
	sub_8B098228(ctx, base);
	// li r30,0
	ctx.r30.s64 = 0;
	// li r5,791
	ctx.r5.s64 = 791;
	// li r4,0
	ctx.r4.s64 = 0;
	// stb r30,80(r1)
	REX_STORE_U8(ctx.r1.u32 + 80, ctx.r30.u8);
	// addi r3,r1,81
	ctx.r3.s64 = ctx.r1.s64 + 81;
	// bl 0x8b0cb8e0
	ctx.lr = 0x8B0B5440;
	sub_8B0CB8E0(ctx, base);
	// li r6,11
	ctx.r6.s64 = 11;
	// addi r5,r1,80
	ctx.r5.s64 = ctx.r1.s64 + 80;
	// lwz r3,8(r31)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r31.u32 + 8);
	// lwz r4,28(r31)
	ctx.r4.u64 = REX_LOAD_U32(ctx.r31.u32 + 28);
	// bl 0x8b098e70
	ctx.lr = 0x8B0B5454;
	sub_8B098E70(ctx, base);
	// clrlwi r10,r3,24
	ctx.r10.u64 = ctx.r3.u32 & 0xFF;
	// cmplwi cr6,r10,0
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 0, ctx.xer);
	// bne cr6,0x8b0b54d4
	if (!ctx.cr6.eq) goto loc_8B0B54D4;
	// lwz r3,28(r31)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r31.u32 + 28);
	// lwz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r10,20(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 20);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B0B5474;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// stw r30,28(r31)
	REX_STORE_U32(ctx.r31.u32 + 28, ctx.r30.u32);
	// li r3,36
	ctx.r3.s64 = 36;
	// bl 0x8b0bf448
	ctx.lr = 0x8B0B5480;
	sub_8B0BF448(ctx, base);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0b54b8
	if (ctx.cr6.eq) goto loc_8B0B54B8;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// addi r6,r11,17076
	ctx.r6.s64 = ctx.r11.s64 + 17076;
	// lis r9,-29944
	ctx.r9.s64 = -1962409984;
	// lis r4,-29944
	ctx.r4.s64 = -1962409984;
	// mr r7,r6
	ctx.r7.u64 = ctx.r6.u64;
	// addi r8,r10,27552
	ctx.r8.s64 = ctx.r10.s64 + 27552;
	// addi r5,r9,4072
	ctx.r5.s64 = ctx.r9.s64 + 4072;
	// addi r4,r4,4080
	ctx.r4.s64 = ctx.r4.s64 + 4080;
	// bl 0x8b0c1438
	ctx.lr = 0x8B0B54B0;
	sub_8B0C1438(ctx, base);
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// b 0x8b0b54bc
	goto loc_8B0B54BC;
loc_8B0B54B8:
	// mr r4,r30
	ctx.r4.u64 = ctx.r30.u64;
loc_8B0B54BC:
	// lis r11,-29938
	ctx.r11.s64 = -1962016768;
	// lwz r3,4480(r11)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r11.u32 + 4480);
	// lwz r10,0(r3)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r9,8(r10)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r10.u32 + 8);
	// mtctr r9
	ctx.ctr.u64 = ctx.r9.u64;
	// b 0x8b0b5520
	goto loc_8B0B5520;
loc_8B0B54D4:
	// lis r30,-29938
	ctx.r30.s64 = -1962016768;
	// ld r5,856(r1)
	ctx.r5.u64 = REX_LOAD_U64(ctx.r1.u32 + 856);
	// ld r4,864(r1)
	ctx.r4.u64 = REX_LOAD_U64(ctx.r1.u32 + 864);
	// lwz r11,2364(r30)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r30.u32 + 2364);
	// lwz r3,76(r11)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r11.u32 + 76);
	// lwz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r10,36(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 36);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B0B54F8;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// li r4,1
	ctx.r4.s64 = 1;
	// lwz r5,852(r1)
	ctx.r5.u64 = REX_LOAD_U32(ctx.r1.u32 + 852);
	// lwz r3,28(r31)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r31.u32 + 28);
	// bl 0x8b0a0610
	ctx.lr = 0x8B0B5508;
	sub_8B0A0610(ctx, base);
	// lwz r11,2364(r30)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r30.u32 + 2364);
	// addi r4,r1,594
	ctx.r4.s64 = ctx.r1.s64 + 594;
	// lwz r3,84(r11)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r11.u32 + 84);
	// lwz r9,0(r3)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r8,28(r9)
	ctx.r8.u64 = REX_LOAD_U32(ctx.r9.u32 + 28);
	// mtctr r8
	ctx.ctr.u64 = ctx.r8.u64;
loc_8B0B5520:
	// bctrl 
	ctx.lr = 0x8B0B5524;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// addi r1,r1,896
	ctx.r1.s64 = ctx.r1.s64 + 896;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// ld r30,-24(r1)
	ctx.r30.u64 = REX_LOAD_U64(ctx.r1.u32 + -24);
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0B5A08) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9b8
	ctx.lr = 0x8B0B5A10;
	__savegprlr_28(ctx, base);
	// stwu r1,-128(r1)
	ea = -128 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// mr r3,r4
	ctx.r3.u64 = ctx.r4.u64;
	// mr r30,r4
	ctx.r30.u64 = ctx.r4.u64;
	// bl 0x8b0beee8
	ctx.lr = 0x8B0B5A24;
	sub_8B0BEEE8(ctx, base);
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// mr r29,r3
	ctx.r29.u64 = ctx.r3.u64;
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// addi r3,r11,4000
	ctx.r3.s64 = ctx.r11.s64 + 4000;
	// bl 0x8b0cea10
	ctx.lr = 0x8B0B5A38;
	sub_8B0CEA10(ctx, base);
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// bne cr6,0x8b0b5b20
	if (!ctx.cr6.eq) goto loc_8B0B5B20;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// li r5,0
	ctx.r5.s64 = 0;
	// addi r4,r11,3988
	ctx.r4.s64 = ctx.r11.s64 + 3988;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// bl 0x8b0bfc38
	ctx.lr = 0x8B0B5A54;
	sub_8B0BFC38(ctx, base);
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// mr r29,r3
	ctx.r29.u64 = ctx.r3.u64;
	// addi r4,r10,3984
	ctx.r4.s64 = ctx.r10.s64 + 3984;
	// li r5,0
	ctx.r5.s64 = 0;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// bl 0x8b0bfc38
	ctx.lr = 0x8B0B5A6C;
	sub_8B0BFC38(ctx, base);
	// cmpwi cr6,r29,2
	ctx.cr6.compare<int32_t>(ctx.r29.s32, 2, ctx.xer);
	// blt cr6,0x8b0b601c
	if (ctx.cr6.lt) goto loc_8B0B601C;
	// cmpwi cr6,r3,2
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 2, ctx.xer);
	// bge cr6,0x8b0b601c
	if (!ctx.cr6.lt) goto loc_8B0B601C;
	// lwz r11,20(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 20);
	// cmpwi cr6,r11,3
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 3, ctx.xer);
	// bne cr6,0x8b0b5ab8
	if (!ctx.cr6.eq) goto loc_8B0B5AB8;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// addi r3,r11,28576
	ctx.r3.s64 = ctx.r11.s64 + 28576;
	// bl 0x8b0df298
	ctx.lr = 0x8B0B5A94;
	sub_8B0DF298(ctx, base);
	// li r3,36
	ctx.r3.s64 = 36;
	// bl 0x8b0bf448
	ctx.lr = 0x8B0B5A9C;
	sub_8B0BF448(ctx, base);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0b5afc
	if (ctx.cr6.eq) goto loc_8B0B5AFC;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// addi r4,r11,19592
	ctx.r4.s64 = ctx.r11.s64 + 19592;
	// bl 0x8b0bf9f8
	ctx.lr = 0x8B0B5AB0;
	sub_8B0BF9F8(ctx, base);
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// b 0x8b0b5b00
	goto loc_8B0B5B00;
loc_8B0B5AB8:
	// cmpwi cr6,r11,4
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 4, ctx.xer);
	// bne cr6,0x8b0b601c
	if (!ctx.cr6.eq) goto loc_8B0B601C;
	// li r11,2
	ctx.r11.s64 = 2;
	// li r3,36
	ctx.r3.s64 = 36;
	// stw r11,20(r31)
	REX_STORE_U32(ctx.r31.u32 + 20, ctx.r11.u32);
	// bl 0x8b0bf448
	ctx.lr = 0x8B0B5AD0;
	sub_8B0BF448(ctx, base);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0b5afc
	if (ctx.cr6.eq) goto loc_8B0B5AFC;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// lis r9,-29944
	ctx.r9.s64 = -1962409984;
	// addi r6,r11,4040
	ctx.r6.s64 = ctx.r11.s64 + 4040;
	// addi r5,r10,4072
	ctx.r5.s64 = ctx.r10.s64 + 4072;
	// addi r4,r9,4080
	ctx.r4.s64 = ctx.r9.s64 + 4080;
	// bl 0x8b0c1300
	ctx.lr = 0x8B0B5AF4;
	sub_8B0C1300(ctx, base);
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// b 0x8b0b5b00
	goto loc_8B0B5B00;
loc_8B0B5AFC:
	// li r4,0
	ctx.r4.s64 = 0;
loc_8B0B5B00:
	// lis r11,-29938
	ctx.r11.s64 = -1962016768;
	// lwz r3,4480(r11)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r11.u32 + 4480);
	// lwz r10,0(r3)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r9,8(r10)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r10.u32 + 8);
	// mtctr r9
	ctx.ctr.u64 = ctx.r9.u64;
	// bctrl 
	ctx.lr = 0x8B0B5B18;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// addi r1,r1,128
	ctx.r1.s64 = ctx.r1.s64 + 128;
	// b 0x8b0cba08
	__restgprlr_28(ctx, base);
	return;
loc_8B0B5B20:
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// mr r4,r29
	ctx.r4.u64 = ctx.r29.u64;
	// addi r3,r11,4136
	ctx.r3.s64 = ctx.r11.s64 + 4136;
	// bl 0x8b0cea10
	ctx.lr = 0x8B0B5B30;
	sub_8B0CEA10(ctx, base);
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// bne cr6,0x8b0b5c50
	if (!ctx.cr6.eq) goto loc_8B0B5C50;
	// lwz r11,20(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 20);
	// cmpwi cr6,r11,3
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 3, ctx.xer);
	// bne cr6,0x8b0b601c
	if (!ctx.cr6.eq) goto loc_8B0B601C;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// addi r5,r11,1791
	ctx.r5.s64 = ctx.r11.s64 + 1791;
	// addi r4,r10,4500
	ctx.r4.s64 = ctx.r10.s64 + 4500;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// bl 0x8b0c1588
	ctx.lr = 0x8B0B5B5C;
	sub_8B0C1588(ctx, base);
	// lis r9,-29944
	ctx.r9.s64 = -1962409984;
	// mr r29,r3
	ctx.r29.u64 = ctx.r3.u64;
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// addi r3,r9,28544
	ctx.r3.s64 = ctx.r9.s64 + 28544;
	// bl 0x8b0df298
	ctx.lr = 0x8B0B5B70;
	sub_8B0DF298(ctx, base);
	// lis r8,-29944
	ctx.r8.s64 = -1962409984;
	// mr r3,r29
	ctx.r3.u64 = ctx.r29.u64;
	// addi r4,r8,28512
	ctx.r4.s64 = ctx.r8.s64 + 28512;
	// bl 0x8b0c3c50
	ctx.lr = 0x8B0B5B80;
	sub_8B0C3C50(ctx, base);
	// li r28,0
	ctx.r28.s64 = 0;
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// bne cr6,0x8b0b5ba8
	if (!ctx.cr6.eq) goto loc_8B0B5BA8;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// mr r3,r29
	ctx.r3.u64 = ctx.r29.u64;
	// addi r4,r11,4164
	ctx.r4.s64 = ctx.r11.s64 + 4164;
	// bl 0x8b0c3c50
	ctx.lr = 0x8B0B5B9C;
	sub_8B0C3C50(ctx, base);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// mr r11,r28
	ctx.r11.u64 = ctx.r28.u64;
	// beq cr6,0x8b0b5bac
	if (ctx.cr6.eq) goto loc_8B0B5BAC;
loc_8B0B5BA8:
	// li r11,1
	ctx.r11.s64 = 1;
loc_8B0B5BAC:
	// clrlwi r11,r11,24
	ctx.r11.u64 = ctx.r11.u32 & 0xFF;
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// bne cr6,0x8b0b5c00
	if (!ctx.cr6.eq) goto loc_8B0B5C00;
	// li r3,36
	ctx.r3.s64 = 36;
	// bl 0x8b0bf448
	ctx.lr = 0x8B0B5BC0;
	sub_8B0BF448(ctx, base);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0b5bdc
	if (ctx.cr6.eq) goto loc_8B0B5BDC;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// addi r4,r11,19592
	ctx.r4.s64 = ctx.r11.s64 + 19592;
	// bl 0x8b0bf9f8
	ctx.lr = 0x8B0B5BD4;
	sub_8B0BF9F8(ctx, base);
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// b 0x8b0b5be0
	goto loc_8B0B5BE0;
loc_8B0B5BDC:
	// mr r4,r28
	ctx.r4.u64 = ctx.r28.u64;
loc_8B0B5BE0:
	// lis r11,-29938
	ctx.r11.s64 = -1962016768;
	// lwz r3,4480(r11)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r11.u32 + 4480);
	// lwz r10,0(r3)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r9,8(r10)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r10.u32 + 8);
	// mtctr r9
	ctx.ctr.u64 = ctx.r9.u64;
	// bctrl 
	ctx.lr = 0x8B0B5BF8;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// addi r1,r1,128
	ctx.r1.s64 = ctx.r1.s64 + 128;
	// b 0x8b0cba08
	__restgprlr_28(ctx, base);
	return;
loc_8B0B5C00:
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// addi r5,r11,4636
	ctx.r5.s64 = ctx.r11.s64 + 4636;
	// addi r4,r10,28496
	ctx.r4.s64 = ctx.r10.s64 + 28496;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// bl 0x8b0c0010
	ctx.lr = 0x8B0B5C18;
	sub_8B0C0010(ctx, base);
	// lis r29,-29938
	ctx.r29.s64 = -1962016768;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// lwz r11,4480(r29)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r29.u32 + 4480);
	// lwz r30,0(r11)
	ctx.r30.u64 = REX_LOAD_U32(ctx.r11.u32 + 0);
	// bl 0x8b0c0298
	ctx.lr = 0x8B0B5C2C;
	sub_8B0C0298(ctx, base);
	// lwz r9,12(r30)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r30.u32 + 12);
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// lwz r3,4480(r29)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r29.u32 + 4480);
	// mtctr r9
	ctx.ctr.u64 = ctx.r9.u64;
	// bctrl 
	ctx.lr = 0x8B0B5C40;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
loc_8B0B5C40:
	// addi r3,r31,-4
	ctx.r3.s64 = ctx.r31.s64 + -4;
	// bl 0x8b0b5398
	ctx.lr = 0x8B0B5C48;
	sub_8B0B5398(ctx, base);
	// addi r1,r1,128
	ctx.r1.s64 = ctx.r1.s64 + 128;
	// b 0x8b0cba08
	__restgprlr_28(ctx, base);
	return;
loc_8B0B5C50:
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// mr r4,r29
	ctx.r4.u64 = ctx.r29.u64;
	// addi r3,r11,28480
	ctx.r3.s64 = ctx.r11.s64 + 28480;
	// bl 0x8b0cea10
	ctx.lr = 0x8B0B5C60;
	sub_8B0CEA10(ctx, base);
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// beq cr6,0x8b0b5c40
	if (ctx.cr6.eq) goto loc_8B0B5C40;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// mr r4,r29
	ctx.r4.u64 = ctx.r29.u64;
	// addi r28,r11,4080
	ctx.r28.s64 = ctx.r11.s64 + 4080;
	// mr r3,r28
	ctx.r3.u64 = ctx.r28.u64;
	// bl 0x8b0cea10
	ctx.lr = 0x8B0B5C7C;
	sub_8B0CEA10(ctx, base);
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// bne cr6,0x8b0b5d04
	if (!ctx.cr6.eq) goto loc_8B0B5D04;
	// lwz r11,20(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 20);
	// cmpwi cr6,r11,2
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 2, ctx.xer);
	// bne cr6,0x8b0b601c
	if (!ctx.cr6.eq) goto loc_8B0B601C;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// addi r5,r11,1791
	ctx.r5.s64 = ctx.r11.s64 + 1791;
	// addi r4,r10,4072
	ctx.r4.s64 = ctx.r10.s64 + 4072;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// bl 0x8b0c1588
	ctx.lr = 0x8B0B5CA8;
	sub_8B0C1588(ctx, base);
	// lis r9,-29944
	ctx.r9.s64 = -1962409984;
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// addi r3,r9,4064
	ctx.r3.s64 = ctx.r9.s64 + 4064;
	// bl 0x8b0cea10
	ctx.lr = 0x8B0B5CB8;
	sub_8B0CEA10(ctx, base);
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// bne cr6,0x8b0b601c
	if (!ctx.cr6.eq) goto loc_8B0B601C;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// li r5,0
	ctx.r5.s64 = 0;
	// addi r4,r11,4056
	ctx.r4.s64 = ctx.r11.s64 + 4056;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// bl 0x8b0bfa88
	ctx.lr = 0x8B0B5CD4;
	sub_8B0BFA88(ctx, base);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0b601c
	if (ctx.cr6.eq) goto loc_8B0B601C;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// li r5,0
	ctx.r5.s64 = 0;
	// addi r4,r11,28028
	ctx.r4.s64 = ctx.r11.s64 + 28028;
	// bl 0x8b0bfa88
	ctx.lr = 0x8B0B5CEC;
	sub_8B0BFA88(ctx, base);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0b601c
	if (ctx.cr6.eq) goto loc_8B0B601C;
	// addi r3,r31,-4
	ctx.r3.s64 = ctx.r31.s64 + -4;
	// bl 0x8b0b5400
	ctx.lr = 0x8B0B5CFC;
	sub_8B0B5400(ctx, base);
	// addi r1,r1,128
	ctx.r1.s64 = ctx.r1.s64 + 128;
	// b 0x8b0cba08
	__restgprlr_28(ctx, base);
	return;
loc_8B0B5D04:
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// mr r4,r29
	ctx.r4.u64 = ctx.r29.u64;
	// addi r3,r11,9244
	ctx.r3.s64 = ctx.r11.s64 + 9244;
	// bl 0x8b0cea10
	ctx.lr = 0x8B0B5D14;
	sub_8B0CEA10(ctx, base);
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// bne cr6,0x8b0b5d68
	if (!ctx.cr6.eq) goto loc_8B0B5D68;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// bl 0x8b0bf248
	ctx.lr = 0x8B0B5D24;
	sub_8B0BF248(ctx, base);
	// bl 0x8b0beee8
	ctx.lr = 0x8B0B5D28;
	sub_8B0BEEE8(ctx, base);
	// lwz r11,24(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 24);
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// beq cr6,0x8b0b601c
	if (ctx.cr6.eq) goto loc_8B0B601C;
	// lwz r11,20(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 20);
	// cmpwi cr6,r11,1
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 1, ctx.xer);
	// ble cr6,0x8b0b601c
	if (!ctx.cr6.gt) goto loc_8B0B601C;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// addi r4,r11,8764
	ctx.r4.s64 = ctx.r11.s64 + 8764;
	// bl 0x8b0cea10
	ctx.lr = 0x8B0B5D4C;
	sub_8B0CEA10(ctx, base);
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// bne cr6,0x8b0b601c
	if (!ctx.cr6.eq) goto loc_8B0B601C;
	// mr r4,r30
	ctx.r4.u64 = ctx.r30.u64;
	// lwz r3,24(r31)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r31.u32 + 24);
	// bl 0x8b0a36b0
	ctx.lr = 0x8B0B5D60;
	sub_8B0A36B0(ctx, base);
	// addi r1,r1,128
	ctx.r1.s64 = ctx.r1.s64 + 128;
	// b 0x8b0cba08
	__restgprlr_28(ctx, base);
	return;
loc_8B0B5D68:
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// mr r4,r29
	ctx.r4.u64 = ctx.r29.u64;
	// addi r3,r11,28428
	ctx.r3.s64 = ctx.r11.s64 + 28428;
	// bl 0x8b0cea10
	ctx.lr = 0x8B0B5D78;
	sub_8B0CEA10(ctx, base);
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// bne cr6,0x8b0b5da4
	if (!ctx.cr6.eq) goto loc_8B0B5DA4;
	// lwz r3,24(r31)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r31.u32 + 24);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0b601c
	if (ctx.cr6.eq) goto loc_8B0B601C;
	// lwz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r10,80(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 80);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B0B5D9C;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// addi r1,r1,128
	ctx.r1.s64 = ctx.r1.s64 + 128;
	// b 0x8b0cba08
	__restgprlr_28(ctx, base);
	return;
loc_8B0B5DA4:
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// mr r4,r29
	ctx.r4.u64 = ctx.r29.u64;
	// addi r3,r11,17092
	ctx.r3.s64 = ctx.r11.s64 + 17092;
	// bl 0x8b0cea10
	ctx.lr = 0x8B0B5DB4;
	sub_8B0CEA10(ctx, base);
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// bne cr6,0x8b0b5fbc
	if (!ctx.cr6.eq) goto loc_8B0B5FBC;
	// lwz r11,24(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 24);
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// beq cr6,0x8b0b601c
	if (ctx.cr6.eq) goto loc_8B0B601C;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// li r5,0
	ctx.r5.s64 = 0;
	// addi r4,r11,16280
	ctx.r4.s64 = ctx.r11.s64 + 16280;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// bl 0x8b0bfe68
	ctx.lr = 0x8B0B5DDC;
	sub_8B0BFE68(ctx, base);
	// lwz r10,24(r31)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r31.u32 + 24);
	// cmplw cr6,r3,r10
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, ctx.r10.u32, ctx.xer);
	// bne cr6,0x8b0b601c
	if (!ctx.cr6.eq) goto loc_8B0B601C;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// li r5,0
	ctx.r5.s64 = 0;
	// addi r29,r11,17076
	ctx.r29.s64 = ctx.r11.s64 + 17076;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// mr r4,r29
	ctx.r4.u64 = ctx.r29.u64;
	// bl 0x8b0c1588
	ctx.lr = 0x8B0B5E00;
	sub_8B0C1588(ctx, base);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0b5e78
	if (ctx.cr6.eq) goto loc_8B0B5E78;
	// lwz r3,24(r31)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r31.u32 + 24);
	// lwz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r10,20(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 20);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B0B5E1C;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// li r9,0
	ctx.r9.s64 = 0;
	// li r8,1
	ctx.r8.s64 = 1;
	// stw r9,24(r31)
	REX_STORE_U32(ctx.r31.u32 + 24, ctx.r9.u32);
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// stw r8,20(r31)
	REX_STORE_U32(ctx.r31.u32 + 20, ctx.r8.u32);
	// bl 0x8b0c0298
	ctx.lr = 0x8B0B5E34;
	sub_8B0C0298(ctx, base);
	// mr r4,r28
	ctx.r4.u64 = ctx.r28.u64;
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// bl 0x8b0bf328
	ctx.lr = 0x8B0B5E40;
	sub_8B0BF328(ctx, base);
	// lis r7,-29944
	ctx.r7.s64 = -1962409984;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// mr r5,r29
	ctx.r5.u64 = ctx.r29.u64;
	// addi r4,r7,4072
	ctx.r4.s64 = ctx.r7.s64 + 4072;
	// bl 0x8b0c0010
	ctx.lr = 0x8B0B5E54;
	sub_8B0C0010(ctx, base);
	// lis r6,-29938
	ctx.r6.s64 = -1962016768;
	// mr r4,r31
	ctx.r4.u64 = ctx.r31.u64;
	// lwz r3,4480(r6)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r6.u32 + 4480);
	// lwz r5,0(r3)
	ctx.r5.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r11,8(r5)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r5.u32 + 8);
	// mtctr r11
	ctx.ctr.u64 = ctx.r11.u64;
	// bctrl 
	ctx.lr = 0x8B0B5E70;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// addi r1,r1,128
	ctx.r1.s64 = ctx.r1.s64 + 128;
	// b 0x8b0cba08
	__restgprlr_28(ctx, base);
	return;
loc_8B0B5E78:
	// lwz r11,20(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 20);
	// cmpwi cr6,r11,1
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 1, ctx.xer);
	// beq cr6,0x8b0b5fa4
	if (ctx.cr6.eq) goto loc_8B0B5FA4;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// li r5,0
	ctx.r5.s64 = 0;
	// addi r4,r11,8928
	ctx.r4.s64 = ctx.r11.s64 + 8928;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// bl 0x8b0c1588
	ctx.lr = 0x8B0B5E98;
	sub_8B0C1588(ctx, base);
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0b5f90
	if (ctx.cr6.eq) goto loc_8B0B5F90;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// addi r3,r11,3904
	ctx.r3.s64 = ctx.r11.s64 + 3904;
	// bl 0x8b0cea10
	ctx.lr = 0x8B0B5EB0;
	sub_8B0CEA10(ctx, base);
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// bne cr6,0x8b0b5f90
	if (!ctx.cr6.eq) goto loc_8B0B5F90;
	// li r3,36
	ctx.r3.s64 = 36;
	// bl 0x8b0bf448
	ctx.lr = 0x8B0B5EC0;
	sub_8B0BF448(ctx, base);
	// li r28,0
	ctx.r28.s64 = 0;
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0b5ee0
	if (ctx.cr6.eq) goto loc_8B0B5EE0;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// addi r4,r11,30256
	ctx.r4.s64 = ctx.r11.s64 + 30256;
	// bl 0x8b0bf9f8
	ctx.lr = 0x8B0B5ED8;
	sub_8B0BF9F8(ctx, base);
	// mr r30,r3
	ctx.r30.u64 = ctx.r3.u64;
	// b 0x8b0b5ee4
	goto loc_8B0B5EE4;
loc_8B0B5EE0:
	// mr r30,r28
	ctx.r30.u64 = ctx.r28.u64;
loc_8B0B5EE4:
	// lwz r11,20(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 20);
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// addi r5,r10,4636
	ctx.r5.s64 = ctx.r10.s64 + 4636;
	// cmpwi cr6,r11,3
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 3, ctx.xer);
	// beq cr6,0x8b0b5f0c
	if (ctx.cr6.eq) goto loc_8B0B5F0C;
	// cmpwi cr6,r11,4
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 4, ctx.xer);
	// bne cr6,0x8b0b5f14
	if (!ctx.cr6.eq) goto loc_8B0B5F14;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// addi r5,r11,27328
	ctx.r5.s64 = ctx.r11.s64 + 27328;
	// b 0x8b0b5f14
	goto loc_8B0B5F14;
loc_8B0B5F0C:
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// addi r5,r11,5212
	ctx.r5.s64 = ctx.r11.s64 + 5212;
loc_8B0B5F14:
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// addi r4,r11,4072
	ctx.r4.s64 = ctx.r11.s64 + 4072;
	// bl 0x8b0c0010
	ctx.lr = 0x8B0B5F24;
	sub_8B0C0010(ctx, base);
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// lwz r4,4(r31)
	ctx.r4.u64 = REX_LOAD_U32(ctx.r31.u32 + 4);
	// bl 0x8b0bfc00
	ctx.lr = 0x8B0B5F30;
	sub_8B0BFC00(ctx, base);
	// li r10,5
	ctx.r10.s64 = 5;
	// stw r28,4(r31)
	REX_STORE_U32(ctx.r31.u32 + 4, ctx.r28.u32);
	// lis r9,-29938
	ctx.r9.s64 = -1962016768;
	// stw r28,8(r31)
	REX_STORE_U32(ctx.r31.u32 + 8, ctx.r28.u32);
	// li r4,0
	ctx.r4.s64 = 0;
	// stw r10,20(r31)
	REX_STORE_U32(ctx.r31.u32 + 20, ctx.r10.u32);
	// lwz r29,24(r31)
	ctx.r29.u64 = REX_LOAD_U32(ctx.r31.u32 + 24);
	// stw r28,24(r31)
	REX_STORE_U32(ctx.r31.u32 + 24, ctx.r28.u32);
	// lwz r3,3036(r9)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r9.u32 + 3036);
	// bl 0x8b0a55b8
	ctx.lr = 0x8B0B5F58;
	sub_8B0A55B8(ctx, base);
	// lwz r8,-4(r31)
	ctx.r8.u64 = REX_LOAD_U32(ctx.r31.u32 + -4);
	// lwz r7,20(r8)
	ctx.r7.u64 = REX_LOAD_U32(ctx.r8.u32 + 20);
	// addi r3,r31,-4
	ctx.r3.s64 = ctx.r31.s64 + -4;
	// mtctr r7
	ctx.ctr.u64 = ctx.r7.u64;
	// bctrl 
	ctx.lr = 0x8B0B5F6C;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// li r3,40
	ctx.r3.s64 = 40;
	// bl 0x8b090000
	ctx.lr = 0x8B0B5F74;
	sub_8B090000(ctx, base);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0b601c
	if (ctx.cr6.eq) goto loc_8B0B601C;
	// mr r5,r30
	ctx.r5.u64 = ctx.r30.u64;
	// mr r4,r29
	ctx.r4.u64 = ctx.r29.u64;
	// bl 0x8b0ae7c0
	ctx.lr = 0x8B0B5F88;
	sub_8B0AE7C0(ctx, base);
	// addi r1,r1,128
	ctx.r1.s64 = ctx.r1.s64 + 128;
	// b 0x8b0cba08
	__restgprlr_28(ctx, base);
	return;
loc_8B0B5F90:
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// addi r3,r11,30220
	ctx.r3.s64 = ctx.r11.s64 + 30220;
	// bl 0x8b0df2e8
	ctx.lr = 0x8B0B5F9C;
	sub_8B0DF2E8(ctx, base);
	// addi r1,r1,128
	ctx.r1.s64 = ctx.r1.s64 + 128;
	// b 0x8b0cba08
	__restgprlr_28(ctx, base);
	return;
loc_8B0B5FA4:
	// li r11,2
	ctx.r11.s64 = 2;
	// addi r3,r31,-4
	ctx.r3.s64 = ctx.r31.s64 + -4;
	// stw r11,20(r31)
	REX_STORE_U32(ctx.r31.u32 + 20, ctx.r11.u32);
	// bl 0x8b0b5608
	ctx.lr = 0x8B0B5FB4;
	sub_8B0B5608(ctx, base);
	// addi r1,r1,128
	ctx.r1.s64 = ctx.r1.s64 + 128;
	// b 0x8b0cba08
	__restgprlr_28(ctx, base);
	return;
loc_8B0B5FBC:
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// mr r4,r29
	ctx.r4.u64 = ctx.r29.u64;
	// addi r3,r11,16292
	ctx.r3.s64 = ctx.r11.s64 + 16292;
	// bl 0x8b0cea10
	ctx.lr = 0x8B0B5FCC;
	sub_8B0CEA10(ctx, base);
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// bne cr6,0x8b0b601c
	if (!ctx.cr6.eq) goto loc_8B0B601C;
	// lwz r11,24(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 24);
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// beq cr6,0x8b0b601c
	if (ctx.cr6.eq) goto loc_8B0B601C;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// li r5,0
	ctx.r5.s64 = 0;
	// addi r4,r11,16280
	ctx.r4.s64 = ctx.r11.s64 + 16280;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// bl 0x8b0bfe68
	ctx.lr = 0x8B0B5FF4;
	sub_8B0BFE68(ctx, base);
	// lwz r10,24(r31)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r31.u32 + 24);
	// cmplw cr6,r3,r10
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, ctx.r10.u32, ctx.xer);
	// bne cr6,0x8b0b601c
	if (!ctx.cr6.eq) goto loc_8B0B601C;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// bl 0x8b0bf248
	ctx.lr = 0x8B0B6008;
	sub_8B0BF248(ctx, base);
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0b601c
	if (ctx.cr6.eq) goto loc_8B0B601C;
	// addi r3,r31,-4
	ctx.r3.s64 = ctx.r31.s64 + -4;
	// bl 0x8b0b5540
	ctx.lr = 0x8B0B601C;
	sub_8B0B5540(ctx, base);
loc_8B0B601C:
	// addi r1,r1,128
	ctx.r1.s64 = ctx.r1.s64 + 128;
	// b 0x8b0cba08
	__restgprlr_28(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0B7120) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// std r31,-16(r1)
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.r31.u64);
	// stwu r1,-112(r1)
	ea = -112 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// lwz r3,44(r3)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r3.u32 + 44);
	// lwz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r10,8(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 8);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B0B7148;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// lwz r10,44(r31)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r31.u32 + 44);
	// lwz r9,4(r10)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r10.u32 + 4);
	// cmpwi cr6,r9,4
	ctx.cr6.compare<int32_t>(ctx.r9.s32, 4, ctx.xer);
	// bne cr6,0x8b0b7160
	if (!ctx.cr6.eq) goto loc_8B0B7160;
	// li r11,2
	ctx.r11.s64 = 2;
	// stw r11,36(r31)
	REX_STORE_U32(ctx.r31.u32 + 36, ctx.r11.u32);
loc_8B0B7160:
	// lwz r11,36(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 36);
	// cmplwi cr6,r11,1
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 1, ctx.xer);
	// blt cr6,0x8b0b7198
	if (ctx.cr6.lt) goto loc_8B0B7198;
	// bne cr6,0x8b0b71c8
	if (!ctx.cr6.eq) goto loc_8B0B71C8;
	// lwz r3,460(r10)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r10.u32 + 460);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0b71c8
	if (ctx.cr6.eq) goto loc_8B0B71C8;
	// bl 0x8b0c0298
	ctx.lr = 0x8B0B7180;
	sub_8B0C0298(ctx, base);
	// stw r3,80(r1)
	REX_STORE_U32(ctx.r1.u32 + 80, ctx.r3.u32);
	// addi r3,r31,20
	ctx.r3.s64 = ctx.r31.s64 + 20;
	// lwz r4,32(r31)
	ctx.r4.u64 = REX_LOAD_U32(ctx.r31.u32 + 32);
	// addi r5,r1,80
	ctx.r5.s64 = ctx.r1.s64 + 80;
	// bl 0x8b09f3f8
	ctx.lr = 0x8B0B7194;
	sub_8B09F3F8(ctx, base);
	// b 0x8b0b71c0
	goto loc_8B0B71C0;
loc_8B0B7198:
	// lwz r11,4(r10)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r10.u32 + 4);
	// cmpwi cr6,r11,2
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 2, ctx.xer);
	// beq cr6,0x8b0b71b0
	if (ctx.cr6.eq) goto loc_8B0B71B0;
	// cmpwi cr6,r11,3
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 3, ctx.xer);
	// li r11,0
	ctx.r11.s64 = 0;
	// bne cr6,0x8b0b71b4
	if (!ctx.cr6.eq) goto loc_8B0B71B4;
loc_8B0B71B0:
	// li r11,1
	ctx.r11.s64 = 1;
loc_8B0B71B4:
	// clrlwi r11,r11,24
	ctx.r11.u64 = ctx.r11.u32 & 0xFF;
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// beq cr6,0x8b0b71c8
	if (ctx.cr6.eq) goto loc_8B0B71C8;
loc_8B0B71C0:
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0b6cf8
	ctx.lr = 0x8B0B71C8;
	sub_8B0B6CF8(ctx, base);
loc_8B0B71C8:
	// addi r1,r1,112
	ctx.r1.s64 = ctx.r1.s64 + 112;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0B7850) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// std r30,-24(r1)
	REX_STORE_U64(ctx.r1.u32 + -24, ctx.r30.u64);
	// std r31,-16(r1)
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.r31.u64);
	// stwu r1,-112(r1)
	ea = -112 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// lwz r3,8(r3)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r3.u32 + 8);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0b7878
	if (ctx.cr6.eq) goto loc_8B0B7878;
	// bl 0x8b0b71e0
	ctx.lr = 0x8B0B7878;
	sub_8B0B71E0(ctx, base);
loc_8B0B7878:
	// lwz r11,4(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 4);
	// li r30,0
	ctx.r30.s64 = 0;
	// stw r30,8(r31)
	REX_STORE_U32(ctx.r31.u32 + 8, ctx.r30.u32);
	// cmpwi cr6,r11,2
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 2, ctx.xer);
	// blt cr6,0x8b0b7894
	if (ctx.cr6.lt) goto loc_8B0B7894;
	// addi r3,r31,12
	ctx.r3.s64 = ctx.r31.s64 + 12;
	// bl 0x8b0b6540
	ctx.lr = 0x8B0B7894;
	sub_8B0B6540(ctx, base);
loc_8B0B7894:
	// lwz r11,4(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 4);
	// cmpwi cr6,r11,3
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 3, ctx.xer);
	// bne cr6,0x8b0b78bc
	if (!ctx.cr6.eq) goto loc_8B0B78BC;
	// lis r11,-29938
	ctx.r11.s64 = -1962016768;
	// mr r4,r31
	ctx.r4.u64 = ctx.r31.u64;
	// lwz r3,4480(r11)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r11.u32 + 4480);
	// lwz r10,0(r3)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r9,4(r10)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r10.u32 + 4);
	// mtctr r9
	ctx.ctr.u64 = ctx.r9.u64;
	// bctrl 
	ctx.lr = 0x8B0B78BC;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
loc_8B0B78BC:
	// lwz r3,460(r31)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r31.u32 + 460);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0b78cc
	if (ctx.cr6.eq) goto loc_8B0B78CC;
	// bl 0x8b0c04f0
	ctx.lr = 0x8B0B78CC;
	sub_8B0C04F0(ctx, base);
loc_8B0B78CC:
	// stw r30,460(r31)
	REX_STORE_U32(ctx.r31.u32 + 460, ctx.r30.u32);
	// li r4,1
	ctx.r4.s64 = 1;
	// lwz r11,0(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 0);
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// lwz r10,4(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 4);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B0B78E8;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// addi r1,r1,112
	ctx.r1.s64 = ctx.r1.s64 + 112;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// ld r30,-24(r1)
	ctx.r30.u64 = REX_LOAD_U64(ctx.r1.u32 + -24);
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0B7A78) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9b8
	ctx.lr = 0x8B0B7A80;
	__savegprlr_28(ctx, base);
	// stwu r1,-128(r1)
	ea = -128 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// li r29,0
	ctx.r29.s64 = 0;
	// addi r10,r11,30652
	ctx.r10.s64 = ctx.r11.s64 + 30652;
	// addi r30,r3,20
	ctx.r30.s64 = ctx.r3.s64 + 20;
	// stw r10,0(r3)
	REX_STORE_U32(ctx.r3.u32 + 0, ctx.r10.u32);
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// stw r29,32(r3)
	REX_STORE_U32(ctx.r3.u32 + 32, ctx.r29.u32);
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// mr r28,r4
	ctx.r28.u64 = ctx.r4.u64;
	// bl 0x8b0906a8
	ctx.lr = 0x8B0B7AAC;
	sub_8B0906A8(ctx, base);
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// bl 0x8b0906a8
	ctx.lr = 0x8B0B7AB4;
	sub_8B0906A8(ctx, base);
	// stw r29,16(r31)
	REX_STORE_U32(ctx.r31.u32 + 16, ctx.r29.u32);
	// addi r30,r31,4
	ctx.r30.s64 = ctx.r31.s64 + 4;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// bl 0x8b0906a8
	ctx.lr = 0x8B0B7AC4;
	sub_8B0906A8(ctx, base);
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// bl 0x8b0906a8
	ctx.lr = 0x8B0B7ACC;
	sub_8B0906A8(ctx, base);
	// clrlwi r9,r28,31
	ctx.r9.u64 = ctx.r28.u32 & 0x1;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// cmplwi cr6,r9,0
	ctx.cr6.compare<uint32_t>(ctx.r9.u32, 0, ctx.xer);
	// beq cr6,0x8b0b7ae4
	if (ctx.cr6.eq) goto loc_8B0B7AE4;
	// bl 0x8b090020
	ctx.lr = 0x8B0B7AE0;
	sub_8B090020(ctx, base);
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
loc_8B0B7AE4:
	// addi r1,r1,128
	ctx.r1.s64 = ctx.r1.s64 + 128;
	// b 0x8b0cba08
	__restgprlr_28(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0B7AF0) {
	REX_FUNC_PROLOGUE();
	PPCRegister temp{};
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// std r30,-24(r1)
	REX_STORE_U64(ctx.r1.u32 + -24, ctx.r30.u64);
	// std r31,-16(r1)
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.r31.u64);
	// stfd f31,-32(r1)
	ctx.fpscr.disableFlushMode();
	REX_STORE_U64(ctx.r1.u32 + -32, ctx.f31.u64);
	// stwu r1,-128(r1)
	ea = -128 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lwz r11,4(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 4);
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// cmplwi cr6,r11,1
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 1, ctx.xer);
	// blt cr6,0x8b0b7c08
	if (ctx.cr6.lt) goto loc_8B0B7C08;
	// beq cr6,0x8b0b7b64
	if (ctx.cr6.eq) goto loc_8B0B7B64;
	// cmplwi cr6,r11,3
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 3, ctx.xer);
	// bge cr6,0x8b0b7c54
	if (!ctx.cr6.lt) goto loc_8B0B7C54;
	// bl 0x8b0df2f8
	ctx.lr = 0x8B0B7B28;
	sub_8B0DF2F8(ctx, base);
	// lfs f0,96(r31)
	ctx.fpscr.disableFlushMode();
	temp.u32 = REX_LOAD_U32(ctx.r31.u32 + 96);
	ctx.f0.f64 = double(temp.f32);
	// fcmpu cr6,f1,f0
	ctx.cr6.compare(ctx.f1.f64, ctx.f0.f64);
	// bgt cr6,0x8b0b7b44
	if (ctx.cr6.gt) goto loc_8B0B7B44;
	// lwz r11,92(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 92);
	// lwz r10,4(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 4);
	// cmplwi cr6,r10,0
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 0, ctx.xer);
	// bne cr6,0x8b0b7c54
	if (!ctx.cr6.eq) goto loc_8B0B7C54;
loc_8B0B7B44:
	// addi r6,r31,92
	ctx.r6.s64 = ctx.r31.s64 + 92;
	// addi r5,r31,40
	ctx.r5.s64 = ctx.r31.s64 + 40;
	// addi r4,r31,104
	ctx.r4.s64 = ctx.r31.s64 + 104;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0b75e0
	ctx.lr = 0x8B0B7B58;
	sub_8B0B75E0(ctx, base);
	// li r11,3
	ctx.r11.s64 = 3;
	// stw r11,4(r31)
	REX_STORE_U32(ctx.r31.u32 + 4, ctx.r11.u32);
	// b 0x8b0b7c54
	goto loc_8B0B7C54;
loc_8B0B7B64:
	// lwz r11,12(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 12);
	// addi r30,r31,12
	ctx.r30.s64 = ctx.r31.s64 + 12;
	// cmplwi cr6,r11,997
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 997, ctx.xer);
	// bne cr6,0x8b0b7bb4
	if (!ctx.cr6.eq) goto loc_8B0B7BB4;
	// bl 0x8b0df2f8
	ctx.lr = 0x8B0B7B78;
	sub_8B0DF2F8(ctx, base);
	// lfs f0,96(r31)
	ctx.fpscr.disableFlushMode();
	temp.u32 = REX_LOAD_U32(ctx.r31.u32 + 96);
	ctx.f0.f64 = double(temp.f32);
	// fcmpu cr6,f1,f0
	ctx.cr6.compare(ctx.f1.f64, ctx.f0.f64);
	// ble cr6,0x8b0b7c54
	if (!ctx.cr6.gt) goto loc_8B0B7C54;
	// stw r30,80(r1)
	REX_STORE_U32(ctx.r1.u32 + 80, ctx.r30.u32);
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lis r10,-29942
	ctx.r10.s64 = -1962278912;
	// addi r5,r1,80
	ctx.r5.s64 = ctx.r1.s64 + 80;
	// addi r4,r10,-26176
	ctx.r4.s64 = ctx.r10.s64 + -26176;
	// lwz r11,1208(r11)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r11.u32 + 1208);
	// lwz r3,0(r11)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r11.u32 + 0);
	// bl 0x8b09a5d0
	ctx.lr = 0x8B0B7BA4;
	sub_8B09A5D0(ctx, base);
	// li r9,3
	ctx.r9.s64 = 3;
	// stw r3,100(r31)
	REX_STORE_U32(ctx.r31.u32 + 100, ctx.r3.u32);
	// stw r9,4(r31)
	REX_STORE_U32(ctx.r31.u32 + 4, ctx.r9.u32);
	// b 0x8b0b7c54
	goto loc_8B0B7C54;
loc_8B0B7BB4:
	// lis r11,-29938
	ctx.r11.s64 = -1962016768;
	// addi r10,r11,21176
	ctx.r10.s64 = ctx.r11.s64 + 21176;
	// lwz r11,28(r10)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r10.u32 + 28);
	// lfs f31,44(r11)
	ctx.fpscr.disableFlushMode();
	temp.u32 = REX_LOAD_U32(ctx.r11.u32 + 44);
	ctx.f31.f64 = double(temp.f32);
	// bl 0x8b0df2f8
	ctx.lr = 0x8B0B7BC8;
	sub_8B0DF2F8(ctx, base);
	// fadd f0,f1,f31
	ctx.fpscr.disableFlushMode();
	ctx.f0.f64 = ctx.f1.f64 + ctx.f31.f64;
	// addi r8,r31,92
	ctx.r8.s64 = ctx.r31.s64 + 92;
	// addi r7,r31,88
	ctx.r7.s64 = ctx.r31.s64 + 88;
	// addi r6,r31,40
	ctx.r6.s64 = ctx.r31.s64 + 40;
	// mr r5,r30
	ctx.r5.u64 = ctx.r30.u64;
	// addi r4,r31,8
	ctx.r4.s64 = ctx.r31.s64 + 8;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// frsp f13,f0
	ctx.f13.f64 = double(float(ctx.f0.f64));
	// stfs f13,96(r31)
	temp.f32 = float(ctx.f13.f64);
	REX_STORE_U32(ctx.r31.u32 + 96, temp.u32);
	// bl 0x8b0b72d8
	ctx.lr = 0x8B0B7BF0;
	sub_8B0B72D8(ctx, base);
	// clrlwi r9,r3,24
	ctx.r9.u64 = ctx.r3.u32 & 0xFF;
	// cntlzw r8,r9
	ctx.r8.u64 = ctx.r9.u32 == 0 ? 32 : __builtin_clz(ctx.r9.u32);
	// rlwinm r11,r8,27,31,31
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r8.u32 | (ctx.r8.u64 << 32), 27) & 0x1;
	// addi r7,r11,2
	ctx.r7.s64 = ctx.r11.s64 + 2;
	// stw r7,4(r31)
	REX_STORE_U32(ctx.r31.u32 + 4, ctx.r7.u32);
	// b 0x8b0b7c54
	goto loc_8B0B7C54;
loc_8B0B7C08:
	// lis r11,-29938
	ctx.r11.s64 = -1962016768;
	// addi r10,r11,21176
	ctx.r10.s64 = ctx.r11.s64 + 21176;
	// lwz r11,28(r10)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r10.u32 + 28);
	// lfs f31,44(r11)
	ctx.fpscr.disableFlushMode();
	temp.u32 = REX_LOAD_U32(ctx.r11.u32 + 44);
	ctx.f31.f64 = double(temp.f32);
	// bl 0x8b0df2f8
	ctx.lr = 0x8B0B7C1C;
	sub_8B0DF2F8(ctx, base);
	// fadd f0,f1,f31
	ctx.fpscr.disableFlushMode();
	ctx.f0.f64 = ctx.f1.f64 + ctx.f31.f64;
	// addi r6,r31,40
	ctx.r6.s64 = ctx.r31.s64 + 40;
	// addi r5,r31,12
	ctx.r5.s64 = ctx.r31.s64 + 12;
	// addi r4,r31,8
	ctx.r4.s64 = ctx.r31.s64 + 8;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// frsp f13,f0
	ctx.f13.f64 = double(float(ctx.f0.f64));
	// stfs f13,96(r31)
	temp.f32 = float(ctx.f13.f64);
	REX_STORE_U32(ctx.r31.u32 + 96, temp.u32);
	// bl 0x8b0b6740
	ctx.lr = 0x8B0B7C3C;
	sub_8B0B6740(ctx, base);
	// clrlwi r9,r3,24
	ctx.r9.u64 = ctx.r3.u32 & 0xFF;
	// subfic r8,r9,0
	ctx.xer.ca = ctx.r9.u32 <= 0;
	ctx.r8.u64 = static_cast<uint64_t>(0) - ctx.r9.u64;
	// subfe r7,r8,r8
	temp.u8 = (~ctx.r8.u32 + ctx.r8.u32 < ~ctx.r8.u32) | (~ctx.r8.u32 + ctx.r8.u32 + ctx.xer.ca < ctx.xer.ca);
	ctx.r7.u64 = ~ctx.r8.u64 + ctx.r8.u64 + ctx.xer.ca;
	ctx.xer.ca = temp.u8;
	// rlwinm r11,r7,0,0,30
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r7.u32 | (ctx.r7.u64 << 32), 0) & 0xFFFFFFFE;
	// addi r6,r11,3
	ctx.r6.s64 = ctx.r11.s64 + 3;
	// stw r6,4(r31)
	REX_STORE_U32(ctx.r31.u32 + 4, ctx.r6.u32);
loc_8B0B7C54:
	// addi r1,r1,128
	ctx.r1.s64 = ctx.r1.s64 + 128;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// lfd f31,-32(r1)
	ctx.fpscr.disableFlushMode();
	ctx.f31.u64 = REX_LOAD_U64(ctx.r1.u32 + -32);
	// ld r30,-24(r1)
	ctx.r30.u64 = REX_LOAD_U64(ctx.r1.u32 + -24);
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0B8150) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// std r30,-24(r1)
	REX_STORE_U64(ctx.r1.u32 + -24, ctx.r30.u64);
	// std r31,-16(r1)
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.r31.u64);
	// stwu r1,-112(r1)
	ea = -112 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lwz r11,0(r4)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r4.u32 + 0);
	// mr r30,r3
	ctx.r30.u64 = ctx.r3.u64;
	// mr r31,r4
	ctx.r31.u64 = ctx.r4.u64;
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// bne cr6,0x8b0b819c
	if (!ctx.cr6.eq) goto loc_8B0B819C;
	// lis r11,-29940
	ctx.r11.s64 = -1962147840;
	// li r5,0
	ctx.r5.s64 = 0;
	// addi r3,r11,-32440
	ctx.r3.s64 = ctx.r11.s64 + -32440;
	// bl 0x8b0df4c8
	ctx.lr = 0x8B0B8188;
	sub_8B0DF4C8(ctx, base);
	// stw r3,0(r31)
	REX_STORE_U32(ctx.r31.u32 + 0, ctx.r3.u32);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0b819c
	if (ctx.cr6.eq) goto loc_8B0B819C;
	// li r4,8
	ctx.r4.s64 = 8;
	// bl 0x8b0df4b8
	ctx.lr = 0x8B0B819C;
	sub_8B0DF4B8(ctx, base);
loc_8B0B819C:
	// addi r3,r31,4
	ctx.r3.s64 = ctx.r31.s64 + 4;
	// bl 0x8b0df4a8
	ctx.lr = 0x8B0B81A4;
	sub_8B0DF4A8(ctx, base);
	// li r9,5
	ctx.r9.s64 = 5;
	// addi r11,r31,8
	ctx.r11.s64 = ctx.r31.s64 + 8;
	// addi r10,r30,-4
	ctx.r10.s64 = ctx.r30.s64 + -4;
	// mtctr r9
	ctx.ctr.u64 = ctx.r9.u64;
loc_8B0B81B4:
	// lwzu r9,4(r11)
	ea = 4 + ctx.r11.u32;
	ctx.r9.u64 = REX_LOAD_U32(ea);
	ctx.r11.u32 = ea;
	// stwu r9,4(r10)
	ea = 4 + ctx.r10.u32;
	REX_STORE_U32(ea, ctx.r9.u32);
	ctx.r10.u32 = ea;
	// bdnz 0x8b0b81b4
	--ctx.ctr.u64;
	if (ctx.ctr.u32 != 0) goto loc_8B0B81B4;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// addi r1,r1,112
	ctx.r1.s64 = ctx.r1.s64 + 112;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// ld r30,-24(r1)
	ctx.r30.u64 = REX_LOAD_U64(ctx.r1.u32 + -24);
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0B8330) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// std r30,-24(r1)
	REX_STORE_U64(ctx.r1.u32 + -24, ctx.r30.u64);
	// std r31,-16(r1)
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.r31.u64);
	// stwu r1,-112(r1)
	ea = -112 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// mr r30,r4
	ctx.r30.u64 = ctx.r4.u64;
	// mr r4,r5
	ctx.r4.u64 = ctx.r5.u64;
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// bl 0x8b0bcd70
	ctx.lr = 0x8B0B8354;
	sub_8B0BCD70(ctx, base);
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// stw r30,180(r31)
	REX_STORE_U32(ctx.r31.u32 + 180, ctx.r30.u32);
	// li r3,36
	ctx.r3.s64 = 36;
	// addi r10,r11,32288
	ctx.r10.s64 = ctx.r11.s64 + 32288;
	// stw r10,0(r31)
	REX_STORE_U32(ctx.r31.u32 + 0, ctx.r10.u32);
	// bl 0x8b0bf448
	ctx.lr = 0x8B0B836C;
	sub_8B0BF448(ctx, base);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0b8398
	if (ctx.cr6.eq) goto loc_8B0B8398;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// lis r9,-29944
	ctx.r9.s64 = -1962409984;
	// addi r6,r11,9276
	ctx.r6.s64 = ctx.r11.s64 + 9276;
	// addi r5,r10,9316
	ctx.r5.s64 = ctx.r10.s64 + 9316;
	// addi r4,r9,32260
	ctx.r4.s64 = ctx.r9.s64 + 32260;
	// bl 0x8b0c1300
	ctx.lr = 0x8B0B8390;
	sub_8B0C1300(ctx, base);
	// mr r30,r3
	ctx.r30.u64 = ctx.r3.u64;
	// b 0x8b0b839c
	goto loc_8B0B839C;
loc_8B0B8398:
	// li r30,0
	ctx.r30.s64 = 0;
loc_8B0B839C:
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lwz r5,180(r31)
	ctx.r5.u64 = REX_LOAD_U32(ctx.r31.u32 + 180);
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// addi r4,r11,32256
	ctx.r4.s64 = ctx.r11.s64 + 32256;
	// bl 0x8b0c0250
	ctx.lr = 0x8B0B83B0;
	sub_8B0C0250(ctx, base);
	// lis r10,-29936
	ctx.r10.s64 = -1961885696;
	// lwz r3,-17796(r10)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r10.u32 + -17796);
	// lwz r9,0(r3)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r8,28(r9)
	ctx.r8.u64 = REX_LOAD_U32(ctx.r9.u32 + 28);
	// mtctr r8
	ctx.ctr.u64 = ctx.r8.u64;
	// bctrl 
	ctx.lr = 0x8B0B83C8;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// lwz r7,0(r3)
	ctx.r7.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// mr r4,r30
	ctx.r4.u64 = ctx.r30.u64;
	// lwz r6,8(r7)
	ctx.r6.u64 = REX_LOAD_U32(ctx.r7.u32 + 8);
	// mtctr r6
	ctx.ctr.u64 = ctx.r6.u64;
	// bctrl 
	ctx.lr = 0x8B0B83DC;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// addi r1,r1,112
	ctx.r1.s64 = ctx.r1.s64 + 112;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// ld r30,-24(r1)
	ctx.r30.u64 = REX_LOAD_U64(ctx.r1.u32 + -24);
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0B87A8) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9b0
	ctx.lr = 0x8B0B87B0;
	__savegprlr_26(ctx, base);
	// stwu r1,-144(r1)
	ea = -144 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lwz r11,12(r4)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r4.u32 + 12);
	// li r26,0
	ctx.r26.s64 = 0;
	// mr r29,r4
	ctx.r29.u64 = ctx.r4.u64;
	// mr r28,r26
	ctx.r28.u64 = ctx.r26.u64;
	// cmpwi cr6,r11,0
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// ble cr6,0x8b0b881c
	if (!ctx.cr6.gt) goto loc_8B0B881C;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// mr r30,r26
	ctx.r30.u64 = ctx.r26.u64;
	// addi r27,r11,32340
	ctx.r27.s64 = ctx.r11.s64 + 32340;
loc_8B0B87D8:
	// lwz r11,0(r29)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r29.u32 + 0);
	// lwzx r31,r11,r30
	ctx.r31.u64 = REX_LOAD_U32(ctx.r11.u32 + ctx.r30.u32);
	// cmplwi cr6,r31,0
	ctx.cr6.compare<uint32_t>(ctx.r31.u32, 0, ctx.xer);
	// beq cr6,0x8b0b8808
	if (ctx.cr6.eq) goto loc_8B0B8808;
	// lwz r3,16(r31)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r31.u32 + 16);
	// stw r27,0(r31)
	REX_STORE_U32(ctx.r31.u32 + 0, ctx.r27.u32);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0b87fc
	if (ctx.cr6.eq) goto loc_8B0B87FC;
	// bl 0x8b0c04f0
	ctx.lr = 0x8B0B87FC;
	sub_8B0C04F0(ctx, base);
loc_8B0B87FC:
	// stw r26,16(r31)
	REX_STORE_U32(ctx.r31.u32 + 16, ctx.r26.u32);
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b090020
	ctx.lr = 0x8B0B8808;
	sub_8B090020(ctx, base);
loc_8B0B8808:
	// lwz r11,12(r29)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r29.u32 + 12);
	// addi r28,r28,1
	ctx.r28.s64 = ctx.r28.s64 + 1;
	// addi r30,r30,4
	ctx.r30.s64 = ctx.r30.s64 + 4;
	// cmpw cr6,r28,r11
	ctx.cr6.compare<int32_t>(ctx.r28.s32, ctx.r11.s32, ctx.xer);
	// blt cr6,0x8b0b87d8
	if (ctx.cr6.lt) goto loc_8B0B87D8;
loc_8B0B881C:
	// stw r26,12(r29)
	REX_STORE_U32(ctx.r29.u32 + 12, ctx.r26.u32);
	// addi r1,r1,144
	ctx.r1.s64 = ctx.r1.s64 + 144;
	// b 0x8b0cba00
	__restgprlr_26(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0B8A10) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// std r30,-24(r1)
	REX_STORE_U64(ctx.r1.u32 + -24, ctx.r30.u64);
	// std r31,-16(r1)
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.r31.u64);
	// stwu r1,-128(r1)
	ea = -128 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// addi r9,r11,32412
	ctx.r9.s64 = ctx.r11.s64 + 32412;
	// addi r8,r10,32404
	ctx.r8.s64 = ctx.r10.s64 + 32404;
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// stw r9,0(r3)
	REX_STORE_U32(ctx.r3.u32 + 0, ctx.r9.u32);
	// li r30,0
	ctx.r30.s64 = 0;
	// stw r8,4(r3)
	REX_STORE_U32(ctx.r3.u32 + 4, ctx.r8.u32);
	// cmplwi cr6,r4,0
	ctx.cr6.compare<uint32_t>(ctx.r4.u32, 0, ctx.xer);
	// beq cr6,0x8b0b8a58
	if (ctx.cr6.eq) goto loc_8B0B8A58;
	// mr r3,r4
	ctx.r3.u64 = ctx.r4.u64;
	// bl 0x8b0c0298
	ctx.lr = 0x8B0B8A54;
	sub_8B0C0298(ctx, base);
	// b 0x8b0b8a5c
	goto loc_8B0B8A5C;
loc_8B0B8A58:
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
loc_8B0B8A5C:
	// stw r3,8(r31)
	REX_STORE_U32(ctx.r31.u32 + 8, ctx.r3.u32);
	// stw r30,12(r31)
	REX_STORE_U32(ctx.r31.u32 + 12, ctx.r30.u32);
	// stw r30,20(r31)
	REX_STORE_U32(ctx.r31.u32 + 20, ctx.r30.u32);
	// stw r30,24(r31)
	REX_STORE_U32(ctx.r31.u32 + 24, ctx.r30.u32);
	// stw r30,28(r31)
	REX_STORE_U32(ctx.r31.u32 + 28, ctx.r30.u32);
	// stw r30,32(r31)
	REX_STORE_U32(ctx.r31.u32 + 32, ctx.r30.u32);
	// stw r30,36(r31)
	REX_STORE_U32(ctx.r31.u32 + 36, ctx.r30.u32);
	// stw r31,80(r1)
	REX_STORE_U32(ctx.r1.u32 + 80, ctx.r31.u32);
	// bl 0x8b0b88f0
	ctx.lr = 0x8B0B8A80;
	sub_8B0B88F0(ctx, base);
	// addi r5,r1,80
	ctx.r5.s64 = ctx.r1.s64 + 80;
	// lwz r4,12(r3)
	ctx.r4.u64 = REX_LOAD_U32(ctx.r3.u32 + 12);
	// bl 0x8b09f3f8
	ctx.lr = 0x8B0B8A8C;
	sub_8B09F3F8(ctx, base);
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// mr r4,r31
	ctx.r4.u64 = ctx.r31.u64;
	// addi r3,r11,32368
	ctx.r3.s64 = ctx.r11.s64 + 32368;
	// bl 0x8b0df298
	ctx.lr = 0x8B0B8A9C;
	sub_8B0DF298(ctx, base);
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// li r9,1
	ctx.r9.s64 = 1;
	// lwz r3,8(r31)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r31.u32 + 8);
	// addi r8,r10,1800
	ctx.r8.s64 = ctx.r10.s64 + 1800;
	// stw r9,92(r1)
	REX_STORE_U32(ctx.r1.u32 + 92, ctx.r9.u32);
	// li r5,1
	ctx.r5.s64 = 1;
	// stw r8,88(r1)
	REX_STORE_U32(ctx.r1.u32 + 88, ctx.r8.u32);
	// addi r4,r1,88
	ctx.r4.s64 = ctx.r1.s64 + 88;
	// bl 0x8b0bf510
	ctx.lr = 0x8B0B8AC0;
	sub_8B0BF510(ctx, base);
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// addi r1,r1,128
	ctx.r1.s64 = ctx.r1.s64 + 128;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// ld r30,-24(r1)
	ctx.r30.u64 = REX_LOAD_U64(ctx.r1.u32 + -24);
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0B9070) {
	REX_FUNC_PROLOGUE();
	// b 0x8b0bd588
	sub_8B0BD588(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0B9078) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// std r31,-16(r1)
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.r31.u64);
	// stwu r1,-96(r1)
	ea = -96 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// mr r31,r4
	ctx.r31.u64 = ctx.r4.u64;
	// cmplwi cr6,r4,0
	ctx.cr6.compare<uint32_t>(ctx.r4.u32, 0, ctx.xer);
	// beq cr6,0x8b0b90c0
	if (ctx.cr6.eq) goto loc_8B0B90C0;
	// lwz r11,64(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 64);
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// beq cr6,0x8b0b90b8
	if (ctx.cr6.eq) goto loc_8B0B90B8;
	// rotlwi r11,r11,0
	ctx.r11.u64 = __builtin_rotateleft32(ctx.r11.u32, 0);
	// addi r3,r11,4
	ctx.r3.s64 = ctx.r11.s64 + 4;
	// lwz r11,4(r11)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r11.u32 + 4);
	// lwz r10,0(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 0);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B0B90B8;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
loc_8B0B90B8:
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0c04f0
	ctx.lr = 0x8B0B90C0;
	sub_8B0C04F0(ctx, base);
loc_8B0B90C0:
	// addi r1,r1,96
	ctx.r1.s64 = ctx.r1.s64 + 96;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0B9208) {
	REX_FUNC_PROLOGUE();
	PPCRegister temp{};
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// std r30,-24(r1)
	REX_STORE_U64(ctx.r1.u32 + -24, ctx.r30.u64);
	// std r31,-16(r1)
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.r31.u64);
	// stfd f31,-32(r1)
	ctx.fpscr.disableFlushMode();
	REX_STORE_U64(ctx.r1.u32 + -32, ctx.f31.u64);
	// stwu r1,-112(r1)
	ea = -112 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lis r11,-29943
	ctx.r11.s64 = -1962344448;
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// addi r3,r11,-32560
	ctx.r3.s64 = ctx.r11.s64 + -32560;
	// bl 0x8b0df298
	ctx.lr = 0x8B0B9230;
	sub_8B0DF298(ctx, base);
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0b20b0
	ctx.lr = 0x8B0B9238;
	sub_8B0B20B0(ctx, base);
	// lis r10,-29943
	ctx.r10.s64 = -1962344448;
	// lwz r4,44(r31)
	ctx.r4.u64 = REX_LOAD_U32(ctx.r31.u32 + 44);
	// addi r3,r10,-32604
	ctx.r3.s64 = ctx.r10.s64 + -32604;
	// bl 0x8b0df298
	ctx.lr = 0x8B0B9248;
	sub_8B0DF298(ctx, base);
	// lis r9,-29943
	ctx.r9.s64 = -1962344448;
	// lwz r4,48(r31)
	ctx.r4.u64 = REX_LOAD_U32(ctx.r31.u32 + 48);
	// addi r3,r9,-32624
	ctx.r3.s64 = ctx.r9.s64 + -32624;
	// bl 0x8b0df298
	ctx.lr = 0x8B0B9258;
	sub_8B0DF298(ctx, base);
	// lis r8,-29943
	ctx.r8.s64 = -1962344448;
	// ld r4,56(r31)
	ctx.r4.u64 = REX_LOAD_U64(ctx.r31.u32 + 56);
	// addi r3,r8,-32648
	ctx.r3.s64 = ctx.r8.s64 + -32648;
	// bl 0x8b0df298
	ctx.lr = 0x8B0B9268;
	sub_8B0DF298(ctx, base);
	// lis r7,-29944
	ctx.r7.s64 = -1962409984;
	// lfs f0,8492(r7)
	ctx.fpscr.disableFlushMode();
	temp.u32 = REX_LOAD_U32(ctx.r7.u32 + 8492);
	ctx.f0.f64 = double(temp.f32);
	// lfs f31,80(r31)
	temp.u32 = REX_LOAD_U32(ctx.r31.u32 + 80);
	ctx.f31.f64 = double(temp.f32);
	// fcmpu cr6,f31,f0
	ctx.cr6.compare(ctx.f31.f64, ctx.f0.f64);
	// beq cr6,0x8b0b9288
	if (ctx.cr6.eq) goto loc_8B0B9288;
	// bl 0x8b0df2f8
	ctx.lr = 0x8B0B9280;
	sub_8B0DF2F8(ctx, base);
	// fsub f1,f31,f1
	ctx.fpscr.disableFlushMode();
	ctx.f1.f64 = ctx.f31.f64 - ctx.f1.f64;
	// b 0x8b0b9290
	goto loc_8B0B9290;
loc_8B0B9288:
	// lis r11,-29943
	ctx.r11.s64 = -1962344448;
	// lfd f1,-32656(r11)
	ctx.fpscr.disableFlushMode();
	ctx.f1.u64 = REX_LOAD_U64(ctx.r11.u32 + -32656);
loc_8B0B9290:
	// stfd f1,24(r1)
	ctx.fpscr.disableFlushMode();
	REX_STORE_U64(ctx.r1.u32 + 24, ctx.f1.u64);
	// ld r4,24(r1)
	ctx.r4.u64 = REX_LOAD_U64(ctx.r1.u32 + 24);
	// lis r11,-29943
	ctx.r11.s64 = -1962344448;
	// addi r3,r11,-32684
	ctx.r3.s64 = ctx.r11.s64 + -32684;
	// bl 0x8b0df298
	ctx.lr = 0x8B0B92A4;
	sub_8B0DF298(ctx, base);
	// lwz r10,76(r31)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r31.u32 + 76);
	// cmplwi cr6,r10,0
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 0, ctx.xer);
	// beq cr6,0x8b0b92bc
	if (ctx.cr6.eq) goto loc_8B0B92BC;
	// lis r11,-29943
	ctx.r11.s64 = -1962344448;
	// addi r3,r11,-32728
	ctx.r3.s64 = ctx.r11.s64 + -32728;
	// b 0x8b0b92c4
	goto loc_8B0B92C4;
loc_8B0B92BC:
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// addi r3,r11,32764
	ctx.r3.s64 = ctx.r11.s64 + 32764;
loc_8B0B92C4:
	// bl 0x8b0df298
	ctx.lr = 0x8B0B92C8;
	sub_8B0DF298(ctx, base);
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// addi r3,r11,32728
	ctx.r3.s64 = ctx.r11.s64 + 32728;
	// bl 0x8b0df298
	ctx.lr = 0x8B0B92D4;
	sub_8B0DF298(ctx, base);
	// lwz r10,68(r31)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r31.u32 + 68);
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// cmplwi cr6,r10,0
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 0, ctx.xer);
	// addi r30,r11,27748
	ctx.r30.s64 = ctx.r11.s64 + 27748;
	// beq cr6,0x8b0b9300
	if (ctx.cr6.eq) goto loc_8B0B9300;
	// rotlwi r3,r10,0
	ctx.r3.u64 = __builtin_rotateleft32(ctx.r10.u32, 0);
	// lwz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r10,32(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 32);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B0B92FC;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// b 0x8b0b9308
	goto loc_8B0B9308;
loc_8B0B9300:
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// bl 0x8b0df298
	ctx.lr = 0x8B0B9308;
	sub_8B0DF298(ctx, base);
loc_8B0B9308:
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// addi r3,r11,32688
	ctx.r3.s64 = ctx.r11.s64 + 32688;
	// bl 0x8b0df298
	ctx.lr = 0x8B0B9314;
	sub_8B0DF298(ctx, base);
	// lwz r10,72(r31)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r31.u32 + 72);
	// cmplwi cr6,r10,0
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 0, ctx.xer);
	// beq cr6,0x8b0b9338
	if (ctx.cr6.eq) goto loc_8B0B9338;
	// rotlwi r3,r10,0
	ctx.r3.u64 = __builtin_rotateleft32(ctx.r10.u32, 0);
	// lwz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r10,32(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 32);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B0B9334;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// b 0x8b0b9340
	goto loc_8B0B9340;
loc_8B0B9338:
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// bl 0x8b0df298
	ctx.lr = 0x8B0B9340;
	sub_8B0DF298(ctx, base);
loc_8B0B9340:
	// addi r1,r1,112
	ctx.r1.s64 = ctx.r1.s64 + 112;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// lfd f31,-32(r1)
	ctx.fpscr.disableFlushMode();
	ctx.f31.u64 = REX_LOAD_U64(ctx.r1.u32 + -32);
	// ld r30,-24(r1)
	ctx.r30.u64 = REX_LOAD_U64(ctx.r1.u32 + -24);
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0B9860) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9b8
	ctx.lr = 0x8B0B9868;
	__savegprlr_28(ctx, base);
	// stwu r1,-384(r1)
	ea = -384 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// mr r30,r3
	ctx.r30.u64 = ctx.r3.u64;
	// mr r3,r4
	ctx.r3.u64 = ctx.r4.u64;
	// mr r31,r4
	ctx.r31.u64 = ctx.r4.u64;
	// bl 0x8b0beee8
	ctx.lr = 0x8B0B987C;
	sub_8B0BEEE8(ctx, base);
	// lis r11,-29943
	ctx.r11.s64 = -1962344448;
	// mr r29,r3
	ctx.r29.u64 = ctx.r3.u64;
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// addi r3,r11,-32216
	ctx.r3.s64 = ctx.r11.s64 + -32216;
	// bl 0x8b0cea10
	ctx.lr = 0x8B0B9890;
	sub_8B0CEA10(ctx, base);
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// beq cr6,0x8b0b98b0
	if (ctx.cr6.eq) goto loc_8B0B98B0;
	// lis r11,-29943
	ctx.r11.s64 = -1962344448;
	// mr r4,r29
	ctx.r4.u64 = ctx.r29.u64;
	// addi r3,r11,-32248
	ctx.r3.s64 = ctx.r11.s64 + -32248;
	// bl 0x8b0cea10
	ctx.lr = 0x8B0B98A8;
	sub_8B0CEA10(ctx, base);
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// bne cr6,0x8b0b9950
	if (!ctx.cr6.eq) goto loc_8B0B9950;
loc_8B0B98B0:
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// li r5,0
	ctx.r5.s64 = 0;
	// addi r4,r11,28028
	ctx.r4.s64 = ctx.r11.s64 + 28028;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0bfa88
	ctx.lr = 0x8B0B98C4;
	sub_8B0BFA88(ctx, base);
	// mr r28,r3
	ctx.r28.u64 = ctx.r3.u64;
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// bne cr6,0x8b0b98e0
	if (!ctx.cr6.eq) goto loc_8B0B98E0;
	// bl 0x8b0b90d8
	ctx.lr = 0x8B0B98D8;
	sub_8B0B90D8(ctx, base);
	// addi r1,r1,384
	ctx.r1.s64 = ctx.r1.s64 + 384;
	// b 0x8b0cba08
	__restgprlr_28(ctx, base);
	return;
loc_8B0B98E0:
	// bl 0x8b0b9170
	ctx.lr = 0x8B0B98E4;
	sub_8B0B9170(ctx, base);
	// li r3,36
	ctx.r3.s64 = 36;
	// bl 0x8b0bf448
	ctx.lr = 0x8B0B98EC;
	sub_8B0BF448(ctx, base);
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0b9950
	if (ctx.cr6.eq) goto loc_8B0B9950;
	// lis r11,-29943
	ctx.r11.s64 = -1962344448;
	// addi r5,r29,16
	ctx.r5.s64 = ctx.r29.s64 + 16;
	// addi r4,r11,-32272
	ctx.r4.s64 = ctx.r11.s64 + -32272;
	// addi r3,r1,80
	ctx.r3.s64 = ctx.r1.s64 + 80;
	// bl 0x8b090220
	ctx.lr = 0x8B0B990C;
	sub_8B090220(ctx, base);
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0bf9f8
	ctx.lr = 0x8B0B9918;
	sub_8B0BF9F8(ctx, base);
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0b9950
	if (ctx.cr6.eq) goto loc_8B0B9950;
	// mr r3,r28
	ctx.r3.u64 = ctx.r28.u64;
	// bl 0x8b0c0298
	ctx.lr = 0x8B0B992C;
	sub_8B0C0298(ctx, base);
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0bfc00
	ctx.lr = 0x8B0B9938;
	sub_8B0BFC00(ctx, base);
	// lwz r11,0(r30)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r30.u32 + 0);
	// mr r4,r31
	ctx.r4.u64 = ctx.r31.u64;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// lwz r10,48(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 48);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B0B9950;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
loc_8B0B9950:
	// addi r1,r1,384
	ctx.r1.s64 = ctx.r1.s64 + 384;
	// b 0x8b0cba08
	__restgprlr_28(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0B9EC8) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9bc
	ctx.lr = 0x8B0B9ED0;
	__savegprlr_29(ctx, base);
	// stwu r1,-112(r1)
	ea = -112 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// mr r3,r4
	ctx.r3.u64 = ctx.r4.u64;
	// mr r30,r4
	ctx.r30.u64 = ctx.r4.u64;
	// bl 0x8b0beee8
	ctx.lr = 0x8B0B9EE4;
	sub_8B0BEEE8(ctx, base);
	// lis r11,-29943
	ctx.r11.s64 = -1962344448;
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// addi r3,r11,-32072
	ctx.r3.s64 = ctx.r11.s64 + -32072;
	// bl 0x8b0cea10
	ctx.lr = 0x8B0B9EF4;
	sub_8B0CEA10(ctx, base);
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// bne cr6,0x8b0ba010
	if (!ctx.cr6.eq) goto loc_8B0BA010;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// bl 0x8b0bf248
	ctx.lr = 0x8B0B9F04;
	sub_8B0BF248(ctx, base);
	// lwz r11,64(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 64);
	// mr r30,r3
	ctx.r30.u64 = ctx.r3.u64;
	// mr r3,r11
	ctx.r3.u64 = ctx.r11.u64;
	// lwz r10,0(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 0);
	// lwz r9,4(r10)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r10.u32 + 4);
	// mtctr r9
	ctx.ctr.u64 = ctx.r9.u64;
	// bctrl 
	ctx.lr = 0x8B0B9F20;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// lis r8,-29938
	ctx.r8.s64 = -1962016768;
	// mr r29,r3
	ctx.r29.u64 = ctx.r3.u64;
	// lwz r3,3036(r8)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r8.u32 + 3036);
	// lwz r7,0(r3)
	ctx.r7.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r6,64(r7)
	ctx.r6.u64 = REX_LOAD_U32(ctx.r7.u32 + 64);
	// mtctr r6
	ctx.ctr.u64 = ctx.r6.u64;
	// bctrl 
	ctx.lr = 0x8B0B9F3C;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// lwz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// mr r5,r30
	ctx.r5.u64 = ctx.r30.u64;
	// mr r4,r29
	ctx.r4.u64 = ctx.r29.u64;
	// lwz r10,44(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 44);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B0B9F54;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// mr r30,r3
	ctx.r30.u64 = ctx.r3.u64;
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0b9ff4
	if (ctx.cr6.eq) goto loc_8B0B9FF4;
	// li r3,36
	ctx.r3.s64 = 36;
	// bl 0x8b0bf448
	ctx.lr = 0x8B0B9F68;
	sub_8B0BF448(ctx, base);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0b9fcc
	if (ctx.cr6.eq) goto loc_8B0B9FCC;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// lis r9,-29943
	ctx.r9.s64 = -1962344448;
	// addi r6,r11,3904
	ctx.r6.s64 = ctx.r11.s64 + 3904;
	// addi r5,r10,3900
	ctx.r5.s64 = ctx.r10.s64 + 3900;
	// addi r4,r9,-32112
	ctx.r4.s64 = ctx.r9.s64 + -32112;
	// bl 0x8b0c1300
	ctx.lr = 0x8B0B9F8C;
	sub_8B0C1300(ctx, base);
	// mr r29,r3
	ctx.r29.u64 = ctx.r3.u64;
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0b9fcc
	if (ctx.cr6.eq) goto loc_8B0B9FCC;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// bl 0x8b0c0298
	ctx.lr = 0x8B0B9FA0;
	sub_8B0C0298(ctx, base);
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// mr r3,r29
	ctx.r3.u64 = ctx.r29.u64;
	// bl 0x8b0bfc00
	ctx.lr = 0x8B0B9FAC;
	sub_8B0BFC00(ctx, base);
	// lwz r3,72(r31)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r31.u32 + 72);
	// mr r4,r29
	ctx.r4.u64 = ctx.r29.u64;
	// lwz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r10,24(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 24);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B0B9FC4;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// mr r3,r29
	ctx.r3.u64 = ctx.r29.u64;
	// bl 0x8b0c04f0
	ctx.lr = 0x8B0B9FCC;
	sub_8B0C04F0(ctx, base);
loc_8B0B9FCC:
	// li r5,0
	ctx.r5.s64 = 0;
	// lwz r3,8(r31)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r31.u32 + 8);
	// mr r4,r30
	ctx.r4.u64 = ctx.r30.u64;
	// bl 0x8b0c0668
	ctx.lr = 0x8B0B9FDC;
	sub_8B0C0668(ctx, base);
	// lwz r3,84(r31)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r31.u32 + 84);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0b9fec
	if (ctx.cr6.eq) goto loc_8B0B9FEC;
	// bl 0x8b0c04f0
	ctx.lr = 0x8B0B9FEC;
	sub_8B0C04F0(ctx, base);
loc_8B0B9FEC:
	// stw r30,84(r31)
	REX_STORE_U32(ctx.r31.u32 + 84, ctx.r30.u32);
	// stw r30,88(r31)
	REX_STORE_U32(ctx.r31.u32 + 88, ctx.r30.u32);
loc_8B0B9FF4:
	// lwz r11,48(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 48);
	// cmpwi cr6,r11,5
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 5, ctx.xer);
	// bne cr6,0x8b0ba01c
	if (!ctx.cr6.eq) goto loc_8B0BA01C;
	// li r11,6
	ctx.r11.s64 = 6;
	// stw r11,48(r31)
	REX_STORE_U32(ctx.r31.u32 + 48, ctx.r11.u32);
	// addi r1,r1,112
	ctx.r1.s64 = ctx.r1.s64 + 112;
	// b 0x8b0cba0c
	__restgprlr_29(ctx, base);
	return;
loc_8B0BA010:
	// mr r4,r30
	ctx.r4.u64 = ctx.r30.u64;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0b9860
	ctx.lr = 0x8B0BA01C;
	sub_8B0B9860(ctx, base);
loc_8B0BA01C:
	// addi r1,r1,112
	ctx.r1.s64 = ctx.r1.s64 + 112;
	// b 0x8b0cba0c
	__restgprlr_29(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0BA3B0) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9b8
	ctx.lr = 0x8B0BA3B8;
	__savegprlr_28(ctx, base);
	// stwu r1,-128(r1)
	ea = -128 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lwz r11,48(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 48);
	// mr r29,r3
	ctx.r29.u64 = ctx.r3.u64;
	// cmpwi cr6,r11,5
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 5, ctx.xer);
	// beq cr6,0x8b0ba534
	if (ctx.cr6.eq) goto loc_8B0BA534;
	// cmpwi cr6,r11,6
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 6, ctx.xer);
	// beq cr6,0x8b0ba3e0
	if (ctx.cr6.eq) goto loc_8B0BA3E0;
	// bl 0x8b0ba228
	ctx.lr = 0x8B0BA3D8;
	sub_8B0BA228(ctx, base);
	// addi r1,r1,128
	ctx.r1.s64 = ctx.r1.s64 + 128;
	// b 0x8b0cba08
	__restgprlr_28(ctx, base);
	return;
loc_8B0BA3E0:
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lwz r3,8(r29)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r29.u32 + 8);
	// lis r10,-29943
	ctx.r10.s64 = -1962344448;
	// addi r31,r11,1791
	ctx.r31.s64 = ctx.r11.s64 + 1791;
	// addi r30,r10,-32156
	ctx.r30.s64 = ctx.r10.s64 + -32156;
	// mr r5,r31
	ctx.r5.u64 = ctx.r31.u64;
	// mr r4,r30
	ctx.r4.u64 = ctx.r30.u64;
	// bl 0x8b0c1588
	ctx.lr = 0x8B0BA400;
	sub_8B0C1588(ctx, base);
	// lwz r9,64(r29)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r29.u32 + 64);
	// mr r28,r3
	ctx.r28.u64 = ctx.r3.u64;
	// mr r3,r9
	ctx.r3.u64 = ctx.r9.u64;
	// lwz r8,0(r9)
	ctx.r8.u64 = REX_LOAD_U32(ctx.r9.u32 + 0);
	// lwz r7,4(r8)
	ctx.r7.u64 = REX_LOAD_U32(ctx.r8.u32 + 4);
	// mtctr r7
	ctx.ctr.u64 = ctx.r7.u64;
	// bctrl 
	ctx.lr = 0x8B0BA41C;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// mr r4,r30
	ctx.r4.u64 = ctx.r30.u64;
	// mr r5,r31
	ctx.r5.u64 = ctx.r31.u64;
	// bl 0x8b0c1588
	ctx.lr = 0x8B0BA428;
	sub_8B0C1588(ctx, base);
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// mr r30,r3
	ctx.r30.u64 = ctx.r3.u64;
	// addi r31,r11,10100
	ctx.r31.s64 = ctx.r11.s64 + 10100;
	// mr r3,r28
	ctx.r3.u64 = ctx.r28.u64;
	// mr r4,r31
	ctx.r4.u64 = ctx.r31.u64;
	// bl 0x8b0cea10
	ctx.lr = 0x8B0BA440;
	sub_8B0CEA10(ctx, base);
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// beq cr6,0x8b0ba4cc
	if (ctx.cr6.eq) goto loc_8B0BA4CC;
	// mr r4,r31
	ctx.r4.u64 = ctx.r31.u64;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// bl 0x8b0cea10
	ctx.lr = 0x8B0BA454;
	sub_8B0CEA10(ctx, base);
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// bne cr6,0x8b0ba4cc
	if (!ctx.cr6.eq) goto loc_8B0BA4CC;
	// li r3,36
	ctx.r3.s64 = 36;
	// bl 0x8b0bf448
	ctx.lr = 0x8B0BA464;
	sub_8B0BF448(ctx, base);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0ba490
	if (ctx.cr6.eq) goto loc_8B0BA490;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// lis r9,-29943
	ctx.r9.s64 = -1962344448;
	// addi r6,r11,3904
	ctx.r6.s64 = ctx.r11.s64 + 3904;
	// addi r5,r10,3900
	ctx.r5.s64 = ctx.r10.s64 + 3900;
	// addi r4,r9,-32188
	ctx.r4.s64 = ctx.r9.s64 + -32188;
	// bl 0x8b0c1300
	ctx.lr = 0x8B0BA488;
	sub_8B0C1300(ctx, base);
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// b 0x8b0ba494
	goto loc_8B0BA494;
loc_8B0BA490:
	// li r31,0
	ctx.r31.s64 = 0;
loc_8B0BA494:
	// lwz r3,72(r29)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r29.u32 + 72);
	// mr r4,r31
	ctx.r4.u64 = ctx.r31.u64;
	// lwz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r10,24(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 24);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B0BA4AC;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// cmplwi cr6,r31,0
	ctx.cr6.compare<uint32_t>(ctx.r31.u32, 0, ctx.xer);
	// beq cr6,0x8b0ba4bc
	if (ctx.cr6.eq) goto loc_8B0BA4BC;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0c04f0
	ctx.lr = 0x8B0BA4BC;
	sub_8B0C04F0(ctx, base);
loc_8B0BA4BC:
	// mr r3,r29
	ctx.r3.u64 = ctx.r29.u64;
	// bl 0x8b0b9958
	ctx.lr = 0x8B0BA4C4;
	sub_8B0B9958(ctx, base);
	// addi r1,r1,128
	ctx.r1.s64 = ctx.r1.s64 + 128;
	// b 0x8b0cba08
	__restgprlr_28(ctx, base);
	return;
loc_8B0BA4CC:
	// li r3,36
	ctx.r3.s64 = 36;
	// bl 0x8b0bf448
	ctx.lr = 0x8B0BA4D4;
	sub_8B0BF448(ctx, base);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0ba500
	if (ctx.cr6.eq) goto loc_8B0BA500;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// lis r9,-29943
	ctx.r9.s64 = -1962344448;
	// addi r6,r11,3904
	ctx.r6.s64 = ctx.r11.s64 + 3904;
	// addi r5,r10,3900
	ctx.r5.s64 = ctx.r10.s64 + 3900;
	// addi r4,r9,-32140
	ctx.r4.s64 = ctx.r9.s64 + -32140;
	// bl 0x8b0c1300
	ctx.lr = 0x8B0BA4F8;
	sub_8B0C1300(ctx, base);
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// b 0x8b0ba504
	goto loc_8B0BA504;
loc_8B0BA500:
	// li r31,0
	ctx.r31.s64 = 0;
loc_8B0BA504:
	// lwz r3,72(r29)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r29.u32 + 72);
	// mr r4,r31
	ctx.r4.u64 = ctx.r31.u64;
	// lwz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r10,24(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 24);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B0BA51C;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// cmplwi cr6,r31,0
	ctx.cr6.compare<uint32_t>(ctx.r31.u32, 0, ctx.xer);
	// beq cr6,0x8b0ba52c
	if (ctx.cr6.eq) goto loc_8B0BA52C;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0c04f0
	ctx.lr = 0x8B0BA52C;
	sub_8B0C04F0(ctx, base);
loc_8B0BA52C:
	// mr r3,r29
	ctx.r3.u64 = ctx.r29.u64;
	// bl 0x8b0b94a0
	ctx.lr = 0x8B0BA534;
	sub_8B0B94A0(ctx, base);
loc_8B0BA534:
	// addi r1,r1,128
	ctx.r1.s64 = ctx.r1.s64 + 128;
	// b 0x8b0cba08
	__restgprlr_28(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0BADD0) {
	REX_FUNC_PROLOGUE();
	// lwz r11,784(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 784);
	// addi r11,r11,-6
	ctx.r11.s64 = ctx.r11.s64 + -6;
	// cntlzw r10,r11
	ctx.r10.u64 = ctx.r11.u32 == 0 ? 32 : __builtin_clz(ctx.r11.u32);
	// rlwinm r3,r10,27,31,31
	ctx.r3.u64 = __builtin_rotateleft64(ctx.r10.u32 | (ctx.r10.u64 << 32), 27) & 0x1;
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0BADE8) {
	REX_FUNC_PROLOGUE();
	// addi r3,r3,788
	ctx.r3.s64 = ctx.r3.s64 + 788;
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0BADF0) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// std r30,-24(r1)
	REX_STORE_U64(ctx.r1.u32 + -24, ctx.r30.u64);
	// std r31,-16(r1)
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.r31.u64);
	// stwu r1,-112(r1)
	ea = -112 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// mr r30,r4
	ctx.r30.u64 = ctx.r4.u64;
	// mr r3,r4
	ctx.r3.u64 = ctx.r4.u64;
	// addi r5,r11,26576
	ctx.r5.s64 = ctx.r11.s64 + 26576;
	// addi r4,r10,28004
	ctx.r4.s64 = ctx.r10.s64 + 28004;
	// bl 0x8b0c0010
	ctx.lr = 0x8B0BAE24;
	sub_8B0C0010(ctx, base);
	// lis r9,-29943
	ctx.r9.s64 = -1962344448;
	// addi r5,r31,258
	ctx.r5.s64 = ctx.r31.s64 + 258;
	// addi r4,r9,-31592
	ctx.r4.s64 = ctx.r9.s64 + -31592;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// bl 0x8b0c0010
	ctx.lr = 0x8B0BAE38;
	sub_8B0C0010(ctx, base);
	// addi r1,r1,112
	ctx.r1.s64 = ctx.r1.s64 + 112;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// ld r30,-24(r1)
	ctx.r30.u64 = REX_LOAD_U64(ctx.r1.u32 + -24);
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0BB090) {
	REX_FUNC_PROLOGUE();
	PPCRegister temp{};
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// std r31,-16(r1)
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.r31.u64);
	// stfd f31,-24(r1)
	ctx.fpscr.disableFlushMode();
	REX_STORE_U64(ctx.r1.u32 + -24, ctx.f31.u64);
	// stwu r1,-112(r1)
	ea = -112 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lis r11,-29938
	ctx.r11.s64 = -1962016768;
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// addi r10,r11,22288
	ctx.r10.s64 = ctx.r11.s64 + 22288;
	// lwz r11,28(r10)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r10.u32 + 28);
	// lwz r9,48(r11)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r11.u32 + 48);
	// cmpwi cr6,r9,0
	ctx.cr6.compare<int32_t>(ctx.r9.s32, 0, ctx.xer);
	// beq cr6,0x8b0bb0f0
	if (ctx.cr6.eq) goto loc_8B0BB0F0;
	// lis r11,-29938
	ctx.r11.s64 = -1962016768;
	// addi r10,r11,22072
	ctx.r10.s64 = ctx.r11.s64 + 22072;
	// lwz r11,28(r10)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r10.u32 + 28);
	// lfs f31,44(r11)
	temp.u32 = REX_LOAD_U32(ctx.r11.u32 + 44);
	ctx.f31.f64 = double(temp.f32);
	// bl 0x8b0df2f8
	ctx.lr = 0x8B0BB0D4;
	sub_8B0DF2F8(ctx, base);
	// fadd f0,f1,f31
	ctx.fpscr.disableFlushMode();
	ctx.f0.f64 = ctx.f1.f64 + ctx.f31.f64;
	// li r11,1
	ctx.r11.s64 = 1;
	// stw r11,784(r31)
	REX_STORE_U32(ctx.r31.u32 + 784, ctx.r11.u32);
	// stb r11,788(r31)
	REX_STORE_U8(ctx.r31.u32 + 788, ctx.r11.u8);
	// frsp f13,f0
	ctx.f13.f64 = double(float(ctx.f0.f64));
	// stfs f13,8(r31)
	temp.f32 = float(ctx.f13.f64);
	REX_STORE_U32(ctx.r31.u32 + 8, temp.u32);
	// b 0x8b0bb0f8
	goto loc_8B0BB0F8;
loc_8B0BB0F0:
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0bae50
	ctx.lr = 0x8B0BB0F8;
	sub_8B0BAE50(ctx, base);
loc_8B0BB0F8:
	// addi r1,r1,112
	ctx.r1.s64 = ctx.r1.s64 + 112;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// lfd f31,-24(r1)
	ctx.fpscr.disableFlushMode();
	ctx.f31.u64 = REX_LOAD_U64(ctx.r1.u32 + -24);
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0BB1E8) {
	REX_FUNC_PROLOGUE();
	PPCRegister temp{};
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9b0
	ctx.lr = 0x8B0BB1F0;
	__savegprlr_26(ctx, base);
	// stfd f31,-64(r1)
	ctx.fpscr.disableFlushMode();
	REX_STORE_U64(ctx.r1.u32 + -64, ctx.f31.u64);
	// stwu r1,-1424(r1)
	ea = -1424 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lwz r11,32(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 32);
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// cmpwi cr6,r11,0
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// bne cr6,0x8b0bb21c
	if (!ctx.cr6.eq) goto loc_8B0BB21C;
	// li r11,6
	ctx.r11.s64 = 6;
	// stw r11,784(r3)
	REX_STORE_U32(ctx.r3.u32 + 784, ctx.r11.u32);
	// addi r1,r1,1424
	ctx.r1.s64 = ctx.r1.s64 + 1424;
	// lfd f31,-64(r1)
	ctx.f31.u64 = REX_LOAD_U64(ctx.r1.u32 + -64);
	// b 0x8b0cba00
	__restgprlr_26(ctx, base);
	return;
loc_8B0BB21C:
	// addi r27,r31,296
	ctx.r27.s64 = ctx.r31.s64 + 296;
	// lwz r4,20(r31)
	ctx.r4.u64 = REX_LOAD_U32(ctx.r31.u32 + 20);
	// li r5,448
	ctx.r5.s64 = 448;
	// mr r3,r27
	ctx.r3.u64 = ctx.r27.u64;
	// addi r30,r31,20
	ctx.r30.s64 = ctx.r31.s64 + 20;
	// bl 0x8b0cbb30
	ctx.lr = 0x8B0BB234;
	sub_8B0CBB30(ctx, base);
	// lwz r11,32(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 32);
	// addic. r11,r11,-1
	ctx.xer.ca = ctx.r11.u32 > 0;
	ctx.r11.s64 = ctx.r11.s64 + -1;
	ctx.cr0.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// ble 0x8b0bb250
	if (!ctx.cr0.gt) goto loc_8B0BB250;
	// lwz r3,0(r30)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r30.u32 + 0);
	// mulli r5,r11,448
	ctx.r5.s64 = static_cast<int64_t>(ctx.r11.u64 * static_cast<uint64_t>(448));
	// addi r4,r3,448
	ctx.r4.s64 = ctx.r3.s64 + 448;
	// bl 0x8b0cc060
	ctx.lr = 0x8B0BB250;
	sub_8B0CC060(ctx, base);
loc_8B0BB250:
	// lis r10,-29938
	ctx.r10.s64 = -1962016768;
	// lwz r11,12(r30)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r30.u32 + 12);
	// addi r9,r10,21176
	ctx.r9.s64 = ctx.r10.s64 + 21176;
	// addi r8,r11,-1
	ctx.r8.s64 = ctx.r11.s64 + -1;
	// stw r8,12(r30)
	REX_STORE_U32(ctx.r30.u32 + 12, ctx.r8.u32);
	// lwz r11,28(r9)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r9.u32 + 28);
	// lfs f31,44(r11)
	ctx.fpscr.disableFlushMode();
	temp.u32 = REX_LOAD_U32(ctx.r11.u32 + 44);
	ctx.f31.f64 = double(temp.f32);
	// bl 0x8b0df2f8
	ctx.lr = 0x8B0BB270;
	sub_8B0DF2F8(ctx, base);
	// fadd f0,f1,f31
	ctx.fpscr.disableFlushMode();
	ctx.f0.f64 = ctx.f1.f64 + ctx.f31.f64;
	// lhz r7,518(r31)
	ctx.r7.u64 = REX_LOAD_U16(ctx.r31.u32 + 518);
	// lwz r11,524(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 524);
	// lis r10,-29943
	ctx.r10.s64 = -1962344448;
	// lwz r30,520(r31)
	ctx.r30.u64 = REX_LOAD_U32(ctx.r31.u32 + 520);
	// addi r4,r31,528
	ctx.r4.s64 = ctx.r31.s64 + 528;
	// lhz r29,516(r31)
	ctx.r29.u64 = REX_LOAD_U16(ctx.r31.u32 + 516);
	// addi r3,r10,-31464
	ctx.r3.s64 = ctx.r10.s64 + -31464;
	// lhz r10,508(r31)
	ctx.r10.u64 = REX_LOAD_U16(ctx.r31.u32 + 508);
	// lhz r9,506(r31)
	ctx.r9.u64 = REX_LOAD_U16(ctx.r31.u32 + 506);
	// lwz r8,736(r31)
	ctx.r8.u64 = REX_LOAD_U32(ctx.r31.u32 + 736);
	// lwz r6,732(r31)
	ctx.r6.u64 = REX_LOAD_U32(ctx.r31.u32 + 732);
	// lwz r5,728(r31)
	ctx.r5.u64 = REX_LOAD_U32(ctx.r31.u32 + 728);
	// stw r7,92(r1)
	REX_STORE_U32(ctx.r1.u32 + 92, ctx.r7.u32);
	// frsp f13,f0
	ctx.f13.f64 = double(float(ctx.f0.f64));
	// stfs f13,8(r31)
	temp.f32 = float(ctx.f13.f64);
	REX_STORE_U32(ctx.r31.u32 + 8, temp.u32);
	// stw r11,108(r1)
	REX_STORE_U32(ctx.r1.u32 + 108, ctx.r11.u32);
	// stw r30,100(r1)
	REX_STORE_U32(ctx.r1.u32 + 100, ctx.r30.u32);
	// stw r29,84(r1)
	REX_STORE_U32(ctx.r1.u32 + 84, ctx.r29.u32);
	// bl 0x8b0df298
	ctx.lr = 0x8B0BB2C0;
	sub_8B0DF298(ctx, base);
	// lis r9,-29936
	ctx.r9.s64 = -1961885696;
	// lwz r3,-17796(r9)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r9.u32 + -17796);
	// lwz r8,0(r3)
	ctx.r8.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r7,32(r8)
	ctx.r7.u64 = REX_LOAD_U32(ctx.r8.u32 + 32);
	// mtctr r7
	ctx.ctr.u64 = ctx.r7.u64;
	// bctrl 
	ctx.lr = 0x8B0BB2D8;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// lis r29,-29938
	ctx.r29.s64 = -1962016768;
	// lwz r6,0(r3)
	ctx.r6.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// addi r30,r31,740
	ctx.r30.s64 = ctx.r31.s64 + 740;
	// lwz r11,2364(r29)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r29.u32 + 2364);
	// lwz r5,4(r6)
	ctx.r5.u64 = REX_LOAD_U32(ctx.r6.u32 + 4);
	// lwz r26,104(r11)
	ctx.r26.u64 = REX_LOAD_U32(ctx.r11.u32 + 104);
	// mtctr r5
	ctx.ctr.u64 = ctx.r5.u64;
	// lwz r28,0(r26)
	ctx.r28.u64 = REX_LOAD_U32(ctx.r26.u32 + 0);
	// bctrl 
	ctx.lr = 0x8B0BB2FC;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// lwz r11,36(r28)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r28.u32 + 36);
	// rotlwi r5,r3,0
	ctx.r5.u64 = __builtin_rotateleft32(ctx.r3.u32, 0);
	// mr r3,r26
	ctx.r3.u64 = ctx.r26.u64;
	// lwz r4,0(r27)
	ctx.r4.u64 = REX_LOAD_U32(ctx.r27.u32 + 0);
	// mr r6,r30
	ctx.r6.u64 = ctx.r30.u64;
	// mtctr r11
	ctx.ctr.u64 = ctx.r11.u64;
	// bctrl 
	ctx.lr = 0x8B0BB318;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0bb33c
	if (ctx.cr6.eq) goto loc_8B0BB33C;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// addi r3,r11,31356
	ctx.r3.s64 = ctx.r11.s64 + 31356;
	// bl 0x8b0df2e8
	ctx.lr = 0x8B0BB330;
	sub_8B0DF2E8(ctx, base);
	// addi r1,r1,1424
	ctx.r1.s64 = ctx.r1.s64 + 1424;
	// lfd f31,-64(r1)
	ctx.fpscr.disableFlushMode();
	ctx.f31.u64 = REX_LOAD_U64(ctx.r1.u32 + -64);
	// b 0x8b0cba00
	__restgprlr_26(ctx, base);
	return;
loc_8B0BB33C:
	// li r4,0
	ctx.r4.s64 = 0;
	// addi r3,r1,112
	ctx.r3.s64 = ctx.r1.s64 + 112;
	// bl 0x8b0c72a8
	ctx.lr = 0x8B0BB348;
	sub_8B0C72A8(ctx, base);
	// li r4,0
	ctx.r4.s64 = 0;
	// addi r3,r1,112
	ctx.r3.s64 = ctx.r1.s64 + 112;
	// bl 0x8b0c72d0
	ctx.lr = 0x8B0BB354;
	sub_8B0C72D0(ctx, base);
	// li r4,3
	ctx.r4.s64 = 3;
	// addi r3,r1,112
	ctx.r3.s64 = ctx.r1.s64 + 112;
	// bl 0x8b0c72b0
	ctx.lr = 0x8B0BB360;
	sub_8B0C72B0(ctx, base);
	// li r4,3
	ctx.r4.s64 = 3;
	// addi r3,r1,112
	ctx.r3.s64 = ctx.r1.s64 + 112;
	// bl 0x8b0c72b0
	ctx.lr = 0x8B0BB36C;
	sub_8B0C72B0(ctx, base);
	// lwz r11,732(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 732);
	// li r3,0
	ctx.r3.s64 = 0;
	// addi r4,r11,-1
	ctx.r4.s64 = ctx.r11.s64 + -1;
	// bl 0x8b0df558
	ctx.lr = 0x8B0BB37C;
	sub_8B0DF558(ctx, base);
	// lwz r11,728(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 728);
	// lwz r4,0(r30)
	ctx.r4.u64 = REX_LOAD_U32(ctx.r30.u32 + 0);
	// add r10,r3,r11
	ctx.r10.u64 = ctx.r3.u64 + ctx.r11.u64;
	// addi r3,r1,112
	ctx.r3.s64 = ctx.r1.s64 + 112;
	// clrlwi r28,r10,16
	ctx.r28.u64 = ctx.r10.u32 & 0xFFFF;
	// bl 0x8b0c72a8
	ctx.lr = 0x8B0BB394;
	sub_8B0C72A8(ctx, base);
	// mr r4,r28
	ctx.r4.u64 = ctx.r28.u64;
	// addi r3,r1,112
	ctx.r3.s64 = ctx.r1.s64 + 112;
	// bl 0x8b0c72d0
	ctx.lr = 0x8B0BB3A0;
	sub_8B0C72D0(ctx, base);
	// li r6,-1
	ctx.r6.s64 = -1;
	// li r5,1200
	ctx.r5.s64 = 1200;
	// addi r4,r1,160
	ctx.r4.s64 = ctx.r1.s64 + 160;
	// addi r3,r1,128
	ctx.r3.s64 = ctx.r1.s64 + 128;
	// bl 0x8b0c9ee0
	ctx.lr = 0x8B0BB3B4;
	sub_8B0C9EE0(ctx, base);
	// li r4,49
	ctx.r4.s64 = 49;
	// addi r3,r1,128
	ctx.r3.s64 = ctx.r1.s64 + 128;
	// bl 0x8b0c9ed0
	ctx.lr = 0x8B0BB3C0;
	sub_8B0C9ED0(ctx, base);
	// li r4,10
	ctx.r4.s64 = 10;
	// addi r3,r1,128
	ctx.r3.s64 = ctx.r1.s64 + 128;
	// bl 0x8b0c9ed0
	ctx.lr = 0x8B0BB3CC;
	sub_8B0C9ED0(ctx, base);
	// li r4,0
	ctx.r4.s64 = 0;
	// addi r3,r1,128
	ctx.r3.s64 = ctx.r1.s64 + 128;
	// bl 0x8b0ca230
	ctx.lr = 0x8B0BB3D8;
	sub_8B0CA230(ctx, base);
	// addi r3,r1,128
	ctx.r3.s64 = ctx.r1.s64 + 128;
	// lwz r4,0(r30)
	ctx.r4.u64 = REX_LOAD_U32(ctx.r30.u32 + 0);
	// bl 0x8b0ca230
	ctx.lr = 0x8B0BB3E4;
	sub_8B0CA230(ctx, base);
	// addi r4,r31,36
	ctx.r4.s64 = ctx.r31.s64 + 36;
	// addi r3,r1,128
	ctx.r3.s64 = ctx.r1.s64 + 128;
	// bl 0x8b0ca240
	ctx.lr = 0x8B0BB3F0;
	sub_8B0CA240(ctx, base);
	// li r4,10
	ctx.r4.s64 = 10;
	// addi r3,r1,128
	ctx.r3.s64 = ctx.r1.s64 + 128;
	// bl 0x8b0c9ed0
	ctx.lr = 0x8B0BB3FC;
	sub_8B0C9ED0(ctx, base);
	// lwz r11,2364(r29)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r29.u32 + 2364);
	// lwz r8,140(r1)
	ctx.r8.u64 = REX_LOAD_U32(ctx.r1.u32 + 140);
	// li r10,0
	ctx.r10.s64 = 0;
	// li r9,0
	ctx.r9.s64 = 0;
	// lwz r7,128(r1)
	ctx.r7.u64 = REX_LOAD_U32(ctx.r1.u32 + 128);
	// addi r6,r1,112
	ctx.r6.s64 = ctx.r1.s64 + 112;
	// li r5,0
	ctx.r5.s64 = 0;
	// lwz r3,76(r11)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r11.u32 + 76);
	// addi r11,r8,7
	ctx.r11.s64 = ctx.r8.s64 + 7;
	// li r4,0
	ctx.r4.s64 = 0;
	// srawi r8,r11,3
	ctx.xer.ca = (ctx.r11.s32 < 0) & ((ctx.r11.u32 & 0x7) != 0);
	ctx.r8.s64 = ctx.r11.s32 >> 3;
	// lwz r30,0(r3)
	ctx.r30.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r11,56(r30)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r30.u32 + 56);
	// mtctr r11
	ctx.ctr.u64 = ctx.r11.u64;
	// bctrl 
	ctx.lr = 0x8B0BB438;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// li r10,4
	ctx.r10.s64 = 4;
	// stw r10,784(r31)
	REX_STORE_U32(ctx.r31.u32 + 784, ctx.r10.u32);
	// addi r1,r1,1424
	ctx.r1.s64 = ctx.r1.s64 + 1424;
	// lfd f31,-64(r1)
	ctx.fpscr.disableFlushMode();
	ctx.f31.u64 = REX_LOAD_U64(ctx.r1.u32 + -64);
	// b 0x8b0cba00
	__restgprlr_26(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0BC030) {
	REX_FUNC_PROLOGUE();
	PPCRegister temp{};
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9b8
	ctx.lr = 0x8B0BC038;
	__savegprlr_28(ctx, base);
	// stwu r1,-128(r1)
	ea = -128 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lwz r11,784(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 784);
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// cmplwi cr6,r11,4
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 4, ctx.xer);
	// bgt cr6,0x8b0bc19c
	if (ctx.cr6.gt) goto loc_8B0BC19C;
	// mtctr r11
	ctx.ctr.u64 = ctx.r11.u64;
	// cmpwi cr6,r11,0
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// bdzf 4*cr6+eq,0x8b0bc110
	--ctx.ctr.u64;
	if (ctx.ctr.u32 == 0 && !ctx.cr6.eq) goto loc_8B0BC110;
	// bdzf 4*cr6+eq,0x8b0bc130
	--ctx.ctr.u64;
	if (ctx.ctr.u32 == 0 && !ctx.cr6.eq) goto loc_8B0BC130;
	// bdzf 4*cr6+eq,0x8b0bc15c
	--ctx.ctr.u64;
	if (ctx.ctr.u32 == 0 && !ctx.cr6.eq) goto loc_8B0BC15C;
	// bne cr6,0x8b0bc16c
	if (!ctx.cr6.eq) goto loc_8B0BC16C;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lwz r3,760(r31)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r31.u32 + 760);
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// addi r5,r11,1791
	ctx.r5.s64 = ctx.r11.s64 + 1791;
	// addi r4,r10,3720
	ctx.r4.s64 = ctx.r10.s64 + 3720;
	// bl 0x8b0c1588
	ctx.lr = 0x8B0BC07C;
	sub_8B0C1588(ctx, base);
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lis r9,-29943
	ctx.r9.s64 = -1962344448;
	// addi r30,r11,10100
	ctx.r30.s64 = ctx.r11.s64 + 10100;
	// addi r4,r9,-32156
	ctx.r4.s64 = ctx.r9.s64 + -32156;
	// mr r5,r30
	ctx.r5.u64 = ctx.r30.u64;
	// mr r29,r3
	ctx.r29.u64 = ctx.r3.u64;
	// lwz r3,760(r31)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r31.u32 + 760);
	// bl 0x8b0c1588
	ctx.lr = 0x8B0BC09C;
	sub_8B0C1588(ctx, base);
	// lis r8,-29944
	ctx.r8.s64 = -1962409984;
	// li r5,0
	ctx.r5.s64 = 0;
	// addi r4,r8,4588
	ctx.r4.s64 = ctx.r8.s64 + 4588;
	// mr r28,r3
	ctx.r28.u64 = ctx.r3.u64;
	// lwz r3,760(r31)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r31.u32 + 760);
	// bl 0x8b0c1588
	ctx.lr = 0x8B0BC0B4;
	sub_8B0C1588(ctx, base);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// bne cr6,0x8b0bc120
	if (!ctx.cr6.eq) goto loc_8B0BC120;
	// lis r11,-29938
	ctx.r11.s64 = -1962016768;
	// addi r10,r11,22360
	ctx.r10.s64 = ctx.r11.s64 + 22360;
	// lwz r11,28(r10)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r10.u32 + 28);
	// lwz r9,48(r11)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r11.u32 + 48);
	// cmpwi cr6,r9,0
	ctx.cr6.compare<int32_t>(ctx.r9.s32, 0, ctx.xer);
	// beq cr6,0x8b0bc120
	if (ctx.cr6.eq) goto loc_8B0BC120;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// mr r4,r29
	ctx.r4.u64 = ctx.r29.u64;
	// addi r3,r11,5604
	ctx.r3.s64 = ctx.r11.s64 + 5604;
	// bl 0x8b0cea10
	ctx.lr = 0x8B0BC0E4;
	sub_8B0CEA10(ctx, base);
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// bne cr6,0x8b0bc120
	if (!ctx.cr6.eq) goto loc_8B0BC120;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// mr r4,r28
	ctx.r4.u64 = ctx.r28.u64;
	// bl 0x8b0cea10
	ctx.lr = 0x8B0BC0F8;
	sub_8B0CEA10(ctx, base);
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// beq cr6,0x8b0bc120
	if (ctx.cr6.eq) goto loc_8B0BC120;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0bb090
	ctx.lr = 0x8B0BC108;
	sub_8B0BB090(ctx, base);
	// addi r1,r1,128
	ctx.r1.s64 = ctx.r1.s64 + 128;
	// b 0x8b0cba08
	__restgprlr_28(ctx, base);
	return;
loc_8B0BC110:
	// bl 0x8b0df2f8
	ctx.lr = 0x8B0BC114;
	sub_8B0DF2F8(ctx, base);
	// lfs f0,8(r31)
	ctx.fpscr.disableFlushMode();
	temp.u32 = REX_LOAD_U32(ctx.r31.u32 + 8);
	ctx.f0.f64 = double(temp.f32);
	// fcmpu cr6,f1,f0
	ctx.cr6.compare(ctx.f1.f64, ctx.f0.f64);
	// ble cr6,0x8b0bc19c
	if (!ctx.cr6.gt) goto loc_8B0BC19C;
loc_8B0BC120:
	// li r11,6
	ctx.r11.s64 = 6;
	// stw r11,784(r31)
	REX_STORE_U32(ctx.r31.u32 + 784, ctx.r11.u32);
	// addi r1,r1,128
	ctx.r1.s64 = ctx.r1.s64 + 128;
	// b 0x8b0cba08
	__restgprlr_28(ctx, base);
	return;
loc_8B0BC130:
	// lwz r3,16(r31)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r31.u32 + 16);
	// bl 0x8b0b7af0
	ctx.lr = 0x8B0BC138;
	sub_8B0B7AF0(ctx, base);
	// lwz r3,16(r31)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r31.u32 + 16);
	// bl 0x8b0b65a8
	ctx.lr = 0x8B0BC140;
	sub_8B0B65A8(ctx, base);
	// clrlwi r11,r3,24
	ctx.r11.u64 = ctx.r3.u32 & 0xFF;
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// beq cr6,0x8b0bc19c
	if (ctx.cr6.eq) goto loc_8B0BC19C;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0bb9e8
	ctx.lr = 0x8B0BC154;
	sub_8B0BB9E8(ctx, base);
	// addi r1,r1,128
	ctx.r1.s64 = ctx.r1.s64 + 128;
	// b 0x8b0cba08
	__restgprlr_28(ctx, base);
	return;
loc_8B0BC15C:
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0bb1e8
	ctx.lr = 0x8B0BC164;
	sub_8B0BB1E8(ctx, base);
	// addi r1,r1,128
	ctx.r1.s64 = ctx.r1.s64 + 128;
	// b 0x8b0cba08
	__restgprlr_28(ctx, base);
	return;
loc_8B0BC16C:
	// bl 0x8b0df2f8
	ctx.lr = 0x8B0BC170;
	sub_8B0DF2F8(ctx, base);
	// lfs f0,8(r31)
	ctx.fpscr.disableFlushMode();
	temp.u32 = REX_LOAD_U32(ctx.r31.u32 + 8);
	ctx.f0.f64 = double(temp.f32);
	// fcmpu cr6,f1,f0
	ctx.cr6.compare(ctx.f1.f64, ctx.f0.f64);
	// ble cr6,0x8b0bc19c
	if (!ctx.cr6.gt) goto loc_8B0BC19C;
	// lis r11,-29943
	ctx.r11.s64 = -1962344448;
	// addi r4,r31,528
	ctx.r4.s64 = ctx.r31.s64 + 528;
	// addi r3,r11,-30828
	ctx.r3.s64 = ctx.r11.s64 + -30828;
	// bl 0x8b0df2e8
	ctx.lr = 0x8B0BC18C;
	sub_8B0DF2E8(ctx, base);
	// addi r3,r31,296
	ctx.r3.s64 = ctx.r31.s64 + 296;
	// bl 0x8b0b6540
	ctx.lr = 0x8B0BC194;
	sub_8B0B6540(ctx, base);
	// li r10,3
	ctx.r10.s64 = 3;
	// stw r10,784(r31)
	REX_STORE_U32(ctx.r31.u32 + 784, ctx.r10.u32);
loc_8B0BC19C:
	// addi r1,r1,128
	ctx.r1.s64 = ctx.r1.s64 + 128;
	// b 0x8b0cba08
	__restgprlr_28(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0BC618) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// std r31,-16(r1)
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.r31.u64);
	// stwu r1,-96(r1)
	ea = -96 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lwz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// lwz r10,36(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 36);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B0BC63C;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// clrlwi r9,r3,24
	ctx.r9.u64 = ctx.r3.u32 & 0xFF;
	// cmplwi cr6,r9,0
	ctx.cr6.compare<uint32_t>(ctx.r9.u32, 0, ctx.xer);
	// beq cr6,0x8b0bc660
	if (ctx.cr6.eq) goto loc_8B0BC660;
	// lwz r3,176(r31)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r31.u32 + 176);
	// addi r1,r1,96
	ctx.r1.s64 = ctx.r1.s64 + 96;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
loc_8B0BC660:
	// li r3,0
	ctx.r3.s64 = 0;
	// addi r1,r1,96
	ctx.r1.s64 = ctx.r1.s64 + 96;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0BC750) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9a0
	ctx.lr = 0x8B0BC758;
	__savegprlr_22(ctx, base);
	// stwu r1,-448(r1)
	ea = -448 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// li r5,1
	ctx.r5.s64 = 1;
	// addi r4,r11,28036
	ctx.r4.s64 = ctx.r11.s64 + 28036;
	// mr r23,r3
	ctx.r23.u64 = ctx.r3.u64;
	// lwz r3,124(r3)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r3.u32 + 124);
	// bl 0x8b0bfa88
	ctx.lr = 0x8B0BC774;
	sub_8B0BFA88(ctx, base);
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0bc7e4
	if (ctx.cr6.eq) goto loc_8B0BC7E4;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// li r5,0
	ctx.r5.s64 = 0;
	// addi r30,r11,28020
	ctx.r30.s64 = ctx.r11.s64 + 28020;
	// mr r4,r30
	ctx.r4.u64 = ctx.r30.u64;
	// bl 0x8b0bfa88
	ctx.lr = 0x8B0BC794;
	sub_8B0BFA88(ctx, base);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// bne cr6,0x8b0bc7b0
	if (!ctx.cr6.eq) goto loc_8B0BC7B0;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// mr r4,r30
	ctx.r4.u64 = ctx.r30.u64;
	// addi r5,r11,5604
	ctx.r5.s64 = ctx.r11.s64 + 5604;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0c0010
	ctx.lr = 0x8B0BC7B0;
	sub_8B0C0010(ctx, base);
loc_8B0BC7B0:
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// li r5,0
	ctx.r5.s64 = 0;
	// addi r30,r11,28012
	ctx.r30.s64 = ctx.r11.s64 + 28012;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// mr r4,r30
	ctx.r4.u64 = ctx.r30.u64;
	// bl 0x8b0bfa88
	ctx.lr = 0x8B0BC7C8;
	sub_8B0BFA88(ctx, base);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// bne cr6,0x8b0bc7e4
	if (!ctx.cr6.eq) goto loc_8B0BC7E4;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// mr r4,r30
	ctx.r4.u64 = ctx.r30.u64;
	// addi r5,r11,5788
	ctx.r5.s64 = ctx.r11.s64 + 5788;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0c0010
	ctx.lr = 0x8B0BC7E4;
	sub_8B0C0010(ctx, base);
loc_8B0BC7E4:
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lwz r3,124(r23)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r23.u32 + 124);
	// li r5,1
	ctx.r5.s64 = 1;
	// addi r4,r11,3636
	ctx.r4.s64 = ctx.r11.s64 + 3636;
	// bl 0x8b0bfa88
	ctx.lr = 0x8B0BC7F8;
	sub_8B0BFA88(ctx, base);
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0bc9cc
	if (ctx.cr6.eq) goto loc_8B0BC9CC;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// li r5,1
	ctx.r5.s64 = 1;
	// addi r4,r11,3624
	ctx.r4.s64 = ctx.r11.s64 + 3624;
	// bl 0x8b0c0148
	ctx.lr = 0x8B0BC814;
	sub_8B0C0148(ctx, base);
	// bl 0x8b0df2c8
	ctx.lr = 0x8B0BC818;
	sub_8B0DF2C8(ctx, base);
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// mr r27,r3
	ctx.r27.u64 = ctx.r3.u64;
	// addi r29,r11,3592
	ctx.r29.s64 = ctx.r11.s64 + 3592;
	// mr r5,r3
	ctx.r5.u64 = ctx.r3.u64;
	// mr r4,r29
	ctx.r4.u64 = ctx.r29.u64;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0c0148
	ctx.lr = 0x8B0BC834;
	sub_8B0C0148(ctx, base);
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// mr r5,r27
	ctx.r5.u64 = ctx.r27.u64;
	// addi r4,r10,27992
	ctx.r4.s64 = ctx.r10.s64 + 27992;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0c0148
	ctx.lr = 0x8B0BC848;
	sub_8B0C0148(ctx, base);
	// lis r9,-29944
	ctx.r9.s64 = -1962409984;
	// li r5,1
	ctx.r5.s64 = 1;
	// addi r4,r9,27980
	ctx.r4.s64 = ctx.r9.s64 + 27980;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0bfa88
	ctx.lr = 0x8B0BC85C;
	sub_8B0BFA88(ctx, base);
	// mr r30,r3
	ctx.r30.u64 = ctx.r3.u64;
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0bc9cc
	if (ctx.cr6.eq) goto loc_8B0BC9CC;
	// lis r28,-29938
	ctx.r28.s64 = -1962016768;
	// lwz r11,2548(r28)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r28.u32 + 2548);
	// lwz r31,0(r11)
	ctx.r31.u64 = REX_LOAD_U32(ctx.r11.u32 + 0);
	// bl 0x8b0df318
	ctx.lr = 0x8B0BC878;
	sub_8B0DF318(ctx, base);
	// lwz r11,4(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 4);
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// lwz r3,2548(r28)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r28.u32 + 2548);
	// mtctr r11
	ctx.ctr.u64 = ctx.r11.u64;
	// bctrl 
	ctx.lr = 0x8B0BC88C;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// lwz r10,0(r3)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r9,0(r10)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r10.u32 + 0);
	// mtctr r9
	ctx.ctr.u64 = ctx.r9.u64;
	// bctrl 
	ctx.lr = 0x8B0BC89C;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// lis r8,-29944
	ctx.r8.s64 = -1962409984;
	// mr r5,r3
	ctx.r5.u64 = ctx.r3.u64;
	// addi r4,r8,16356
	ctx.r4.s64 = ctx.r8.s64 + 16356;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// bl 0x8b0c0190
	ctx.lr = 0x8B0BC8B0;
	sub_8B0C0190(ctx, base);
	// mr r4,r29
	ctx.r4.u64 = ctx.r29.u64;
	// mr r5,r27
	ctx.r5.u64 = ctx.r27.u64;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// bl 0x8b0c0148
	ctx.lr = 0x8B0BC8C0;
	sub_8B0C0148(ctx, base);
	// bl 0x8b0982e0
	ctx.lr = 0x8B0BC8C4;
	sub_8B0982E0(ctx, base);
	// lis r7,-29944
	ctx.r7.s64 = -1962409984;
	// mr r5,r3
	ctx.r5.u64 = ctx.r3.u64;
	// addi r4,r7,3816
	ctx.r4.s64 = ctx.r7.s64 + 3816;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// bl 0x8b0c0190
	ctx.lr = 0x8B0BC8D8;
	sub_8B0C0190(ctx, base);
	// bl 0x8b098428
	ctx.lr = 0x8B0BC8DC;
	sub_8B098428(ctx, base);
	// lis r6,-29944
	ctx.r6.s64 = -1962409984;
	// mr r5,r3
	ctx.r5.u64 = ctx.r3.u64;
	// addi r4,r6,17688
	ctx.r4.s64 = ctx.r6.s64 + 17688;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// bl 0x8b0c0010
	ctx.lr = 0x8B0BC8F0;
	sub_8B0C0010(ctx, base);
	// lis r4,-29944
	ctx.r4.s64 = -1962409984;
	// li r5,0
	ctx.r5.s64 = 0;
	// addi r4,r4,27972
	ctx.r4.s64 = ctx.r4.s64 + 27972;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// bl 0x8b0c0148
	ctx.lr = 0x8B0BC904;
	sub_8B0C0148(ctx, base);
	// li r29,0
	ctx.r29.s64 = 0;
	// cmpwi cr6,r27,0
	ctx.cr6.compare<int32_t>(ctx.r27.s32, 0, ctx.xer);
	// ble cr6,0x8b0bc9cc
	if (!ctx.cr6.gt) goto loc_8B0BC9CC;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// lis r9,-29944
	ctx.r9.s64 = -1962409984;
	// addi r26,r11,2776
	ctx.r26.s64 = ctx.r11.s64 + 2776;
	// addi r25,r10,3616
	ctx.r25.s64 = ctx.r10.s64 + 3616;
	// addi r24,r9,3604
	ctx.r24.s64 = ctx.r9.s64 + 3604;
loc_8B0BC928:
	// mr r4,r24
	ctx.r4.u64 = ctx.r24.u64;
	// mr r5,r29
	ctx.r5.u64 = ctx.r29.u64;
	// addi r3,r1,96
	ctx.r3.s64 = ctx.r1.s64 + 96;
	// bl 0x8b090220
	ctx.lr = 0x8B0BC938;
	sub_8B090220(ctx, base);
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// li r5,1
	ctx.r5.s64 = 1;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// bl 0x8b0bfa88
	ctx.lr = 0x8B0BC948;
	sub_8B0BFA88(ctx, base);
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0bc9c0
	if (ctx.cr6.eq) goto loc_8B0BC9C0;
	// mr r3,r29
	ctx.r3.u64 = ctx.r29.u64;
	// bl 0x8b0df2b8
	ctx.lr = 0x8B0BC95C;
	sub_8B0DF2B8(ctx, base);
	// lwz r11,2548(r28)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r28.u32 + 2548);
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// mr r3,r11
	ctx.r3.u64 = ctx.r11.u64;
	// lwz r10,0(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 0);
	// lwz r9,4(r10)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r10.u32 + 4);
	// mtctr r9
	ctx.ctr.u64 = ctx.r9.u64;
	// bctrl 
	ctx.lr = 0x8B0BC978;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// lwz r8,0(r3)
	ctx.r8.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// mr r22,r3
	ctx.r22.u64 = ctx.r3.u64;
	// lwz r7,0(r8)
	ctx.r7.u64 = REX_LOAD_U32(ctx.r8.u32 + 0);
	// mtctr r7
	ctx.ctr.u64 = ctx.r7.u64;
	// bctrl 
	ctx.lr = 0x8B0BC98C;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// mr r5,r3
	ctx.r5.u64 = ctx.r3.u64;
	// mr r4,r25
	ctx.r4.u64 = ctx.r25.u64;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0c0190
	ctx.lr = 0x8B0BC99C;
	sub_8B0C0190(ctx, base);
	// lwz r6,0(r22)
	ctx.r6.u64 = REX_LOAD_U32(ctx.r22.u32 + 0);
	// mr r3,r22
	ctx.r3.u64 = ctx.r22.u64;
	// lwz r5,8(r6)
	ctx.r5.u64 = REX_LOAD_U32(ctx.r6.u32 + 8);
	// mtctr r5
	ctx.ctr.u64 = ctx.r5.u64;
	// bctrl 
	ctx.lr = 0x8B0BC9B0;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// mr r5,r3
	ctx.r5.u64 = ctx.r3.u64;
	// mr r4,r26
	ctx.r4.u64 = ctx.r26.u64;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0c0010
	ctx.lr = 0x8B0BC9C0;
	sub_8B0C0010(ctx, base);
loc_8B0BC9C0:
	// addi r29,r29,1
	ctx.r29.s64 = ctx.r29.s64 + 1;
	// cmpw cr6,r29,r27
	ctx.cr6.compare<int32_t>(ctx.r29.s32, ctx.r27.s32, ctx.xer);
	// blt cr6,0x8b0bc928
	if (ctx.cr6.lt) goto loc_8B0BC928;
loc_8B0BC9CC:
	// lis r11,-29943
	ctx.r11.s64 = -1962344448;
	// addi r3,r11,-30228
	ctx.r3.s64 = ctx.r11.s64 + -30228;
	// bl 0x8b0df298
	ctx.lr = 0x8B0BC9D8;
	sub_8B0DF298(ctx, base);
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// li r9,1
	ctx.r9.s64 = 1;
	// lwz r3,124(r23)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r23.u32 + 124);
	// addi r8,r10,1800
	ctx.r8.s64 = ctx.r10.s64 + 1800;
	// stw r9,84(r1)
	REX_STORE_U32(ctx.r1.u32 + 84, ctx.r9.u32);
	// li r5,1
	ctx.r5.s64 = 1;
	// stw r8,80(r1)
	REX_STORE_U32(ctx.r1.u32 + 80, ctx.r8.u32);
	// addi r4,r1,80
	ctx.r4.s64 = ctx.r1.s64 + 80;
	// bl 0x8b0bf510
	ctx.lr = 0x8B0BC9FC;
	sub_8B0BF510(ctx, base);
	// addi r1,r1,448
	ctx.r1.s64 = ctx.r1.s64 + 448;
	// b 0x8b0cb9f0
	__restgprlr_22(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0BD238) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9b0
	ctx.lr = 0x8B0BD240;
	__savegprlr_26(ctx, base);
	// stwu r1,-160(r1)
	ea = -160 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lwz r11,40(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 40);
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// lwz r28,0(r11)
	ctx.r28.u64 = REX_LOAD_U32(ctx.r11.u32 + 0);
	// cmplwi cr6,r28,0
	ctx.cr6.compare<uint32_t>(ctx.r28.u32, 0, ctx.xer);
	// beq cr6,0x8b0bd33c
	if (ctx.cr6.eq) goto loc_8B0BD33C;
	// rlwinm r11,r28,1,0,30
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r28.u32 | (ctx.r28.u64 << 32), 1) & 0xFFFFFFFE;
	// rlwinm r29,r28,6,0,25
	ctx.r29.u64 = __builtin_rotateleft64(ctx.r28.u32 | (ctx.r28.u64 << 32), 6) & 0xFFFFFFC0;
	// add r11,r28,r11
	ctx.r11.u64 = ctx.r28.u64 + ctx.r11.u64;
	// lis r26,-29936
	ctx.r26.s64 = -1961885696;
	// rlwinm r27,r11,3,0,28
	ctx.r27.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 3) & 0xFFFFFFF8;
loc_8B0BD26C:
	// lwz r11,40(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 40);
	// addi r27,r27,-24
	ctx.r27.s64 = ctx.r27.s64 + -24;
	// addi r28,r28,-1
	ctx.r28.s64 = ctx.r28.s64 + -1;
	// add r11,r27,r11
	ctx.r11.u64 = ctx.r27.u64 + ctx.r11.u64;
	// addi r29,r29,-64
	ctx.r29.s64 = ctx.r29.s64 + -64;
	// lbz r10,8(r11)
	ctx.r10.u64 = REX_LOAD_U8(ctx.r11.u32 + 8);
	// rlwinm r9,r10,0,28,30
	ctx.r9.u64 = __builtin_rotateleft64(ctx.r10.u32 | (ctx.r10.u64 << 32), 0) & 0xE;
	// rlwinm r9,r9,0,30,28
	ctx.r9.u64 = __builtin_rotateleft64(ctx.r9.u32 | (ctx.r9.u64 << 32), 0) & 0xFFFFFFFFFFFFFFFB;
	// cmplwi cr6,r9,10
	ctx.cr6.compare<uint32_t>(ctx.r9.u32, 10, ctx.xer);
	// bne cr6,0x8b0bd300
	if (!ctx.cr6.eq) goto loc_8B0BD300;
	// rlwinm r10,r10,0,29,29
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r10.u32 | (ctx.r10.u64 << 32), 0) & 0x4;
	// cmplwi cr6,r10,0
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 0, ctx.xer);
	// bne cr6,0x8b0bd300
	if (!ctx.cr6.eq) goto loc_8B0BD300;
	// lhz r9,14(r11)
	ctx.r9.u64 = REX_LOAD_U16(ctx.r11.u32 + 14);
	// cmplwi cr6,r9,0
	ctx.cr6.compare<uint32_t>(ctx.r9.u32, 0, ctx.xer);
	// beq cr6,0x8b0bd334
	if (ctx.cr6.eq) goto loc_8B0BD334;
	// lwz r10,16(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 16);
	// cmplwi cr6,r10,0
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 0, ctx.xer);
	// beq cr6,0x8b0bd334
	if (ctx.cr6.eq) goto loc_8B0BD334;
	// lhz r11,22(r11)
	ctx.r11.u64 = REX_LOAD_U16(ctx.r11.u32 + 22);
	// stw r9,84(r1)
	REX_STORE_U32(ctx.r1.u32 + 84, ctx.r9.u32);
	// stw r10,80(r1)
	REX_STORE_U32(ctx.r1.u32 + 80, ctx.r10.u32);
	// lwz r3,-17796(r26)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r26.u32 + -17796);
	// stw r11,88(r1)
	REX_STORE_U32(ctx.r1.u32 + 88, ctx.r11.u32);
	// lwz r10,0(r3)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r9,40(r10)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r10.u32 + 40);
	// mtctr r9
	ctx.ctr.u64 = ctx.r9.u64;
	// bctrl 
	ctx.lr = 0x8B0BD2DC;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// lwz r8,0(r3)
	ctx.r8.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r7,8(r8)
	ctx.r7.u64 = REX_LOAD_U32(ctx.r8.u32 + 8);
	// addi r4,r1,80
	ctx.r4.s64 = ctx.r1.s64 + 80;
	// lwz r11,148(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 148);
	// add r30,r11,r29
	ctx.r30.u64 = ctx.r11.u64 + ctx.r29.u64;
	// mtctr r7
	ctx.ctr.u64 = ctx.r7.u64;
	// bctrl 
	ctx.lr = 0x8B0BD2F8;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// stw r3,60(r30)
	REX_STORE_U32(ctx.r30.u32 + 60, ctx.r3.u32);
	// b 0x8b0bd334
	goto loc_8B0BD334;
loc_8B0BD300:
	// lwz r11,160(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 160);
	// addi r30,r31,148
	ctx.r30.s64 = ctx.r31.s64 + 148;
	// subf r10,r28,r11
	ctx.r10.u64 = ctx.r11.u64 - ctx.r28.u64;
	// addic. r11,r10,-1
	ctx.xer.ca = ctx.r10.u32 > 0;
	ctx.r11.s64 = ctx.r10.s64 + -1;
	ctx.cr0.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// ble 0x8b0bd328
	if (!ctx.cr0.gt) goto loc_8B0BD328;
	// lwz r10,0(r30)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r30.u32 + 0);
	// rlwinm r5,r11,6,0,25
	ctx.r5.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 6) & 0xFFFFFFC0;
	// add r3,r29,r10
	ctx.r3.u64 = ctx.r29.u64 + ctx.r10.u64;
	// addi r4,r3,64
	ctx.r4.s64 = ctx.r3.s64 + 64;
	// bl 0x8b0cc060
	ctx.lr = 0x8B0BD328;
	sub_8B0CC060(ctx, base);
loc_8B0BD328:
	// lwz r11,12(r30)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r30.u32 + 12);
	// addi r11,r11,-1
	ctx.r11.s64 = ctx.r11.s64 + -1;
	// stw r11,12(r30)
	REX_STORE_U32(ctx.r30.u32 + 12, ctx.r11.u32);
loc_8B0BD334:
	// cmplwi cr6,r28,0
	ctx.cr6.compare<uint32_t>(ctx.r28.u32, 0, ctx.xer);
	// bne cr6,0x8b0bd26c
	if (!ctx.cr6.eq) goto loc_8B0BD26C;
loc_8B0BD33C:
	// lis r11,-29938
	ctx.r11.s64 = -1962016768;
	// lwz r4,40(r31)
	ctx.r4.u64 = REX_LOAD_U32(ctx.r31.u32 + 40);
	// lwz r11,2364(r11)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r11.u32 + 2364);
	// lwz r3,104(r11)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r11.u32 + 104);
	// lwz r10,0(r3)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r9,12(r10)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r10.u32 + 12);
	// mtctr r9
	ctx.ctr.u64 = ctx.r9.u64;
	// bctrl 
	ctx.lr = 0x8B0BD35C;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// li r29,0
	ctx.r29.s64 = 0;
	// lwz r4,160(r31)
	ctx.r4.u64 = REX_LOAD_U32(ctx.r31.u32 + 160);
	// lis r8,-29943
	ctx.r8.s64 = -1962344448;
	// stw r29,40(r31)
	REX_STORE_U32(ctx.r31.u32 + 40, ctx.r29.u32);
	// addi r3,r8,-30060
	ctx.r3.s64 = ctx.r8.s64 + -30060;
	// bl 0x8b0df298
	ctx.lr = 0x8B0BD374;
	sub_8B0DF298(ctx, base);
	// addi r3,r31,164
	ctx.r3.s64 = ctx.r31.s64 + 164;
	// lwz r6,148(r31)
	ctx.r6.u64 = REX_LOAD_U32(ctx.r31.u32 + 148);
	// addi r30,r31,148
	ctx.r30.s64 = ctx.r31.s64 + 148;
	// lwz r5,160(r31)
	ctx.r5.u64 = REX_LOAD_U32(ctx.r31.u32 + 160);
	// lwz r4,176(r31)
	ctx.r4.u64 = REX_LOAD_U32(ctx.r31.u32 + 176);
	// bl 0x8b0bca98
	ctx.lr = 0x8B0BD38C;
	sub_8B0BCA98(ctx, base);
	// stw r29,160(r31)
	REX_STORE_U32(ctx.r31.u32 + 160, ctx.r29.u32);
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// bl 0x8b0906a8
	ctx.lr = 0x8B0BD398;
	sub_8B0906A8(ctx, base);
	// lwz r7,0(r31)
	ctx.r7.u64 = REX_LOAD_U32(ctx.r31.u32 + 0);
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// lwz r4,140(r31)
	ctx.r4.u64 = REX_LOAD_U32(ctx.r31.u32 + 140);
	// lwz r6,28(r7)
	ctx.r6.u64 = REX_LOAD_U32(ctx.r7.u32 + 28);
	// mtctr r6
	ctx.ctr.u64 = ctx.r6.u64;
	// bctrl 
	ctx.lr = 0x8B0BD3B0;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// addi r1,r1,160
	ctx.r1.s64 = ctx.r1.s64 + 160;
	// b 0x8b0cba00
	__restgprlr_26(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0BDA08) {
	REX_FUNC_PROLOGUE();
	PPCRegister temp{};
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// std r31,-16(r1)
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.r31.u64);
	// stwu r1,-96(r1)
	ea = -96 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lwz r11,144(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 144);
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// cmplwi cr6,r11,1
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 1, ctx.xer);
	// blt cr6,0x8b0bda98
	if (ctx.cr6.lt) goto loc_8B0BDA98;
	// beq cr6,0x8b0bda70
	if (ctx.cr6.eq) goto loc_8B0BDA70;
	// cmplwi cr6,r11,3
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 3, ctx.xer);
	// bge cr6,0x8b0bdb00
	if (!ctx.cr6.lt) goto loc_8B0BDB00;
	// bl 0x8b0df2f8
	ctx.lr = 0x8B0BDA38;
	sub_8B0DF2F8(ctx, base);
	// lfs f0,36(r31)
	ctx.fpscr.disableFlushMode();
	temp.u32 = REX_LOAD_U32(ctx.r31.u32 + 36);
	ctx.f0.f64 = double(temp.f32);
	// fcmpu cr6,f1,f0
	ctx.cr6.compare(ctx.f1.f64, ctx.f0.f64);
	// bgt cr6,0x8b0bda54
	if (ctx.cr6.gt) goto loc_8B0BDA54;
	// lwz r11,40(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 40);
	// lwz r10,4(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 4);
	// cmplwi cr6,r10,0
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 0, ctx.xer);
	// bne cr6,0x8b0bdb00
	if (!ctx.cr6.eq) goto loc_8B0BDB00;
loc_8B0BDA54:
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0bd238
	ctx.lr = 0x8B0BDA5C;
	sub_8B0BD238(ctx, base);
	// addi r1,r1,96
	ctx.r1.s64 = ctx.r1.s64 + 96;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
loc_8B0BDA70:
	// lwz r11,92(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 92);
	// cmplwi cr6,r11,997
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 997, ctx.xer);
	// beq cr6,0x8b0bdb00
	if (ctx.cr6.eq) goto loc_8B0BDB00;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0bd8d8
	ctx.lr = 0x8B0BDA84;
	sub_8B0BD8D8(ctx, base);
	// addi r1,r1,96
	ctx.r1.s64 = ctx.r1.s64 + 96;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
loc_8B0BDA98:
	// li r11,1
	ctx.r11.s64 = 1;
	// li r3,36
	ctx.r3.s64 = 36;
	// stw r11,144(r31)
	REX_STORE_U32(ctx.r31.u32 + 144, ctx.r11.u32);
	// bl 0x8b0bf448
	ctx.lr = 0x8B0BDAA8;
	sub_8B0BF448(ctx, base);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0bdae0
	if (ctx.cr6.eq) goto loc_8B0BDAE0;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lis r10,-29943
	ctx.r10.s64 = -1962344448;
	// addi r6,r11,28164
	ctx.r6.s64 = ctx.r11.s64 + 28164;
	// lis r9,-29944
	ctx.r9.s64 = -1962409984;
	// lis r4,-29944
	ctx.r4.s64 = -1962409984;
	// mr r7,r6
	ctx.r7.u64 = ctx.r6.u64;
	// addi r8,r10,-29744
	ctx.r8.s64 = ctx.r10.s64 + -29744;
	// addi r5,r9,4072
	ctx.r5.s64 = ctx.r9.s64 + 4072;
	// addi r4,r4,4080
	ctx.r4.s64 = ctx.r4.s64 + 4080;
	// bl 0x8b0c1438
	ctx.lr = 0x8B0BDAD8;
	sub_8B0C1438(ctx, base);
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// b 0x8b0bdae4
	goto loc_8B0BDAE4;
loc_8B0BDAE0:
	// li r4,0
	ctx.r4.s64 = 0;
loc_8B0BDAE4:
	// lwz r11,0(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 0);
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// lwz r10,20(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 20);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B0BDAF8;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0bc2f0
	ctx.lr = 0x8B0BDB00;
	sub_8B0BC2F0(ctx, base);
loc_8B0BDB00:
	// addi r1,r1,96
	ctx.r1.s64 = ctx.r1.s64 + 96;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0BDD68) {
	REX_FUNC_PROLOGUE();
	PPCRegister temp{};
	// lfs f0,4(r3)
	ctx.fpscr.disableFlushMode();
	temp.u32 = REX_LOAD_U32(ctx.r3.u32 + 4);
	ctx.f0.f64 = double(temp.f32);
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// fmuls f13,f0,f0
	ctx.f13.f64 = double(float(ctx.f0.f64 * ctx.f0.f64));
	// lfs f12,0(r3)
	temp.u32 = REX_LOAD_U32(ctx.r3.u32 + 0);
	ctx.f12.f64 = double(temp.f32);
	// lfs f11,8(r3)
	temp.u32 = REX_LOAD_U32(ctx.r3.u32 + 8);
	ctx.f11.f64 = double(temp.f32);
	// lfs f1,32132(r11)
	temp.u32 = REX_LOAD_U32(ctx.r11.u32 + 32132);
	ctx.f1.f64 = double(temp.f32);
	// fmadds f10,f12,f12,f13
	ctx.f10.f64 = double(float(std::fma(ctx.f12.f64, ctx.f12.f64, ctx.f13.f64)));
	// fmadds f0,f11,f11,f10
	ctx.f0.f64 = double(float(std::fma(ctx.f11.f64, ctx.f11.f64, ctx.f10.f64)));
	// fcmpu cr6,f0,f1
	ctx.cr6.compare(ctx.f0.f64, ctx.f1.f64);
	// bltlr cr6
	if (ctx.cr6.lt) return;
	// fdivs f1,f1,f0
	ctx.f1.f64 = double(float(ctx.f1.f64 / ctx.f0.f64));
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0BDE88) {
	REX_FUNC_PROLOGUE();
	// mr r11,r3
	ctx.r11.u64 = ctx.r3.u64;
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// bne cr6,0x8b0bde98
	if (!ctx.cr6.eq) goto loc_8B0BDE98;
	// blr 
	return;
loc_8B0BDE98:
	// mr r9,r11
	ctx.r9.u64 = ctx.r11.u64;
	// mr r10,r11
	ctx.r10.u64 = ctx.r11.u64;
	// li r8,0
	ctx.r8.s64 = 0;
loc_8B0BDEA4:
	// clrlwi r7,r9,31
	ctx.r7.u64 = ctx.r9.u32 & 0x1;
	// cmplwi cr6,r7,0
	ctx.cr6.compare<uint32_t>(ctx.r7.u32, 0, ctx.xer);
	// beq cr6,0x8b0bdeb4
	if (ctx.cr6.eq) goto loc_8B0BDEB4;
	// xor r8,r8,r10
	ctx.r8.u64 = ctx.r8.u64 ^ ctx.r10.u64;
loc_8B0BDEB4:
	// rlwinm r10,r10,1,0,30
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r10.u32 | (ctx.r10.u64 << 32), 1) & 0xFFFFFFFE;
	// rlwinm r9,r9,31,1,31
	ctx.r9.u64 = __builtin_rotateleft64(ctx.r9.u32 | (ctx.r9.u64 << 32), 31) & 0x7FFFFFFF;
	// cmplwi cr6,r10,256
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 256, ctx.xer);
	// blt cr6,0x8b0bdec8
	if (ctx.cr6.lt) goto loc_8B0BDEC8;
	// xor r10,r10,r4
	ctx.r10.u64 = ctx.r10.u64 ^ ctx.r4.u64;
loc_8B0BDEC8:
	// cmplwi cr6,r9,0
	ctx.cr6.compare<uint32_t>(ctx.r9.u32, 0, ctx.xer);
	// bne cr6,0x8b0bdea4
	if (!ctx.cr6.eq) goto loc_8B0BDEA4;
	// mr r10,r11
	ctx.r10.u64 = ctx.r11.u64;
	// cmplwi cr6,r8,0
	ctx.cr6.compare<uint32_t>(ctx.r8.u32, 0, ctx.xer);
	// beq cr6,0x8b0bdf08
	if (ctx.cr6.eq) goto loc_8B0BDF08;
loc_8B0BDEDC:
	// clrlwi r7,r8,31
	ctx.r7.u64 = ctx.r8.u32 & 0x1;
	// cmplwi cr6,r7,0
	ctx.cr6.compare<uint32_t>(ctx.r7.u32, 0, ctx.xer);
	// beq cr6,0x8b0bdeec
	if (ctx.cr6.eq) goto loc_8B0BDEEC;
	// xor r9,r9,r10
	ctx.r9.u64 = ctx.r9.u64 ^ ctx.r10.u64;
loc_8B0BDEEC:
	// rlwinm r10,r10,1,0,30
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r10.u32 | (ctx.r10.u64 << 32), 1) & 0xFFFFFFFE;
	// rlwinm r8,r8,31,1,31
	ctx.r8.u64 = __builtin_rotateleft64(ctx.r8.u32 | (ctx.r8.u64 << 32), 31) & 0x7FFFFFFF;
	// cmplwi cr6,r10,256
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 256, ctx.xer);
	// blt cr6,0x8b0bdf00
	if (ctx.cr6.lt) goto loc_8B0BDF00;
	// xor r10,r10,r4
	ctx.r10.u64 = ctx.r10.u64 ^ ctx.r4.u64;
loc_8B0BDF00:
	// cmplwi cr6,r8,0
	ctx.cr6.compare<uint32_t>(ctx.r8.u32, 0, ctx.xer);
	// bne cr6,0x8b0bdedc
	if (!ctx.cr6.eq) goto loc_8B0BDEDC;
loc_8B0BDF08:
	// li r8,0
	ctx.r8.s64 = 0;
	// mr r10,r9
	ctx.r10.u64 = ctx.r9.u64;
	// cmplwi cr6,r9,0
	ctx.cr6.compare<uint32_t>(ctx.r9.u32, 0, ctx.xer);
	// beq cr6,0x8b0bdf44
	if (ctx.cr6.eq) goto loc_8B0BDF44;
loc_8B0BDF18:
	// clrlwi r7,r9,31
	ctx.r7.u64 = ctx.r9.u32 & 0x1;
	// cmplwi cr6,r7,0
	ctx.cr6.compare<uint32_t>(ctx.r7.u32, 0, ctx.xer);
	// beq cr6,0x8b0bdf28
	if (ctx.cr6.eq) goto loc_8B0BDF28;
	// xor r8,r8,r10
	ctx.r8.u64 = ctx.r8.u64 ^ ctx.r10.u64;
loc_8B0BDF28:
	// rlwinm r10,r10,1,0,30
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r10.u32 | (ctx.r10.u64 << 32), 1) & 0xFFFFFFFE;
	// rlwinm r9,r9,31,1,31
	ctx.r9.u64 = __builtin_rotateleft64(ctx.r9.u32 | (ctx.r9.u64 << 32), 31) & 0x7FFFFFFF;
	// cmplwi cr6,r10,256
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 256, ctx.xer);
	// blt cr6,0x8b0bdf3c
	if (ctx.cr6.lt) goto loc_8B0BDF3C;
	// xor r10,r10,r4
	ctx.r10.u64 = ctx.r10.u64 ^ ctx.r4.u64;
loc_8B0BDF3C:
	// cmplwi cr6,r9,0
	ctx.cr6.compare<uint32_t>(ctx.r9.u32, 0, ctx.xer);
	// bne cr6,0x8b0bdf18
	if (!ctx.cr6.eq) goto loc_8B0BDF18;
loc_8B0BDF44:
	// mr r10,r8
	ctx.r10.u64 = ctx.r8.u64;
	// li r3,0
	ctx.r3.s64 = 0;
	// cmplwi cr6,r8,0
	ctx.cr6.compare<uint32_t>(ctx.r8.u32, 0, ctx.xer);
	// beqlr cr6
	if (ctx.cr6.eq) return;
loc_8B0BDF54:
	// clrlwi r9,r10,31
	ctx.r9.u64 = ctx.r10.u32 & 0x1;
	// cmplwi cr6,r9,0
	ctx.cr6.compare<uint32_t>(ctx.r9.u32, 0, ctx.xer);
	// beq cr6,0x8b0bdf64
	if (ctx.cr6.eq) goto loc_8B0BDF64;
	// xor r3,r3,r11
	ctx.r3.u64 = ctx.r3.u64 ^ ctx.r11.u64;
loc_8B0BDF64:
	// rlwinm r11,r11,1,0,30
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 1) & 0xFFFFFFFE;
	// rlwinm r10,r10,31,1,31
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r10.u32 | (ctx.r10.u64 << 32), 31) & 0x7FFFFFFF;
	// cmplwi cr6,r11,256
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 256, ctx.xer);
	// blt cr6,0x8b0bdf78
	if (ctx.cr6.lt) goto loc_8B0BDF78;
	// xor r11,r11,r4
	ctx.r11.u64 = ctx.r11.u64 ^ ctx.r4.u64;
loc_8B0BDF78:
	// cmplwi cr6,r10,0
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 0, ctx.xer);
	// bne cr6,0x8b0bdf54
	if (!ctx.cr6.eq) goto loc_8B0BDF54;
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0BE5B0) {
	REX_FUNC_PROLOGUE();
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9a8
	ctx.lr = 0x8B0BE5B8;
	__savegprlr_24(ctx, base);
	// rlwinm r11,r5,1,0,30
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r5.u32 | (ctx.r5.u64 << 32), 1) & 0xFFFFFFFE;
	// mr r27,r6
	ctx.r27.u64 = ctx.r6.u64;
	// add r11,r5,r11
	ctx.r11.u64 = ctx.r5.u64 + ctx.r11.u64;
	// li r26,8
	ctx.r26.s64 = 8;
	// rlwinm r28,r11,2,0,29
	ctx.r28.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 2) & 0xFFFFFFFC;
	// lis r11,21845
	ctx.r11.s64 = 1431633920;
	// li r29,0
	ctx.r29.s64 = 0;
	// ori r30,r11,21846
	ctx.r30.u64 = ctx.r11.u64 | 21846;
loc_8B0BE5D8:
	// lwz r11,8(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 8);
	// li r9,15
	ctx.r9.s64 = 15;
	// lwz r10,0(r27)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r27.u32 + 0);
	// add r11,r11,r28
	ctx.r11.u64 = ctx.r11.u64 + ctx.r28.u64;
	// addi r8,r10,1
	ctx.r8.s64 = ctx.r10.s64 + 1;
	// addi r7,r10,-2
	ctx.r7.s64 = ctx.r10.s64 + -2;
	// addi r6,r10,-1
	ctx.r6.s64 = ctx.r10.s64 + -1;
	// mtctr r9
	ctx.ctr.u64 = ctx.r9.u64;
	// rlwinm r5,r10,1,29,30
	ctx.r5.u64 = __builtin_rotateleft64(ctx.r10.u32 | (ctx.r10.u64 << 32), 1) & 0x6;
	// stw r29,0(r11)
	REX_STORE_U32(ctx.r11.u32 + 0, ctx.r29.u32);
	// rlwinm r8,r8,1,29,30
	ctx.r8.u64 = __builtin_rotateleft64(ctx.r8.u32 | (ctx.r8.u64 << 32), 1) & 0x6;
	// rlwinm r7,r7,1,29,30
	ctx.r7.u64 = __builtin_rotateleft64(ctx.r7.u32 | (ctx.r7.u64 << 32), 1) & 0x6;
	// stw r29,4(r11)
	REX_STORE_U32(ctx.r11.u32 + 4, ctx.r29.u32);
	// rlwinm r10,r6,1,29,30
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r6.u32 | (ctx.r6.u64 << 32), 1) & 0x6;
	// stw r29,8(r11)
	REX_STORE_U32(ctx.r11.u32 + 8, ctx.r29.u32);
	// mr r9,r29
	ctx.r9.u64 = ctx.r29.u64;
	// add r8,r8,r4
	ctx.r8.u64 = ctx.r8.u64 + ctx.r4.u64;
	// add r7,r7,r4
	ctx.r7.u64 = ctx.r7.u64 + ctx.r4.u64;
	// add r6,r10,r4
	ctx.r6.u64 = ctx.r10.u64 + ctx.r4.u64;
loc_8B0BE624:
	// mulhw r10,r9,r30
	ctx.r10.s64 = (int64_t(ctx.r9.s32) * int64_t(ctx.r30.s32)) >> 32;
	// lhzx r25,r5,r4
	ctx.r25.u64 = REX_LOAD_U16(ctx.r5.u32 + ctx.r4.u32);
	// rlwinm r31,r10,1,31,31
	ctx.r31.u64 = __builtin_rotateleft64(ctx.r10.u32 | (ctx.r10.u64 << 32), 1) & 0x1;
	// clrlwi r25,r25,31
	ctx.r25.u64 = ctx.r25.u32 & 0x1;
	// add r10,r10,r31
	ctx.r10.u64 = ctx.r10.u64 + ctx.r31.u64;
	// not r24,r25
	ctx.r24.u64 = ~ctx.r25.u64;
	// rlwinm r31,r10,1,0,30
	ctx.r31.u64 = __builtin_rotateleft64(ctx.r10.u32 | (ctx.r10.u64 << 32), 1) & 0xFFFFFFFE;
	// rlwinm r24,r24,15,16,16
	ctx.r24.u64 = __builtin_rotateleft64(ctx.r24.u32 | (ctx.r24.u64 << 32), 15) & 0x8000;
	// add r10,r10,r31
	ctx.r10.u64 = ctx.r10.u64 + ctx.r31.u64;
	// subf r10,r10,r9
	ctx.r10.u64 = ctx.r9.u64 - ctx.r10.u64;
	// addi r9,r9,1
	ctx.r9.s64 = ctx.r9.s64 + 1;
	// rlwinm r10,r10,2,0,29
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r10.u32 | (ctx.r10.u64 << 32), 2) & 0xFFFFFFFC;
	// lwzx r31,r10,r11
	ctx.r31.u64 = REX_LOAD_U32(ctx.r10.u32 + ctx.r11.u32);
	// rlwinm r31,r31,1,0,30
	ctx.r31.u64 = __builtin_rotateleft64(ctx.r31.u32 | (ctx.r31.u64 << 32), 1) & 0xFFFFFFFE;
	// or r31,r31,r25
	ctx.r31.u64 = ctx.r31.u64 | ctx.r25.u64;
	// stwx r31,r10,r11
	REX_STORE_U32(ctx.r10.u32 + ctx.r11.u32, ctx.r31.u32);
	// lhzx r31,r5,r4
	ctx.r31.u64 = REX_LOAD_U16(ctx.r5.u32 + ctx.r4.u32);
	// rlwinm r31,r31,31,1,31
	ctx.r31.u64 = __builtin_rotateleft64(ctx.r31.u32 | (ctx.r31.u64 << 32), 31) & 0x7FFFFFFF;
	// or r31,r24,r31
	ctx.r31.u64 = ctx.r24.u64 | ctx.r31.u64;
	// sthx r31,r5,r4
	REX_STORE_U16(ctx.r5.u32 + ctx.r4.u32, ctx.r31.u16);
	// lhz r25,0(r8)
	ctx.r25.u64 = REX_LOAD_U16(ctx.r8.u32 + 0);
	// lwzx r31,r10,r11
	ctx.r31.u64 = REX_LOAD_U32(ctx.r10.u32 + ctx.r11.u32);
	// rlwinm r31,r31,1,0,30
	ctx.r31.u64 = __builtin_rotateleft64(ctx.r31.u32 | (ctx.r31.u64 << 32), 1) & 0xFFFFFFFE;
	// clrlwi r25,r25,31
	ctx.r25.u64 = ctx.r25.u32 & 0x1;
	// or r31,r31,r25
	ctx.r31.u64 = ctx.r31.u64 | ctx.r25.u64;
	// not r24,r25
	ctx.r24.u64 = ~ctx.r25.u64;
	// stwx r31,r10,r11
	REX_STORE_U32(ctx.r10.u32 + ctx.r11.u32, ctx.r31.u32);
	// lhz r31,0(r8)
	ctx.r31.u64 = REX_LOAD_U16(ctx.r8.u32 + 0);
	// rlwinm r31,r31,31,1,31
	ctx.r31.u64 = __builtin_rotateleft64(ctx.r31.u32 | (ctx.r31.u64 << 32), 31) & 0x7FFFFFFF;
	// rlwinm r25,r24,15,16,16
	ctx.r25.u64 = __builtin_rotateleft64(ctx.r24.u32 | (ctx.r24.u64 << 32), 15) & 0x8000;
	// or r31,r25,r31
	ctx.r31.u64 = ctx.r25.u64 | ctx.r31.u64;
	// sth r31,0(r8)
	REX_STORE_U16(ctx.r8.u32 + 0, ctx.r31.u16);
	// lhz r25,0(r7)
	ctx.r25.u64 = REX_LOAD_U16(ctx.r7.u32 + 0);
	// lwzx r31,r10,r11
	ctx.r31.u64 = REX_LOAD_U32(ctx.r10.u32 + ctx.r11.u32);
	// rlwinm r31,r31,1,0,30
	ctx.r31.u64 = __builtin_rotateleft64(ctx.r31.u32 | (ctx.r31.u64 << 32), 1) & 0xFFFFFFFE;
	// clrlwi r25,r25,31
	ctx.r25.u64 = ctx.r25.u32 & 0x1;
	// or r31,r31,r25
	ctx.r31.u64 = ctx.r31.u64 | ctx.r25.u64;
	// not r24,r25
	ctx.r24.u64 = ~ctx.r25.u64;
	// stwx r31,r10,r11
	REX_STORE_U32(ctx.r10.u32 + ctx.r11.u32, ctx.r31.u32);
	// lhz r31,0(r7)
	ctx.r31.u64 = REX_LOAD_U16(ctx.r7.u32 + 0);
	// rlwinm r31,r31,31,1,31
	ctx.r31.u64 = __builtin_rotateleft64(ctx.r31.u32 | (ctx.r31.u64 << 32), 31) & 0x7FFFFFFF;
	// rlwinm r25,r24,15,16,16
	ctx.r25.u64 = __builtin_rotateleft64(ctx.r24.u32 | (ctx.r24.u64 << 32), 15) & 0x8000;
	// or r31,r25,r31
	ctx.r31.u64 = ctx.r25.u64 | ctx.r31.u64;
	// sth r31,0(r7)
	REX_STORE_U16(ctx.r7.u32 + 0, ctx.r31.u16);
	// lhz r25,0(r6)
	ctx.r25.u64 = REX_LOAD_U16(ctx.r6.u32 + 0);
	// lwzx r31,r10,r11
	ctx.r31.u64 = REX_LOAD_U32(ctx.r10.u32 + ctx.r11.u32);
	// rlwinm r31,r31,1,0,30
	ctx.r31.u64 = __builtin_rotateleft64(ctx.r31.u32 | (ctx.r31.u64 << 32), 1) & 0xFFFFFFFE;
	// clrlwi r25,r25,31
	ctx.r25.u64 = ctx.r25.u32 & 0x1;
	// or r31,r31,r25
	ctx.r31.u64 = ctx.r31.u64 | ctx.r25.u64;
	// not r24,r25
	ctx.r24.u64 = ~ctx.r25.u64;
	// stwx r31,r10,r11
	REX_STORE_U32(ctx.r10.u32 + ctx.r11.u32, ctx.r31.u32);
	// lhz r10,0(r6)
	ctx.r10.u64 = REX_LOAD_U16(ctx.r6.u32 + 0);
	// rlwinm r25,r24,15,16,16
	ctx.r25.u64 = __builtin_rotateleft64(ctx.r24.u32 | (ctx.r24.u64 << 32), 15) & 0x8000;
	// rlwinm r10,r10,31,1,31
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r10.u32 | (ctx.r10.u64 << 32), 31) & 0x7FFFFFFF;
	// or r10,r25,r10
	ctx.r10.u64 = ctx.r25.u64 | ctx.r10.u64;
	// sth r10,0(r6)
	REX_STORE_U16(ctx.r6.u32 + 0, ctx.r10.u16);
	// bdnz 0x8b0be624
	--ctx.ctr.u64;
	if (ctx.ctr.u32 != 0) goto loc_8B0BE624;
	// addic. r26,r26,-1
	ctx.xer.ca = ctx.r26.u32 > 0;
	ctx.r26.s64 = ctx.r26.s64 + -1;
	ctx.cr0.compare<int32_t>(ctx.r26.s32, 0, ctx.xer);
	// addi r28,r28,12
	ctx.r28.s64 = ctx.r28.s64 + 12;
	// addi r27,r27,4
	ctx.r27.s64 = ctx.r27.s64 + 4;
	// bne 0x8b0be5d8
	if (!ctx.cr0.eq) goto loc_8B0BE5D8;
	// b 0x8b0cb9f8
	__restgprlr_24(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0BE920) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9b8
	ctx.lr = 0x8B0BE928;
	__savegprlr_28(ctx, base);
	// stwu r1,-128(r1)
	ea = -128 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lis r11,-29937
	ctx.r11.s64 = -1961951232;
	// mr r28,r3
	ctx.r28.u64 = ctx.r3.u64;
	// addi r29,r11,-25392
	ctx.r29.s64 = ctx.r11.s64 + -25392;
	// li r30,0
	ctx.r30.s64 = 0;
	// mr r31,r29
	ctx.r31.u64 = ctx.r29.u64;
loc_8B0BE940:
	// add r4,r30,r28
	ctx.r4.u64 = ctx.r30.u64 + ctx.r28.u64;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0be850
	ctx.lr = 0x8B0BE94C;
	sub_8B0BE850(ctx, base);
	// addi r31,r31,896
	ctx.r31.s64 = ctx.r31.s64 + 896;
	// addi r11,r29,28672
	ctx.r11.s64 = ctx.r29.s64 + 28672;
	// addi r30,r30,1
	ctx.r30.s64 = ctx.r30.s64 + 1;
	// cmpw cr6,r31,r11
	ctx.cr6.compare<int32_t>(ctx.r31.s32, ctx.r11.s32, ctx.xer);
	// blt cr6,0x8b0be940
	if (ctx.cr6.lt) goto loc_8B0BE940;
	// addi r1,r1,128
	ctx.r1.s64 = ctx.r1.s64 + 128;
	// b 0x8b0cba08
	__restgprlr_28(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0BEE28) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9b8
	ctx.lr = 0x8B0BEE30;
	__savegprlr_28(ctx, base);
	// stwu r1,-128(r1)
	ea = -128 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lwz r31,24(r3)
	ctx.r31.u64 = REX_LOAD_U32(ctx.r3.u32 + 24);
	// mr r28,r3
	ctx.r28.u64 = ctx.r3.u64;
	// li r29,0
	ctx.r29.s64 = 0;
	// cmplwi cr6,r31,0
	ctx.cr6.compare<uint32_t>(ctx.r31.u32, 0, ctx.xer);
	// beq cr6,0x8b0bee7c
	if (ctx.cr6.eq) goto loc_8B0BEE7C;
loc_8B0BEE48:
	// lwz r30,20(r31)
	ctx.r30.u64 = REX_LOAD_U32(ctx.r31.u32 + 20);
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// stw r29,20(r31)
	REX_STORE_U32(ctx.r31.u32 + 20, ctx.r29.u32);
	// bl 0x8b0bee28
	ctx.lr = 0x8B0BEE58;
	sub_8B0BEE28(ctx, base);
	// bl 0x8b0df568
	ctx.lr = 0x8B0BEE5C;
	sub_8B0DF568(ctx, base);
	// lwz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// mr r4,r31
	ctx.r4.u64 = ctx.r31.u64;
	// lwz r10,8(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 8);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B0BEE70;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// mr r31,r30
	ctx.r31.u64 = ctx.r30.u64;
	// cmplwi cr6,r30,0
	ctx.cr6.compare<uint32_t>(ctx.r30.u32, 0, ctx.xer);
	// bne cr6,0x8b0bee48
	if (!ctx.cr6.eq) goto loc_8B0BEE48;
loc_8B0BEE7C:
	// lwz r31,20(r28)
	ctx.r31.u64 = REX_LOAD_U32(ctx.r28.u32 + 20);
	// cmplwi cr6,r31,0
	ctx.cr6.compare<uint32_t>(ctx.r31.u32, 0, ctx.xer);
	// beq cr6,0x8b0beec4
	if (ctx.cr6.eq) goto loc_8B0BEEC4;
loc_8B0BEE88:
	// cmplw cr6,r31,r28
	ctx.cr6.compare<uint32_t>(ctx.r31.u32, ctx.r28.u32, ctx.xer);
	// beq cr6,0x8b0beec4
	if (ctx.cr6.eq) goto loc_8B0BEEC4;
	// lwz r30,20(r31)
	ctx.r30.u64 = REX_LOAD_U32(ctx.r31.u32 + 20);
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// stw r29,20(r31)
	REX_STORE_U32(ctx.r31.u32 + 20, ctx.r29.u32);
	// bl 0x8b0bee28
	ctx.lr = 0x8B0BEEA0;
	sub_8B0BEE28(ctx, base);
	// bl 0x8b0df568
	ctx.lr = 0x8B0BEEA4;
	sub_8B0DF568(ctx, base);
	// lwz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// mr r4,r31
	ctx.r4.u64 = ctx.r31.u64;
	// lwz r10,8(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 8);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B0BEEB8;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// mr r31,r30
	ctx.r31.u64 = ctx.r30.u64;
	// cmplwi cr6,r30,0
	ctx.cr6.compare<uint32_t>(ctx.r30.u32, 0, ctx.xer);
	// bne cr6,0x8b0bee88
	if (!ctx.cr6.eq) goto loc_8B0BEE88;
loc_8B0BEEC4:
	// lwz r3,4(r28)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r28.u32 + 4);
	// bl 0x8b090020
	ctx.lr = 0x8B0BEECC;
	sub_8B090020(ctx, base);
	// stw r29,4(r28)
	REX_STORE_U32(ctx.r28.u32 + 4, ctx.r29.u32);
	// lwz r3,8(r28)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r28.u32 + 8);
	// bl 0x8b090020
	ctx.lr = 0x8B0BEED8;
	sub_8B090020(ctx, base);
	// stw r29,8(r28)
	REX_STORE_U32(ctx.r28.u32 + 8, ctx.r29.u32);
	// addi r1,r1,128
	ctx.r1.s64 = ctx.r1.s64 + 128;
	// b 0x8b0cba08
	__restgprlr_28(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0BF230) {
	REX_FUNC_PROLOGUE();
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0bf240
	if (ctx.cr6.eq) goto loc_8B0BF240;
	// lwz r3,20(r3)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r3.u32 + 20);
	// blr 
	return;
loc_8B0BF240:
	// li r3,0
	ctx.r3.s64 = 0;
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0BF280) {
	REX_FUNC_PROLOGUE();
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0bf2b0
	if (ctx.cr6.eq) goto loc_8B0BF2B0;
	// lwz r3,20(r3)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r3.u32 + 20);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0bf2ac
	if (ctx.cr6.eq) goto loc_8B0BF2AC;
loc_8B0BF294:
	// lbz r11,16(r3)
	ctx.r11.u64 = REX_LOAD_U8(ctx.r3.u32 + 16);
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// beq cr6,0x8b0bf2ac
	if (ctx.cr6.eq) goto loc_8B0BF2AC;
	// lwz r3,20(r3)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r3.u32 + 20);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// bne cr6,0x8b0bf294
	if (!ctx.cr6.eq) goto loc_8B0BF294;
loc_8B0BF2AC:
	// blr 
	return;
loc_8B0BF2B0:
	// li r3,0
	ctx.r3.s64 = 0;
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0BF328) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// std r30,-24(r1)
	REX_STORE_U64(ctx.r1.u32 + -24, ctx.r30.u64);
	// std r31,-16(r1)
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.r31.u64);
	// stwu r1,-112(r1)
	ea = -112 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// mr r30,r4
	ctx.r30.u64 = ctx.r4.u64;
	// bl 0x8b0df568
	ctx.lr = 0x8B0BF348;
	sub_8B0DF568(ctx, base);
	// lwz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// li r5,1
	ctx.r5.s64 = 1;
	// mr r4,r30
	ctx.r4.u64 = ctx.r30.u64;
	// lwz r10,12(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 12);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B0BF360;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// stw r3,0(r31)
	REX_STORE_U32(ctx.r31.u32 + 0, ctx.r3.u32);
	// addi r1,r1,112
	ctx.r1.s64 = ctx.r1.s64 + 112;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// ld r30,-24(r1)
	ctx.r30.u64 = REX_LOAD_U64(ctx.r1.u32 + -24);
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0BF448) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// std r31,-16(r1)
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.r31.u64);
	// stwu r1,-96(r1)
	ea = -96 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// bl 0x8b0df568
	ctx.lr = 0x8B0BF460;
	sub_8B0DF568(ctx, base);
	// lwz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// mr r4,r31
	ctx.r4.u64 = ctx.r31.u64;
	// lwz r10,4(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 4);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B0BF474;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// addi r1,r1,96
	ctx.r1.s64 = ctx.r1.s64 + 96;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0BF510) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9b4
	ctx.lr = 0x8B0BF518;
	__savegprlr_27(ctx, base);
	// stwu r1,-128(r1)
	ea = -128 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lwz r11,0(r4)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r4.u32 + 0);
	// mr r29,r4
	ctx.r29.u64 = ctx.r4.u64;
	// mr r28,r3
	ctx.r28.u64 = ctx.r3.u64;
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// mr r3,r29
	ctx.r3.u64 = ctx.r29.u64;
	// mr r27,r5
	ctx.r27.u64 = ctx.r5.u64;
	// lwz r10,0(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 0);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B0BF540;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// clrlwi r9,r3,24
	ctx.r9.u64 = ctx.r3.u32 & 0xFF;
	// cmplwi cr6,r9,0
	ctx.cr6.compare<uint32_t>(ctx.r9.u32, 0, ctx.xer);
	// bne cr6,0x8b0bf558
	if (!ctx.cr6.eq) goto loc_8B0BF558;
loc_8B0BF54C:
	// li r3,0
	ctx.r3.s64 = 0;
	// addi r1,r1,128
	ctx.r1.s64 = ctx.r1.s64 + 128;
	// b 0x8b0cba04
	__restgprlr_27(ctx, base);
	return;
loc_8B0BF558:
	// cmplwi cr6,r28,0
	ctx.cr6.compare<uint32_t>(ctx.r28.u32, 0, ctx.xer);
	// beq cr6,0x8b0bf678
	if (ctx.cr6.eq) goto loc_8B0BF678;
	// lwz r11,24(r28)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r28.u32 + 24);
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// beq cr6,0x8b0bf584
	if (ctx.cr6.eq) goto loc_8B0BF584;
loc_8B0BF56C:
	// lbz r10,16(r11)
	ctx.r10.u64 = REX_LOAD_U8(ctx.r11.u32 + 16);
	// cmplwi cr6,r10,0
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 0, ctx.xer);
	// bne cr6,0x8b0bf584
	if (!ctx.cr6.eq) goto loc_8B0BF584;
	// lwz r11,20(r11)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r11.u32 + 20);
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// bne cr6,0x8b0bf56c
	if (!ctx.cr6.eq) goto loc_8B0BF56C;
loc_8B0BF584:
	// mr r31,r11
	ctx.r31.u64 = ctx.r11.u64;
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// beq cr6,0x8b0bf5f4
	if (ctx.cr6.eq) goto loc_8B0BF5F4;
	// addi r30,r27,1
	ctx.r30.s64 = ctx.r27.s64 + 1;
loc_8B0BF594:
	// lwz r11,0(r29)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r29.u32 + 0);
	// mr r5,r30
	ctx.r5.u64 = ctx.r30.u64;
	// mr r4,r31
	ctx.r4.u64 = ctx.r31.u64;
	// mr r3,r29
	ctx.r3.u64 = ctx.r29.u64;
	// lwz r10,4(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 4);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B0BF5B0;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// clrlwi r9,r3,24
	ctx.r9.u64 = ctx.r3.u32 & 0xFF;
	// cmplwi cr6,r9,0
	ctx.cr6.compare<uint32_t>(ctx.r9.u32, 0, ctx.xer);
	// beq cr6,0x8b0bf54c
	if (ctx.cr6.eq) goto loc_8B0BF54C;
	// cmplwi cr6,r31,0
	ctx.cr6.compare<uint32_t>(ctx.r31.u32, 0, ctx.xer);
	// beq cr6,0x8b0bf69c
	if (ctx.cr6.eq) goto loc_8B0BF69C;
	// lwz r11,20(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 20);
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// beq cr6,0x8b0bf5e8
	if (ctx.cr6.eq) goto loc_8B0BF5E8;
loc_8B0BF5D0:
	// lbz r10,16(r11)
	ctx.r10.u64 = REX_LOAD_U8(ctx.r11.u32 + 16);
	// cmplwi cr6,r10,0
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 0, ctx.xer);
	// bne cr6,0x8b0bf5e8
	if (!ctx.cr6.eq) goto loc_8B0BF5E8;
	// lwz r11,20(r11)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r11.u32 + 20);
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// bne cr6,0x8b0bf5d0
	if (!ctx.cr6.eq) goto loc_8B0BF5D0;
loc_8B0BF5E8:
	// mr r31,r11
	ctx.r31.u64 = ctx.r11.u64;
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// bne cr6,0x8b0bf594
	if (!ctx.cr6.eq) goto loc_8B0BF594;
loc_8B0BF5F4:
	// lwz r31,24(r28)
	ctx.r31.u64 = REX_LOAD_U32(ctx.r28.u32 + 24);
	// cmplwi cr6,r31,0
	ctx.cr6.compare<uint32_t>(ctx.r31.u32, 0, ctx.xer);
	// beq cr6,0x8b0bf678
	if (ctx.cr6.eq) goto loc_8B0BF678;
loc_8B0BF600:
	// lbz r11,16(r31)
	ctx.r11.u64 = REX_LOAD_U8(ctx.r31.u32 + 16);
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// beq cr6,0x8b0bf618
	if (ctx.cr6.eq) goto loc_8B0BF618;
	// lwz r31,20(r31)
	ctx.r31.u64 = REX_LOAD_U32(ctx.r31.u32 + 20);
	// cmplwi cr6,r31,0
	ctx.cr6.compare<uint32_t>(ctx.r31.u32, 0, ctx.xer);
	// bne cr6,0x8b0bf600
	if (!ctx.cr6.eq) goto loc_8B0BF600;
loc_8B0BF618:
	// cmplwi cr6,r31,0
	ctx.cr6.compare<uint32_t>(ctx.r31.u32, 0, ctx.xer);
	// beq cr6,0x8b0bf678
	if (ctx.cr6.eq) goto loc_8B0BF678;
	// addi r30,r27,1
	ctx.r30.s64 = ctx.r27.s64 + 1;
loc_8B0BF624:
	// mr r5,r30
	ctx.r5.u64 = ctx.r30.u64;
	// mr r4,r29
	ctx.r4.u64 = ctx.r29.u64;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0bf510
	ctx.lr = 0x8B0BF634;
	sub_8B0BF510(ctx, base);
	// clrlwi r11,r3,24
	ctx.r11.u64 = ctx.r3.u32 & 0xFF;
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// beq cr6,0x8b0bf54c
	if (ctx.cr6.eq) goto loc_8B0BF54C;
	// cmplwi cr6,r31,0
	ctx.cr6.compare<uint32_t>(ctx.r31.u32, 0, ctx.xer);
	// beq cr6,0x8b0bf6a4
	if (ctx.cr6.eq) goto loc_8B0BF6A4;
	// lwz r11,20(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 20);
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// beq cr6,0x8b0bf66c
	if (ctx.cr6.eq) goto loc_8B0BF66C;
loc_8B0BF654:
	// lbz r10,16(r11)
	ctx.r10.u64 = REX_LOAD_U8(ctx.r11.u32 + 16);
	// cmplwi cr6,r10,0
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 0, ctx.xer);
	// beq cr6,0x8b0bf66c
	if (ctx.cr6.eq) goto loc_8B0BF66C;
	// lwz r11,20(r11)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r11.u32 + 20);
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// bne cr6,0x8b0bf654
	if (!ctx.cr6.eq) goto loc_8B0BF654;
loc_8B0BF66C:
	// mr r31,r11
	ctx.r31.u64 = ctx.r11.u64;
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// bne cr6,0x8b0bf624
	if (!ctx.cr6.eq) goto loc_8B0BF624;
loc_8B0BF678:
	// lwz r11,0(r29)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r29.u32 + 0);
	// mr r5,r27
	ctx.r5.u64 = ctx.r27.u64;
	// mr r4,r28
	ctx.r4.u64 = ctx.r28.u64;
	// mr r3,r29
	ctx.r3.u64 = ctx.r29.u64;
	// lwz r10,8(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 8);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B0BF694;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// addi r1,r1,128
	ctx.r1.s64 = ctx.r1.s64 + 128;
	// b 0x8b0cba04
	__restgprlr_27(ctx, base);
	return;
loc_8B0BF69C:
	// li r11,0
	ctx.r11.s64 = 0;
	// b 0x8b0bf5e8
	goto loc_8B0BF5E8;
loc_8B0BF6A4:
	// li r11,0
	ctx.r11.s64 = 0;
	// b 0x8b0bf66c
	goto loc_8B0BF66C;
}

DEFINE_REX_FUNC(sub_8B0BFC38) {
	REX_FUNC_PROLOGUE();
	PPCRegister temp{};
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// std r31,-16(r1)
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.r31.u64);
	// stwu r1,-112(r1)
	ea = -112 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// mr r31,r5
	ctx.r31.u64 = ctx.r5.u64;
	// li r5,0
	ctx.r5.s64 = 0;
	// bl 0x8b0bfa88
	ctx.lr = 0x8B0BFC54;
	sub_8B0BFA88(ctx, base);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0bfd18
	if (ctx.cr6.eq) goto loc_8B0BFD18;
	// lbz r11,16(r3)
	ctx.r11.u64 = REX_LOAD_U8(ctx.r3.u32 + 16);
	// addi r11,r11,-1
	ctx.r11.s64 = ctx.r11.s64 + -1;
	// cmplwi cr6,r11,6
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 6, ctx.xer);
	// bgt cr6,0x8b0bfd00
	if (ctx.cr6.gt) goto loc_8B0BFD00;
	// mtctr r11
	ctx.ctr.u64 = ctx.r11.u64;
	// cmpwi cr6,r11,0
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// bdzf 4*cr6+eq,0x8b0bfd00
	--ctx.ctr.u64;
	if (ctx.ctr.u32 == 0 && !ctx.cr6.eq) goto loc_8B0BFD00;
	// bdzf 4*cr6+eq,0x8b0bfcc4
	--ctx.ctr.u64;
	if (ctx.ctr.u32 == 0 && !ctx.cr6.eq) goto loc_8B0BFCC4;
	// bdzf 4*cr6+eq,0x8b0bfd00
	--ctx.ctr.u64;
	if (ctx.ctr.u32 == 0 && !ctx.cr6.eq) goto loc_8B0BFD00;
	// bdzf 4*cr6+eq,0x8b0bfca8
	--ctx.ctr.u64;
	if (ctx.ctr.u32 == 0 && !ctx.cr6.eq) goto loc_8B0BFCA8;
	// bdzf 4*cr6+eq,0x8b0bfd00
	--ctx.ctr.u64;
	if (ctx.ctr.u32 == 0 && !ctx.cr6.eq) goto loc_8B0BFD00;
	// bne cr6,0x8b0bfce8
	if (!ctx.cr6.eq) goto loc_8B0BFCE8;
	// lwz r3,4(r3)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r3.u32 + 4);
	// bl 0x8b0cc598
	ctx.lr = 0x8B0BFC94;
	sub_8B0CC598(ctx, base);
	// addi r1,r1,112
	ctx.r1.s64 = ctx.r1.s64 + 112;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
loc_8B0BFCA8:
	// lwz r3,8(r3)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r3.u32 + 8);
	// bl 0x8b0cdff8
	ctx.lr = 0x8B0BFCB0;
	sub_8B0CDFF8(ctx, base);
	// addi r1,r1,112
	ctx.r1.s64 = ctx.r1.s64 + 112;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
loc_8B0BFCC4:
	// lfs f0,12(r3)
	ctx.fpscr.disableFlushMode();
	temp.u32 = REX_LOAD_U32(ctx.r3.u32 + 12);
	ctx.f0.f64 = double(temp.f32);
	// fctiwz f13,f0
	ctx.f13.s64 = std::isnan(ctx.f0.f64) ? int64_t(0x80000000U) : (ctx.f0.f64 >= double(INT_MAX)) ? INT_MAX : simde_mm_cvttsd_si32(simde_mm_load_sd(&ctx.f0.f64));
	// stfd f13,80(r1)
	REX_STORE_U64(ctx.r1.u32 + 80, ctx.f13.u64);
	// lwz r3,84(r1)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r1.u32 + 84);
	// addi r1,r1,112
	ctx.r1.s64 = ctx.r1.s64 + 112;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
loc_8B0BFCE8:
	// li r3,0
	ctx.r3.s64 = 0;
	// addi r1,r1,112
	ctx.r1.s64 = ctx.r1.s64 + 112;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
loc_8B0BFD00:
	// lwz r3,12(r3)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r3.u32 + 12);
	// addi r1,r1,112
	ctx.r1.s64 = ctx.r1.s64 + 112;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
loc_8B0BFD18:
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// addi r1,r1,112
	ctx.r1.s64 = ctx.r1.s64 + 112;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0C00A8) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9bc
	ctx.lr = 0x8B0C00B0;
	__savegprlr_29(ctx, base);
	// stwu r1,-112(r1)
	ea = -112 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// mr r31,r5
	ctx.r31.u64 = ctx.r5.u64;
	// li r5,1
	ctx.r5.s64 = 1;
	// bl 0x8b0bfa88
	ctx.lr = 0x8B0C00C0;
	sub_8B0BFA88(ctx, base);
	// mr r30,r3
	ctx.r30.u64 = ctx.r3.u64;
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0c013c
	if (ctx.cr6.eq) goto loc_8B0C013C;
	// lwz r3,8(r3)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r3.u32 + 8);
	// bl 0x8b090020
	ctx.lr = 0x8B0C00D4;
	sub_8B090020(ctx, base);
	// lwz r3,4(r30)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r30.u32 + 4);
	// bl 0x8b090020
	ctx.lr = 0x8B0C00DC;
	sub_8B090020(ctx, base);
	// li r11,0
	ctx.r11.s64 = 0;
	// cmplwi cr6,r31,0
	ctx.cr6.compare<uint32_t>(ctx.r31.u32, 0, ctx.xer);
	// stw r11,4(r30)
	REX_STORE_U32(ctx.r30.u32 + 4, ctx.r11.u32);
	// bne cr6,0x8b0c00f4
	if (!ctx.cr6.eq) goto loc_8B0C00F4;
	// lis r11,-29943
	ctx.r11.s64 = -1962344448;
	// addi r31,r11,-28248
	ctx.r31.s64 = ctx.r11.s64 + -28248;
loc_8B0C00F4:
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0cdfd0
	ctx.lr = 0x8B0C00FC;
	sub_8B0CDFD0(ctx, base);
	// lis r10,32767
	ctx.r10.s64 = 2147418112;
	// addi r11,r3,1
	ctx.r11.s64 = ctx.r3.s64 + 1;
	// ori r9,r10,65535
	ctx.r9.u64 = ctx.r10.u64 | 65535;
	// mr r29,r3
	ctx.r29.u64 = ctx.r3.u64;
	// cmplw cr6,r11,r9
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, ctx.r9.u32, ctx.xer);
	// rlwinm r3,r11,1,0,30
	ctx.r3.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 1) & 0xFFFFFFFE;
	// ble cr6,0x8b0c011c
	if (!ctx.cr6.gt) goto loc_8B0C011C;
	// li r3,-1
	ctx.r3.s64 = -1;
loc_8B0C011C:
	// bl 0x8b090000
	ctx.lr = 0x8B0C0120;
	sub_8B090000(ctx, base);
	// stw r3,8(r30)
	REX_STORE_U32(ctx.r30.u32 + 8, ctx.r3.u32);
	// addi r11,r29,1
	ctx.r11.s64 = ctx.r29.s64 + 1;
	// mr r4,r31
	ctx.r4.u64 = ctx.r31.u64;
	// rlwinm r5,r11,1,0,30
	ctx.r5.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 1) & 0xFFFFFFFE;
	// bl 0x8b0cbb30
	ctx.lr = 0x8B0C0134;
	sub_8B0CBB30(ctx, base);
	// li r10,5
	ctx.r10.s64 = 5;
	// stb r10,16(r30)
	REX_STORE_U8(ctx.r30.u32 + 16, ctx.r10.u8);
loc_8B0C013C:
	// addi r1,r1,112
	ctx.r1.s64 = ctx.r1.s64 + 112;
	// b 0x8b0cba0c
	__restgprlr_29(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0C0298) {
	REX_FUNC_PROLOGUE();
	PPCRegister temp{};
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9bc
	ctx.lr = 0x8B0C02A0;
	__savegprlr_29(ctx, base);
	// stwu r1,-112(r1)
	ea = -112 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// bl 0x8b0df568
	ctx.lr = 0x8B0C02AC;
	sub_8B0DF568(ctx, base);
	// lwz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// li r4,36
	ctx.r4.s64 = 36;
	// lwz r10,4(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 4);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B0C02C0;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// mr r30,r3
	ctx.r30.u64 = ctx.r3.u64;
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0c02e8
	if (ctx.cr6.eq) goto loc_8B0C02E8;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0beee8
	ctx.lr = 0x8B0C02D4;
	sub_8B0BEEE8(ctx, base);
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// bl 0x8b0bf9f8
	ctx.lr = 0x8B0C02E0;
	sub_8B0BF9F8(ctx, base);
	// mr r30,r3
	ctx.r30.u64 = ctx.r3.u64;
	// b 0x8b0c02ec
	goto loc_8B0C02EC;
loc_8B0C02E8:
	// li r30,0
	ctx.r30.s64 = 0;
loc_8B0C02EC:
	// lbz r11,16(r31)
	ctx.r11.u64 = REX_LOAD_U8(ctx.r31.u32 + 16);
	// stb r11,16(r30)
	REX_STORE_U8(ctx.r30.u32 + 16, ctx.r11.u8);
	// lbz r11,16(r31)
	ctx.r11.u64 = REX_LOAD_U8(ctx.r31.u32 + 16);
	// addi r11,r11,-1
	ctx.r11.s64 = ctx.r11.s64 + -1;
	// cmplwi cr6,r11,6
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 6, ctx.xer);
	// bgt cr6,0x8b0c0424
	if (ctx.cr6.gt) goto loc_8B0C0424;
	// mtctr r11
	ctx.ctr.u64 = ctx.r11.u64;
	// cmpwi cr6,r11,0
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// bdzf 4*cr6+eq,0x8b0c03bc
	--ctx.ctr.u64;
	if (ctx.ctr.u32 == 0 && !ctx.cr6.eq) goto loc_8B0C03BC;
	// bdzf 4*cr6+eq,0x8b0c03c8
	--ctx.ctr.u64;
	if (ctx.ctr.u32 == 0 && !ctx.cr6.eq) goto loc_8B0C03C8;
	// bdzf 4*cr6+eq,0x8b0c03bc
	--ctx.ctr.u64;
	if (ctx.ctr.u32 == 0 && !ctx.cr6.eq) goto loc_8B0C03BC;
	// bdzf 4*cr6+eq,0x8b0c0370
	--ctx.ctr.u64;
	if (ctx.ctr.u32 == 0 && !ctx.cr6.eq) goto loc_8B0C0370;
	// bdzf 4*cr6+eq,0x8b0c03d4
	--ctx.ctr.u64;
	if (ctx.ctr.u32 == 0 && !ctx.cr6.eq) goto loc_8B0C03D4;
	// bne cr6,0x8b0c03f8
	if (!ctx.cr6.eq) goto loc_8B0C03F8;
	// lwz r10,4(r31)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r31.u32 + 4);
	// cmplwi cr6,r10,0
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 0, ctx.xer);
	// beq cr6,0x8b0c0424
	if (ctx.cr6.eq) goto loc_8B0C0424;
	// mr r11,r10
	ctx.r11.u64 = ctx.r10.u64;
loc_8B0C0334:
	// lbz r9,0(r11)
	ctx.r9.u64 = REX_LOAD_U8(ctx.r11.u32 + 0);
	// addi r11,r11,1
	ctx.r11.s64 = ctx.r11.s64 + 1;
	// cmplwi cr6,r9,0
	ctx.cr6.compare<uint32_t>(ctx.r9.u32, 0, ctx.xer);
	// bne cr6,0x8b0c0334
	if (!ctx.cr6.eq) goto loc_8B0C0334;
	// subf r11,r10,r11
	ctx.r11.u64 = ctx.r11.u64 - ctx.r10.u64;
	// addi r11,r11,-1
	ctx.r11.s64 = ctx.r11.s64 + -1;
	// rotlwi r11,r11,0
	ctx.r11.u64 = __builtin_rotateleft32(ctx.r11.u32, 0);
	// addi r29,r11,1
	ctx.r29.s64 = ctx.r11.s64 + 1;
	// mr r3,r29
	ctx.r3.u64 = ctx.r29.u64;
	// bl 0x8b090000
	ctx.lr = 0x8B0C035C;
	sub_8B090000(ctx, base);
	// stw r3,4(r30)
	REX_STORE_U32(ctx.r30.u32 + 4, ctx.r3.u32);
	// mr r5,r29
	ctx.r5.u64 = ctx.r29.u64;
	// lwz r4,4(r31)
	ctx.r4.u64 = REX_LOAD_U32(ctx.r31.u32 + 4);
	// bl 0x8b0cbb30
	ctx.lr = 0x8B0C036C;
	sub_8B0CBB30(ctx, base);
	// b 0x8b0c0424
	goto loc_8B0C0424;
loc_8B0C0370:
	// lwz r3,8(r31)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r31.u32 + 8);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0c0424
	if (ctx.cr6.eq) goto loc_8B0C0424;
	// bl 0x8b0cdfd0
	ctx.lr = 0x8B0C0380;
	sub_8B0CDFD0(ctx, base);
	// lis r10,32767
	ctx.r10.s64 = 2147418112;
	// addi r11,r3,1
	ctx.r11.s64 = ctx.r3.s64 + 1;
	// ori r9,r10,65535
	ctx.r9.u64 = ctx.r10.u64 | 65535;
	// mr r29,r3
	ctx.r29.u64 = ctx.r3.u64;
	// cmplw cr6,r11,r9
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, ctx.r9.u32, ctx.xer);
	// rlwinm r3,r11,1,0,30
	ctx.r3.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 1) & 0xFFFFFFFE;
	// ble cr6,0x8b0c03a0
	if (!ctx.cr6.gt) goto loc_8B0C03A0;
	// li r3,-1
	ctx.r3.s64 = -1;
loc_8B0C03A0:
	// bl 0x8b090000
	ctx.lr = 0x8B0C03A4;
	sub_8B090000(ctx, base);
	// stw r3,8(r30)
	REX_STORE_U32(ctx.r30.u32 + 8, ctx.r3.u32);
	// addi r11,r29,1
	ctx.r11.s64 = ctx.r29.s64 + 1;
	// rlwinm r5,r11,1,0,30
	ctx.r5.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 1) & 0xFFFFFFFE;
	// lwz r4,8(r31)
	ctx.r4.u64 = REX_LOAD_U32(ctx.r31.u32 + 8);
	// bl 0x8b0cbb30
	ctx.lr = 0x8B0C03B8;
	sub_8B0CBB30(ctx, base);
	// b 0x8b0c0424
	goto loc_8B0C0424;
loc_8B0C03BC:
	// lwz r11,12(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 12);
	// stw r11,12(r30)
	REX_STORE_U32(ctx.r30.u32 + 12, ctx.r11.u32);
	// b 0x8b0c0424
	goto loc_8B0C0424;
loc_8B0C03C8:
	// lfs f0,12(r31)
	ctx.fpscr.disableFlushMode();
	temp.u32 = REX_LOAD_U32(ctx.r31.u32 + 12);
	ctx.f0.f64 = double(temp.f32);
	// stfs f0,12(r30)
	temp.f32 = float(ctx.f0.f64);
	REX_STORE_U32(ctx.r30.u32 + 12, temp.u32);
	// b 0x8b0c0424
	goto loc_8B0C0424;
loc_8B0C03D4:
	// lbz r11,12(r31)
	ctx.r11.u64 = REX_LOAD_U8(ctx.r31.u32 + 12);
	// stb r11,12(r30)
	REX_STORE_U8(ctx.r30.u32 + 12, ctx.r11.u8);
	// lbz r10,13(r31)
	ctx.r10.u64 = REX_LOAD_U8(ctx.r31.u32 + 13);
	// stb r10,13(r30)
	REX_STORE_U8(ctx.r30.u32 + 13, ctx.r10.u8);
	// lbz r9,14(r31)
	ctx.r9.u64 = REX_LOAD_U8(ctx.r31.u32 + 14);
	// stb r9,14(r30)
	REX_STORE_U8(ctx.r30.u32 + 14, ctx.r9.u8);
	// lbz r8,15(r31)
	ctx.r8.u64 = REX_LOAD_U8(ctx.r31.u32 + 15);
	// stb r8,15(r30)
	REX_STORE_U8(ctx.r30.u32 + 15, ctx.r8.u8);
	// b 0x8b0c0424
	goto loc_8B0C0424;
loc_8B0C03F8:
	// li r3,8
	ctx.r3.s64 = 8;
	// bl 0x8b090000
	ctx.lr = 0x8B0C0400;
	sub_8B090000(ctx, base);
	// stw r3,4(r30)
	REX_STORE_U32(ctx.r30.u32 + 4, ctx.r3.u32);
	// li r9,8
	ctx.r9.s64 = 8;
	// addi r10,r3,-1
	ctx.r10.s64 = ctx.r3.s64 + -1;
	// mtctr r9
	ctx.ctr.u64 = ctx.r9.u64;
	// lwz r11,4(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 4);
	// addi r11,r11,-1
	ctx.r11.s64 = ctx.r11.s64 + -1;
loc_8B0C0418:
	// lbzu r9,1(r11)
	ea = 1 + ctx.r11.u32;
	ctx.r9.u64 = REX_LOAD_U8(ea);
	ctx.r11.u32 = ea;
	// stbu r9,1(r10)
	ea = 1 + ctx.r10.u32;
	REX_STORE_U8(ea, ctx.r9.u8);
	ctx.r10.u32 = ea;
	// bdnz 0x8b0c0418
	--ctx.ctr.u64;
	if (ctx.ctr.u32 != 0) goto loc_8B0C0418;
loc_8B0C0424:
	// mr r4,r30
	ctx.r4.u64 = ctx.r30.u64;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0bf380
	ctx.lr = 0x8B0C0430;
	sub_8B0BF380(ctx, base);
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// addi r1,r1,112
	ctx.r1.s64 = ctx.r1.s64 + 112;
	// b 0x8b0cba0c
	__restgprlr_29(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0C1160) {
	REX_FUNC_PROLOGUE();
	PPCRegister temp{};
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// std r30,-24(r1)
	REX_STORE_U64(ctx.r1.u32 + -24, ctx.r30.u64);
	// std r31,-16(r1)
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.r31.u64);
	// stwu r1,-112(r1)
	ea = -112 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// mr r30,r4
	ctx.r30.u64 = ctx.r4.u64;
	// li r4,4
	ctx.r4.s64 = 4;
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// bl 0x8b0c7a58
	ctx.lr = 0x8B0C1184;
	sub_8B0C7A58(ctx, base);
	// clrlwi r11,r3,24
	ctx.r11.u64 = ctx.r3.u32 & 0xFF;
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// beq cr6,0x8b0c1210
	if (ctx.cr6.eq) goto loc_8B0C1210;
	// lwz r11,32(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 32);
	// lwz r9,12(r31)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r31.u32 + 12);
	// lwz r10,0(r31)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r31.u32 + 0);
	// subf r11,r11,r9
	ctx.r11.u64 = ctx.r9.u64 - ctx.r11.u64;
	// add r11,r11,r10
	ctx.r11.u64 = ctx.r11.u64 + ctx.r10.u64;
	// clrlwi r8,r11,30
	ctx.r8.u64 = ctx.r11.u32 & 0x3;
	// cmplwi cr6,r8,0
	ctx.cr6.compare<uint32_t>(ctx.r8.u32, 0, ctx.xer);
	// beq cr6,0x8b0c11d4
	if (ctx.cr6.eq) goto loc_8B0C11D4;
	// lbz r10,0(r11)
	ctx.r10.u64 = REX_LOAD_U8(ctx.r11.u32 + 0);
	// stb r10,0(r30)
	REX_STORE_U8(ctx.r30.u32 + 0, ctx.r10.u8);
	// lbz r9,1(r11)
	ctx.r9.u64 = REX_LOAD_U8(ctx.r11.u32 + 1);
	// stb r9,1(r30)
	REX_STORE_U8(ctx.r30.u32 + 1, ctx.r9.u8);
	// lbz r8,2(r11)
	ctx.r8.u64 = REX_LOAD_U8(ctx.r11.u32 + 2);
	// stb r8,2(r30)
	REX_STORE_U8(ctx.r30.u32 + 2, ctx.r8.u8);
	// lbz r7,3(r11)
	ctx.r7.u64 = REX_LOAD_U8(ctx.r11.u32 + 3);
	// stb r7,3(r30)
	REX_STORE_U8(ctx.r30.u32 + 3, ctx.r7.u8);
	// b 0x8b0c11dc
	goto loc_8B0C11DC;
loc_8B0C11D4:
	// lfs f0,0(r11)
	ctx.fpscr.disableFlushMode();
	temp.u32 = REX_LOAD_U32(ctx.r11.u32 + 0);
	ctx.f0.f64 = double(temp.f32);
	// stfs f0,0(r30)
	temp.f32 = float(ctx.f0.f64);
	REX_STORE_U32(ctx.r30.u32 + 0, temp.u32);
loc_8B0C11DC:
	// lwz r11,44(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 44);
	// addi r3,r31,44
	ctx.r3.s64 = ctx.r31.s64 + 44;
	// rlwinm r10,r11,1,31,31
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 1) & 0x1;
	// cmplwi cr6,r10,0
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 0, ctx.xer);
	// beq cr6,0x8b0c1200
	if (ctx.cr6.eq) goto loc_8B0C1200;
	// li r6,1
	ctx.r6.s64 = 1;
	// mr r5,r30
	ctx.r5.u64 = ctx.r30.u64;
	// mr r4,r30
	ctx.r4.u64 = ctx.r30.u64;
	// bl 0x8b0c0ef0
	ctx.lr = 0x8B0C1200;
	sub_8B0C0EF0(ctx, base);
loc_8B0C1200:
	// lwz r11,12(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 12);
	// addi r11,r11,4
	ctx.r11.s64 = ctx.r11.s64 + 4;
	// stw r11,12(r31)
	REX_STORE_U32(ctx.r31.u32 + 12, ctx.r11.u32);
	// b 0x8b0c121c
	goto loc_8B0C121C;
loc_8B0C1210:
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lfs f0,8492(r11)
	ctx.fpscr.disableFlushMode();
	temp.u32 = REX_LOAD_U32(ctx.r11.u32 + 8492);
	ctx.f0.f64 = double(temp.f32);
	// stfs f0,0(r30)
	temp.f32 = float(ctx.f0.f64);
	REX_STORE_U32(ctx.r30.u32 + 0, temp.u32);
loc_8B0C121C:
	// addi r1,r1,112
	ctx.r1.s64 = ctx.r1.s64 + 112;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// ld r30,-24(r1)
	ctx.r30.u64 = REX_LOAD_U64(ctx.r1.u32 + -24);
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0C1390) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9b8
	ctx.lr = 0x8B0C1398;
	__savegprlr_28(ctx, base);
	// stwu r1,-128(r1)
	ea = -128 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// li r11,0
	ctx.r11.s64 = 0;
	// li r10,-1
	ctx.r10.s64 = -1;
	// stb r11,16(r3)
	REX_STORE_U8(ctx.r3.u32 + 16, ctx.r11.u8);
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// stw r10,0(r3)
	REX_STORE_U32(ctx.r3.u32 + 0, ctx.r10.u32);
	// mr r29,r4
	ctx.r29.u64 = ctx.r4.u64;
	// stw r11,24(r3)
	REX_STORE_U32(ctx.r3.u32 + 24, ctx.r11.u32);
	// mr r28,r5
	ctx.r28.u64 = ctx.r5.u64;
	// stw r11,20(r3)
	REX_STORE_U32(ctx.r3.u32 + 20, ctx.r11.u32);
	// mr r30,r6
	ctx.r30.u64 = ctx.r6.u64;
	// stw r11,28(r3)
	REX_STORE_U32(ctx.r3.u32 + 28, ctx.r11.u32);
	// stw r11,4(r3)
	REX_STORE_U32(ctx.r3.u32 + 4, ctx.r11.u32);
	// stw r11,8(r3)
	REX_STORE_U32(ctx.r3.u32 + 8, ctx.r11.u32);
	// stw r11,12(r3)
	REX_STORE_U32(ctx.r3.u32 + 12, ctx.r11.u32);
	// stb r11,17(r3)
	REX_STORE_U8(ctx.r3.u32 + 17, ctx.r11.u8);
	// stw r11,32(r3)
	REX_STORE_U32(ctx.r3.u32 + 32, ctx.r11.u32);
	// sth r11,18(r3)
	REX_STORE_U16(ctx.r3.u32 + 18, ctx.r11.u16);
	// bl 0x8b0df568
	ctx.lr = 0x8B0C13E4;
	sub_8B0DF568(ctx, base);
	// lwz r9,0(r3)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// li r5,1
	ctx.r5.s64 = 1;
	// mr r4,r29
	ctx.r4.u64 = ctx.r29.u64;
	// lwz r8,12(r9)
	ctx.r8.u64 = REX_LOAD_U32(ctx.r9.u32 + 12);
	// mtctr r8
	ctx.ctr.u64 = ctx.r8.u64;
	// bctrl 
	ctx.lr = 0x8B0C13FC;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// stw r3,0(r31)
	REX_STORE_U32(ctx.r31.u32 + 0, ctx.r3.u32);
	// li r5,1
	ctx.r5.s64 = 1;
	// mr r4,r28
	ctx.r4.u64 = ctx.r28.u64;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0bfa88
	ctx.lr = 0x8B0C1410;
	sub_8B0BFA88(ctx, base);
	// mr r11,r3
	ctx.r11.u64 = ctx.r3.u64;
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// beq cr6,0x8b0c142c
	if (ctx.cr6.eq) goto loc_8B0C142C;
	// li r10,2
	ctx.r10.s64 = 2;
	// stw r30,12(r11)
	REX_STORE_U32(ctx.r11.u32 + 12, ctx.r30.u32);
	// stb r10,16(r11)
	REX_STORE_U8(ctx.r11.u32 + 16, ctx.r10.u8);
loc_8B0C142C:
	// addi r1,r1,128
	ctx.r1.s64 = ctx.r1.s64 + 128;
	// b 0x8b0cba08
	__restgprlr_28(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0C16E8) {
	REX_FUNC_PROLOGUE();
	PPCRegister temp{};
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9b4
	ctx.lr = 0x8B0C16F0;
	__savegprlr_27(ctx, base);
	// stwu r1,-256(r1)
	ea = -256 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// mr r27,r5
	ctx.r27.u64 = ctx.r5.u64;
	// li r5,0
	ctx.r5.s64 = 0;
	// mr r30,r3
	ctx.r30.u64 = ctx.r3.u64;
	// mr r29,r4
	ctx.r29.u64 = ctx.r4.u64;
	// bl 0x8b0bfa88
	ctx.lr = 0x8B0C1708;
	sub_8B0BFA88(ctx, base);
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0c1830
	if (ctx.cr6.eq) goto loc_8B0C1830;
	// lbz r11,16(r3)
	ctx.r11.u64 = REX_LOAD_U8(ctx.r3.u32 + 16);
	// addi r11,r11,-1
	ctx.r11.s64 = ctx.r11.s64 + -1;
	// cmplwi cr6,r11,6
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 6, ctx.xer);
	// bgt cr6,0x8b0c1830
	if (ctx.cr6.gt) goto loc_8B0C1830;
	// mtctr r11
	ctx.ctr.u64 = ctx.r11.u64;
	// cmpwi cr6,r11,0
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// beq cr6,0x8b0c17e4
	if (ctx.cr6.eq) goto loc_8B0C17E4;
	// bdz 0x8b0c1780
	--ctx.ctr.u64;
	if (ctx.ctr.u32 == 0) goto loc_8B0C1780;
	// bdz 0x8b0c1748
	--ctx.ctr.u64;
	if (ctx.ctr.u32 == 0) goto loc_8B0C1748;
	// bdz 0x8b0c1780
	--ctx.ctr.u64;
	if (ctx.ctr.u32 == 0) goto loc_8B0C1780;
	// bdz 0x8b0c1824
	--ctx.ctr.u64;
	if (ctx.ctr.u32 == 0) goto loc_8B0C1824;
	// bdz 0x8b0c1830
	--ctx.ctr.u64;
	if (ctx.ctr.u32 == 0) goto loc_8B0C1830;
	// b 0x8b0c17b0
	goto loc_8B0C17B0;
loc_8B0C1748:
	// lfs f1,12(r31)
	ctx.fpscr.disableFlushMode();
	temp.u32 = REX_LOAD_U32(ctx.r31.u32 + 12);
	ctx.f1.f64 = double(temp.f32);
	// lis r11,-29943
	ctx.r11.s64 = -1962344448;
	// stfd f1,32(r1)
	REX_STORE_U64(ctx.r1.u32 + 32, ctx.f1.u64);
	// ld r5,32(r1)
	ctx.r5.u64 = REX_LOAD_U64(ctx.r1.u32 + 32);
	// addi r4,r11,-28200
	ctx.r4.s64 = ctx.r11.s64 + -28200;
	// addi r3,r1,80
	ctx.r3.s64 = ctx.r1.s64 + 80;
	// bl 0x8b0becf8
	ctx.lr = 0x8B0C1764;
	sub_8B0BECF8(ctx, base);
	// addi r5,r1,80
	ctx.r5.s64 = ctx.r1.s64 + 80;
	// mr r4,r29
	ctx.r4.u64 = ctx.r29.u64;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// bl 0x8b0c00a8
	ctx.lr = 0x8B0C1774;
	sub_8B0C00A8(ctx, base);
	// lwz r3,8(r31)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r31.u32 + 8);
	// addi r1,r1,256
	ctx.r1.s64 = ctx.r1.s64 + 256;
	// b 0x8b0cba04
	__restgprlr_27(ctx, base);
	return;
loc_8B0C1780:
	// lis r11,-29943
	ctx.r11.s64 = -1962344448;
	// lwz r5,12(r31)
	ctx.r5.u64 = REX_LOAD_U32(ctx.r31.u32 + 12);
	// addi r3,r1,80
	ctx.r3.s64 = ctx.r1.s64 + 80;
	// addi r4,r11,-28208
	ctx.r4.s64 = ctx.r11.s64 + -28208;
	// bl 0x8b0becf8
	ctx.lr = 0x8B0C1794;
	sub_8B0BECF8(ctx, base);
	// addi r5,r1,80
	ctx.r5.s64 = ctx.r1.s64 + 80;
	// mr r4,r29
	ctx.r4.u64 = ctx.r29.u64;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// bl 0x8b0c00a8
	ctx.lr = 0x8B0C17A4;
	sub_8B0C00A8(ctx, base);
	// lwz r3,8(r31)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r31.u32 + 8);
	// addi r1,r1,256
	ctx.r1.s64 = ctx.r1.s64 + 256;
	// b 0x8b0cba04
	__restgprlr_27(ctx, base);
	return;
loc_8B0C17B0:
	// lwz r11,4(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 4);
	// lis r10,-29943
	ctx.r10.s64 = -1962344448;
	// addi r3,r1,80
	ctx.r3.s64 = ctx.r1.s64 + 80;
	// addi r4,r10,-28220
	ctx.r4.s64 = ctx.r10.s64 + -28220;
	// ld r5,0(r11)
	ctx.r5.u64 = REX_LOAD_U64(ctx.r11.u32 + 0);
	// bl 0x8b0becf8
	ctx.lr = 0x8B0C17C8;
	sub_8B0BECF8(ctx, base);
	// addi r5,r1,80
	ctx.r5.s64 = ctx.r1.s64 + 80;
	// mr r4,r29
	ctx.r4.u64 = ctx.r29.u64;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// bl 0x8b0c00a8
	ctx.lr = 0x8B0C17D8;
	sub_8B0C00A8(ctx, base);
	// lwz r3,8(r31)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r31.u32 + 8);
	// addi r1,r1,256
	ctx.r1.s64 = ctx.r1.s64 + 256;
	// b 0x8b0cba04
	__restgprlr_27(ctx, base);
	return;
loc_8B0C17E4:
	// lis r11,-29936
	ctx.r11.s64 = -1961885696;
	// lwz r5,4(r31)
	ctx.r5.u64 = REX_LOAD_U32(ctx.r31.u32 + 4);
	// lis r3,0
	ctx.r3.s64 = 0;
	// addi r28,r11,-28880
	ctx.r28.s64 = ctx.r11.s64 + -28880;
	// li r8,512
	ctx.r8.s64 = 512;
	// li r6,-1
	ctx.r6.s64 = -1;
	// mr r7,r28
	ctx.r7.u64 = ctx.r28.u64;
	// li r4,0
	ctx.r4.s64 = 0;
	// ori r3,r3,65001
	ctx.r3.u64 = ctx.r3.u64 | 65001;
	// bl 0x8b0dc260
	ctx.lr = 0x8B0C180C;
	sub_8B0DC260(ctx, base);
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// beq cr6,0x8b0c1830
	if (ctx.cr6.eq) goto loc_8B0C1830;
	// mr r5,r28
	ctx.r5.u64 = ctx.r28.u64;
	// mr r4,r29
	ctx.r4.u64 = ctx.r29.u64;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// bl 0x8b0c00a8
	ctx.lr = 0x8B0C1824;
	sub_8B0C00A8(ctx, base);
loc_8B0C1824:
	// lwz r3,8(r31)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r31.u32 + 8);
	// addi r1,r1,256
	ctx.r1.s64 = ctx.r1.s64 + 256;
	// b 0x8b0cba04
	__restgprlr_27(ctx, base);
	return;
loc_8B0C1830:
	// mr r3,r27
	ctx.r3.u64 = ctx.r27.u64;
	// addi r1,r1,256
	ctx.r1.s64 = ctx.r1.s64 + 256;
	// b 0x8b0cba04
	__restgprlr_27(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0C2170) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// std r30,-24(r1)
	REX_STORE_U64(ctx.r1.u32 + -24, ctx.r30.u64);
	// std r31,-16(r1)
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.r31.u64);
	// stwu r1,-112(r1)
	ea = -112 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// mr r30,r4
	ctx.r30.u64 = ctx.r4.u64;
	// li r4,2
	ctx.r4.s64 = 2;
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// bl 0x8b0c7a58
	ctx.lr = 0x8B0C2194;
	sub_8B0C7A58(ctx, base);
	// clrlwi r11,r3,24
	ctx.r11.u64 = ctx.r3.u32 & 0xFF;
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// beq cr6,0x8b0c2208
	if (ctx.cr6.eq) goto loc_8B0C2208;
	// lwz r11,44(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 44);
	// addi r3,r31,44
	ctx.r3.s64 = ctx.r31.s64 + 44;
	// rlwinm r10,r11,1,31,31
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 1) & 0x1;
	// lwz r11,32(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 32);
	// cmplwi cr6,r10,0
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 0, ctx.xer);
	// beq cr6,0x8b0c21e4
	if (ctx.cr6.eq) goto loc_8B0C21E4;
	// lwz r9,12(r31)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r31.u32 + 12);
	// li r6,1
	ctx.r6.s64 = 1;
	// lwz r10,0(r31)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r31.u32 + 0);
	// mr r4,r30
	ctx.r4.u64 = ctx.r30.u64;
	// subf r11,r11,r9
	ctx.r11.u64 = ctx.r9.u64 - ctx.r11.u64;
	// add r5,r11,r10
	ctx.r5.u64 = ctx.r11.u64 + ctx.r10.u64;
	// bl 0x8b0c0fc0
	ctx.lr = 0x8B0C21D4;
	sub_8B0C0FC0(ctx, base);
	// lwz r11,12(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 12);
	// addi r11,r11,2
	ctx.r11.s64 = ctx.r11.s64 + 2;
	// stw r11,12(r31)
	REX_STORE_U32(ctx.r31.u32 + 12, ctx.r11.u32);
	// b 0x8b0c2210
	goto loc_8B0C2210;
loc_8B0C21E4:
	// lwz r10,12(r31)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r31.u32 + 12);
	// lwz r9,0(r31)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r31.u32 + 0);
	// subf r8,r11,r10
	ctx.r8.u64 = ctx.r10.u64 - ctx.r11.u64;
	// lhzx r7,r8,r9
	ctx.r7.u64 = REX_LOAD_U16(ctx.r8.u32 + ctx.r9.u32);
	// sth r7,0(r30)
	REX_STORE_U16(ctx.r30.u32 + 0, ctx.r7.u16);
	// lwz r11,12(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 12);
	// addi r11,r11,2
	ctx.r11.s64 = ctx.r11.s64 + 2;
	// stw r11,12(r31)
	REX_STORE_U32(ctx.r31.u32 + 12, ctx.r11.u32);
	// b 0x8b0c2210
	goto loc_8B0C2210;
loc_8B0C2208:
	// li r11,0
	ctx.r11.s64 = 0;
	// sth r11,0(r30)
	REX_STORE_U16(ctx.r30.u32 + 0, ctx.r11.u16);
loc_8B0C2210:
	// addi r1,r1,112
	ctx.r1.s64 = ctx.r1.s64 + 112;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// ld r30,-24(r1)
	ctx.r30.u64 = REX_LOAD_U64(ctx.r1.u32 + -24);
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0C22E0) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// std r30,-24(r1)
	REX_STORE_U64(ctx.r1.u32 + -24, ctx.r30.u64);
	// std r31,-16(r1)
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.r31.u64);
	// stwu r1,-112(r1)
	ea = -112 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// mr r30,r4
	ctx.r30.u64 = ctx.r4.u64;
	// li r4,4
	ctx.r4.s64 = 4;
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// bl 0x8b0c7a58
	ctx.lr = 0x8B0C2304;
	sub_8B0C7A58(ctx, base);
	// clrlwi r11,r3,24
	ctx.r11.u64 = ctx.r3.u32 & 0xFF;
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// beq cr6,0x8b0c2378
	if (ctx.cr6.eq) goto loc_8B0C2378;
	// lwz r11,44(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 44);
	// addi r3,r31,44
	ctx.r3.s64 = ctx.r31.s64 + 44;
	// rlwinm r10,r11,1,31,31
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 1) & 0x1;
	// lwz r11,32(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 32);
	// cmplwi cr6,r10,0
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 0, ctx.xer);
	// beq cr6,0x8b0c2354
	if (ctx.cr6.eq) goto loc_8B0C2354;
	// lwz r9,12(r31)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r31.u32 + 12);
	// li r6,1
	ctx.r6.s64 = 1;
	// lwz r10,0(r31)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r31.u32 + 0);
	// mr r4,r30
	ctx.r4.u64 = ctx.r30.u64;
	// subf r11,r11,r9
	ctx.r11.u64 = ctx.r9.u64 - ctx.r11.u64;
	// add r5,r11,r10
	ctx.r5.u64 = ctx.r11.u64 + ctx.r10.u64;
	// bl 0x8b0ac178
	ctx.lr = 0x8B0C2344;
	sub_8B0AC178(ctx, base);
	// lwz r11,12(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 12);
	// addi r11,r11,4
	ctx.r11.s64 = ctx.r11.s64 + 4;
	// stw r11,12(r31)
	REX_STORE_U32(ctx.r31.u32 + 12, ctx.r11.u32);
	// b 0x8b0c2380
	goto loc_8B0C2380;
loc_8B0C2354:
	// lwz r10,12(r31)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r31.u32 + 12);
	// lwz r9,0(r31)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r31.u32 + 0);
	// subf r8,r11,r10
	ctx.r8.u64 = ctx.r10.u64 - ctx.r11.u64;
	// lwzx r7,r8,r9
	ctx.r7.u64 = REX_LOAD_U32(ctx.r8.u32 + ctx.r9.u32);
	// stw r7,0(r30)
	REX_STORE_U32(ctx.r30.u32 + 0, ctx.r7.u32);
	// lwz r11,12(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 12);
	// addi r11,r11,4
	ctx.r11.s64 = ctx.r11.s64 + 4;
	// stw r11,12(r31)
	REX_STORE_U32(ctx.r31.u32 + 12, ctx.r11.u32);
	// b 0x8b0c2380
	goto loc_8B0C2380;
loc_8B0C2378:
	// li r11,0
	ctx.r11.s64 = 0;
	// stw r11,0(r30)
	REX_STORE_U32(ctx.r30.u32 + 0, ctx.r11.u32);
loc_8B0C2380:
	// addi r1,r1,112
	ctx.r1.s64 = ctx.r1.s64 + 112;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// ld r30,-24(r1)
	ctx.r30.u64 = REX_LOAD_U64(ctx.r1.u32 + -24);
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0C2440) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// std r30,-24(r1)
	REX_STORE_U64(ctx.r1.u32 + -24, ctx.r30.u64);
	// std r31,-16(r1)
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.r31.u64);
	// stwu r1,-112(r1)
	ea = -112 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// mr r30,r4
	ctx.r30.u64 = ctx.r4.u64;
	// std r4,136(r1)
	REX_STORE_U64(ctx.r1.u32 + 136, ctx.r4.u64);
	// li r4,8
	ctx.r4.s64 = 8;
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// bl 0x8b0c7d98
	ctx.lr = 0x8B0C2468;
	sub_8B0C7D98(ctx, base);
	// clrlwi r11,r3,24
	ctx.r11.u64 = ctx.r3.u32 & 0xFF;
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// beq cr6,0x8b0c24d0
	if (ctx.cr6.eq) goto loc_8B0C24D0;
	// lwz r11,44(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 44);
	// addi r3,r31,44
	ctx.r3.s64 = ctx.r31.s64 + 44;
	// rlwinm r10,r11,1,31,31
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 1) & 0x1;
	// lwz r11,32(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 32);
	// cmplwi cr6,r10,0
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 0, ctx.xer);
	// beq cr6,0x8b0c24ac
	if (ctx.cr6.eq) goto loc_8B0C24AC;
	// lwz r9,16(r31)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r31.u32 + 16);
	// li r6,1
	ctx.r6.s64 = 1;
	// lwz r10,0(r31)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r31.u32 + 0);
	// addi r5,r1,136
	ctx.r5.s64 = ctx.r1.s64 + 136;
	// subf r11,r11,r9
	ctx.r11.u64 = ctx.r9.u64 - ctx.r11.u64;
	// add r4,r11,r10
	ctx.r4.u64 = ctx.r11.u64 + ctx.r10.u64;
	// bl 0x8b0c1080
	ctx.lr = 0x8B0C24A8;
	sub_8B0C1080(ctx, base);
	// b 0x8b0c24bc
	goto loc_8B0C24BC;
loc_8B0C24AC:
	// lwz r10,16(r31)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r31.u32 + 16);
	// lwz r9,0(r31)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r31.u32 + 0);
	// subf r8,r11,r10
	ctx.r8.u64 = ctx.r10.u64 - ctx.r11.u64;
	// stdx r30,r8,r9
	REX_STORE_U64(ctx.r8.u32 + ctx.r9.u32, ctx.r30.u64);
loc_8B0C24BC:
	// lwz r11,16(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 16);
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// addi r11,r11,8
	ctx.r11.s64 = ctx.r11.s64 + 8;
	// stw r11,16(r31)
	REX_STORE_U32(ctx.r31.u32 + 16, ctx.r11.u32);
	// bl 0x8b0c7e48
	ctx.lr = 0x8B0C24D0;
	sub_8B0C7E48(ctx, base);
loc_8B0C24D0:
	// addi r1,r1,112
	ctx.r1.s64 = ctx.r1.s64 + 112;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// ld r30,-24(r1)
	ctx.r30.u64 = REX_LOAD_U64(ctx.r1.u32 + -24);
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0C2610) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// stwu r1,-96(r1)
	ea = -96 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lbz r11,21(r3)
	ctx.r11.u64 = REX_LOAD_U8(ctx.r3.u32 + 21);
	// clrlwi r10,r11,31
	ctx.r10.u64 = ctx.r11.u32 & 0x1;
	// cmplwi cr6,r10,0
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 0, ctx.xer);
	// bne cr6,0x8b0c2648
	if (!ctx.cr6.eq) goto loc_8B0C2648;
	// addi r4,r1,80
	ctx.r4.s64 = ctx.r1.s64 + 80;
	// bl 0x8b0c20f8
	ctx.lr = 0x8B0C2634;
	sub_8B0C20F8(ctx, base);
	// lbz r3,80(r1)
	ctx.r3.u64 = REX_LOAD_U8(ctx.r1.u32 + 80);
	// addi r1,r1,96
	ctx.r1.s64 = ctx.r1.s64 + 96;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// blr 
	return;
loc_8B0C2648:
	// li r11,0
	ctx.r11.s64 = 0;
	// lis r10,-29943
	ctx.r10.s64 = -1962344448;
	// stb r11,80(r1)
	REX_STORE_U8(ctx.r1.u32 + 80, ctx.r11.u8);
	// addi r5,r1,80
	ctx.r5.s64 = ctx.r1.s64 + 80;
	// addi r4,r10,-27848
	ctx.r4.s64 = ctx.r10.s64 + -27848;
	// bl 0x8b0c95a8
	ctx.lr = 0x8B0C2660;
	sub_8B0C95A8(ctx, base);
	// lbz r3,80(r1)
	ctx.r3.u64 = REX_LOAD_U8(ctx.r1.u32 + 80);
	// addi r1,r1,96
	ctx.r1.s64 = ctx.r1.s64 + 96;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0C2748) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// stwu r1,-96(r1)
	ea = -96 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lbz r11,21(r3)
	ctx.r11.u64 = REX_LOAD_U8(ctx.r3.u32 + 21);
	// clrlwi r10,r11,31
	ctx.r10.u64 = ctx.r11.u32 & 0x1;
	// cmplwi cr6,r10,0
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 0, ctx.xer);
	// bne cr6,0x8b0c2780
	if (!ctx.cr6.eq) goto loc_8B0C2780;
	// addi r4,r1,80
	ctx.r4.s64 = ctx.r1.s64 + 80;
	// bl 0x8b0c22e0
	ctx.lr = 0x8B0C276C;
	sub_8B0C22E0(ctx, base);
	// lwz r3,80(r1)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r1.u32 + 80);
	// addi r1,r1,96
	ctx.r1.s64 = ctx.r1.s64 + 96;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// blr 
	return;
loc_8B0C2780:
	// li r11,0
	ctx.r11.s64 = 0;
	// lis r10,-29943
	ctx.r10.s64 = -1962344448;
	// stw r11,80(r1)
	REX_STORE_U32(ctx.r1.u32 + 80, ctx.r11.u32);
	// addi r5,r1,80
	ctx.r5.s64 = ctx.r1.s64 + 80;
	// addi r4,r10,-27848
	ctx.r4.s64 = ctx.r10.s64 + -27848;
	// bl 0x8b0c95a8
	ctx.lr = 0x8B0C2798;
	sub_8B0C95A8(ctx, base);
	// lwz r3,80(r1)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r1.u32 + 80);
	// addi r1,r1,96
	ctx.r1.s64 = ctx.r1.s64 + 96;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0C2FD8) {
	REX_FUNC_PROLOGUE();
	PPCRegister temp{};
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb994
	ctx.lr = 0x8B0C2FE0;
	__savegprlr_19(ctx, base);
	// stwu r1,-1216(r1)
	ea = -1216 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lbz r11,21(r4)
	ctx.r11.u64 = REX_LOAD_U8(ctx.r4.u32 + 21);
	// mr r29,r3
	ctx.r29.u64 = ctx.r3.u64;
	// mr r27,r4
	ctx.r27.u64 = ctx.r4.u64;
	// clrlwi r10,r11,31
	ctx.r10.u64 = ctx.r11.u32 & 0x1;
	// mr r26,r5
	ctx.r26.u64 = ctx.r5.u64;
	// mr r24,r6
	ctx.r24.u64 = ctx.r6.u64;
	// cmplwi cr6,r10,0
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 0, ctx.xer);
	// beq cr6,0x8b0c3010
	if (ctx.cr6.eq) goto loc_8B0C3010;
loc_8B0C3004:
	// li r3,0
	ctx.r3.s64 = 0;
	// addi r1,r1,1216
	ctx.r1.s64 = ctx.r1.s64 + 1216;
	// b 0x8b0cb9e4
	__restgprlr_19(ctx, base);
	return;
loc_8B0C3010:
	// lbz r11,20(r27)
	ctx.r11.u64 = REX_LOAD_U8(ctx.r27.u32 + 20);
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// bne cr6,0x8b0c3004
	if (!ctx.cr6.eq) goto loc_8B0C3004;
	// mr r3,r27
	ctx.r3.u64 = ctx.r27.u64;
	// bl 0x8b0c2610
	ctx.lr = 0x8B0C3024;
	sub_8B0C2610(ctx, base);
	// clrlwi r31,r3,24
	ctx.r31.u64 = ctx.r3.u32 & 0xFF;
	// cmpwi cr6,r31,11
	ctx.cr6.compare<int32_t>(ctx.r31.s32, 11, ctx.xer);
	// beq cr6,0x8b0c335c
	if (ctx.cr6.eq) goto loc_8B0C335C;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lis r10,32767
	ctx.r10.s64 = 2147418112;
	// li r25,0
	ctx.r25.s64 = 0;
	// ori r21,r10,65535
	ctx.r21.u64 = ctx.r10.u64 | 65535;
	// li r19,-1
	ctx.r19.s64 = -1;
	// li r23,2
	ctx.r23.s64 = 2;
	// li r20,1
	ctx.r20.s64 = 1;
	// addi r22,r11,1791
	ctx.r22.s64 = ctx.r11.s64 + 1791;
loc_8B0C3050:
	// stb r31,16(r29)
	REX_STORE_U8(ctx.r29.u32 + 16, ctx.r31.u8);
	// mr r3,r27
	ctx.r3.u64 = ctx.r27.u64;
	// bl 0x8b0c2748
	ctx.lr = 0x8B0C305C;
	sub_8B0C2748(ctx, base);
	// mr r5,r3
	ctx.r5.u64 = ctx.r3.u64;
	// cmplwi cr6,r26,0
	ctx.cr6.compare<uint32_t>(ctx.r26.u32, 0, ctx.xer);
	// addi r11,r26,-4
	ctx.r11.s64 = ctx.r26.s64 + -4;
	// bne cr6,0x8b0c3070
	if (!ctx.cr6.eq) goto loc_8B0C3070;
	// mr r11,r25
	ctx.r11.u64 = ctx.r25.u64;
loc_8B0C3070:
	// lwz r10,0(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 0);
	// li r7,1024
	ctx.r7.s64 = 1024;
	// addi r6,r1,80
	ctx.r6.s64 = ctx.r1.s64 + 80;
	// mr r4,r24
	ctx.r4.u64 = ctx.r24.u64;
	// mr r3,r11
	ctx.r3.u64 = ctx.r11.u64;
	// lwz r9,440(r10)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r10.u32 + 440);
	// mtctr r9
	ctx.ctr.u64 = ctx.r9.u64;
	// bctrl 
	ctx.lr = 0x8B0C3090;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// clrlwi r8,r3,24
	ctx.r8.u64 = ctx.r3.u32 & 0xFF;
	// cmplwi cr6,r8,0
	ctx.cr6.compare<uint32_t>(ctx.r8.u32, 0, ctx.xer);
	// beq cr6,0x8b0c3004
	if (ctx.cr6.eq) goto loc_8B0C3004;
	// addi r4,r1,80
	ctx.r4.s64 = ctx.r1.s64 + 80;
	// mr r3,r29
	ctx.r3.u64 = ctx.r29.u64;
	// bl 0x8b0bf328
	ctx.lr = 0x8B0C30A8;
	sub_8B0BF328(ctx, base);
	// cmplwi cr6,r31,10
	ctx.cr6.compare<uint32_t>(ctx.r31.u32, 10, ctx.xer);
	// bgt cr6,0x8b0c32e8
	if (ctx.cr6.gt) goto loc_8B0C32E8;
	// lis r12,-29940
	ctx.r12.s64 = -1962147840;
	// rlwinm r0,r31,2,0,29
	ctx.r0.u64 = __builtin_rotateleft64(ctx.r31.u32 | (ctx.r31.u64 << 32), 2) & 0xFFFFFFFC;
	// addi r12,r12,12488
	ctx.r12.s64 = ctx.r12.s64 + 12488;
	// lwzx r0,r12,r0
	ctx.r0.u64 = REX_LOAD_U32(ctx.r12.u32 + ctx.r0.u32);
	// mtctr r0
	ctx.ctr.u64 = ctx.r0.u64;
	// bctr 
	switch (ctx.r31.u32) {
	case 0:
		goto loc_8B0C30F4;
	case 1:
		goto loc_8B0C3148;
	case 2:
		goto loc_8B0C3238;
	case 3:
		goto loc_8B0C3268;
	case 4:
		goto loc_8B0C32AC;
	case 5:
		goto loc_8B0C31D4;
	case 6:
		goto loc_8B0C3278;
	case 7:
		goto loc_8B0C3248;
	case 8:
		goto loc_8B0C32D4;
	case 9:
		goto loc_8B0C32BC;
	case 10:
		goto loc_8B0C32C8;
	default:
		__builtin_trap(); // Switch case out of range
	}
loc_8B0C30F4:
	// bl 0x8b0df568
	ctx.lr = 0x8B0C30F8;
	sub_8B0DF568(ctx, base);
	// lwz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// li r4,36
	ctx.r4.s64 = 36;
	// lwz r10,4(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 4);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B0C310C;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0c3120
	if (ctx.cr6.eq) goto loc_8B0C3120;
	// mr r4,r22
	ctx.r4.u64 = ctx.r22.u64;
	// bl 0x8b0bf9f8
	ctx.lr = 0x8B0C311C;
	sub_8B0BF9F8(ctx, base);
	// b 0x8b0c3124
	goto loc_8B0C3124;
loc_8B0C3120:
	// mr r3,r25
	ctx.r3.u64 = ctx.r25.u64;
loc_8B0C3124:
	// stw r3,24(r29)
	REX_STORE_U32(ctx.r29.u32 + 24, ctx.r3.u32);
	// mr r6,r24
	ctx.r6.u64 = ctx.r24.u64;
	// mr r5,r26
	ctx.r5.u64 = ctx.r26.u64;
	// mr r4,r27
	ctx.r4.u64 = ctx.r27.u64;
	// bl 0x8b0c2fd8
	ctx.lr = 0x8B0C3138;
	sub_8B0C2FD8(ctx, base);
	// clrlwi r11,r3,24
	ctx.r11.u64 = ctx.r3.u32 & 0xFF;
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// beq cr6,0x8b0c3004
	if (ctx.cr6.eq) goto loc_8B0C3004;
	// b 0x8b0c32e8
	goto loc_8B0C32E8;
loc_8B0C3148:
	// mr r3,r27
	ctx.r3.u64 = ctx.r27.u64;
	// bl 0x8b0c2748
	ctx.lr = 0x8B0C3150;
	sub_8B0C2748(ctx, base);
	// mr r5,r3
	ctx.r5.u64 = ctx.r3.u64;
	// cmplwi cr6,r26,0
	ctx.cr6.compare<uint32_t>(ctx.r26.u32, 0, ctx.xer);
	// addi r11,r26,-4
	ctx.r11.s64 = ctx.r26.s64 + -4;
	// bne cr6,0x8b0c3164
	if (!ctx.cr6.eq) goto loc_8B0C3164;
	// mr r11,r25
	ctx.r11.u64 = ctx.r25.u64;
loc_8B0C3164:
	// lwz r10,0(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 0);
	// li r7,1024
	ctx.r7.s64 = 1024;
	// addi r6,r1,80
	ctx.r6.s64 = ctx.r1.s64 + 80;
	// mr r4,r24
	ctx.r4.u64 = ctx.r24.u64;
	// mr r3,r11
	ctx.r3.u64 = ctx.r11.u64;
	// lwz r9,440(r10)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r10.u32 + 440);
	// mtctr r9
	ctx.ctr.u64 = ctx.r9.u64;
	// bctrl 
	ctx.lr = 0x8B0C3184;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// clrlwi r8,r3,24
	ctx.r8.u64 = ctx.r3.u32 & 0xFF;
	// cmplwi cr6,r8,0
	ctx.cr6.compare<uint32_t>(ctx.r8.u32, 0, ctx.xer);
	// beq cr6,0x8b0c3004
	if (ctx.cr6.eq) goto loc_8B0C3004;
	// addi r11,r1,80
	ctx.r11.s64 = ctx.r1.s64 + 80;
	// mr r10,r11
	ctx.r10.u64 = ctx.r11.u64;
loc_8B0C3198:
	// lbz r9,0(r11)
	ctx.r9.u64 = REX_LOAD_U8(ctx.r11.u32 + 0);
	// addi r11,r11,1
	ctx.r11.s64 = ctx.r11.s64 + 1;
	// cmplwi cr6,r9,0
	ctx.cr6.compare<uint32_t>(ctx.r9.u32, 0, ctx.xer);
	// bne cr6,0x8b0c3198
	if (!ctx.cr6.eq) goto loc_8B0C3198;
	// subf r11,r10,r11
	ctx.r11.u64 = ctx.r11.u64 - ctx.r10.u64;
	// addi r11,r11,-1
	ctx.r11.s64 = ctx.r11.s64 + -1;
	// rotlwi r11,r11,0
	ctx.r11.u64 = __builtin_rotateleft32(ctx.r11.u32, 0);
	// addi r31,r11,1
	ctx.r31.s64 = ctx.r11.s64 + 1;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b090000
	ctx.lr = 0x8B0C31C0;
	sub_8B090000(ctx, base);
	// stw r3,4(r29)
	REX_STORE_U32(ctx.r29.u32 + 4, ctx.r3.u32);
	// mr r5,r31
	ctx.r5.u64 = ctx.r31.u64;
	// addi r4,r1,80
	ctx.r4.s64 = ctx.r1.s64 + 80;
	// bl 0x8b0cbb30
	ctx.lr = 0x8B0C31D0;
	sub_8B0CBB30(ctx, base);
	// b 0x8b0c32e8
	goto loc_8B0C32E8;
loc_8B0C31D4:
	// mr r3,r27
	ctx.r3.u64 = ctx.r27.u64;
	// bl 0x8b0c2678
	ctx.lr = 0x8B0C31DC;
	sub_8B0C2678(ctx, base);
	// extsh r28,r3
	ctx.r28.s64 = ctx.r3.s16;
	// addi r11,r28,1
	ctx.r11.s64 = ctx.r28.s64 + 1;
	// cmplw cr6,r11,r21
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, ctx.r21.u32, ctx.xer);
	// rlwinm r3,r11,1,0,30
	ctx.r3.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 1) & 0xFFFFFFFE;
	// ble cr6,0x8b0c31f4
	if (!ctx.cr6.gt) goto loc_8B0C31F4;
	// mr r3,r19
	ctx.r3.u64 = ctx.r19.u64;
loc_8B0C31F4:
	// bl 0x8b090000
	ctx.lr = 0x8B0C31F8;
	sub_8B090000(ctx, base);
	// stw r3,8(r29)
	REX_STORE_U32(ctx.r29.u32 + 8, ctx.r3.u32);
	// cmpwi cr6,r28,0
	ctx.cr6.compare<int32_t>(ctx.r28.s32, 0, ctx.xer);
	// ble cr6,0x8b0c3228
	if (!ctx.cr6.gt) goto loc_8B0C3228;
	// mr r30,r25
	ctx.r30.u64 = ctx.r25.u64;
	// mr r31,r28
	ctx.r31.u64 = ctx.r28.u64;
loc_8B0C320C:
	// mr r3,r27
	ctx.r3.u64 = ctx.r27.u64;
	// bl 0x8b0c2678
	ctx.lr = 0x8B0C3214;
	sub_8B0C2678(ctx, base);
	// lwz r11,8(r29)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r29.u32 + 8);
	// addic. r31,r31,-1
	ctx.xer.ca = ctx.r31.u32 > 0;
	ctx.r31.s64 = ctx.r31.s64 + -1;
	ctx.cr0.compare<int32_t>(ctx.r31.s32, 0, ctx.xer);
	// sthx r3,r30,r11
	REX_STORE_U16(ctx.r30.u32 + ctx.r11.u32, ctx.r3.u16);
	// addi r30,r30,2
	ctx.r30.s64 = ctx.r30.s64 + 2;
	// bne 0x8b0c320c
	if (!ctx.cr0.eq) goto loc_8B0C320C;
loc_8B0C3228:
	// lwz r11,8(r29)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r29.u32 + 8);
	// rlwinm r10,r28,1,0,30
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r28.u32 | (ctx.r28.u64 << 32), 1) & 0xFFFFFFFE;
	// sthx r25,r10,r11
	REX_STORE_U16(ctx.r10.u32 + ctx.r11.u32, ctx.r25.u16);
	// b 0x8b0c32e8
	goto loc_8B0C32E8;
loc_8B0C3238:
	// mr r3,r27
	ctx.r3.u64 = ctx.r27.u64;
	// bl 0x8b0ac368
	ctx.lr = 0x8B0C3240;
	sub_8B0AC368(ctx, base);
	// stw r3,12(r29)
	REX_STORE_U32(ctx.r29.u32 + 12, ctx.r3.u32);
	// b 0x8b0c32e8
	goto loc_8B0C32E8;
loc_8B0C3248:
	// li r3,8
	ctx.r3.s64 = 8;
	// bl 0x8b090000
	ctx.lr = 0x8B0C3250;
	sub_8B090000(ctx, base);
	// stw r3,4(r29)
	REX_STORE_U32(ctx.r29.u32 + 4, ctx.r3.u32);
	// mr r3,r27
	ctx.r3.u64 = ctx.r27.u64;
	// bl 0x8b0c26e0
	ctx.lr = 0x8B0C325C;
	sub_8B0C26E0(ctx, base);
	// lwz r11,4(r29)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r29.u32 + 4);
	// std r3,0(r11)
	REX_STORE_U64(ctx.r11.u32 + 0, ctx.r3.u64);
	// b 0x8b0c32e8
	goto loc_8B0C32E8;
loc_8B0C3268:
	// mr r3,r27
	ctx.r3.u64 = ctx.r27.u64;
	// bl 0x8b0c24e8
	ctx.lr = 0x8B0C3270;
	sub_8B0C24E8(ctx, base);
	// stfs f1,12(r29)
	ctx.fpscr.disableFlushMode();
	temp.f32 = float(ctx.f1.f64);
	REX_STORE_U32(ctx.r29.u32 + 12, temp.u32);
	// b 0x8b0c32e8
	goto loc_8B0C32E8;
loc_8B0C3278:
	// mr r3,r27
	ctx.r3.u64 = ctx.r27.u64;
	// bl 0x8b0c2610
	ctx.lr = 0x8B0C3280;
	sub_8B0C2610(ctx, base);
	// stb r3,12(r29)
	REX_STORE_U8(ctx.r29.u32 + 12, ctx.r3.u8);
	// mr r3,r27
	ctx.r3.u64 = ctx.r27.u64;
	// bl 0x8b0c2610
	ctx.lr = 0x8B0C328C;
	sub_8B0C2610(ctx, base);
	// stb r3,13(r29)
	REX_STORE_U8(ctx.r29.u32 + 13, ctx.r3.u8);
	// mr r3,r27
	ctx.r3.u64 = ctx.r27.u64;
	// bl 0x8b0c2610
	ctx.lr = 0x8B0C3298;
	sub_8B0C2610(ctx, base);
	// stb r3,14(r29)
	REX_STORE_U8(ctx.r29.u32 + 14, ctx.r3.u8);
	// mr r3,r27
	ctx.r3.u64 = ctx.r27.u64;
	// bl 0x8b0c2610
	ctx.lr = 0x8B0C32A4;
	sub_8B0C2610(ctx, base);
	// stb r3,15(r29)
	REX_STORE_U8(ctx.r29.u32 + 15, ctx.r3.u8);
	// b 0x8b0c32e8
	goto loc_8B0C32E8;
loc_8B0C32AC:
	// mr r3,r27
	ctx.r3.u64 = ctx.r27.u64;
	// bl 0x8b0c2748
	ctx.lr = 0x8B0C32B4;
	sub_8B0C2748(ctx, base);
	// stw r3,12(r29)
	REX_STORE_U32(ctx.r29.u32 + 12, ctx.r3.u32);
	// b 0x8b0c32e8
	goto loc_8B0C32E8;
loc_8B0C32BC:
	// stb r23,16(r29)
	REX_STORE_U8(ctx.r29.u32 + 16, ctx.r23.u8);
	// stw r25,12(r29)
	REX_STORE_U32(ctx.r29.u32 + 12, ctx.r25.u32);
	// b 0x8b0c32e8
	goto loc_8B0C32E8;
loc_8B0C32C8:
	// stb r23,16(r29)
	REX_STORE_U8(ctx.r29.u32 + 16, ctx.r23.u8);
	// stw r20,12(r29)
	REX_STORE_U32(ctx.r29.u32 + 12, ctx.r20.u32);
	// b 0x8b0c32e8
	goto loc_8B0C32E8;
loc_8B0C32D4:
	// stb r23,16(r29)
	REX_STORE_U8(ctx.r29.u32 + 16, ctx.r23.u8);
	// mr r3,r27
	ctx.r3.u64 = ctx.r27.u64;
	// bl 0x8b0c25a8
	ctx.lr = 0x8B0C32E0;
	sub_8B0C25A8(ctx, base);
	// extsb r11,r3
	ctx.r11.s64 = ctx.r3.s8;
	// stw r11,12(r29)
	REX_STORE_U32(ctx.r29.u32 + 12, ctx.r11.u32);
loc_8B0C32E8:
	// lbz r11,20(r27)
	ctx.r11.u64 = REX_LOAD_U8(ctx.r27.u32 + 20);
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// bne cr6,0x8b0c3004
	if (!ctx.cr6.eq) goto loc_8B0C3004;
	// lwz r11,28(r27)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r27.u32 + 28);
	// lwz r10,12(r27)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r27.u32 + 12);
	// subf. r9,r10,r11
	ctx.r9.u64 = ctx.r11.u64 - ctx.r10.u64;
	ctx.cr0.compare<int32_t>(ctx.r9.s32, 0, ctx.xer);
	// beq 0x8b0c335c
	if (ctx.cr0.eq) goto loc_8B0C335C;
	// mr r3,r27
	ctx.r3.u64 = ctx.r27.u64;
	// bl 0x8b0c2610
	ctx.lr = 0x8B0C330C;
	sub_8B0C2610(ctx, base);
	// clrlwi r31,r3,24
	ctx.r31.u64 = ctx.r3.u32 & 0xFF;
	// cmpwi cr6,r31,11
	ctx.cr6.compare<int32_t>(ctx.r31.s32, 11, ctx.xer);
	// beq cr6,0x8b0c335c
	if (ctx.cr6.eq) goto loc_8B0C335C;
	// bl 0x8b0df568
	ctx.lr = 0x8B0C331C;
	sub_8B0DF568(ctx, base);
	// lwz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// li r4,36
	ctx.r4.s64 = 36;
	// lwz r10,4(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 4);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B0C3330;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0c334c
	if (ctx.cr6.eq) goto loc_8B0C334C;
	// mr r4,r22
	ctx.r4.u64 = ctx.r22.u64;
	// bl 0x8b0bf9f8
	ctx.lr = 0x8B0C3340;
	sub_8B0BF9F8(ctx, base);
	// stw r3,20(r29)
	REX_STORE_U32(ctx.r29.u32 + 20, ctx.r3.u32);
	// mr r29,r3
	ctx.r29.u64 = ctx.r3.u64;
	// b 0x8b0c3050
	goto loc_8B0C3050;
loc_8B0C334C:
	// stw r25,20(r29)
	REX_STORE_U32(ctx.r29.u32 + 20, ctx.r25.u32);
	// mr r3,r25
	ctx.r3.u64 = ctx.r25.u64;
	// mr r29,r25
	ctx.r29.u64 = ctx.r25.u64;
	// b 0x8b0c3050
	goto loc_8B0C3050;
loc_8B0C335C:
	// lbz r11,20(r27)
	ctx.r11.u64 = REX_LOAD_U8(ctx.r27.u32 + 20);
	// cntlzw r10,r11
	ctx.r10.u64 = ctx.r11.u32 == 0 ? 32 : __builtin_clz(ctx.r11.u32);
	// rlwinm r3,r10,27,31,31
	ctx.r3.u64 = __builtin_rotateleft64(ctx.r10.u32 | (ctx.r10.u64 << 32), 27) & 0x1;
	// addi r1,r1,1216
	ctx.r1.s64 = ctx.r1.s64 + 1216;
	// b 0x8b0cb9e4
	__restgprlr_19(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0C3E18) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9b8
	ctx.lr = 0x8B0C3E20;
	__savegprlr_28(ctx, base);
	// stwu r1,-128(r1)
	ea = -128 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// mr r31,r4
	ctx.r31.u64 = ctx.r4.u64;
	// lis r4,255
	ctx.r4.s64 = 16711680;
	// mr r30,r3
	ctx.r30.u64 = ctx.r3.u64;
	// ori r4,r4,65535
	ctx.r4.u64 = ctx.r4.u64 | 65535;
	// mr r28,r5
	ctx.r28.u64 = ctx.r5.u64;
	// mr r29,r6
	ctx.r29.u64 = ctx.r6.u64;
	// bl 0x8b0df518
	ctx.lr = 0x8B0C3E40;
	sub_8B0DF518(ctx, base);
	// lis r4,255
	ctx.r4.s64 = 16711680;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// ori r4,r4,65535
	ctx.r4.u64 = ctx.r4.u64 | 65535;
	// bl 0x8b0df518
	ctx.lr = 0x8B0C3E50;
	sub_8B0DF518(ctx, base);
	// mr r11,r30
	ctx.r11.u64 = ctx.r30.u64;
loc_8B0C3E54:
	// lbz r10,0(r11)
	ctx.r10.u64 = REX_LOAD_U8(ctx.r11.u32 + 0);
	// addi r11,r11,1
	ctx.r11.s64 = ctx.r11.s64 + 1;
	// cmplwi cr6,r10,0
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 0, ctx.xer);
	// bne cr6,0x8b0c3e54
	if (!ctx.cr6.eq) goto loc_8B0C3E54;
	// subf r10,r30,r11
	ctx.r10.u64 = ctx.r11.u64 - ctx.r30.u64;
	// mr r11,r31
	ctx.r11.u64 = ctx.r31.u64;
	// addi r10,r10,-1
	ctx.r10.s64 = ctx.r10.s64 + -1;
	// rotlwi r10,r10,0
	ctx.r10.u64 = __builtin_rotateleft32(ctx.r10.u32, 0);
loc_8B0C3E74:
	// lbz r9,0(r11)
	ctx.r9.u64 = REX_LOAD_U8(ctx.r11.u32 + 0);
	// addi r11,r11,1
	ctx.r11.s64 = ctx.r11.s64 + 1;
	// cmplwi cr6,r9,0
	ctx.cr6.compare<uint32_t>(ctx.r9.u32, 0, ctx.xer);
	// bne cr6,0x8b0c3e74
	if (!ctx.cr6.eq) goto loc_8B0C3E74;
	// subf r11,r31,r11
	ctx.r11.u64 = ctx.r11.u64 - ctx.r31.u64;
	// cmpwi cr6,r29,-1
	ctx.cr6.compare<int32_t>(ctx.r29.s32, -1, ctx.xer);
	// addi r11,r11,-1
	ctx.r11.s64 = ctx.r11.s64 + -1;
	// rotlwi r5,r11,0
	ctx.r5.u64 = __builtin_rotateleft32(ctx.r11.u32, 0);
	// ble cr6,0x8b0c3ea4
	if (!ctx.cr6.gt) goto loc_8B0C3EA4;
	// cmpw cr6,r29,r5
	ctx.cr6.compare<int32_t>(ctx.r29.s32, ctx.r5.s32, ctx.xer);
	// bge cr6,0x8b0c3ea4
	if (!ctx.cr6.lt) goto loc_8B0C3EA4;
	// mr r5,r29
	ctx.r5.u64 = ctx.r29.u64;
loc_8B0C3EA4:
	// add r11,r10,r5
	ctx.r11.u64 = ctx.r10.u64 + ctx.r5.u64;
	// cmplw cr6,r11,r28
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, ctx.r28.u32, ctx.xer);
	// blt cr6,0x8b0c3eb8
	if (ctx.cr6.lt) goto loc_8B0C3EB8;
	// subf r11,r10,r28
	ctx.r11.u64 = ctx.r28.u64 - ctx.r10.u64;
	// addi r5,r11,-1
	ctx.r5.s64 = ctx.r11.s64 + -1;
loc_8B0C3EB8:
	// cmplwi cr6,r5,0
	ctx.cr6.compare<uint32_t>(ctx.r5.u32, 0, ctx.xer);
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// beq cr6,0x8b0c3ed8
	if (ctx.cr6.eq) goto loc_8B0C3ED8;
	// mr r4,r31
	ctx.r4.u64 = ctx.r31.u64;
	// bl 0x8b0ce808
	ctx.lr = 0x8B0C3ECC;
	sub_8B0CE808(ctx, base);
	// add r10,r3,r28
	ctx.r10.u64 = ctx.r3.u64 + ctx.r28.u64;
	// li r11,0
	ctx.r11.s64 = 0;
	// stb r11,-1(r10)
	REX_STORE_U8(ctx.r10.u32 + -1, ctx.r11.u8);
loc_8B0C3ED8:
	// addi r1,r1,128
	ctx.r1.s64 = ctx.r1.s64 + 128;
	// b 0x8b0cba08
	__restgprlr_28(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0C40C0) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// std r30,-24(r1)
	REX_STORE_U64(ctx.r1.u32 + -24, ctx.r30.u64);
	// std r31,-16(r1)
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.r31.u64);
	// stwu r1,-144(r1)
	ea = -144 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lbz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U8(ctx.r3.u32 + 0);
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// mr r30,r4
	ctx.r30.u64 = ctx.r4.u64;
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// beq cr6,0x8b0c41f4
	if (ctx.cr6.eq) goto loc_8B0C41F4;
	// lis r11,-29943
	ctx.r11.s64 = -1962344448;
	// addi r4,r11,-27652
	ctx.r4.s64 = ctx.r11.s64 + -27652;
	// bl 0x8b0cea10
	ctx.lr = 0x8B0C40F4;
	sub_8B0CEA10(ctx, base);
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// beq cr6,0x8b0c41f4
	if (ctx.cr6.eq) goto loc_8B0C41F4;
	// lis r11,-29943
	ctx.r11.s64 = -1962344448;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// addi r4,r11,-27656
	ctx.r4.s64 = ctx.r11.s64 + -27656;
	// bl 0x8b0cea10
	ctx.lr = 0x8B0C410C;
	sub_8B0CEA10(ctx, base);
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// beq cr6,0x8b0c41f4
	if (ctx.cr6.eq) goto loc_8B0C41F4;
	// mr r11,r31
	ctx.r11.u64 = ctx.r31.u64;
loc_8B0C4118:
	// lbz r10,0(r11)
	ctx.r10.u64 = REX_LOAD_U8(ctx.r11.u32 + 0);
	// addi r11,r11,1
	ctx.r11.s64 = ctx.r11.s64 + 1;
	// cmplwi cr6,r10,0
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 0, ctx.xer);
	// bne cr6,0x8b0c4118
	if (!ctx.cr6.eq) goto loc_8B0C4118;
	// subf r11,r31,r11
	ctx.r11.u64 = ctx.r11.u64 - ctx.r31.u64;
	// addi r11,r11,-1
	ctx.r11.s64 = ctx.r11.s64 + -1;
	// rotlwi r11,r11,0
	ctx.r11.u64 = __builtin_rotateleft32(ctx.r11.u32, 0);
	// add r10,r11,r31
	ctx.r10.u64 = ctx.r11.u64 + ctx.r31.u64;
	// lbz r9,-1(r10)
	ctx.r9.u64 = REX_LOAD_U8(ctx.r10.u32 + -1);
	// extsb r10,r9
	ctx.r10.s64 = ctx.r9.s8;
	// cmpwi cr6,r10,92
	ctx.cr6.compare<int32_t>(ctx.r10.s32, 92, ctx.xer);
	// beq cr6,0x8b0c4150
	if (ctx.cr6.eq) goto loc_8B0C4150;
	// cmpwi cr6,r10,47
	ctx.cr6.compare<int32_t>(ctx.r10.s32, 47, ctx.xer);
	// bne cr6,0x8b0c4154
	if (!ctx.cr6.eq) goto loc_8B0C4154;
loc_8B0C4150:
	// addi r11,r11,-1
	ctx.r11.s64 = ctx.r11.s64 + -1;
loc_8B0C4154:
	// cmpwi cr6,r11,0
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// ble cr6,0x8b0c4184
	if (!ctx.cr6.gt) goto loc_8B0C4184;
	// addi r9,r31,-1
	ctx.r9.s64 = ctx.r31.s64 + -1;
loc_8B0C4160:
	// lbzx r10,r9,r11
	ctx.r10.u64 = REX_LOAD_U8(ctx.r9.u32 + ctx.r11.u32);
	// extsb r10,r10
	ctx.r10.s64 = ctx.r10.s8;
	// cmpwi cr6,r10,92
	ctx.cr6.compare<int32_t>(ctx.r10.s32, 92, ctx.xer);
	// beq cr6,0x8b0c41a8
	if (ctx.cr6.eq) goto loc_8B0C41A8;
	// cmpwi cr6,r10,47
	ctx.cr6.compare<int32_t>(ctx.r10.s32, 47, ctx.xer);
	// beq cr6,0x8b0c41a8
	if (ctx.cr6.eq) goto loc_8B0C41A8;
	// addic. r11,r11,-1
	ctx.xer.ca = ctx.r11.u32 > 0;
	ctx.r11.s64 = ctx.r11.s64 + -1;
	ctx.cr0.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// bgt 0x8b0c4160
	if (ctx.cr0.gt) goto loc_8B0C4160;
	// cmpwi cr6,r11,0
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
loc_8B0C4184:
	// bne cr6,0x8b0c41ec
	if (!ctx.cr6.eq) goto loc_8B0C41EC;
	// lis r11,-29943
	ctx.r11.s64 = -1962344448;
	// li r6,92
	ctx.r6.s64 = 92;
	// addi r5,r11,-27660
	ctx.r5.s64 = ctx.r11.s64 + -27660;
	// mr r4,r30
	ctx.r4.u64 = ctx.r30.u64;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0c3fd8
	ctx.lr = 0x8B0C41A0;
	sub_8B0C3FD8(ctx, base);
	// li r3,1
	ctx.r3.s64 = 1;
	// b 0x8b0c41f8
	goto loc_8B0C41F8;
loc_8B0C41A8:
	// li r9,0
	ctx.r9.s64 = 0;
	// mr r10,r31
	ctx.r10.u64 = ctx.r31.u64;
	// stbx r9,r11,r31
	REX_STORE_U8(ctx.r11.u32 + ctx.r31.u32, ctx.r9.u8);
	// lbz r8,0(r31)
	ctx.r8.u64 = REX_LOAD_U8(ctx.r31.u32 + 0);
	// cmplwi cr6,r8,0
	ctx.cr6.compare<uint32_t>(ctx.r8.u32, 0, ctx.xer);
	// beq cr6,0x8b0c41ec
	if (ctx.cr6.eq) goto loc_8B0C41EC;
	// li r9,92
	ctx.r9.s64 = 92;
loc_8B0C41C4:
	// lbz r11,0(r10)
	ctx.r11.u64 = REX_LOAD_U8(ctx.r10.u32 + 0);
	// extsb r11,r11
	ctx.r11.s64 = ctx.r11.s8;
	// cmpwi cr6,r11,47
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 47, ctx.xer);
	// beq cr6,0x8b0c41dc
	if (ctx.cr6.eq) goto loc_8B0C41DC;
	// cmpwi cr6,r11,92
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 92, ctx.xer);
	// bne cr6,0x8b0c41e0
	if (!ctx.cr6.eq) goto loc_8B0C41E0;
loc_8B0C41DC:
	// stb r9,0(r10)
	REX_STORE_U8(ctx.r10.u32 + 0, ctx.r9.u8);
loc_8B0C41E0:
	// lbzu r11,1(r10)
	ea = 1 + ctx.r10.u32;
	ctx.r11.u64 = REX_LOAD_U8(ea);
	ctx.r10.u32 = ea;
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// bne cr6,0x8b0c41c4
	if (!ctx.cr6.eq) goto loc_8B0C41C4;
loc_8B0C41EC:
	// li r3,1
	ctx.r3.s64 = 1;
	// b 0x8b0c41f8
	goto loc_8B0C41F8;
loc_8B0C41F4:
	// li r3,0
	ctx.r3.s64 = 0;
loc_8B0C41F8:
	// addi r1,r1,144
	ctx.r1.s64 = ctx.r1.s64 + 144;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// ld r30,-24(r1)
	ctx.r30.u64 = REX_LOAD_U64(ctx.r1.u32 + -24);
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0C47B0) {
	REX_FUNC_PROLOGUE();
	// lwz r9,48(r3)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r3.u32 + 48);
	// li r10,0
	ctx.r10.s64 = 0;
	// cmpwi cr6,r9,0
	ctx.cr6.compare<int32_t>(ctx.r9.s32, 0, ctx.xer);
	// ble cr6,0x8b0c47ec
	if (!ctx.cr6.gt) goto loc_8B0C47EC;
	// lwz r11,36(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 36);
loc_8B0C47C4:
	// lwz r8,0(r11)
	ctx.r8.u64 = REX_LOAD_U32(ctx.r11.u32 + 0);
	// lwz r7,0(r8)
	ctx.r7.u64 = REX_LOAD_U32(ctx.r8.u32 + 0);
	// lwz r6,4(r8)
	ctx.r6.u64 = REX_LOAD_U32(ctx.r8.u32 + 4);
	// subf r5,r6,r7
	ctx.r5.u64 = ctx.r7.u64 - ctx.r6.u64;
	// cmpw cr6,r5,r4
	ctx.cr6.compare<int32_t>(ctx.r5.s32, ctx.r4.s32, ctx.xer);
	// bge cr6,0x8b0c47f4
	if (!ctx.cr6.lt) goto loc_8B0C47F4;
	// addi r10,r10,1
	ctx.r10.s64 = ctx.r10.s64 + 1;
	// addi r11,r11,4
	ctx.r11.s64 = ctx.r11.s64 + 4;
	// cmpw cr6,r10,r9
	ctx.cr6.compare<int32_t>(ctx.r10.s32, ctx.r9.s32, ctx.xer);
	// blt cr6,0x8b0c47c4
	if (ctx.cr6.lt) goto loc_8B0C47C4;
loc_8B0C47EC:
	// li r3,-1
	ctx.r3.s64 = -1;
	// blr 
	return;
loc_8B0C47F4:
	// mr r3,r10
	ctx.r3.u64 = ctx.r10.u64;
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0C4950) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9b0
	ctx.lr = 0x8B0C4958;
	__savegprlr_26(ctx, base);
	// stwu r1,-144(r1)
	ea = -144 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// mr r30,r4
	ctx.r30.u64 = ctx.r4.u64;
	// bl 0x8b0c45e8
	ctx.lr = 0x8B0C4968;
	sub_8B0C45E8(ctx, base);
	// lhz r29,2(r3)
	ctx.r29.u64 = REX_LOAD_U16(ctx.r3.u32 + 2);
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// mr r4,r29
	ctx.r4.u64 = ctx.r29.u64;
	// bl 0x8b0c45e8
	ctx.lr = 0x8B0C4978;
	sub_8B0C45E8(ctx, base);
	// rlwinm r11,r30,1,15,30
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r30.u32 | (ctx.r30.u64 << 32), 1) & 0x1FFFE;
	// clrlwi r27,r30,16
	ctx.r27.u64 = ctx.r30.u32 & 0xFFFF;
	// mr r10,r3
	ctx.r10.u64 = ctx.r3.u64;
	// add r9,r27,r11
	ctx.r9.u64 = ctx.r27.u64 + ctx.r11.u64;
	// lwz r11,4(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 4);
	// mr r4,r29
	ctx.r4.u64 = ctx.r29.u64;
	// rlwinm r26,r9,2,0,29
	ctx.r26.u64 = __builtin_rotateleft64(ctx.r9.u32 | (ctx.r9.u64 << 32), 2) & 0xFFFFFFFC;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// lhz r8,0(r10)
	ctx.r8.u64 = REX_LOAD_U16(ctx.r10.u32 + 0);
	// add r7,r11,r26
	ctx.r7.u64 = ctx.r11.u64 + ctx.r26.u64;
	// sth r8,2(r7)
	REX_STORE_U16(ctx.r7.u32 + 2, ctx.r8.u16);
	// bl 0x8b0c45e8
	ctx.lr = 0x8B0C49A8;
	sub_8B0C45E8(ctx, base);
	// lhz r6,0(r3)
	ctx.r6.u64 = REX_LOAD_U16(ctx.r3.u32 + 0);
	// cmplwi cr6,r6,65535
	ctx.cr6.compare<uint32_t>(ctx.r6.u32, 65535, ctx.xer);
	// beq cr6,0x8b0c49dc
	if (ctx.cr6.eq) goto loc_8B0C49DC;
	// mr r4,r29
	ctx.r4.u64 = ctx.r29.u64;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0c45e8
	ctx.lr = 0x8B0C49C0;
	sub_8B0C45E8(ctx, base);
	// lhz r10,0(r3)
	ctx.r10.u64 = REX_LOAD_U16(ctx.r3.u32 + 0);
	// lwz r9,4(r31)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r31.u32 + 4);
	// rotlwi r11,r10,1
	ctx.r11.u64 = __builtin_rotateleft32(ctx.r10.u32, 1);
	// add r8,r10,r11
	ctx.r8.u64 = ctx.r10.u64 + ctx.r11.u64;
	// rlwinm r11,r8,2,0,29
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r8.u32 | (ctx.r8.u64 << 32), 2) & 0xFFFFFFFC;
	// add r7,r11,r9
	ctx.r7.u64 = ctx.r11.u64 + ctx.r9.u64;
	// sth r30,4(r7)
	REX_STORE_U16(ctx.r7.u32 + 4, ctx.r30.u16);
loc_8B0C49DC:
	// clrlwi r28,r29,16
	ctx.r28.u64 = ctx.r29.u32 & 0xFFFF;
	// cmplwi cr6,r28,65535
	ctx.cr6.compare<uint32_t>(ctx.r28.u32, 65535, ctx.xer);
	// beq cr6,0x8b0c4a10
	if (ctx.cr6.eq) goto loc_8B0C4A10;
	// mr r4,r30
	ctx.r4.u64 = ctx.r30.u64;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0c45e8
	ctx.lr = 0x8B0C49F4;
	sub_8B0C45E8(ctx, base);
	// rlwinm r11,r28,1,0,30
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r28.u32 | (ctx.r28.u64 << 32), 1) & 0xFFFFFFFE;
	// lwz r10,4(r31)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r31.u32 + 4);
	// add r11,r28,r11
	ctx.r11.u64 = ctx.r28.u64 + ctx.r11.u64;
	// lhz r9,4(r3)
	ctx.r9.u64 = REX_LOAD_U16(ctx.r3.u32 + 4);
	// rlwinm r11,r11,2,0,29
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 2) & 0xFFFFFFFC;
	// add r8,r11,r10
	ctx.r8.u64 = ctx.r11.u64 + ctx.r10.u64;
	// sth r9,4(r8)
	REX_STORE_U16(ctx.r8.u32 + 4, ctx.r9.u16);
loc_8B0C4A10:
	// lhz r11,16(r31)
	ctx.r11.u64 = REX_LOAD_U16(ctx.r31.u32 + 16);
	// cmplw cr6,r27,r11
	ctx.cr6.compare<uint32_t>(ctx.r27.u32, ctx.r11.u32, ctx.xer);
	// beq cr6,0x8b0c4a90
	if (ctx.cr6.eq) goto loc_8B0C4A90;
	// mr r4,r30
	ctx.r4.u64 = ctx.r30.u64;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0c45e8
	ctx.lr = 0x8B0C4A28;
	sub_8B0C45E8(ctx, base);
	// lhz r4,4(r3)
	ctx.r4.u64 = REX_LOAD_U16(ctx.r3.u32 + 4);
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0c45e8
	ctx.lr = 0x8B0C4A34;
	sub_8B0C45E8(ctx, base);
	// lhz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U16(ctx.r3.u32 + 0);
	// mr r4,r30
	ctx.r4.u64 = ctx.r30.u64;
	// cmplw cr6,r11,r27
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, ctx.r27.u32, ctx.xer);
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bne cr6,0x8b0c4a6c
	if (!ctx.cr6.eq) goto loc_8B0C4A6C;
	// bl 0x8b0c45e8
	ctx.lr = 0x8B0C4A4C;
	sub_8B0C45E8(ctx, base);
	// lhz r11,4(r3)
	ctx.r11.u64 = REX_LOAD_U16(ctx.r3.u32 + 4);
	// lwz r9,4(r31)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r31.u32 + 4);
	// mr r10,r11
	ctx.r10.u64 = ctx.r11.u64;
	// rotlwi r11,r11,1
	ctx.r11.u64 = __builtin_rotateleft32(ctx.r11.u32, 1);
	// add r8,r10,r11
	ctx.r8.u64 = ctx.r10.u64 + ctx.r11.u64;
	// rlwinm r7,r8,2,0,29
	ctx.r7.u64 = __builtin_rotateleft64(ctx.r8.u32 | (ctx.r8.u64 << 32), 2) & 0xFFFFFFFC;
	// sthx r29,r7,r9
	REX_STORE_U16(ctx.r7.u32 + ctx.r9.u32, ctx.r29.u16);
	// b 0x8b0c4a94
	goto loc_8B0C4A94;
loc_8B0C4A6C:
	// bl 0x8b0c45e8
	ctx.lr = 0x8B0C4A70;
	sub_8B0C45E8(ctx, base);
	// lhz r9,4(r3)
	ctx.r9.u64 = REX_LOAD_U16(ctx.r3.u32 + 4);
	// lwz r10,4(r31)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r31.u32 + 4);
	// rotlwi r11,r9,1
	ctx.r11.u64 = __builtin_rotateleft32(ctx.r9.u32, 1);
	// add r8,r9,r11
	ctx.r8.u64 = ctx.r9.u64 + ctx.r11.u64;
	// rlwinm r11,r8,2,0,29
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r8.u32 | (ctx.r8.u64 << 32), 2) & 0xFFFFFFFC;
	// add r7,r11,r10
	ctx.r7.u64 = ctx.r11.u64 + ctx.r10.u64;
	// sth r29,2(r7)
	REX_STORE_U16(ctx.r7.u32 + 2, ctx.r29.u16);
	// b 0x8b0c4a94
	goto loc_8B0C4A94;
loc_8B0C4A90:
	// sth r29,16(r31)
	REX_STORE_U16(ctx.r31.u32 + 16, ctx.r29.u16);
loc_8B0C4A94:
	// rlwinm r11,r28,1,0,30
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r28.u32 | (ctx.r28.u64 << 32), 1) & 0xFFFFFFFE;
	// lwz r10,4(r31)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r31.u32 + 4);
	// cmplwi cr6,r27,65535
	ctx.cr6.compare<uint32_t>(ctx.r27.u32, 65535, ctx.xer);
	// add r9,r28,r11
	ctx.r9.u64 = ctx.r28.u64 + ctx.r11.u64;
	// rlwinm r8,r9,2,0,29
	ctx.r8.u64 = __builtin_rotateleft64(ctx.r9.u32 | (ctx.r9.u64 << 32), 2) & 0xFFFFFFFC;
	// sthx r30,r8,r10
	REX_STORE_U16(ctx.r8.u32 + ctx.r10.u32, ctx.r30.u16);
	// beq cr6,0x8b0c4abc
	if (ctx.cr6.eq) goto loc_8B0C4ABC;
	// lwz r11,4(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 4);
	// add r11,r11,r26
	ctx.r11.u64 = ctx.r11.u64 + ctx.r26.u64;
	// sth r29,4(r11)
	REX_STORE_U16(ctx.r11.u32 + 4, ctx.r29.u16);
loc_8B0C4ABC:
	// addi r1,r1,144
	ctx.r1.s64 = ctx.r1.s64 + 144;
	// b 0x8b0cba00
	__restgprlr_26(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0C5770) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// std r30,-24(r1)
	REX_STORE_U64(ctx.r1.u32 + -24, ctx.r30.u64);
	// std r31,-16(r1)
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.r31.u64);
	// stwu r1,-112(r1)
	ea = -112 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// mr r30,r3
	ctx.r30.u64 = ctx.r3.u64;
	// mr r31,r4
	ctx.r31.u64 = ctx.r4.u64;
	// mr r3,r5
	ctx.r3.u64 = ctx.r5.u64;
	// cmplwi cr6,r5,0
	ctx.cr6.compare<uint32_t>(ctx.r5.u32, 0, ctx.xer);
	// bne cr6,0x8b0c57a4
	if (!ctx.cr6.eq) goto loc_8B0C57A4;
	// li r11,-1
	ctx.r11.s64 = -1;
	// sth r11,0(r30)
	REX_STORE_U16(ctx.r30.u32 + 0, ctx.r11.u16);
	// b 0x8b0c57e4
	goto loc_8B0C57E4;
loc_8B0C57A4:
	// lbz r11,28(r31)
	ctx.r11.u64 = REX_LOAD_U8(ctx.r31.u32 + 28);
	// stw r3,32(r31)
	REX_STORE_U32(ctx.r31.u32 + 32, ctx.r3.u32);
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// beq cr6,0x8b0c57bc
	if (ctx.cr6.eq) goto loc_8B0C57BC;
	// bl 0x8b0cafe8
	ctx.lr = 0x8B0C57B8;
	sub_8B0CAFE8(ctx, base);
	// b 0x8b0c57c0
	goto loc_8B0C57C0;
loc_8B0C57BC:
	// bl 0x8b0caf80
	ctx.lr = 0x8B0C57C0;
	sub_8B0CAF80(ctx, base);
loc_8B0C57C0:
	// lis r11,0
	ctx.r11.s64 = 0;
	// sth r3,30(r31)
	REX_STORE_U16(ctx.r31.u32 + 30, ctx.r3.u16);
	// addi r4,r1,80
	ctx.r4.s64 = ctx.r1.s64 + 80;
	// ori r11,r11,65535
	ctx.r11.u64 = ctx.r11.u64 | 65535;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// sth r11,80(r1)
	REX_STORE_U16(ctx.r1.u32 + 80, ctx.r11.u16);
	// sth r11,82(r1)
	REX_STORE_U16(ctx.r1.u32 + 82, ctx.r11.u16);
	// bl 0x8b0c4c40
	ctx.lr = 0x8B0C57E0;
	sub_8B0C4C40(ctx, base);
	// sth r3,0(r30)
	REX_STORE_U16(ctx.r30.u32 + 0, ctx.r3.u16);
loc_8B0C57E4:
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// addi r1,r1,112
	ctx.r1.s64 = ctx.r1.s64 + 112;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// ld r30,-24(r1)
	ctx.r30.u64 = REX_LOAD_U64(ctx.r1.u32 + -24);
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0C5800) {
	REX_FUNC_PROLOGUE();
	// lis r11,0
	ctx.r11.s64 = 0;
	// rlwinm r10,r4,1,15,30
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r4.u32 | (ctx.r4.u64 << 32), 1) & 0x1FFFE;
	// clrlwi r9,r4,16
	ctx.r9.u64 = ctx.r4.u32 & 0xFFFF;
	// ori r11,r11,65535
	ctx.r11.u64 = ctx.r11.u64 | 65535;
	// add r9,r9,r10
	ctx.r9.u64 = ctx.r9.u64 + ctx.r10.u64;
	// lwz r10,4(r3)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r3.u32 + 4);
	// mr r7,r11
	ctx.r7.u64 = ctx.r11.u64;
	// mr r8,r11
	ctx.r8.u64 = ctx.r11.u64;
	// rlwinm r11,r9,2,0,29
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r9.u32 | (ctx.r9.u64 << 32), 2) & 0xFFFFFFFC;
	// li r9,0
	ctx.r9.s64 = 0;
	// add r11,r11,r10
	ctx.r11.u64 = ctx.r11.u64 + ctx.r10.u64;
	// clrlwi r10,r5,16
	ctx.r10.u64 = ctx.r5.u32 & 0xFFFF;
	// cmplwi cr6,r10,65535
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 65535, ctx.xer);
	// sth r5,4(r11)
	REX_STORE_U16(ctx.r11.u32 + 4, ctx.r5.u16);
	// sth r7,2(r11)
	REX_STORE_U16(ctx.r11.u32 + 2, ctx.r7.u16);
	// sth r7,0(r11)
	REX_STORE_U16(ctx.r11.u32 + 0, ctx.r7.u16);
	// sth r9,6(r11)
	REX_STORE_U16(ctx.r11.u32 + 6, ctx.r9.u16);
	// beq cr6,0x8b0c5880
	if (ctx.cr6.eq) goto loc_8B0C5880;
	// clrlwi r11,r6,24
	ctx.r11.u64 = ctx.r6.u32 & 0xFF;
	// lwz r9,4(r3)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r3.u32 + 4);
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// rlwinm r11,r10,1,0,30
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r10.u32 | (ctx.r10.u64 << 32), 1) & 0xFFFFFFFE;
	// beq cr6,0x8b0c586c
	if (ctx.cr6.eq) goto loc_8B0C586C;
	// add r8,r10,r11
	ctx.r8.u64 = ctx.r10.u64 + ctx.r11.u64;
	// rlwinm r7,r8,2,0,29
	ctx.r7.u64 = __builtin_rotateleft64(ctx.r8.u32 | (ctx.r8.u64 << 32), 2) & 0xFFFFFFFC;
	// sthx r4,r7,r9
	REX_STORE_U16(ctx.r7.u32 + ctx.r9.u32, ctx.r4.u16);
	// b 0x8b0c5884
	goto loc_8B0C5884;
loc_8B0C586C:
	// add r11,r10,r11
	ctx.r11.u64 = ctx.r10.u64 + ctx.r11.u64;
	// rlwinm r11,r11,2,0,29
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 2) & 0xFFFFFFFC;
	// add r10,r11,r9
	ctx.r10.u64 = ctx.r11.u64 + ctx.r9.u64;
	// sth r4,2(r10)
	REX_STORE_U16(ctx.r10.u32 + 2, ctx.r4.u16);
	// b 0x8b0c5884
	goto loc_8B0C5884;
loc_8B0C5880:
	// sth r4,16(r3)
	REX_STORE_U16(ctx.r3.u32 + 16, ctx.r4.u16);
loc_8B0C5884:
	// b 0x8b0c4ee0
	sub_8B0C4EE0(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0C5A08) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// std r30,-24(r1)
	REX_STORE_U64(ctx.r1.u32 + -24, ctx.r30.u64);
	// std r31,-16(r1)
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.r31.u64);
	// stwu r1,-112(r1)
	ea = -112 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// addi r3,r3,4
	ctx.r3.s64 = ctx.r3.s64 + 4;
	// mr r30,r6
	ctx.r30.u64 = ctx.r6.u64;
	// bl 0x8b0c4308
	ctx.lr = 0x8B0C5A2C;
	sub_8B0C4308(ctx, base);
	// lis r11,0
	ctx.r11.s64 = 0;
	// li r10,0
	ctx.r10.s64 = 0;
	// ori r11,r11,65535
	ctx.r11.u64 = ctx.r11.u64 | 65535;
	// sth r10,18(r31)
	REX_STORE_U16(ctx.r31.u32 + 18, ctx.r10.u16);
	// li r9,8
	ctx.r9.s64 = 8;
	// sth r11,16(r31)
	REX_STORE_U16(ctx.r31.u32 + 16, ctx.r11.u16);
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// sth r11,20(r31)
	REX_STORE_U16(ctx.r31.u32 + 20, ctx.r11.u16);
	// sth r11,22(r31)
	REX_STORE_U16(ctx.r31.u32 + 22, ctx.r11.u16);
	// lwz r8,4(r31)
	ctx.r8.u64 = REX_LOAD_U32(ctx.r31.u32 + 4);
	// stb r30,28(r31)
	REX_STORE_U8(ctx.r31.u32 + 28, ctx.r30.u8);
	// stw r8,24(r31)
	REX_STORE_U32(ctx.r31.u32 + 24, ctx.r8.u32);
	// stw r10,36(r31)
	REX_STORE_U32(ctx.r31.u32 + 36, ctx.r10.u32);
	// stw r10,40(r31)
	REX_STORE_U32(ctx.r31.u32 + 40, ctx.r10.u32);
	// stw r9,44(r31)
	REX_STORE_U32(ctx.r31.u32 + 44, ctx.r9.u32);
	// stw r10,48(r31)
	REX_STORE_U32(ctx.r31.u32 + 48, ctx.r10.u32);
	// addi r1,r1,112
	ctx.r1.s64 = ctx.r1.s64 + 112;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// ld r30,-24(r1)
	ctx.r30.u64 = REX_LOAD_U64(ctx.r1.u32 + -24);
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0C5CA0) {
	REX_FUNC_PROLOGUE();
	// lis r11,-29936
	ctx.r11.s64 = -1961885696;
	// lwz r8,-27812(r11)
	ctx.r8.u64 = REX_LOAD_U32(ctx.r11.u32 + -27812);
	// cmplwi cr6,r8,0
	ctx.cr6.compare<uint32_t>(ctx.r8.u32, 0, ctx.xer);
	// beq cr6,0x8b0c5cf0
	if (ctx.cr6.eq) goto loc_8B0C5CF0;
loc_8B0C5CB0:
	// lwz r11,4(r8)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r8.u32 + 4);
	// mr r10,r3
	ctx.r10.u64 = ctx.r3.u64;
loc_8B0C5CB8:
	// lbz r9,0(r11)
	ctx.r9.u64 = REX_LOAD_U8(ctx.r11.u32 + 0);
	// lbz r7,0(r10)
	ctx.r7.u64 = REX_LOAD_U8(ctx.r10.u32 + 0);
	// cmpwi cr6,r9,0
	ctx.cr6.compare<int32_t>(ctx.r9.s32, 0, ctx.xer);
	// subf r9,r7,r9
	ctx.r9.u64 = ctx.r9.u64 - ctx.r7.u64;
	// beq cr6,0x8b0c5cdc
	if (ctx.cr6.eq) goto loc_8B0C5CDC;
	// addi r11,r11,1
	ctx.r11.s64 = ctx.r11.s64 + 1;
	// addi r10,r10,1
	ctx.r10.s64 = ctx.r10.s64 + 1;
	// cmpwi cr6,r9,0
	ctx.cr6.compare<int32_t>(ctx.r9.s32, 0, ctx.xer);
	// beq cr6,0x8b0c5cb8
	if (ctx.cr6.eq) goto loc_8B0C5CB8;
loc_8B0C5CDC:
	// cmpwi cr6,r9,0
	ctx.cr6.compare<int32_t>(ctx.r9.s32, 0, ctx.xer);
	// beq cr6,0x8b0c5d08
	if (ctx.cr6.eq) goto loc_8B0C5D08;
	// lwz r8,8(r8)
	ctx.r8.u64 = REX_LOAD_U32(ctx.r8.u32 + 8);
	// cmplwi cr6,r8,0
	ctx.cr6.compare<uint32_t>(ctx.r8.u32, 0, ctx.xer);
	// bne cr6,0x8b0c5cb0
	if (!ctx.cr6.eq) goto loc_8B0C5CB0;
loc_8B0C5CF0:
	// cmplwi cr6,r4,0
	ctx.cr6.compare<uint32_t>(ctx.r4.u32, 0, ctx.xer);
	// beq cr6,0x8b0c5d00
	if (ctx.cr6.eq) goto loc_8B0C5D00;
	// li r11,1
	ctx.r11.s64 = 1;
	// stw r11,0(r4)
	REX_STORE_U32(ctx.r4.u32 + 0, ctx.r11.u32);
loc_8B0C5D00:
	// li r3,0
	ctx.r3.s64 = 0;
	// blr 
	return;
loc_8B0C5D08:
	// cmplwi cr6,r4,0
	ctx.cr6.compare<uint32_t>(ctx.r4.u32, 0, ctx.xer);
	// beq cr6,0x8b0c5d18
	if (ctx.cr6.eq) goto loc_8B0C5D18;
	// li r11,0
	ctx.r11.s64 = 0;
	// stw r11,0(r4)
	REX_STORE_U32(ctx.r4.u32 + 0, ctx.r11.u32);
loc_8B0C5D18:
	// lwz r11,0(r8)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r8.u32 + 0);
	// mtctr r11
	ctx.ctr.u64 = ctx.r11.u64;
	// bctr 
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	return;
}

DEFINE_REX_FUNC(sub_8B0C5EB8) {
	REX_FUNC_PROLOGUE();
	// lis r11,-29938
	ctx.r11.s64 = -1962016768;
	// lwz r3,9044(r11)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r11.u32 + 9044);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0C5EC8) {
	REX_FUNC_PROLOGUE();
	// li r11,0
	ctx.r11.s64 = 0;
	// stw r4,12(r3)
	REX_STORE_U32(ctx.r3.u32 + 12, ctx.r4.u32);
	// cmplwi cr6,r5,0
	ctx.cr6.compare<uint32_t>(ctx.r5.u32, 0, ctx.xer);
	// stb r11,8(r3)
	REX_STORE_U8(ctx.r3.u32 + 8, ctx.r11.u8);
	// bne cr6,0x8b0c5ee4
	if (!ctx.cr6.eq) goto loc_8B0C5EE4;
	// lis r10,-29938
	ctx.r10.s64 = -1962016768;
	// lwz r5,9204(r10)
	ctx.r5.u64 = REX_LOAD_U32(ctx.r10.u32 + 9204);
loc_8B0C5EE4:
	// clrlwi r10,r6,31
	ctx.r10.u64 = ctx.r6.u32 & 0x1;
	// stw r5,16(r3)
	REX_STORE_U32(ctx.r3.u32 + 16, ctx.r5.u32);
	// stw r6,20(r3)
	REX_STORE_U32(ctx.r3.u32 + 20, ctx.r6.u32);
	// cmpwi cr6,r10,0
	ctx.cr6.compare<int32_t>(ctx.r10.s32, 0, ctx.xer);
	// bne cr6,0x8b0c5f0c
	if (!ctx.cr6.eq) goto loc_8B0C5F0C;
	// lis r10,-29936
	ctx.r10.s64 = -1961885696;
	// lwz r11,-27544(r10)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r10.u32 + -27544);
	// stw r11,4(r3)
	REX_STORE_U32(ctx.r3.u32 + 4, ctx.r11.u32);
	// stw r3,-27544(r10)
	REX_STORE_U32(ctx.r10.u32 + -27544, ctx.r3.u32);
	// b 0x8b0c5f10
	goto loc_8B0C5F10;
loc_8B0C5F0C:
	// stw r11,4(r3)
	REX_STORE_U32(ctx.r3.u32 + 4, ctx.r11.u32);
loc_8B0C5F10:
	// lis r11,-29936
	ctx.r11.s64 = -1961885696;
	// lwz r11,-27540(r11)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r11.u32 + -27540);
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// beqlr cr6
	if (ctx.cr6.eq) return;
	// lwz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r10,44(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 44);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctr 
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	return;
}

DEFINE_REX_FUNC(sub_8B0C5F88) {
	REX_FUNC_PROLOGUE();
	// lwz r11,20(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 20);
	// or r10,r4,r11
	ctx.r10.u64 = ctx.r4.u64 | ctx.r11.u64;
	// stw r10,20(r3)
	REX_STORE_U32(ctx.r3.u32 + 20, ctx.r10.u32);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0C5F98) {
	REX_FUNC_PROLOGUE();
	// lwz r11,20(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 20);
	// andc r10,r11,r4
	ctx.r10.u64 = ctx.r11.u64 & ~ctx.r4.u64;
	// stw r10,20(r3)
	REX_STORE_U32(ctx.r3.u32 + 20, ctx.r10.u32);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0C6138) {
	REX_FUNC_PROLOGUE();
	// lbz r11,32(r3)
	ctx.r11.u64 = REX_LOAD_U8(ctx.r3.u32 + 32);
	// rlwinm r3,r11,25,7,31
	ctx.r3.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 25) & 0x1FFFFFF;
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0C61B0) {
	REX_FUNC_PROLOGUE();
	PPCRegister temp{};
	// lwz r11,28(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 28);
	// lwz r10,20(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 20);
	// and r9,r10,r4
	ctx.r9.u64 = ctx.r10.u64 & ctx.r4.u64;
	// addic r8,r9,-1
	ctx.xer.ca = ctx.r9.u32 > 0;
	ctx.r8.s64 = ctx.r9.s64 + -1;
	// subfe r3,r8,r9
	temp.u8 = (~ctx.r8.u32 + ctx.r9.u32 < ~ctx.r8.u32) | (~ctx.r8.u32 + ctx.r9.u32 + ctx.xer.ca < ctx.xer.ca);
	ctx.r3.u64 = ~ctx.r8.u64 + ctx.r9.u64 + ctx.xer.ca;
	ctx.xer.ca = temp.u8;
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0C61C8) {
	REX_FUNC_PROLOGUE();
	// lwz r11,28(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 28);
	// lwz r3,20(r11)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r11.u32 + 20);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0C61D8) {
	REX_FUNC_PROLOGUE();
	// lwz r11,28(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 28);
	// lwz r3,16(r11)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r11.u32 + 16);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0C61E8) {
	REX_FUNC_PROLOGUE();
	// lwz r11,28(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 28);
	// lwz r10,20(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 20);
	// or r9,r10,r4
	ctx.r9.u64 = ctx.r10.u64 | ctx.r4.u64;
	// stw r9,20(r11)
	REX_STORE_U32(ctx.r11.u32 + 20, ctx.r9.u32);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0C6200) {
	REX_FUNC_PROLOGUE();
	// lwz r11,28(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 28);
	// lbz r3,8(r11)
	ctx.r3.u64 = REX_LOAD_U8(ctx.r11.u32 + 8);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0C6230) {
	REX_FUNC_PROLOGUE();
	PPCRegister temp{};
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9bc
	ctx.lr = 0x8B0C6238;
	__savegprlr_29(ctx, base);
	// stfd f30,-48(r1)
	ctx.fpscr.disableFlushMode();
	REX_STORE_U64(ctx.r1.u32 + -48, ctx.f30.u64);
	// stfd f31,-40(r1)
	REX_STORE_U64(ctx.r1.u32 + -40, ctx.f31.u64);
	// stwu r1,-176(r1)
	ea = -176 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lwz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// mr r30,r4
	ctx.r30.u64 = ctx.r4.u64;
	// lis r4,176
	ctx.r4.s64 = 11534336;
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// lwz r10,8(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 8);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B0C6260;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// clrlwi r9,r3,24
	ctx.r9.u64 = ctx.r3.u32 & 0xFF;
	// cmplwi cr6,r9,0
	ctx.cr6.compare<uint32_t>(ctx.r9.u32, 0, ctx.xer);
	// beq cr6,0x8b0c62c4
	if (ctx.cr6.eq) goto loc_8B0C62C4;
	// lis r29,-29936
	ctx.r29.s64 = -1961885696;
	// lwz r3,-27244(r29)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r29.u32 + -27244);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0c62c4
	if (ctx.cr6.eq) goto loc_8B0C62C4;
	// lwz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r10,132(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 132);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B0C628C;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// clrlwi r9,r3,24
	ctx.r9.u64 = ctx.r3.u32 & 0xFF;
	// cmplwi cr6,r9,0
	ctx.cr6.compare<uint32_t>(ctx.r9.u32, 0, ctx.xer);
	// bne cr6,0x8b0c62c4
	if (!ctx.cr6.eq) goto loc_8B0C62C4;
	// lwz r3,-27244(r29)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r29.u32 + -27244);
	// mr r5,r30
	ctx.r5.u64 = ctx.r30.u64;
	// mr r4,r31
	ctx.r4.u64 = ctx.r31.u64;
	// lwz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r10,144(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 144);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B0C62B4;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// addi r1,r1,176
	ctx.r1.s64 = ctx.r1.s64 + 176;
	// lfd f30,-48(r1)
	ctx.fpscr.disableFlushMode();
	ctx.f30.u64 = REX_LOAD_U64(ctx.r1.u32 + -48);
	// lfd f31,-40(r1)
	ctx.f31.u64 = REX_LOAD_U64(ctx.r1.u32 + -40);
	// b 0x8b0cba0c
	__restgprlr_29(ctx, base);
	return;
loc_8B0C62C4:
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// lfs f30,44(r31)
	ctx.fpscr.disableFlushMode();
	temp.u32 = REX_LOAD_U32(ctx.r31.u32 + 44);
	ctx.f30.f64 = double(temp.f32);
	// bl 0x8b0ce2d8
	ctx.lr = 0x8B0C62D0;
	sub_8B0CE2D8(ctx, base);
	// frsp f0,f1
	ctx.fpscr.disableFlushMode();
	ctx.f0.f64 = double(float(ctx.f1.f64));
	// lis r11,-29943
	ctx.r11.s64 = -1962344448;
	// stfs f0,80(r1)
	temp.f32 = float(ctx.f0.f64);
	REX_STORE_U32(ctx.r1.u32 + 80, temp.u32);
	// lfs f31,-27648(r11)
	temp.u32 = REX_LOAD_U32(ctx.r11.u32 + -27648);
	ctx.f31.f64 = double(temp.f32);
	// fcmpu cr6,f0,f0
	ctx.cr6.compare(ctx.f0.f64, ctx.f0.f64);
	// bne cr6,0x8b0c62f8
	if (!ctx.cr6.eq) goto loc_8B0C62F8;
	// fabs f0,f0
	ctx.f0.u64 = ctx.f0.u64 & ~0x8000000000000000;
	// li r11,1
	ctx.r11.s64 = 1;
	// fcmpu cr6,f0,f31
	ctx.cr6.compare(ctx.f0.f64, ctx.f31.f64);
	// ble cr6,0x8b0c62fc
	if (!ctx.cr6.gt) goto loc_8B0C62FC;
loc_8B0C62F8:
	// li r11,0
	ctx.r11.s64 = 0;
loc_8B0C62FC:
	// clrlwi r11,r11,24
	ctx.r11.u64 = ctx.r11.u32 & 0xFF;
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// bne cr6,0x8b0c6334
	if (!ctx.cr6.eq) goto loc_8B0C6334;
	// lwz r11,0(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 0);
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// lwz r10,24(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 24);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B0C631C;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// lis r9,-29943
	ctx.r9.s64 = -1962344448;
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// addi r3,r9,-27408
	ctx.r3.s64 = ctx.r9.s64 + -27408;
	// mr r5,r30
	ctx.r5.u64 = ctx.r30.u64;
	// bl 0x8b0df2a8
	ctx.lr = 0x8B0C6330;
	sub_8B0DF2A8(ctx, base);
	// stfs f31,80(r1)
	ctx.fpscr.disableFlushMode();
	temp.f32 = float(ctx.f31.f64);
	REX_STORE_U32(ctx.r1.u32 + 80, temp.u32);
loc_8B0C6334:
	// lwz r11,0(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 0);
	// addi r4,r1,80
	ctx.r4.s64 = ctx.r1.s64 + 80;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// lwz r10,64(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 64);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B0C634C;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// clrlwi r9,r3,24
	ctx.r9.u64 = ctx.r3.u32 & 0xFF;
	// cmplwi cr6,r9,0
	ctx.cr6.compare<uint32_t>(ctx.r9.u32, 0, ctx.xer);
	// beq cr6,0x8b0c637c
	if (ctx.cr6.eq) goto loc_8B0C637C;
	// lfs f1,80(r1)
	ctx.fpscr.disableFlushMode();
	temp.u32 = REX_LOAD_U32(ctx.r1.u32 + 80);
	ctx.f1.f64 = double(temp.f32);
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// stfd f1,40(r1)
	REX_STORE_U64(ctx.r1.u32 + 40, ctx.f1.u64);
	// ld r6,40(r1)
	ctx.r6.u64 = REX_LOAD_U64(ctx.r1.u32 + 40);
	// addi r5,r11,16516
	ctx.r5.s64 = ctx.r11.s64 + 16516;
	// li r4,32
	ctx.r4.s64 = 32;
	// addi r3,r1,96
	ctx.r3.s64 = ctx.r1.s64 + 96;
	// bl 0x8b0c3fd8
	ctx.lr = 0x8B0C6378;
	sub_8B0C3FD8(ctx, base);
	// addi r30,r1,96
	ctx.r30.s64 = ctx.r1.s64 + 96;
loc_8B0C637C:
	// lwz r11,20(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 20);
	// li r10,48
	ctx.r10.s64 = 48;
	// lfs f0,80(r1)
	ctx.fpscr.disableFlushMode();
	temp.u32 = REX_LOAD_U32(ctx.r1.u32 + 80);
	ctx.f0.f64 = double(temp.f32);
	// rlwinm r9,r11,0,19,19
	ctx.r9.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 0) & 0x1000;
	// fctiwz f13,f0
	ctx.f13.s64 = std::isnan(ctx.f0.f64) ? int64_t(0x80000000U) : (ctx.f0.f64 >= double(INT_MAX)) ? INT_MAX : simde_mm_cvttsd_si32(simde_mm_load_sd(&ctx.f0.f64));
	// stfs f0,44(r31)
	temp.f32 = float(ctx.f0.f64);
	REX_STORE_U32(ctx.r31.u32 + 44, temp.u32);
	// cmpwi cr6,r9,0
	ctx.cr6.compare<int32_t>(ctx.r9.s32, 0, ctx.xer);
	// stfiwx f13,r31,r10
	REX_STORE_U32(ctx.r31.u32 + ctx.r10.u32, ctx.f13.u32);
	// bne cr6,0x8b0c63bc
	if (!ctx.cr6.eq) goto loc_8B0C63BC;
	// lwz r11,0(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 0);
	// mr r4,r30
	ctx.r4.u64 = ctx.r30.u64;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// fmr f1,f30
	ctx.f1.f64 = ctx.f30.f64;
	// lwz r10,68(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 68);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B0C63BC;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
loc_8B0C63BC:
	// addi r1,r1,176
	ctx.r1.s64 = ctx.r1.s64 + 176;
	// lfd f30,-48(r1)
	ctx.fpscr.disableFlushMode();
	ctx.f30.u64 = REX_LOAD_U64(ctx.r1.u32 + -48);
	// lfd f31,-40(r1)
	ctx.f31.u64 = REX_LOAD_U64(ctx.r1.u32 + -40);
	// b 0x8b0cba0c
	__restgprlr_29(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0C69B0) {
	REX_FUNC_PROLOGUE();
	// lwz r3,4(r3)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r3.u32 + 4);
	// lwz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r10,52(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 52);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctr 
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	return;
}

DEFINE_REX_FUNC(sub_8B0C69E0) {
	REX_FUNC_PROLOGUE();
	// lwz r3,4(r3)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r3.u32 + 4);
	// lwz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r10,60(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 60);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctr 
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	return;
}

DEFINE_REX_FUNC(sub_8B0C6A18) {
	REX_FUNC_PROLOGUE();
	// addi r3,r3,-24
	ctx.r3.s64 = ctx.r3.s64 + -24;
	// b 0x8b0c61b0
	sub_8B0C61B0(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0C6A28) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// stwu r1,-96(r1)
	ea = -96 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lis r11,-29936
	ctx.r11.s64 = -1961885696;
	// lwz r3,-27244(r11)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r11.u32 + -27244);
	// lwz r10,0(r3)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r9,24(r10)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r10.u32 + 24);
	// mtctr r9
	ctx.ctr.u64 = ctx.r9.u64;
	// bctrl 
	ctx.lr = 0x8B0C6A4C;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// li r3,1
	ctx.r3.s64 = 1;
	// addi r1,r1,96
	ctx.r1.s64 = ctx.r1.s64 + 96;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0C6B30) {
	REX_FUNC_PROLOGUE();
	PPCRegister temp{};
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// std r30,-24(r1)
	REX_STORE_U64(ctx.r1.u32 + -24, ctx.r30.u64);
	// std r31,-16(r1)
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.r31.u64);
	// stwu r1,-128(r1)
	ea = -128 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// lis r8,-29943
	ctx.r8.s64 = -1962344448;
	// lis r9,-29943
	ctx.r9.s64 = -1962344448;
	// li r11,0
	ctx.r11.s64 = 0;
	// addi r30,r8,-27524
	ctx.r30.s64 = ctx.r8.s64 + -27524;
	// lfs f2,8492(r10)
	ctx.fpscr.disableFlushMode();
	temp.u32 = REX_LOAD_U32(ctx.r10.u32 + 8492);
	ctx.f2.f64 = double(temp.f32);
	// addi r9,r9,-27484
	ctx.r9.s64 = ctx.r9.s64 + -27484;
	// li r10,0
	ctx.r10.s64 = 0;
	// stb r11,8(r3)
	REX_STORE_U8(ctx.r3.u32 + 8, ctx.r11.u8);
	// li r8,0
	ctx.r8.s64 = 0;
	// stw r11,12(r3)
	REX_STORE_U32(ctx.r3.u32 + 12, ctx.r11.u32);
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// stw r11,16(r3)
	REX_STORE_U32(ctx.r3.u32 + 16, ctx.r11.u32);
	// stw r11,20(r3)
	REX_STORE_U32(ctx.r3.u32 + 20, ctx.r11.u32);
	// fmr f1,f2
	ctx.f1.f64 = ctx.f2.f64;
	// stw r11,4(r3)
	REX_STORE_U32(ctx.r3.u32 + 4, ctx.r11.u32);
	// stw r9,0(r3)
	REX_STORE_U32(ctx.r3.u32 + 0, ctx.r9.u32);
	// stw r30,24(r3)
	REX_STORE_U32(ctx.r3.u32 + 24, ctx.r30.u32);
	// stw r11,92(r1)
	REX_STORE_U32(ctx.r1.u32 + 92, ctx.r11.u32);
	// bl 0x8b0c67e8
	ctx.lr = 0x8B0C6B94;
	sub_8B0C67E8(ctx, base);
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// addi r1,r1,128
	ctx.r1.s64 = ctx.r1.s64 + 128;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// ld r30,-24(r1)
	ctx.r30.u64 = REX_LOAD_U64(ctx.r1.u32 + -24);
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0C6D30) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9a8
	ctx.lr = 0x8B0C6D38;
	__savegprlr_24(ctx, base);
	// stwu r1,-416(r1)
	ea = -416 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lis r11,-29938
	ctx.r11.s64 = -1962016768;
	// lis r10,-29943
	ctx.r10.s64 = -1962344448;
	// mr r28,r3
	ctx.r28.u64 = ctx.r3.u64;
	// mr r25,r4
	ctx.r25.u64 = ctx.r4.u64;
	// mr r24,r5
	ctx.r24.u64 = ctx.r5.u64;
	// li r31,0
	ctx.r31.s64 = 0;
	// lis r26,-29936
	ctx.r26.s64 = -1961885696;
	// addi r29,r11,9060
	ctx.r29.s64 = ctx.r11.s64 + 9060;
	// addi r27,r10,-27304
	ctx.r27.s64 = ctx.r10.s64 + -27304;
loc_8B0C6D60:
	// rlwinm r11,r31,3,0,28
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r31.u32 | (ctx.r31.u64 << 32), 3) & 0xFFFFFFF8;
	// cmpwi cr6,r31,0
	ctx.cr6.compare<int32_t>(ctx.r31.s32, 0, ctx.xer);
	// add r30,r11,r28
	ctx.r30.u64 = ctx.r11.u64 + ctx.r28.u64;
	// addi r3,r1,80
	ctx.r3.s64 = ctx.r1.s64 + 80;
	// beq cr6,0x8b0c6d8c
	if (ctx.cr6.eq) goto loc_8B0C6D8C;
	// mr r5,r27
	ctx.r5.u64 = ctx.r27.u64;
	// addi r7,r31,1
	ctx.r7.s64 = ctx.r31.s64 + 1;
	// mr r6,r25
	ctx.r6.u64 = ctx.r25.u64;
	// li r4,256
	ctx.r4.s64 = 256;
	// bl 0x8b0c3fd8
	ctx.lr = 0x8B0C6D88;
	sub_8B0C3FD8(ctx, base);
	// b 0x8b0c6d98
	goto loc_8B0C6D98;
loc_8B0C6D8C:
	// li r5,256
	ctx.r5.s64 = 256;
	// mr r4,r25
	ctx.r4.u64 = ctx.r25.u64;
	// bl 0x8b0c3f18
	ctx.lr = 0x8B0C6D98;
	sub_8B0C3F18(ctx, base);
loc_8B0C6D98:
	// lwz r3,-27244(r26)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r26.u32 + -27244);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0c6dc8
	if (ctx.cr6.eq) goto loc_8B0C6DC8;
	// lwz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// addi r4,r1,80
	ctx.r4.s64 = ctx.r1.s64 + 80;
	// lwz r10,52(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 52);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B0C6DB8;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0c6dd4
	if (ctx.cr6.eq) goto loc_8B0C6DD4;
	// addi r11,r3,24
	ctx.r11.s64 = ctx.r3.s64 + 24;
	// b 0x8b0c6dd8
	goto loc_8B0C6DD8;
loc_8B0C6DC8:
	// mr r3,r29
	ctx.r3.u64 = ctx.r29.u64;
	// addi r11,r29,24
	ctx.r11.s64 = ctx.r29.s64 + 24;
	// b 0x8b0c6dd8
	goto loc_8B0C6DD8;
loc_8B0C6DD4:
	// li r11,0
	ctx.r11.s64 = 0;
loc_8B0C6DD8:
	// stw r11,0(r30)
	REX_STORE_U32(ctx.r30.u32 + 0, ctx.r11.u32);
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// bne cr6,0x8b0c6e04
	if (!ctx.cr6.eq) goto loc_8B0C6E04;
	// addi r11,r29,24
	ctx.r11.s64 = ctx.r29.s64 + 24;
	// cmpwi cr6,r31,0
	ctx.cr6.compare<int32_t>(ctx.r31.s32, 0, ctx.xer);
	// stw r11,0(r30)
	REX_STORE_U32(ctx.r30.u32 + 0, ctx.r11.u32);
	// ble cr6,0x8b0c6e04
	if (!ctx.cr6.gt) goto loc_8B0C6E04;
	// lwz r11,0(r28)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r28.u32 + 0);
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// stw r11,0(r30)
	REX_STORE_U32(ctx.r30.u32 + 0, ctx.r11.u32);
	// beq cr6,0x8b0c6e10
	if (ctx.cr6.eq) goto loc_8B0C6E10;
loc_8B0C6E04:
	// lwz r11,0(r30)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r30.u32 + 0);
	// addi r11,r11,-24
	ctx.r11.s64 = ctx.r11.s64 + -24;
	// b 0x8b0c6e14
	goto loc_8B0C6E14;
loc_8B0C6E10:
	// li r11,0
	ctx.r11.s64 = 0;
loc_8B0C6E14:
	// addi r31,r31,1
	ctx.r31.s64 = ctx.r31.s64 + 1;
	// stw r11,4(r30)
	REX_STORE_U32(ctx.r30.u32 + 4, ctx.r11.u32);
	// cmpwi cr6,r31,4
	ctx.cr6.compare<int32_t>(ctx.r31.s32, 4, ctx.xer);
	// blt cr6,0x8b0c6d60
	if (ctx.cr6.lt) goto loc_8B0C6D60;
	// lwz r11,0(r28)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r28.u32 + 0);
	// addi r10,r29,24
	ctx.r10.s64 = ctx.r29.s64 + 24;
	// cmplw cr6,r11,r10
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, ctx.r10.u32, ctx.xer);
	// bne cr6,0x8b0c6e74
	if (!ctx.cr6.eq) goto loc_8B0C6E74;
	// lwz r11,-27244(r26)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r26.u32 + -27244);
	// lis r31,-29938
	ctx.r31.s64 = -1962016768;
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// bne cr6,0x8b0c6e50
	if (!ctx.cr6.eq) goto loc_8B0C6E50;
	// lbz r11,9348(r31)
	ctx.r11.u64 = REX_LOAD_U8(ctx.r31.u32 + 9348);
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// beq cr6,0x8b0c6e74
	if (ctx.cr6.eq) goto loc_8B0C6E74;
loc_8B0C6E50:
	// clrlwi r11,r24,24
	ctx.r11.u64 = ctx.r24.u32 & 0xFF;
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// bne cr6,0x8b0c6e6c
	if (!ctx.cr6.eq) goto loc_8B0C6E6C;
	// lis r11,-29943
	ctx.r11.s64 = -1962344448;
	// mr r4,r25
	ctx.r4.u64 = ctx.r25.u64;
	// addi r3,r11,-27168
	ctx.r3.s64 = ctx.r11.s64 + -27168;
	// bl 0x8b0df2a8
	ctx.lr = 0x8B0C6E6C;
	sub_8B0DF2A8(ctx, base);
loc_8B0C6E6C:
	// li r11,0
	ctx.r11.s64 = 0;
	// stb r11,9348(r31)
	REX_STORE_U8(ctx.r31.u32 + 9348, ctx.r11.u8);
loc_8B0C6E74:
	// addi r1,r1,416
	ctx.r1.s64 = ctx.r1.s64 + 416;
	// b 0x8b0cb9f8
	__restgprlr_24(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0C72A8) {
	REX_FUNC_PROLOGUE();
	// stw r4,4(r3)
	REX_STORE_U32(ctx.r3.u32 + 4, ctx.r4.u32);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0C72B0) {
	REX_FUNC_PROLOGUE();
	// stw r4,0(r3)
	REX_STORE_U32(ctx.r3.u32 + 0, ctx.r4.u32);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0C72B8) {
	REX_FUNC_PROLOGUE();
	// lwz r3,0(r3)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0C72C0) {
	REX_FUNC_PROLOGUE();
	// lhz r3,8(r3)
	ctx.r3.u64 = REX_LOAD_U16(ctx.r3.u32 + 8);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0C72C8) {
	REX_FUNC_PROLOGUE();
	// lwz r3,4(r3)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r3.u32 + 4);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0C72D0) {
	REX_FUNC_PROLOGUE();
	// sth r4,8(r3)
	REX_STORE_U16(ctx.r3.u32 + 8, ctx.r4.u16);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0C72D8) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// std r30,-24(r1)
	REX_STORE_U64(ctx.r1.u32 + -24, ctx.r30.u64);
	// std r31,-16(r1)
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.r31.u64);
	// stwu r1,-128(r1)
	ea = -128 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// li r11,0
	ctx.r11.s64 = 0;
	// li r10,3
	ctx.r10.s64 = 3;
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// stb r11,7(r3)
	REX_STORE_U8(ctx.r3.u32 + 7, ctx.r11.u8);
	// mr r30,r4
	ctx.r30.u64 = ctx.r4.u64;
	// stb r11,6(r3)
	REX_STORE_U8(ctx.r3.u32 + 6, ctx.r11.u8);
	// cmplwi cr6,r4,0
	ctx.cr6.compare<uint32_t>(ctx.r4.u32, 0, ctx.xer);
	// stb r11,5(r3)
	REX_STORE_U8(ctx.r3.u32 + 5, ctx.r11.u8);
	// stb r11,4(r3)
	REX_STORE_U8(ctx.r3.u32 + 4, ctx.r11.u8);
	// sth r11,8(r3)
	REX_STORE_U16(ctx.r3.u32 + 8, ctx.r11.u16);
	// stw r10,0(r3)
	REX_STORE_U32(ctx.r3.u32 + 0, ctx.r10.u32);
	// beq cr6,0x8b0c73a4
	if (ctx.cr6.eq) goto loc_8B0C73A4;
	// lbz r11,0(r4)
	ctx.r11.u64 = REX_LOAD_U8(ctx.r4.u32 + 0);
	// extsb r11,r11
	ctx.r11.s64 = ctx.r11.s8;
	// cmpwi cr6,r11,48
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 48, ctx.xer);
	// blt cr6,0x8b0c73a4
	if (ctx.cr6.lt) goto loc_8B0C73A4;
	// cmpwi cr6,r11,57
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 57, ctx.xer);
	// bgt cr6,0x8b0c73a4
	if (ctx.cr6.gt) goto loc_8B0C73A4;
	// li r4,46
	ctx.r4.s64 = 46;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// bl 0x8b0ccee0
	ctx.lr = 0x8B0C7340;
	sub_8B0CCEE0(ctx, base);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0c73a4
	if (ctx.cr6.eq) goto loc_8B0C73A4;
	// lis r11,-29943
	ctx.r11.s64 = -1962344448;
	// addi r9,r1,96
	ctx.r9.s64 = ctx.r1.s64 + 96;
	// addi r4,r11,-27064
	ctx.r4.s64 = ctx.r11.s64 + -27064;
	// addi r8,r1,92
	ctx.r8.s64 = ctx.r1.s64 + 92;
	// addi r7,r1,88
	ctx.r7.s64 = ctx.r1.s64 + 88;
	// addi r6,r1,84
	ctx.r6.s64 = ctx.r1.s64 + 84;
	// addi r5,r1,80
	ctx.r5.s64 = ctx.r1.s64 + 80;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// bl 0x8b0cd008
	ctx.lr = 0x8B0C736C;
	sub_8B0CD008(ctx, base);
	// cmpwi cr6,r3,4
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 4, ctx.xer);
	// blt cr6,0x8b0c7394
	if (ctx.cr6.lt) goto loc_8B0C7394;
	// lwz r11,80(r1)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r1.u32 + 80);
	// lwz r10,84(r1)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r1.u32 + 84);
	// lwz r9,88(r1)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r1.u32 + 88);
	// lwz r7,92(r1)
	ctx.r7.u64 = REX_LOAD_U32(ctx.r1.u32 + 92);
	// stb r11,4(r31)
	REX_STORE_U8(ctx.r31.u32 + 4, ctx.r11.u8);
	// stb r10,5(r31)
	REX_STORE_U8(ctx.r31.u32 + 5, ctx.r10.u8);
	// stb r9,6(r31)
	REX_STORE_U8(ctx.r31.u32 + 6, ctx.r9.u8);
	// stb r7,7(r31)
	REX_STORE_U8(ctx.r31.u32 + 7, ctx.r7.u8);
loc_8B0C7394:
	// cmpwi cr6,r3,5
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 5, ctx.xer);
	// bne cr6,0x8b0c73a4
	if (!ctx.cr6.eq) goto loc_8B0C73A4;
	// lwz r11,96(r1)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r1.u32 + 96);
	// sth r11,8(r31)
	REX_STORE_U16(ctx.r31.u32 + 8, ctx.r11.u16);
loc_8B0C73A4:
	// addi r1,r1,128
	ctx.r1.s64 = ctx.r1.s64 + 128;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// ld r30,-24(r1)
	ctx.r30.u64 = REX_LOAD_U64(ctx.r1.u32 + -24);
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0C77F0) {
	REX_FUNC_PROLOGUE();
	// lis r11,-29936
	ctx.r11.s64 = -1961885696;
	// addi r3,r11,-27188
	ctx.r3.s64 = ctx.r11.s64 + -27188;
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0C7800) {
	REX_FUNC_PROLOGUE();
	// lis r11,-29936
	ctx.r11.s64 = -1961885696;
	// addi r3,r11,-24608
	ctx.r3.s64 = ctx.r11.s64 + -24608;
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0C7810) {
	REX_FUNC_PROLOGUE();
	PPCRegister temp{};
	// lbz r11,0(r4)
	ctx.r11.u64 = REX_LOAD_U8(ctx.r4.u32 + 0);
	// extsb r11,r11
	ctx.r11.s64 = ctx.r11.s8;
	// add r10,r11,r3
	ctx.r10.u64 = ctx.r11.u64 + ctx.r3.u64;
	// lbz r3,2320(r10)
	ctx.r3.u64 = REX_LOAD_U8(ctx.r10.u32 + 2320);
	// extsb r9,r3
	ctx.r9.s64 = ctx.r3.s8;
	// addic r8,r9,-1
	ctx.xer.ca = ctx.r9.u32 > 0;
	ctx.r8.s64 = ctx.r9.s64 + -1;
	// subfe r7,r8,r9
	temp.u8 = (~ctx.r8.u32 + ctx.r9.u32 < ~ctx.r8.u32) | (~ctx.r8.u32 + ctx.r9.u32 + ctx.xer.ca < ctx.xer.ca);
	ctx.r7.u64 = ~ctx.r8.u64 + ctx.r9.u64 + ctx.xer.ca;
	ctx.xer.ca = temp.u8;
	// stw r7,0(r5)
	REX_STORE_U32(ctx.r5.u32 + 0, ctx.r7.u32);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0C7920) {
	REX_FUNC_PROLOGUE();
	// std r31,-8(r1)
	REX_STORE_U64(ctx.r1.u32 + -8, ctx.r31.u64);
	// lwz r6,16(r3)
	ctx.r6.u64 = REX_LOAD_U32(ctx.r3.u32 + 16);
	// li r8,0
	ctx.r8.s64 = 0;
	// cmpwi cr6,r6,0
	ctx.cr6.compare<int32_t>(ctx.r6.s32, 0, ctx.xer);
	// ble cr6,0x8b0c7988
	if (!ctx.cr6.gt) goto loc_8B0C7988;
	// addi r7,r3,24
	ctx.r7.s64 = ctx.r3.s64 + 24;
loc_8B0C7938:
	// lbzx r10,r7,r8
	ctx.r10.u64 = REX_LOAD_U8(ctx.r7.u32 + ctx.r8.u32);
	// mr r11,r4
	ctx.r11.u64 = ctx.r4.u64;
	// extsb r9,r10
	ctx.r9.s64 = ctx.r10.s8;
	// rlwinm r10,r9,3,0,28
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r9.u32 | (ctx.r9.u64 << 32), 3) & 0xFFFFFFF8;
	// add r10,r10,r3
	ctx.r10.u64 = ctx.r10.u64 + ctx.r3.u64;
	// lwz r10,284(r10)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r10.u32 + 284);
loc_8B0C7950:
	// lbz r9,0(r11)
	ctx.r9.u64 = REX_LOAD_U8(ctx.r11.u32 + 0);
	// lbz r31,0(r10)
	ctx.r31.u64 = REX_LOAD_U8(ctx.r10.u32 + 0);
	// cmpwi cr6,r9,0
	ctx.cr6.compare<int32_t>(ctx.r9.s32, 0, ctx.xer);
	// subf r9,r31,r9
	ctx.r9.u64 = ctx.r9.u64 - ctx.r31.u64;
	// beq cr6,0x8b0c7974
	if (ctx.cr6.eq) goto loc_8B0C7974;
	// addi r11,r11,1
	ctx.r11.s64 = ctx.r11.s64 + 1;
	// addi r10,r10,1
	ctx.r10.s64 = ctx.r10.s64 + 1;
	// cmpwi cr6,r9,0
	ctx.cr6.compare<int32_t>(ctx.r9.s32, 0, ctx.xer);
	// beq cr6,0x8b0c7950
	if (ctx.cr6.eq) goto loc_8B0C7950;
loc_8B0C7974:
	// cmpwi cr6,r9,0
	ctx.cr6.compare<int32_t>(ctx.r9.s32, 0, ctx.xer);
	// beq cr6,0x8b0c799c
	if (ctx.cr6.eq) goto loc_8B0C799C;
	// addi r8,r8,1
	ctx.r8.s64 = ctx.r8.s64 + 1;
	// cmpw cr6,r8,r6
	ctx.cr6.compare<int32_t>(ctx.r8.s32, ctx.r6.s32, ctx.xer);
	// blt cr6,0x8b0c7938
	if (ctx.cr6.lt) goto loc_8B0C7938;
loc_8B0C7988:
	// li r11,0
	ctx.r11.s64 = 0;
	// li r3,0
	ctx.r3.s64 = 0;
	// stw r11,0(r5)
	REX_STORE_U32(ctx.r5.u32 + 0, ctx.r11.u32);
	// ld r31,-8(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -8);
	// blr 
	return;
loc_8B0C799C:
	// add r11,r8,r3
	ctx.r11.u64 = ctx.r8.u64 + ctx.r3.u64;
	// addi r10,r11,24
	ctx.r10.s64 = ctx.r11.s64 + 24;
	// lbz r10,24(r11)
	ctx.r10.u64 = REX_LOAD_U8(ctx.r11.u32 + 24);
	// extsb r10,r10
	ctx.r10.s64 = ctx.r10.s8;
	// addi r9,r10,35
	ctx.r9.s64 = ctx.r10.s64 + 35;
	// rlwinm r8,r9,3,0,28
	ctx.r8.u64 = __builtin_rotateleft64(ctx.r9.u32 | (ctx.r9.u64 << 32), 3) & 0xFFFFFFF8;
	// lwzx r7,r8,r3
	ctx.r7.u64 = REX_LOAD_U32(ctx.r8.u32 + ctx.r3.u32);
	// stw r7,0(r5)
	REX_STORE_U32(ctx.r5.u32 + 0, ctx.r7.u32);
	// lbz r3,24(r11)
	ctx.r3.u64 = REX_LOAD_U8(ctx.r11.u32 + 24);
	// ld r31,-8(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -8);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0C7A48) {
	REX_FUNC_PROLOGUE();
	// li r11,0
	ctx.r11.s64 = 0;
	// li r3,0
	ctx.r3.s64 = 0;
	// stw r11,0(r5)
	REX_STORE_U32(ctx.r5.u32 + 0, ctx.r11.u32);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0C7B48) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// std r31,-16(r1)
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.r31.u64);
	// stwu r1,-96(r1)
	ea = -96 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lbz r11,20(r3)
	ctx.r11.u64 = REX_LOAD_U8(ctx.r3.u32 + 20);
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// rlwinm r10,r11,0,30,30
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 0) & 0x2;
	// cmplwi cr6,r10,0
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 0, ctx.xer);
	// beq cr6,0x8b0c7b84
	if (ctx.cr6.eq) goto loc_8B0C7B84;
	// li r3,0
	ctx.r3.s64 = 0;
	// addi r1,r1,96
	ctx.r1.s64 = ctx.r1.s64 + 96;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
loc_8B0C7B84:
	// add r4,r4,r5
	ctx.r4.u64 = ctx.r4.u64 + ctx.r5.u64;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0c7a58
	ctx.lr = 0x8B0C7B90;
	sub_8B0C7A58(ctx, base);
	// lbz r11,20(r31)
	ctx.r11.u64 = REX_LOAD_U8(ctx.r31.u32 + 20);
	// clrlwi r10,r11,24
	ctx.r10.u64 = ctx.r11.u32 & 0xFF;
	// rlwinm r10,r10,0,31,29
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r10.u32 | (ctx.r10.u64 << 32), 0) & 0xFFFFFFFFFFFFFFFD;
	// stb r10,20(r31)
	REX_STORE_U8(ctx.r31.u32 + 20, ctx.r10.u8);
	// addi r1,r1,96
	ctx.r1.s64 = ctx.r1.s64 + 96;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0C7D00) {
	REX_FUNC_PROLOGUE();
	// cmplwi cr6,r4,1
	ctx.cr6.compare<uint32_t>(ctx.r4.u32, 1, ctx.xer);
	// blt cr6,0x8b0c7d34
	if (ctx.cr6.lt) goto loc_8B0C7D34;
	// beq cr6,0x8b0c7d24
	if (ctx.cr6.eq) goto loc_8B0C7D24;
	// cmplwi cr6,r4,3
	ctx.cr6.compare<uint32_t>(ctx.r4.u32, 3, ctx.xer);
	// bge cr6,0x8b0c7d38
	if (!ctx.cr6.lt) goto loc_8B0C7D38;
	// lwz r11,28(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 28);
	// subf r10,r5,r11
	ctx.r10.u64 = ctx.r11.u64 - ctx.r5.u64;
	// stw r10,12(r3)
	REX_STORE_U32(ctx.r3.u32 + 12, ctx.r10.u32);
	// b 0x8b0c7d38
	goto loc_8B0C7D38;
loc_8B0C7D24:
	// lwz r11,12(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 12);
	// add r11,r5,r11
	ctx.r11.u64 = ctx.r5.u64 + ctx.r11.u64;
	// stw r11,12(r3)
	REX_STORE_U32(ctx.r3.u32 + 12, ctx.r11.u32);
	// b 0x8b0c7d38
	goto loc_8B0C7D38;
loc_8B0C7D34:
	// stw r5,12(r3)
	REX_STORE_U32(ctx.r3.u32 + 12, ctx.r5.u32);
loc_8B0C7D38:
	// lwz r11,12(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 12);
	// lwz r10,28(r3)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r3.u32 + 28);
	// cmpw cr6,r11,r10
	ctx.cr6.compare<int32_t>(ctx.r11.s32, ctx.r10.s32, ctx.xer);
	// ble cr6,0x8b0c7d58
	if (!ctx.cr6.gt) goto loc_8B0C7D58;
	// lbz r11,20(r3)
	ctx.r11.u64 = REX_LOAD_U8(ctx.r3.u32 + 20);
	// ori r10,r11,2
	ctx.r10.u64 = ctx.r11.u64 | 2;
	// stb r10,20(r3)
	REX_STORE_U8(ctx.r3.u32 + 20, ctx.r10.u8);
	// blr 
	return;
loc_8B0C7D58:
	// lbz r9,20(r3)
	ctx.r9.u64 = REX_LOAD_U8(ctx.r3.u32 + 20);
	// lwz r10,32(r3)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r3.u32 + 32);
	// clrlwi r8,r9,24
	ctx.r8.u64 = ctx.r9.u32 & 0xFF;
	// cmpw cr6,r11,r10
	ctx.cr6.compare<int32_t>(ctx.r11.s32, ctx.r10.s32, ctx.xer);
	// rlwinm r8,r8,0,31,29
	ctx.r8.u64 = __builtin_rotateleft64(ctx.r8.u32 | (ctx.r8.u64 << 32), 0) & 0xFFFFFFFFFFFFFFFD;
	// stb r8,20(r3)
	REX_STORE_U8(ctx.r3.u32 + 20, ctx.r8.u8);
	// blt cr6,0x8b0c7d84
	if (ctx.cr6.lt) goto loc_8B0C7D84;
	// lwz r9,4(r3)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r3.u32 + 4);
	// add r10,r9,r10
	ctx.r10.u64 = ctx.r9.u64 + ctx.r10.u64;
	// cmpw cr6,r11,r10
	ctx.cr6.compare<int32_t>(ctx.r11.s32, ctx.r10.s32, ctx.xer);
	// bltlr cr6
	if (ctx.cr6.lt) return;
loc_8B0C7D84:
	// lwz r11,36(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 36);
	// li r4,-1
	ctx.r4.s64 = -1;
	// mtctr r11
	ctx.ctr.u64 = ctx.r11.u64;
	// bctr 
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	return;
}

DEFINE_REX_FUNC(sub_8B0C7F78) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9bc
	ctx.lr = 0x8B0C7F80;
	__savegprlr_29(ctx, base);
	// stwu r1,-112(r1)
	ea = -112 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lwz r11,8(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 8);
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// cmpwi cr6,r11,0
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// bge cr6,0x8b0c7fe8
	if (!ctx.cr6.lt) goto loc_8B0C7FE8;
	// lwz r30,4(r3)
	ctx.r30.u64 = REX_LOAD_U32(ctx.r3.u32 + 4);
	// stw r4,8(r3)
	REX_STORE_U32(ctx.r3.u32 + 8, ctx.r4.u32);
	// cmpwi cr6,r30,0
	ctx.cr6.compare<int32_t>(ctx.r30.s32, 0, ctx.xer);
	// beq cr6,0x8b0c7fe0
	if (ctx.cr6.eq) goto loc_8B0C7FE0;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// mr r4,r30
	ctx.r4.u64 = ctx.r30.u64;
	// lwz r11,1144(r11)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r11.u32 + 1144);
	// lwz r3,0(r11)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r11.u32 + 0);
	// lwz r10,0(r3)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r9,4(r10)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r10.u32 + 4);
	// mtctr r9
	ctx.ctr.u64 = ctx.r9.u64;
	// bctrl 
	ctx.lr = 0x8B0C7FC4;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// mr r5,r30
	ctx.r5.u64 = ctx.r30.u64;
	// lwz r4,0(r31)
	ctx.r4.u64 = REX_LOAD_U32(ctx.r31.u32 + 0);
	// mr r29,r3
	ctx.r29.u64 = ctx.r3.u64;
	// bl 0x8b0cbb30
	ctx.lr = 0x8B0C7FD4;
	sub_8B0CBB30(ctx, base);
	// stw r29,0(r31)
	REX_STORE_U32(ctx.r31.u32 + 0, ctx.r29.u32);
	// addi r1,r1,112
	ctx.r1.s64 = ctx.r1.s64 + 112;
	// b 0x8b0cba0c
	__restgprlr_29(ctx, base);
	return;
loc_8B0C7FE0:
	// li r11,0
	ctx.r11.s64 = 0;
	// stw r11,0(r31)
	REX_STORE_U32(ctx.r31.u32 + 0, ctx.r11.u32);
loc_8B0C7FE8:
	// addi r1,r1,112
	ctx.r1.s64 = ctx.r1.s64 + 112;
	// b 0x8b0cba0c
	__restgprlr_29(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0C8220) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// std r31,-16(r1)
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.r31.u64);
	// stwu r1,-96(r1)
	ea = -96 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lbz r11,21(r3)
	ctx.r11.u64 = REX_LOAD_U8(ctx.r3.u32 + 21);
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// clrlwi r10,r11,31
	ctx.r10.u64 = ctx.r11.u32 & 0x1;
	// cmplwi cr6,r10,0
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 0, ctx.xer);
	// beq cr6,0x8b0c82a8
	if (ctx.cr6.eq) goto loc_8B0C82A8;
	// lbz r11,20(r3)
	ctx.r11.u64 = REX_LOAD_U8(ctx.r3.u32 + 20);
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// bne cr6,0x8b0c82a8
	if (!ctx.cr6.eq) goto loc_8B0C82A8;
	// li r4,1
	ctx.r4.s64 = 1;
	// bl 0x8b0c7a58
	ctx.lr = 0x8B0C8258;
	sub_8B0C7A58(ctx, base);
	// clrlwi r11,r3,24
	ctx.r11.u64 = ctx.r3.u32 & 0xFF;
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// beq cr6,0x8b0c82a8
	if (ctx.cr6.eq) goto loc_8B0C82A8;
loc_8B0C8264:
	// lwz r11,0(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 0);
	// lwz r9,32(r31)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r31.u32 + 32);
	// lwz r10,12(r31)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r31.u32 + 12);
	// subf r11,r9,r11
	ctx.r11.u64 = ctx.r11.u64 - ctx.r9.u64;
	// lbzx r3,r11,r10
	ctx.r3.u64 = REX_LOAD_U8(ctx.r11.u32 + ctx.r10.u32);
	// bl 0x8b0cc470
	ctx.lr = 0x8B0C827C;
	sub_8B0CC470(ctx, base);
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// beq cr6,0x8b0c82a8
	if (ctx.cr6.eq) goto loc_8B0C82A8;
	// lwz r11,12(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 12);
	// li r4,1
	ctx.r4.s64 = 1;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// addi r11,r11,1
	ctx.r11.s64 = ctx.r11.s64 + 1;
	// stw r11,12(r31)
	REX_STORE_U32(ctx.r31.u32 + 12, ctx.r11.u32);
	// bl 0x8b0c7a58
	ctx.lr = 0x8B0C829C;
	sub_8B0C7A58(ctx, base);
	// clrlwi r10,r3,24
	ctx.r10.u64 = ctx.r3.u32 & 0xFF;
	// cmplwi cr6,r10,0
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 0, ctx.xer);
	// bne cr6,0x8b0c8264
	if (!ctx.cr6.eq) goto loc_8B0C8264;
loc_8B0C82A8:
	// addi r1,r1,96
	ctx.r1.s64 = ctx.r1.s64 + 96;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0C8588) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9bc
	ctx.lr = 0x8B0C8590;
	__savegprlr_29(ctx, base);
	// stwu r1,-112(r1)
	ea = -112 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// mr r29,r4
	ctx.r29.u64 = ctx.r4.u64;
	// mr r30,r5
	ctx.r30.u64 = ctx.r5.u64;
	// cmpwi cr6,r5,0
	ctx.cr6.compare<int32_t>(ctx.r5.s32, 0, ctx.xer);
	// beq cr6,0x8b0c85f0
	if (ctx.cr6.eq) goto loc_8B0C85F0;
	// mr r4,r5
	ctx.r4.u64 = ctx.r5.u64;
	// bl 0x8b0c7d98
	ctx.lr = 0x8B0C85B0;
	sub_8B0C7D98(ctx, base);
	// clrlwi r11,r3,24
	ctx.r11.u64 = ctx.r3.u32 & 0xFF;
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// beq cr6,0x8b0c85f0
	if (ctx.cr6.eq) goto loc_8B0C85F0;
	// lwz r11,0(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 0);
	// mr r5,r30
	ctx.r5.u64 = ctx.r30.u64;
	// lwz r9,32(r31)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r31.u32 + 32);
	// mr r4,r29
	ctx.r4.u64 = ctx.r29.u64;
	// lwz r10,16(r31)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r31.u32 + 16);
	// subf r11,r9,r11
	ctx.r11.u64 = ctx.r11.u64 - ctx.r9.u64;
	// add r3,r11,r10
	ctx.r3.u64 = ctx.r11.u64 + ctx.r10.u64;
	// bl 0x8b0cbb30
	ctx.lr = 0x8B0C85DC;
	sub_8B0CBB30(ctx, base);
	// lwz r11,16(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 16);
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// add r8,r30,r11
	ctx.r8.u64 = ctx.r30.u64 + ctx.r11.u64;
	// stw r8,16(r31)
	REX_STORE_U32(ctx.r31.u32 + 16, ctx.r8.u32);
	// bl 0x8b0c7e48
	ctx.lr = 0x8B0C85F0;
	sub_8B0C7E48(ctx, base);
loc_8B0C85F0:
	// addi r1,r1,112
	ctx.r1.s64 = ctx.r1.s64 + 112;
	// b 0x8b0cba0c
	__restgprlr_29(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0C86A8) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// std r30,-24(r1)
	REX_STORE_U64(ctx.r1.u32 + -24, ctx.r30.u64);
	// std r31,-16(r1)
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.r31.u64);
	// stwu r1,-112(r1)
	ea = -112 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lwz r31,16(r3)
	ctx.r31.u64 = REX_LOAD_U32(ctx.r3.u32 + 16);
	// mr r30,r3
	ctx.r30.u64 = ctx.r3.u64;
	// cmplwi cr6,r4,1
	ctx.cr6.compare<uint32_t>(ctx.r4.u32, 1, ctx.xer);
	// blt cr6,0x8b0c86ec
	if (ctx.cr6.lt) goto loc_8B0C86EC;
	// beq cr6,0x8b0c86e4
	if (ctx.cr6.eq) goto loc_8B0C86E4;
	// cmplwi cr6,r4,3
	ctx.cr6.compare<uint32_t>(ctx.r4.u32, 3, ctx.xer);
	// bge cr6,0x8b0c86f0
	if (!ctx.cr6.lt) goto loc_8B0C86F0;
	// lwz r11,28(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 28);
	// subf r31,r5,r11
	ctx.r31.u64 = ctx.r11.u64 - ctx.r5.u64;
	// b 0x8b0c86f0
	goto loc_8B0C86F0;
loc_8B0C86E4:
	// add r31,r31,r5
	ctx.r31.u64 = ctx.r31.u64 + ctx.r5.u64;
	// b 0x8b0c86f0
	goto loc_8B0C86F0;
loc_8B0C86EC:
	// mr r31,r5
	ctx.r31.u64 = ctx.r5.u64;
loc_8B0C86F0:
	// lwz r11,40(r30)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r30.u32 + 40);
	// subfic r4,r31,-1
	ctx.xer.ca = ctx.r31.u32 <= 4294967295;
	ctx.r4.u64 = static_cast<uint64_t>(-1) - ctx.r31.u64;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// mtctr r11
	ctx.ctr.u64 = ctx.r11.u64;
	// bctrl 
	ctx.lr = 0x8B0C8704;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// stw r31,16(r30)
	REX_STORE_U32(ctx.r30.u32 + 16, ctx.r31.u32);
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// bl 0x8b0c7e48
	ctx.lr = 0x8B0C8710;
	sub_8B0C7E48(ctx, base);
	// addi r1,r1,112
	ctx.r1.s64 = ctx.r1.s64 + 112;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// ld r30,-24(r1)
	ctx.r30.u64 = REX_LOAD_U64(ctx.r1.u32 + -24);
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0C8968) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9b4
	ctx.lr = 0x8B0C8970;
	__savegprlr_27(ctx, base);
	// stwu r1,-128(r1)
	ea = -128 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// mr r30,r4
	ctx.r30.u64 = ctx.r4.u64;
	// mr r29,r5
	ctx.r29.u64 = ctx.r5.u64;
	// mr r28,r6
	ctx.r28.u64 = ctx.r6.u64;
	// mr r27,r7
	ctx.r27.u64 = ctx.r7.u64;
	// bl 0x8b0906a8
	ctx.lr = 0x8B0C898C;
	sub_8B0906A8(ctx, base);
	// li r11,0
	ctx.r11.s64 = 0;
	// stw r30,0(r31)
	REX_STORE_U32(ctx.r31.u32 + 0, ctx.r30.u32);
	// li r10,-1
	ctx.r10.s64 = -1;
	// stw r29,4(r31)
	REX_STORE_U32(ctx.r31.u32 + 4, ctx.r29.u32);
	// stw r11,12(r31)
	REX_STORE_U32(ctx.r31.u32 + 12, ctx.r11.u32);
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// stw r10,8(r31)
	REX_STORE_U32(ctx.r31.u32 + 8, ctx.r10.u32);
	// stw r28,16(r31)
	REX_STORE_U32(ctx.r31.u32 + 16, ctx.r28.u32);
	// stw r11,24(r31)
	REX_STORE_U32(ctx.r31.u32 + 24, ctx.r11.u32);
	// stb r11,20(r31)
	REX_STORE_U8(ctx.r31.u32 + 20, ctx.r11.u8);
	// stw r11,32(r31)
	REX_STORE_U32(ctx.r31.u32 + 32, ctx.r11.u32);
	// stb r27,21(r31)
	REX_STORE_U8(ctx.r31.u32 + 21, ctx.r27.u8);
	// stw r10,28(r31)
	REX_STORE_U32(ctx.r31.u32 + 28, ctx.r10.u32);
	// bl 0x8b0c7e48
	ctx.lr = 0x8B0C89C4;
	sub_8B0C7E48(ctx, base);
	// addi r1,r1,128
	ctx.r1.s64 = ctx.r1.s64 + 128;
	// b 0x8b0cba04
	__restgprlr_27(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0C8BD0) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// std r31,-16(r1)
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.r31.u64);
	// stwu r1,-96(r1)
	ea = -96 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lbz r11,21(r3)
	ctx.r11.u64 = REX_LOAD_U8(ctx.r3.u32 + 21);
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// clrlwi r10,r11,31
	ctx.r10.u64 = ctx.r11.u32 & 0x1;
	// cmplwi cr6,r10,0
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 0, ctx.xer);
	// beq cr6,0x8b0c8c84
	if (ctx.cr6.eq) goto loc_8B0C8C84;
	// lbz r11,20(r3)
	ctx.r11.u64 = REX_LOAD_U8(ctx.r3.u32 + 20);
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// bne cr6,0x8b0c8c84
	if (!ctx.cr6.eq) goto loc_8B0C8C84;
	// li r5,0
	ctx.r5.s64 = 0;
	// li r4,2
	ctx.r4.s64 = 2;
	// bl 0x8b0c7c68
	ctx.lr = 0x8B0C8C0C;
	sub_8B0C7C68(ctx, base);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0c8c84
	if (ctx.cr6.eq) goto loc_8B0C8C84;
	// lbz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U8(ctx.r3.u32 + 0);
	// cmplwi cr6,r11,47
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 47, ctx.xer);
	// bne cr6,0x8b0c8c84
	if (!ctx.cr6.eq) goto loc_8B0C8C84;
	// lbz r11,1(r3)
	ctx.r11.u64 = REX_LOAD_U8(ctx.r3.u32 + 1);
	// cmplwi cr6,r11,47
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 47, ctx.xer);
	// bne cr6,0x8b0c8c84
	if (!ctx.cr6.eq) goto loc_8B0C8C84;
	// lwz r11,12(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 12);
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// addi r11,r11,2
	ctx.r11.s64 = ctx.r11.s64 + 2;
	// stw r11,12(r31)
	REX_STORE_U32(ctx.r31.u32 + 12, ctx.r11.u32);
	// bl 0x8b0c25a8
	ctx.lr = 0x8B0C8C40;
	sub_8B0C25A8(ctx, base);
	// lbz r10,20(r31)
	ctx.r10.u64 = REX_LOAD_U8(ctx.r31.u32 + 20);
	// cmplwi cr6,r10,0
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 0, ctx.xer);
	// bne cr6,0x8b0c8c6c
	if (!ctx.cr6.eq) goto loc_8B0C8C6C;
loc_8B0C8C4C:
	// extsb r11,r3
	ctx.r11.s64 = ctx.r3.s8;
	// cmpwi cr6,r11,10
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 10, ctx.xer);
	// beq cr6,0x8b0c8c6c
	if (ctx.cr6.eq) goto loc_8B0C8C6C;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0c25a8
	ctx.lr = 0x8B0C8C60;
	sub_8B0C25A8(ctx, base);
	// lbz r11,20(r31)
	ctx.r11.u64 = REX_LOAD_U8(ctx.r31.u32 + 20);
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// beq cr6,0x8b0c8c4c
	if (ctx.cr6.eq) goto loc_8B0C8C4C;
loc_8B0C8C6C:
	// li r3,1
	ctx.r3.s64 = 1;
	// addi r1,r1,96
	ctx.r1.s64 = ctx.r1.s64 + 96;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
loc_8B0C8C84:
	// li r3,0
	ctx.r3.s64 = 0;
	// addi r1,r1,96
	ctx.r1.s64 = ctx.r1.s64 + 96;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0C9130) {
	REX_FUNC_PROLOGUE();
	PPCRegister temp{};
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9ac
	ctx.lr = 0x8B0C9138;
	__savegprlr_25(ctx, base);
	// stwu r1,-160(r1)
	ea = -160 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lbz r11,20(r3)
	ctx.r11.u64 = REX_LOAD_U8(ctx.r3.u32 + 20);
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// mr r29,r5
	ctx.r29.u64 = ctx.r5.u64;
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// bne cr6,0x8b0c959c
	if (!ctx.cr6.eq) goto loc_8B0C959C;
	// lbz r11,21(r3)
	ctx.r11.u64 = REX_LOAD_U8(ctx.r3.u32 + 21);
	// clrlwi r10,r11,31
	ctx.r10.u64 = ctx.r11.u32 & 0x1;
	// cmplwi cr6,r10,0
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 0, ctx.xer);
	// beq cr6,0x8b0c959c
	if (ctx.cr6.eq) goto loc_8B0C959C;
	// lbz r11,0(r4)
	ctx.r11.u64 = REX_LOAD_U8(ctx.r4.u32 + 0);
	// li r25,0
	ctx.r25.s64 = 0;
	// extsb r30,r11
	ctx.r30.s64 = ctx.r11.s8;
	// mr r26,r25
	ctx.r26.u64 = ctx.r25.u64;
	// cmpwi cr6,r30,0
	ctx.cr6.compare<int32_t>(ctx.r30.s32, 0, ctx.xer);
	// beq cr6,0x8b0c9558
	if (ctx.cr6.eq) goto loc_8B0C9558;
	// addi r27,r4,-1
	ctx.r27.s64 = ctx.r4.s64 + -1;
	// li r28,128
	ctx.r28.s64 = 128;
loc_8B0C9180:
	// lwz r11,12(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 12);
	// addi r27,r27,1
	ctx.r27.s64 = ctx.r27.s64 + 1;
	// lwz r10,28(r31)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r31.u32 + 28);
	// cmpw cr6,r11,r10
	ctx.cr6.compare<int32_t>(ctx.r11.s32, ctx.r10.s32, ctx.xer);
	// bge cr6,0x8b0c954c
	if (!ctx.cr6.lt) goto loc_8B0C954C;
	// cmpwi cr6,r30,32
	ctx.cr6.compare<int32_t>(ctx.r30.s32, 32, ctx.xer);
	// beq cr6,0x8b0c9528
	if (ctx.cr6.eq) goto loc_8B0C9528;
	// cmpwi cr6,r30,37
	ctx.cr6.compare<int32_t>(ctx.r30.s32, 37, ctx.xer);
	// beq cr6,0x8b0c9210
	if (ctx.cr6.eq) goto loc_8B0C9210;
	// lbz r11,20(r31)
	ctx.r11.u64 = REX_LOAD_U8(ctx.r31.u32 + 20);
	// rlwinm r10,r11,0,30,30
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 0) & 0x2;
	// cmplwi cr6,r10,0
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 0, ctx.xer);
	// beq cr6,0x8b0c91bc
	if (ctx.cr6.eq) goto loc_8B0C91BC;
	// mr r3,r25
	ctx.r3.u64 = ctx.r25.u64;
	// b 0x8b0c91d8
	goto loc_8B0C91D8;
loc_8B0C91BC:
	// li r4,1
	ctx.r4.s64 = 1;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0c7a58
	ctx.lr = 0x8B0C91C8;
	sub_8B0C7A58(ctx, base);
	// lbz r11,20(r31)
	ctx.r11.u64 = REX_LOAD_U8(ctx.r31.u32 + 20);
	// clrlwi r10,r11,24
	ctx.r10.u64 = ctx.r11.u32 & 0xFF;
	// rlwinm r10,r10,0,31,29
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r10.u32 | (ctx.r10.u64 << 32), 0) & 0xFFFFFFFFFFFFFFFD;
	// stb r10,20(r31)
	REX_STORE_U8(ctx.r31.u32 + 20, ctx.r10.u8);
loc_8B0C91D8:
	// clrlwi r11,r3,24
	ctx.r11.u64 = ctx.r3.u32 & 0xFF;
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// beq cr6,0x8b0c9558
	if (ctx.cr6.eq) goto loc_8B0C9558;
	// lwz r11,12(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 12);
	// lwz r10,32(r31)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r31.u32 + 32);
	// lwz r9,0(r31)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r31.u32 + 0);
	// subf r8,r10,r11
	ctx.r8.u64 = ctx.r11.u64 - ctx.r10.u64;
	// lbzx r7,r8,r9
	ctx.r7.u64 = REX_LOAD_U8(ctx.r8.u32 + ctx.r9.u32);
	// extsb r6,r7
	ctx.r6.s64 = ctx.r7.s8;
	// cmpw cr6,r30,r6
	ctx.cr6.compare<int32_t>(ctx.r30.s32, ctx.r6.s32, ctx.xer);
	// bne cr6,0x8b0c9558
	if (!ctx.cr6.eq) goto loc_8B0C9558;
	// addi r11,r11,1
	ctx.r11.s64 = ctx.r11.s64 + 1;
	// stw r11,12(r31)
	REX_STORE_U32(ctx.r31.u32 + 12, ctx.r11.u32);
	// b 0x8b0c9530
	goto loc_8B0C9530;
loc_8B0C9210:
	// lbzu r11,1(r27)
	ea = 1 + ctx.r27.u32;
	ctx.r11.u64 = REX_LOAD_U8(ea);
	ctx.r27.u32 = ea;
	// extsb r11,r11
	ctx.r11.s64 = ctx.r11.s8;
	// cmpwi cr6,r11,0
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// beq cr6,0x8b0c9558
	if (ctx.cr6.eq) goto loc_8B0C9558;
	// addi r11,r11,-99
	ctx.r11.s64 = ctx.r11.s64 + -99;
	// cmplwi cr6,r11,21
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 21, ctx.xer);
	// bgt cr6,0x8b0c9558
	if (ctx.cr6.gt) goto loc_8B0C9558;
	// lis r12,-29939
	ctx.r12.s64 = -1962082304;
	// rlwinm r0,r11,2,0,29
	ctx.r0.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 2) & 0xFFFFFFFC;
	// addi r12,r12,-28092
	ctx.r12.s64 = ctx.r12.s64 + -28092;
	// lwzx r0,r12,r0
	ctx.r0.u64 = REX_LOAD_U32(ctx.r12.u32 + ctx.r0.u32);
	// mtctr r0
	ctx.ctr.u64 = ctx.r0.u64;
	// bctr 
	switch (ctx.r11.u32) {
	case 0:
		goto loc_8B0C929C;
	case 1:
		goto loc_8B0C92F4;
	case 2:
		goto loc_8B0C9558;
	case 3:
		goto loc_8B0C9480;
	case 4:
		goto loc_8B0C9558;
	case 5:
		goto loc_8B0C9558;
	case 6:
		goto loc_8B0C92F4;
	case 7:
		goto loc_8B0C9558;
	case 8:
		goto loc_8B0C9558;
	case 9:
		goto loc_8B0C9558;
	case 10:
		goto loc_8B0C9558;
	case 11:
		goto loc_8B0C9558;
	case 12:
		goto loc_8B0C9558;
	case 13:
		goto loc_8B0C9558;
	case 14:
		goto loc_8B0C9558;
	case 15:
		goto loc_8B0C9558;
	case 16:
		goto loc_8B0C9504;
	case 17:
		goto loc_8B0C9558;
	case 18:
		goto loc_8B0C93FC;
	case 19:
		goto loc_8B0C9558;
	case 20:
		goto loc_8B0C9558;
	case 21:
		goto loc_8B0C9378;
	default:
		__builtin_trap(); // Switch case out of range
	}
loc_8B0C929C:
	// addi r11,r29,7
	ctx.r11.s64 = ctx.r29.s64 + 7;
	// li r5,1
	ctx.r5.s64 = 1;
	// rlwinm r11,r11,0,0,28
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 0) & 0xFFFFFFF8;
	// li r4,0
	ctx.r4.s64 = 0;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// addi r29,r11,8
	ctx.r29.s64 = ctx.r11.s64 + 8;
	// lwz r30,4(r11)
	ctx.r30.u64 = REX_LOAD_U32(ctx.r11.u32 + 4);
	// bl 0x8b0c7b48
	ctx.lr = 0x8B0C92BC;
	sub_8B0C7B48(ctx, base);
	// clrlwi r10,r3,24
	ctx.r10.u64 = ctx.r3.u32 & 0xFF;
	// cmplwi cr6,r10,0
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 0, ctx.xer);
	// beq cr6,0x8b0c9564
	if (ctx.cr6.eq) goto loc_8B0C9564;
	// lwz r11,12(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 12);
	// addi r26,r26,1
	ctx.r26.s64 = ctx.r26.s64 + 1;
	// lwz r10,32(r31)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r31.u32 + 32);
	// lwz r9,0(r31)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r31.u32 + 0);
	// subf r8,r10,r11
	ctx.r8.u64 = ctx.r11.u64 - ctx.r10.u64;
	// lbzx r7,r8,r9
	ctx.r7.u64 = REX_LOAD_U8(ctx.r8.u32 + ctx.r9.u32);
	// stb r7,0(r30)
	REX_STORE_U8(ctx.r30.u32 + 0, ctx.r7.u8);
	// lwz r11,12(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 12);
	// addi r6,r11,1
	ctx.r6.s64 = ctx.r11.s64 + 1;
	// stw r6,12(r31)
	REX_STORE_U32(ctx.r31.u32 + 12, ctx.r6.u32);
	// b 0x8b0c9530
	goto loc_8B0C9530;
loc_8B0C92F4:
	// stw r28,80(r1)
	REX_STORE_U32(ctx.r1.u32 + 80, ctx.r28.u32);
	// addi r11,r29,7
	ctx.r11.s64 = ctx.r29.s64 + 7;
	// addi r5,r1,80
	ctx.r5.s64 = ctx.r1.s64 + 80;
	// rlwinm r11,r11,0,0,28
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 0) & 0xFFFFFFF8;
	// li r4,0
	ctx.r4.s64 = 0;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// addi r29,r11,8
	ctx.r29.s64 = ctx.r11.s64 + 8;
	// lwz r30,4(r11)
	ctx.r30.u64 = REX_LOAD_U32(ctx.r11.u32 + 4);
	// bl 0x8b0c7bb8
	ctx.lr = 0x8B0C9318;
	sub_8B0C7BB8(ctx, base);
	// clrlwi r10,r3,24
	ctx.r10.u64 = ctx.r3.u32 & 0xFF;
	// cmplwi cr6,r10,0
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 0, ctx.xer);
	// beq cr6,0x8b0c9574
	if (ctx.cr6.eq) goto loc_8B0C9574;
	// lwz r10,12(r31)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r31.u32 + 12);
	// li r5,10
	ctx.r5.s64 = 10;
	// lwz r9,32(r31)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r31.u32 + 32);
	// addi r4,r1,84
	ctx.r4.s64 = ctx.r1.s64 + 84;
	// lwz r11,0(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 0);
	// subf r10,r9,r10
	ctx.r10.u64 = ctx.r10.u64 - ctx.r9.u64;
	// add r3,r10,r11
	ctx.r3.u64 = ctx.r10.u64 + ctx.r11.u64;
	// bl 0x8b0ce798
	ctx.lr = 0x8B0C9344;
	sub_8B0CE798(ctx, base);
	// stw r3,0(r30)
	REX_STORE_U32(ctx.r30.u32 + 0, ctx.r3.u32);
	// lwz r8,0(r31)
	ctx.r8.u64 = REX_LOAD_U32(ctx.r31.u32 + 0);
	// lwz r10,84(r1)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r1.u32 + 84);
	// lwz r11,12(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 12);
	// lwz r7,32(r31)
	ctx.r7.u64 = REX_LOAD_U32(ctx.r31.u32 + 32);
	// subf r6,r11,r7
	ctx.r6.u64 = ctx.r7.u64 - ctx.r11.u64;
	// subf r9,r8,r6
	ctx.r9.u64 = ctx.r6.u64 - ctx.r8.u64;
	// add. r10,r9,r10
	ctx.r10.u64 = ctx.r9.u64 + ctx.r10.u64;
	ctx.cr0.compare<int32_t>(ctx.r10.s32, 0, ctx.xer);
	// beq 0x8b0c9558
	if (ctx.cr0.eq) goto loc_8B0C9558;
	// add r11,r11,r10
	ctx.r11.u64 = ctx.r11.u64 + ctx.r10.u64;
	// addi r26,r26,1
	ctx.r26.s64 = ctx.r26.s64 + 1;
	// stw r11,12(r31)
	REX_STORE_U32(ctx.r31.u32 + 12, ctx.r11.u32);
	// b 0x8b0c9530
	goto loc_8B0C9530;
loc_8B0C9378:
	// stw r28,80(r1)
	REX_STORE_U32(ctx.r1.u32 + 80, ctx.r28.u32);
	// addi r11,r29,7
	ctx.r11.s64 = ctx.r29.s64 + 7;
	// addi r5,r1,80
	ctx.r5.s64 = ctx.r1.s64 + 80;
	// rlwinm r11,r11,0,0,28
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 0) & 0xFFFFFFF8;
	// li r4,0
	ctx.r4.s64 = 0;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// addi r29,r11,8
	ctx.r29.s64 = ctx.r11.s64 + 8;
	// lwz r30,4(r11)
	ctx.r30.u64 = REX_LOAD_U32(ctx.r11.u32 + 4);
	// bl 0x8b0c7bb8
	ctx.lr = 0x8B0C939C;
	sub_8B0C7BB8(ctx, base);
	// clrlwi r10,r3,24
	ctx.r10.u64 = ctx.r3.u32 & 0xFF;
	// cmplwi cr6,r10,0
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 0, ctx.xer);
	// beq cr6,0x8b0c9574
	if (ctx.cr6.eq) goto loc_8B0C9574;
	// lwz r11,12(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 12);
	// li r5,16
	ctx.r5.s64 = 16;
	// lwz r9,32(r31)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r31.u32 + 32);
	// addi r4,r1,84
	ctx.r4.s64 = ctx.r1.s64 + 84;
	// lwz r10,0(r31)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r31.u32 + 0);
	// subf r11,r9,r11
	ctx.r11.u64 = ctx.r11.u64 - ctx.r9.u64;
	// add r3,r11,r10
	ctx.r3.u64 = ctx.r11.u64 + ctx.r10.u64;
	// bl 0x8b0ce798
	ctx.lr = 0x8B0C93C8;
	sub_8B0CE798(ctx, base);
	// stw r3,0(r30)
	REX_STORE_U32(ctx.r30.u32 + 0, ctx.r3.u32);
	// lwz r9,84(r1)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r1.u32 + 84);
	// lwz r11,12(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 12);
	// lwz r7,32(r31)
	ctx.r7.u64 = REX_LOAD_U32(ctx.r31.u32 + 32);
	// subf r6,r11,r7
	ctx.r6.u64 = ctx.r7.u64 - ctx.r11.u64;
	// lwz r8,0(r31)
	ctx.r8.u64 = REX_LOAD_U32(ctx.r31.u32 + 0);
	// subf r10,r8,r6
	ctx.r10.u64 = ctx.r6.u64 - ctx.r8.u64;
	// add. r10,r10,r9
	ctx.r10.u64 = ctx.r10.u64 + ctx.r9.u64;
	ctx.cr0.compare<int32_t>(ctx.r10.s32, 0, ctx.xer);
	// beq 0x8b0c9558
	if (ctx.cr0.eq) goto loc_8B0C9558;
	// add r11,r11,r10
	ctx.r11.u64 = ctx.r11.u64 + ctx.r10.u64;
	// addi r26,r26,1
	ctx.r26.s64 = ctx.r26.s64 + 1;
	// stw r11,12(r31)
	REX_STORE_U32(ctx.r31.u32 + 12, ctx.r11.u32);
	// b 0x8b0c9530
	goto loc_8B0C9530;
loc_8B0C93FC:
	// stw r28,80(r1)
	REX_STORE_U32(ctx.r1.u32 + 80, ctx.r28.u32);
	// addi r11,r29,7
	ctx.r11.s64 = ctx.r29.s64 + 7;
	// addi r5,r1,80
	ctx.r5.s64 = ctx.r1.s64 + 80;
	// rlwinm r11,r11,0,0,28
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 0) & 0xFFFFFFF8;
	// li r4,0
	ctx.r4.s64 = 0;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// addi r29,r11,8
	ctx.r29.s64 = ctx.r11.s64 + 8;
	// lwz r30,4(r11)
	ctx.r30.u64 = REX_LOAD_U32(ctx.r11.u32 + 4);
	// bl 0x8b0c7bb8
	ctx.lr = 0x8B0C9420;
	sub_8B0C7BB8(ctx, base);
	// clrlwi r10,r3,24
	ctx.r10.u64 = ctx.r3.u32 & 0xFF;
	// cmplwi cr6,r10,0
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 0, ctx.xer);
	// beq cr6,0x8b0c9574
	if (ctx.cr6.eq) goto loc_8B0C9574;
	// lwz r11,12(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 12);
	// li r5,10
	ctx.r5.s64 = 10;
	// lwz r9,32(r31)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r31.u32 + 32);
	// addi r4,r1,84
	ctx.r4.s64 = ctx.r1.s64 + 84;
	// lwz r10,0(r31)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r31.u32 + 0);
	// subf r11,r9,r11
	ctx.r11.u64 = ctx.r11.u64 - ctx.r9.u64;
	// add r3,r11,r10
	ctx.r3.u64 = ctx.r11.u64 + ctx.r10.u64;
	// bl 0x8b0ce7a0
	ctx.lr = 0x8B0C944C;
	sub_8B0CE7A0(ctx, base);
	// stw r3,0(r30)
	REX_STORE_U32(ctx.r30.u32 + 0, ctx.r3.u32);
	// lwz r9,84(r1)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r1.u32 + 84);
	// lwz r11,12(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 12);
	// lwz r8,32(r31)
	ctx.r8.u64 = REX_LOAD_U32(ctx.r31.u32 + 32);
	// lwz r7,0(r31)
	ctx.r7.u64 = REX_LOAD_U32(ctx.r31.u32 + 0);
	// subf r6,r11,r8
	ctx.r6.u64 = ctx.r8.u64 - ctx.r11.u64;
	// subf r10,r7,r6
	ctx.r10.u64 = ctx.r6.u64 - ctx.r7.u64;
	// add. r10,r10,r9
	ctx.r10.u64 = ctx.r10.u64 + ctx.r9.u64;
	ctx.cr0.compare<int32_t>(ctx.r10.s32, 0, ctx.xer);
	// beq 0x8b0c9558
	if (ctx.cr0.eq) goto loc_8B0C9558;
	// add r11,r11,r10
	ctx.r11.u64 = ctx.r11.u64 + ctx.r10.u64;
	// addi r26,r26,1
	ctx.r26.s64 = ctx.r26.s64 + 1;
	// stw r11,12(r31)
	REX_STORE_U32(ctx.r31.u32 + 12, ctx.r11.u32);
	// b 0x8b0c9530
	goto loc_8B0C9530;
loc_8B0C9480:
	// stw r28,80(r1)
	REX_STORE_U32(ctx.r1.u32 + 80, ctx.r28.u32);
	// addi r11,r29,7
	ctx.r11.s64 = ctx.r29.s64 + 7;
	// addi r5,r1,80
	ctx.r5.s64 = ctx.r1.s64 + 80;
	// rlwinm r11,r11,0,0,28
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 0) & 0xFFFFFFF8;
	// li r4,0
	ctx.r4.s64 = 0;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// addi r29,r11,8
	ctx.r29.s64 = ctx.r11.s64 + 8;
	// lwz r30,4(r11)
	ctx.r30.u64 = REX_LOAD_U32(ctx.r11.u32 + 4);
	// bl 0x8b0c7bb8
	ctx.lr = 0x8B0C94A4;
	sub_8B0C7BB8(ctx, base);
	// clrlwi r10,r3,24
	ctx.r10.u64 = ctx.r3.u32 & 0xFF;
	// cmplwi cr6,r10,0
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 0, ctx.xer);
	// beq cr6,0x8b0c9584
	if (ctx.cr6.eq) goto loc_8B0C9584;
	// lwz r11,12(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 12);
	// addi r4,r1,84
	ctx.r4.s64 = ctx.r1.s64 + 84;
	// lwz r9,32(r31)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r31.u32 + 32);
	// lwz r10,0(r31)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r31.u32 + 0);
	// subf r11,r9,r11
	ctx.r11.u64 = ctx.r11.u64 - ctx.r9.u64;
	// add r3,r11,r10
	ctx.r3.u64 = ctx.r11.u64 + ctx.r10.u64;
	// bl 0x8b0ce4a0
	ctx.lr = 0x8B0C94CC;
	sub_8B0CE4A0(ctx, base);
	// frsp f0,f1
	ctx.fpscr.disableFlushMode();
	ctx.f0.f64 = double(float(ctx.f1.f64));
	// stfs f0,0(r30)
	temp.f32 = float(ctx.f0.f64);
	REX_STORE_U32(ctx.r30.u32 + 0, temp.u32);
	// lwz r9,84(r1)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r1.u32 + 84);
	// lwz r11,12(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 12);
	// lwz r8,32(r31)
	ctx.r8.u64 = REX_LOAD_U32(ctx.r31.u32 + 32);
	// lwz r7,0(r31)
	ctx.r7.u64 = REX_LOAD_U32(ctx.r31.u32 + 0);
	// subf r6,r11,r8
	ctx.r6.u64 = ctx.r8.u64 - ctx.r11.u64;
	// subf r10,r7,r6
	ctx.r10.u64 = ctx.r6.u64 - ctx.r7.u64;
	// add. r10,r10,r9
	ctx.r10.u64 = ctx.r10.u64 + ctx.r9.u64;
	ctx.cr0.compare<int32_t>(ctx.r10.s32, 0, ctx.xer);
	// beq 0x8b0c9558
	if (ctx.cr0.eq) goto loc_8B0C9558;
	// add r11,r11,r10
	ctx.r11.u64 = ctx.r11.u64 + ctx.r10.u64;
	// addi r26,r26,1
	ctx.r26.s64 = ctx.r26.s64 + 1;
	// stw r11,12(r31)
	REX_STORE_U32(ctx.r31.u32 + 12, ctx.r11.u32);
	// b 0x8b0c9530
	goto loc_8B0C9530;
loc_8B0C9504:
	// addi r11,r29,7
	ctx.r11.s64 = ctx.r29.s64 + 7;
	// li r5,0
	ctx.r5.s64 = 0;
	// rlwinm r11,r11,0,0,28
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 0) & 0xFFFFFFF8;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// addi r29,r11,8
	ctx.r29.s64 = ctx.r11.s64 + 8;
	// lwz r4,4(r11)
	ctx.r4.u64 = REX_LOAD_U32(ctx.r11.u32 + 4);
	// bl 0x8b0c8ca0
	ctx.lr = 0x8B0C9520;
	sub_8B0C8CA0(ctx, base);
	// addi r26,r26,1
	ctx.r26.s64 = ctx.r26.s64 + 1;
	// b 0x8b0c9530
	goto loc_8B0C9530;
loc_8B0C9528:
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0c8220
	ctx.lr = 0x8B0C9530;
	sub_8B0C8220(ctx, base);
loc_8B0C9530:
	// lbz r11,1(r27)
	ctx.r11.u64 = REX_LOAD_U8(ctx.r27.u32 + 1);
	// extsb r30,r11
	ctx.r30.s64 = ctx.r11.s8;
	// cmpwi cr6,r30,0
	ctx.cr6.compare<int32_t>(ctx.r30.s32, 0, ctx.xer);
	// bne cr6,0x8b0c9180
	if (!ctx.cr6.eq) goto loc_8B0C9180;
	// mr r3,r26
	ctx.r3.u64 = ctx.r26.u64;
	// addi r1,r1,160
	ctx.r1.s64 = ctx.r1.s64 + 160;
	// b 0x8b0cb9fc
	__restgprlr_25(ctx, base);
	return;
loc_8B0C954C:
	// lbz r11,20(r31)
	ctx.r11.u64 = REX_LOAD_U8(ctx.r31.u32 + 20);
	// ori r10,r11,2
	ctx.r10.u64 = ctx.r11.u64 | 2;
	// stb r10,20(r31)
	REX_STORE_U8(ctx.r31.u32 + 20, ctx.r10.u8);
loc_8B0C9558:
	// mr r3,r26
	ctx.r3.u64 = ctx.r26.u64;
	// addi r1,r1,160
	ctx.r1.s64 = ctx.r1.s64 + 160;
	// b 0x8b0cb9fc
	__restgprlr_25(ctx, base);
	return;
loc_8B0C9564:
	// mr r3,r26
	ctx.r3.u64 = ctx.r26.u64;
	// stb r25,0(r30)
	REX_STORE_U8(ctx.r30.u32 + 0, ctx.r25.u8);
	// addi r1,r1,160
	ctx.r1.s64 = ctx.r1.s64 + 160;
	// b 0x8b0cb9fc
	__restgprlr_25(ctx, base);
	return;
loc_8B0C9574:
	// mr r3,r26
	ctx.r3.u64 = ctx.r26.u64;
	// stw r25,0(r30)
	REX_STORE_U32(ctx.r30.u32 + 0, ctx.r25.u32);
	// addi r1,r1,160
	ctx.r1.s64 = ctx.r1.s64 + 160;
	// b 0x8b0cb9fc
	__restgprlr_25(ctx, base);
	return;
loc_8B0C9584:
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// mr r3,r26
	ctx.r3.u64 = ctx.r26.u64;
	// lfs f0,8492(r11)
	ctx.fpscr.disableFlushMode();
	temp.u32 = REX_LOAD_U32(ctx.r11.u32 + 8492);
	ctx.f0.f64 = double(temp.f32);
	// stfs f0,0(r30)
	temp.f32 = float(ctx.f0.f64);
	REX_STORE_U32(ctx.r30.u32 + 0, temp.u32);
	// addi r1,r1,160
	ctx.r1.s64 = ctx.r1.s64 + 160;
	// b 0x8b0cb9fc
	__restgprlr_25(ctx, base);
	return;
loc_8B0C959C:
	// li r3,0
	ctx.r3.s64 = 0;
	// addi r1,r1,160
	ctx.r1.s64 = ctx.r1.s64 + 160;
	// b 0x8b0cb9fc
	__restgprlr_25(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0CA5F8) {
	REX_FUNC_PROLOGUE();
	PPCRegister temp{};
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9bc
	ctx.lr = 0x8B0CA600;
	__savegprlr_29(ctx, base);
	// stwu r1,-112(r1)
	ea = -112 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lbz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U8(ctx.r3.u32 + 0);
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// cmplwi cr6,r11,36
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 36, ctx.xer);
	// bne cr6,0x8b0ca618
	if (!ctx.cr6.eq) goto loc_8B0CA618;
	// addi r31,r31,1
	ctx.r31.s64 = ctx.r31.s64 + 1;
loc_8B0CA618:
	// lis r11,-29943
	ctx.r11.s64 = -1962344448;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// addi r4,r11,-25432
	ctx.r4.s64 = ctx.r11.s64 + -25432;
	// bl 0x8b0cea10
	ctx.lr = 0x8B0CA628;
	sub_8B0CEA10(ctx, base);
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// beq cr6,0x8b0ca914
	if (ctx.cr6.eq) goto loc_8B0CA914;
	// lis r11,-29943
	ctx.r11.s64 = -1962344448;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// addi r4,r11,-25440
	ctx.r4.s64 = ctx.r11.s64 + -25440;
	// bl 0x8b0cea10
	ctx.lr = 0x8B0CA640;
	sub_8B0CEA10(ctx, base);
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// bne cr6,0x8b0ca654
	if (!ctx.cr6.eq) goto loc_8B0CA654;
	// li r3,1
	ctx.r3.s64 = 1;
	// addi r1,r1,112
	ctx.r1.s64 = ctx.r1.s64 + 112;
	// b 0x8b0cba0c
	__restgprlr_29(ctx, base);
	return;
loc_8B0CA654:
	// lis r11,-29943
	ctx.r11.s64 = -1962344448;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// addi r4,r11,-25448
	ctx.r4.s64 = ctx.r11.s64 + -25448;
	// bl 0x8b0cea10
	ctx.lr = 0x8B0CA664;
	sub_8B0CEA10(ctx, base);
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// beq cr6,0x8b0ca914
	if (ctx.cr6.eq) goto loc_8B0CA914;
	// lis r11,-29943
	ctx.r11.s64 = -1962344448;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// addi r4,r11,-25460
	ctx.r4.s64 = ctx.r11.s64 + -25460;
	// bl 0x8b0cea10
	ctx.lr = 0x8B0CA67C;
	sub_8B0CEA10(ctx, base);
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// beq cr6,0x8b0ca914
	if (ctx.cr6.eq) goto loc_8B0CA914;
	// lis r11,-29943
	ctx.r11.s64 = -1962344448;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// addi r29,r11,-25472
	ctx.r29.s64 = ctx.r11.s64 + -25472;
	// mr r4,r29
	ctx.r4.u64 = ctx.r29.u64;
	// bl 0x8b0cea10
	ctx.lr = 0x8B0CA698;
	sub_8B0CEA10(ctx, base);
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// beq cr6,0x8b0ca95c
	if (ctx.cr6.eq) goto loc_8B0CA95C;
	// lis r11,-29943
	ctx.r11.s64 = -1962344448;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// addi r4,r11,-25484
	ctx.r4.s64 = ctx.r11.s64 + -25484;
	// bl 0x8b0cea10
	ctx.lr = 0x8B0CA6B0;
	sub_8B0CEA10(ctx, base);
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// beq cr6,0x8b0ca95c
	if (ctx.cr6.eq) goto loc_8B0CA95C;
	// lis r11,-29943
	ctx.r11.s64 = -1962344448;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// addi r4,r11,-25496
	ctx.r4.s64 = ctx.r11.s64 + -25496;
	// bl 0x8b0cea10
	ctx.lr = 0x8B0CA6C8;
	sub_8B0CEA10(ctx, base);
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// bne cr6,0x8b0ca71c
	if (!ctx.cr6.eq) goto loc_8B0CA71C;
	// lis r10,-29936
	ctx.r10.s64 = -1961885696;
	// lis r11,-29936
	ctx.r11.s64 = -1961885696;
	// addi r31,r11,-17892
	ctx.r31.s64 = ctx.r11.s64 + -17892;
	// lwz r11,-17884(r10)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r10.u32 + -17884);
	// rlwinm r9,r11,0,30,30
	ctx.r9.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 0) & 0x2;
	// cmplwi cr6,r9,0
	ctx.cr6.compare<uint32_t>(ctx.r9.u32, 0, ctx.xer);
	// bne cr6,0x8b0ca704
	if (!ctx.cr6.eq) goto loc_8B0CA704;
	// ori r11,r11,2
	ctx.r11.u64 = ctx.r11.u64 | 2;
	// lis r9,-29943
	ctx.r9.s64 = -1962344448;
	// stw r11,-17884(r10)
	REX_STORE_U32(ctx.r10.u32 + -17884, ctx.r11.u32);
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// addi r4,r9,-25520
	ctx.r4.s64 = ctx.r9.s64 + -25520;
	// bl 0x8b0c6f58
	ctx.lr = 0x8B0CA704;
	sub_8B0C6F58(ctx, base);
loc_8B0CA704:
	// lwz r11,4(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 4);
	// lwz r11,48(r11)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r11.u32 + 48);
loc_8B0CA70C:
	// addic r10,r11,-1
	ctx.xer.ca = ctx.r11.u32 > 0;
	ctx.r10.s64 = ctx.r11.s64 + -1;
	// subfe r3,r10,r11
	temp.u8 = (~ctx.r10.u32 + ctx.r11.u32 < ~ctx.r10.u32) | (~ctx.r10.u32 + ctx.r11.u32 + ctx.xer.ca < ctx.xer.ca);
	ctx.r3.u64 = ~ctx.r10.u64 + ctx.r11.u64 + ctx.xer.ca;
	ctx.xer.ca = temp.u8;
	// addi r1,r1,112
	ctx.r1.s64 = ctx.r1.s64 + 112;
	// b 0x8b0cba0c
	__restgprlr_29(ctx, base);
	return;
loc_8B0CA71C:
	// lis r11,-29943
	ctx.r11.s64 = -1962344448;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// addi r4,r11,-25536
	ctx.r4.s64 = ctx.r11.s64 + -25536;
	// bl 0x8b0cea10
	ctx.lr = 0x8B0CA72C;
	sub_8B0CEA10(ctx, base);
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// bne cr6,0x8b0ca74c
	if (!ctx.cr6.eq) goto loc_8B0CA74C;
	// bl 0x8b0df2c8
	ctx.lr = 0x8B0CA738;
	sub_8B0DF2C8(ctx, base);
	// subfic r11,r3,1
	ctx.xer.ca = ctx.r3.u32 <= 1;
	ctx.r11.u64 = static_cast<uint64_t>(1) - ctx.r3.u64;
	// subfe r9,r10,r10
	temp.u8 = (~ctx.r10.u32 + ctx.r10.u32 < ~ctx.r10.u32) | (~ctx.r10.u32 + ctx.r10.u32 + ctx.xer.ca < ctx.xer.ca);
	ctx.r9.u64 = ~ctx.r10.u64 + ctx.r10.u64 + ctx.xer.ca;
	ctx.xer.ca = temp.u8;
	// clrlwi r3,r9,31
	ctx.r3.u64 = ctx.r9.u32 & 0x1;
	// addi r1,r1,112
	ctx.r1.s64 = ctx.r1.s64 + 112;
	// b 0x8b0cba0c
	__restgprlr_29(ctx, base);
	return;
loc_8B0CA74C:
	// lis r11,-29943
	ctx.r11.s64 = -1962344448;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// addi r4,r11,-25548
	ctx.r4.s64 = ctx.r11.s64 + -25548;
	// bl 0x8b0cea10
	ctx.lr = 0x8B0CA75C;
	sub_8B0CEA10(ctx, base);
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// bne cr6,0x8b0ca778
	if (!ctx.cr6.eq) goto loc_8B0CA778;
	// bl 0x8b0df338
	ctx.lr = 0x8B0CA768;
	sub_8B0DF338(ctx, base);
	// addic r11,r3,-1
	ctx.xer.ca = ctx.r3.u32 > 0;
	ctx.r11.s64 = ctx.r3.s64 + -1;
	// subfe r3,r11,r3
	temp.u8 = (~ctx.r11.u32 + ctx.r3.u32 < ~ctx.r11.u32) | (~ctx.r11.u32 + ctx.r3.u32 + ctx.xer.ca < ctx.xer.ca);
	ctx.r3.u64 = ~ctx.r11.u64 + ctx.r3.u64 + ctx.xer.ca;
	ctx.xer.ca = temp.u8;
	// addi r1,r1,112
	ctx.r1.s64 = ctx.r1.s64 + 112;
	// b 0x8b0cba0c
	__restgprlr_29(ctx, base);
	return;
loc_8B0CA778:
	// lis r11,-29943
	ctx.r11.s64 = -1962344448;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// addi r4,r11,-25556
	ctx.r4.s64 = ctx.r11.s64 + -25556;
	// bl 0x8b0cea10
	ctx.lr = 0x8B0CA788;
	sub_8B0CEA10(ctx, base);
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// beq cr6,0x8b0ca920
	if (ctx.cr6.eq) goto loc_8B0CA920;
	// lis r11,-29943
	ctx.r11.s64 = -1962344448;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// addi r4,r11,-25568
	ctx.r4.s64 = ctx.r11.s64 + -25568;
	// bl 0x8b0cea10
	ctx.lr = 0x8B0CA7A0;
	sub_8B0CEA10(ctx, base);
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// beq cr6,0x8b0ca920
	if (ctx.cr6.eq) goto loc_8B0CA920;
	// lis r11,-29943
	ctx.r11.s64 = -1962344448;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// addi r4,r11,-25576
	ctx.r4.s64 = ctx.r11.s64 + -25576;
	// bl 0x8b0cea10
	ctx.lr = 0x8B0CA7B8;
	sub_8B0CEA10(ctx, base);
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// beq cr6,0x8b0ca920
	if (ctx.cr6.eq) goto loc_8B0CA920;
	// lis r11,-29943
	ctx.r11.s64 = -1962344448;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// addi r4,r11,-25584
	ctx.r4.s64 = ctx.r11.s64 + -25584;
	// bl 0x8b0cea10
	ctx.lr = 0x8B0CA7D0;
	sub_8B0CEA10(ctx, base);
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// beq cr6,0x8b0ca920
	if (ctx.cr6.eq) goto loc_8B0CA920;
	// lis r11,-29943
	ctx.r11.s64 = -1962344448;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// addi r4,r11,-25592
	ctx.r4.s64 = ctx.r11.s64 + -25592;
	// bl 0x8b0cea10
	ctx.lr = 0x8B0CA7E8;
	sub_8B0CEA10(ctx, base);
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// beq cr6,0x8b0ca920
	if (ctx.cr6.eq) goto loc_8B0CA920;
	// lis r11,-29943
	ctx.r11.s64 = -1962344448;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// addi r4,r11,-25600
	ctx.r4.s64 = ctx.r11.s64 + -25600;
	// bl 0x8b0cea10
	ctx.lr = 0x8B0CA800;
	sub_8B0CEA10(ctx, base);
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// beq cr6,0x8b0ca920
	if (ctx.cr6.eq) goto loc_8B0CA920;
	// lis r11,-29943
	ctx.r11.s64 = -1962344448;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// addi r4,r11,-25608
	ctx.r4.s64 = ctx.r11.s64 + -25608;
	// bl 0x8b0cea10
	ctx.lr = 0x8B0CA818;
	sub_8B0CEA10(ctx, base);
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// beq cr6,0x8b0ca920
	if (ctx.cr6.eq) goto loc_8B0CA920;
	// lis r11,-29943
	ctx.r11.s64 = -1962344448;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// addi r4,r11,-25620
	ctx.r4.s64 = ctx.r11.s64 + -25620;
	// bl 0x8b0cea10
	ctx.lr = 0x8B0CA830;
	sub_8B0CEA10(ctx, base);
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// beq cr6,0x8b0ca920
	if (ctx.cr6.eq) goto loc_8B0CA920;
	// lis r11,-29943
	ctx.r11.s64 = -1962344448;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// addi r4,r11,-25632
	ctx.r4.s64 = ctx.r11.s64 + -25632;
	// bl 0x8b0cea10
	ctx.lr = 0x8B0CA848;
	sub_8B0CEA10(ctx, base);
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// beq cr6,0x8b0ca920
	if (ctx.cr6.eq) goto loc_8B0CA920;
	// lis r11,-29943
	ctx.r11.s64 = -1962344448;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// addi r4,r11,-25644
	ctx.r4.s64 = ctx.r11.s64 + -25644;
	// bl 0x8b0cea10
	ctx.lr = 0x8B0CA860;
	sub_8B0CEA10(ctx, base);
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// beq cr6,0x8b0ca920
	if (ctx.cr6.eq) goto loc_8B0CA920;
	// lis r11,-29943
	ctx.r11.s64 = -1962344448;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// addi r4,r11,-25652
	ctx.r4.s64 = ctx.r11.s64 + -25652;
	// bl 0x8b0cea10
	ctx.lr = 0x8B0CA878;
	sub_8B0CEA10(ctx, base);
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// beq cr6,0x8b0ca920
	if (ctx.cr6.eq) goto loc_8B0CA920;
	// lis r11,-29943
	ctx.r11.s64 = -1962344448;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// addi r4,r11,-25660
	ctx.r4.s64 = ctx.r11.s64 + -25660;
	// bl 0x8b0cea10
	ctx.lr = 0x8B0CA890;
	sub_8B0CEA10(ctx, base);
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// beq cr6,0x8b0ca920
	if (ctx.cr6.eq) goto loc_8B0CA920;
	// lis r11,-29943
	ctx.r11.s64 = -1962344448;
	// li r5,5
	ctx.r5.s64 = 5;
	// addi r4,r11,-25668
	ctx.r4.s64 = ctx.r11.s64 + -25668;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0c3c00
	ctx.lr = 0x8B0CA8AC;
	sub_8B0C3C00(ctx, base);
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// bne cr6,0x8b0ca904
	if (!ctx.cr6.eq) goto loc_8B0CA904;
	// lis r11,-29936
	ctx.r11.s64 = -1961885696;
	// lwz r3,-27244(r11)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r11.u32 + -27244);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0ca904
	if (ctx.cr6.eq) goto loc_8B0CA904;
	// lwz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// addi r4,r31,5
	ctx.r4.s64 = ctx.r31.s64 + 5;
	// lwz r10,52(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 52);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B0CA8D8;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0ca904
	if (ctx.cr6.eq) goto loc_8B0CA904;
	// addi r11,r3,24
	ctx.r11.s64 = ctx.r3.s64 + 24;
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// beq cr6,0x8b0ca904
	if (ctx.cr6.eq) goto loc_8B0CA904;
	// lwz r11,4(r11)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r11.u32 + 4);
	// lwz r10,48(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 48);
	// addic r9,r10,-1
	ctx.xer.ca = ctx.r10.u32 > 0;
	ctx.r9.s64 = ctx.r10.s64 + -1;
	// subfe r3,r9,r10
	temp.u8 = (~ctx.r9.u32 + ctx.r10.u32 < ~ctx.r9.u32) | (~ctx.r9.u32 + ctx.r10.u32 + ctx.xer.ca < ctx.xer.ca);
	ctx.r3.u64 = ~ctx.r9.u64 + ctx.r10.u64 + ctx.xer.ca;
	ctx.xer.ca = temp.u8;
	// addi r1,r1,112
	ctx.r1.s64 = ctx.r1.s64 + 112;
	// b 0x8b0cba0c
	__restgprlr_29(ctx, base);
	return;
loc_8B0CA904:
	// lis r11,-29943
	ctx.r11.s64 = -1962344448;
	// mr r4,r31
	ctx.r4.u64 = ctx.r31.u64;
	// addi r3,r11,-25704
	ctx.r3.s64 = ctx.r11.s64 + -25704;
	// bl 0x8b0df2a8
	ctx.lr = 0x8B0CA914;
	sub_8B0DF2A8(ctx, base);
loc_8B0CA914:
	// li r3,0
	ctx.r3.s64 = 0;
	// addi r1,r1,112
	ctx.r1.s64 = ctx.r1.s64 + 112;
	// b 0x8b0cba0c
	__restgprlr_29(ctx, base);
	return;
loc_8B0CA920:
	// bl 0x8b0df548
	ctx.lr = 0x8B0CA924;
	sub_8B0DF548(ctx, base);
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0ca93c
	if (ctx.cr6.eq) goto loc_8B0CA93C;
	// lbz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U8(ctx.r3.u32 + 0);
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// bne cr6,0x8b0ca944
	if (!ctx.cr6.eq) goto loc_8B0CA944;
loc_8B0CA93C:
	// lis r11,-29943
	ctx.r11.s64 = -1962344448;
	// addi r4,r11,-25712
	ctx.r4.s64 = ctx.r11.s64 + -25712;
loc_8B0CA944:
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0cea10
	ctx.lr = 0x8B0CA94C;
	sub_8B0CEA10(ctx, base);
	// cntlzw r11,r3
	ctx.r11.u64 = ctx.r3.u32 == 0 ? 32 : __builtin_clz(ctx.r3.u32);
	// rlwinm r3,r11,27,31,31
	ctx.r3.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 27) & 0x1;
	// addi r1,r1,112
	ctx.r1.s64 = ctx.r1.s64 + 112;
	// b 0x8b0cba0c
	__restgprlr_29(ctx, base);
	return;
loc_8B0CA95C:
	// lis r10,-29936
	ctx.r10.s64 = -1961885696;
	// lis r11,-29936
	ctx.r11.s64 = -1961885696;
	// addi r30,r11,-17900
	ctx.r30.s64 = ctx.r11.s64 + -17900;
	// lwz r11,-17884(r10)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r10.u32 + -17884);
	// clrlwi r9,r11,31
	ctx.r9.u64 = ctx.r11.u32 & 0x1;
	// cmplwi cr6,r9,0
	ctx.cr6.compare<uint32_t>(ctx.r9.u32, 0, ctx.xer);
	// bne cr6,0x8b0ca990
	if (!ctx.cr6.eq) goto loc_8B0CA990;
	// ori r11,r11,1
	ctx.r11.u64 = ctx.r11.u64 | 1;
	// lis r9,-29943
	ctx.r9.s64 = -1962344448;
	// stw r11,-17884(r10)
	REX_STORE_U32(ctx.r10.u32 + -17884, ctx.r11.u32);
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// addi r4,r9,-25732
	ctx.r4.s64 = ctx.r9.s64 + -25732;
	// bl 0x8b0c6f58
	ctx.lr = 0x8B0CA990;
	sub_8B0C6F58(ctx, base);
loc_8B0CA990:
	// mr r4,r29
	ctx.r4.u64 = ctx.r29.u64;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0cea10
	ctx.lr = 0x8B0CA99C;
	sub_8B0CEA10(ctx, base);
	// lwz r11,4(r30)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r30.u32 + 4);
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// lwz r11,48(r11)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r11.u32 + 48);
	// beq cr6,0x8b0ca70c
	if (ctx.cr6.eq) goto loc_8B0CA70C;
	// cntlzw r10,r11
	ctx.r10.u64 = ctx.r11.u32 == 0 ? 32 : __builtin_clz(ctx.r11.u32);
	// rlwinm r3,r10,27,31,31
	ctx.r3.u64 = __builtin_rotateleft64(ctx.r10.u32 | (ctx.r10.u64 << 32), 27) & 0x1;
	// addi r1,r1,112
	ctx.r1.s64 = ctx.r1.s64 + 112;
	// b 0x8b0cba0c
	__restgprlr_29(ctx, base);
	return;
}

DEFINE_REX_FUNC(__savegprlr_14) {
	REX_FUNC_PROLOGUE();
	// std r14,-152(r1)
	REX_STORE_U64(ctx.r1.u32 + -152, ctx.r14.u64);
	// std r15,-144(r1)
	REX_STORE_U64(ctx.r1.u32 + -144, ctx.r15.u64);
	// std r16,-136(r1)
	REX_STORE_U64(ctx.r1.u32 + -136, ctx.r16.u64);
	// std r17,-128(r1)
	REX_STORE_U64(ctx.r1.u32 + -128, ctx.r17.u64);
	// std r18,-120(r1)
	REX_STORE_U64(ctx.r1.u32 + -120, ctx.r18.u64);
	// std r19,-112(r1)
	REX_STORE_U64(ctx.r1.u32 + -112, ctx.r19.u64);
	// std r20,-104(r1)
	REX_STORE_U64(ctx.r1.u32 + -104, ctx.r20.u64);
	// std r21,-96(r1)
	REX_STORE_U64(ctx.r1.u32 + -96, ctx.r21.u64);
	// std r22,-88(r1)
	REX_STORE_U64(ctx.r1.u32 + -88, ctx.r22.u64);
	// std r23,-80(r1)
	REX_STORE_U64(ctx.r1.u32 + -80, ctx.r23.u64);
	// std r24,-72(r1)
	REX_STORE_U64(ctx.r1.u32 + -72, ctx.r24.u64);
	// std r25,-64(r1)
	REX_STORE_U64(ctx.r1.u32 + -64, ctx.r25.u64);
	// std r26,-56(r1)
	REX_STORE_U64(ctx.r1.u32 + -56, ctx.r26.u64);
	// std r27,-48(r1)
	REX_STORE_U64(ctx.r1.u32 + -48, ctx.r27.u64);
	// std r28,-40(r1)
	REX_STORE_U64(ctx.r1.u32 + -40, ctx.r28.u64);
	// std r29,-32(r1)
	REX_STORE_U64(ctx.r1.u32 + -32, ctx.r29.u64);
	// std r30,-24(r1)
	REX_STORE_U64(ctx.r1.u32 + -24, ctx.r30.u64);
	// std r31,-16(r1)
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.r31.u64);
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// blr 
	return;
}

DEFINE_REX_FUNC(__savegprlr_16) {
	REX_FUNC_PROLOGUE();
	// std r16,-136(r1)
	REX_STORE_U64(ctx.r1.u32 + -136, ctx.r16.u64);
	// std r17,-128(r1)
	REX_STORE_U64(ctx.r1.u32 + -128, ctx.r17.u64);
	// std r18,-120(r1)
	REX_STORE_U64(ctx.r1.u32 + -120, ctx.r18.u64);
	// std r19,-112(r1)
	REX_STORE_U64(ctx.r1.u32 + -112, ctx.r19.u64);
	// std r20,-104(r1)
	REX_STORE_U64(ctx.r1.u32 + -104, ctx.r20.u64);
	// std r21,-96(r1)
	REX_STORE_U64(ctx.r1.u32 + -96, ctx.r21.u64);
	// std r22,-88(r1)
	REX_STORE_U64(ctx.r1.u32 + -88, ctx.r22.u64);
	// std r23,-80(r1)
	REX_STORE_U64(ctx.r1.u32 + -80, ctx.r23.u64);
	// std r24,-72(r1)
	REX_STORE_U64(ctx.r1.u32 + -72, ctx.r24.u64);
	// std r25,-64(r1)
	REX_STORE_U64(ctx.r1.u32 + -64, ctx.r25.u64);
	// std r26,-56(r1)
	REX_STORE_U64(ctx.r1.u32 + -56, ctx.r26.u64);
	// std r27,-48(r1)
	REX_STORE_U64(ctx.r1.u32 + -48, ctx.r27.u64);
	// std r28,-40(r1)
	REX_STORE_U64(ctx.r1.u32 + -40, ctx.r28.u64);
	// std r29,-32(r1)
	REX_STORE_U64(ctx.r1.u32 + -32, ctx.r29.u64);
	// std r30,-24(r1)
	REX_STORE_U64(ctx.r1.u32 + -24, ctx.r30.u64);
	// std r31,-16(r1)
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.r31.u64);
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// blr 
	return;
}

DEFINE_REX_FUNC(__savegprlr_21) {
	REX_FUNC_PROLOGUE();
	// std r21,-96(r1)
	REX_STORE_U64(ctx.r1.u32 + -96, ctx.r21.u64);
	// std r22,-88(r1)
	REX_STORE_U64(ctx.r1.u32 + -88, ctx.r22.u64);
	// std r23,-80(r1)
	REX_STORE_U64(ctx.r1.u32 + -80, ctx.r23.u64);
	// std r24,-72(r1)
	REX_STORE_U64(ctx.r1.u32 + -72, ctx.r24.u64);
	// std r25,-64(r1)
	REX_STORE_U64(ctx.r1.u32 + -64, ctx.r25.u64);
	// std r26,-56(r1)
	REX_STORE_U64(ctx.r1.u32 + -56, ctx.r26.u64);
	// std r27,-48(r1)
	REX_STORE_U64(ctx.r1.u32 + -48, ctx.r27.u64);
	// std r28,-40(r1)
	REX_STORE_U64(ctx.r1.u32 + -40, ctx.r28.u64);
	// std r29,-32(r1)
	REX_STORE_U64(ctx.r1.u32 + -32, ctx.r29.u64);
	// std r30,-24(r1)
	REX_STORE_U64(ctx.r1.u32 + -24, ctx.r30.u64);
	// std r31,-16(r1)
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.r31.u64);
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// blr 
	return;
}

DEFINE_REX_FUNC(__savegprlr_23) {
	REX_FUNC_PROLOGUE();
	// std r23,-80(r1)
	REX_STORE_U64(ctx.r1.u32 + -80, ctx.r23.u64);
	// std r24,-72(r1)
	REX_STORE_U64(ctx.r1.u32 + -72, ctx.r24.u64);
	// std r25,-64(r1)
	REX_STORE_U64(ctx.r1.u32 + -64, ctx.r25.u64);
	// std r26,-56(r1)
	REX_STORE_U64(ctx.r1.u32 + -56, ctx.r26.u64);
	// std r27,-48(r1)
	REX_STORE_U64(ctx.r1.u32 + -48, ctx.r27.u64);
	// std r28,-40(r1)
	REX_STORE_U64(ctx.r1.u32 + -40, ctx.r28.u64);
	// std r29,-32(r1)
	REX_STORE_U64(ctx.r1.u32 + -32, ctx.r29.u64);
	// std r30,-24(r1)
	REX_STORE_U64(ctx.r1.u32 + -24, ctx.r30.u64);
	// std r31,-16(r1)
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.r31.u64);
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// blr 
	return;
}

DEFINE_REX_FUNC(__savegprlr_30) {
	REX_FUNC_PROLOGUE();
	// std r30,-24(r1)
	REX_STORE_U64(ctx.r1.u32 + -24, ctx.r30.u64);
	// std r31,-16(r1)
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.r31.u64);
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// blr 
	return;
}

DEFINE_REX_FUNC(__savegprlr_31) {
	REX_FUNC_PROLOGUE();
	// std r31,-16(r1)
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.r31.u64);
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// blr 
	return;
}

DEFINE_REX_FUNC(__restgprlr_17) {
	REX_FUNC_PROLOGUE();
	// ld r17,-128(r1)
	ctx.r17.u64 = REX_LOAD_U64(ctx.r1.u32 + -128);
	// ld r18,-120(r1)
	ctx.r18.u64 = REX_LOAD_U64(ctx.r1.u32 + -120);
	// ld r19,-112(r1)
	ctx.r19.u64 = REX_LOAD_U64(ctx.r1.u32 + -112);
	// ld r20,-104(r1)
	ctx.r20.u64 = REX_LOAD_U64(ctx.r1.u32 + -104);
	// ld r21,-96(r1)
	ctx.r21.u64 = REX_LOAD_U64(ctx.r1.u32 + -96);
	// ld r22,-88(r1)
	ctx.r22.u64 = REX_LOAD_U64(ctx.r1.u32 + -88);
	// ld r23,-80(r1)
	ctx.r23.u64 = REX_LOAD_U64(ctx.r1.u32 + -80);
	// ld r24,-72(r1)
	ctx.r24.u64 = REX_LOAD_U64(ctx.r1.u32 + -72);
	// ld r25,-64(r1)
	ctx.r25.u64 = REX_LOAD_U64(ctx.r1.u32 + -64);
	// ld r26,-56(r1)
	ctx.r26.u64 = REX_LOAD_U64(ctx.r1.u32 + -56);
	// ld r27,-48(r1)
	ctx.r27.u64 = REX_LOAD_U64(ctx.r1.u32 + -48);
	// ld r28,-40(r1)
	ctx.r28.u64 = REX_LOAD_U64(ctx.r1.u32 + -40);
	// ld r29,-32(r1)
	ctx.r29.u64 = REX_LOAD_U64(ctx.r1.u32 + -32);
	// ld r30,-24(r1)
	ctx.r30.u64 = REX_LOAD_U64(ctx.r1.u32 + -24);
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// blr 
	return;
}

DEFINE_REX_FUNC(__restgprlr_20) {
	REX_FUNC_PROLOGUE();
	// ld r20,-104(r1)
	ctx.r20.u64 = REX_LOAD_U64(ctx.r1.u32 + -104);
	// ld r21,-96(r1)
	ctx.r21.u64 = REX_LOAD_U64(ctx.r1.u32 + -96);
	// ld r22,-88(r1)
	ctx.r22.u64 = REX_LOAD_U64(ctx.r1.u32 + -88);
	// ld r23,-80(r1)
	ctx.r23.u64 = REX_LOAD_U64(ctx.r1.u32 + -80);
	// ld r24,-72(r1)
	ctx.r24.u64 = REX_LOAD_U64(ctx.r1.u32 + -72);
	// ld r25,-64(r1)
	ctx.r25.u64 = REX_LOAD_U64(ctx.r1.u32 + -64);
	// ld r26,-56(r1)
	ctx.r26.u64 = REX_LOAD_U64(ctx.r1.u32 + -56);
	// ld r27,-48(r1)
	ctx.r27.u64 = REX_LOAD_U64(ctx.r1.u32 + -48);
	// ld r28,-40(r1)
	ctx.r28.u64 = REX_LOAD_U64(ctx.r1.u32 + -40);
	// ld r29,-32(r1)
	ctx.r29.u64 = REX_LOAD_U64(ctx.r1.u32 + -32);
	// ld r30,-24(r1)
	ctx.r30.u64 = REX_LOAD_U64(ctx.r1.u32 + -24);
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// blr 
	return;
}

DEFINE_REX_FUNC(__restgprlr_23) {
	REX_FUNC_PROLOGUE();
	// ld r23,-80(r1)
	ctx.r23.u64 = REX_LOAD_U64(ctx.r1.u32 + -80);
	// ld r24,-72(r1)
	ctx.r24.u64 = REX_LOAD_U64(ctx.r1.u32 + -72);
	// ld r25,-64(r1)
	ctx.r25.u64 = REX_LOAD_U64(ctx.r1.u32 + -64);
	// ld r26,-56(r1)
	ctx.r26.u64 = REX_LOAD_U64(ctx.r1.u32 + -56);
	// ld r27,-48(r1)
	ctx.r27.u64 = REX_LOAD_U64(ctx.r1.u32 + -48);
	// ld r28,-40(r1)
	ctx.r28.u64 = REX_LOAD_U64(ctx.r1.u32 + -40);
	// ld r29,-32(r1)
	ctx.r29.u64 = REX_LOAD_U64(ctx.r1.u32 + -32);
	// ld r30,-24(r1)
	ctx.r30.u64 = REX_LOAD_U64(ctx.r1.u32 + -24);
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// blr 
	return;
}

DEFINE_REX_FUNC(__restgprlr_28) {
	REX_FUNC_PROLOGUE();
	// ld r28,-40(r1)
	ctx.r28.u64 = REX_LOAD_U64(ctx.r1.u32 + -40);
	// ld r29,-32(r1)
	ctx.r29.u64 = REX_LOAD_U64(ctx.r1.u32 + -32);
	// ld r30,-24(r1)
	ctx.r30.u64 = REX_LOAD_U64(ctx.r1.u32 + -24);
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// blr 
	return;
}

DEFINE_REX_FUNC(__restgprlr_31) {
	REX_FUNC_PROLOGUE();
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0CBB30) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// std r3,-8(r1)
	REX_STORE_U64(ctx.r1.u32 + -8, ctx.r3.u64);
	// clrlwi r6,r3,29
	ctx.r6.u64 = ctx.r3.u32 & 0x7;
	// dcbt r0,r4
	// cmplwi r6,0
	ctx.cr0.compare<uint32_t>(ctx.r6.u32, 0, ctx.xer);
	// subfic r6,r6,8
	ctx.xer.ca = ctx.r6.u32 <= 8;
	ctx.r6.u64 = static_cast<uint64_t>(8) - ctx.r6.u64;
	// beq 0x8b0cbb94
	if (ctx.cr0.eq) goto loc_8B0CBB94;
	// cmplw r5,r6
	ctx.cr0.compare<uint32_t>(ctx.r5.u32, ctx.r6.u32, ctx.xer);
	// ble 0x8b0cbbb0
	if (!ctx.cr0.gt) goto loc_8B0CBBB0;
	// cmplwi r6,4
	ctx.cr0.compare<uint32_t>(ctx.r6.u32, 4, ctx.xer);
	// beq 0x8b0cbb80
	if (ctx.cr0.eq) goto loc_8B0CBB80;
	// addi r3,r3,-1
	ctx.r3.s64 = ctx.r3.s64 + -1;
	// addi r4,r4,-1
	ctx.r4.s64 = ctx.r4.s64 + -1;
	// subf r5,r6,r5
	ctx.r5.u64 = ctx.r5.u64 - ctx.r6.u64;
	// mtctr r6
	ctx.ctr.u64 = ctx.r6.u64;
loc_8B0CBB68:
	// lbzu r6,1(r4)
	ea = 1 + ctx.r4.u32;
	ctx.r6.u64 = REX_LOAD_U8(ea);
	ctx.r4.u32 = ea;
	// stbu r6,1(r3)
	ea = 1 + ctx.r3.u32;
	REX_STORE_U8(ea, ctx.r6.u8);
	ctx.r3.u32 = ea;
	// bdnz 0x8b0cbb68
	--ctx.ctr.u64;
	if (ctx.ctr.u32 != 0) goto loc_8B0CBB68;
	// addi r3,r3,1
	ctx.r3.s64 = ctx.r3.s64 + 1;
	// addi r4,r4,1
	ctx.r4.s64 = ctx.r4.s64 + 1;
	// b 0x8b0cbb94
	goto loc_8B0CBB94;
loc_8B0CBB80:
	// subf r5,r6,r5
	ctx.r5.u64 = ctx.r5.u64 - ctx.r6.u64;
	// lwz r6,0(r4)
	ctx.r6.u64 = REX_LOAD_U32(ctx.r4.u32 + 0);
	// addi r4,r4,4
	ctx.r4.s64 = ctx.r4.s64 + 4;
	// stw r6,0(r3)
	REX_STORE_U32(ctx.r3.u32 + 0, ctx.r6.u32);
	// addi r3,r3,4
	ctx.r3.s64 = ctx.r3.s64 + 4;
loc_8B0CBB94:
	// clrlwi r6,r4,29
	ctx.r6.u64 = ctx.r4.u32 & 0x7;
	// cmplwi cr6,r6,4
	ctx.cr6.compare<uint32_t>(ctx.r6.u32, 4, ctx.xer);
	// cmplwi cr1,r6,0
	ctx.cr1.compare<uint32_t>(ctx.r6.u32, 0, ctx.xer);
	// cmplwi cr7,r5,128
	ctx.cr7.compare<uint32_t>(ctx.r5.u32, 128, ctx.xer);
	// beq cr6,0x8b0cbd78
	if (ctx.cr6.eq) goto loc_8B0CBD78;
	// bne cr1,0x8b0cbea8
	if (!ctx.cr1.eq) goto loc_8B0CBEA8;
	// bge cr7,0x8b0cbc4c
	if (!ctx.cr7.lt) goto loc_8B0CBC4C;
loc_8B0CBBB0:
	// dcbtst r0,r3
	// addi r4,r4,-8
	ctx.r4.s64 = ctx.r4.s64 + -8;
	// addi r3,r3,-8
	ctx.r3.s64 = ctx.r3.s64 + -8;
loc_8B0CBBBC:
	// rlwinm r7,r5,29,28,31
	ctx.r7.u64 = __builtin_rotateleft64(ctx.r5.u32 | (ctx.r5.u64 << 32), 29) & 0xF;
	// clrlwi r6,r5,29
	ctx.r6.u64 = ctx.r5.u32 & 0x7;
	// cmplwi cr1,r7,0
	ctx.cr1.compare<uint32_t>(ctx.r7.u32, 0, ctx.xer);
	// cmplwi cr6,r6,0
	ctx.cr6.compare<uint32_t>(ctx.r6.u32, 0, ctx.xer);
	// beq cr1,0x8b0cbbe0
	if (ctx.cr1.eq) goto loc_8B0CBBE0;
	// mtctr r7
	ctx.ctr.u64 = ctx.r7.u64;
loc_8B0CBBD4:
	// ldu r7,8(r4)
	ea = 8 + ctx.r4.u32;
	ctx.r7.u64 = REX_LOAD_U64(ea);
	ctx.r4.u32 = ea;
	// stdu r7,8(r3)
	ea = 8 + ctx.r3.u32;
	REX_STORE_U64(ea, ctx.r7.u64);
	ctx.r3.u32 = ea;
	// bdnz 0x8b0cbbd4
	--ctx.ctr.u64;
	if (ctx.ctr.u32 != 0) goto loc_8B0CBBD4;
loc_8B0CBBE0:
	// cmplwi cr1,r6,4
	ctx.cr1.compare<uint32_t>(ctx.r6.u32, 4, ctx.xer);
	// beq cr6,0x8b0cbc04
	if (ctx.cr6.eq) goto loc_8B0CBC04;
	// beq cr1,0x8b0cbc0c
	if (ctx.cr1.eq) goto loc_8B0CBC0C;
	// addi r3,r3,7
	ctx.r3.s64 = ctx.r3.s64 + 7;
	// addi r4,r4,7
	ctx.r4.s64 = ctx.r4.s64 + 7;
	// mtctr r6
	ctx.ctr.u64 = ctx.r6.u64;
loc_8B0CBBF8:
	// lbzu r7,1(r4)
	ea = 1 + ctx.r4.u32;
	ctx.r7.u64 = REX_LOAD_U8(ea);
	ctx.r4.u32 = ea;
	// stbu r7,1(r3)
	ea = 1 + ctx.r3.u32;
	REX_STORE_U8(ea, ctx.r7.u8);
	ctx.r3.u32 = ea;
	// bdnz 0x8b0cbbf8
	--ctx.ctr.u64;
	if (ctx.ctr.u32 != 0) goto loc_8B0CBBF8;
loc_8B0CBC04:
	// ld r3,-8(r1)
	ctx.r3.u64 = REX_LOAD_U64(ctx.r1.u32 + -8);
	// blr 
	return;
loc_8B0CBC0C:
	// clrlwi r6,r3,30
	ctx.r6.u64 = ctx.r3.u32 & 0x3;
	// lwz r5,8(r4)
	ctx.r5.u64 = REX_LOAD_U32(ctx.r4.u32 + 8);
	// cmplwi r6,0
	ctx.cr0.compare<uint32_t>(ctx.r6.u32, 0, ctx.xer);
	// bne 0x8b0cbc28
	if (!ctx.cr0.eq) goto loc_8B0CBC28;
	// stw r5,8(r3)
	REX_STORE_U32(ctx.r3.u32 + 8, ctx.r5.u32);
	// ld r3,-8(r1)
	ctx.r3.u64 = REX_LOAD_U64(ctx.r1.u32 + -8);
	// blr 
	return;
loc_8B0CBC28:
	// lbz r8,8(r4)
	ctx.r8.u64 = REX_LOAD_U8(ctx.r4.u32 + 8);
	// lbz r7,9(r4)
	ctx.r7.u64 = REX_LOAD_U8(ctx.r4.u32 + 9);
	// lbz r6,10(r4)
	ctx.r6.u64 = REX_LOAD_U8(ctx.r4.u32 + 10);
	// stb r8,8(r3)
	REX_STORE_U8(ctx.r3.u32 + 8, ctx.r8.u8);
	// stb r7,9(r3)
	REX_STORE_U8(ctx.r3.u32 + 9, ctx.r7.u8);
	// stb r6,10(r3)
	REX_STORE_U8(ctx.r3.u32 + 10, ctx.r6.u8);
	// stb r5,11(r3)
	REX_STORE_U8(ctx.r3.u32 + 11, ctx.r5.u8);
	// ld r3,-8(r1)
	ctx.r3.u64 = REX_LOAD_U64(ctx.r1.u32 + -8);
	// blr 
	return;
loc_8B0CBC4C:
	// clrlwi r6,r3,25
	ctx.r6.u64 = ctx.r3.u32 & 0x7F;
	// addi r3,r3,-8
	ctx.r3.s64 = ctx.r3.s64 + -8;
	// addi r4,r4,-8
	ctx.r4.s64 = ctx.r4.s64 + -8;
	// cmplwi r6,0
	ctx.cr0.compare<uint32_t>(ctx.r6.u32, 0, ctx.xer);
	// subfic r6,r6,128
	ctx.xer.ca = ctx.r6.u32 <= 128;
	ctx.r6.u64 = static_cast<uint64_t>(128) - ctx.r6.u64;
	// beq 0x8b0cbc7c
	if (ctx.cr0.eq) goto loc_8B0CBC7C;
	// rlwinm r7,r6,29,3,31
	ctx.r7.u64 = __builtin_rotateleft64(ctx.r6.u32 | (ctx.r6.u64 << 32), 29) & 0x1FFFFFFF;
	// subf r5,r6,r5
	ctx.r5.u64 = ctx.r5.u64 - ctx.r6.u64;
	// mtctr r7
	ctx.ctr.u64 = ctx.r7.u64;
loc_8B0CBC70:
	// ldu r7,8(r4)
	ea = 8 + ctx.r4.u32;
	ctx.r7.u64 = REX_LOAD_U64(ea);
	ctx.r4.u32 = ea;
	// stdu r7,8(r3)
	ea = 8 + ctx.r3.u32;
	REX_STORE_U64(ea, ctx.r7.u64);
	ctx.r3.u32 = ea;
	// bdnz 0x8b0cbc70
	--ctx.ctr.u64;
	if (ctx.ctr.u32 != 0) goto loc_8B0CBC70;
loc_8B0CBC7C:
	// rlwinm r6,r5,25,7,31
	ctx.r6.u64 = __builtin_rotateleft64(ctx.r5.u32 | (ctx.r5.u64 << 32), 25) & 0x1FFFFFF;
	// cmplwi r6,0
	ctx.cr0.compare<uint32_t>(ctx.r6.u32, 0, ctx.xer);
	// beq 0x8b0cbbbc
	if (ctx.cr0.eq) goto loc_8B0CBBBC;
	// addi r10,r5,127
	ctx.r10.s64 = ctx.r5.s64 + 127;
	// clrlwi r8,r5,25
	ctx.r8.u64 = ctx.r5.u32 & 0x7F;
	// rlwinm r10,r10,25,7,31
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r10.u32 | (ctx.r10.u64 << 32), 25) & 0x1FFFFFF;
	// cmplwi cr1,r8,0
	ctx.cr1.compare<uint32_t>(ctx.r8.u32, 0, ctx.xer);
	// addi r10,r10,-1
	ctx.r10.s64 = ctx.r10.s64 + -1;
	// clrlwi r10,r10,29
	ctx.r10.u64 = ctx.r10.u32 & 0x7;
	// addi r10,r10,1
	ctx.r10.s64 = ctx.r10.s64 + 1;
	// li r9,8
	ctx.r9.s64 = 8;
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
loc_8B0CBCAC:
	// dcbt r9,r4
	// addi r9,r9,128
	ctx.r9.s64 = ctx.r9.s64 + 128;
	// bdnz 0x8b0cbcac
	--ctx.ctr.u64;
	if (ctx.ctr.u32 != 0) goto loc_8B0CBCAC;
	// add r12,r4,r5
	ctx.r12.u64 = ctx.r4.u64 + ctx.r5.u64;
	// li r10,8
	ctx.r10.s64 = 8;
	// subf r11,r9,r12
	ctx.r11.u64 = ctx.r12.u64 - ctx.r9.u64;
	// add r12,r3,r5
	ctx.r12.u64 = ctx.r3.u64 + ctx.r5.u64;
	// mtctr r6
	ctx.ctr.u64 = ctx.r6.u64;
loc_8B0CBCCC:
	// ld r6,8(r4)
	ctx.r6.u64 = REX_LOAD_U64(ctx.r4.u32 + 8);
	// ld r7,16(r4)
	ctx.r7.u64 = REX_LOAD_U64(ctx.r4.u32 + 16);
	// ld r8,24(r4)
	ctx.r8.u64 = REX_LOAD_U64(ctx.r4.u32 + 24);
	// std r6,8(r3)
	REX_STORE_U64(ctx.r3.u32 + 8, ctx.r6.u64);
	// ld r6,32(r4)
	ctx.r6.u64 = REX_LOAD_U64(ctx.r4.u32 + 32);
	// std r7,16(r3)
	REX_STORE_U64(ctx.r3.u32 + 16, ctx.r7.u64);
	// ld r7,40(r4)
	ctx.r7.u64 = REX_LOAD_U64(ctx.r4.u32 + 40);
	// std r8,24(r3)
	REX_STORE_U64(ctx.r3.u32 + 24, ctx.r8.u64);
	// ld r8,48(r4)
	ctx.r8.u64 = REX_LOAD_U64(ctx.r4.u32 + 48);
	// std r6,32(r3)
	REX_STORE_U64(ctx.r3.u32 + 32, ctx.r6.u64);
	// ld r6,56(r4)
	ctx.r6.u64 = REX_LOAD_U64(ctx.r4.u32 + 56);
	// std r7,40(r3)
	REX_STORE_U64(ctx.r3.u32 + 40, ctx.r7.u64);
	// ld r7,64(r4)
	ctx.r7.u64 = REX_LOAD_U64(ctx.r4.u32 + 64);
	// std r8,48(r3)
	REX_STORE_U64(ctx.r3.u32 + 48, ctx.r8.u64);
	// ld r8,72(r4)
	ctx.r8.u64 = REX_LOAD_U64(ctx.r4.u32 + 72);
	// std r6,56(r3)
	REX_STORE_U64(ctx.r3.u32 + 56, ctx.r6.u64);
	// ld r6,80(r4)
	ctx.r6.u64 = REX_LOAD_U64(ctx.r4.u32 + 80);
	// std r7,64(r3)
	REX_STORE_U64(ctx.r3.u32 + 64, ctx.r7.u64);
	// ld r7,88(r4)
	ctx.r7.u64 = REX_LOAD_U64(ctx.r4.u32 + 88);
	// std r8,72(r3)
	REX_STORE_U64(ctx.r3.u32 + 72, ctx.r8.u64);
	// ld r8,96(r4)
	ctx.r8.u64 = REX_LOAD_U64(ctx.r4.u32 + 96);
	// std r6,80(r3)
	REX_STORE_U64(ctx.r3.u32 + 80, ctx.r6.u64);
	// ld r6,104(r4)
	ctx.r6.u64 = REX_LOAD_U64(ctx.r4.u32 + 104);
	// std r7,88(r3)
	REX_STORE_U64(ctx.r3.u32 + 88, ctx.r7.u64);
	// ld r7,112(r4)
	ctx.r7.u64 = REX_LOAD_U64(ctx.r4.u32 + 112);
	// std r8,96(r3)
	REX_STORE_U64(ctx.r3.u32 + 96, ctx.r8.u64);
	// ld r8,120(r4)
	ctx.r8.u64 = REX_LOAD_U64(ctx.r4.u32 + 120);
	// std r6,104(r3)
	REX_STORE_U64(ctx.r3.u32 + 104, ctx.r6.u64);
	// ldu r6,128(r4)
	ea = 128 + ctx.r4.u32;
	ctx.r6.u64 = REX_LOAD_U64(ea);
	ctx.r4.u32 = ea;
	// std r7,112(r3)
	REX_STORE_U64(ctx.r3.u32 + 112, ctx.r7.u64);
	// std r8,120(r3)
	REX_STORE_U64(ctx.r3.u32 + 120, ctx.r8.u64);
	// stdu r6,128(r3)
	ea = 128 + ctx.r3.u32;
	REX_STORE_U64(ea, ctx.r6.u64);
	ctx.r3.u32 = ea;
	// cmplw r4,r11
	ctx.cr0.compare<uint32_t>(ctx.r4.u32, ctx.r11.u32, ctx.xer);
	// bge 0x8b0cbd60
	if (!ctx.cr0.lt) goto loc_8B0CBD60;
	// dcbt r9,r4
	// bdnz 0x8b0cbccc
	--ctx.ctr.u64;
	if (ctx.ctr.u32 != 0) goto loc_8B0CBCCC;
	// b 0x8b0cbbbc
	goto loc_8B0CBBBC;
loc_8B0CBD60:
	// beq cr1,0x8b0cbd70
	if (ctx.cr1.eq) goto loc_8B0CBD70;
	// li r8,-1
	ctx.r8.s64 = -1;
	// dcbtst r8,r12
	// cmplwi cr1,r8,0
	ctx.cr1.compare<uint32_t>(ctx.r8.u32, 0, ctx.xer);
loc_8B0CBD70:
	// bdnz 0x8b0cbccc
	--ctx.ctr.u64;
	if (ctx.ctr.u32 != 0) goto loc_8B0CBCCC;
	// b 0x8b0cbbbc
	goto loc_8B0CBBBC;
loc_8B0CBD78:
	// addi r4,r4,-4
	ctx.r4.s64 = ctx.r4.s64 + -4;
	// bge cr7,0x8b0cbdd0
	if (!ctx.cr7.lt) goto loc_8B0CBDD0;
	// dcbtst r0,r3
	// addi r3,r3,-4
	ctx.r3.s64 = ctx.r3.s64 + -4;
loc_8B0CBD88:
	// rlwinm r7,r5,30,27,31
	ctx.r7.u64 = __builtin_rotateleft64(ctx.r5.u32 | (ctx.r5.u64 << 32), 30) & 0x1F;
	// clrlwi r6,r5,30
	ctx.r6.u64 = ctx.r5.u32 & 0x3;
	// cmplwi cr1,r7,0
	ctx.cr1.compare<uint32_t>(ctx.r7.u32, 0, ctx.xer);
	// cmplwi cr6,r6,0
	ctx.cr6.compare<uint32_t>(ctx.r6.u32, 0, ctx.xer);
	// beq cr1,0x8b0cbdac
	if (ctx.cr1.eq) goto loc_8B0CBDAC;
	// mtctr r7
	ctx.ctr.u64 = ctx.r7.u64;
loc_8B0CBDA0:
	// lwzu r7,4(r4)
	ea = 4 + ctx.r4.u32;
	ctx.r7.u64 = REX_LOAD_U32(ea);
	ctx.r4.u32 = ea;
	// stwu r7,4(r3)
	ea = 4 + ctx.r3.u32;
	REX_STORE_U32(ea, ctx.r7.u32);
	ctx.r3.u32 = ea;
	// bdnz 0x8b0cbda0
	--ctx.ctr.u64;
	if (ctx.ctr.u32 != 0) goto loc_8B0CBDA0;
loc_8B0CBDAC:
	// beq cr6,0x8b0cbdc8
	if (ctx.cr6.eq) goto loc_8B0CBDC8;
	// addi r3,r3,3
	ctx.r3.s64 = ctx.r3.s64 + 3;
	// addi r4,r4,3
	ctx.r4.s64 = ctx.r4.s64 + 3;
	// mtctr r6
	ctx.ctr.u64 = ctx.r6.u64;
loc_8B0CBDBC:
	// lbzu r7,1(r4)
	ea = 1 + ctx.r4.u32;
	ctx.r7.u64 = REX_LOAD_U8(ea);
	ctx.r4.u32 = ea;
	// stbu r7,1(r3)
	ea = 1 + ctx.r3.u32;
	REX_STORE_U8(ea, ctx.r7.u8);
	ctx.r3.u32 = ea;
	// bdnz 0x8b0cbdbc
	--ctx.ctr.u64;
	if (ctx.ctr.u32 != 0) goto loc_8B0CBDBC;
loc_8B0CBDC8:
	// ld r3,-8(r1)
	ctx.r3.u64 = REX_LOAD_U64(ctx.r1.u32 + -8);
	// blr 
	return;
loc_8B0CBDD0:
	// clrlwi r6,r3,25
	ctx.r6.u64 = ctx.r3.u32 & 0x7F;
	// addi r3,r3,-4
	ctx.r3.s64 = ctx.r3.s64 + -4;
	// cmplwi r6,0
	ctx.cr0.compare<uint32_t>(ctx.r6.u32, 0, ctx.xer);
	// subfic r6,r6,128
	ctx.xer.ca = ctx.r6.u32 <= 128;
	ctx.r6.u64 = static_cast<uint64_t>(128) - ctx.r6.u64;
	// beq 0x8b0cbdfc
	if (ctx.cr0.eq) goto loc_8B0CBDFC;
	// rlwinm r7,r6,30,2,31
	ctx.r7.u64 = __builtin_rotateleft64(ctx.r6.u32 | (ctx.r6.u64 << 32), 30) & 0x3FFFFFFF;
	// subf r5,r6,r5
	ctx.r5.u64 = ctx.r5.u64 - ctx.r6.u64;
	// mtctr r7
	ctx.ctr.u64 = ctx.r7.u64;
loc_8B0CBDF0:
	// lwzu r7,4(r4)
	ea = 4 + ctx.r4.u32;
	ctx.r7.u64 = REX_LOAD_U32(ea);
	ctx.r4.u32 = ea;
	// stwu r7,4(r3)
	ea = 4 + ctx.r3.u32;
	REX_STORE_U32(ea, ctx.r7.u32);
	ctx.r3.u32 = ea;
	// bdnz 0x8b0cbdf0
	--ctx.ctr.u64;
	if (ctx.ctr.u32 != 0) goto loc_8B0CBDF0;
loc_8B0CBDFC:
	// rlwinm r6,r5,25,7,31
	ctx.r6.u64 = __builtin_rotateleft64(ctx.r5.u32 | (ctx.r5.u64 << 32), 25) & 0x1FFFFFF;
	// cmplwi r6,0
	ctx.cr0.compare<uint32_t>(ctx.r6.u32, 0, ctx.xer);
	// beq 0x8b0cbd88
	if (ctx.cr0.eq) goto loc_8B0CBD88;
	// addi r10,r5,127
	ctx.r10.s64 = ctx.r5.s64 + 127;
	// clrlwi r8,r5,25
	ctx.r8.u64 = ctx.r5.u32 & 0x7F;
	// rlwinm r10,r10,25,7,31
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r10.u32 | (ctx.r10.u64 << 32), 25) & 0x1FFFFFF;
	// cmplwi cr1,r8,0
	ctx.cr1.compare<uint32_t>(ctx.r8.u32, 0, ctx.xer);
	// addi r10,r10,-1
	ctx.r10.s64 = ctx.r10.s64 + -1;
	// clrlwi r10,r10,29
	ctx.r10.u64 = ctx.r10.u32 & 0x7;
	// addi r10,r10,1
	ctx.r10.s64 = ctx.r10.s64 + 1;
	// li r9,4
	ctx.r9.s64 = 4;
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
loc_8B0CBE2C:
	// dcbt r9,r4
	// addi r9,r9,128
	ctx.r9.s64 = ctx.r9.s64 + 128;
	// bdnz 0x8b0cbe2c
	--ctx.ctr.u64;
	if (ctx.ctr.u32 != 0) goto loc_8B0CBE2C;
	// add r12,r4,r5
	ctx.r12.u64 = ctx.r4.u64 + ctx.r5.u64;
	// li r10,8
	ctx.r10.s64 = 8;
	// subf r11,r9,r12
	ctx.r11.u64 = ctx.r12.u64 - ctx.r9.u64;
	// add r12,r3,r5
	ctx.r12.u64 = ctx.r3.u64 + ctx.r5.u64;
	// mtctr r6
	ctx.ctr.u64 = ctx.r6.u64;
loc_8B0CBE4C:
	// li r6,8
	ctx.r6.s64 = 8;
loc_8B0CBE50:
	// addi r6,r6,-1
	ctx.r6.s64 = ctx.r6.s64 + -1;
	// lwz r0,4(r4)
	ctx.r0.u64 = REX_LOAD_U32(ctx.r4.u32 + 4);
	// lwz r7,8(r4)
	ctx.r7.u64 = REX_LOAD_U32(ctx.r4.u32 + 8);
	// lwz r8,12(r4)
	ctx.r8.u64 = REX_LOAD_U32(ctx.r4.u32 + 12);
	// cmplwi r6,0
	ctx.cr0.compare<uint32_t>(ctx.r6.u32, 0, ctx.xer);
	// stw r0,4(r3)
	REX_STORE_U32(ctx.r3.u32 + 4, ctx.r0.u32);
	// lwzu r0,16(r4)
	ea = 16 + ctx.r4.u32;
	ctx.r0.u64 = REX_LOAD_U32(ea);
	ctx.r4.u32 = ea;
	// stw r7,8(r3)
	REX_STORE_U32(ctx.r3.u32 + 8, ctx.r7.u32);
	// stw r8,12(r3)
	REX_STORE_U32(ctx.r3.u32 + 12, ctx.r8.u32);
	// stwu r0,16(r3)
	ea = 16 + ctx.r3.u32;
	REX_STORE_U32(ea, ctx.r0.u32);
	ctx.r3.u32 = ea;
	// bne 0x8b0cbe50
	if (!ctx.cr0.eq) goto loc_8B0CBE50;
	// cmplw r4,r11
	ctx.cr0.compare<uint32_t>(ctx.r4.u32, ctx.r11.u32, ctx.xer);
	// bge 0x8b0cbe90
	if (!ctx.cr0.lt) goto loc_8B0CBE90;
	// dcbt r9,r4
	// bdnz 0x8b0cbe4c
	--ctx.ctr.u64;
	if (ctx.ctr.u32 != 0) goto loc_8B0CBE4C;
	// b 0x8b0cbd88
	goto loc_8B0CBD88;
loc_8B0CBE90:
	// beq cr1,0x8b0cbea0
	if (ctx.cr1.eq) goto loc_8B0CBEA0;
	// li r8,-1
	ctx.r8.s64 = -1;
	// dcbtst r8,r12
	// cmplwi cr1,r8,0
	ctx.cr1.compare<uint32_t>(ctx.r8.u32, 0, ctx.xer);
loc_8B0CBEA0:
	// bdnz 0x8b0cbe4c
	--ctx.ctr.u64;
	if (ctx.ctr.u32 != 0) goto loc_8B0CBE4C;
	// b 0x8b0cbd88
	goto loc_8B0CBD88;
loc_8B0CBEA8:
	// addi r4,r4,-1
	ctx.r4.s64 = ctx.r4.s64 + -1;
	// bge cr7,0x8b0cbedc
	if (!ctx.cr7.lt) goto loc_8B0CBEDC;
	// dcbtst r0,r3
	// addi r3,r3,-1
	ctx.r3.s64 = ctx.r3.s64 + -1;
loc_8B0CBEB8:
	// clrlwi r6,r5,25
	ctx.r6.u64 = ctx.r5.u32 & 0x7F;
	// cmplwi r6,0
	ctx.cr0.compare<uint32_t>(ctx.r6.u32, 0, ctx.xer);
	// mtctr r6
	ctx.ctr.u64 = ctx.r6.u64;
	// beq 0x8b0cbed4
	if (ctx.cr0.eq) goto loc_8B0CBED4;
loc_8B0CBEC8:
	// lbzu r6,1(r4)
	ea = 1 + ctx.r4.u32;
	ctx.r6.u64 = REX_LOAD_U8(ea);
	ctx.r4.u32 = ea;
	// stbu r6,1(r3)
	ea = 1 + ctx.r3.u32;
	REX_STORE_U8(ea, ctx.r6.u8);
	ctx.r3.u32 = ea;
	// bdnz 0x8b0cbec8
	--ctx.ctr.u64;
	if (ctx.ctr.u32 != 0) goto loc_8B0CBEC8;
loc_8B0CBED4:
	// ld r3,-8(r1)
	ctx.r3.u64 = REX_LOAD_U64(ctx.r1.u32 + -8);
	// blr 
	return;
loc_8B0CBEDC:
	// clrlwi r6,r3,25
	ctx.r6.u64 = ctx.r3.u32 & 0x7F;
	// addi r3,r3,-1
	ctx.r3.s64 = ctx.r3.s64 + -1;
	// cmplwi r6,0
	ctx.cr0.compare<uint32_t>(ctx.r6.u32, 0, ctx.xer);
	// subfic r6,r6,128
	ctx.xer.ca = ctx.r6.u32 <= 128;
	ctx.r6.u64 = static_cast<uint64_t>(128) - ctx.r6.u64;
	// beq 0x8b0cbf04
	if (ctx.cr0.eq) goto loc_8B0CBF04;
	// subf r5,r6,r5
	ctx.r5.u64 = ctx.r5.u64 - ctx.r6.u64;
	// mtctr r6
	ctx.ctr.u64 = ctx.r6.u64;
loc_8B0CBEF8:
	// lbzu r6,1(r4)
	ea = 1 + ctx.r4.u32;
	ctx.r6.u64 = REX_LOAD_U8(ea);
	ctx.r4.u32 = ea;
	// stbu r6,1(r3)
	ea = 1 + ctx.r3.u32;
	REX_STORE_U8(ea, ctx.r6.u8);
	ctx.r3.u32 = ea;
	// bdnz 0x8b0cbef8
	--ctx.ctr.u64;
	if (ctx.ctr.u32 != 0) goto loc_8B0CBEF8;
loc_8B0CBF04:
	// rlwinm r6,r5,25,7,31
	ctx.r6.u64 = __builtin_rotateleft64(ctx.r5.u32 | (ctx.r5.u64 << 32), 25) & 0x1FFFFFF;
	// cmplwi r6,0
	ctx.cr0.compare<uint32_t>(ctx.r6.u32, 0, ctx.xer);
	// beq 0x8b0cbeb8
	if (ctx.cr0.eq) goto loc_8B0CBEB8;
	// addi r10,r5,127
	ctx.r10.s64 = ctx.r5.s64 + 127;
	// clrlwi r8,r5,25
	ctx.r8.u64 = ctx.r5.u32 & 0x7F;
	// rlwinm r10,r10,25,7,31
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r10.u32 | (ctx.r10.u64 << 32), 25) & 0x1FFFFFF;
	// cmplwi cr1,r8,0
	ctx.cr1.compare<uint32_t>(ctx.r8.u32, 0, ctx.xer);
	// addi r10,r10,-1
	ctx.r10.s64 = ctx.r10.s64 + -1;
	// clrlwi r10,r10,29
	ctx.r10.u64 = ctx.r10.u32 & 0x7;
	// addi r10,r10,1
	ctx.r10.s64 = ctx.r10.s64 + 1;
	// li r9,1
	ctx.r9.s64 = 1;
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
loc_8B0CBF34:
	// dcbt r9,r4
	// addi r9,r9,128
	ctx.r9.s64 = ctx.r9.s64 + 128;
	// bdnz 0x8b0cbf34
	--ctx.ctr.u64;
	if (ctx.ctr.u32 != 0) goto loc_8B0CBF34;
	// add r12,r4,r5
	ctx.r12.u64 = ctx.r4.u64 + ctx.r5.u64;
	// li r10,1
	ctx.r10.s64 = 1;
	// subf r11,r9,r12
	ctx.r11.u64 = ctx.r12.u64 - ctx.r9.u64;
	// add r12,r3,r5
	ctx.r12.u64 = ctx.r3.u64 + ctx.r5.u64;
	// mtctr r6
	ctx.ctr.u64 = ctx.r6.u64;
loc_8B0CBF54:
	// li r6,32
	ctx.r6.s64 = 32;
loc_8B0CBF58:
	// lbz r7,4(r4)
	ctx.r7.u64 = REX_LOAD_U8(ctx.r4.u32 + 4);
	// lbz r8,3(r4)
	ctx.r8.u64 = REX_LOAD_U8(ctx.r4.u32 + 3);
	// addi r6,r6,-1
	ctx.r6.s64 = ctx.r6.s64 + -1;
	// rlwimi r7,r8,8,16,23
	ctx.r7.u64 = (__builtin_rotateleft64(ctx.r8.u32 | (ctx.r8.u64 << 32), 8) & 0xFF00) | (ctx.r7.u64 & 0xFFFFFFFFFFFF00FF);
	// lbz r9,2(r4)
	ctx.r9.u64 = REX_LOAD_U8(ctx.r4.u32 + 2);
	// cmplwi r6,0
	ctx.cr0.compare<uint32_t>(ctx.r6.u32, 0, ctx.xer);
	// rlwimi r7,r9,16,8,15
	ctx.r7.u64 = (__builtin_rotateleft64(ctx.r9.u32 | (ctx.r9.u64 << 32), 16) & 0xFF0000) | (ctx.r7.u64 & 0xFFFFFFFFFF00FFFF);
	// lbz r10,1(r4)
	ctx.r10.u64 = REX_LOAD_U8(ctx.r4.u32 + 1);
	// addi r4,r4,4
	ctx.r4.s64 = ctx.r4.s64 + 4;
	// rlwimi r7,r10,24,0,7
	ctx.r7.u64 = (__builtin_rotateleft64(ctx.r10.u32 | (ctx.r10.u64 << 32), 24) & 0xFF000000) | (ctx.r7.u64 & 0xFFFFFFFF00FFFFFF);
	// stw r7,1(r3)
	REX_STORE_U32(ctx.r3.u32 + 1, ctx.r7.u32);
	// addi r3,r3,4
	ctx.r3.s64 = ctx.r3.s64 + 4;
	// bne 0x8b0cbf58
	if (!ctx.cr0.eq) goto loc_8B0CBF58;
	// cmplw r4,r11
	ctx.cr0.compare<uint32_t>(ctx.r4.u32, ctx.r11.u32, ctx.xer);
	// bge 0x8b0cbfa0
	if (!ctx.cr0.lt) goto loc_8B0CBFA0;
	// dcbt r9,r4
	// bdnz 0x8b0cbf54
	--ctx.ctr.u64;
	if (ctx.ctr.u32 != 0) goto loc_8B0CBF54;
	// b 0x8b0cbeb8
	goto loc_8B0CBEB8;
loc_8B0CBFA0:
	// beq cr1,0x8b0cbfb0
	if (ctx.cr1.eq) goto loc_8B0CBFB0;
	// li r8,-1
	ctx.r8.s64 = -1;
	// dcbtst r8,r12
	// cmplwi cr1,r8,0
	ctx.cr1.compare<uint32_t>(ctx.r8.u32, 0, ctx.xer);
loc_8B0CBFB0:
	// bdnz 0x8b0cbf54
	--ctx.ctr.u64;
	if (ctx.ctr.u32 != 0) goto loc_8B0CBF54;
	// b 0x8b0cbeb8
	goto loc_8B0CBEB8;
}

DEFINE_REX_FUNC(sub_8B0CD5C0) {
	REX_FUNC_PROLOGUE();
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// stfd f1,16(r1)
	ctx.fpscr.disableFlushMode();
	REX_STORE_U64(ctx.r1.u32 + 16, ctx.f1.u64);
	// lfd f6,17272(r11)
	ctx.f6.u64 = REX_LOAD_U64(ctx.r11.u32 + 17272);
	// fcmpu cr6,f1,f6
	ctx.cr6.compare(ctx.f1.f64, ctx.f6.f64);
	// bne cr6,0x8b0cd5e0
	if (!ctx.cr6.eq) goto loc_8B0CD5E0;
	// lis r11,-29943
	ctx.r11.s64 = -1962344448;
	// lfd f1,-32656(r11)
	ctx.f1.u64 = REX_LOAD_U64(ctx.r11.u32 + -32656);
	// blr 
	return;
loc_8B0CD5E0:
	// lhz r10,16(r1)
	ctx.r10.u64 = REX_LOAD_U16(ctx.r1.u32 + 16);
	// rlwinm r11,r10,0,17,27
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r10.u32 | (ctx.r10.u64 << 32), 0) & 0x7FF0;
	// mr r9,r10
	ctx.r9.u64 = ctx.r10.u64;
	// cmplwi cr6,r11,32752
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 32752, ctx.xer);
	// bne cr6,0x8b0cd614
	if (!ctx.cr6.eq) goto loc_8B0CD614;
	// lis r11,-29943
	ctx.r11.s64 = -1962344448;
	// lfd f0,-24792(r11)
	ctx.fpscr.disableFlushMode();
	ctx.f0.u64 = REX_LOAD_U64(ctx.r11.u32 + -24792);
	// fcmpu cr6,f1,f0
	ctx.cr6.compare(ctx.f1.f64, ctx.f0.f64);
	// bgtlr cr6
	if (ctx.cr6.gt) return;
loc_8B0CD604:
	// lis r11,-29938
	ctx.r11.s64 = -1962016768;
	// lfd f0,12528(r11)
	ctx.fpscr.disableFlushMode();
	ctx.f0.u64 = REX_LOAD_U64(ctx.r11.u32 + 12528);
loc_8B0CD60C:
	// fneg f1,f0
	ctx.fpscr.disableFlushMode();
	ctx.f1.u64 = ctx.f0.u64 ^ 0x8000000000000000;
	// blr 
	return;
loc_8B0CD614:
	// lis r10,-29943
	ctx.r10.s64 = -1962344448;
	// lfd f0,-32656(r10)
	ctx.fpscr.disableFlushMode();
	ctx.f0.u64 = REX_LOAD_U64(ctx.r10.u32 + -32656);
	// fcmpu cr6,f1,f0
	ctx.cr6.compare(ctx.f1.f64, ctx.f0.f64);
	// bgt cr6,0x8b0cd638
	if (ctx.cr6.gt) goto loc_8B0CD638;
	// fcmpu cr6,f1,f0
	ctx.cr6.compare(ctx.f1.f64, ctx.f0.f64);
	// bne cr6,0x8b0cd604
	if (!ctx.cr6.eq) goto loc_8B0CD604;
	// lis r11,-29938
	ctx.r11.s64 = -1962016768;
	// lfd f0,12520(r11)
	ctx.f0.u64 = REX_LOAD_U64(ctx.r11.u32 + 12520);
	// b 0x8b0cd60c
	goto loc_8B0CD60C;
loc_8B0CD638:
	// lis r10,-29943
	ctx.r10.s64 = -1962344448;
	// lfd f0,-24800(r10)
	ctx.fpscr.disableFlushMode();
	ctx.f0.u64 = REX_LOAD_U64(ctx.r10.u32 + -24800);
	// fcmpu cr6,f1,f0
	ctx.cr6.compare(ctx.f1.f64, ctx.f0.f64);
	// bge cr6,0x8b0cd670
	if (!ctx.cr6.lt) goto loc_8B0CD670;
	// lis r11,-29943
	ctx.r11.s64 = -1962344448;
	// lfd f0,-24808(r11)
	ctx.f0.u64 = REX_LOAD_U64(ctx.r11.u32 + -24808);
	// fmul f1,f1,f0
	ctx.f1.f64 = ctx.f1.f64 * ctx.f0.f64;
	// stfd f1,16(r1)
	REX_STORE_U64(ctx.r1.u32 + 16, ctx.f1.u64);
	// lhz r11,16(r1)
	ctx.r11.u64 = REX_LOAD_U16(ctx.r1.u32 + 16);
	// rlwinm r10,r11,28,21,31
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 28) & 0x7FF;
	// mr r9,r11
	ctx.r9.u64 = ctx.r11.u64;
	// mr r11,r10
	ctx.r11.u64 = ctx.r10.u64;
	// addi r10,r10,-1075
	ctx.r10.s64 = ctx.r10.s64 + -1075;
	// b 0x8b0cd678
	goto loc_8B0CD678;
loc_8B0CD670:
	// rlwinm r11,r11,28,20,31
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 28) & 0xFFF;
	// addi r10,r11,-1022
	ctx.r10.s64 = ctx.r11.s64 + -1022;
loc_8B0CD678:
	// lis r11,-29943
	ctx.r11.s64 = -1962344448;
	// stfd f1,-16(r1)
	ctx.fpscr.disableFlushMode();
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.f1.u64);
	// andi. r9,r9,32783
	ctx.r9.u64 = ctx.r9.u64 & 32783;
	ctx.cr0.compare<int32_t>(ctx.r9.s32, 0, ctx.xer);
	// addi r11,r11,-24928
	ctx.r11.s64 = ctx.r11.s64 + -24928;
	// ori r9,r9,16352
	ctx.r9.u64 = ctx.r9.u64 | 16352;
	// sth r9,-16(r1)
	REX_STORE_U16(ctx.r1.u32 + -16, ctx.r9.u16);
	// lfd f13,-16(r1)
	ctx.f13.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// lis r9,-29943
	ctx.r9.s64 = -1962344448;
	// lfd f0,0(r11)
	ctx.f0.u64 = REX_LOAD_U64(ctx.r11.u32 + 0);
	// fcmpu cr6,f13,f0
	ctx.cr6.compare(ctx.f13.f64, ctx.f0.f64);
	// ble cr6,0x8b0cd6bc
	if (!ctx.cr6.gt) goto loc_8B0CD6BC;
	// lfd f0,-29624(r9)
	ctx.f0.u64 = REX_LOAD_U64(ctx.r9.u32 + -29624);
	// fadd f12,f13,f6
	ctx.f12.f64 = ctx.f13.f64 + ctx.f6.f64;
	// fsub f11,f13,f0
	ctx.f11.f64 = ctx.f13.f64 - ctx.f0.f64;
	// fmul f13,f12,f0
	ctx.f13.f64 = ctx.f12.f64 * ctx.f0.f64;
	// fsub f0,f11,f0
	ctx.f0.f64 = ctx.f11.f64 - ctx.f0.f64;
	// b 0x8b0cd6d0
	goto loc_8B0CD6D0;
loc_8B0CD6BC:
	// lfd f12,-29624(r9)
	ctx.fpscr.disableFlushMode();
	ctx.f12.u64 = REX_LOAD_U64(ctx.r9.u32 + -29624);
	// addi r10,r10,-1
	ctx.r10.s64 = ctx.r10.s64 + -1;
	// fsub f0,f13,f12
	ctx.f0.f64 = ctx.f13.f64 - ctx.f12.f64;
	// fadd f13,f0,f6
	ctx.f13.f64 = ctx.f0.f64 + ctx.f6.f64;
	// fmul f13,f13,f12
	ctx.f13.f64 = ctx.f13.f64 * ctx.f12.f64;
loc_8B0CD6D0:
	// fdiv f5,f0,f13
	ctx.fpscr.disableFlushMode();
	ctx.f5.f64 = ctx.f0.f64 / ctx.f13.f64;
	// lis r9,-29943
	ctx.r9.s64 = -1962344448;
	// lis r8,-29943
	ctx.r8.s64 = -1962344448;
	// lfd f12,40(r11)
	ctx.f12.u64 = REX_LOAD_U64(ctx.r11.u32 + 40);
	// lis r7,-29943
	ctx.r7.s64 = -1962344448;
	// lfd f9,64(r11)
	ctx.f9.u64 = REX_LOAD_U64(ctx.r11.u32 + 64);
	// lis r6,-29943
	ctx.r6.s64 = -1962344448;
	// lfd f7,8(r11)
	ctx.f7.u64 = REX_LOAD_U64(ctx.r11.u32 + 8);
	// extsw r11,r10
	ctx.r11.s64 = ctx.r10.s32;
	// lfd f13,-24816(r9)
	ctx.f13.u64 = REX_LOAD_U64(ctx.r9.u32 + -24816);
	// lis r10,-29943
	ctx.r10.s64 = -1962344448;
	// lfd f11,-24824(r8)
	ctx.f11.u64 = REX_LOAD_U64(ctx.r8.u32 + -24824);
	// std r11,-16(r1)
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.r11.u64);
	// lfd f10,-24832(r7)
	ctx.f10.u64 = REX_LOAD_U64(ctx.r7.u32 + -24832);
	// lfd f8,-24840(r6)
	ctx.f8.u64 = REX_LOAD_U64(ctx.r6.u32 + -24840);
	// lfd f0,-16(r1)
	ctx.f0.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// fcfid f4,f0
	ctx.f4.f64 = double(ctx.f0.s64);
	// fmul f3,f5,f5
	ctx.f3.f64 = ctx.f5.f64 * ctx.f5.f64;
	// lfd f0,-24848(r10)
	ctx.f0.u64 = REX_LOAD_U64(ctx.r10.u32 + -24848);
	// fmul f0,f4,f0
	ctx.f0.f64 = ctx.f4.f64 * ctx.f0.f64;
	// fnmsub f13,f3,f13,f12
	ctx.f13.f64 = -std::fma(ctx.f3.f64, ctx.f13.f64, -ctx.f12.f64);
	// fsub f12,f3,f11
	ctx.f12.f64 = ctx.f3.f64 - ctx.f11.f64;
	// fmsub f13,f13,f3,f10
	ctx.f13.f64 = std::fma(ctx.f13.f64, ctx.f3.f64, -ctx.f10.f64);
	// fmadd f12,f12,f3,f9
	ctx.f12.f64 = std::fma(ctx.f12.f64, ctx.f3.f64, ctx.f9.f64);
	// fmul f13,f13,f3
	ctx.f13.f64 = ctx.f13.f64 * ctx.f3.f64;
	// fmsub f12,f12,f3,f8
	ctx.f12.f64 = std::fma(ctx.f12.f64, ctx.f3.f64, -ctx.f8.f64);
	// fdiv f13,f13,f12
	ctx.f13.f64 = ctx.f13.f64 / ctx.f12.f64;
	// fadd f13,f13,f6
	ctx.f13.f64 = ctx.f13.f64 + ctx.f6.f64;
	// fmsub f0,f13,f5,f0
	ctx.f0.f64 = std::fma(ctx.f13.f64, ctx.f5.f64, -ctx.f0.f64);
	// fmadd f1,f4,f7,f0
	ctx.f1.f64 = std::fma(ctx.f4.f64, ctx.f7.f64, ctx.f0.f64);
	// blr 
	return;
}

DEFINE_REX_FUNC(__savefpr_16) {
	REX_FUNC_PROLOGUE();
	// stfd f16,-128(r12)
	ctx.fpscr.disableFlushMode();
	REX_STORE_U64(ctx.r12.u32 + -128, ctx.f16.u64);
	// stfd f17,-120(r12)
	REX_STORE_U64(ctx.r12.u32 + -120, ctx.f17.u64);
	// stfd f18,-112(r12)
	REX_STORE_U64(ctx.r12.u32 + -112, ctx.f18.u64);
	// stfd f19,-104(r12)
	REX_STORE_U64(ctx.r12.u32 + -104, ctx.f19.u64);
	// stfd f20,-96(r12)
	REX_STORE_U64(ctx.r12.u32 + -96, ctx.f20.u64);
	// stfd f21,-88(r12)
	REX_STORE_U64(ctx.r12.u32 + -88, ctx.f21.u64);
	// stfd f22,-80(r12)
	REX_STORE_U64(ctx.r12.u32 + -80, ctx.f22.u64);
	// stfd f23,-72(r12)
	REX_STORE_U64(ctx.r12.u32 + -72, ctx.f23.u64);
	// stfd f24,-64(r12)
	REX_STORE_U64(ctx.r12.u32 + -64, ctx.f24.u64);
	// stfd f25,-56(r12)
	REX_STORE_U64(ctx.r12.u32 + -56, ctx.f25.u64);
	// stfd f26,-48(r12)
	REX_STORE_U64(ctx.r12.u32 + -48, ctx.f26.u64);
	// stfd f27,-40(r12)
	REX_STORE_U64(ctx.r12.u32 + -40, ctx.f27.u64);
	// stfd f28,-32(r12)
	REX_STORE_U64(ctx.r12.u32 + -32, ctx.f28.u64);
	// stfd f29,-24(r12)
	REX_STORE_U64(ctx.r12.u32 + -24, ctx.f29.u64);
	// stfd f30,-16(r12)
	REX_STORE_U64(ctx.r12.u32 + -16, ctx.f30.u64);
	// stfd f31,-8(r12)
	REX_STORE_U64(ctx.r12.u32 + -8, ctx.f31.u64);
	// blr 
	return;
}

DEFINE_REX_FUNC(__savefpr_18) {
	REX_FUNC_PROLOGUE();
	// stfd f18,-112(r12)
	ctx.fpscr.disableFlushMode();
	REX_STORE_U64(ctx.r12.u32 + -112, ctx.f18.u64);
	// stfd f19,-104(r12)
	REX_STORE_U64(ctx.r12.u32 + -104, ctx.f19.u64);
	// stfd f20,-96(r12)
	REX_STORE_U64(ctx.r12.u32 + -96, ctx.f20.u64);
	// stfd f21,-88(r12)
	REX_STORE_U64(ctx.r12.u32 + -88, ctx.f21.u64);
	// stfd f22,-80(r12)
	REX_STORE_U64(ctx.r12.u32 + -80, ctx.f22.u64);
	// stfd f23,-72(r12)
	REX_STORE_U64(ctx.r12.u32 + -72, ctx.f23.u64);
	// stfd f24,-64(r12)
	REX_STORE_U64(ctx.r12.u32 + -64, ctx.f24.u64);
	// stfd f25,-56(r12)
	REX_STORE_U64(ctx.r12.u32 + -56, ctx.f25.u64);
	// stfd f26,-48(r12)
	REX_STORE_U64(ctx.r12.u32 + -48, ctx.f26.u64);
	// stfd f27,-40(r12)
	REX_STORE_U64(ctx.r12.u32 + -40, ctx.f27.u64);
	// stfd f28,-32(r12)
	REX_STORE_U64(ctx.r12.u32 + -32, ctx.f28.u64);
	// stfd f29,-24(r12)
	REX_STORE_U64(ctx.r12.u32 + -24, ctx.f29.u64);
	// stfd f30,-16(r12)
	REX_STORE_U64(ctx.r12.u32 + -16, ctx.f30.u64);
	// stfd f31,-8(r12)
	REX_STORE_U64(ctx.r12.u32 + -8, ctx.f31.u64);
	// blr 
	return;
}

DEFINE_REX_FUNC(__savefpr_21) {
	REX_FUNC_PROLOGUE();
	// stfd f21,-88(r12)
	ctx.fpscr.disableFlushMode();
	REX_STORE_U64(ctx.r12.u32 + -88, ctx.f21.u64);
	// stfd f22,-80(r12)
	REX_STORE_U64(ctx.r12.u32 + -80, ctx.f22.u64);
	// stfd f23,-72(r12)
	REX_STORE_U64(ctx.r12.u32 + -72, ctx.f23.u64);
	// stfd f24,-64(r12)
	REX_STORE_U64(ctx.r12.u32 + -64, ctx.f24.u64);
	// stfd f25,-56(r12)
	REX_STORE_U64(ctx.r12.u32 + -56, ctx.f25.u64);
	// stfd f26,-48(r12)
	REX_STORE_U64(ctx.r12.u32 + -48, ctx.f26.u64);
	// stfd f27,-40(r12)
	REX_STORE_U64(ctx.r12.u32 + -40, ctx.f27.u64);
	// stfd f28,-32(r12)
	REX_STORE_U64(ctx.r12.u32 + -32, ctx.f28.u64);
	// stfd f29,-24(r12)
	REX_STORE_U64(ctx.r12.u32 + -24, ctx.f29.u64);
	// stfd f30,-16(r12)
	REX_STORE_U64(ctx.r12.u32 + -16, ctx.f30.u64);
	// stfd f31,-8(r12)
	REX_STORE_U64(ctx.r12.u32 + -8, ctx.f31.u64);
	// blr 
	return;
}

DEFINE_REX_FUNC(__savefpr_24) {
	REX_FUNC_PROLOGUE();
	// stfd f24,-64(r12)
	ctx.fpscr.disableFlushMode();
	REX_STORE_U64(ctx.r12.u32 + -64, ctx.f24.u64);
	// stfd f25,-56(r12)
	REX_STORE_U64(ctx.r12.u32 + -56, ctx.f25.u64);
	// stfd f26,-48(r12)
	REX_STORE_U64(ctx.r12.u32 + -48, ctx.f26.u64);
	// stfd f27,-40(r12)
	REX_STORE_U64(ctx.r12.u32 + -40, ctx.f27.u64);
	// stfd f28,-32(r12)
	REX_STORE_U64(ctx.r12.u32 + -32, ctx.f28.u64);
	// stfd f29,-24(r12)
	REX_STORE_U64(ctx.r12.u32 + -24, ctx.f29.u64);
	// stfd f30,-16(r12)
	REX_STORE_U64(ctx.r12.u32 + -16, ctx.f30.u64);
	// stfd f31,-8(r12)
	REX_STORE_U64(ctx.r12.u32 + -8, ctx.f31.u64);
	// blr 
	return;
}

DEFINE_REX_FUNC(__savefpr_27) {
	REX_FUNC_PROLOGUE();
	// stfd f27,-40(r12)
	ctx.fpscr.disableFlushMode();
	REX_STORE_U64(ctx.r12.u32 + -40, ctx.f27.u64);
	// stfd f28,-32(r12)
	REX_STORE_U64(ctx.r12.u32 + -32, ctx.f28.u64);
	// stfd f29,-24(r12)
	REX_STORE_U64(ctx.r12.u32 + -24, ctx.f29.u64);
	// stfd f30,-16(r12)
	REX_STORE_U64(ctx.r12.u32 + -16, ctx.f30.u64);
	// stfd f31,-8(r12)
	REX_STORE_U64(ctx.r12.u32 + -8, ctx.f31.u64);
	// blr 
	return;
}

DEFINE_REX_FUNC(__savefpr_31) {
	REX_FUNC_PROLOGUE();
	// stfd f31,-8(r12)
	ctx.fpscr.disableFlushMode();
	REX_STORE_U64(ctx.r12.u32 + -8, ctx.f31.u64);
	// blr 
	return;
}

DEFINE_REX_FUNC(__restfpr_14) {
	REX_FUNC_PROLOGUE();
	// lfd f14,-144(r12)
	ctx.fpscr.disableFlushMode();
	ctx.f14.u64 = REX_LOAD_U64(ctx.r12.u32 + -144);
	// lfd f15,-136(r12)
	ctx.f15.u64 = REX_LOAD_U64(ctx.r12.u32 + -136);
	// lfd f16,-128(r12)
	ctx.f16.u64 = REX_LOAD_U64(ctx.r12.u32 + -128);
	// lfd f17,-120(r12)
	ctx.f17.u64 = REX_LOAD_U64(ctx.r12.u32 + -120);
	// lfd f18,-112(r12)
	ctx.f18.u64 = REX_LOAD_U64(ctx.r12.u32 + -112);
	// lfd f19,-104(r12)
	ctx.f19.u64 = REX_LOAD_U64(ctx.r12.u32 + -104);
	// lfd f20,-96(r12)
	ctx.f20.u64 = REX_LOAD_U64(ctx.r12.u32 + -96);
	// lfd f21,-88(r12)
	ctx.f21.u64 = REX_LOAD_U64(ctx.r12.u32 + -88);
	// lfd f22,-80(r12)
	ctx.f22.u64 = REX_LOAD_U64(ctx.r12.u32 + -80);
	// lfd f23,-72(r12)
	ctx.f23.u64 = REX_LOAD_U64(ctx.r12.u32 + -72);
	// lfd f24,-64(r12)
	ctx.f24.u64 = REX_LOAD_U64(ctx.r12.u32 + -64);
	// lfd f25,-56(r12)
	ctx.f25.u64 = REX_LOAD_U64(ctx.r12.u32 + -56);
	// lfd f26,-48(r12)
	ctx.f26.u64 = REX_LOAD_U64(ctx.r12.u32 + -48);
	// lfd f27,-40(r12)
	ctx.f27.u64 = REX_LOAD_U64(ctx.r12.u32 + -40);
	// lfd f28,-32(r12)
	ctx.f28.u64 = REX_LOAD_U64(ctx.r12.u32 + -32);
	// lfd f29,-24(r12)
	ctx.f29.u64 = REX_LOAD_U64(ctx.r12.u32 + -24);
	// lfd f30,-16(r12)
	ctx.f30.u64 = REX_LOAD_U64(ctx.r12.u32 + -16);
	// lfd f31,-8(r12)
	ctx.f31.u64 = REX_LOAD_U64(ctx.r12.u32 + -8);
	// blr 
	return;
}

DEFINE_REX_FUNC(__restfpr_20) {
	REX_FUNC_PROLOGUE();
	// lfd f20,-96(r12)
	ctx.fpscr.disableFlushMode();
	ctx.f20.u64 = REX_LOAD_U64(ctx.r12.u32 + -96);
	// lfd f21,-88(r12)
	ctx.f21.u64 = REX_LOAD_U64(ctx.r12.u32 + -88);
	// lfd f22,-80(r12)
	ctx.f22.u64 = REX_LOAD_U64(ctx.r12.u32 + -80);
	// lfd f23,-72(r12)
	ctx.f23.u64 = REX_LOAD_U64(ctx.r12.u32 + -72);
	// lfd f24,-64(r12)
	ctx.f24.u64 = REX_LOAD_U64(ctx.r12.u32 + -64);
	// lfd f25,-56(r12)
	ctx.f25.u64 = REX_LOAD_U64(ctx.r12.u32 + -56);
	// lfd f26,-48(r12)
	ctx.f26.u64 = REX_LOAD_U64(ctx.r12.u32 + -48);
	// lfd f27,-40(r12)
	ctx.f27.u64 = REX_LOAD_U64(ctx.r12.u32 + -40);
	// lfd f28,-32(r12)
	ctx.f28.u64 = REX_LOAD_U64(ctx.r12.u32 + -32);
	// lfd f29,-24(r12)
	ctx.f29.u64 = REX_LOAD_U64(ctx.r12.u32 + -24);
	// lfd f30,-16(r12)
	ctx.f30.u64 = REX_LOAD_U64(ctx.r12.u32 + -16);
	// lfd f31,-8(r12)
	ctx.f31.u64 = REX_LOAD_U64(ctx.r12.u32 + -8);
	// blr 
	return;
}

DEFINE_REX_FUNC(__restfpr_21) {
	REX_FUNC_PROLOGUE();
	// lfd f21,-88(r12)
	ctx.fpscr.disableFlushMode();
	ctx.f21.u64 = REX_LOAD_U64(ctx.r12.u32 + -88);
	// lfd f22,-80(r12)
	ctx.f22.u64 = REX_LOAD_U64(ctx.r12.u32 + -80);
	// lfd f23,-72(r12)
	ctx.f23.u64 = REX_LOAD_U64(ctx.r12.u32 + -72);
	// lfd f24,-64(r12)
	ctx.f24.u64 = REX_LOAD_U64(ctx.r12.u32 + -64);
	// lfd f25,-56(r12)
	ctx.f25.u64 = REX_LOAD_U64(ctx.r12.u32 + -56);
	// lfd f26,-48(r12)
	ctx.f26.u64 = REX_LOAD_U64(ctx.r12.u32 + -48);
	// lfd f27,-40(r12)
	ctx.f27.u64 = REX_LOAD_U64(ctx.r12.u32 + -40);
	// lfd f28,-32(r12)
	ctx.f28.u64 = REX_LOAD_U64(ctx.r12.u32 + -32);
	// lfd f29,-24(r12)
	ctx.f29.u64 = REX_LOAD_U64(ctx.r12.u32 + -24);
	// lfd f30,-16(r12)
	ctx.f30.u64 = REX_LOAD_U64(ctx.r12.u32 + -16);
	// lfd f31,-8(r12)
	ctx.f31.u64 = REX_LOAD_U64(ctx.r12.u32 + -8);
	// blr 
	return;
}

DEFINE_REX_FUNC(__restfpr_28) {
	REX_FUNC_PROLOGUE();
	// lfd f28,-32(r12)
	ctx.fpscr.disableFlushMode();
	ctx.f28.u64 = REX_LOAD_U64(ctx.r12.u32 + -32);
	// lfd f29,-24(r12)
	ctx.f29.u64 = REX_LOAD_U64(ctx.r12.u32 + -24);
	// lfd f30,-16(r12)
	ctx.f30.u64 = REX_LOAD_U64(ctx.r12.u32 + -16);
	// lfd f31,-8(r12)
	ctx.f31.u64 = REX_LOAD_U64(ctx.r12.u32 + -8);
	// blr 
	return;
}

DEFINE_REX_FUNC(__restfpr_29) {
	REX_FUNC_PROLOGUE();
	// lfd f29,-24(r12)
	ctx.fpscr.disableFlushMode();
	ctx.f29.u64 = REX_LOAD_U64(ctx.r12.u32 + -24);
	// lfd f30,-16(r12)
	ctx.f30.u64 = REX_LOAD_U64(ctx.r12.u32 + -16);
	// lfd f31,-8(r12)
	ctx.f31.u64 = REX_LOAD_U64(ctx.r12.u32 + -8);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0CDFF8) {
	REX_FUNC_PROLOGUE();
	// li r5,10
	ctx.r5.s64 = 10;
	// li r4,0
	ctx.r4.s64 = 0;
	// b 0x8b0d37d8
	sub_8B0D37D8(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0CE0C0) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// std r5,32(r1)
	REX_STORE_U64(ctx.r1.u32 + 32, ctx.r5.u64);
	// std r6,40(r1)
	REX_STORE_U64(ctx.r1.u32 + 40, ctx.r6.u64);
	// std r7,48(r1)
	REX_STORE_U64(ctx.r1.u32 + 48, ctx.r7.u64);
	// std r8,56(r1)
	REX_STORE_U64(ctx.r1.u32 + 56, ctx.r8.u64);
	// std r9,64(r1)
	REX_STORE_U64(ctx.r1.u32 + 64, ctx.r9.u64);
	// std r10,72(r1)
	REX_STORE_U64(ctx.r1.u32 + 72, ctx.r10.u64);
	// stwu r1,-96(r1)
	ea = -96 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// addi r11,r1,80
	ctx.r11.s64 = ctx.r1.s64 + 80;
	// lis r10,-29939
	ctx.r10.s64 = -1962082304;
	// mr r5,r4
	ctx.r5.u64 = ctx.r4.u64;
	// addi r9,r1,128
	ctx.r9.s64 = ctx.r1.s64 + 128;
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// li r6,0
	ctx.r6.s64 = 0;
	// stw r9,0(r11)
	REX_STORE_U32(ctx.r11.u32 + 0, ctx.r9.u32);
	// addi r3,r10,14472
	ctx.r3.s64 = ctx.r10.s64 + 14472;
	// lwz r7,80(r1)
	ctx.r7.u64 = REX_LOAD_U32(ctx.r1.u32 + 80);
	// bl 0x8b0ce008
	ctx.lr = 0x8B0CE10C;
	sub_8B0CE008(ctx, base);
	// addi r1,r1,96
	ctx.r1.s64 = ctx.r1.s64 + 96;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0CE1D8) {
	REX_FUNC_PROLOGUE();
	// li r4,0
	ctx.r4.s64 = 0;
	// b 0x8b0ce120
	sub_8B0CE120(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0CE1E0) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// std r30,-24(r1)
	REX_STORE_U64(ctx.r1.u32 + -24, ctx.r30.u64);
	// std r31,-16(r1)
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.r31.u64);
	// stwu r1,-128(r1)
	ea = -128 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// bne cr6,0x8b0ce230
	if (!ctx.cr6.eq) goto loc_8B0CE230;
	// bl 0x8b0d0288
	ctx.lr = 0x8B0CE204;
	sub_8B0D0288(ctx, base);
	// li r11,22
	ctx.r11.s64 = 22;
	// li r7,0
	ctx.r7.s64 = 0;
	// stw r11,0(r3)
	REX_STORE_U32(ctx.r3.u32 + 0, ctx.r11.u32);
	// li r6,0
	ctx.r6.s64 = 0;
	// li r5,0
	ctx.r5.s64 = 0;
	// li r4,0
	ctx.r4.s64 = 0;
	// li r3,0
	ctx.r3.s64 = 0;
	// bl 0x8b0d0148
	ctx.lr = 0x8B0CE224;
	sub_8B0D0148(ctx, base);
	// lis r11,-29943
	ctx.r11.s64 = -1962344448;
	// lfd f1,-32656(r11)
	ctx.fpscr.disableFlushMode();
	ctx.f1.u64 = REX_LOAD_U64(ctx.r11.u32 + -32656);
	// b 0x8b0ce2c0
	goto loc_8B0CE2C0;
loc_8B0CE230:
	// lis r11,-29938
	ctx.r11.s64 = -1962016768;
	// addi r30,r11,12512
	ctx.r30.s64 = ctx.r11.s64 + 12512;
	// lwz r11,12512(r11)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r11.u32 + 12512);
loc_8B0CE23C:
	// lwz r10,172(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 172);
	// cmpwi cr6,r10,1
	ctx.cr6.compare<int32_t>(ctx.r10.s32, 1, ctx.xer);
	// ble cr6,0x8b0ce260
	if (!ctx.cr6.gt) goto loc_8B0CE260;
	// mr r5,r30
	ctx.r5.u64 = ctx.r30.u64;
	// lbz r3,0(r31)
	ctx.r3.u64 = REX_LOAD_U8(ctx.r31.u32 + 0);
	// li r4,8
	ctx.r4.s64 = 8;
	// bl 0x8b0d13a8
	ctx.lr = 0x8B0CE258;
	sub_8B0D13A8(ctx, base);
	// lwz r11,0(r30)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r30.u32 + 0);
	// b 0x8b0ce274
	goto loc_8B0CE274;
loc_8B0CE260:
	// lbz r10,0(r31)
	ctx.r10.u64 = REX_LOAD_U8(ctx.r31.u32 + 0);
	// lwz r9,200(r11)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r11.u32 + 200);
	// rotlwi r10,r10,1
	ctx.r10.u64 = __builtin_rotateleft32(ctx.r10.u32, 1);
	// lhzx r10,r10,r9
	ctx.r10.u64 = REX_LOAD_U16(ctx.r10.u32 + ctx.r9.u32);
	// rlwinm r3,r10,0,28,28
	ctx.r3.u64 = __builtin_rotateleft64(ctx.r10.u32 | (ctx.r10.u64 << 32), 0) & 0x8;
loc_8B0CE274:
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// beq cr6,0x8b0ce284
	if (ctx.cr6.eq) goto loc_8B0CE284;
	// addi r31,r31,1
	ctx.r31.s64 = ctx.r31.s64 + 1;
	// b 0x8b0ce23c
	goto loc_8B0CE23C;
loc_8B0CE284:
	// mr r11,r31
	ctx.r11.u64 = ctx.r31.u64;
loc_8B0CE288:
	// lbz r10,0(r11)
	ctx.r10.u64 = REX_LOAD_U8(ctx.r11.u32 + 0);
	// addi r11,r11,1
	ctx.r11.s64 = ctx.r11.s64 + 1;
	// cmplwi cr6,r10,0
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 0, ctx.xer);
	// bne cr6,0x8b0ce288
	if (!ctx.cr6.eq) goto loc_8B0CE288;
	// subf r11,r31,r11
	ctx.r11.u64 = ctx.r11.u64 - ctx.r31.u64;
	// mr r8,r30
	ctx.r8.u64 = ctx.r30.u64;
	// addi r11,r11,-1
	ctx.r11.s64 = ctx.r11.s64 + -1;
	// li r7,0
	ctx.r7.s64 = 0;
	// rotlwi r5,r11,0
	ctx.r5.u64 = __builtin_rotateleft32(ctx.r11.u32, 0);
	// li r6,0
	ctx.r6.s64 = 0;
	// mr r4,r31
	ctx.r4.u64 = ctx.r31.u64;
	// addi r3,r1,80
	ctx.r3.s64 = ctx.r1.s64 + 80;
	// bl 0x8b0d5358
	ctx.lr = 0x8B0CE2BC;
	sub_8B0D5358(ctx, base);
	// lfd f1,16(r3)
	ctx.fpscr.disableFlushMode();
	ctx.f1.u64 = REX_LOAD_U64(ctx.r3.u32 + 16);
loc_8B0CE2C0:
	// addi r1,r1,128
	ctx.r1.s64 = ctx.r1.s64 + 128;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// ld r30,-24(r1)
	ctx.r30.u64 = REX_LOAD_U64(ctx.r1.u32 + -24);
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0CE808) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mr r11,r3
	ctx.r11.u64 = ctx.r3.u64;
loc_8B0CE80C:
	// lbz r10,0(r11)
	ctx.r10.u64 = REX_LOAD_U8(ctx.r11.u32 + 0);
	// addi r11,r11,1
	ctx.r11.s64 = ctx.r11.s64 + 1;
	// cmplwi r10,0
	ctx.cr0.compare<uint32_t>(ctx.r10.u32, 0, ctx.xer);
	// bne 0x8b0ce80c
	if (!ctx.cr0.eq) goto loc_8B0CE80C;
	// addi r11,r11,-1
	ctx.r11.s64 = ctx.r11.s64 + -1;
	// cmplwi cr6,r5,0
	ctx.cr6.compare<uint32_t>(ctx.r5.u32, 0, ctx.xer);
	// beq cr6,0x8b0ce84c
	if (ctx.cr6.eq) goto loc_8B0CE84C;
	// addi r9,r4,-1
	ctx.r9.s64 = ctx.r4.s64 + -1;
loc_8B0CE82C:
	// lbzu r10,1(r9)
	ea = 1 + ctx.r9.u32;
	ctx.r10.u64 = REX_LOAD_U8(ea);
	ctx.r9.u32 = ea;
	// addi r5,r5,-1
	ctx.r5.s64 = ctx.r5.s64 + -1;
	// cmplwi r10,0
	ctx.cr0.compare<uint32_t>(ctx.r10.u32, 0, ctx.xer);
	// stb r10,0(r11)
	REX_STORE_U8(ctx.r11.u32 + 0, ctx.r10.u8);
	// addi r11,r11,1
	ctx.r11.s64 = ctx.r11.s64 + 1;
	// beqlr 
	if (ctx.cr0.eq) return;
	// cmplwi cr6,r5,0
	ctx.cr6.compare<uint32_t>(ctx.r5.u32, 0, ctx.xer);
	// bne cr6,0x8b0ce82c
	if (!ctx.cr6.eq) goto loc_8B0CE82C;
loc_8B0CE84C:
	// li r10,0
	ctx.r10.s64 = 0;
	// stb r10,0(r11)
	REX_STORE_U8(ctx.r11.u32 + 0, ctx.r10.u8);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0CE8B8) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// std r30,-24(r1)
	REX_STORE_U64(ctx.r1.u32 + -24, ctx.r30.u64);
	// std r31,-16(r1)
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.r31.u64);
	// stwu r1,-144(r1)
	ea = -144 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// mr r11,r5
	ctx.r11.u64 = ctx.r5.u64;
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// mr r5,r6
	ctx.r5.u64 = ctx.r6.u64;
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// bne cr6,0x8b0ce90c
	if (!ctx.cr6.eq) goto loc_8B0CE90C;
loc_8B0CE8E0:
	// bl 0x8b0d0288
	ctx.lr = 0x8B0CE8E4;
	sub_8B0D0288(ctx, base);
	// li r11,22
	ctx.r11.s64 = 22;
	// li r7,0
	ctx.r7.s64 = 0;
	// stw r11,0(r3)
	REX_STORE_U32(ctx.r3.u32 + 0, ctx.r11.u32);
	// li r6,0
	ctx.r6.s64 = 0;
	// li r5,0
	ctx.r5.s64 = 0;
	// li r4,0
	ctx.r4.s64 = 0;
	// li r3,0
	ctx.r3.s64 = 0;
	// bl 0x8b0d0148
	ctx.lr = 0x8B0CE904;
	sub_8B0D0148(ctx, base);
	// li r3,-1
	ctx.r3.s64 = -1;
	// b 0x8b0ce9d0
	goto loc_8B0CE9D0;
loc_8B0CE90C:
	// cmplwi cr6,r4,0
	ctx.cr6.compare<uint32_t>(ctx.r4.u32, 0, ctx.xer);
	// beq cr6,0x8b0ce91c
	if (ctx.cr6.eq) goto loc_8B0CE91C;
	// cmplwi cr6,r31,0
	ctx.cr6.compare<uint32_t>(ctx.r31.u32, 0, ctx.xer);
	// beq cr6,0x8b0ce8e0
	if (ctx.cr6.eq) goto loc_8B0CE8E0;
loc_8B0CE91C:
	// lis r10,16383
	ctx.r10.s64 = 1073676288;
	// stw r31,88(r1)
	REX_STORE_U32(ctx.r1.u32 + 88, ctx.r31.u32);
	// li r9,66
	ctx.r9.s64 = 66;
	// stw r31,80(r1)
	REX_STORE_U32(ctx.r1.u32 + 80, ctx.r31.u32);
	// ori r10,r10,65535
	ctx.r10.u64 = ctx.r10.u64 | 65535;
	// stw r9,92(r1)
	REX_STORE_U32(ctx.r1.u32 + 92, ctx.r9.u32);
	// cmplw cr6,r4,r10
	ctx.cr6.compare<uint32_t>(ctx.r4.u32, ctx.r10.u32, ctx.xer);
	// ble cr6,0x8b0ce948
	if (!ctx.cr6.gt) goto loc_8B0CE948;
	// lis r10,32767
	ctx.r10.s64 = 2147418112;
	// ori r10,r10,65535
	ctx.r10.u64 = ctx.r10.u64 | 65535;
	// b 0x8b0ce94c
	goto loc_8B0CE94C;
loc_8B0CE948:
	// rlwinm r10,r4,1,0,30
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r4.u32 | (ctx.r4.u64 << 32), 1) & 0xFFFFFFFE;
loc_8B0CE94C:
	// stw r10,84(r1)
	REX_STORE_U32(ctx.r1.u32 + 84, ctx.r10.u32);
	// mr r6,r7
	ctx.r6.u64 = ctx.r7.u64;
	// mr r4,r11
	ctx.r4.u64 = ctx.r11.u64;
	// addi r3,r1,80
	ctx.r3.s64 = ctx.r1.s64 + 80;
	// bl 0x8b0d2ac8
	ctx.lr = 0x8B0CE960;
	sub_8B0D2AC8(ctx, base);
	// mr r30,r3
	ctx.r30.u64 = ctx.r3.u64;
	// cmplwi cr6,r31,0
	ctx.cr6.compare<uint32_t>(ctx.r31.u32, 0, ctx.xer);
	// beq cr6,0x8b0ce9cc
	if (ctx.cr6.eq) goto loc_8B0CE9CC;
	// lwz r11,84(r1)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r1.u32 + 84);
	// li r31,0
	ctx.r31.s64 = 0;
	// addic. r11,r11,-1
	ctx.xer.ca = ctx.r11.u32 > 0;
	ctx.r11.s64 = ctx.r11.s64 + -1;
	ctx.cr0.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// stw r11,84(r1)
	REX_STORE_U32(ctx.r1.u32 + 84, ctx.r11.u32);
	// blt 0x8b0ce998
	if (ctx.cr0.lt) goto loc_8B0CE998;
	// lwz r11,80(r1)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r1.u32 + 80);
	// stb r31,0(r11)
	REX_STORE_U8(ctx.r11.u32 + 0, ctx.r31.u8);
	// lwz r11,80(r1)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r1.u32 + 80);
	// addi r10,r11,1
	ctx.r10.s64 = ctx.r11.s64 + 1;
	// stw r10,80(r1)
	REX_STORE_U32(ctx.r1.u32 + 80, ctx.r10.u32);
	// b 0x8b0ce9a8
	goto loc_8B0CE9A8;
loc_8B0CE998:
	// addi r4,r1,80
	ctx.r4.s64 = ctx.r1.s64 + 80;
	// li r3,0
	ctx.r3.s64 = 0;
	// bl 0x8b0cf2e0
	ctx.lr = 0x8B0CE9A4;
	sub_8B0CF2E0(ctx, base);
	// lwz r10,80(r1)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r1.u32 + 80);
loc_8B0CE9A8:
	// lwz r11,84(r1)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r1.u32 + 84);
	// addic. r11,r11,-1
	ctx.xer.ca = ctx.r11.u32 > 0;
	ctx.r11.s64 = ctx.r11.s64 + -1;
	ctx.cr0.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// stw r11,84(r1)
	REX_STORE_U32(ctx.r1.u32 + 84, ctx.r11.u32);
	// blt 0x8b0ce9c0
	if (ctx.cr0.lt) goto loc_8B0CE9C0;
	// stb r31,0(r10)
	REX_STORE_U8(ctx.r10.u32 + 0, ctx.r31.u8);
	// b 0x8b0ce9cc
	goto loc_8B0CE9CC;
loc_8B0CE9C0:
	// addi r4,r1,80
	ctx.r4.s64 = ctx.r1.s64 + 80;
	// li r3,0
	ctx.r3.s64 = 0;
	// bl 0x8b0cf2e0
	ctx.lr = 0x8B0CE9CC;
	sub_8B0CF2E0(ctx, base);
loc_8B0CE9CC:
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
loc_8B0CE9D0:
	// addi r1,r1,144
	ctx.r1.s64 = ctx.r1.s64 + 144;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// ld r30,-24(r1)
	ctx.r30.u64 = REX_LOAD_U64(ctx.r1.u32 + -24);
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0CECAC) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// std r31,-8(r1)
	REX_STORE_U64(ctx.r1.u32 + -8, ctx.r31.u64);
	// addi r31,r12,-176
	ctx.r31.s64 = ctx.r12.s64 + -176;
	// std r24,-16(r1)
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.r24.u64);
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-24(r1)
	REX_STORE_U32(ctx.r1.u32 + -24, ctx.r12.u32);
	// stwu r1,-112(r1)
	ea = -112 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// cmpwi cr6,r24,0
	ctx.cr6.compare<int32_t>(ctx.r24.s32, 0, ctx.xer);
	// beq cr6,0x8b0cecd4
	if (ctx.cr6.eq) goto loc_8B0CECD4;
	// li r3,8
	ctx.r3.s64 = 8;
	// bl 0x8b0d5e60
	ctx.lr = 0x8B0CECD4;
	sub_8B0D5E60(ctx, base);
loc_8B0CECD4:
	// lwz r1,0(r1)
	ctx.r1.u64 = REX_LOAD_U32(ctx.r1.u32 + 0);
	// ld r31,-8(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -8);
	// ld r24,-16(r1)
	ctx.r24.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// lwz r12,-24(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -24);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0CEDB8) {
	REX_FUNC_PROLOGUE();
	PPCRegister temp{};
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9bc
	ctx.lr = 0x8B0CEDC0;
	__savegprlr_29(ctx, base);
	// stwu r1,-112(r1)
	ea = -112 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// bl 0x8b0dc5d8
	ctx.lr = 0x8B0CEDC8;
	sub_8B0DC5D8(ctx, base);
	// lis r30,-29938
	ctx.r30.s64 = -1962016768;
	// mr r29,r3
	ctx.r29.u64 = ctx.r3.u64;
	// lwz r3,11652(r30)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r30.u32 + 11652);
	// bl 0x8b0df5e8
	ctx.lr = 0x8B0CEDD8;
	__imp__KeTlsGetValue(ctx, base);
	// mr. r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	ctx.cr0.compare<int32_t>(ctx.r31.s32, 0, ctx.xer);
	// bne 0x8b0cee60
	if (!ctx.cr0.eq) goto loc_8B0CEE60;
	// li r4,1
	ctx.r4.s64 = 1;
	// lwz r3,11652(r30)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r30.u32 + 11652);
	// bl 0x8b0df5f8
	ctx.lr = 0x8B0CEDEC;
	__imp__KeTlsSetValue(ctx, base);
	// cmpwi r3,0
	ctx.cr0.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// beq 0x8b0cee70
	if (ctx.cr0.eq) goto loc_8B0CEE70;
	// li r4,196
	ctx.r4.s64 = 196;
	// li r3,1
	ctx.r3.s64 = 1;
	// bl 0x8b090068
	ctx.lr = 0x8B0CEE00;
	sub_8B090068(ctx, base);
	// mr. r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	ctx.cr0.compare<int32_t>(ctx.r31.s32, 0, ctx.xer);
	// lwz r3,11652(r30)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r30.u32 + 11652);
	// beq 0x8b0cee54
	if (ctx.cr0.eq) goto loc_8B0CEE54;
	// mr r4,r31
	ctx.r4.u64 = ctx.r31.u64;
	// bl 0x8b0df5f8
	ctx.lr = 0x8B0CEE14;
	__imp__KeTlsSetValue(ctx, base);
	// cmpwi r3,0
	ctx.cr0.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// beq 0x8b0cee44
	if (ctx.cr0.eq) goto loc_8B0CEE44;
	// lis r11,-29943
	ctx.r11.s64 = -1962344448;
	// li r10,1
	ctx.r10.s64 = 1;
	// addi r11,r11,-24336
	ctx.r11.s64 = ctx.r11.s64 + -24336;
	// stw r10,20(r31)
	REX_STORE_U32(ctx.r31.u32 + 20, ctx.r10.u32);
	// stw r11,92(r31)
	REX_STORE_U32(ctx.r31.u32 + 92, ctx.r11.u32);
	// bl 0x8b0dc5c8
	ctx.lr = 0x8B0CEE34;
	sub_8B0DC5C8(ctx, base);
	// li r11,-1
	ctx.r11.s64 = -1;
	// stw r3,0(r31)
	REX_STORE_U32(ctx.r31.u32 + 0, ctx.r3.u32);
	// stw r11,4(r31)
	REX_STORE_U32(ctx.r31.u32 + 4, ctx.r11.u32);
	// b 0x8b0cee70
	goto loc_8B0CEE70;
loc_8B0CEE44:
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b090020
	ctx.lr = 0x8B0CEE4C;
	sub_8B090020(ctx, base);
	// li r31,0
	ctx.r31.s64 = 0;
	// b 0x8b0cee70
	goto loc_8B0CEE70;
loc_8B0CEE54:
	// li r4,0
	ctx.r4.s64 = 0;
	// bl 0x8b0df5f8
	ctx.lr = 0x8B0CEE5C;
	__imp__KeTlsSetValue(ctx, base);
	// b 0x8b0cee70
	goto loc_8B0CEE70;
loc_8B0CEE60:
	// addi r11,r31,-1
	ctx.r11.s64 = ctx.r31.s64 + -1;
	// subfic r11,r11,0
	ctx.xer.ca = ctx.r11.u32 <= 0;
	ctx.r11.u64 = static_cast<uint64_t>(0) - ctx.r11.u64;
	// subfe r11,r11,r11
	temp.u8 = (~ctx.r11.u32 + ctx.r11.u32 < ~ctx.r11.u32) | (~ctx.r11.u32 + ctx.r11.u32 + ctx.xer.ca < ctx.xer.ca);
	ctx.r11.u64 = ~ctx.r11.u64 + ctx.r11.u64 + ctx.xer.ca;
	ctx.xer.ca = temp.u8;
	// and r31,r11,r31
	ctx.r31.u64 = ctx.r11.u64 & ctx.r31.u64;
loc_8B0CEE70:
	// mr r3,r29
	ctx.r3.u64 = ctx.r29.u64;
	// bl 0x8b096358
	ctx.lr = 0x8B0CEE78;
	sub_8B096358(ctx, base);
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// addi r1,r1,112
	ctx.r1.s64 = ctx.r1.s64 + 112;
	// b 0x8b0cba0c
	__restgprlr_29(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0CEFF8) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// std r30,-24(r1)
	REX_STORE_U64(ctx.r1.u32 + -24, ctx.r30.u64);
	// std r31,-16(r1)
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.r31.u64);
	// stwu r1,-112(r1)
	ea = -112 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// bl 0x8b0ced10
	ctx.lr = 0x8B0CF010;
	sub_8B0CED10(ctx, base);
	// bl 0x8b0d5d70
	ctx.lr = 0x8B0CF014;
	sub_8B0D5D70(ctx, base);
	// cmpwi r3,0
	ctx.cr0.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// beq 0x8b0cf0a4
	if (ctx.cr0.eq) goto loc_8B0CF0A4;
	// bl 0x8b0df5d8
	ctx.lr = 0x8B0CF020;
	__imp__KeTlsAlloc(ctx, base);
	// lis r30,-29938
	ctx.r30.s64 = -1962016768;
	// cmpwi cr6,r3,-1
	ctx.cr6.compare<int32_t>(ctx.r3.s32, -1, ctx.xer);
	// stw r3,11652(r30)
	REX_STORE_U32(ctx.r30.u32 + 11652, ctx.r3.u32);
	// beq cr6,0x8b0cf0a4
	if (ctx.cr6.eq) goto loc_8B0CF0A4;
	// li r4,196
	ctx.r4.s64 = 196;
	// li r3,1
	ctx.r3.s64 = 1;
	// bl 0x8b090068
	ctx.lr = 0x8B0CF03C;
	sub_8B090068(ctx, base);
	// mr. r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	ctx.cr0.compare<int32_t>(ctx.r31.s32, 0, ctx.xer);
	// beq 0x8b0cf0a4
	if (ctx.cr0.eq) goto loc_8B0CF0A4;
	// mr r4,r31
	ctx.r4.u64 = ctx.r31.u64;
	// lwz r3,11652(r30)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r30.u32 + 11652);
	// bl 0x8b0df5f8
	ctx.lr = 0x8B0CF050;
	__imp__KeTlsSetValue(ctx, base);
	// cmpwi r3,0
	ctx.cr0.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// beq 0x8b0cf0a4
	if (ctx.cr0.eq) goto loc_8B0CF0A4;
	// lis r11,-29943
	ctx.r11.s64 = -1962344448;
	// li r10,1
	ctx.r10.s64 = 1;
	// addi r11,r11,-24336
	ctx.r11.s64 = ctx.r11.s64 + -24336;
	// stw r10,20(r31)
	REX_STORE_U32(ctx.r31.u32 + 20, ctx.r10.u32);
	// stw r11,92(r31)
	REX_STORE_U32(ctx.r31.u32 + 92, ctx.r11.u32);
	// bl 0x8b0dc5c8
	ctx.lr = 0x8B0CF070;
	sub_8B0DC5C8(ctx, base);
	// lis r10,-29936
	ctx.r10.s64 = -1961885696;
	// lis r11,-29939
	ctx.r11.s64 = -1962082304;
	// stw r3,0(r31)
	REX_STORE_U32(ctx.r31.u32 + 0, ctx.r3.u32);
	// addi r10,r10,-17704
	ctx.r10.s64 = ctx.r10.s64 + -17704;
	// li r9,-1
	ctx.r9.s64 = -1;
	// addi r11,r11,24920
	ctx.r11.s64 = ctx.r11.s64 + 24920;
	// stw r9,4(r31)
	REX_STORE_U32(ctx.r31.u32 + 4, ctx.r9.u32);
	// mr r3,r10
	ctx.r3.u64 = ctx.r10.u64;
	// li r4,1
	ctx.r4.s64 = 1;
	// stw r11,8(r10)
	REX_STORE_U32(ctx.r10.u32 + 8, ctx.r11.u32);
	// bl 0x8b0dc5e0
	ctx.lr = 0x8B0CF09C;
	sub_8B0DC5E0(ctx, base);
	// li r3,1
	ctx.r3.s64 = 1;
	// b 0x8b0cf0ac
	goto loc_8B0CF0AC;
loc_8B0CF0A4:
	// bl 0x8b0ced70
	ctx.lr = 0x8B0CF0A8;
	sub_8B0CED70(ctx, base);
	// li r3,0
	ctx.r3.s64 = 0;
loc_8B0CF0AC:
	// addi r1,r1,112
	ctx.r1.s64 = ctx.r1.s64 + 112;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// ld r30,-24(r1)
	ctx.r30.u64 = REX_LOAD_U64(ctx.r1.u32 + -24);
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0CF5F0) {
	REX_FUNC_PROLOGUE();
	PPCRegister temp{};
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb980
	ctx.lr = 0x8B0CF5F8;
	__savegprlr_14(ctx, base);
	// stwu r1,-1328(r1)
	ea = -1328 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// li r30,0
	ctx.r30.s64 = 0;
	// mr r18,r3
	ctx.r18.u64 = ctx.r3.u64;
	// mr r31,r4
	ctx.r31.u64 = ctx.r4.u64;
	// stw r30,104(r1)
	REX_STORE_U32(ctx.r1.u32 + 104, ctx.r30.u32);
	// mr r26,r6
	ctx.r26.u64 = ctx.r6.u64;
	// stw r30,96(r1)
	REX_STORE_U32(ctx.r1.u32 + 96, ctx.r30.u32);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// stw r30,92(r1)
	REX_STORE_U32(ctx.r1.u32 + 92, ctx.r30.u32);
	// mr r27,r30
	ctx.r27.u64 = ctx.r30.u64;
	// stw r30,100(r1)
	REX_STORE_U32(ctx.r1.u32 + 100, ctx.r30.u32);
	// mr r25,r30
	ctx.r25.u64 = ctx.r30.u64;
	// mr r16,r30
	ctx.r16.u64 = ctx.r30.u64;
	// bne cr6,0x8b0cf65c
	if (!ctx.cr6.eq) goto loc_8B0CF65C;
loc_8B0CF630:
	// bl 0x8b0d0288
	ctx.lr = 0x8B0CF634;
	sub_8B0D0288(ctx, base);
	// li r11,22
	ctx.r11.s64 = 22;
	// li r7,0
	ctx.r7.s64 = 0;
	// stw r11,0(r3)
	REX_STORE_U32(ctx.r3.u32 + 0, ctx.r11.u32);
	// li r6,0
	ctx.r6.s64 = 0;
	// li r5,0
	ctx.r5.s64 = 0;
	// li r4,0
	ctx.r4.s64 = 0;
	// li r3,0
	ctx.r3.s64 = 0;
	// bl 0x8b0d0148
	ctx.lr = 0x8B0CF654;
	sub_8B0D0148(ctx, base);
	// li r3,-1
	ctx.r3.s64 = -1;
	// b 0x8b0d012c
	goto loc_8B0D012C;
loc_8B0CF65C:
	// lwz r11,12(r18)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r18.u32 + 12);
	// rlwinm. r11,r11,0,25,25
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 0) & 0x40;
	ctx.cr0.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// bne 0x8b0cf6f8
	if (!ctx.cr0.eq) goto loc_8B0CF6F8;
	// mr r3,r18
	ctx.r3.u64 = ctx.r18.u64;
	// bl 0x8b0d6c70
	ctx.lr = 0x8B0CF670;
	sub_8B0D6C70(ctx, base);
	// lis r11,-29936
	ctx.r11.s64 = -1961885696;
	// lis r10,-29938
	ctx.r10.s64 = -1962016768;
	// cmpwi cr6,r3,-1
	ctx.cr6.compare<int32_t>(ctx.r3.s32, -1, ctx.xer);
	// addi r11,r11,-16864
	ctx.r11.s64 = ctx.r11.s64 + -16864;
	// addi r8,r10,12856
	ctx.r8.s64 = ctx.r10.s64 + 12856;
	// beq cr6,0x8b0cf6ac
	if (ctx.cr6.eq) goto loc_8B0CF6AC;
	// cmpwi cr6,r3,-2
	ctx.cr6.compare<int32_t>(ctx.r3.s32, -2, ctx.xer);
	// beq cr6,0x8b0cf6ac
	if (ctx.cr6.eq) goto loc_8B0CF6AC;
	// srawi r10,r3,5
	ctx.xer.ca = (ctx.r3.s32 < 0) & ((ctx.r3.u32 & 0x1F) != 0);
	ctx.r10.s64 = ctx.r3.s32 >> 5;
	// clrlwi r9,r3,27
	ctx.r9.u64 = ctx.r3.u32 & 0x1F;
	// rlwinm r7,r10,2,0,29
	ctx.r7.u64 = __builtin_rotateleft64(ctx.r10.u32 | (ctx.r10.u64 << 32), 2) & 0xFFFFFFFC;
	// mulli r10,r9,72
	ctx.r10.s64 = static_cast<int64_t>(ctx.r9.u64 * static_cast<uint64_t>(72));
	// lwzx r9,r7,r11
	ctx.r9.u64 = REX_LOAD_U32(ctx.r7.u32 + ctx.r11.u32);
	// add r10,r9,r10
	ctx.r10.u64 = ctx.r9.u64 + ctx.r10.u64;
	// b 0x8b0cf6b0
	goto loc_8B0CF6B0;
loc_8B0CF6AC:
	// mr r10,r8
	ctx.r10.u64 = ctx.r8.u64;
loc_8B0CF6B0:
	// lbz r10,40(r10)
	ctx.r10.u64 = REX_LOAD_U8(ctx.r10.u32 + 40);
	// rlwinm. r10,r10,0,0,30
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r10.u32 | (ctx.r10.u64 << 32), 0) & 0xFFFFFFFE;
	ctx.cr0.compare<int32_t>(ctx.r10.s32, 0, ctx.xer);
	// bne 0x8b0cf630
	if (!ctx.cr0.eq) goto loc_8B0CF630;
	// cmpwi cr6,r3,-1
	ctx.cr6.compare<int32_t>(ctx.r3.s32, -1, ctx.xer);
	// beq cr6,0x8b0cf6e8
	if (ctx.cr6.eq) goto loc_8B0CF6E8;
	// cmpwi cr6,r3,-2
	ctx.cr6.compare<int32_t>(ctx.r3.s32, -2, ctx.xer);
	// beq cr6,0x8b0cf6e8
	if (ctx.cr6.eq) goto loc_8B0CF6E8;
	// srawi r10,r3,5
	ctx.xer.ca = (ctx.r3.s32 < 0) & ((ctx.r3.u32 & 0x1F) != 0);
	ctx.r10.s64 = ctx.r3.s32 >> 5;
	// clrlwi r9,r3,27
	ctx.r9.u64 = ctx.r3.u32 & 0x1F;
	// rlwinm r8,r10,2,0,29
	ctx.r8.u64 = __builtin_rotateleft64(ctx.r10.u32 | (ctx.r10.u64 << 32), 2) & 0xFFFFFFFC;
	// mulli r10,r9,72
	ctx.r10.s64 = static_cast<int64_t>(ctx.r9.u64 * static_cast<uint64_t>(72));
	// lwzx r11,r8,r11
	ctx.r11.u64 = REX_LOAD_U32(ctx.r8.u32 + ctx.r11.u32);
	// add r11,r11,r10
	ctx.r11.u64 = ctx.r11.u64 + ctx.r10.u64;
	// b 0x8b0cf6ec
	goto loc_8B0CF6EC;
loc_8B0CF6E8:
	// mr r11,r8
	ctx.r11.u64 = ctx.r8.u64;
loc_8B0CF6EC:
	// lbz r11,40(r11)
	ctx.r11.u64 = REX_LOAD_U8(ctx.r11.u32 + 40);
	// clrlwi. r11,r11,31
	ctx.r11.u64 = ctx.r11.u32 & 0x1;
	ctx.cr0.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// bne 0x8b0cf630
	if (!ctx.cr0.eq) goto loc_8B0CF630;
loc_8B0CF6F8:
	// cmplwi cr6,r31,0
	ctx.cr6.compare<uint32_t>(ctx.r31.u32, 0, ctx.xer);
	// beq cr6,0x8b0cf630
	if (ctx.cr6.eq) goto loc_8B0CF630;
	// bl 0x8b0d69d0
	ctx.lr = 0x8B0CF704;
	sub_8B0D69D0(ctx, base);
	// addi r11,r3,32
	ctx.r11.s64 = ctx.r3.s64 + 32;
	// cmplw cr6,r18,r11
	ctx.cr6.compare<uint32_t>(ctx.r18.u32, ctx.r11.u32, ctx.xer);
	// beq cr6,0x8b0d00f8
	if (ctx.cr6.eq) goto loc_8B0D00F8;
	// bl 0x8b0d69d0
	ctx.lr = 0x8B0CF714;
	sub_8B0D69D0(ctx, base);
	// addi r11,r3,64
	ctx.r11.s64 = ctx.r3.s64 + 64;
	// cmplw cr6,r18,r11
	ctx.cr6.compare<uint32_t>(ctx.r18.u32, ctx.r11.u32, ctx.xer);
	// beq cr6,0x8b0d00f8
	if (ctx.cr6.eq) goto loc_8B0D00F8;
	// lbz r29,0(r31)
	ctx.r29.u64 = REX_LOAD_U8(ctx.r31.u32 + 0);
	// mr r24,r30
	ctx.r24.u64 = ctx.r30.u64;
	// mr r6,r30
	ctx.r6.u64 = ctx.r30.u64;
	// stw r30,80(r1)
	REX_STORE_U32(ctx.r1.u32 + 80, ctx.r30.u32);
	// extsb. r8,r29
	ctx.r8.s64 = ctx.r29.s8;
	ctx.cr0.compare<int32_t>(ctx.r8.s32, 0, ctx.xer);
	// stw r30,84(r1)
	REX_STORE_U32(ctx.r1.u32 + 84, ctx.r30.u32);
	// mr r7,r30
	ctx.r7.u64 = ctx.r30.u64;
	// mr r14,r30
	ctx.r14.u64 = ctx.r30.u64;
	// beq 0x8b0d00f0
	if (ctx.cr0.eq) goto loc_8B0D00F0;
	// lis r11,-29938
	ctx.r11.s64 = -1962016768;
	// lwz r21,112(r1)
	ctx.r21.u64 = REX_LOAD_U32(ctx.r1.u32 + 112);
	// lis r10,-29938
	ctx.r10.s64 = -1962016768;
	// lwz r28,112(r1)
	ctx.r28.u64 = REX_LOAD_U32(ctx.r1.u32 + 112);
	// lis r9,-29943
	ctx.r9.s64 = -1962344448;
	// addi r19,r31,-1
	ctx.r19.s64 = ctx.r31.s64 + -1;
	// lis r15,-29943
	ctx.r15.s64 = -1962344448;
	// lis r20,-29943
	ctx.r20.s64 = -1962344448;
	// addi r23,r11,12512
	ctx.r23.s64 = ctx.r11.s64 + 12512;
	// addi r22,r10,12048
	ctx.r22.s64 = ctx.r10.s64 + 12048;
	// addi r17,r9,-24184
	ctx.r17.s64 = ctx.r9.s64 + -24184;
loc_8B0CF770:
	// addi r19,r19,1
	ctx.r19.s64 = ctx.r19.s64 + 1;
	// cmpwi cr6,r24,0
	ctx.cr6.compare<int32_t>(ctx.r24.s32, 0, ctx.xer);
	// blt cr6,0x8b0d00f0
	if (ctx.cr6.lt) goto loc_8B0D00F0;
	// cmpwi cr6,r8,32
	ctx.cr6.compare<int32_t>(ctx.r8.s32, 32, ctx.xer);
	// blt cr6,0x8b0cf79c
	if (ctx.cr6.lt) goto loc_8B0CF79C;
	// cmpwi cr6,r8,120
	ctx.cr6.compare<int32_t>(ctx.r8.s32, 120, ctx.xer);
	// bgt cr6,0x8b0cf79c
	if (ctx.cr6.gt) goto loc_8B0CF79C;
	// add r11,r8,r17
	ctx.r11.u64 = ctx.r8.u64 + ctx.r17.u64;
	// lbz r11,-32(r11)
	ctx.r11.u64 = REX_LOAD_U8(ctx.r11.u32 + -32);
	// clrlwi r11,r11,28
	ctx.r11.u64 = ctx.r11.u32 & 0xF;
	// b 0x8b0cf7a0
	goto loc_8B0CF7A0;
loc_8B0CF79C:
	// mr r11,r30
	ctx.r11.u64 = ctx.r30.u64;
loc_8B0CF7A0:
	// rlwinm r11,r11,3,0,28
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 3) & 0xFFFFFFF8;
	// add r11,r11,r7
	ctx.r11.u64 = ctx.r11.u64 + ctx.r7.u64;
	// lbzx r11,r11,r17
	ctx.r11.u64 = REX_LOAD_U8(ctx.r11.u32 + ctx.r17.u32);
	// extsb r11,r11
	ctx.r11.s64 = ctx.r11.s8;
	// srawi r11,r11,4
	ctx.xer.ca = (ctx.r11.s32 < 0) & ((ctx.r11.u32 & 0xF) != 0);
	ctx.r11.s64 = ctx.r11.s32 >> 4;
	// stw r11,108(r1)
	REX_STORE_U32(ctx.r1.u32 + 108, ctx.r11.u32);
	// cmplwi cr6,r11,7
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 7, ctx.xer);
	// bgt cr6,0x8b0d00d4
	if (ctx.cr6.gt) goto loc_8B0D00D4;
	// rotlwi r11,r11,0
	ctx.r11.u64 = __builtin_rotateleft32(ctx.r11.u32, 0);
	// mtctr r11
	ctx.ctr.u64 = ctx.r11.u64;
	// cmpwi cr6,r11,0
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// beq cr6,0x8b0cf9b8
	if (ctx.cr6.eq) goto loc_8B0CF9B8;
	// bdz 0x8b0cf7ec
	--ctx.ctr.u64;
	if (ctx.ctr.u32 == 0) goto loc_8B0CF7EC;
	// bdz 0x8b0cf80c
	--ctx.ctr.u64;
	if (ctx.ctr.u32 == 0) goto loc_8B0CF80C;
	// bdz 0x8b0cf85c
	--ctx.ctr.u64;
	if (ctx.ctr.u32 == 0) goto loc_8B0CF85C;
	// bdz 0x8b0cf8a8
	--ctx.ctr.u64;
	if (ctx.ctr.u32 == 0) goto loc_8B0CF8A8;
	// bdz 0x8b0cf8b0
	--ctx.ctr.u64;
	if (ctx.ctr.u32 == 0) goto loc_8B0CF8B0;
	// bdz 0x8b0cf8e8
	--ctx.ctr.u64;
	if (ctx.ctr.u32 == 0) goto loc_8B0CF8E8;
	// b 0x8b0cfa04
	goto loc_8B0CFA04;
loc_8B0CF7EC:
	// li r27,0
	ctx.r27.s64 = 0;
	// li r25,-1
	ctx.r25.s64 = -1;
	// mr r21,r27
	ctx.r21.u64 = ctx.r27.u64;
	// stw r27,100(r1)
	REX_STORE_U32(ctx.r1.u32 + 100, ctx.r27.u32);
	// stw r27,96(r1)
	REX_STORE_U32(ctx.r1.u32 + 96, ctx.r27.u32);
	// mr r16,r27
	ctx.r16.u64 = ctx.r27.u64;
	// stw r27,92(r1)
	REX_STORE_U32(ctx.r1.u32 + 92, ctx.r27.u32);
	// b 0x8b0d00d4
	goto loc_8B0D00D4;
loc_8B0CF80C:
	// cmpwi cr6,r8,32
	ctx.cr6.compare<int32_t>(ctx.r8.s32, 32, ctx.xer);
	// beq cr6,0x8b0cf854
	if (ctx.cr6.eq) goto loc_8B0CF854;
	// cmpwi cr6,r8,35
	ctx.cr6.compare<int32_t>(ctx.r8.s32, 35, ctx.xer);
	// beq cr6,0x8b0cf84c
	if (ctx.cr6.eq) goto loc_8B0CF84C;
	// cmpwi cr6,r8,43
	ctx.cr6.compare<int32_t>(ctx.r8.s32, 43, ctx.xer);
	// beq cr6,0x8b0cf844
	if (ctx.cr6.eq) goto loc_8B0CF844;
	// cmpwi cr6,r8,45
	ctx.cr6.compare<int32_t>(ctx.r8.s32, 45, ctx.xer);
	// beq cr6,0x8b0cf83c
	if (ctx.cr6.eq) goto loc_8B0CF83C;
	// cmpwi cr6,r8,48
	ctx.cr6.compare<int32_t>(ctx.r8.s32, 48, ctx.xer);
	// bne cr6,0x8b0d00d4
	if (!ctx.cr6.eq) goto loc_8B0D00D4;
	// ori r27,r27,8
	ctx.r27.u64 = ctx.r27.u64 | 8;
	// b 0x8b0d00d4
	goto loc_8B0D00D4;
loc_8B0CF83C:
	// ori r27,r27,4
	ctx.r27.u64 = ctx.r27.u64 | 4;
	// b 0x8b0d00d4
	goto loc_8B0D00D4;
loc_8B0CF844:
	// ori r27,r27,1
	ctx.r27.u64 = ctx.r27.u64 | 1;
	// b 0x8b0d00d4
	goto loc_8B0D00D4;
loc_8B0CF84C:
	// ori r27,r27,128
	ctx.r27.u64 = ctx.r27.u64 | 128;
	// b 0x8b0d00d4
	goto loc_8B0D00D4;
loc_8B0CF854:
	// ori r27,r27,2
	ctx.r27.u64 = ctx.r27.u64 | 2;
	// b 0x8b0d00d4
	goto loc_8B0D00D4;
loc_8B0CF85C:
	// cmpwi cr6,r8,42
	ctx.cr6.compare<int32_t>(ctx.r8.s32, 42, ctx.xer);
	// bne cr6,0x8b0cf890
	if (!ctx.cr6.eq) goto loc_8B0CF890;
	// addi r11,r26,7
	ctx.r11.s64 = ctx.r26.s64 + 7;
	// rlwinm r11,r11,0,0,28
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 0) & 0xFFFFFFF8;
	// addi r26,r11,8
	ctx.r26.s64 = ctx.r11.s64 + 8;
	// lwz r11,4(r11)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r11.u32 + 4);
	// cmpwi cr6,r11,0
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// stw r11,96(r1)
	REX_STORE_U32(ctx.r1.u32 + 96, ctx.r11.u32);
	// bge cr6,0x8b0d00d4
	if (!ctx.cr6.lt) goto loc_8B0D00D4;
	// rotlwi r11,r11,0
	ctx.r11.u64 = __builtin_rotateleft32(ctx.r11.u32, 0);
	// ori r27,r27,4
	ctx.r27.u64 = ctx.r27.u64 | 4;
	// neg r11,r11
	ctx.r11.s64 = static_cast<int64_t>(-ctx.r11.u64);
	// b 0x8b0cf8a0
	goto loc_8B0CF8A0;
loc_8B0CF890:
	// lwz r11,96(r1)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r1.u32 + 96);
	// mulli r11,r11,10
	ctx.r11.s64 = static_cast<int64_t>(ctx.r11.u64 * static_cast<uint64_t>(10));
	// add r11,r11,r8
	ctx.r11.u64 = ctx.r11.u64 + ctx.r8.u64;
	// addi r11,r11,-48
	ctx.r11.s64 = ctx.r11.s64 + -48;
loc_8B0CF8A0:
	// stw r11,96(r1)
	REX_STORE_U32(ctx.r1.u32 + 96, ctx.r11.u32);
	// b 0x8b0d00d4
	goto loc_8B0D00D4;
loc_8B0CF8A8:
	// li r25,0
	ctx.r25.s64 = 0;
	// b 0x8b0d00d4
	goto loc_8B0D00D4;
loc_8B0CF8B0:
	// cmpwi cr6,r8,42
	ctx.cr6.compare<int32_t>(ctx.r8.s32, 42, ctx.xer);
	// bne cr6,0x8b0cf8d8
	if (!ctx.cr6.eq) goto loc_8B0CF8D8;
	// addi r11,r26,7
	ctx.r11.s64 = ctx.r26.s64 + 7;
	// rlwinm r11,r11,0,0,28
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 0) & 0xFFFFFFF8;
	// addi r26,r11,8
	ctx.r26.s64 = ctx.r11.s64 + 8;
	// lwz r25,4(r11)
	ctx.r25.u64 = REX_LOAD_U32(ctx.r11.u32 + 4);
	// cmpwi cr6,r25,0
	ctx.cr6.compare<int32_t>(ctx.r25.s32, 0, ctx.xer);
	// bge cr6,0x8b0d00d4
	if (!ctx.cr6.lt) goto loc_8B0D00D4;
	// li r25,-1
	ctx.r25.s64 = -1;
	// b 0x8b0d00d4
	goto loc_8B0D00D4;
loc_8B0CF8D8:
	// mulli r11,r25,10
	ctx.r11.s64 = static_cast<int64_t>(ctx.r25.u64 * static_cast<uint64_t>(10));
	// add r11,r11,r8
	ctx.r11.u64 = ctx.r11.u64 + ctx.r8.u64;
	// addi r25,r11,-48
	ctx.r25.s64 = ctx.r11.s64 + -48;
	// b 0x8b0d00d4
	goto loc_8B0D00D4;
loc_8B0CF8E8:
	// cmpwi cr6,r8,73
	ctx.cr6.compare<int32_t>(ctx.r8.s32, 73, ctx.xer);
	// beq cr6,0x8b0cf938
	if (ctx.cr6.eq) goto loc_8B0CF938;
	// cmpwi cr6,r8,104
	ctx.cr6.compare<int32_t>(ctx.r8.s32, 104, ctx.xer);
	// beq cr6,0x8b0cf930
	if (ctx.cr6.eq) goto loc_8B0CF930;
	// cmpwi cr6,r8,108
	ctx.cr6.compare<int32_t>(ctx.r8.s32, 108, ctx.xer);
	// beq cr6,0x8b0cf910
	if (ctx.cr6.eq) goto loc_8B0CF910;
	// cmpwi cr6,r8,119
	ctx.cr6.compare<int32_t>(ctx.r8.s32, 119, ctx.xer);
	// bne cr6,0x8b0d00d4
	if (!ctx.cr6.eq) goto loc_8B0D00D4;
	// ori r27,r27,2048
	ctx.r27.u64 = ctx.r27.u64 | 2048;
	// b 0x8b0d00d4
	goto loc_8B0D00D4;
loc_8B0CF910:
	// lbz r11,1(r19)
	ctx.r11.u64 = REX_LOAD_U8(ctx.r19.u32 + 1);
	// cmplwi cr6,r11,108
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 108, ctx.xer);
	// bne cr6,0x8b0cf928
	if (!ctx.cr6.eq) goto loc_8B0CF928;
	// addi r19,r19,1
	ctx.r19.s64 = ctx.r19.s64 + 1;
	// ori r27,r27,4096
	ctx.r27.u64 = ctx.r27.u64 | 4096;
	// b 0x8b0d00d4
	goto loc_8B0D00D4;
loc_8B0CF928:
	// ori r27,r27,16
	ctx.r27.u64 = ctx.r27.u64 | 16;
	// b 0x8b0d00d4
	goto loc_8B0D00D4;
loc_8B0CF930:
	// ori r27,r27,32
	ctx.r27.u64 = ctx.r27.u64 | 32;
	// b 0x8b0d00d4
	goto loc_8B0D00D4;
loc_8B0CF938:
	// lbz r11,1(r19)
	ctx.r11.u64 = REX_LOAD_U8(ctx.r19.u32 + 1);
	// extsb r11,r11
	ctx.r11.s64 = ctx.r11.s8;
	// cmpwi cr6,r11,54
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 54, ctx.xer);
	// bne cr6,0x8b0cf960
	if (!ctx.cr6.eq) goto loc_8B0CF960;
	// lbz r10,2(r19)
	ctx.r10.u64 = REX_LOAD_U8(ctx.r19.u32 + 2);
	// cmplwi cr6,r10,52
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 52, ctx.xer);
	// bne cr6,0x8b0cf960
	if (!ctx.cr6.eq) goto loc_8B0CF960;
	// addi r19,r19,2
	ctx.r19.s64 = ctx.r19.s64 + 2;
	// ori r27,r27,32768
	ctx.r27.u64 = ctx.r27.u64 | 32768;
	// b 0x8b0d00d4
	goto loc_8B0D00D4;
loc_8B0CF960:
	// cmpwi cr6,r11,51
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 51, ctx.xer);
	// bne cr6,0x8b0cf980
	if (!ctx.cr6.eq) goto loc_8B0CF980;
	// lbz r10,2(r19)
	ctx.r10.u64 = REX_LOAD_U8(ctx.r19.u32 + 2);
	// cmplwi cr6,r10,50
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 50, ctx.xer);
	// bne cr6,0x8b0cf980
	if (!ctx.cr6.eq) goto loc_8B0CF980;
	// addi r19,r19,2
	ctx.r19.s64 = ctx.r19.s64 + 2;
	// rlwinm r27,r27,0,17,15
	ctx.r27.u64 = __builtin_rotateleft64(ctx.r27.u32 | (ctx.r27.u64 << 32), 0) & 0xFFFFFFFFFFFF7FFF;
	// b 0x8b0d00d4
	goto loc_8B0D00D4;
loc_8B0CF980:
	// cmpwi cr6,r11,100
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 100, ctx.xer);
	// beq cr6,0x8b0d00d4
	if (ctx.cr6.eq) goto loc_8B0D00D4;
	// cmpwi cr6,r11,105
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 105, ctx.xer);
	// beq cr6,0x8b0d00d4
	if (ctx.cr6.eq) goto loc_8B0D00D4;
	// cmpwi cr6,r11,111
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 111, ctx.xer);
	// beq cr6,0x8b0d00d4
	if (ctx.cr6.eq) goto loc_8B0D00D4;
	// cmpwi cr6,r11,117
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 117, ctx.xer);
	// beq cr6,0x8b0d00d4
	if (ctx.cr6.eq) goto loc_8B0D00D4;
	// cmpwi cr6,r11,120
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 120, ctx.xer);
	// beq cr6,0x8b0d00d4
	if (ctx.cr6.eq) goto loc_8B0D00D4;
	// cmpwi cr6,r11,88
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 88, ctx.xer);
	// beq cr6,0x8b0d00d4
	if (ctx.cr6.eq) goto loc_8B0D00D4;
	// li r11,0
	ctx.r11.s64 = 0;
	// stw r11,108(r1)
	REX_STORE_U32(ctx.r1.u32 + 108, ctx.r11.u32);
loc_8B0CF9B8:
	// mr r4,r23
	ctx.r4.u64 = ctx.r23.u64;
	// clrlwi r3,r29,24
	ctx.r3.u64 = ctx.r29.u32 & 0xFF;
	// li r16,0
	ctx.r16.s64 = 0;
	// bl 0x8b0d6e18
	ctx.lr = 0x8B0CF9C8;
	sub_8B0D6E18(ctx, base);
	// cmpwi r3,0
	ctx.cr0.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// beq 0x8b0cf9ec
	if (ctx.cr0.eq) goto loc_8B0CF9EC;
	// addi r5,r1,80
	ctx.r5.s64 = ctx.r1.s64 + 80;
	// mr r4,r18
	ctx.r4.u64 = ctx.r18.u64;
	// mr r3,r29
	ctx.r3.u64 = ctx.r29.u64;
	// bl 0x8b0cf4b8
	ctx.lr = 0x8B0CF9E0;
	sub_8B0CF4B8(ctx, base);
	// lbzu r29,1(r19)
	ea = 1 + ctx.r19.u32;
	ctx.r29.u64 = REX_LOAD_U8(ea);
	ctx.r19.u32 = ea;
	// cmplwi r29,0
	ctx.cr0.compare<uint32_t>(ctx.r29.u32, 0, ctx.xer);
	// beq 0x8b0cf630
	if (ctx.cr0.eq) goto loc_8B0CF630;
loc_8B0CF9EC:
	// addi r5,r1,80
	ctx.r5.s64 = ctx.r1.s64 + 80;
	// mr r4,r18
	ctx.r4.u64 = ctx.r18.u64;
	// mr r3,r29
	ctx.r3.u64 = ctx.r29.u64;
	// bl 0x8b0cf4b8
	ctx.lr = 0x8B0CF9FC;
	sub_8B0CF4B8(ctx, base);
	// lwz r24,80(r1)
	ctx.r24.u64 = REX_LOAD_U32(ctx.r1.u32 + 80);
	// b 0x8b0d00d4
	goto loc_8B0D00D4;
loc_8B0CFA04:
	// addi r11,r8,-65
	ctx.r11.s64 = ctx.r8.s64 + -65;
	// cmplwi cr6,r11,55
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 55, ctx.xer);
	// bgt cr6,0x8b0cff04
	if (ctx.cr6.gt) goto loc_8B0CFF04;
	// lis r12,-29943
	ctx.r12.s64 = -1962344448;
	// rlwinm r0,r11,1,0,30
	ctx.r0.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 1) & 0xFFFFFFFE;
	// addi r12,r12,-24088
	ctx.r12.s64 = ctx.r12.s64 + -24088;
	// lhzx r0,r12,r0
	ctx.r0.u64 = REX_LOAD_U16(ctx.r12.u32 + ctx.r0.u32);
	// lis r12,-29939
	ctx.r12.s64 = -1962082304;
	// addi r12,r12,-1480
	ctx.r12.s64 = ctx.r12.s64 + -1480;
	// nop 
	// add r12,r12,r0
	ctx.r12.u64 = ctx.r12.u64 + ctx.r0.u64;
	// mtctr r12
	ctx.ctr.u64 = ctx.r12.u64;
	// bctr 
	switch (ctx.r11.u32) {
	case 0:
		goto loc_8B0CFC14;
	case 1:
		goto loc_8B0CFF04;
	case 2:
		goto loc_8B0CFA38;
	case 3:
		goto loc_8B0CFF04;
	case 4:
		goto loc_8B0CFC14;
	case 5:
		goto loc_8B0CFF04;
	case 6:
		goto loc_8B0CFC14;
	case 7:
		goto loc_8B0CFF04;
	case 8:
		goto loc_8B0CFF04;
	case 9:
		goto loc_8B0CFF04;
	case 10:
		goto loc_8B0CFF04;
	case 11:
		goto loc_8B0CFF04;
	case 12:
		goto loc_8B0CFF04;
	case 13:
		goto loc_8B0CFF04;
	case 14:
		goto loc_8B0CFF04;
	case 15:
		goto loc_8B0CFF04;
	case 16:
		goto loc_8B0CFF04;
	case 17:
		goto loc_8B0CFF04;
	case 18:
		goto loc_8B0CFB20;
	case 19:
		goto loc_8B0CFF04;
	case 20:
		goto loc_8B0CFF04;
	case 21:
		goto loc_8B0CFF04;
	case 22:
		goto loc_8B0CFF04;
	case 23:
		goto loc_8B0CFD54;
	case 24:
		goto loc_8B0CFF04;
	case 25:
		goto loc_8B0CFAA4;
	case 26:
		goto loc_8B0CFF04;
	case 27:
		goto loc_8B0CFF04;
	case 28:
		goto loc_8B0CFF04;
	case 29:
		goto loc_8B0CFF04;
	case 30:
		goto loc_8B0CFF04;
	case 31:
		goto loc_8B0CFF04;
	case 32:
		goto loc_8B0CFC20;
	case 33:
		goto loc_8B0CFF04;
	case 34:
		goto loc_8B0CFA48;
	case 35:
		goto loc_8B0CFD44;
	case 36:
		goto loc_8B0CFC20;
	case 37:
		goto loc_8B0CFC20;
	case 38:
		goto loc_8B0CFC20;
	case 39:
		goto loc_8B0CFF04;
	case 40:
		goto loc_8B0CFD44;
	case 41:
		goto loc_8B0CFF04;
	case 42:
		goto loc_8B0CFF04;
	case 43:
		goto loc_8B0CFF04;
	case 44:
		goto loc_8B0CFF04;
	case 45:
		goto loc_8B0CFBD8;
	case 46:
		goto loc_8B0CFD8C;
	case 47:
		goto loc_8B0CFD50;
	case 48:
		goto loc_8B0CFF04;
	case 49:
		goto loc_8B0CFF04;
	case 50:
		goto loc_8B0CFB30;
	case 51:
		goto loc_8B0CFF04;
	case 52:
		goto loc_8B0CFD48;
	case 53:
		goto loc_8B0CFF04;
	case 54:
		goto loc_8B0CFF04;
	case 55:
		goto loc_8B0CFD5C;
	default:
		__builtin_trap(); // Switch case out of range
	}
loc_8B0CFA38:
	// andi. r11,r27,2096
	ctx.r11.u64 = ctx.r27.u64 & 2096;
	ctx.cr0.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// cmpwi r11,0
	ctx.cr0.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// bne 0x8b0cfa48
	if (!ctx.cr0.eq) goto loc_8B0CFA48;
	// ori r27,r27,2048
	ctx.r27.u64 = ctx.r27.u64 | 2048;
loc_8B0CFA48:
	// andi. r11,r27,2064
	ctx.r11.u64 = ctx.r27.u64 & 2064;
	ctx.cr0.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// cmpwi r11,0
	ctx.cr0.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// addi r11,r26,7
	ctx.r11.s64 = ctx.r26.s64 + 7;
	// rlwinm r11,r11,0,0,28
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 0) & 0xFFFFFFF8;
	// addi r26,r11,8
	ctx.r26.s64 = ctx.r11.s64 + 8;
	// beq 0x8b0cfa88
	if (ctx.cr0.eq) goto loc_8B0CFA88;
	// li r5,512
	ctx.r5.s64 = 512;
	// lhz r6,6(r11)
	ctx.r6.u64 = REX_LOAD_U16(ctx.r11.u32 + 6);
	// addi r4,r1,144
	ctx.r4.s64 = ctx.r1.s64 + 144;
	// addi r3,r1,84
	ctx.r3.s64 = ctx.r1.s64 + 84;
	// bl 0x8b0d6e10
	ctx.lr = 0x8B0CFA74;
	sub_8B0D6E10(ctx, base);
	// cmpwi r3,0
	ctx.cr0.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// beq 0x8b0cfa98
	if (ctx.cr0.eq) goto loc_8B0CFA98;
	// li r11,1
	ctx.r11.s64 = 1;
	// stw r11,100(r1)
	REX_STORE_U32(ctx.r1.u32 + 100, ctx.r11.u32);
	// b 0x8b0cfa98
	goto loc_8B0CFA98;
loc_8B0CFA88:
	// lwz r11,4(r11)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r11.u32 + 4);
	// li r10,1
	ctx.r10.s64 = 1;
	// stw r10,84(r1)
	REX_STORE_U32(ctx.r1.u32 + 84, ctx.r10.u32);
	// stb r11,144(r1)
	REX_STORE_U8(ctx.r1.u32 + 144, ctx.r11.u8);
loc_8B0CFA98:
	// lwz r6,84(r1)
	ctx.r6.u64 = REX_LOAD_U32(ctx.r1.u32 + 84);
	// addi r28,r1,144
	ctx.r28.s64 = ctx.r1.s64 + 144;
	// b 0x8b0cff04
	goto loc_8B0CFF04;
loc_8B0CFAA4:
	// addi r11,r26,7
	ctx.r11.s64 = ctx.r26.s64 + 7;
	// rlwinm r11,r11,0,0,28
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 0) & 0xFFFFFFF8;
	// addi r26,r11,8
	ctx.r26.s64 = ctx.r11.s64 + 8;
	// lwz r11,4(r11)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r11.u32 + 4);
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// beq cr6,0x8b0cfaf4
	if (ctx.cr6.eq) goto loc_8B0CFAF4;
	// lwz r10,4(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 4);
	// cmplwi cr6,r10,0
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 0, ctx.xer);
	// beq cr6,0x8b0cfaf4
	if (ctx.cr6.eq) goto loc_8B0CFAF4;
	// rlwinm. r9,r27,0,20,20
	ctx.r9.u64 = __builtin_rotateleft64(ctx.r27.u32 | (ctx.r27.u64 << 32), 0) & 0x800;
	ctx.cr0.compare<int32_t>(ctx.r9.s32, 0, ctx.xer);
	// mr r28,r10
	ctx.r28.u64 = ctx.r10.u64;
	// beq 0x8b0cfae8
	if (ctx.cr0.eq) goto loc_8B0CFAE8;
	// lha r11,0(r11)
	ctx.r11.s64 = int16_t(REX_LOAD_U16(ctx.r11.u32 + 0));
	// li r16,1
	ctx.r16.s64 = 1;
	// srawi r11,r11,1
	ctx.xer.ca = (ctx.r11.s32 < 0) & ((ctx.r11.u32 & 0x1) != 0);
	ctx.r11.s64 = ctx.r11.s32 >> 1;
	// addze r6,r11
	temp.s64 = ctx.r11.s64 + ctx.xer.ca;
	ctx.xer.ca = temp.u32 < ctx.r11.u32;
	ctx.r6.s64 = temp.s64;
	// b 0x8b0cff00
	goto loc_8B0CFF00;
loc_8B0CFAE8:
	// lha r6,0(r11)
	ctx.r6.s64 = int16_t(REX_LOAD_U16(ctx.r11.u32 + 0));
	// li r16,0
	ctx.r16.s64 = 0;
	// b 0x8b0cff00
	goto loc_8B0CFF00;
loc_8B0CFAF4:
	// lwz r28,-24192(r20)
	ctx.r28.u64 = REX_LOAD_U32(ctx.r20.u32 + -24192);
	// mr r11,r28
	ctx.r11.u64 = ctx.r28.u64;
	// mr r10,r28
	ctx.r10.u64 = ctx.r28.u64;
loc_8B0CFB00:
	// lbz r9,0(r11)
	ctx.r9.u64 = REX_LOAD_U8(ctx.r11.u32 + 0);
	// addi r11,r11,1
	ctx.r11.s64 = ctx.r11.s64 + 1;
	// cmplwi cr6,r9,0
	ctx.cr6.compare<uint32_t>(ctx.r9.u32, 0, ctx.xer);
	// bne cr6,0x8b0cfb00
	if (!ctx.cr6.eq) goto loc_8B0CFB00;
	// subf r11,r10,r11
	ctx.r11.u64 = ctx.r11.u64 - ctx.r10.u64;
loc_8B0CFB14:
	// addi r11,r11,-1
	ctx.r11.s64 = ctx.r11.s64 + -1;
	// rotlwi r6,r11,0
	ctx.r6.u64 = __builtin_rotateleft32(ctx.r11.u32, 0);
	// b 0x8b0cff00
	goto loc_8B0CFF00;
loc_8B0CFB20:
	// andi. r11,r27,2096
	ctx.r11.u64 = ctx.r27.u64 & 2096;
	ctx.cr0.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// cmpwi r11,0
	ctx.cr0.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// bne 0x8b0cfb30
	if (!ctx.cr0.eq) goto loc_8B0CFB30;
	// ori r27,r27,2048
	ctx.r27.u64 = ctx.r27.u64 | 2048;
loc_8B0CFB30:
	// cmpwi cr6,r25,-1
	ctx.cr6.compare<int32_t>(ctx.r25.s32, -1, ctx.xer);
	// bne cr6,0x8b0cfb44
	if (!ctx.cr6.eq) goto loc_8B0CFB44;
	// lis r10,32767
	ctx.r10.s64 = 2147418112;
	// ori r10,r10,65535
	ctx.r10.u64 = ctx.r10.u64 | 65535;
	// b 0x8b0cfb48
	goto loc_8B0CFB48;
loc_8B0CFB44:
	// mr r10,r25
	ctx.r10.u64 = ctx.r25.u64;
loc_8B0CFB48:
	// addi r11,r26,7
	ctx.r11.s64 = ctx.r26.s64 + 7;
	// andi. r9,r27,2064
	ctx.r9.u64 = ctx.r27.u64 & 2064;
	ctx.cr0.compare<int32_t>(ctx.r9.s32, 0, ctx.xer);
	// rlwinm r11,r11,0,0,28
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 0) & 0xFFFFFFF8;
	// cmpwi r9,0
	ctx.cr0.compare<int32_t>(ctx.r9.s32, 0, ctx.xer);
	// addi r26,r11,8
	ctx.r26.s64 = ctx.r11.s64 + 8;
	// lwz r28,4(r11)
	ctx.r28.u64 = REX_LOAD_U32(ctx.r11.u32 + 4);
	// cmplwi cr6,r28,0
	ctx.cr6.compare<uint32_t>(ctx.r28.u32, 0, ctx.xer);
	// beq 0x8b0cfba4
	if (ctx.cr0.eq) goto loc_8B0CFBA4;
	// bne cr6,0x8b0cfb70
	if (!ctx.cr6.eq) goto loc_8B0CFB70;
	// lwz r28,-24188(r15)
	ctx.r28.u64 = REX_LOAD_U32(ctx.r15.u32 + -24188);
loc_8B0CFB70:
	// li r16,1
	ctx.r16.s64 = 1;
	// mr r11,r28
	ctx.r11.u64 = ctx.r28.u64;
	// b 0x8b0cfb90
	goto loc_8B0CFB90;
loc_8B0CFB7C:
	// lhz r9,0(r11)
	ctx.r9.u64 = REX_LOAD_U16(ctx.r11.u32 + 0);
	// addi r10,r10,-1
	ctx.r10.s64 = ctx.r10.s64 + -1;
	// cmplwi r9,0
	ctx.cr0.compare<uint32_t>(ctx.r9.u32, 0, ctx.xer);
	// beq 0x8b0cfb98
	if (ctx.cr0.eq) goto loc_8B0CFB98;
	// addi r11,r11,2
	ctx.r11.s64 = ctx.r11.s64 + 2;
loc_8B0CFB90:
	// cmpwi cr6,r10,0
	ctx.cr6.compare<int32_t>(ctx.r10.s32, 0, ctx.xer);
	// bne cr6,0x8b0cfb7c
	if (!ctx.cr6.eq) goto loc_8B0CFB7C;
loc_8B0CFB98:
	// subf r11,r28,r11
	ctx.r11.u64 = ctx.r11.u64 - ctx.r28.u64;
	// srawi r6,r11,1
	ctx.xer.ca = (ctx.r11.s32 < 0) & ((ctx.r11.u32 & 0x1) != 0);
	ctx.r6.s64 = ctx.r11.s32 >> 1;
	// b 0x8b0cff00
	goto loc_8B0CFF00;
loc_8B0CFBA4:
	// bne cr6,0x8b0cfbac
	if (!ctx.cr6.eq) goto loc_8B0CFBAC;
	// lwz r28,-24192(r20)
	ctx.r28.u64 = REX_LOAD_U32(ctx.r20.u32 + -24192);
loc_8B0CFBAC:
	// mr r11,r28
	ctx.r11.u64 = ctx.r28.u64;
	// b 0x8b0cfbc8
	goto loc_8B0CFBC8;
loc_8B0CFBB4:
	// lbz r9,0(r11)
	ctx.r9.u64 = REX_LOAD_U8(ctx.r11.u32 + 0);
	// addi r10,r10,-1
	ctx.r10.s64 = ctx.r10.s64 + -1;
	// cmplwi r9,0
	ctx.cr0.compare<uint32_t>(ctx.r9.u32, 0, ctx.xer);
	// beq 0x8b0cfbd0
	if (ctx.cr0.eq) goto loc_8B0CFBD0;
	// addi r11,r11,1
	ctx.r11.s64 = ctx.r11.s64 + 1;
loc_8B0CFBC8:
	// cmpwi cr6,r10,0
	ctx.cr6.compare<int32_t>(ctx.r10.s32, 0, ctx.xer);
	// bne cr6,0x8b0cfbb4
	if (!ctx.cr6.eq) goto loc_8B0CFBB4;
loc_8B0CFBD0:
	// subf r6,r28,r11
	ctx.r6.u64 = ctx.r11.u64 - ctx.r28.u64;
	// b 0x8b0cff00
	goto loc_8B0CFF00;
loc_8B0CFBD8:
	// addi r11,r26,7
	ctx.r11.s64 = ctx.r26.s64 + 7;
	// rlwinm r11,r11,0,0,28
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 0) & 0xFFFFFFF8;
	// addi r26,r11,8
	ctx.r26.s64 = ctx.r11.s64 + 8;
	// lwz r31,4(r11)
	ctx.r31.u64 = REX_LOAD_U32(ctx.r11.u32 + 4);
	// bl 0x8b0d6cc8
	ctx.lr = 0x8B0CFBEC;
	sub_8B0D6CC8(ctx, base);
	// cmpwi r3,0
	ctx.cr0.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// beq 0x8b0cf630
	if (ctx.cr0.eq) goto loc_8B0CF630;
	// rlwinm. r11,r27,0,26,26
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r27.u32 | (ctx.r27.u64 << 32), 0) & 0x20;
	ctx.cr0.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// beq 0x8b0cfc04
	if (ctx.cr0.eq) goto loc_8B0CFC04;
	// sth r24,0(r31)
	REX_STORE_U16(ctx.r31.u32 + 0, ctx.r24.u16);
	// b 0x8b0cfc08
	goto loc_8B0CFC08;
loc_8B0CFC04:
	// stw r24,0(r31)
	REX_STORE_U32(ctx.r31.u32 + 0, ctx.r24.u32);
loc_8B0CFC08:
	// li r11,1
	ctx.r11.s64 = 1;
	// stw r11,100(r1)
	REX_STORE_U32(ctx.r1.u32 + 100, ctx.r11.u32);
	// b 0x8b0d00c0
	goto loc_8B0D00C0;
loc_8B0CFC14:
	// addi r11,r8,32
	ctx.r11.s64 = ctx.r8.s64 + 32;
	// li r21,1
	ctx.r21.s64 = 1;
	// extsb r29,r11
	ctx.r29.s64 = ctx.r11.s8;
loc_8B0CFC20:
	// ori r27,r27,64
	ctx.r27.u64 = ctx.r27.u64 | 64;
	// addi r28,r1,144
	ctx.r28.s64 = ctx.r1.s64 + 144;
	// li r30,512
	ctx.r30.s64 = 512;
	// cmpwi cr6,r25,0
	ctx.cr6.compare<int32_t>(ctx.r25.s32, 0, ctx.xer);
	// bge cr6,0x8b0cfc3c
	if (!ctx.cr6.lt) goto loc_8B0CFC3C;
	// li r25,6
	ctx.r25.s64 = 6;
	// b 0x8b0cfc8c
	goto loc_8B0CFC8C;
loc_8B0CFC3C:
	// bne cr6,0x8b0cfc54
	if (!ctx.cr6.eq) goto loc_8B0CFC54;
	// extsb r11,r29
	ctx.r11.s64 = ctx.r29.s8;
	// cmpwi cr6,r11,103
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 103, ctx.xer);
	// bne cr6,0x8b0cfc8c
	if (!ctx.cr6.eq) goto loc_8B0CFC8C;
	// li r25,1
	ctx.r25.s64 = 1;
	// b 0x8b0cfc8c
	goto loc_8B0CFC8C;
loc_8B0CFC54:
	// cmpwi cr6,r25,512
	ctx.cr6.compare<int32_t>(ctx.r25.s32, 512, ctx.xer);
	// ble cr6,0x8b0cfc60
	if (!ctx.cr6.gt) goto loc_8B0CFC60;
	// li r25,512
	ctx.r25.s64 = 512;
loc_8B0CFC60:
	// cmpwi cr6,r25,163
	ctx.cr6.compare<int32_t>(ctx.r25.s32, 163, ctx.xer);
	// ble cr6,0x8b0cfc8c
	if (!ctx.cr6.gt) goto loc_8B0CFC8C;
	// addi r31,r25,349
	ctx.r31.s64 = ctx.r25.s64 + 349;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b090000
	ctx.lr = 0x8B0CFC74;
	sub_8B090000(ctx, base);
	// mr. r14,r3
	ctx.r14.u64 = ctx.r3.u64;
	ctx.cr0.compare<int32_t>(ctx.r14.s32, 0, ctx.xer);
	// beq 0x8b0cfc88
	if (ctx.cr0.eq) goto loc_8B0CFC88;
	// mr r28,r14
	ctx.r28.u64 = ctx.r14.u64;
	// mr r30,r31
	ctx.r30.u64 = ctx.r31.u64;
	// b 0x8b0cfc8c
	goto loc_8B0CFC8C;
loc_8B0CFC88:
	// li r25,163
	ctx.r25.s64 = 163;
loc_8B0CFC8C:
	// addi r11,r26,7
	ctx.r11.s64 = ctx.r26.s64 + 7;
	// lwz r10,24(r22)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r22.u32 + 24);
	// extsb r31,r29
	ctx.r31.s64 = ctx.r29.s8;
	// rlwinm r11,r11,0,0,28
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 0) & 0xFFFFFFF8;
	// mr r9,r23
	ctx.r9.u64 = ctx.r23.u64;
	// mr r8,r21
	ctx.r8.u64 = ctx.r21.u64;
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// mr r7,r25
	ctx.r7.u64 = ctx.r25.u64;
	// mr r6,r31
	ctx.r6.u64 = ctx.r31.u64;
	// ld r10,0(r11)
	ctx.r10.u64 = REX_LOAD_U64(ctx.r11.u32 + 0);
	// mr r5,r30
	ctx.r5.u64 = ctx.r30.u64;
	// mr r4,r28
	ctx.r4.u64 = ctx.r28.u64;
	// addi r3,r1,128
	ctx.r3.s64 = ctx.r1.s64 + 128;
	// addi r26,r11,8
	ctx.r26.s64 = ctx.r11.s64 + 8;
	// std r10,128(r1)
	REX_STORE_U64(ctx.r1.u32 + 128, ctx.r10.u64);
	// bctrl 
	ctx.lr = 0x8B0CFCCC;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// rlwinm. r30,r27,0,24,24
	ctx.r30.u64 = __builtin_rotateleft64(ctx.r27.u32 | (ctx.r27.u64 << 32), 0) & 0x80;
	ctx.cr0.compare<int32_t>(ctx.r30.s32, 0, ctx.xer);
	// beq 0x8b0cfcf0
	if (ctx.cr0.eq) goto loc_8B0CFCF0;
	// cmpwi cr6,r25,0
	ctx.cr6.compare<int32_t>(ctx.r25.s32, 0, ctx.xer);
	// bne cr6,0x8b0cfcf0
	if (!ctx.cr6.eq) goto loc_8B0CFCF0;
	// lwz r11,36(r22)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r22.u32 + 36);
	// mr r4,r23
	ctx.r4.u64 = ctx.r23.u64;
	// mr r3,r28
	ctx.r3.u64 = ctx.r28.u64;
	// mtctr r11
	ctx.ctr.u64 = ctx.r11.u64;
	// bctrl 
	ctx.lr = 0x8B0CFCF0;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
loc_8B0CFCF0:
	// cmpwi cr6,r31,103
	ctx.cr6.compare<int32_t>(ctx.r31.s32, 103, ctx.xer);
	// bne cr6,0x8b0cfd14
	if (!ctx.cr6.eq) goto loc_8B0CFD14;
	// cmpwi cr6,r30,0
	ctx.cr6.compare<int32_t>(ctx.r30.s32, 0, ctx.xer);
	// bne cr6,0x8b0cfd14
	if (!ctx.cr6.eq) goto loc_8B0CFD14;
	// lwz r11,32(r22)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r22.u32 + 32);
	// mr r4,r23
	ctx.r4.u64 = ctx.r23.u64;
	// mr r3,r28
	ctx.r3.u64 = ctx.r28.u64;
	// mtctr r11
	ctx.ctr.u64 = ctx.r11.u64;
	// bctrl 
	ctx.lr = 0x8B0CFD14;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
loc_8B0CFD14:
	// lbz r11,0(r28)
	ctx.r11.u64 = REX_LOAD_U8(ctx.r28.u32 + 0);
	// cmplwi cr6,r11,45
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 45, ctx.xer);
	// bne cr6,0x8b0cfd28
	if (!ctx.cr6.eq) goto loc_8B0CFD28;
	// ori r27,r27,256
	ctx.r27.u64 = ctx.r27.u64 | 256;
	// addi r28,r28,1
	ctx.r28.s64 = ctx.r28.s64 + 1;
loc_8B0CFD28:
	// mr r11,r28
	ctx.r11.u64 = ctx.r28.u64;
loc_8B0CFD2C:
	// lbz r10,0(r11)
	ctx.r10.u64 = REX_LOAD_U8(ctx.r11.u32 + 0);
	// addi r11,r11,1
	ctx.r11.s64 = ctx.r11.s64 + 1;
	// cmplwi cr6,r10,0
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 0, ctx.xer);
	// bne cr6,0x8b0cfd2c
	if (!ctx.cr6.eq) goto loc_8B0CFD2C;
	// subf r11,r28,r11
	ctx.r11.u64 = ctx.r11.u64 - ctx.r28.u64;
	// b 0x8b0cfb14
	goto loc_8B0CFB14;
loc_8B0CFD44:
	// ori r27,r27,64
	ctx.r27.u64 = ctx.r27.u64 | 64;
loc_8B0CFD48:
	// li r8,10
	ctx.r8.s64 = 10;
	// b 0x8b0cfd9c
	goto loc_8B0CFD9C;
loc_8B0CFD50:
	// li r25,8
	ctx.r25.s64 = 8;
loc_8B0CFD54:
	// li r11,7
	ctx.r11.s64 = 7;
	// b 0x8b0cfd60
	goto loc_8B0CFD60;
loc_8B0CFD5C:
	// li r11,39
	ctx.r11.s64 = 39;
loc_8B0CFD60:
	// stw r11,104(r1)
	REX_STORE_U32(ctx.r1.u32 + 104, ctx.r11.u32);
	// rlwinm. r10,r27,0,24,24
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r27.u32 | (ctx.r27.u64 << 32), 0) & 0x80;
	ctx.cr0.compare<int32_t>(ctx.r10.s32, 0, ctx.xer);
	// li r8,16
	ctx.r8.s64 = 16;
	// beq 0x8b0cfd9c
	if (ctx.cr0.eq) goto loc_8B0CFD9C;
	// addi r11,r11,81
	ctx.r11.s64 = ctx.r11.s64 + 81;
	// li r10,48
	ctx.r10.s64 = 48;
	// li r9,2
	ctx.r9.s64 = 2;
	// stb r11,89(r1)
	REX_STORE_U8(ctx.r1.u32 + 89, ctx.r11.u8);
	// stb r10,88(r1)
	REX_STORE_U8(ctx.r1.u32 + 88, ctx.r10.u8);
	// stw r9,92(r1)
	REX_STORE_U32(ctx.r1.u32 + 92, ctx.r9.u32);
	// b 0x8b0cfd9c
	goto loc_8B0CFD9C;
loc_8B0CFD8C:
	// rlwinm. r11,r27,0,24,24
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r27.u32 | (ctx.r27.u64 << 32), 0) & 0x80;
	ctx.cr0.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// li r8,8
	ctx.r8.s64 = 8;
	// beq 0x8b0cfd9c
	if (ctx.cr0.eq) goto loc_8B0CFD9C;
	// ori r27,r27,512
	ctx.r27.u64 = ctx.r27.u64 | 512;
loc_8B0CFD9C:
	// rlwinm. r11,r27,0,16,16
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r27.u32 | (ctx.r27.u64 << 32), 0) & 0x8000;
	ctx.cr0.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// bne 0x8b0cfdac
	if (!ctx.cr0.eq) goto loc_8B0CFDAC;
	// rlwinm. r11,r27,0,19,19
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r27.u32 | (ctx.r27.u64 << 32), 0) & 0x1000;
	ctx.cr0.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// beq 0x8b0cfdc0
	if (ctx.cr0.eq) goto loc_8B0CFDC0;
loc_8B0CFDAC:
	// addi r11,r26,7
	ctx.r11.s64 = ctx.r26.s64 + 7;
	// rlwinm r11,r11,0,0,28
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 0) & 0xFFFFFFF8;
	// addi r26,r11,8
	ctx.r26.s64 = ctx.r11.s64 + 8;
	// ld r11,0(r11)
	ctx.r11.u64 = REX_LOAD_U64(ctx.r11.u32 + 0);
	// b 0x8b0cfe10
	goto loc_8B0CFE10;
loc_8B0CFDC0:
	// rlwinm. r11,r27,0,26,26
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r27.u32 | (ctx.r27.u64 << 32), 0) & 0x20;
	ctx.cr0.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// beq 0x8b0cfdf0
	if (ctx.cr0.eq) goto loc_8B0CFDF0;
	// rlwinm. r11,r27,0,25,25
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r27.u32 | (ctx.r27.u64 << 32), 0) & 0x40;
	ctx.cr0.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// addi r11,r26,7
	ctx.r11.s64 = ctx.r26.s64 + 7;
	// rlwinm r11,r11,0,0,28
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 0) & 0xFFFFFFF8;
	// addi r26,r11,8
	ctx.r26.s64 = ctx.r11.s64 + 8;
	// lwz r11,4(r11)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r11.u32 + 4);
	// beq 0x8b0cfde8
	if (ctx.cr0.eq) goto loc_8B0CFDE8;
	// extsh r11,r11
	ctx.r11.s64 = ctx.r11.s16;
	// b 0x8b0cfe10
	goto loc_8B0CFE10;
loc_8B0CFDE8:
	// clrlwi r11,r11,16
	ctx.r11.u64 = ctx.r11.u32 & 0xFFFF;
	// b 0x8b0cfe10
	goto loc_8B0CFE10;
loc_8B0CFDF0:
	// rlwinm. r11,r27,0,25,25
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r27.u32 | (ctx.r27.u64 << 32), 0) & 0x40;
	ctx.cr0.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// addi r11,r26,7
	ctx.r11.s64 = ctx.r26.s64 + 7;
	// rlwinm r11,r11,0,0,28
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 0) & 0xFFFFFFF8;
	// addi r26,r11,8
	ctx.r26.s64 = ctx.r11.s64 + 8;
	// beq 0x8b0cfe0c
	if (ctx.cr0.eq) goto loc_8B0CFE0C;
	// lwa r11,4(r11)
	ctx.r11.s64 = int32_t(REX_LOAD_U32(ctx.r11.u32 + 4));
	// b 0x8b0cfe10
	goto loc_8B0CFE10;
loc_8B0CFE0C:
	// lwz r11,4(r11)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r11.u32 + 4);
loc_8B0CFE10:
	// rlwinm. r10,r27,0,25,25
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r27.u32 | (ctx.r27.u64 << 32), 0) & 0x40;
	ctx.cr0.compare<int32_t>(ctx.r10.s32, 0, ctx.xer);
	// beq 0x8b0cfe28
	if (ctx.cr0.eq) goto loc_8B0CFE28;
	// cmpdi cr6,r11,0
	ctx.cr6.compare<int64_t>(ctx.r11.s64, 0, ctx.xer);
	// bge cr6,0x8b0cfe28
	if (!ctx.cr6.lt) goto loc_8B0CFE28;
	// neg r11,r11
	ctx.r11.s64 = static_cast<int64_t>(-ctx.r11.u64);
	// ori r27,r27,256
	ctx.r27.u64 = ctx.r27.u64 | 256;
loc_8B0CFE28:
	// rlwinm. r10,r27,0,16,16
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r27.u32 | (ctx.r27.u64 << 32), 0) & 0x8000;
	ctx.cr0.compare<int32_t>(ctx.r10.s32, 0, ctx.xer);
	// bne 0x8b0cfe3c
	if (!ctx.cr0.eq) goto loc_8B0CFE3C;
	// rlwinm. r10,r27,0,19,19
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r27.u32 | (ctx.r27.u64 << 32), 0) & 0x1000;
	ctx.cr0.compare<int32_t>(ctx.r10.s32, 0, ctx.xer);
	// bne 0x8b0cfe3c
	if (!ctx.cr0.eq) goto loc_8B0CFE3C;
	// clrldi r11,r11,32
	ctx.r11.u64 = ctx.r11.u64 & 0xFFFFFFFF;
loc_8B0CFE3C:
	// cmpwi cr6,r25,0
	ctx.cr6.compare<int32_t>(ctx.r25.s32, 0, ctx.xer);
	// bge cr6,0x8b0cfe4c
	if (!ctx.cr6.lt) goto loc_8B0CFE4C;
	// li r25,1
	ctx.r25.s64 = 1;
	// b 0x8b0cfe5c
	goto loc_8B0CFE5C;
loc_8B0CFE4C:
	// rlwinm r27,r27,0,29,27
	ctx.r27.u64 = __builtin_rotateleft64(ctx.r27.u32 | (ctx.r27.u64 << 32), 0) & 0xFFFFFFFFFFFFFFF7;
	// cmpwi cr6,r25,512
	ctx.cr6.compare<int32_t>(ctx.r25.s32, 512, ctx.xer);
	// ble cr6,0x8b0cfe5c
	if (!ctx.cr6.gt) goto loc_8B0CFE5C;
	// li r25,512
	ctx.r25.s64 = 512;
loc_8B0CFE5C:
	// cmpldi cr6,r11,0
	ctx.cr6.compare<uint64_t>(ctx.r11.u64, 0, ctx.xer);
	// bne cr6,0x8b0cfe6c
	if (!ctx.cr6.eq) goto loc_8B0CFE6C;
	// li r10,0
	ctx.r10.s64 = 0;
	// stw r10,92(r1)
	REX_STORE_U32(ctx.r1.u32 + 92, ctx.r10.u32);
loc_8B0CFE6C:
	// addi r9,r1,655
	ctx.r9.s64 = ctx.r1.s64 + 655;
loc_8B0CFE70:
	// cmpwi cr6,r25,0
	ctx.cr6.compare<int32_t>(ctx.r25.s32, 0, ctx.xer);
	// addi r25,r25,-1
	ctx.r25.s64 = ctx.r25.s64 + -1;
	// bgt cr6,0x8b0cfe84
	if (ctx.cr6.gt) goto loc_8B0CFE84;
	// cmpldi cr6,r11,0
	ctx.cr6.compare<uint64_t>(ctx.r11.u64, 0, ctx.xer);
	// beq cr6,0x8b0cfec8
	if (ctx.cr6.eq) goto loc_8B0CFEC8;
loc_8B0CFE84:
	// extsw r10,r8
	ctx.r10.s64 = ctx.r8.s32;
	// divdu r7,r11,r10
	ctx.r7.u64 = ctx.r10.u64 ? ctx.r11.u64 / ctx.r10.u64 : 0;
	// tdllei r10,0
	if (ctx.r10.s64 == 0ll || ctx.r10.u64 < 0ull) ppc_trap(ctx, base, 0);
	// mulld r7,r7,r10
	ctx.r7.s64 = static_cast<int64_t>(ctx.r7.u64 * ctx.r10.u64);
	// subf r7,r7,r11
	ctx.r7.u64 = ctx.r11.u64 - ctx.r7.u64;
	// divdu r11,r11,r10
	ctx.r11.u64 = ctx.r10.u64 ? ctx.r11.u64 / ctx.r10.u64 : 0;
	// tdllei r10,0
	if (ctx.r10.s64 == 0ll || ctx.r10.u64 < 0ull) ppc_trap(ctx, base, 0);
	// rotlwi r10,r7,0
	ctx.r10.u64 = __builtin_rotateleft32(ctx.r7.u32, 0);
	// addi r10,r10,48
	ctx.r10.s64 = ctx.r10.s64 + 48;
	// cmpwi cr6,r10,57
	ctx.cr6.compare<int32_t>(ctx.r10.s32, 57, ctx.xer);
	// ble cr6,0x8b0cfeb8
	if (!ctx.cr6.gt) goto loc_8B0CFEB8;
	// lwz r7,104(r1)
	ctx.r7.u64 = REX_LOAD_U32(ctx.r1.u32 + 104);
	// add r10,r10,r7
	ctx.r10.u64 = ctx.r10.u64 + ctx.r7.u64;
loc_8B0CFEB8:
	// extsb r10,r10
	ctx.r10.s64 = ctx.r10.s8;
	// stb r10,0(r9)
	REX_STORE_U8(ctx.r9.u32 + 0, ctx.r10.u8);
	// addi r9,r9,-1
	ctx.r9.s64 = ctx.r9.s64 + -1;
	// b 0x8b0cfe70
	goto loc_8B0CFE70;
loc_8B0CFEC8:
	// addi r11,r1,655
	ctx.r11.s64 = ctx.r1.s64 + 655;
	// rlwinm. r10,r27,0,22,22
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r27.u32 | (ctx.r27.u64 << 32), 0) & 0x200;
	ctx.cr0.compare<int32_t>(ctx.r10.s32, 0, ctx.xer);
	// subf r6,r9,r11
	ctx.r6.u64 = ctx.r11.u64 - ctx.r9.u64;
	// addi r28,r9,1
	ctx.r28.s64 = ctx.r9.s64 + 1;
	// stw r6,84(r1)
	REX_STORE_U32(ctx.r1.u32 + 84, ctx.r6.u32);
	// beq 0x8b0cff04
	if (ctx.cr0.eq) goto loc_8B0CFF04;
	// cmpwi cr6,r6,0
	ctx.cr6.compare<int32_t>(ctx.r6.s32, 0, ctx.xer);
	// beq cr6,0x8b0cfef4
	if (ctx.cr6.eq) goto loc_8B0CFEF4;
	// lbz r11,0(r28)
	ctx.r11.u64 = REX_LOAD_U8(ctx.r28.u32 + 0);
	// cmplwi cr6,r11,48
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 48, ctx.xer);
	// beq cr6,0x8b0cff04
	if (ctx.cr6.eq) goto loc_8B0CFF04;
loc_8B0CFEF4:
	// li r11,48
	ctx.r11.s64 = 48;
	// addi r6,r6,1
	ctx.r6.s64 = ctx.r6.s64 + 1;
	// stbu r11,-1(r28)
	ea = -1 + ctx.r28.u32;
	REX_STORE_U8(ea, ctx.r11.u8);
	ctx.r28.u32 = ea;
loc_8B0CFF00:
	// stw r6,84(r1)
	REX_STORE_U32(ctx.r1.u32 + 84, ctx.r6.u32);
loc_8B0CFF04:
	// lwz r11,100(r1)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r1.u32 + 100);
	// cmpwi cr6,r11,0
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// bne cr6,0x8b0d00c0
	if (!ctx.cr6.eq) goto loc_8B0D00C0;
	// rlwinm. r11,r27,0,25,25
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r27.u32 | (ctx.r27.u64 << 32), 0) & 0x40;
	ctx.cr0.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// beq 0x8b0cff54
	if (ctx.cr0.eq) goto loc_8B0CFF54;
	// rlwinm. r11,r27,0,23,23
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r27.u32 | (ctx.r27.u64 << 32), 0) & 0x100;
	ctx.cr0.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// beq 0x8b0cff28
	if (ctx.cr0.eq) goto loc_8B0CFF28;
	// li r11,45
	ctx.r11.s64 = 45;
	// b 0x8b0cff34
	goto loc_8B0CFF34;
loc_8B0CFF28:
	// clrlwi. r11,r27,31
	ctx.r11.u64 = ctx.r27.u32 & 0x1;
	ctx.cr0.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// beq 0x8b0cff44
	if (ctx.cr0.eq) goto loc_8B0CFF44;
	// li r11,43
	ctx.r11.s64 = 43;
loc_8B0CFF34:
	// li r30,1
	ctx.r30.s64 = 1;
	// stb r11,88(r1)
	REX_STORE_U8(ctx.r1.u32 + 88, ctx.r11.u8);
	// stw r30,92(r1)
	REX_STORE_U32(ctx.r1.u32 + 92, ctx.r30.u32);
	// b 0x8b0cff58
	goto loc_8B0CFF58;
loc_8B0CFF44:
	// rlwinm. r11,r27,0,30,30
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r27.u32 | (ctx.r27.u64 << 32), 0) & 0x2;
	ctx.cr0.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// beq 0x8b0cff54
	if (ctx.cr0.eq) goto loc_8B0CFF54;
	// li r11,32
	ctx.r11.s64 = 32;
	// b 0x8b0cff34
	goto loc_8B0CFF34;
loc_8B0CFF54:
	// lwz r30,92(r1)
	ctx.r30.u64 = REX_LOAD_U32(ctx.r1.u32 + 92);
loc_8B0CFF58:
	// lwz r11,96(r1)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r1.u32 + 96);
	// rlwinm. r10,r27,0,28,29
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r27.u32 | (ctx.r27.u64 << 32), 0) & 0xC;
	ctx.cr0.compare<int32_t>(ctx.r10.s32, 0, ctx.xer);
	// subf r11,r6,r11
	ctx.r11.u64 = ctx.r11.u64 - ctx.r6.u64;
	// subf r29,r30,r11
	ctx.r29.u64 = ctx.r11.u64 - ctx.r30.u64;
	// bne 0x8b0cffa0
	if (!ctx.cr0.eq) goto loc_8B0CFFA0;
	// mr r31,r29
	ctx.r31.u64 = ctx.r29.u64;
	// cmpwi cr6,r29,0
	ctx.cr6.compare<int32_t>(ctx.r29.s32, 0, ctx.xer);
	// ble cr6,0x8b0cffa0
	if (!ctx.cr6.gt) goto loc_8B0CFFA0;
loc_8B0CFF78:
	// addi r5,r1,80
	ctx.r5.s64 = ctx.r1.s64 + 80;
	// mr r4,r18
	ctx.r4.u64 = ctx.r18.u64;
	// li r3,32
	ctx.r3.s64 = 32;
	// addi r31,r31,-1
	ctx.r31.s64 = ctx.r31.s64 + -1;
	// bl 0x8b0cf4b8
	ctx.lr = 0x8B0CFF8C;
	sub_8B0CF4B8(ctx, base);
	// lwz r11,80(r1)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r1.u32 + 80);
	// cmpwi cr6,r11,-1
	ctx.cr6.compare<int32_t>(ctx.r11.s32, -1, ctx.xer);
	// beq cr6,0x8b0cffa0
	if (ctx.cr6.eq) goto loc_8B0CFFA0;
	// cmpwi cr6,r31,0
	ctx.cr6.compare<int32_t>(ctx.r31.s32, 0, ctx.xer);
	// bgt cr6,0x8b0cff78
	if (ctx.cr6.gt) goto loc_8B0CFF78;
loc_8B0CFFA0:
	// addi r6,r1,80
	ctx.r6.s64 = ctx.r1.s64 + 80;
	// mr r5,r18
	ctx.r5.u64 = ctx.r18.u64;
	// mr r4,r30
	ctx.r4.u64 = ctx.r30.u64;
	// addi r3,r1,88
	ctx.r3.s64 = ctx.r1.s64 + 88;
	// bl 0x8b0cf550
	ctx.lr = 0x8B0CFFB4;
	sub_8B0CF550(ctx, base);
	// rlwinm. r11,r27,0,28,28
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r27.u32 | (ctx.r27.u64 << 32), 0) & 0x8;
	ctx.cr0.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// beq 0x8b0cfff8
	if (ctx.cr0.eq) goto loc_8B0CFFF8;
	// rlwinm. r11,r27,0,29,29
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r27.u32 | (ctx.r27.u64 << 32), 0) & 0x4;
	ctx.cr0.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// bne 0x8b0cfff8
	if (!ctx.cr0.eq) goto loc_8B0CFFF8;
	// mr r31,r29
	ctx.r31.u64 = ctx.r29.u64;
	// cmpwi cr6,r29,0
	ctx.cr6.compare<int32_t>(ctx.r29.s32, 0, ctx.xer);
	// ble cr6,0x8b0cfff8
	if (!ctx.cr6.gt) goto loc_8B0CFFF8;
loc_8B0CFFD0:
	// addi r5,r1,80
	ctx.r5.s64 = ctx.r1.s64 + 80;
	// mr r4,r18
	ctx.r4.u64 = ctx.r18.u64;
	// li r3,48
	ctx.r3.s64 = 48;
	// addi r31,r31,-1
	ctx.r31.s64 = ctx.r31.s64 + -1;
	// bl 0x8b0cf4b8
	ctx.lr = 0x8B0CFFE4;
	sub_8B0CF4B8(ctx, base);
	// lwz r11,80(r1)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r1.u32 + 80);
	// cmpwi cr6,r11,-1
	ctx.cr6.compare<int32_t>(ctx.r11.s32, -1, ctx.xer);
	// beq cr6,0x8b0cfff8
	if (ctx.cr6.eq) goto loc_8B0CFFF8;
	// cmpwi cr6,r31,0
	ctx.cr6.compare<int32_t>(ctx.r31.s32, 0, ctx.xer);
	// bgt cr6,0x8b0cffd0
	if (ctx.cr6.gt) goto loc_8B0CFFD0;
loc_8B0CFFF8:
	// lwz r4,84(r1)
	ctx.r4.u64 = REX_LOAD_U32(ctx.r1.u32 + 84);
	// cmpwi cr6,r16,0
	ctx.cr6.compare<int32_t>(ctx.r16.s32, 0, ctx.xer);
	// beq cr6,0x8b0d0068
	if (ctx.cr6.eq) goto loc_8B0D0068;
	// cmpwi cr6,r4,0
	ctx.cr6.compare<int32_t>(ctx.r4.s32, 0, ctx.xer);
	// ble cr6,0x8b0d0068
	if (!ctx.cr6.gt) goto loc_8B0D0068;
	// addi r30,r28,-2
	ctx.r30.s64 = ctx.r28.s64 + -2;
	// mr r31,r4
	ctx.r31.u64 = ctx.r4.u64;
loc_8B0D0014:
	// li r5,6
	ctx.r5.s64 = 6;
	// lhzu r6,2(r30)
	ea = 2 + ctx.r30.u32;
	ctx.r6.u64 = REX_LOAD_U16(ea);
	ctx.r30.u32 = ea;
	// addi r4,r1,116
	ctx.r4.s64 = ctx.r1.s64 + 116;
	// addi r3,r1,112
	ctx.r3.s64 = ctx.r1.s64 + 112;
	// addi r31,r31,-1
	ctx.r31.s64 = ctx.r31.s64 + -1;
	// bl 0x8b0d6e10
	ctx.lr = 0x8B0D002C;
	sub_8B0D6E10(ctx, base);
	// cmpwi r3,0
	ctx.cr0.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// bne 0x8b0d005c
	if (!ctx.cr0.eq) goto loc_8B0D005C;
	// lwz r4,112(r1)
	ctx.r4.u64 = REX_LOAD_U32(ctx.r1.u32 + 112);
	// cmpwi cr6,r4,0
	ctx.cr6.compare<int32_t>(ctx.r4.s32, 0, ctx.xer);
	// beq cr6,0x8b0d005c
	if (ctx.cr6.eq) goto loc_8B0D005C;
	// addi r6,r1,80
	ctx.r6.s64 = ctx.r1.s64 + 80;
	// mr r5,r18
	ctx.r5.u64 = ctx.r18.u64;
	// addi r3,r1,116
	ctx.r3.s64 = ctx.r1.s64 + 116;
	// bl 0x8b0cf550
	ctx.lr = 0x8B0D0050;
	sub_8B0CF550(ctx, base);
	// cmpwi cr6,r31,0
	ctx.cr6.compare<int32_t>(ctx.r31.s32, 0, ctx.xer);
	// bne cr6,0x8b0d0014
	if (!ctx.cr6.eq) goto loc_8B0D0014;
	// b 0x8b0d0078
	goto loc_8B0D0078;
loc_8B0D005C:
	// li r24,-1
	ctx.r24.s64 = -1;
	// stw r24,80(r1)
	REX_STORE_U32(ctx.r1.u32 + 80, ctx.r24.u32);
	// b 0x8b0d007c
	goto loc_8B0D007C;
loc_8B0D0068:
	// addi r6,r1,80
	ctx.r6.s64 = ctx.r1.s64 + 80;
	// mr r5,r18
	ctx.r5.u64 = ctx.r18.u64;
	// mr r3,r28
	ctx.r3.u64 = ctx.r28.u64;
	// bl 0x8b0cf550
	ctx.lr = 0x8B0D0078;
	sub_8B0CF550(ctx, base);
loc_8B0D0078:
	// lwz r24,80(r1)
	ctx.r24.u64 = REX_LOAD_U32(ctx.r1.u32 + 80);
loc_8B0D007C:
	// cmpwi cr6,r24,0
	ctx.cr6.compare<int32_t>(ctx.r24.s32, 0, ctx.xer);
	// blt cr6,0x8b0d00c0
	if (ctx.cr6.lt) goto loc_8B0D00C0;
	// rlwinm. r11,r27,0,29,29
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r27.u32 | (ctx.r27.u64 << 32), 0) & 0x4;
	ctx.cr0.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// beq 0x8b0d00c0
	if (ctx.cr0.eq) goto loc_8B0D00C0;
	// mr r31,r29
	ctx.r31.u64 = ctx.r29.u64;
	// cmpwi cr6,r29,0
	ctx.cr6.compare<int32_t>(ctx.r29.s32, 0, ctx.xer);
	// ble cr6,0x8b0d00c0
	if (!ctx.cr6.gt) goto loc_8B0D00C0;
loc_8B0D0098:
	// addi r5,r1,80
	ctx.r5.s64 = ctx.r1.s64 + 80;
	// mr r4,r18
	ctx.r4.u64 = ctx.r18.u64;
	// li r3,32
	ctx.r3.s64 = 32;
	// addi r31,r31,-1
	ctx.r31.s64 = ctx.r31.s64 + -1;
	// bl 0x8b0cf4b8
	ctx.lr = 0x8B0D00AC;
	sub_8B0CF4B8(ctx, base);
	// lwz r24,80(r1)
	ctx.r24.u64 = REX_LOAD_U32(ctx.r1.u32 + 80);
	// cmpwi cr6,r24,-1
	ctx.cr6.compare<int32_t>(ctx.r24.s32, -1, ctx.xer);
	// beq cr6,0x8b0d00c0
	if (ctx.cr6.eq) goto loc_8B0D00C0;
	// cmpwi cr6,r31,0
	ctx.cr6.compare<int32_t>(ctx.r31.s32, 0, ctx.xer);
	// bgt cr6,0x8b0d0098
	if (ctx.cr6.gt) goto loc_8B0D0098;
loc_8B0D00C0:
	// cmplwi cr6,r14,0
	ctx.cr6.compare<uint32_t>(ctx.r14.u32, 0, ctx.xer);
	// beq cr6,0x8b0d00d4
	if (ctx.cr6.eq) goto loc_8B0D00D4;
	// mr r3,r14
	ctx.r3.u64 = ctx.r14.u64;
	// bl 0x8b090020
	ctx.lr = 0x8B0D00D0;
	sub_8B090020(ctx, base);
	// li r14,0
	ctx.r14.s64 = 0;
loc_8B0D00D4:
	// lbz r29,1(r19)
	ctx.r29.u64 = REX_LOAD_U8(ctx.r19.u32 + 1);
	// extsb. r8,r29
	ctx.r8.s64 = ctx.r29.s8;
	ctx.cr0.compare<int32_t>(ctx.r8.s32, 0, ctx.xer);
	// beq 0x8b0d00f0
	if (ctx.cr0.eq) goto loc_8B0D00F0;
	// lwz r7,108(r1)
	ctx.r7.u64 = REX_LOAD_U32(ctx.r1.u32 + 108);
	// li r30,0
	ctx.r30.s64 = 0;
	// lwz r6,84(r1)
	ctx.r6.u64 = REX_LOAD_U32(ctx.r1.u32 + 84);
	// b 0x8b0cf770
	goto loc_8B0CF770;
loc_8B0D00F0:
	// mr r3,r24
	ctx.r3.u64 = ctx.r24.u64;
	// b 0x8b0d012c
	goto loc_8B0D012C;
loc_8B0D00F8:
	// mr r6,r26
	ctx.r6.u64 = ctx.r26.u64;
	// mr r5,r31
	ctx.r5.u64 = ctx.r31.u64;
	// li r4,512
	ctx.r4.s64 = 512;
	// addi r3,r1,656
	ctx.r3.s64 = ctx.r1.s64 + 656;
	// bl 0x8b0cbb20
	ctx.lr = 0x8B0D010C;
	sub_8B0CBB20(ctx, base);
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// cmpwi cr6,r3,-1
	ctx.cr6.compare<int32_t>(ctx.r3.s32, -1, ctx.xer);
	// bne cr6,0x8b0d0120
	if (!ctx.cr6.eq) goto loc_8B0D0120;
	// li r31,511
	ctx.r31.s64 = 511;
	// stb r30,1167(r1)
	REX_STORE_U8(ctx.r1.u32 + 1167, ctx.r30.u8);
loc_8B0D0120:
	// addi r3,r1,656
	ctx.r3.s64 = ctx.r1.s64 + 656;
	// bl 0x8b0dc650
	ctx.lr = 0x8B0D0128;
	sub_8B0DC650(ctx, base);
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
loc_8B0D012C:
	// addi r1,r1,1328
	ctx.r1.s64 = ctx.r1.s64 + 1328;
	// b 0x8b0cb9d0
	__restgprlr_14(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0D5358) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9b4
	ctx.lr = 0x8B0D5360;
	__savegprlr_27(ctx, base);
	// stwu r1,-160(r1)
	ea = -160 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// mr r29,r3
	ctx.r29.u64 = ctx.r3.u64;
	// mr r28,r4
	ctx.r28.u64 = ctx.r4.u64;
	// mr r10,r8
	ctx.r10.u64 = ctx.r8.u64;
	// mr r5,r4
	ctx.r5.u64 = ctx.r4.u64;
	// li r27,0
	ctx.r27.s64 = 0;
	// li r9,0
	ctx.r9.s64 = 0;
	// li r8,0
	ctx.r8.s64 = 0;
	// li r7,0
	ctx.r7.s64 = 0;
	// li r6,0
	ctx.r6.s64 = 0;
	// addi r4,r1,80
	ctx.r4.s64 = ctx.r1.s64 + 80;
	// addi r3,r1,96
	ctx.r3.s64 = ctx.r1.s64 + 96;
	// mr r30,r27
	ctx.r30.u64 = ctx.r27.u64;
	// bl 0x8b0d5410
	ctx.lr = 0x8B0D5398;
	sub_8B0D5410(ctx, base);
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// rlwinm. r11,r3,0,29,29
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r3.u32 | (ctx.r3.u64 << 32), 0) & 0x4;
	ctx.cr0.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// beq 0x8b0d53b4
	if (ctx.cr0.eq) goto loc_8B0D53B4;
	// li r30,512
	ctx.r30.s64 = 512;
	// stw r27,88(r1)
	REX_STORE_U32(ctx.r1.u32 + 88, ctx.r27.u32);
	// stw r27,92(r1)
	REX_STORE_U32(ctx.r1.u32 + 92, ctx.r27.u32);
	// b 0x8b0d53e8
	goto loc_8B0D53E8;
loc_8B0D53B4:
	// addi r4,r1,88
	ctx.r4.s64 = ctx.r1.s64 + 88;
	// addi r3,r1,96
	ctx.r3.s64 = ctx.r1.s64 + 96;
	// bl 0x8b0d8908
	ctx.lr = 0x8B0D53C0;
	sub_8B0D8908(ctx, base);
	// rlwinm. r11,r31,0,30,30
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r31.u32 | (ctx.r31.u64 << 32), 0) & 0x2;
	ctx.cr0.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// bne 0x8b0d53d0
	if (!ctx.cr0.eq) goto loc_8B0D53D0;
	// cmpwi cr6,r3,1
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 1, ctx.xer);
	// bne cr6,0x8b0d53d4
	if (!ctx.cr6.eq) goto loc_8B0D53D4;
loc_8B0D53D0:
	// li r30,128
	ctx.r30.s64 = 128;
loc_8B0D53D4:
	// clrlwi. r11,r31,31
	ctx.r11.u64 = ctx.r31.u32 & 0x1;
	ctx.cr0.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// bne 0x8b0d53e4
	if (!ctx.cr0.eq) goto loc_8B0D53E4;
	// cmpwi cr6,r3,2
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 2, ctx.xer);
	// bne cr6,0x8b0d53e8
	if (!ctx.cr6.eq) goto loc_8B0D53E8;
loc_8B0D53E4:
	// ori r30,r30,256
	ctx.r30.u64 = ctx.r30.u64 | 256;
loc_8B0D53E8:
	// lwz r11,80(r1)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r1.u32 + 80);
	// mr r3,r29
	ctx.r3.u64 = ctx.r29.u64;
	// ld r10,88(r1)
	ctx.r10.u64 = REX_LOAD_U64(ctx.r1.u32 + 88);
	// subf r11,r28,r11
	ctx.r11.u64 = ctx.r11.u64 - ctx.r28.u64;
	// stw r30,0(r29)
	REX_STORE_U32(ctx.r29.u32 + 0, ctx.r30.u32);
	// stw r11,4(r29)
	REX_STORE_U32(ctx.r29.u32 + 4, ctx.r11.u32);
	// std r10,16(r29)
	REX_STORE_U64(ctx.r29.u32 + 16, ctx.r10.u64);
	// addi r1,r1,160
	ctx.r1.s64 = ctx.r1.s64 + 160;
	// b 0x8b0cba04
	__restgprlr_27(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0D5410) {
	REX_FUNC_PROLOGUE();
	PPCRegister temp{};
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb994
	ctx.lr = 0x8B0D5418;
	__savegprlr_19(ctx, base);
	// stwu r1,-272(r1)
	ea = -272 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// li r22,0
	ctx.r22.s64 = 0;
	// mr r20,r3
	ctx.r20.u64 = ctx.r3.u64;
	// mr r23,r6
	ctx.r23.u64 = ctx.r6.u64;
	// mr r25,r7
	ctx.r25.u64 = ctx.r7.u64;
	// mr r24,r8
	ctx.r24.u64 = ctx.r8.u64;
	// addi r3,r1,128
	ctx.r3.s64 = ctx.r1.s64 + 128;
	// mr r19,r22
	ctx.r19.u64 = ctx.r22.u64;
	// mr r6,r22
	ctx.r6.u64 = ctx.r22.u64;
	// mr r30,r22
	ctx.r30.u64 = ctx.r22.u64;
	// mr r26,r22
	ctx.r26.u64 = ctx.r22.u64;
	// mr r28,r22
	ctx.r28.u64 = ctx.r22.u64;
	// mr r29,r22
	ctx.r29.u64 = ctx.r22.u64;
	// mr r31,r22
	ctx.r31.u64 = ctx.r22.u64;
	// li r27,1
	ctx.r27.s64 = 1;
	// mr r11,r22
	ctx.r11.u64 = ctx.r22.u64;
	// cmplwi cr6,r10,0
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 0, ctx.xer);
	// bne cr6,0x8b0d548c
	if (!ctx.cr6.eq) goto loc_8B0D548C;
	// bl 0x8b0d0288
	ctx.lr = 0x8B0D5464;
	sub_8B0D0288(ctx, base);
	// li r11,22
	ctx.r11.s64 = 22;
	// li r7,0
	ctx.r7.s64 = 0;
	// stw r11,0(r3)
	REX_STORE_U32(ctx.r3.u32 + 0, ctx.r11.u32);
	// li r6,0
	ctx.r6.s64 = 0;
	// li r5,0
	ctx.r5.s64 = 0;
	// li r4,0
	ctx.r4.s64 = 0;
	// li r3,0
	ctx.r3.s64 = 0;
	// bl 0x8b0d0148
	ctx.lr = 0x8B0D5484;
	sub_8B0D0148(ctx, base);
	// li r3,0
	ctx.r3.s64 = 0;
	// b 0x8b0d5d64
	goto loc_8B0D5D64;
loc_8B0D548C:
	// mr r8,r5
	ctx.r8.u64 = ctx.r5.u64;
loc_8B0D5490:
	// lbz r10,0(r8)
	ctx.r10.u64 = REX_LOAD_U8(ctx.r8.u32 + 0);
	// extsb r10,r10
	ctx.r10.s64 = ctx.r10.s8;
	// cmpwi cr6,r10,32
	ctx.cr6.compare<int32_t>(ctx.r10.s32, 32, ctx.xer);
	// beq cr6,0x8b0d54b8
	if (ctx.cr6.eq) goto loc_8B0D54B8;
	// cmpwi cr6,r10,9
	ctx.cr6.compare<int32_t>(ctx.r10.s32, 9, ctx.xer);
	// beq cr6,0x8b0d54b8
	if (ctx.cr6.eq) goto loc_8B0D54B8;
	// cmpwi cr6,r10,10
	ctx.cr6.compare<int32_t>(ctx.r10.s32, 10, ctx.xer);
	// beq cr6,0x8b0d54b8
	if (ctx.cr6.eq) goto loc_8B0D54B8;
	// cmpwi cr6,r10,13
	ctx.cr6.compare<int32_t>(ctx.r10.s32, 13, ctx.xer);
	// bne cr6,0x8b0d54c0
	if (!ctx.cr6.eq) goto loc_8B0D54C0;
loc_8B0D54B8:
	// addi r8,r8,1
	ctx.r8.s64 = ctx.r8.s64 + 1;
	// b 0x8b0d5490
	goto loc_8B0D5490;
loc_8B0D54C0:
	// lis r10,-29938
	ctx.r10.s64 = -1962016768;
	// lis r7,0
	ctx.r7.s64 = 0;
	// ori r21,r7,32768
	ctx.r21.u64 = ctx.r7.u64 | 32768;
	// lwz r7,13620(r10)
	ctx.r7.u64 = REX_LOAD_U32(ctx.r10.u32 + 13620);
loc_8B0D54D0:
	// lbz r10,0(r8)
	ctx.r10.u64 = REX_LOAD_U8(ctx.r8.u32 + 0);
	// addi r8,r8,1
	ctx.r8.s64 = ctx.r8.s64 + 1;
	// cmplwi cr6,r11,11
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 11, ctx.xer);
	// bgt cr6,0x8b0d5848
	if (ctx.cr6.gt) goto loc_8B0D5848;
	// lis r12,-29943
	ctx.r12.s64 = -1962344448;
	// addi r12,r12,-22128
	ctx.r12.s64 = ctx.r12.s64 + -22128;
	// lbzx r0,r12,r11
	ctx.r0.u64 = REX_LOAD_U8(ctx.r12.u32 + ctx.r11.u32);
	// rlwinm r0,r0,2,0,29
	ctx.r0.u64 = __builtin_rotateleft64(ctx.r0.u32 | (ctx.r0.u64 << 32), 2) & 0xFFFFFFFC;
	// lis r12,-29939
	ctx.r12.s64 = -1962082304;
	// nop 
	// addi r12,r12,21768
	ctx.r12.s64 = ctx.r12.s64 + 21768;
	// add r12,r12,r0
	ctx.r12.u64 = ctx.r12.u64 + ctx.r0.u64;
	// mtctr r12
	ctx.ctr.u64 = ctx.r12.u64;
	// bctr 
	switch (ctx.r11.u32) {
	case 0:
		goto loc_8B0D5508;
	case 1:
		goto loc_8B0D557C;
	case 2:
		goto loc_8B0D55FC;
	case 3:
		goto loc_8B0D5678;
	case 4:
		goto loc_8B0D56E8;
	case 5:
		goto loc_8B0D575C;
	case 6:
		goto loc_8B0D577C;
	case 7:
		goto loc_8B0D57FC;
	case 8:
		goto loc_8B0D57C4;
	case 9:
		goto loc_8B0D5854;
	case 10:
		goto loc_8B0D5848;
	case 11:
		goto loc_8B0D5814;
	default:
		__builtin_trap(); // Switch case out of range
	}
loc_8B0D5508:
	// extsb r11,r10
	ctx.r11.s64 = ctx.r10.s8;
	// cmpwi cr6,r11,49
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 49, ctx.xer);
	// blt cr6,0x8b0d5528
	if (ctx.cr6.lt) goto loc_8B0D5528;
	// cmpwi cr6,r11,57
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 57, ctx.xer);
	// bgt cr6,0x8b0d5528
	if (ctx.cr6.gt) goto loc_8B0D5528;
loc_8B0D551C:
	// li r11,3
	ctx.r11.s64 = 3;
loc_8B0D5520:
	// addi r8,r8,-1
	ctx.r8.s64 = ctx.r8.s64 + -1;
	// b 0x8b0d54d0
	goto loc_8B0D54D0;
loc_8B0D5528:
	// lwz r10,0(r7)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r7.u32 + 0);
	// lbz r10,0(r10)
	ctx.r10.u64 = REX_LOAD_U8(ctx.r10.u32 + 0);
	// extsb r10,r10
	ctx.r10.s64 = ctx.r10.s8;
	// cmpw cr6,r11,r10
	ctx.cr6.compare<int32_t>(ctx.r11.s32, ctx.r10.s32, ctx.xer);
	// bne cr6,0x8b0d5544
	if (!ctx.cr6.eq) goto loc_8B0D5544;
loc_8B0D553C:
	// li r11,5
	ctx.r11.s64 = 5;
	// b 0x8b0d54d0
	goto loc_8B0D54D0;
loc_8B0D5544:
	// cmpwi cr6,r11,43
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 43, ctx.xer);
	// beq cr6,0x8b0d5570
	if (ctx.cr6.eq) goto loc_8B0D5570;
	// cmpwi cr6,r11,45
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 45, ctx.xer);
	// beq cr6,0x8b0d5564
	if (ctx.cr6.eq) goto loc_8B0D5564;
	// cmpwi cr6,r11,48
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 48, ctx.xer);
	// bne cr6,0x8b0d57f4
	if (!ctx.cr6.eq) goto loc_8B0D57F4;
loc_8B0D555C:
	// li r11,1
	ctx.r11.s64 = 1;
	// b 0x8b0d54d0
	goto loc_8B0D54D0;
loc_8B0D5564:
	// li r11,2
	ctx.r11.s64 = 2;
	// mr r19,r21
	ctx.r19.u64 = ctx.r21.u64;
	// b 0x8b0d54d0
	goto loc_8B0D54D0;
loc_8B0D5570:
	// li r11,2
	ctx.r11.s64 = 2;
	// mr r19,r22
	ctx.r19.u64 = ctx.r22.u64;
	// b 0x8b0d54d0
	goto loc_8B0D54D0;
loc_8B0D557C:
	// extsb r11,r10
	ctx.r11.s64 = ctx.r10.s8;
	// li r30,1
	ctx.r30.s64 = 1;
	// cmpwi cr6,r11,49
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 49, ctx.xer);
	// blt cr6,0x8b0d5594
	if (ctx.cr6.lt) goto loc_8B0D5594;
	// cmpwi cr6,r11,57
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 57, ctx.xer);
	// ble cr6,0x8b0d551c
	if (!ctx.cr6.gt) goto loc_8B0D551C;
loc_8B0D5594:
	// lwz r10,0(r7)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r7.u32 + 0);
	// lbz r10,0(r10)
	ctx.r10.u64 = REX_LOAD_U8(ctx.r10.u32 + 0);
	// extsb r10,r10
	ctx.r10.s64 = ctx.r10.s8;
	// cmpw cr6,r11,r10
	ctx.cr6.compare<int32_t>(ctx.r11.s32, ctx.r10.s32, ctx.xer);
	// bne cr6,0x8b0d55b0
	if (!ctx.cr6.eq) goto loc_8B0D55B0;
loc_8B0D55A8:
	// li r11,4
	ctx.r11.s64 = 4;
	// b 0x8b0d54d0
	goto loc_8B0D54D0;
loc_8B0D55B0:
	// cmpwi cr6,r11,43
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 43, ctx.xer);
	// beq cr6,0x8b0d55f0
	if (ctx.cr6.eq) goto loc_8B0D55F0;
	// cmpwi cr6,r11,45
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 45, ctx.xer);
	// beq cr6,0x8b0d55f0
	if (ctx.cr6.eq) goto loc_8B0D55F0;
	// cmpwi cr6,r11,48
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 48, ctx.xer);
	// beq cr6,0x8b0d555c
	if (ctx.cr6.eq) goto loc_8B0D555C;
loc_8B0D55C8:
	// cmpwi cr6,r11,67
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 67, ctx.xer);
	// ble cr6,0x8b0d57f4
	if (!ctx.cr6.gt) goto loc_8B0D57F4;
	// cmpwi cr6,r11,69
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 69, ctx.xer);
	// ble cr6,0x8b0d55e8
	if (!ctx.cr6.gt) goto loc_8B0D55E8;
	// cmpwi cr6,r11,99
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 99, ctx.xer);
	// ble cr6,0x8b0d57f4
	if (!ctx.cr6.gt) goto loc_8B0D57F4;
	// cmpwi cr6,r11,101
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 101, ctx.xer);
	// bgt cr6,0x8b0d57f4
	if (ctx.cr6.gt) goto loc_8B0D57F4;
loc_8B0D55E8:
	// li r11,6
	ctx.r11.s64 = 6;
	// b 0x8b0d54d0
	goto loc_8B0D54D0;
loc_8B0D55F0:
	// addi r8,r8,-1
	ctx.r8.s64 = ctx.r8.s64 + -1;
	// li r11,11
	ctx.r11.s64 = 11;
	// b 0x8b0d54d0
	goto loc_8B0D54D0;
loc_8B0D55FC:
	// extsb r11,r10
	ctx.r11.s64 = ctx.r10.s8;
	// cmpwi cr6,r11,49
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 49, ctx.xer);
	// blt cr6,0x8b0d5610
	if (ctx.cr6.lt) goto loc_8B0D5610;
	// cmpwi cr6,r11,57
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 57, ctx.xer);
	// ble cr6,0x8b0d551c
	if (!ctx.cr6.gt) goto loc_8B0D551C;
loc_8B0D5610:
	// lwz r10,0(r7)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r7.u32 + 0);
	// lbz r10,0(r10)
	ctx.r10.u64 = REX_LOAD_U8(ctx.r10.u32 + 0);
	// extsb r10,r10
	ctx.r10.s64 = ctx.r10.s8;
	// cmpw cr6,r11,r10
	ctx.cr6.compare<int32_t>(ctx.r11.s32, ctx.r10.s32, ctx.xer);
	// beq cr6,0x8b0d553c
	if (ctx.cr6.eq) goto loc_8B0D553C;
	// cmpwi cr6,r11,48
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 48, ctx.xer);
	// beq cr6,0x8b0d555c
	if (ctx.cr6.eq) goto loc_8B0D555C;
loc_8B0D562C:
	// mr r8,r5
	ctx.r8.u64 = ctx.r5.u64;
loc_8B0D5630:
	// stw r8,0(r4)
	REX_STORE_U32(ctx.r4.u32 + 0, ctx.r8.u32);
	// cmpwi cr6,r30,0
	ctx.cr6.compare<int32_t>(ctx.r30.s32, 0, ctx.xer);
	// beq cr6,0x8b0d5d00
	if (ctx.cr6.eq) goto loc_8B0D5D00;
	// cmplwi cr6,r6,24
	ctx.cr6.compare<uint32_t>(ctx.r6.u32, 24, ctx.xer);
	// ble cr6,0x8b0d5668
	if (!ctx.cr6.gt) goto loc_8B0D5668;
	// lbz r11,151(r1)
	ctx.r11.u64 = REX_LOAD_U8(ctx.r1.u32 + 151);
	// extsb r11,r11
	ctx.r11.s64 = ctx.r11.s8;
	// cmpwi cr6,r11,5
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 5, ctx.xer);
	// blt cr6,0x8b0d565c
	if (ctx.cr6.lt) goto loc_8B0D565C;
	// addi r11,r11,1
	ctx.r11.s64 = ctx.r11.s64 + 1;
	// stb r11,151(r1)
	REX_STORE_U8(ctx.r1.u32 + 151, ctx.r11.u8);
loc_8B0D565C:
	// li r6,24
	ctx.r6.s64 = 24;
	// addi r3,r3,-1
	ctx.r3.s64 = ctx.r3.s64 + -1;
	// addi r31,r31,1
	ctx.r31.s64 = ctx.r31.s64 + 1;
loc_8B0D5668:
	// cmplwi cr6,r6,0
	ctx.cr6.compare<uint32_t>(ctx.r6.u32, 0, ctx.xer);
	// beq cr6,0x8b0d5cec
	if (ctx.cr6.eq) goto loc_8B0D5CEC;
	// lbzu r11,-1(r3)
	ea = -1 + ctx.r3.u32;
	ctx.r11.u64 = REX_LOAD_U8(ea);
	ctx.r3.u32 = ea;
	// b 0x8b0d58d0
	goto loc_8B0D58D0;
loc_8B0D5678:
	// extsb r11,r10
	ctx.r11.s64 = ctx.r10.s8;
	// li r30,1
	ctx.r30.s64 = 1;
	// b 0x8b0d56b8
	goto loc_8B0D56B8;
loc_8B0D5684:
	// cmpwi cr6,r11,57
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 57, ctx.xer);
	// bgt cr6,0x8b0d56c0
	if (ctx.cr6.gt) goto loc_8B0D56C0;
	// cmplwi cr6,r6,25
	ctx.cr6.compare<uint32_t>(ctx.r6.u32, 25, ctx.xer);
	// bge cr6,0x8b0d56a8
	if (!ctx.cr6.lt) goto loc_8B0D56A8;
	// addi r11,r11,-48
	ctx.r11.s64 = ctx.r11.s64 + -48;
	// addi r6,r6,1
	ctx.r6.s64 = ctx.r6.s64 + 1;
	// stb r11,0(r3)
	REX_STORE_U8(ctx.r3.u32 + 0, ctx.r11.u8);
	// addi r3,r3,1
	ctx.r3.s64 = ctx.r3.s64 + 1;
	// b 0x8b0d56ac
	goto loc_8B0D56AC;
loc_8B0D56A8:
	// addi r31,r31,1
	ctx.r31.s64 = ctx.r31.s64 + 1;
loc_8B0D56AC:
	// lbz r11,0(r8)
	ctx.r11.u64 = REX_LOAD_U8(ctx.r8.u32 + 0);
	// addi r8,r8,1
	ctx.r8.s64 = ctx.r8.s64 + 1;
	// extsb r11,r11
	ctx.r11.s64 = ctx.r11.s8;
loc_8B0D56B8:
	// cmpwi cr6,r11,48
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 48, ctx.xer);
	// bge cr6,0x8b0d5684
	if (!ctx.cr6.lt) goto loc_8B0D5684;
loc_8B0D56C0:
	// lwz r10,0(r7)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r7.u32 + 0);
	// lbz r10,0(r10)
	ctx.r10.u64 = REX_LOAD_U8(ctx.r10.u32 + 0);
	// extsb r10,r10
	ctx.r10.s64 = ctx.r10.s8;
	// cmpw cr6,r11,r10
	ctx.cr6.compare<int32_t>(ctx.r11.s32, ctx.r10.s32, ctx.xer);
	// beq cr6,0x8b0d55a8
	if (ctx.cr6.eq) goto loc_8B0D55A8;
loc_8B0D56D4:
	// cmpwi cr6,r11,43
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 43, ctx.xer);
	// beq cr6,0x8b0d55f0
	if (ctx.cr6.eq) goto loc_8B0D55F0;
	// cmpwi cr6,r11,45
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 45, ctx.xer);
	// beq cr6,0x8b0d55f0
	if (ctx.cr6.eq) goto loc_8B0D55F0;
	// b 0x8b0d55c8
	goto loc_8B0D55C8;
loc_8B0D56E8:
	// li r30,1
	ctx.r30.s64 = 1;
	// li r26,1
	ctx.r26.s64 = 1;
	// cmplwi cr6,r6,0
	ctx.cr6.compare<uint32_t>(ctx.r6.u32, 0, ctx.xer);
	// bne cr6,0x8b0d5718
	if (!ctx.cr6.eq) goto loc_8B0D5718;
	// extsb r11,r10
	ctx.r11.s64 = ctx.r10.s8;
	// cmpwi cr6,r11,48
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 48, ctx.xer);
	// bne cr6,0x8b0d5718
	if (!ctx.cr6.eq) goto loc_8B0D5718;
loc_8B0D5704:
	// lbz r10,0(r8)
	ctx.r10.u64 = REX_LOAD_U8(ctx.r8.u32 + 0);
	// addi r31,r31,-1
	ctx.r31.s64 = ctx.r31.s64 + -1;
	// addi r8,r8,1
	ctx.r8.s64 = ctx.r8.s64 + 1;
	// cmplwi cr6,r10,48
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 48, ctx.xer);
	// beq cr6,0x8b0d5704
	if (ctx.cr6.eq) goto loc_8B0D5704;
loc_8B0D5718:
	// extsb r11,r10
	ctx.r11.s64 = ctx.r10.s8;
	// b 0x8b0d5750
	goto loc_8B0D5750;
loc_8B0D5720:
	// cmpwi cr6,r11,57
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 57, ctx.xer);
	// bgt cr6,0x8b0d56d4
	if (ctx.cr6.gt) goto loc_8B0D56D4;
	// cmplwi cr6,r6,25
	ctx.cr6.compare<uint32_t>(ctx.r6.u32, 25, ctx.xer);
	// bge cr6,0x8b0d5744
	if (!ctx.cr6.lt) goto loc_8B0D5744;
	// addi r11,r11,-48
	ctx.r11.s64 = ctx.r11.s64 + -48;
	// addi r6,r6,1
	ctx.r6.s64 = ctx.r6.s64 + 1;
	// stb r11,0(r3)
	REX_STORE_U8(ctx.r3.u32 + 0, ctx.r11.u8);
	// addi r31,r31,-1
	ctx.r31.s64 = ctx.r31.s64 + -1;
	// addi r3,r3,1
	ctx.r3.s64 = ctx.r3.s64 + 1;
loc_8B0D5744:
	// lbz r11,0(r8)
	ctx.r11.u64 = REX_LOAD_U8(ctx.r8.u32 + 0);
	// addi r8,r8,1
	ctx.r8.s64 = ctx.r8.s64 + 1;
	// extsb r11,r11
	ctx.r11.s64 = ctx.r11.s8;
loc_8B0D5750:
	// cmpwi cr6,r11,48
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 48, ctx.xer);
	// bge cr6,0x8b0d5720
	if (!ctx.cr6.lt) goto loc_8B0D5720;
	// b 0x8b0d56d4
	goto loc_8B0D56D4;
loc_8B0D575C:
	// extsb r11,r10
	ctx.r11.s64 = ctx.r10.s8;
	// li r26,1
	ctx.r26.s64 = 1;
	// cmpwi cr6,r11,48
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 48, ctx.xer);
	// blt cr6,0x8b0d562c
	if (ctx.cr6.lt) goto loc_8B0D562C;
	// cmpwi cr6,r11,57
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 57, ctx.xer);
	// bgt cr6,0x8b0d562c
	if (ctx.cr6.gt) goto loc_8B0D562C;
	// li r11,4
	ctx.r11.s64 = 4;
	// b 0x8b0d5520
	goto loc_8B0D5520;
loc_8B0D577C:
	// extsb r11,r10
	ctx.r11.s64 = ctx.r10.s8;
	// addi r5,r8,-2
	ctx.r5.s64 = ctx.r8.s64 + -2;
	// cmpwi cr6,r11,49
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 49, ctx.xer);
	// blt cr6,0x8b0d579c
	if (ctx.cr6.lt) goto loc_8B0D579C;
	// cmpwi cr6,r11,57
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 57, ctx.xer);
	// bgt cr6,0x8b0d579c
	if (ctx.cr6.gt) goto loc_8B0D579C;
loc_8B0D5794:
	// li r11,9
	ctx.r11.s64 = 9;
	// b 0x8b0d5520
	goto loc_8B0D5520;
loc_8B0D579C:
	// cmpwi cr6,r11,43
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 43, ctx.xer);
	// beq cr6,0x8b0d57bc
	if (ctx.cr6.eq) goto loc_8B0D57BC;
	// cmpwi cr6,r11,45
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 45, ctx.xer);
	// beq cr6,0x8b0d5834
	if (ctx.cr6.eq) goto loc_8B0D5834;
loc_8B0D57AC:
	// cmpwi cr6,r11,48
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 48, ctx.xer);
	// bne cr6,0x8b0d562c
	if (!ctx.cr6.eq) goto loc_8B0D562C;
	// li r11,8
	ctx.r11.s64 = 8;
	// b 0x8b0d54d0
	goto loc_8B0D54D0;
loc_8B0D57BC:
	// li r11,7
	ctx.r11.s64 = 7;
	// b 0x8b0d54d0
	goto loc_8B0D54D0;
loc_8B0D57C4:
	// extsb r11,r10
	ctx.r11.s64 = ctx.r10.s8;
	// li r28,1
	ctx.r28.s64 = 1;
	// b 0x8b0d57dc
	goto loc_8B0D57DC;
loc_8B0D57D0:
	// lbz r11,0(r8)
	ctx.r11.u64 = REX_LOAD_U8(ctx.r8.u32 + 0);
	// addi r8,r8,1
	ctx.r8.s64 = ctx.r8.s64 + 1;
	// extsb r11,r11
	ctx.r11.s64 = ctx.r11.s8;
loc_8B0D57DC:
	// cmpwi cr6,r11,48
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 48, ctx.xer);
	// beq cr6,0x8b0d57d0
	if (ctx.cr6.eq) goto loc_8B0D57D0;
	// cmpwi cr6,r11,49
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 49, ctx.xer);
	// blt cr6,0x8b0d57f4
	if (ctx.cr6.lt) goto loc_8B0D57F4;
	// cmpwi cr6,r11,57
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 57, ctx.xer);
	// ble cr6,0x8b0d5794
	if (!ctx.cr6.gt) goto loc_8B0D5794;
loc_8B0D57F4:
	// addi r8,r8,-1
	ctx.r8.s64 = ctx.r8.s64 + -1;
	// b 0x8b0d5630
	goto loc_8B0D5630;
loc_8B0D57FC:
	// extsb r11,r10
	ctx.r11.s64 = ctx.r10.s8;
	// cmpwi cr6,r11,49
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 49, ctx.xer);
	// blt cr6,0x8b0d57ac
	if (ctx.cr6.lt) goto loc_8B0D57AC;
	// cmpwi cr6,r11,57
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 57, ctx.xer);
	// ble cr6,0x8b0d5794
	if (!ctx.cr6.gt) goto loc_8B0D5794;
	// b 0x8b0d57ac
	goto loc_8B0D57AC;
loc_8B0D5814:
	// cmpwi cr6,r9,0
	ctx.cr6.compare<int32_t>(ctx.r9.s32, 0, ctx.xer);
	// beq cr6,0x8b0d5840
	if (ctx.cr6.eq) goto loc_8B0D5840;
	// extsb r11,r10
	ctx.r11.s64 = ctx.r10.s8;
	// addi r5,r8,-1
	ctx.r5.s64 = ctx.r8.s64 + -1;
	// cmpwi cr6,r11,43
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 43, ctx.xer);
	// beq cr6,0x8b0d57bc
	if (ctx.cr6.eq) goto loc_8B0D57BC;
	// cmpwi cr6,r11,45
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 45, ctx.xer);
	// bne cr6,0x8b0d562c
	if (!ctx.cr6.eq) goto loc_8B0D562C;
loc_8B0D5834:
	// li r11,7
	ctx.r11.s64 = 7;
	// li r27,-1
	ctx.r27.s64 = -1;
	// b 0x8b0d54d0
	goto loc_8B0D54D0;
loc_8B0D5840:
	// li r11,10
	ctx.r11.s64 = 10;
	// addi r8,r8,-1
	ctx.r8.s64 = ctx.r8.s64 + -1;
loc_8B0D5848:
	// cmpwi cr6,r11,10
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 10, ctx.xer);
	// bne cr6,0x8b0d54d0
	if (!ctx.cr6.eq) goto loc_8B0D54D0;
	// b 0x8b0d5630
	goto loc_8B0D5630;
loc_8B0D5854:
	// extsb r11,r10
	ctx.r11.s64 = ctx.r10.s8;
	// li r28,1
	ctx.r28.s64 = 1;
	// mr r10,r22
	ctx.r10.u64 = ctx.r22.u64;
	// b 0x8b0d588c
	goto loc_8B0D588C;
loc_8B0D5864:
	// cmpwi cr6,r11,57
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 57, ctx.xer);
	// bgt cr6,0x8b0d589c
	if (ctx.cr6.gt) goto loc_8B0D589C;
	// mulli r10,r10,10
	ctx.r10.s64 = static_cast<int64_t>(ctx.r10.u64 * static_cast<uint64_t>(10));
	// add r10,r10,r11
	ctx.r10.u64 = ctx.r10.u64 + ctx.r11.u64;
	// addi r10,r10,-48
	ctx.r10.s64 = ctx.r10.s64 + -48;
	// cmpwi cr6,r10,5200
	ctx.cr6.compare<int32_t>(ctx.r10.s32, 5200, ctx.xer);
	// bgt cr6,0x8b0d5898
	if (ctx.cr6.gt) goto loc_8B0D5898;
	// lbz r11,0(r8)
	ctx.r11.u64 = REX_LOAD_U8(ctx.r8.u32 + 0);
	// addi r8,r8,1
	ctx.r8.s64 = ctx.r8.s64 + 1;
	// extsb r11,r11
	ctx.r11.s64 = ctx.r11.s8;
loc_8B0D588C:
	// cmpwi cr6,r11,48
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 48, ctx.xer);
	// bge cr6,0x8b0d5864
	if (!ctx.cr6.lt) goto loc_8B0D5864;
	// b 0x8b0d589c
	goto loc_8B0D589C;
loc_8B0D5898:
	// li r10,5201
	ctx.r10.s64 = 5201;
loc_8B0D589C:
	// mr r29,r10
	ctx.r29.u64 = ctx.r10.u64;
	// b 0x8b0d58b8
	goto loc_8B0D58B8;
loc_8B0D58A4:
	// cmpwi cr6,r11,57
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 57, ctx.xer);
	// bgt cr6,0x8b0d57f4
	if (ctx.cr6.gt) goto loc_8B0D57F4;
	// lbz r11,0(r8)
	ctx.r11.u64 = REX_LOAD_U8(ctx.r8.u32 + 0);
	// addi r8,r8,1
	ctx.r8.s64 = ctx.r8.s64 + 1;
	// extsb r11,r11
	ctx.r11.s64 = ctx.r11.s8;
loc_8B0D58B8:
	// cmpwi cr6,r11,48
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 48, ctx.xer);
	// bge cr6,0x8b0d58a4
	if (!ctx.cr6.lt) goto loc_8B0D58A4;
	// b 0x8b0d57f4
	goto loc_8B0D57F4;
loc_8B0D58C4:
	// lbzu r11,-1(r3)
	ea = -1 + ctx.r3.u32;
	ctx.r11.u64 = REX_LOAD_U8(ea);
	ctx.r3.u32 = ea;
	// addi r6,r6,-1
	ctx.r6.s64 = ctx.r6.s64 + -1;
	// addi r31,r31,1
	ctx.r31.s64 = ctx.r31.s64 + 1;
loc_8B0D58D0:
	// cmplwi r11,0
	ctx.cr0.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// beq 0x8b0d58c4
	if (ctx.cr0.eq) goto loc_8B0D58C4;
	// addi r5,r1,96
	ctx.r5.s64 = ctx.r1.s64 + 96;
	// mr r4,r6
	ctx.r4.u64 = ctx.r6.u64;
	// addi r3,r1,128
	ctx.r3.s64 = ctx.r1.s64 + 128;
	// bl 0x8b0d9738
	ctx.lr = 0x8B0D58E8;
	sub_8B0D9738(ctx, base);
	// cmpwi cr6,r27,0
	ctx.cr6.compare<int32_t>(ctx.r27.s32, 0, ctx.xer);
	// bge cr6,0x8b0d58f4
	if (!ctx.cr6.lt) goto loc_8B0D58F4;
	// neg r29,r29
	ctx.r29.s64 = static_cast<int64_t>(-ctx.r29.u64);
loc_8B0D58F4:
	// add r11,r31,r29
	ctx.r11.u64 = ctx.r31.u64 + ctx.r29.u64;
	// cmpwi cr6,r28,0
	ctx.cr6.compare<int32_t>(ctx.r28.s32, 0, ctx.xer);
	// bne cr6,0x8b0d5904
	if (!ctx.cr6.eq) goto loc_8B0D5904;
	// add r11,r11,r25
	ctx.r11.u64 = ctx.r11.u64 + ctx.r25.u64;
loc_8B0D5904:
	// cmpwi cr6,r26,0
	ctx.cr6.compare<int32_t>(ctx.r26.s32, 0, ctx.xer);
	// bne cr6,0x8b0d5910
	if (!ctx.cr6.eq) goto loc_8B0D5910;
	// subf r11,r24,r11
	ctx.r11.u64 = ctx.r11.u64 - ctx.r24.u64;
loc_8B0D5910:
	// cmpwi cr6,r11,5200
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 5200, ctx.xer);
	// bgt cr6,0x8b0d5d18
	if (ctx.cr6.gt) goto loc_8B0D5D18;
	// cmpwi cr6,r11,-5200
	ctx.cr6.compare<int32_t>(ctx.r11.s32, -5200, ctx.xer);
	// blt cr6,0x8b0d5d30
	if (ctx.cr6.lt) goto loc_8B0D5D30;
	// lis r10,-29938
	ctx.r10.s64 = -1962016768;
	// mr r26,r11
	ctx.r26.u64 = ctx.r11.u64;
	// addi r10,r10,14640
	ctx.r10.s64 = ctx.r10.s64 + 14640;
	// cmpwi cr6,r11,0
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// addi r25,r10,-96
	ctx.r25.s64 = ctx.r10.s64 + -96;
	// beq cr6,0x8b0d5cd8
	if (ctx.cr6.eq) goto loc_8B0D5CD8;
	// bge cr6,0x8b0d594c
	if (!ctx.cr6.lt) goto loc_8B0D594C;
	// lis r10,-29938
	ctx.r10.s64 = -1962016768;
	// neg r26,r11
	ctx.r26.s64 = static_cast<int64_t>(-ctx.r11.u64);
	// addi r11,r10,14992
	ctx.r11.s64 = ctx.r10.s64 + 14992;
	// addi r25,r11,-96
	ctx.r25.s64 = ctx.r11.s64 + -96;
loc_8B0D594C:
	// subfic r11,r23,0
	ctx.xer.ca = ctx.r23.u32 <= 0;
	ctx.r11.u64 = static_cast<uint64_t>(0) - ctx.r23.u64;
	// lhz r10,106(r1)
	ctx.r10.u64 = REX_LOAD_U16(ctx.r1.u32 + 106);
	// cmpwi cr6,r26,0
	ctx.cr6.compare<int32_t>(ctx.r26.s32, 0, ctx.xer);
	// subfe r11,r11,r11
	temp.u8 = (~ctx.r11.u32 + ctx.r11.u32 < ~ctx.r11.u32) | (~ctx.r11.u32 + ctx.r11.u32 + ctx.xer.ca < ctx.xer.ca);
	ctx.r11.u64 = ~ctx.r11.u64 + ctx.r11.u64 + ctx.xer.ca;
	ctx.xer.ca = temp.u8;
	// and r11,r11,r10
	ctx.r11.u64 = ctx.r11.u64 & ctx.r10.u64;
	// sth r11,106(r1)
	REX_STORE_U16(ctx.r1.u32 + 106, ctx.r11.u16);
	// beq cr6,0x8b0d5cd8
	if (ctx.cr6.eq) goto loc_8B0D5CD8;
	// lis r11,0
	ctx.r11.s64 = 0;
	// lis r10,32767
	ctx.r10.s64 = 2147418112;
	// ori r27,r11,65535
	ctx.r27.u64 = ctx.r11.u64 | 65535;
	// li r24,-32768
	ctx.r24.s64 = -32768;
	// ori r23,r10,32768
	ctx.r23.u64 = ctx.r10.u64 | 32768;
loc_8B0D597C:
	// clrlwi. r11,r26,29
	ctx.r11.u64 = ctx.r26.u32 & 0x7;
	ctx.cr0.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// addi r25,r25,84
	ctx.r25.s64 = ctx.r25.s64 + 84;
	// srawi r26,r26,3
	ctx.xer.ca = (ctx.r26.s32 < 0) & ((ctx.r26.u32 & 0x7) != 0);
	ctx.r26.s64 = ctx.r26.s32 >> 3;
	// beq 0x8b0d5cd0
	if (ctx.cr0.eq) goto loc_8B0D5CD0;
	// mulli r11,r11,12
	ctx.r11.s64 = static_cast<int64_t>(ctx.r11.u64 * static_cast<uint64_t>(12));
	// add r4,r11,r25
	ctx.r4.u64 = ctx.r11.u64 + ctx.r25.u64;
	// lhz r11,10(r4)
	ctx.r11.u64 = REX_LOAD_U16(ctx.r4.u32 + 10);
	// cmplwi cr6,r11,32768
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 32768, ctx.xer);
	// blt cr6,0x8b0d59bc
	if (ctx.cr6.lt) goto loc_8B0D59BC;
	// addi r3,r1,112
	ctx.r3.s64 = ctx.r1.s64 + 112;
	// li r5,12
	ctx.r5.s64 = 12;
	// bl 0x8b0cbb30
	ctx.lr = 0x8B0D59AC;
	sub_8B0CBB30(ctx, base);
	// lwz r11,118(r1)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r1.u32 + 118);
	// addi r4,r1,112
	ctx.r4.s64 = ctx.r1.s64 + 112;
	// addi r11,r11,-1
	ctx.r11.s64 = ctx.r11.s64 + -1;
	// stw r11,118(r1)
	REX_STORE_U32(ctx.r1.u32 + 118, ctx.r11.u32);
loc_8B0D59BC:
	// lhz r10,96(r1)
	ctx.r10.u64 = REX_LOAD_U16(ctx.r1.u32 + 96);
	// mr r29,r22
	ctx.r29.u64 = ctx.r22.u64;
	// stw r22,88(r1)
	REX_STORE_U32(ctx.r1.u32 + 88, ctx.r22.u32);
	// stw r22,84(r1)
	REX_STORE_U32(ctx.r1.u32 + 84, ctx.r22.u32);
	// clrlwi r11,r10,17
	ctx.r11.u64 = ctx.r10.u32 & 0x7FFF;
	// stw r22,80(r1)
	REX_STORE_U32(ctx.r1.u32 + 80, ctx.r22.u32);
	// mr r9,r10
	ctx.r9.u64 = ctx.r10.u64;
	// lhz r8,0(r4)
	ctx.r8.u64 = REX_LOAD_U16(ctx.r4.u32 + 0);
	// clrlwi r10,r8,17
	ctx.r10.u64 = ctx.r8.u32 & 0x7FFF;
	// xor r8,r9,r8
	ctx.r8.u64 = ctx.r9.u64 ^ ctx.r8.u64;
	// add r7,r11,r10
	ctx.r7.u64 = ctx.r11.u64 + ctx.r10.u64;
	// mr r9,r11
	ctx.r9.u64 = ctx.r11.u64;
	// cmplwi cr6,r11,32767
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 32767, ctx.xer);
	// rlwinm r28,r8,0,16,16
	ctx.r28.u64 = __builtin_rotateleft64(ctx.r8.u32 | (ctx.r8.u64 << 32), 0) & 0x8000;
	// clrlwi r30,r7,16
	ctx.r30.u64 = ctx.r7.u32 & 0xFFFF;
	// bge cr6,0x8b0d5cb8
	if (!ctx.cr6.lt) goto loc_8B0D5CB8;
	// cmplwi cr6,r10,32767
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 32767, ctx.xer);
	// bge cr6,0x8b0d5cb8
	if (!ctx.cr6.lt) goto loc_8B0D5CB8;
	// clrlwi r11,r30,16
	ctx.r11.u64 = ctx.r30.u32 & 0xFFFF;
	// cmplwi cr6,r11,49149
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 49149, ctx.xer);
	// bgt cr6,0x8b0d5cb8
	if (ctx.cr6.gt) goto loc_8B0D5CB8;
	// cmplwi cr6,r11,16319
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 16319, ctx.xer);
	// bgt cr6,0x8b0d5a20
	if (ctx.cr6.gt) goto loc_8B0D5A20;
loc_8B0D5A18:
	// stw r22,96(r1)
	REX_STORE_U32(ctx.r1.u32 + 96, ctx.r22.u32);
	// b 0x8b0d5cc8
	goto loc_8B0D5CC8;
loc_8B0D5A20:
	// cmplwi cr6,r9,0
	ctx.cr6.compare<uint32_t>(ctx.r9.u32, 0, ctx.xer);
	// bne cr6,0x8b0d5a5c
	if (!ctx.cr6.eq) goto loc_8B0D5A5C;
	// lwz r9,96(r1)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r1.u32 + 96);
	// addi r11,r11,1
	ctx.r11.s64 = ctx.r11.s64 + 1;
	// clrlwi. r9,r9,1
	ctx.r9.u64 = ctx.r9.u32 & 0x7FFFFFFF;
	ctx.cr0.compare<int32_t>(ctx.r9.s32, 0, ctx.xer);
	// clrlwi r30,r11,16
	ctx.r30.u64 = ctx.r11.u32 & 0xFFFF;
	// bne 0x8b0d5a5c
	if (!ctx.cr0.eq) goto loc_8B0D5A5C;
	// lwz r11,100(r1)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r1.u32 + 100);
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// bne cr6,0x8b0d5a5c
	if (!ctx.cr6.eq) goto loc_8B0D5A5C;
	// lwz r11,104(r1)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r1.u32 + 104);
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// bne cr6,0x8b0d5a5c
	if (!ctx.cr6.eq) goto loc_8B0D5A5C;
	// sth r22,96(r1)
	REX_STORE_U16(ctx.r1.u32 + 96, ctx.r22.u16);
	// b 0x8b0d5cd0
	goto loc_8B0D5CD0;
loc_8B0D5A5C:
	// cmplwi cr6,r10,0
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 0, ctx.xer);
	// bne cr6,0x8b0d5a94
	if (!ctx.cr6.eq) goto loc_8B0D5A94;
	// clrlwi r11,r30,16
	ctx.r11.u64 = ctx.r30.u32 & 0xFFFF;
	// lwz r10,0(r4)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r4.u32 + 0);
	// addi r11,r11,1
	ctx.r11.s64 = ctx.r11.s64 + 1;
	// clrlwi. r10,r10,1
	ctx.r10.u64 = ctx.r10.u32 & 0x7FFFFFFF;
	ctx.cr0.compare<int32_t>(ctx.r10.s32, 0, ctx.xer);
	// clrlwi r30,r11,16
	ctx.r30.u64 = ctx.r11.u32 & 0xFFFF;
	// bne 0x8b0d5a94
	if (!ctx.cr0.eq) goto loc_8B0D5A94;
	// lwz r11,4(r4)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r4.u32 + 4);
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// bne cr6,0x8b0d5a94
	if (!ctx.cr6.eq) goto loc_8B0D5A94;
	// lwz r11,8(r4)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r4.u32 + 8);
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// beq cr6,0x8b0d5a18
	if (ctx.cr6.eq) goto loc_8B0D5A18;
loc_8B0D5A94:
	// mr r31,r22
	ctx.r31.u64 = ctx.r22.u64;
	// addi r8,r1,86
	ctx.r8.s64 = ctx.r1.s64 + 86;
	// li r3,5
	ctx.r3.s64 = 5;
loc_8B0D5AA0:
	// rlwinm r11,r31,1,0,30
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r31.u32 | (ctx.r31.u64 << 32), 1) & 0xFFFFFFFE;
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// ble cr6,0x8b0d5b0c
	if (!ctx.cr6.gt) goto loc_8B0D5B0C;
	// addi r10,r1,106
	ctx.r10.s64 = ctx.r1.s64 + 106;
	// mtctr r3
	ctx.ctr.u64 = ctx.r3.u64;
	// addi r5,r4,2
	ctx.r5.s64 = ctx.r4.s64 + 2;
	// subf r6,r11,r10
	ctx.r6.u64 = ctx.r10.u64 - ctx.r11.u64;
loc_8B0D5ABC:
	// lhz r10,0(r6)
	ctx.r10.u64 = REX_LOAD_U16(ctx.r6.u32 + 0);
	// mr r7,r22
	ctx.r7.u64 = ctx.r22.u64;
	// lhz r9,0(r5)
	ctx.r9.u64 = REX_LOAD_U16(ctx.r5.u32 + 0);
	// lwz r11,2(r8)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r8.u32 + 2);
	// mullw r9,r9,r10
	ctx.r9.s64 = int64_t(ctx.r9.s32) * int64_t(ctx.r10.s32);
	// add r10,r11,r9
	ctx.r10.u64 = ctx.r11.u64 + ctx.r9.u64;
	// cmplw cr6,r10,r11
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, ctx.r11.u32, ctx.xer);
	// blt cr6,0x8b0d5ae4
	if (ctx.cr6.lt) goto loc_8B0D5AE4;
	// cmplw cr6,r10,r9
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, ctx.r9.u32, ctx.xer);
	// bge cr6,0x8b0d5ae8
	if (!ctx.cr6.lt) goto loc_8B0D5AE8;
loc_8B0D5AE4:
	// li r7,1
	ctx.r7.s64 = 1;
loc_8B0D5AE8:
	// stw r10,2(r8)
	REX_STORE_U32(ctx.r8.u32 + 2, ctx.r10.u32);
	// cmpwi cr6,r7,0
	ctx.cr6.compare<int32_t>(ctx.r7.s32, 0, ctx.xer);
	// beq cr6,0x8b0d5b00
	if (ctx.cr6.eq) goto loc_8B0D5B00;
	// lhz r11,0(r8)
	ctx.r11.u64 = REX_LOAD_U16(ctx.r8.u32 + 0);
	// addi r11,r11,1
	ctx.r11.s64 = ctx.r11.s64 + 1;
	// sth r11,0(r8)
	REX_STORE_U16(ctx.r8.u32 + 0, ctx.r11.u16);
loc_8B0D5B00:
	// addi r6,r6,-2
	ctx.r6.s64 = ctx.r6.s64 + -2;
	// addi r5,r5,2
	ctx.r5.s64 = ctx.r5.s64 + 2;
	// bdnz 0x8b0d5abc
	--ctx.ctr.u64;
	if (ctx.ctr.u32 != 0) goto loc_8B0D5ABC;
loc_8B0D5B0C:
	// addic. r3,r3,-1
	ctx.xer.ca = ctx.r3.u32 > 0;
	ctx.r3.s64 = ctx.r3.s64 + -1;
	ctx.cr0.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// addi r8,r8,-2
	ctx.r8.s64 = ctx.r8.s64 + -2;
	// addi r31,r31,1
	ctx.r31.s64 = ctx.r31.s64 + 1;
	// bgt 0x8b0d5aa0
	if (ctx.cr0.gt) goto loc_8B0D5AA0;
	// clrlwi r11,r30,16
	ctx.r11.u64 = ctx.r30.u32 & 0xFFFF;
	// lwz r10,88(r1)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r1.u32 + 88);
	// addis r11,r11,1
	ctx.r11.s64 = ctx.r11.s64 + 65536;
	// addi r11,r11,-16382
	ctx.r11.s64 = ctx.r11.s64 + -16382;
loc_8B0D5B2C:
	// clrlwi r11,r11,16
	ctx.r11.u64 = ctx.r11.u32 & 0xFFFF;
	// extsh. r9,r11
	ctx.r9.s64 = ctx.r11.s16;
	ctx.cr0.compare<int32_t>(ctx.r9.s32, 0, ctx.xer);
	// ble 0x8b0d5b7c
	if (!ctx.cr0.gt) goto loc_8B0D5B7C;
	// lwz r8,80(r1)
	ctx.r8.u64 = REX_LOAD_U32(ctx.r1.u32 + 80);
	// rlwinm. r7,r8,0,0,0
	ctx.r7.u64 = __builtin_rotateleft64(ctx.r8.u32 | (ctx.r8.u64 << 32), 0) & 0x80000000;
	ctx.cr0.compare<int32_t>(ctx.r7.s32, 0, ctx.xer);
	// bne 0x8b0d5b7c
	if (!ctx.cr0.eq) goto loc_8B0D5B7C;
	// lwz r9,84(r1)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r1.u32 + 84);
	// rlwinm r7,r10,1,31,31
	ctx.r7.u64 = __builtin_rotateleft64(ctx.r10.u32 | (ctx.r10.u64 << 32), 1) & 0x1;
	// rlwinm r8,r8,1,0,30
	ctx.r8.u64 = __builtin_rotateleft64(ctx.r8.u32 | (ctx.r8.u64 << 32), 1) & 0xFFFFFFFE;
	// rlwinm r6,r9,1,31,31
	ctx.r6.u64 = __builtin_rotateleft64(ctx.r9.u32 | (ctx.r9.u64 << 32), 1) & 0x1;
	// rlwinm r5,r9,1,0,30
	ctx.r5.u64 = __builtin_rotateleft64(ctx.r9.u32 | (ctx.r9.u64 << 32), 1) & 0xFFFFFFFE;
	// clrlwi r11,r11,16
	ctx.r11.u64 = ctx.r11.u32 & 0xFFFF;
	// rlwinm r10,r10,1,0,30
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r10.u32 | (ctx.r10.u64 << 32), 1) & 0xFFFFFFFE;
	// or r7,r5,r7
	ctx.r7.u64 = ctx.r5.u64 | ctx.r7.u64;
	// or r8,r8,r6
	ctx.r8.u64 = ctx.r8.u64 | ctx.r6.u64;
	// stw r10,88(r1)
	REX_STORE_U32(ctx.r1.u32 + 88, ctx.r10.u32);
	// add r11,r11,r27
	ctx.r11.u64 = ctx.r11.u64 + ctx.r27.u64;
	// stw r7,84(r1)
	REX_STORE_U32(ctx.r1.u32 + 84, ctx.r7.u32);
	// stw r8,80(r1)
	REX_STORE_U32(ctx.r1.u32 + 80, ctx.r8.u32);
	// b 0x8b0d5b2c
	goto loc_8B0D5B2C;
loc_8B0D5B7C:
	// cmpwi cr6,r9,0
	ctx.cr6.compare<int32_t>(ctx.r9.s32, 0, ctx.xer);
	// bgt cr6,0x8b0d5c04
	if (ctx.cr6.gt) goto loc_8B0D5C04;
	// clrlwi r11,r11,16
	ctx.r11.u64 = ctx.r11.u32 & 0xFFFF;
	// add r11,r11,r27
	ctx.r11.u64 = ctx.r11.u64 + ctx.r27.u64;
	// clrlwi r11,r11,16
	ctx.r11.u64 = ctx.r11.u32 & 0xFFFF;
	// extsh. r9,r11
	ctx.r9.s64 = ctx.r11.s16;
	ctx.cr0.compare<int32_t>(ctx.r9.s32, 0, ctx.xer);
	// bge 0x8b0d5c04
	if (!ctx.cr0.lt) goto loc_8B0D5C04;
	// lwz r8,80(r1)
	ctx.r8.u64 = REX_LOAD_U32(ctx.r1.u32 + 80);
	// lwz r9,84(r1)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r1.u32 + 84);
loc_8B0D5BA0:
	// lhz r7,90(r1)
	ctx.r7.u64 = REX_LOAD_U16(ctx.r1.u32 + 90);
	// clrlwi. r7,r7,31
	ctx.r7.u64 = ctx.r7.u32 & 0x1;
	ctx.cr0.compare<int32_t>(ctx.r7.s32, 0, ctx.xer);
	// beq 0x8b0d5bb0
	if (ctx.cr0.eq) goto loc_8B0D5BB0;
	// addi r29,r29,1
	ctx.r29.s64 = ctx.r29.s64 + 1;
loc_8B0D5BB0:
	// clrlwi r11,r11,16
	ctx.r11.u64 = ctx.r11.u32 & 0xFFFF;
	// rlwinm r7,r9,31,0,0
	ctx.r7.u64 = __builtin_rotateleft64(ctx.r9.u32 | (ctx.r9.u64 << 32), 31) & 0x80000000;
	// addi r11,r11,1
	ctx.r11.s64 = ctx.r11.s64 + 1;
	// rlwinm r10,r10,31,1,31
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r10.u32 | (ctx.r10.u64 << 32), 31) & 0x7FFFFFFF;
	// rlwinm r6,r8,31,0,0
	ctx.r6.u64 = __builtin_rotateleft64(ctx.r8.u32 | (ctx.r8.u64 << 32), 31) & 0x80000000;
	// clrlwi r11,r11,16
	ctx.r11.u64 = ctx.r11.u32 & 0xFFFF;
	// rlwinm r9,r9,31,1,31
	ctx.r9.u64 = __builtin_rotateleft64(ctx.r9.u32 | (ctx.r9.u64 << 32), 31) & 0x7FFFFFFF;
	// or r10,r10,r7
	ctx.r10.u64 = ctx.r10.u64 | ctx.r7.u64;
	// extsh. r5,r11
	ctx.r5.s64 = ctx.r11.s16;
	ctx.cr0.compare<int32_t>(ctx.r5.s32, 0, ctx.xer);
	// rlwinm r8,r8,31,1,31
	ctx.r8.u64 = __builtin_rotateleft64(ctx.r8.u32 | (ctx.r8.u64 << 32), 31) & 0x7FFFFFFF;
	// stw r10,88(r1)
	REX_STORE_U32(ctx.r1.u32 + 88, ctx.r10.u32);
	// or r9,r9,r6
	ctx.r9.u64 = ctx.r9.u64 | ctx.r6.u64;
	// blt 0x8b0d5ba0
	if (ctx.cr0.lt) goto loc_8B0D5BA0;
	// stw r9,84(r1)
	REX_STORE_U32(ctx.r1.u32 + 84, ctx.r9.u32);
	// cmpwi cr6,r29,0
	ctx.cr6.compare<int32_t>(ctx.r29.s32, 0, ctx.xer);
	// stw r8,80(r1)
	REX_STORE_U32(ctx.r1.u32 + 80, ctx.r8.u32);
	// beq cr6,0x8b0d5c04
	if (ctx.cr6.eq) goto loc_8B0D5C04;
	// lhz r10,90(r1)
	ctx.r10.u64 = REX_LOAD_U16(ctx.r1.u32 + 90);
	// ori r10,r10,1
	ctx.r10.u64 = ctx.r10.u64 | 1;
	// sth r10,90(r1)
	REX_STORE_U16(ctx.r1.u32 + 90, ctx.r10.u16);
	// lwz r10,88(r1)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r1.u32 + 88);
loc_8B0D5C04:
	// lhz r9,90(r1)
	ctx.r9.u64 = REX_LOAD_U16(ctx.r1.u32 + 90);
	// cmplwi cr6,r9,32768
	ctx.cr6.compare<uint32_t>(ctx.r9.u32, 32768, ctx.xer);
	// bgt cr6,0x8b0d5c24
	if (ctx.cr6.gt) goto loc_8B0D5C24;
	// lis r9,1
	ctx.r9.s64 = 65536;
	// clrlwi r10,r10,15
	ctx.r10.u64 = ctx.r10.u32 & 0x1FFFF;
	// ori r9,r9,32768
	ctx.r9.u64 = ctx.r9.u64 | 32768;
	// cmplw cr6,r10,r9
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, ctx.r9.u32, ctx.xer);
	// bne cr6,0x8b0d5c84
	if (!ctx.cr6.eq) goto loc_8B0D5C84;
loc_8B0D5C24:
	// lwz r10,86(r1)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r1.u32 + 86);
	// cmpwi cr6,r10,-1
	ctx.cr6.compare<int32_t>(ctx.r10.s32, -1, ctx.xer);
	// bne cr6,0x8b0d5c7c
	if (!ctx.cr6.eq) goto loc_8B0D5C7C;
	// lwz r10,82(r1)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r1.u32 + 82);
	// stw r22,86(r1)
	REX_STORE_U32(ctx.r1.u32 + 86, ctx.r22.u32);
	// cmpwi cr6,r10,-1
	ctx.cr6.compare<int32_t>(ctx.r10.s32, -1, ctx.xer);
	// bne cr6,0x8b0d5c70
	if (!ctx.cr6.eq) goto loc_8B0D5C70;
	// lhz r10,80(r1)
	ctx.r10.u64 = REX_LOAD_U16(ctx.r1.u32 + 80);
	// stw r22,82(r1)
	REX_STORE_U32(ctx.r1.u32 + 82, ctx.r22.u32);
	// cmplwi cr6,r10,65535
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 65535, ctx.xer);
	// bne cr6,0x8b0d5c64
	if (!ctx.cr6.eq) goto loc_8B0D5C64;
	// clrlwi r11,r11,16
	ctx.r11.u64 = ctx.r11.u32 & 0xFFFF;
	// sth r21,80(r1)
	REX_STORE_U16(ctx.r1.u32 + 80, ctx.r21.u16);
	// addi r11,r11,1
	ctx.r11.s64 = ctx.r11.s64 + 1;
	// clrlwi r11,r11,16
	ctx.r11.u64 = ctx.r11.u32 & 0xFFFF;
	// b 0x8b0d5c84
	goto loc_8B0D5C84;
loc_8B0D5C64:
	// addi r10,r10,1
	ctx.r10.s64 = ctx.r10.s64 + 1;
	// sth r10,80(r1)
	REX_STORE_U16(ctx.r1.u32 + 80, ctx.r10.u16);
	// b 0x8b0d5c84
	goto loc_8B0D5C84;
loc_8B0D5C70:
	// addi r10,r10,1
	ctx.r10.s64 = ctx.r10.s64 + 1;
	// stw r10,82(r1)
	REX_STORE_U32(ctx.r1.u32 + 82, ctx.r10.u32);
	// b 0x8b0d5c84
	goto loc_8B0D5C84;
loc_8B0D5C7C:
	// addi r10,r10,1
	ctx.r10.s64 = ctx.r10.s64 + 1;
	// stw r10,86(r1)
	REX_STORE_U32(ctx.r1.u32 + 86, ctx.r10.u32);
loc_8B0D5C84:
	// clrlwi r11,r11,16
	ctx.r11.u64 = ctx.r11.u32 & 0xFFFF;
	// cmplwi cr6,r11,32767
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 32767, ctx.xer);
	// bge cr6,0x8b0d5cb8
	if (!ctx.cr6.lt) goto loc_8B0D5CB8;
	// lhz r9,88(r1)
	ctx.r9.u64 = REX_LOAD_U16(ctx.r1.u32 + 88);
	// clrlwi r10,r28,16
	ctx.r10.u64 = ctx.r28.u32 & 0xFFFF;
	// lwz r8,84(r1)
	ctx.r8.u64 = REX_LOAD_U32(ctx.r1.u32 + 84);
	// lwz r7,80(r1)
	ctx.r7.u64 = REX_LOAD_U32(ctx.r1.u32 + 80);
	// or r11,r10,r11
	ctx.r11.u64 = ctx.r10.u64 | ctx.r11.u64;
	// sth r11,96(r1)
	REX_STORE_U16(ctx.r1.u32 + 96, ctx.r11.u16);
	// sth r9,106(r1)
	REX_STORE_U16(ctx.r1.u32 + 106, ctx.r9.u16);
	// stw r8,102(r1)
	REX_STORE_U32(ctx.r1.u32 + 102, ctx.r8.u32);
	// stw r7,98(r1)
	REX_STORE_U32(ctx.r1.u32 + 98, ctx.r7.u32);
	// b 0x8b0d5cd0
	goto loc_8B0D5CD0;
loc_8B0D5CB8:
	// stw r24,96(r1)
	REX_STORE_U32(ctx.r1.u32 + 96, ctx.r24.u32);
	// clrlwi. r11,r28,16
	ctx.r11.u64 = ctx.r28.u32 & 0xFFFF;
	ctx.cr0.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// bne 0x8b0d5cc8
	if (!ctx.cr0.eq) goto loc_8B0D5CC8;
	// stw r23,96(r1)
	REX_STORE_U32(ctx.r1.u32 + 96, ctx.r23.u32);
loc_8B0D5CC8:
	// stw r22,104(r1)
	REX_STORE_U32(ctx.r1.u32 + 104, ctx.r22.u32);
	// stw r22,100(r1)
	REX_STORE_U32(ctx.r1.u32 + 100, ctx.r22.u32);
loc_8B0D5CD0:
	// cmpwi cr6,r26,0
	ctx.cr6.compare<int32_t>(ctx.r26.s32, 0, ctx.xer);
	// bne cr6,0x8b0d597c
	if (!ctx.cr6.eq) goto loc_8B0D597C;
loc_8B0D5CD8:
	// lhz r11,106(r1)
	ctx.r11.u64 = REX_LOAD_U16(ctx.r1.u32 + 106);
	// lwz r8,102(r1)
	ctx.r8.u64 = REX_LOAD_U32(ctx.r1.u32 + 102);
	// lwz r9,98(r1)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r1.u32 + 98);
	// lhz r10,96(r1)
	ctx.r10.u64 = REX_LOAD_U16(ctx.r1.u32 + 96);
	// b 0x8b0d5d44
	goto loc_8B0D5D44;
loc_8B0D5CEC:
	// mr r11,r22
	ctx.r11.u64 = ctx.r22.u64;
	// mr r10,r22
	ctx.r10.u64 = ctx.r22.u64;
	// mr r9,r22
	ctx.r9.u64 = ctx.r22.u64;
	// mr r8,r22
	ctx.r8.u64 = ctx.r22.u64;
	// b 0x8b0d5d44
	goto loc_8B0D5D44;
loc_8B0D5D00:
	// mr r11,r22
	ctx.r11.u64 = ctx.r22.u64;
	// mr r10,r22
	ctx.r10.u64 = ctx.r22.u64;
	// mr r9,r22
	ctx.r9.u64 = ctx.r22.u64;
	// mr r8,r22
	ctx.r8.u64 = ctx.r22.u64;
	// li r22,4
	ctx.r22.s64 = 4;
	// b 0x8b0d5d44
	goto loc_8B0D5D44;
loc_8B0D5D18:
	// mr r8,r22
	ctx.r8.u64 = ctx.r22.u64;
	// mr r11,r22
	ctx.r11.u64 = ctx.r22.u64;
	// li r10,32767
	ctx.r10.s64 = 32767;
	// lis r9,-32768
	ctx.r9.s64 = -2147483648;
	// li r22,2
	ctx.r22.s64 = 2;
	// b 0x8b0d5d44
	goto loc_8B0D5D44;
loc_8B0D5D30:
	// mr r11,r22
	ctx.r11.u64 = ctx.r22.u64;
	// mr r10,r22
	ctx.r10.u64 = ctx.r22.u64;
	// mr r9,r22
	ctx.r9.u64 = ctx.r22.u64;
	// mr r8,r22
	ctx.r8.u64 = ctx.r22.u64;
	// li r22,1
	ctx.r22.s64 = 1;
loc_8B0D5D44:
	// sth r11,10(r20)
	REX_STORE_U16(ctx.r20.u32 + 10, ctx.r11.u16);
	// clrlwi r10,r10,16
	ctx.r10.u64 = ctx.r10.u32 & 0xFFFF;
	// clrlwi r11,r19,16
	ctx.r11.u64 = ctx.r19.u32 & 0xFFFF;
	// stw r8,6(r20)
	REX_STORE_U32(ctx.r20.u32 + 6, ctx.r8.u32);
	// stw r9,2(r20)
	REX_STORE_U32(ctx.r20.u32 + 2, ctx.r9.u32);
	// mr r3,r22
	ctx.r3.u64 = ctx.r22.u64;
	// or r11,r10,r11
	ctx.r11.u64 = ctx.r10.u64 | ctx.r11.u64;
	// sth r11,0(r20)
	REX_STORE_U16(ctx.r20.u32 + 0, ctx.r11.u16);
loc_8B0D5D64:
	// addi r1,r1,272
	ctx.r1.s64 = ctx.r1.s64 + 272;
	// b 0x8b0cb9e4
	__restgprlr_19(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0D64F8) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// std r30,-24(r1)
	REX_STORE_U64(ctx.r1.u32 + -24, ctx.r30.u64);
	// std r31,-16(r1)
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.r31.u64);
	// stwu r1,-112(r1)
	ea = -112 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lis r11,-29936
	ctx.r11.s64 = -1961885696;
	// addi r30,r11,-16864
	ctx.r30.s64 = ctx.r11.s64 + -16864;
	// mr r31,r30
	ctx.r31.u64 = ctx.r30.u64;
loc_8B0D6518:
	// lwz r3,0(r31)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r31.u32 + 0);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0d6530
	if (ctx.cr6.eq) goto loc_8B0D6530;
	// bl 0x8b090020
	ctx.lr = 0x8B0D6528;
	sub_8B090020(ctx, base);
	// li r11,0
	ctx.r11.s64 = 0;
	// stw r11,0(r31)
	REX_STORE_U32(ctx.r31.u32 + 0, ctx.r11.u32);
loc_8B0D6530:
	// addi r31,r31,4
	ctx.r31.s64 = ctx.r31.s64 + 4;
	// addi r11,r30,256
	ctx.r11.s64 = ctx.r30.s64 + 256;
	// cmpw cr6,r31,r11
	ctx.cr6.compare<int32_t>(ctx.r31.s32, ctx.r11.s32, ctx.xer);
	// blt cr6,0x8b0d6518
	if (ctx.cr6.lt) goto loc_8B0D6518;
	// addi r1,r1,112
	ctx.r1.s64 = ctx.r1.s64 + 112;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// ld r30,-24(r1)
	ctx.r30.u64 = REX_LOAD_U64(ctx.r1.u32 + -24);
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0D67B8) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9ac
	ctx.lr = 0x8B0D67C0;
	__savegprlr_25(ctx, base);
	// addi r31,r1,-160
	ctx.r31.s64 = ctx.r1.s64 + -160;
	// stwu r1,-160(r1)
	ea = -160 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// mr r30,r3
	ctx.r30.u64 = ctx.r3.u64;
	// stw r3,180(r31)
	REX_STORE_U32(ctx.r31.u32 + 180, ctx.r3.u32);
	// mr r26,r4
	ctx.r26.u64 = ctx.r4.u64;
	// mr r25,r5
	ctx.r25.u64 = ctx.r5.u64;
	// cmpwi cr6,r3,-2
	ctx.cr6.compare<int32_t>(ctx.r3.s32, -2, ctx.xer);
	// bne cr6,0x8b0d6804
	if (!ctx.cr6.eq) goto loc_8B0D6804;
	// bl 0x8b0d02c0
	ctx.lr = 0x8B0D67E4;
	sub_8B0D02C0(ctx, base);
	// li r11,0
	ctx.r11.s64 = 0;
	// stw r11,0(r3)
	REX_STORE_U32(ctx.r3.u32 + 0, ctx.r11.u32);
	// bl 0x8b0d0288
	ctx.lr = 0x8B0D67F0;
	sub_8B0D0288(ctx, base);
	// mr r11,r3
	ctx.r11.u64 = ctx.r3.u64;
	// li r10,9
	ctx.r10.s64 = 9;
	// li r3,-1
	ctx.r3.s64 = -1;
	// stw r10,0(r11)
	REX_STORE_U32(ctx.r11.u32 + 0, ctx.r10.u32);
	// b 0x8b0d68e8
	goto loc_8B0D68E8;
loc_8B0D6804:
	// cmpwi cr6,r30,0
	ctx.cr6.compare<int32_t>(ctx.r30.s32, 0, ctx.xer);
	// blt cr6,0x8b0d681c
	if (ctx.cr6.lt) goto loc_8B0D681C;
	// lis r11,-29936
	ctx.r11.s64 = -1961885696;
	// lwz r11,-16892(r11)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r11.u32 + -16892);
	// cmplw cr6,r30,r11
	ctx.cr6.compare<uint32_t>(ctx.r30.u32, ctx.r11.u32, ctx.xer);
	// blt cr6,0x8b0d6854
	if (ctx.cr6.lt) goto loc_8B0D6854;
loc_8B0D681C:
	// bl 0x8b0d02c0
	ctx.lr = 0x8B0D6820;
	sub_8B0D02C0(ctx, base);
	// li r11,0
	ctx.r11.s64 = 0;
	// stw r11,0(r3)
	REX_STORE_U32(ctx.r3.u32 + 0, ctx.r11.u32);
	// bl 0x8b0d0288
	ctx.lr = 0x8B0D682C;
	sub_8B0D0288(ctx, base);
	// li r11,9
	ctx.r11.s64 = 9;
	// li r7,0
	ctx.r7.s64 = 0;
	// stw r11,0(r3)
	REX_STORE_U32(ctx.r3.u32 + 0, ctx.r11.u32);
	// li r6,0
	ctx.r6.s64 = 0;
	// li r5,0
	ctx.r5.s64 = 0;
	// li r4,0
	ctx.r4.s64 = 0;
	// li r3,0
	ctx.r3.s64 = 0;
	// bl 0x8b0d0148
	ctx.lr = 0x8B0D684C;
	sub_8B0D0148(ctx, base);
	// li r3,-1
	ctx.r3.s64 = -1;
	// b 0x8b0d68e8
	goto loc_8B0D68E8;
loc_8B0D6854:
	// srawi r11,r30,5
	ctx.xer.ca = (ctx.r30.s32 < 0) & ((ctx.r30.u32 & 0x1F) != 0);
	ctx.r11.s64 = ctx.r30.s32 >> 5;
	// lis r10,-29936
	ctx.r10.s64 = -1961885696;
	// rlwinm r27,r11,2,0,29
	ctx.r27.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 2) & 0xFFFFFFFC;
	// addi r28,r10,-16864
	ctx.r28.s64 = ctx.r10.s64 + -16864;
	// clrlwi r11,r30,27
	ctx.r11.u64 = ctx.r30.u32 & 0x1F;
	// mulli r29,r11,72
	ctx.r29.s64 = static_cast<int64_t>(ctx.r11.u64 * static_cast<uint64_t>(72));
	// lwzx r11,r27,r28
	ctx.r11.u64 = REX_LOAD_U32(ctx.r27.u32 + ctx.r28.u32);
	// add r11,r11,r29
	ctx.r11.u64 = ctx.r11.u64 + ctx.r29.u64;
	// lbz r11,4(r11)
	ctx.r11.u64 = REX_LOAD_U8(ctx.r11.u32 + 4);
	// clrlwi. r11,r11,31
	ctx.r11.u64 = ctx.r11.u32 & 0x1;
	ctx.cr0.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// beq 0x8b0d681c
	if (ctx.cr0.eq) goto loc_8B0D681C;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// bl 0x8b0d9b38
	ctx.lr = 0x8B0D6888;
	sub_8B0D9B38(ctx, base);
	// mr r8,r8
	ctx.r8.u64 = ctx.r8.u64;
	// lwzx r11,r27,r28
	ctx.r11.u64 = REX_LOAD_U32(ctx.r27.u32 + ctx.r28.u32);
	// add r11,r11,r29
	ctx.r11.u64 = ctx.r11.u64 + ctx.r29.u64;
	// lbz r11,4(r11)
	ctx.r11.u64 = REX_LOAD_U8(ctx.r11.u32 + 4);
	// clrlwi. r11,r11,31
	ctx.r11.u64 = ctx.r11.u32 & 0x1;
	ctx.cr0.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// beq 0x8b0d68b8
	if (ctx.cr0.eq) goto loc_8B0D68B8;
	// mr r5,r25
	ctx.r5.u64 = ctx.r25.u64;
	// mr r4,r26
	ctx.r4.u64 = ctx.r26.u64;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// bl 0x8b0d6558
	ctx.lr = 0x8B0D68B0;
	sub_8B0D6558(ctx, base);
	// stw r3,80(r31)
	REX_STORE_U32(ctx.r31.u32 + 80, ctx.r3.u32);
	// b 0x8b0d68d8
	goto loc_8B0D68D8;
loc_8B0D68B8:
	// bl 0x8b0d0288
	ctx.lr = 0x8B0D68BC;
	sub_8B0D0288(ctx, base);
	// li r11,9
	ctx.r11.s64 = 9;
	// stw r11,0(r3)
	REX_STORE_U32(ctx.r3.u32 + 0, ctx.r11.u32);
	// bl 0x8b0d02c0
	ctx.lr = 0x8B0D68C8;
	sub_8B0D02C0(ctx, base);
	// li r11,0
	ctx.r11.s64 = 0;
	// li r10,-1
	ctx.r10.s64 = -1;
	// stw r11,0(r3)
	REX_STORE_U32(ctx.r3.u32 + 0, ctx.r11.u32);
	// stw r10,80(r31)
	REX_STORE_U32(ctx.r31.u32 + 80, ctx.r10.u32);
loc_8B0D68D8:
	// mr r8,r8
	ctx.r8.u64 = ctx.r8.u64;
	// addi r12,r31,160
	ctx.r12.s64 = ctx.r31.s64 + 160;
	// bl 0x8b0d6910
	ctx.lr = 0x8B0D68E4;
	sub_8B0D6910(ctx, base);
	// lwz r3,80(r31)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r31.u32 + 80);
loc_8B0D68E8:
	// addi r1,r31,160
	ctx.r1.s64 = ctx.r31.s64 + 160;
	// b 0x8b0cb9fc
	__restgprlr_25(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0D69D0) {
	REX_FUNC_PROLOGUE();
	// lis r11,-29938
	ctx.r11.s64 = -1962016768;
	// addi r3,r11,12928
	ctx.r3.s64 = ctx.r11.s64 + 12928;
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0D69E0) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// std r30,-24(r1)
	REX_STORE_U64(ctx.r1.u32 + -24, ctx.r30.u64);
	// std r31,-16(r1)
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.r31.u64);
	// stwu r1,-112(r1)
	ea = -112 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lis r31,-29936
	ctx.r31.s64 = -1961885696;
	// lwz r3,-16896(r31)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r31.u32 + -16896);
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// bne cr6,0x8b0d6a0c
	if (!ctx.cr6.eq) goto loc_8B0D6A0C;
	// li r3,512
	ctx.r3.s64 = 512;
	// b 0x8b0d6a18
	goto loc_8B0D6A18;
loc_8B0D6A0C:
	// cmpwi cr6,r3,20
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 20, ctx.xer);
	// bge cr6,0x8b0d6a1c
	if (!ctx.cr6.lt) goto loc_8B0D6A1C;
	// li r3,20
	ctx.r3.s64 = 20;
loc_8B0D6A18:
	// stw r3,-16896(r31)
	REX_STORE_U32(ctx.r31.u32 + -16896, ctx.r3.u32);
loc_8B0D6A1C:
	// li r4,4
	ctx.r4.s64 = 4;
	// bl 0x8b090068
	ctx.lr = 0x8B0D6A24;
	sub_8B090068(ctx, base);
	// lis r30,-29936
	ctx.r30.s64 = -1961885696;
	// cmplwi r3,0
	ctx.cr0.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// stw r3,-16900(r30)
	REX_STORE_U32(ctx.r30.u32 + -16900, ctx.r3.u32);
	// bne 0x8b0d6a5c
	if (!ctx.cr0.eq) goto loc_8B0D6A5C;
	// li r11,20
	ctx.r11.s64 = 20;
	// li r4,4
	ctx.r4.s64 = 4;
	// stw r11,-16896(r31)
	REX_STORE_U32(ctx.r31.u32 + -16896, ctx.r11.u32);
	// li r3,20
	ctx.r3.s64 = 20;
	// bl 0x8b090068
	ctx.lr = 0x8B0D6A48;
	sub_8B090068(ctx, base);
	// stw r3,-16900(r30)
	REX_STORE_U32(ctx.r30.u32 + -16900, ctx.r3.u32);
	// cmplwi r3,0
	ctx.cr0.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// bne 0x8b0d6a5c
	if (!ctx.cr0.eq) goto loc_8B0D6A5C;
	// li r3,26
	ctx.r3.s64 = 26;
	// b 0x8b0d6aec
	goto loc_8B0D6AEC;
loc_8B0D6A5C:
	// lis r11,-29938
	ctx.r11.s64 = -1962016768;
	// li r9,20
	ctx.r9.s64 = 20;
	// addi r8,r11,12928
	ctx.r8.s64 = ctx.r11.s64 + 12928;
	// li r10,0
	ctx.r10.s64 = 0;
	// mr r11,r8
	ctx.r11.u64 = ctx.r8.u64;
	// mtctr r9
	ctx.ctr.u64 = ctx.r9.u64;
	// b 0x8b0d6a7c
	goto loc_8B0D6A7C;
loc_8B0D6A78:
	// lwz r3,-16900(r30)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r30.u32 + -16900);
loc_8B0D6A7C:
	// stwx r11,r10,r3
	REX_STORE_U32(ctx.r10.u32 + ctx.r3.u32, ctx.r11.u32);
	// addi r11,r11,32
	ctx.r11.s64 = ctx.r11.s64 + 32;
	// addi r10,r10,4
	ctx.r10.s64 = ctx.r10.s64 + 4;
	// bdnz 0x8b0d6a78
	--ctx.ctr.u64;
	if (ctx.ctr.u32 != 0) goto loc_8B0D6A78;
	// li r10,3
	ctx.r10.s64 = 3;
	// addi r9,r8,16
	ctx.r9.s64 = ctx.r8.s64 + 16;
	// li r11,0
	ctx.r11.s64 = 0;
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// lis r10,-29936
	ctx.r10.s64 = -1961885696;
	// addi r8,r10,-16864
	ctx.r8.s64 = ctx.r10.s64 + -16864;
loc_8B0D6AA4:
	// srawi r10,r11,5
	ctx.xer.ca = (ctx.r11.s32 < 0) & ((ctx.r11.u32 & 0x1F) != 0);
	ctx.r10.s64 = ctx.r11.s32 >> 5;
	// clrlwi r7,r11,27
	ctx.r7.u64 = ctx.r11.u32 & 0x1F;
	// rlwinm r10,r10,2,0,29
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r10.u32 | (ctx.r10.u64 << 32), 2) & 0xFFFFFFFC;
	// mulli r7,r7,72
	ctx.r7.s64 = static_cast<int64_t>(ctx.r7.u64 * static_cast<uint64_t>(72));
	// lwzx r10,r10,r8
	ctx.r10.u64 = REX_LOAD_U32(ctx.r10.u32 + ctx.r8.u32);
	// lwzx r10,r10,r7
	ctx.r10.u64 = REX_LOAD_U32(ctx.r10.u32 + ctx.r7.u32);
	// cmpwi cr6,r10,-1
	ctx.cr6.compare<int32_t>(ctx.r10.s32, -1, ctx.xer);
	// beq cr6,0x8b0d6ad4
	if (ctx.cr6.eq) goto loc_8B0D6AD4;
	// cmpwi cr6,r10,-2
	ctx.cr6.compare<int32_t>(ctx.r10.s32, -2, ctx.xer);
	// beq cr6,0x8b0d6ad4
	if (ctx.cr6.eq) goto loc_8B0D6AD4;
	// cmpwi cr6,r10,0
	ctx.cr6.compare<int32_t>(ctx.r10.s32, 0, ctx.xer);
	// bne cr6,0x8b0d6adc
	if (!ctx.cr6.eq) goto loc_8B0D6ADC;
loc_8B0D6AD4:
	// li r10,-2
	ctx.r10.s64 = -2;
	// stw r10,0(r9)
	REX_STORE_U32(ctx.r9.u32 + 0, ctx.r10.u32);
loc_8B0D6ADC:
	// addi r11,r11,1
	ctx.r11.s64 = ctx.r11.s64 + 1;
	// addi r9,r9,32
	ctx.r9.s64 = ctx.r9.s64 + 32;
	// bdnz 0x8b0d6aa4
	--ctx.ctr.u64;
	if (ctx.ctr.u32 != 0) goto loc_8B0D6AA4;
	// li r3,0
	ctx.r3.s64 = 0;
loc_8B0D6AEC:
	// addi r1,r1,112
	ctx.r1.s64 = ctx.r1.s64 + 112;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// ld r30,-24(r1)
	ctx.r30.u64 = REX_LOAD_U64(ctx.r1.u32 + -24);
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0D6EA8) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// std r30,-24(r1)
	REX_STORE_U64(ctx.r1.u32 + -24, ctx.r30.u64);
	// std r31,-16(r1)
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.r31.u64);
	// stwu r1,-128(r1)
	ea = -128 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lis r11,-29938
	ctx.r11.s64 = -1962016768;
	// mr r30,r3
	ctx.r30.u64 = ctx.r3.u64;
	// mr r5,r4
	ctx.r5.u64 = ctx.r4.u64;
	// addi r10,r11,12512
	ctx.r10.s64 = ctx.r11.s64 + 12512;
	// li r9,0
	ctx.r9.s64 = 0;
	// li r8,0
	ctx.r8.s64 = 0;
	// li r7,0
	ctx.r7.s64 = 0;
	// li r6,0
	ctx.r6.s64 = 0;
	// addi r4,r1,80
	ctx.r4.s64 = ctx.r1.s64 + 80;
	// addi r3,r1,88
	ctx.r3.s64 = ctx.r1.s64 + 88;
	// bl 0x8b0d5410
	ctx.lr = 0x8B0D6EE8;
	sub_8B0D5410(ctx, base);
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// mr r4,r30
	ctx.r4.u64 = ctx.r30.u64;
	// addi r3,r1,88
	ctx.r3.s64 = ctx.r1.s64 + 88;
	// bl 0x8b0d8908
	ctx.lr = 0x8B0D6EF8;
	sub_8B0D8908(ctx, base);
	// clrlwi. r11,r31,30
	ctx.r11.u64 = ctx.r31.u32 & 0x3;
	ctx.cr0.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// bne 0x8b0d6f20
	if (!ctx.cr0.eq) goto loc_8B0D6F20;
	// cmpwi cr6,r3,1
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 1, ctx.xer);
	// bne cr6,0x8b0d6f10
	if (!ctx.cr6.eq) goto loc_8B0D6F10;
	// li r3,3
	ctx.r3.s64 = 3;
	// b 0x8b0d6f38
	goto loc_8B0D6F38;
loc_8B0D6F10:
	// cmpwi cr6,r3,2
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 2, ctx.xer);
	// bne cr6,0x8b0d6f34
	if (!ctx.cr6.eq) goto loc_8B0D6F34;
loc_8B0D6F18:
	// li r3,4
	ctx.r3.s64 = 4;
	// b 0x8b0d6f38
	goto loc_8B0D6F38;
loc_8B0D6F20:
	// clrlwi. r11,r31,31
	ctx.r11.u64 = ctx.r31.u32 & 0x1;
	ctx.cr0.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// bne 0x8b0d6f18
	if (!ctx.cr0.eq) goto loc_8B0D6F18;
	// rlwinm. r11,r31,0,30,30
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r31.u32 | (ctx.r31.u64 << 32), 0) & 0x2;
	ctx.cr0.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// li r3,3
	ctx.r3.s64 = 3;
	// bne 0x8b0d6f38
	if (!ctx.cr0.eq) goto loc_8B0D6F38;
loc_8B0D6F34:
	// li r3,0
	ctx.r3.s64 = 0;
loc_8B0D6F38:
	// addi r1,r1,128
	ctx.r1.s64 = ctx.r1.s64 + 128;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// ld r30,-24(r1)
	ctx.r30.u64 = REX_LOAD_U64(ctx.r1.u32 + -24);
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0D7260) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9bc
	ctx.lr = 0x8B0D7268;
	__savegprlr_29(ctx, base);
	// stwu r1,-160(r1)
	ea = -160 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// std r3,176(r1)
	REX_STORE_U64(ctx.r1.u32 + 176, ctx.r3.u64);
	// mr r31,r4
	ctx.r31.u64 = ctx.r4.u64;
	// addi r4,r1,176
	ctx.r4.s64 = ctx.r1.s64 + 176;
	// addi r3,r1,80
	ctx.r3.s64 = ctx.r1.s64 + 80;
	// mr r30,r5
	ctx.r30.u64 = ctx.r5.u64;
	// mr r29,r6
	ctx.r29.u64 = ctx.r6.u64;
	// bl 0x8b0d7180
	ctx.lr = 0x8B0D7288;
	sub_8B0D7180(ctx, base);
	// lhz r11,88(r1)
	ctx.r11.u64 = REX_LOAD_U16(ctx.r1.u32 + 88);
	// addi r7,r1,96
	ctx.r7.s64 = ctx.r1.s64 + 96;
	// li r6,0
	ctx.r6.s64 = 0;
	// li r5,17
	ctx.r5.s64 = 17;
	// rldicr r4,r11,48,63
	ctx.r4.u64 = __builtin_rotateleft64(ctx.r11.u64, 48) & 0xFFFFFFFFFFFFFFFF;
	// ld r3,80(r1)
	ctx.r3.u64 = REX_LOAD_U64(ctx.r1.u32 + 80);
	// bl 0x8b0da048
	ctx.lr = 0x8B0D72A4;
	sub_8B0DA048(ctx, base);
	// lbz r11,98(r1)
	ctx.r11.u64 = REX_LOAD_U8(ctx.r1.u32 + 98);
	// addi r5,r1,100
	ctx.r5.s64 = ctx.r1.s64 + 100;
	// lha r10,96(r1)
	ctx.r10.s64 = int16_t(REX_LOAD_U16(ctx.r1.u32 + 96));
	// mr r4,r29
	ctx.r4.u64 = ctx.r29.u64;
	// extsb r11,r11
	ctx.r11.s64 = ctx.r11.s8;
	// stw r3,8(r31)
	REX_STORE_U32(ctx.r31.u32 + 8, ctx.r3.u32);
	// stw r10,4(r31)
	REX_STORE_U32(ctx.r31.u32 + 4, ctx.r10.u32);
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// stw r11,0(r31)
	REX_STORE_U32(ctx.r31.u32 + 0, ctx.r11.u32);
	// bl 0x8b0d13e0
	ctx.lr = 0x8B0D72CC;
	sub_8B0D13E0(ctx, base);
	// cmpwi r3,0
	ctx.cr0.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// beq 0x8b0d72ec
	if (ctx.cr0.eq) goto loc_8B0D72EC;
	// li r7,0
	ctx.r7.s64 = 0;
	// li r6,0
	ctx.r6.s64 = 0;
	// li r5,0
	ctx.r5.s64 = 0;
	// li r4,0
	ctx.r4.s64 = 0;
	// li r3,0
	ctx.r3.s64 = 0;
	// bl 0x8b0d0190
	ctx.lr = 0x8B0D72EC;
	sub_8B0D0190(ctx, base);
loc_8B0D72EC:
	// stw r30,12(r31)
	REX_STORE_U32(ctx.r31.u32 + 12, ctx.r30.u32);
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// addi r1,r1,160
	ctx.r1.s64 = ctx.r1.s64 + 160;
	// b 0x8b0cba0c
	__restgprlr_29(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0D760C) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// std r31,-8(r1)
	REX_STORE_U64(ctx.r1.u32 + -8, ctx.r31.u64);
	// addi r31,r12,-160
	ctx.r31.s64 = ctx.r12.s64 + -160;
	// std r28,-16(r1)
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.r28.u64);
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-24(r1)
	REX_STORE_U32(ctx.r1.u32 + -24, ctx.r12.u32);
	// stwu r1,-112(r1)
	ea = -112 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// cmpwi cr6,r28,0
	ctx.cr6.compare<int32_t>(ctx.r28.s32, 0, ctx.xer);
	// beq cr6,0x8b0d7634
	if (ctx.cr6.eq) goto loc_8B0D7634;
	// li r3,0
	ctx.r3.s64 = 0;
	// bl 0x8b0d5e60
	ctx.lr = 0x8B0D7634;
	sub_8B0D5E60(ctx, base);
loc_8B0D7634:
	// lwz r1,0(r1)
	ctx.r1.u64 = REX_LOAD_U32(ctx.r1.u32 + 0);
	// ld r31,-8(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -8);
	// ld r28,-16(r1)
	ctx.r28.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// lwz r12,-24(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -24);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0D7A00) {
	REX_FUNC_PROLOGUE();
	PPCRegister temp{};
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9bc
	ctx.lr = 0x8B0D7A08;
	__savegprlr_29(ctx, base);
	// addi r31,r1,-128
	ctx.r31.s64 = ctx.r1.s64 + -128;
	// stwu r1,-128(r1)
	ea = -128 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// mr r29,r3
	ctx.r29.u64 = ctx.r3.u64;
	// mr r30,r4
	ctx.r30.u64 = ctx.r4.u64;
	// stw r4,156(r31)
	REX_STORE_U32(ctx.r31.u32 + 156, ctx.r4.u32);
	// addic r11,r4,-1
	ctx.xer.ca = ctx.r4.u32 > 0;
	ctx.r11.s64 = ctx.r4.s64 + -1;
	// subfe. r11,r11,r4
	temp.u8 = (~ctx.r11.u32 + ctx.r4.u32 < ~ctx.r11.u32) | (~ctx.r11.u32 + ctx.r4.u32 + ctx.xer.ca < ctx.xer.ca);
	ctx.r11.u64 = ~ctx.r11.u64 + ctx.r4.u64 + ctx.xer.ca;
	ctx.xer.ca = temp.u8;
	ctx.cr0.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// bne 0x8b0d7a54
	if (!ctx.cr0.eq) goto loc_8B0D7A54;
	// bl 0x8b0d0288
	ctx.lr = 0x8B0D7A2C;
	sub_8B0D0288(ctx, base);
	// li r11,22
	ctx.r11.s64 = 22;
	// li r7,0
	ctx.r7.s64 = 0;
	// stw r11,0(r3)
	REX_STORE_U32(ctx.r3.u32 + 0, ctx.r11.u32);
	// li r6,0
	ctx.r6.s64 = 0;
	// li r5,0
	ctx.r5.s64 = 0;
	// li r4,0
	ctx.r4.s64 = 0;
	// li r3,0
	ctx.r3.s64 = 0;
	// bl 0x8b0d0148
	ctx.lr = 0x8B0D7A4C;
	sub_8B0D0148(ctx, base);
	// li r3,-1
	ctx.r3.s64 = -1;
	// b 0x8b0d7a80
	goto loc_8B0D7A80;
loc_8B0D7A54:
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// bl 0x8b0d6b48
	ctx.lr = 0x8B0D7A5C;
	sub_8B0D6B48(ctx, base);
	// mr r8,r8
	ctx.r8.u64 = ctx.r8.u64;
	// mr r4,r30
	ctx.r4.u64 = ctx.r30.u64;
	// mr r3,r29
	ctx.r3.u64 = ctx.r29.u64;
	// bl 0x8b0d7840
	ctx.lr = 0x8B0D7A6C;
	sub_8B0D7840(ctx, base);
	// stw r3,80(r31)
	REX_STORE_U32(ctx.r31.u32 + 80, ctx.r3.u32);
	// mr r8,r8
	ctx.r8.u64 = ctx.r8.u64;
	// addi r12,r31,128
	ctx.r12.s64 = ctx.r31.s64 + 128;
	// bl 0x8b0d7aa8
	ctx.lr = 0x8B0D7A7C;
	sub_8B0D7AA8(ctx, base);
	// lwz r3,80(r31)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r31.u32 + 80);
loc_8B0D7A80:
	// addi r1,r31,128
	ctx.r1.s64 = ctx.r31.s64 + 128;
	// b 0x8b0cba0c
	__restgprlr_29(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0D7AE0) {
	REX_FUNC_PROLOGUE();
	// cmplwi cr6,r4,0
	ctx.cr6.compare<uint32_t>(ctx.r4.u32, 0, ctx.xer);
	// beq cr6,0x8b0d7b0c
	if (ctx.cr6.eq) goto loc_8B0D7B0C;
	// cmplwi cr6,r5,0
	ctx.cr6.compare<uint32_t>(ctx.r5.u32, 0, ctx.xer);
	// beq cr6,0x8b0d7b0c
	if (ctx.cr6.eq) goto loc_8B0D7B0C;
	// lbz r11,0(r4)
	ctx.r11.u64 = REX_LOAD_U8(ctx.r4.u32 + 0);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// cmplwi r11,0
	ctx.cr0.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// bne 0x8b0d7b14
	if (!ctx.cr0.eq) goto loc_8B0D7B14;
	// beq cr6,0x8b0d7b0c
	if (ctx.cr6.eq) goto loc_8B0D7B0C;
	// li r11,0
	ctx.r11.s64 = 0;
	// sth r11,0(r3)
	REX_STORE_U16(ctx.r3.u32 + 0, ctx.r11.u16);
loc_8B0D7B0C:
	// li r3,0
	ctx.r3.s64 = 0;
	// blr 
	return;
loc_8B0D7B14:
	// beq cr6,0x8b0d7b20
	if (ctx.cr6.eq) goto loc_8B0D7B20;
	// clrlwi r11,r11,24
	ctx.r11.u64 = ctx.r11.u32 & 0xFF;
	// sth r11,0(r3)
	REX_STORE_U16(ctx.r3.u32 + 0, ctx.r11.u16);
loc_8B0D7B20:
	// li r3,1
	ctx.r3.s64 = 1;
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0D7B60) {
	REX_FUNC_PROLOGUE();
	// mffs f0
	ctx.f0.u64 = ctx.fpscr.loadFromHost();
	// stfd f0,-8(r1)
	ctx.fpscr.disableFlushMode();
	REX_STORE_U64(ctx.r1.u32 + -8, ctx.f0.u64);
	// lwz r3,-4(r1)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r1.u32 + -4);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0D7B94) {
	REX_FUNC_PROLOGUE();
	// mffs f0
	ctx.f0.u64 = ctx.fpscr.loadFromHost();
	// stfd f0,-8(r1)
	ctx.fpscr.disableFlushMode();
	REX_STORE_U64(ctx.r1.u32 + -8, ctx.f0.u64);
	// lwz r5,-4(r1)
	ctx.r5.u64 = REX_LOAD_U32(ctx.r1.u32 + -4);
	// or r5,r3,r5
	ctx.r5.u64 = ctx.r3.u64 | ctx.r5.u64;
	// stw r5,-4(r1)
	REX_STORE_U32(ctx.r1.u32 + -4, ctx.r5.u32);
	// lfd f1,-8(r1)
	ctx.f1.u64 = REX_LOAD_U64(ctx.r1.u32 + -8);
	// mtfsf 255,f1
	ctx.fpscr.storeFromGuest(ctx.f1.u32);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0D7BC4) {
	REX_FUNC_PROLOGUE();
	// mffs f0
	ctx.f0.u64 = ctx.fpscr.loadFromHost();
	// stfd f0,-8(r1)
	ctx.fpscr.disableFlushMode();
	REX_STORE_U64(ctx.r1.u32 + -8, ctx.f0.u64);
	// lwz r3,-4(r1)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r1.u32 + -4);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0D7E30) {
	REX_FUNC_PROLOGUE();
	// clrlwi r11,r3,16
	ctx.r11.u64 = ctx.r3.u32 & 0xFFFF;
	// cmplwi cr6,r11,48
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 48, ctx.xer);
	// blt cr6,0x8b0d7fe8
	if (ctx.cr6.lt) goto loc_8B0D7FE8;
	// cmplwi cr6,r11,58
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 58, ctx.xer);
	// bge cr6,0x8b0d7e4c
	if (!ctx.cr6.lt) goto loc_8B0D7E4C;
	// addi r3,r11,-48
	ctx.r3.s64 = ctx.r11.s64 + -48;
	// blr 
	return;
loc_8B0D7E4C:
	// cmplwi cr6,r11,65296
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 65296, ctx.xer);
	// bge cr6,0x8b0d7fd4
	if (!ctx.cr6.lt) goto loc_8B0D7FD4;
	// cmplwi cr6,r11,1632
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 1632, ctx.xer);
	// blt cr6,0x8b0d7fe8
	if (ctx.cr6.lt) goto loc_8B0D7FE8;
	// cmplwi cr6,r11,1642
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 1642, ctx.xer);
	// bge cr6,0x8b0d7e6c
	if (!ctx.cr6.lt) goto loc_8B0D7E6C;
	// addi r3,r11,-1632
	ctx.r3.s64 = ctx.r11.s64 + -1632;
	// blr 
	return;
loc_8B0D7E6C:
	// cmplwi cr6,r11,1776
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 1776, ctx.xer);
	// blt cr6,0x8b0d7fe8
	if (ctx.cr6.lt) goto loc_8B0D7FE8;
	// cmplwi cr6,r11,1786
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 1786, ctx.xer);
	// bge cr6,0x8b0d7e84
	if (!ctx.cr6.lt) goto loc_8B0D7E84;
	// addi r3,r11,-1776
	ctx.r3.s64 = ctx.r11.s64 + -1776;
	// blr 
	return;
loc_8B0D7E84:
	// cmplwi cr6,r11,2406
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 2406, ctx.xer);
	// blt cr6,0x8b0d7fe8
	if (ctx.cr6.lt) goto loc_8B0D7FE8;
	// cmplwi cr6,r11,2416
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 2416, ctx.xer);
	// bge cr6,0x8b0d7e9c
	if (!ctx.cr6.lt) goto loc_8B0D7E9C;
	// addi r3,r11,-2406
	ctx.r3.s64 = ctx.r11.s64 + -2406;
	// blr 
	return;
loc_8B0D7E9C:
	// cmplwi cr6,r11,2534
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 2534, ctx.xer);
	// blt cr6,0x8b0d7fe8
	if (ctx.cr6.lt) goto loc_8B0D7FE8;
	// cmplwi cr6,r11,2544
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 2544, ctx.xer);
	// bge cr6,0x8b0d7eb4
	if (!ctx.cr6.lt) goto loc_8B0D7EB4;
	// addi r3,r11,-2534
	ctx.r3.s64 = ctx.r11.s64 + -2534;
	// blr 
	return;
loc_8B0D7EB4:
	// cmplwi cr6,r11,2662
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 2662, ctx.xer);
	// blt cr6,0x8b0d7fe8
	if (ctx.cr6.lt) goto loc_8B0D7FE8;
	// cmplwi cr6,r11,2672
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 2672, ctx.xer);
	// bge cr6,0x8b0d7ecc
	if (!ctx.cr6.lt) goto loc_8B0D7ECC;
	// addi r3,r11,-2662
	ctx.r3.s64 = ctx.r11.s64 + -2662;
	// blr 
	return;
loc_8B0D7ECC:
	// cmplwi cr6,r11,2790
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 2790, ctx.xer);
	// blt cr6,0x8b0d7fe8
	if (ctx.cr6.lt) goto loc_8B0D7FE8;
	// cmplwi cr6,r11,2800
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 2800, ctx.xer);
	// bge cr6,0x8b0d7ee4
	if (!ctx.cr6.lt) goto loc_8B0D7EE4;
	// addi r3,r11,-2790
	ctx.r3.s64 = ctx.r11.s64 + -2790;
	// blr 
	return;
loc_8B0D7EE4:
	// cmplwi cr6,r11,2918
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 2918, ctx.xer);
	// blt cr6,0x8b0d7fe8
	if (ctx.cr6.lt) goto loc_8B0D7FE8;
	// cmplwi cr6,r11,2928
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 2928, ctx.xer);
	// bge cr6,0x8b0d7efc
	if (!ctx.cr6.lt) goto loc_8B0D7EFC;
	// addi r3,r11,-2918
	ctx.r3.s64 = ctx.r11.s64 + -2918;
	// blr 
	return;
loc_8B0D7EFC:
	// cmplwi cr6,r11,3174
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 3174, ctx.xer);
	// blt cr6,0x8b0d7fe8
	if (ctx.cr6.lt) goto loc_8B0D7FE8;
	// cmplwi cr6,r11,3184
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 3184, ctx.xer);
	// bge cr6,0x8b0d7f14
	if (!ctx.cr6.lt) goto loc_8B0D7F14;
	// addi r3,r11,-3174
	ctx.r3.s64 = ctx.r11.s64 + -3174;
	// blr 
	return;
loc_8B0D7F14:
	// cmplwi cr6,r11,3302
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 3302, ctx.xer);
	// blt cr6,0x8b0d7fe8
	if (ctx.cr6.lt) goto loc_8B0D7FE8;
	// cmplwi cr6,r11,3312
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 3312, ctx.xer);
	// bge cr6,0x8b0d7f2c
	if (!ctx.cr6.lt) goto loc_8B0D7F2C;
	// addi r3,r11,-3302
	ctx.r3.s64 = ctx.r11.s64 + -3302;
	// blr 
	return;
loc_8B0D7F2C:
	// cmplwi cr6,r11,3430
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 3430, ctx.xer);
	// blt cr6,0x8b0d7fe8
	if (ctx.cr6.lt) goto loc_8B0D7FE8;
	// cmplwi cr6,r11,3440
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 3440, ctx.xer);
	// bge cr6,0x8b0d7f44
	if (!ctx.cr6.lt) goto loc_8B0D7F44;
	// addi r3,r11,-3430
	ctx.r3.s64 = ctx.r11.s64 + -3430;
	// blr 
	return;
loc_8B0D7F44:
	// cmplwi cr6,r11,3664
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 3664, ctx.xer);
	// blt cr6,0x8b0d7fe8
	if (ctx.cr6.lt) goto loc_8B0D7FE8;
	// cmplwi cr6,r11,3674
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 3674, ctx.xer);
	// bge cr6,0x8b0d7f5c
	if (!ctx.cr6.lt) goto loc_8B0D7F5C;
	// addi r3,r11,-3664
	ctx.r3.s64 = ctx.r11.s64 + -3664;
	// blr 
	return;
loc_8B0D7F5C:
	// cmplwi cr6,r11,3792
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 3792, ctx.xer);
	// blt cr6,0x8b0d7fe8
	if (ctx.cr6.lt) goto loc_8B0D7FE8;
	// cmplwi cr6,r11,3802
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 3802, ctx.xer);
	// bge cr6,0x8b0d7f74
	if (!ctx.cr6.lt) goto loc_8B0D7F74;
	// addi r3,r11,-3792
	ctx.r3.s64 = ctx.r11.s64 + -3792;
	// blr 
	return;
loc_8B0D7F74:
	// cmplwi cr6,r11,3872
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 3872, ctx.xer);
	// blt cr6,0x8b0d7fe8
	if (ctx.cr6.lt) goto loc_8B0D7FE8;
	// cmplwi cr6,r11,3882
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 3882, ctx.xer);
	// bge cr6,0x8b0d7f8c
	if (!ctx.cr6.lt) goto loc_8B0D7F8C;
	// addi r3,r11,-3872
	ctx.r3.s64 = ctx.r11.s64 + -3872;
	// blr 
	return;
loc_8B0D7F8C:
	// cmplwi cr6,r11,4160
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 4160, ctx.xer);
	// blt cr6,0x8b0d7fe8
	if (ctx.cr6.lt) goto loc_8B0D7FE8;
	// cmplwi cr6,r11,4170
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 4170, ctx.xer);
	// bge cr6,0x8b0d7fa4
	if (!ctx.cr6.lt) goto loc_8B0D7FA4;
	// addi r3,r11,-4160
	ctx.r3.s64 = ctx.r11.s64 + -4160;
	// blr 
	return;
loc_8B0D7FA4:
	// cmplwi cr6,r11,6112
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 6112, ctx.xer);
	// blt cr6,0x8b0d7fe8
	if (ctx.cr6.lt) goto loc_8B0D7FE8;
	// cmplwi cr6,r11,6122
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 6122, ctx.xer);
	// bge cr6,0x8b0d7fbc
	if (!ctx.cr6.lt) goto loc_8B0D7FBC;
	// addi r3,r11,-6112
	ctx.r3.s64 = ctx.r11.s64 + -6112;
	// blr 
	return;
loc_8B0D7FBC:
	// cmplwi cr6,r11,6160
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 6160, ctx.xer);
	// blt cr6,0x8b0d7fe8
	if (ctx.cr6.lt) goto loc_8B0D7FE8;
	// cmplwi cr6,r11,6170
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 6170, ctx.xer);
	// bge cr6,0x8b0d7fe8
	if (!ctx.cr6.lt) goto loc_8B0D7FE8;
	// addi r3,r11,-6160
	ctx.r3.s64 = ctx.r11.s64 + -6160;
	// blr 
	return;
loc_8B0D7FD4:
	// cmplwi cr6,r11,65306
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 65306, ctx.xer);
	// bge cr6,0x8b0d7fe8
	if (!ctx.cr6.lt) goto loc_8B0D7FE8;
	// addis r3,r11,-1
	ctx.r3.s64 = ctx.r11.s64 + -65536;
	// addi r3,r3,240
	ctx.r3.s64 = ctx.r3.s64 + 240;
	// blr 
	return;
loc_8B0D7FE8:
	// li r3,-1
	ctx.r3.s64 = -1;
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0D87B0) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9b0
	ctx.lr = 0x8B0D87B8;
	__savegprlr_26(ctx, base);
	// stwu r1,-144(r1)
	ea = -144 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// mr r31,r4
	ctx.r31.u64 = ctx.r4.u64;
	// li r28,0
	ctx.r28.s64 = 0;
	// mr r26,r3
	ctx.r26.u64 = ctx.r3.u64;
	// mr r30,r5
	ctx.r30.u64 = ctx.r5.u64;
	// mr r4,r6
	ctx.r4.u64 = ctx.r6.u64;
	// mr r29,r7
	ctx.r29.u64 = ctx.r7.u64;
	// cmplwi cr6,r31,0
	ctx.cr6.compare<uint32_t>(ctx.r31.u32, 0, ctx.xer);
	// mr r27,r28
	ctx.r27.u64 = ctx.r28.u64;
	// beq cr6,0x8b0d884c
	if (ctx.cr6.eq) goto loc_8B0D884C;
	// cmplwi cr6,r5,0
	ctx.cr6.compare<uint32_t>(ctx.r5.u32, 0, ctx.xer);
	// beq cr6,0x8b0d8854
	if (ctx.cr6.eq) goto loc_8B0D8854;
loc_8B0D87E8:
	// cmplwi cr6,r31,0
	ctx.cr6.compare<uint32_t>(ctx.r31.u32, 0, ctx.xer);
	// beq cr6,0x8b0d87f4
	if (ctx.cr6.eq) goto loc_8B0D87F4;
	// stb r28,0(r31)
	REX_STORE_U8(ctx.r31.u32 + 0, ctx.r28.u8);
loc_8B0D87F4:
	// cmplwi cr6,r26,0
	ctx.cr6.compare<uint32_t>(ctx.r26.u32, 0, ctx.xer);
	// beq cr6,0x8b0d8800
	if (ctx.cr6.eq) goto loc_8B0D8800;
	// stw r28,0(r26)
	REX_STORE_U32(ctx.r26.u32 + 0, ctx.r28.u32);
loc_8B0D8800:
	// cmplw cr6,r29,r30
	ctx.cr6.compare<uint32_t>(ctx.r29.u32, ctx.r30.u32, ctx.xer);
	// mr r5,r30
	ctx.r5.u64 = ctx.r30.u64;
	// bgt cr6,0x8b0d8810
	if (ctx.cr6.gt) goto loc_8B0D8810;
	// mr r5,r29
	ctx.r5.u64 = ctx.r29.u64;
loc_8B0D8810:
	// lis r11,32767
	ctx.r11.s64 = 2147418112;
	// ori r11,r11,65535
	ctx.r11.u64 = ctx.r11.u64 | 65535;
	// cmplw cr6,r5,r11
	ctx.cr6.compare<uint32_t>(ctx.r5.u32, ctx.r11.u32, ctx.xer);
	// bgt cr6,0x8b0d8854
	if (ctx.cr6.gt) goto loc_8B0D8854;
	// mr r6,r8
	ctx.r6.u64 = ctx.r8.u64;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0d84f0
	ctx.lr = 0x8B0D882C;
	sub_8B0D84F0(ctx, base);
	// cmpwi cr6,r3,-1
	ctx.cr6.compare<int32_t>(ctx.r3.s32, -1, ctx.xer);
	// bne cr6,0x8b0d8880
	if (!ctx.cr6.eq) goto loc_8B0D8880;
	// cmplwi cr6,r31,0
	ctx.cr6.compare<uint32_t>(ctx.r31.u32, 0, ctx.xer);
	// beq cr6,0x8b0d8840
	if (ctx.cr6.eq) goto loc_8B0D8840;
	// stb r28,0(r31)
	REX_STORE_U8(ctx.r31.u32 + 0, ctx.r28.u8);
loc_8B0D8840:
	// bl 0x8b0d0288
	ctx.lr = 0x8B0D8844;
	sub_8B0D0288(ctx, base);
	// lwz r3,0(r3)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// b 0x8b0d88f4
	goto loc_8B0D88F4;
loc_8B0D884C:
	// cmplwi cr6,r30,0
	ctx.cr6.compare<uint32_t>(ctx.r30.u32, 0, ctx.xer);
	// beq cr6,0x8b0d87e8
	if (ctx.cr6.eq) goto loc_8B0D87E8;
loc_8B0D8854:
	// bl 0x8b0d0288
	ctx.lr = 0x8B0D8858;
	sub_8B0D0288(ctx, base);
	// li r11,22
	ctx.r11.s64 = 22;
	// li r7,0
	ctx.r7.s64 = 0;
	// stw r11,0(r3)
	REX_STORE_U32(ctx.r3.u32 + 0, ctx.r11.u32);
	// li r6,0
	ctx.r6.s64 = 0;
	// li r5,0
	ctx.r5.s64 = 0;
	// li r4,0
	ctx.r4.s64 = 0;
	// li r3,0
	ctx.r3.s64 = 0;
	// bl 0x8b0d0148
	ctx.lr = 0x8B0D8878;
	sub_8B0D0148(ctx, base);
	// li r3,22
	ctx.r3.s64 = 22;
	// b 0x8b0d88f4
	goto loc_8B0D88F4;
loc_8B0D8880:
	// addi r11,r3,1
	ctx.r11.s64 = ctx.r3.s64 + 1;
	// cmplwi cr6,r31,0
	ctx.cr6.compare<uint32_t>(ctx.r31.u32, 0, ctx.xer);
	// beq cr6,0x8b0d88e4
	if (ctx.cr6.eq) goto loc_8B0D88E4;
	// cmplw cr6,r11,r30
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, ctx.r30.u32, ctx.xer);
	// ble cr6,0x8b0d88dc
	if (!ctx.cr6.gt) goto loc_8B0D88DC;
	// cmpwi cr6,r29,-1
	ctx.cr6.compare<int32_t>(ctx.r29.s32, -1, ctx.xer);
	// beq cr6,0x8b0d88d4
	if (ctx.cr6.eq) goto loc_8B0D88D4;
	// cmplw cr6,r30,r11
	ctx.cr6.compare<uint32_t>(ctx.r30.u32, ctx.r11.u32, ctx.xer);
	// stb r28,0(r31)
	REX_STORE_U8(ctx.r31.u32 + 0, ctx.r28.u8);
	// bgt cr6,0x8b0d88d4
	if (ctx.cr6.gt) goto loc_8B0D88D4;
	// bl 0x8b0d0288
	ctx.lr = 0x8B0D88AC;
	sub_8B0D0288(ctx, base);
	// li r11,34
	ctx.r11.s64 = 34;
	// li r7,0
	ctx.r7.s64 = 0;
	// stw r11,0(r3)
	REX_STORE_U32(ctx.r3.u32 + 0, ctx.r11.u32);
	// li r6,0
	ctx.r6.s64 = 0;
	// li r5,0
	ctx.r5.s64 = 0;
	// li r4,0
	ctx.r4.s64 = 0;
	// li r3,0
	ctx.r3.s64 = 0;
	// bl 0x8b0d0148
	ctx.lr = 0x8B0D88CC;
	sub_8B0D0148(ctx, base);
	// li r3,34
	ctx.r3.s64 = 34;
	// b 0x8b0d88f4
	goto loc_8B0D88F4;
loc_8B0D88D4:
	// mr r11,r30
	ctx.r11.u64 = ctx.r30.u64;
	// li r27,80
	ctx.r27.s64 = 80;
loc_8B0D88DC:
	// add r10,r11,r31
	ctx.r10.u64 = ctx.r11.u64 + ctx.r31.u64;
	// stb r28,-1(r10)
	REX_STORE_U8(ctx.r10.u32 + -1, ctx.r28.u8);
loc_8B0D88E4:
	// cmplwi cr6,r26,0
	ctx.cr6.compare<uint32_t>(ctx.r26.u32, 0, ctx.xer);
	// beq cr6,0x8b0d88f0
	if (ctx.cr6.eq) goto loc_8B0D88F0;
	// stw r11,0(r26)
	REX_STORE_U32(ctx.r26.u32 + 0, ctx.r11.u32);
loc_8B0D88F0:
	// mr r3,r27
	ctx.r3.u64 = ctx.r27.u64;
loc_8B0D88F4:
	// addi r1,r1,144
	ctx.r1.s64 = ctx.r1.s64 + 144;
	// b 0x8b0cba00
	__restgprlr_26(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0D9020) {
	REX_FUNC_PROLOGUE();
	PPCRegister temp{};
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb994
	ctx.lr = 0x8B0D9028;
	__savegprlr_19(ctx, base);
	// lhz r9,0(r3)
	ctx.r9.u64 = REX_LOAD_U16(ctx.r3.u32 + 0);
	// lis r10,-29938
	ctx.r10.s64 = -1962016768;
	// lhz r8,10(r3)
	ctx.r8.u64 = REX_LOAD_U16(ctx.r3.u32 + 10);
	// li r23,0
	ctx.r23.s64 = 0;
	// clrlwi r11,r9,17
	ctx.r11.u64 = ctx.r9.u32 & 0x7FFF;
	// lwz r7,2(r3)
	ctx.r7.u64 = REX_LOAD_U32(ctx.r3.u32 + 2);
	// lwz r6,6(r3)
	ctx.r6.u64 = REX_LOAD_U32(ctx.r3.u32 + 6);
	// addi r20,r10,14616
	ctx.r20.s64 = ctx.r10.s64 + 14616;
	// addi r30,r11,-16383
	ctx.r30.s64 = ctx.r11.s64 + -16383;
	// rotlwi r11,r8,16
	ctx.r11.u64 = __builtin_rotateleft32(ctx.r8.u32, 16);
	// rlwinm r19,r9,0,0,16
	ctx.r19.u64 = __builtin_rotateleft64(ctx.r9.u32 | (ctx.r9.u64 << 32), 0) & 0xFFFF8000;
	// stw r7,-152(r1)
	REX_STORE_U32(ctx.r1.u32 + -152, ctx.r7.u32);
	// cmpwi cr6,r30,-16383
	ctx.cr6.compare<int32_t>(ctx.r30.s32, -16383, ctx.xer);
	// lwz r21,12(r20)
	ctx.r21.u64 = REX_LOAD_U32(ctx.r20.u32 + 12);
	// addi r10,r1,-152
	ctx.r10.s64 = ctx.r1.s64 + -152;
	// stw r6,-148(r1)
	REX_STORE_U32(ctx.r1.u32 + -148, ctx.r6.u32);
	// mr r5,r23
	ctx.r5.u64 = ctx.r23.u64;
	// stw r11,-144(r1)
	REX_STORE_U32(ctx.r1.u32 + -144, ctx.r11.u32);
	// bne cr6,0x8b0d90b0
	if (!ctx.cr6.eq) goto loc_8B0D90B0;
	// mr r11,r23
	ctx.r11.u64 = ctx.r23.u64;
loc_8B0D9078:
	// lwz r9,0(r10)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r10.u32 + 0);
	// cmplwi cr6,r9,0
	ctx.cr6.compare<uint32_t>(ctx.r9.u32, 0, ctx.xer);
	// bne cr6,0x8b0d9098
	if (!ctx.cr6.eq) goto loc_8B0D9098;
	// addi r11,r11,1
	ctx.r11.s64 = ctx.r11.s64 + 1;
	// addi r10,r10,4
	ctx.r10.s64 = ctx.r10.s64 + 4;
	// cmpwi cr6,r11,3
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 3, ctx.xer);
	// blt cr6,0x8b0d9078
	if (ctx.cr6.lt) goto loc_8B0D9078;
	// b 0x8b0d96e4
	goto loc_8B0D96E4;
loc_8B0D9098:
	// addi r11,r1,-152
	ctx.r11.s64 = ctx.r1.s64 + -152;
	// li r3,2
	ctx.r3.s64 = 2;
	// stw r23,0(r11)
	REX_STORE_U32(ctx.r11.u32 + 0, ctx.r23.u32);
	// stw r23,4(r11)
	REX_STORE_U32(ctx.r11.u32 + 4, ctx.r23.u32);
	// stw r23,8(r11)
	REX_STORE_U32(ctx.r11.u32 + 8, ctx.r23.u32);
	// b 0x8b0d96e8
	goto loc_8B0D96E8;
loc_8B0D90B0:
	// lwz r25,8(r20)
	ctx.r25.u64 = REX_LOAD_U32(ctx.r20.u32 + 8);
	// addi r8,r1,-136
	ctx.r8.s64 = ctx.r1.s64 + -136;
	// lwz r9,0(r10)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r10.u32 + 0);
	// addi r28,r1,-152
	ctx.r28.s64 = ctx.r1.s64 + -152;
	// addi r26,r25,-1
	ctx.r26.s64 = ctx.r25.s64 + -1;
	// lwz r6,4(r10)
	ctx.r6.u64 = REX_LOAD_U32(ctx.r10.u32 + 4);
	// lwz r10,8(r10)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r10.u32 + 8);
	// li r3,1
	ctx.r3.s64 = 1;
	// addi r11,r26,1
	ctx.r11.s64 = ctx.r26.s64 + 1;
	// li r22,-1
	ctx.r22.s64 = -1;
	// srawi r7,r11,5
	ctx.xer.ca = (ctx.r11.s32 < 0) & ((ctx.r11.u32 & 0x1F) != 0);
	ctx.r7.s64 = ctx.r11.s32 >> 5;
	// stw r9,0(r8)
	REX_STORE_U32(ctx.r8.u32 + 0, ctx.r9.u32);
	// stw r6,4(r8)
	REX_STORE_U32(ctx.r8.u32 + 4, ctx.r6.u32);
	// mr r24,r30
	ctx.r24.u64 = ctx.r30.u64;
	// addze r31,r7
	temp.s64 = ctx.r7.s64 + ctx.xer.ca;
	ctx.xer.ca = temp.u32 < ctx.r7.u32;
	ctx.r31.s64 = temp.s64;
	// stw r10,8(r8)
	REX_STORE_U32(ctx.r8.u32 + 8, ctx.r10.u32);
	// srawi r7,r11,5
	ctx.xer.ca = (ctx.r11.s32 < 0) & ((ctx.r11.u32 & 0x1F) != 0);
	ctx.r7.s64 = ctx.r11.s32 >> 5;
	// rlwinm r27,r31,2,0,29
	ctx.r27.u64 = __builtin_rotateleft64(ctx.r31.u32 | (ctx.r31.u64 << 32), 2) & 0xFFFFFFFC;
	// addze r9,r7
	temp.s64 = ctx.r7.s64 + ctx.xer.ca;
	ctx.xer.ca = temp.u32 < ctx.r7.u32;
	ctx.r9.s64 = temp.s64;
	// rlwinm r10,r9,5,0,26
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r9.u32 | (ctx.r9.u64 << 32), 5) & 0xFFFFFFE0;
	// subf r11,r10,r11
	ctx.r11.u64 = ctx.r11.u64 - ctx.r10.u64;
	// lwzx r10,r27,r28
	ctx.r10.u64 = REX_LOAD_U32(ctx.r27.u32 + ctx.r28.u32);
	// subfic r29,r11,31
	ctx.xer.ca = ctx.r11.u32 <= 31;
	ctx.r29.u64 = static_cast<uint64_t>(31) - ctx.r11.u64;
	// slw r11,r3,r29
	ctx.r11.u64 = ctx.r29.u8 & 0x20 ? 0 : (ctx.r3.u32 << (ctx.r29.u8 & 0x3F));
	// and. r11,r11,r10
	ctx.r11.u64 = ctx.r11.u64 & ctx.r10.u64;
	ctx.cr0.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// beq 0x8b0d91fc
	if (ctx.cr0.eq) goto loc_8B0D91FC;
	// rlwinm r11,r31,2,0,29
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r31.u32 | (ctx.r31.u64 << 32), 2) & 0xFFFFFFFC;
	// addi r10,r1,-152
	ctx.r10.s64 = ctx.r1.s64 + -152;
	// slw r9,r22,r29
	ctx.r9.u64 = ctx.r29.u8 & 0x20 ? 0 : (ctx.r22.u32 << (ctx.r29.u8 & 0x3F));
	// lwzx r11,r11,r10
	ctx.r11.u64 = REX_LOAD_U32(ctx.r11.u32 + ctx.r10.u32);
	// andc. r11,r11,r9
	ctx.r11.u64 = ctx.r11.u64 & ~ctx.r9.u64;
	ctx.cr0.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// bne 0x8b0d9168
	if (!ctx.cr0.eq) goto loc_8B0D9168;
	// addi r11,r31,1
	ctx.r11.s64 = ctx.r31.s64 + 1;
	// cmpwi cr6,r11,3
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 3, ctx.xer);
	// bge cr6,0x8b0d91fc
	if (!ctx.cr6.lt) goto loc_8B0D91FC;
	// rlwinm r9,r11,2,0,29
	ctx.r9.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 2) & 0xFFFFFFFC;
	// addi r10,r1,-152
	ctx.r10.s64 = ctx.r1.s64 + -152;
	// add r10,r9,r10
	ctx.r10.u64 = ctx.r9.u64 + ctx.r10.u64;
loc_8B0D9148:
	// lwz r9,0(r10)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r10.u32 + 0);
	// cmplwi cr6,r9,0
	ctx.cr6.compare<uint32_t>(ctx.r9.u32, 0, ctx.xer);
	// bne cr6,0x8b0d9168
	if (!ctx.cr6.eq) goto loc_8B0D9168;
	// addi r11,r11,1
	ctx.r11.s64 = ctx.r11.s64 + 1;
	// addi r10,r10,4
	ctx.r10.s64 = ctx.r10.s64 + 4;
	// cmpwi cr6,r11,3
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 3, ctx.xer);
	// blt cr6,0x8b0d9148
	if (ctx.cr6.lt) goto loc_8B0D9148;
	// b 0x8b0d91fc
	goto loc_8B0D91FC;
loc_8B0D9168:
	// srawi r11,r26,5
	ctx.xer.ca = (ctx.r26.s32 < 0) & ((ctx.r26.u32 & 0x1F) != 0);
	ctx.r11.s64 = ctx.r26.s32 >> 5;
	// addi r8,r1,-152
	ctx.r8.s64 = ctx.r1.s64 + -152;
	// addze r9,r11
	temp.s64 = ctx.r11.s64 + ctx.xer.ca;
	ctx.xer.ca = temp.u32 < ctx.r11.u32;
	ctx.r9.s64 = temp.s64;
	// srawi r11,r26,5
	ctx.xer.ca = (ctx.r26.s32 < 0) & ((ctx.r26.u32 & 0x1F) != 0);
	ctx.r11.s64 = ctx.r26.s32 >> 5;
	// rlwinm r7,r9,2,0,29
	ctx.r7.u64 = __builtin_rotateleft64(ctx.r9.u32 | (ctx.r9.u64 << 32), 2) & 0xFFFFFFFC;
	// addze r11,r11
	temp.s64 = ctx.r11.s64 + ctx.xer.ca;
	ctx.xer.ca = temp.u32 < ctx.r11.u32;
	ctx.r11.s64 = temp.s64;
	// mr r5,r23
	ctx.r5.u64 = ctx.r23.u64;
	// rlwinm r11,r11,5,0,26
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 5) & 0xFFFFFFE0;
	// subf r10,r11,r26
	ctx.r10.u64 = ctx.r26.u64 - ctx.r11.u64;
	// lwzx r11,r7,r8
	ctx.r11.u64 = REX_LOAD_U32(ctx.r7.u32 + ctx.r8.u32);
	// subfic r10,r10,31
	ctx.xer.ca = ctx.r10.u32 <= 31;
	ctx.r10.u64 = static_cast<uint64_t>(31) - ctx.r10.u64;
	// slw r6,r3,r10
	ctx.r6.u64 = ctx.r10.u8 & 0x20 ? 0 : (ctx.r3.u32 << (ctx.r10.u8 & 0x3F));
	// add r10,r11,r6
	ctx.r10.u64 = ctx.r11.u64 + ctx.r6.u64;
	// cmplw cr6,r10,r11
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, ctx.r11.u32, ctx.xer);
	// blt cr6,0x8b0d91ac
	if (ctx.cr6.lt) goto loc_8B0D91AC;
	// cmplw cr6,r10,r6
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, ctx.r6.u32, ctx.xer);
	// bge cr6,0x8b0d91b0
	if (!ctx.cr6.lt) goto loc_8B0D91B0;
loc_8B0D91AC:
	// mr r5,r3
	ctx.r5.u64 = ctx.r3.u64;
loc_8B0D91B0:
	// addic. r11,r9,-1
	ctx.xer.ca = ctx.r9.u32 > 0;
	ctx.r11.s64 = ctx.r9.s64 + -1;
	ctx.cr0.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// stwx r10,r7,r8
	REX_STORE_U32(ctx.r7.u32 + ctx.r8.u32, ctx.r10.u32);
	// blt 0x8b0d91fc
	if (ctx.cr0.lt) goto loc_8B0D91FC;
	// rlwinm r9,r11,2,0,29
	ctx.r9.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 2) & 0xFFFFFFFC;
	// addi r10,r1,-148
	ctx.r10.s64 = ctx.r1.s64 + -148;
	// add r10,r9,r10
	ctx.r10.u64 = ctx.r9.u64 + ctx.r10.u64;
loc_8B0D91C8:
	// cmpwi cr6,r5,0
	ctx.cr6.compare<int32_t>(ctx.r5.s32, 0, ctx.xer);
	// beq cr6,0x8b0d91fc
	if (ctx.cr6.eq) goto loc_8B0D91FC;
	// lwz r9,-4(r10)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r10.u32 + -4);
	// mr r5,r23
	ctx.r5.u64 = ctx.r23.u64;
	// addi r8,r9,1
	ctx.r8.s64 = ctx.r9.s64 + 1;
	// cmplw cr6,r8,r9
	ctx.cr6.compare<uint32_t>(ctx.r8.u32, ctx.r9.u32, ctx.xer);
	// blt cr6,0x8b0d91ec
	if (ctx.cr6.lt) goto loc_8B0D91EC;
	// cmplwi cr6,r8,1
	ctx.cr6.compare<uint32_t>(ctx.r8.u32, 1, ctx.xer);
	// bge cr6,0x8b0d91f0
	if (!ctx.cr6.lt) goto loc_8B0D91F0;
loc_8B0D91EC:
	// mr r5,r3
	ctx.r5.u64 = ctx.r3.u64;
loc_8B0D91F0:
	// addic. r11,r11,-1
	ctx.xer.ca = ctx.r11.u32 > 0;
	ctx.r11.s64 = ctx.r11.s64 + -1;
	ctx.cr0.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// stwu r8,-4(r10)
	ea = -4 + ctx.r10.u32;
	REX_STORE_U32(ea, ctx.r8.u32);
	ctx.r10.u32 = ea;
	// bge 0x8b0d91c8
	if (!ctx.cr0.lt) goto loc_8B0D91C8;
loc_8B0D91FC:
	// lwzx r10,r27,r28
	ctx.r10.u64 = REX_LOAD_U32(ctx.r27.u32 + ctx.r28.u32);
	// slw r9,r22,r29
	ctx.r9.u64 = ctx.r29.u8 & 0x20 ? 0 : (ctx.r22.u32 << (ctx.r29.u8 & 0x3F));
	// addi r11,r31,1
	ctx.r11.s64 = ctx.r31.s64 + 1;
	// and r10,r9,r10
	ctx.r10.u64 = ctx.r9.u64 & ctx.r10.u64;
	// cmpwi cr6,r11,3
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 3, ctx.xer);
	// stwx r10,r27,r28
	REX_STORE_U32(ctx.r27.u32 + ctx.r28.u32, ctx.r10.u32);
	// bge cr6,0x8b0d9244
	if (!ctx.cr6.lt) goto loc_8B0D9244;
	// rlwinm r9,r11,2,0,29
	ctx.r9.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 2) & 0xFFFFFFFC;
	// addi r10,r1,-152
	ctx.r10.s64 = ctx.r1.s64 + -152;
	// subfic r11,r11,3
	ctx.xer.ca = ctx.r11.u32 <= 3;
	ctx.r11.u64 = static_cast<uint64_t>(3) - ctx.r11.u64;
	// add r10,r9,r10
	ctx.r10.u64 = ctx.r9.u64 + ctx.r10.u64;
	// mr r9,r23
	ctx.r9.u64 = ctx.r23.u64;
	// addi r10,r10,-4
	ctx.r10.s64 = ctx.r10.s64 + -4;
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// beq cr6,0x8b0d9244
	if (ctx.cr6.eq) goto loc_8B0D9244;
	// mtctr r11
	ctx.ctr.u64 = ctx.r11.u64;
loc_8B0D923C:
	// stwu r9,4(r10)
	ea = 4 + ctx.r10.u32;
	REX_STORE_U32(ea, ctx.r9.u32);
	ctx.r10.u32 = ea;
	// bdnz 0x8b0d923c
	--ctx.ctr.u64;
	if (ctx.ctr.u32 != 0) goto loc_8B0D923C;
loc_8B0D9244:
	// cmpwi cr6,r5,0
	ctx.cr6.compare<int32_t>(ctx.r5.s32, 0, ctx.xer);
	// beq cr6,0x8b0d9250
	if (ctx.cr6.eq) goto loc_8B0D9250;
	// addi r30,r30,1
	ctx.r30.s64 = ctx.r30.s64 + 1;
loc_8B0D9250:
	// lwz r11,4(r20)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r20.u32 + 4);
	// subf r10,r25,r11
	ctx.r10.u64 = ctx.r11.u64 - ctx.r25.u64;
	// cmpw cr6,r30,r10
	ctx.cr6.compare<int32_t>(ctx.r30.s32, ctx.r10.s32, ctx.xer);
	// bge cr6,0x8b0d927c
	if (!ctx.cr6.lt) goto loc_8B0D927C;
	// addi r11,r1,-152
	ctx.r11.s64 = ctx.r1.s64 + -152;
	// mr r5,r23
	ctx.r5.u64 = ctx.r23.u64;
	// li r3,2
	ctx.r3.s64 = 2;
	// stw r23,0(r11)
	REX_STORE_U32(ctx.r11.u32 + 0, ctx.r23.u32);
	// stw r23,4(r11)
	REX_STORE_U32(ctx.r11.u32 + 4, ctx.r23.u32);
	// stw r23,8(r11)
	REX_STORE_U32(ctx.r11.u32 + 8, ctx.r23.u32);
	// b 0x8b0d96e8
	goto loc_8B0D96E8;
loc_8B0D927C:
	// li r10,3
	ctx.r10.s64 = 3;
	// cmpw cr6,r30,r11
	ctx.cr6.compare<int32_t>(ctx.r30.s32, ctx.r11.s32, ctx.xer);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bgt cr6,0x8b0d9564
	if (ctx.cr6.gt) goto loc_8B0D9564;
	// subf r11,r24,r11
	ctx.r11.u64 = ctx.r11.u64 - ctx.r24.u64;
	// addi r9,r1,-136
	ctx.r9.s64 = ctx.r1.s64 + -136;
	// srawi r8,r11,5
	ctx.xer.ca = (ctx.r11.s32 < 0) & ((ctx.r11.u32 & 0x1F) != 0);
	ctx.r8.s64 = ctx.r11.s32 >> 5;
	// addi r6,r1,-152
	ctx.r6.s64 = ctx.r1.s64 + -152;
	// addze r5,r8
	temp.s64 = ctx.r8.s64 + ctx.xer.ca;
	ctx.xer.ca = temp.u32 < ctx.r8.u32;
	ctx.r5.s64 = temp.s64;
	// srawi r8,r11,5
	ctx.xer.ca = (ctx.r11.s32 < 0) & ((ctx.r11.u32 & 0x1F) != 0);
	ctx.r8.s64 = ctx.r11.s32 >> 5;
	// lwz r7,0(r9)
	ctx.r7.u64 = REX_LOAD_U32(ctx.r9.u32 + 0);
	// li r27,-1
	ctx.r27.s64 = -1;
	// addze r8,r8
	temp.s64 = ctx.r8.s64 + ctx.xer.ca;
	ctx.xer.ca = temp.u32 < ctx.r8.u32;
	ctx.r8.s64 = temp.s64;
	// lwz r31,4(r9)
	ctx.r31.u64 = REX_LOAD_U32(ctx.r9.u32 + 4);
	// lwz r30,8(r9)
	ctx.r30.u64 = REX_LOAD_U32(ctx.r9.u32 + 8);
	// addi r9,r1,-152
	ctx.r9.s64 = ctx.r1.s64 + -152;
	// rlwinm r8,r8,5,0,26
	ctx.r8.u64 = __builtin_rotateleft64(ctx.r8.u32 | (ctx.r8.u64 << 32), 5) & 0xFFFFFFE0;
	// subf r11,r8,r11
	ctx.r11.u64 = ctx.r11.u64 - ctx.r8.u64;
	// stw r7,0(r6)
	REX_STORE_U32(ctx.r6.u32 + 0, ctx.r7.u32);
	// stw r31,4(r6)
	REX_STORE_U32(ctx.r6.u32 + 4, ctx.r31.u32);
	// mr r8,r23
	ctx.r8.u64 = ctx.r23.u64;
	// slw r10,r27,r11
	ctx.r10.u64 = ctx.r11.u8 & 0x20 ? 0 : (ctx.r27.u32 << (ctx.r11.u8 & 0x3F));
	// stw r30,8(r6)
	REX_STORE_U32(ctx.r6.u32 + 8, ctx.r30.u32);
	// not r7,r10
	ctx.r7.u64 = ~ctx.r10.u64;
	// subfic r6,r11,32
	ctx.xer.ca = ctx.r11.u32 <= 32;
	ctx.r6.u64 = static_cast<uint64_t>(32) - ctx.r11.u64;
	// addi r10,r9,-4
	ctx.r10.s64 = ctx.r9.s64 + -4;
loc_8B0D92E4:
	// lwz r9,4(r10)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r10.u32 + 4);
	// and r31,r9,r7
	ctx.r31.u64 = ctx.r9.u64 & ctx.r7.u64;
	// stw r31,-160(r1)
	REX_STORE_U32(ctx.r1.u32 + -160, ctx.r31.u32);
	// srw r9,r9,r11
	ctx.r9.u64 = ctx.r11.u8 & 0x20 ? 0 : (ctx.r9.u32 >> (ctx.r11.u8 & 0x3F));
	// or r9,r9,r8
	ctx.r9.u64 = ctx.r9.u64 | ctx.r8.u64;
	// stwu r9,4(r10)
	ea = 4 + ctx.r10.u32;
	REX_STORE_U32(ea, ctx.r9.u32);
	ctx.r10.u32 = ea;
	// lwz r9,-160(r1)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r1.u32 + -160);
	// slw r8,r9,r6
	ctx.r8.u64 = ctx.r6.u8 & 0x20 ? 0 : (ctx.r9.u32 << (ctx.r6.u8 & 0x3F));
	// bdnz 0x8b0d92e4
	--ctx.ctr.u64;
	if (ctx.ctr.u32 != 0) goto loc_8B0D92E4;
	// li r10,3
	ctx.r10.s64 = 3;
	// rlwinm r8,r5,2,0,29
	ctx.r8.u64 = __builtin_rotateleft64(ctx.r5.u32 | (ctx.r5.u64 << 32), 2) & 0xFFFFFFFC;
	// addi r7,r1,-144
	ctx.r7.s64 = ctx.r1.s64 + -144;
	// li r9,2
	ctx.r9.s64 = 2;
	// addi r11,r1,-144
	ctx.r11.s64 = ctx.r1.s64 + -144;
	// subf r8,r8,r7
	ctx.r8.u64 = ctx.r7.u64 - ctx.r8.u64;
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
loc_8B0D9324:
	// cmpw cr6,r9,r5
	ctx.cr6.compare<int32_t>(ctx.r9.s32, ctx.r5.s32, ctx.xer);
	// blt cr6,0x8b0d9338
	if (ctx.cr6.lt) goto loc_8B0D9338;
	// lwz r10,0(r8)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r8.u32 + 0);
	// stw r10,0(r11)
	REX_STORE_U32(ctx.r11.u32 + 0, ctx.r10.u32);
	// b 0x8b0d933c
	goto loc_8B0D933C;
loc_8B0D9338:
	// stw r23,0(r11)
	REX_STORE_U32(ctx.r11.u32 + 0, ctx.r23.u32);
loc_8B0D933C:
	// addi r9,r9,-1
	ctx.r9.s64 = ctx.r9.s64 + -1;
	// addi r8,r8,-4
	ctx.r8.s64 = ctx.r8.s64 + -4;
	// addi r11,r11,-4
	ctx.r11.s64 = ctx.r11.s64 + -4;
	// bdnz 0x8b0d9324
	--ctx.ctr.u64;
	if (ctx.ctr.u32 != 0) goto loc_8B0D9324;
	// addi r11,r26,1
	ctx.r11.s64 = ctx.r26.s64 + 1;
	// addi r29,r1,-152
	ctx.r29.s64 = ctx.r1.s64 + -152;
	// srawi r10,r11,5
	ctx.xer.ca = (ctx.r11.s32 < 0) & ((ctx.r11.u32 & 0x1F) != 0);
	ctx.r10.s64 = ctx.r11.s32 >> 5;
	// addze r31,r10
	temp.s64 = ctx.r10.s64 + ctx.xer.ca;
	ctx.xer.ca = temp.u32 < ctx.r10.u32;
	ctx.r31.s64 = temp.s64;
	// srawi r10,r11,5
	ctx.xer.ca = (ctx.r11.s32 < 0) & ((ctx.r11.u32 & 0x1F) != 0);
	ctx.r10.s64 = ctx.r11.s32 >> 5;
	// rlwinm r28,r31,2,0,29
	ctx.r28.u64 = __builtin_rotateleft64(ctx.r31.u32 | (ctx.r31.u64 << 32), 2) & 0xFFFFFFFC;
	// addze r10,r10
	temp.s64 = ctx.r10.s64 + ctx.xer.ca;
	ctx.xer.ca = temp.u32 < ctx.r10.u32;
	ctx.r10.s64 = temp.s64;
	// rlwinm r10,r10,5,0,26
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r10.u32 | (ctx.r10.u64 << 32), 5) & 0xFFFFFFE0;
	// subf r11,r10,r11
	ctx.r11.u64 = ctx.r11.u64 - ctx.r10.u64;
	// lwzx r10,r28,r29
	ctx.r10.u64 = REX_LOAD_U32(ctx.r28.u32 + ctx.r29.u32);
	// subfic r30,r11,31
	ctx.xer.ca = ctx.r11.u32 <= 31;
	ctx.r30.u64 = static_cast<uint64_t>(31) - ctx.r11.u64;
	// slw r11,r3,r30
	ctx.r11.u64 = ctx.r30.u8 & 0x20 ? 0 : (ctx.r3.u32 << (ctx.r30.u8 & 0x3F));
	// and. r11,r11,r10
	ctx.r11.u64 = ctx.r11.u64 & ctx.r10.u64;
	ctx.cr0.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// beq 0x8b0d946c
	if (ctx.cr0.eq) goto loc_8B0D946C;
	// rlwinm r11,r31,2,0,29
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r31.u32 | (ctx.r31.u64 << 32), 2) & 0xFFFFFFFC;
	// addi r10,r1,-152
	ctx.r10.s64 = ctx.r1.s64 + -152;
	// slw r9,r22,r30
	ctx.r9.u64 = ctx.r30.u8 & 0x20 ? 0 : (ctx.r22.u32 << (ctx.r30.u8 & 0x3F));
	// lwzx r11,r11,r10
	ctx.r11.u64 = REX_LOAD_U32(ctx.r11.u32 + ctx.r10.u32);
	// andc. r11,r11,r9
	ctx.r11.u64 = ctx.r11.u64 & ~ctx.r9.u64;
	ctx.cr0.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// bne 0x8b0d93d4
	if (!ctx.cr0.eq) goto loc_8B0D93D4;
	// addi r11,r31,1
	ctx.r11.s64 = ctx.r31.s64 + 1;
	// cmpwi cr6,r11,3
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 3, ctx.xer);
	// bge cr6,0x8b0d946c
	if (!ctx.cr6.lt) goto loc_8B0D946C;
	// rlwinm r9,r11,2,0,29
	ctx.r9.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 2) & 0xFFFFFFFC;
	// addi r10,r1,-152
	ctx.r10.s64 = ctx.r1.s64 + -152;
	// add r10,r9,r10
	ctx.r10.u64 = ctx.r9.u64 + ctx.r10.u64;
loc_8B0D93B4:
	// lwz r9,0(r10)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r10.u32 + 0);
	// cmplwi cr6,r9,0
	ctx.cr6.compare<uint32_t>(ctx.r9.u32, 0, ctx.xer);
	// bne cr6,0x8b0d93d4
	if (!ctx.cr6.eq) goto loc_8B0D93D4;
	// addi r11,r11,1
	ctx.r11.s64 = ctx.r11.s64 + 1;
	// addi r10,r10,4
	ctx.r10.s64 = ctx.r10.s64 + 4;
	// cmpwi cr6,r11,3
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 3, ctx.xer);
	// blt cr6,0x8b0d93b4
	if (ctx.cr6.lt) goto loc_8B0D93B4;
	// b 0x8b0d946c
	goto loc_8B0D946C;
loc_8B0D93D4:
	// srawi r11,r26,5
	ctx.xer.ca = (ctx.r26.s32 < 0) & ((ctx.r26.u32 & 0x1F) != 0);
	ctx.r11.s64 = ctx.r26.s32 >> 5;
	// addi r8,r1,-152
	ctx.r8.s64 = ctx.r1.s64 + -152;
	// addze r9,r11
	temp.s64 = ctx.r11.s64 + ctx.xer.ca;
	ctx.xer.ca = temp.u32 < ctx.r11.u32;
	ctx.r9.s64 = temp.s64;
	// srawi r11,r26,5
	ctx.xer.ca = (ctx.r26.s32 < 0) & ((ctx.r26.u32 & 0x1F) != 0);
	ctx.r11.s64 = ctx.r26.s32 >> 5;
	// rlwinm r7,r9,2,0,29
	ctx.r7.u64 = __builtin_rotateleft64(ctx.r9.u32 | (ctx.r9.u64 << 32), 2) & 0xFFFFFFFC;
	// addze r11,r11
	temp.s64 = ctx.r11.s64 + ctx.xer.ca;
	ctx.xer.ca = temp.u32 < ctx.r11.u32;
	ctx.r11.s64 = temp.s64;
	// mr r5,r23
	ctx.r5.u64 = ctx.r23.u64;
	// rlwinm r11,r11,5,0,26
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 5) & 0xFFFFFFE0;
	// subf r10,r11,r26
	ctx.r10.u64 = ctx.r26.u64 - ctx.r11.u64;
	// lwzx r11,r7,r8
	ctx.r11.u64 = REX_LOAD_U32(ctx.r7.u32 + ctx.r8.u32);
	// subfic r10,r10,31
	ctx.xer.ca = ctx.r10.u32 <= 31;
	ctx.r10.u64 = static_cast<uint64_t>(31) - ctx.r10.u64;
	// slw r6,r3,r10
	ctx.r6.u64 = ctx.r10.u8 & 0x20 ? 0 : (ctx.r3.u32 << (ctx.r10.u8 & 0x3F));
	// add r10,r11,r6
	ctx.r10.u64 = ctx.r11.u64 + ctx.r6.u64;
	// cmplw cr6,r10,r11
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, ctx.r11.u32, ctx.xer);
	// blt cr6,0x8b0d9418
	if (ctx.cr6.lt) goto loc_8B0D9418;
	// cmplw cr6,r10,r6
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, ctx.r6.u32, ctx.xer);
	// bge cr6,0x8b0d941c
	if (!ctx.cr6.lt) goto loc_8B0D941C;
loc_8B0D9418:
	// mr r5,r3
	ctx.r5.u64 = ctx.r3.u64;
loc_8B0D941C:
	// stwx r10,r7,r8
	REX_STORE_U32(ctx.r7.u32 + ctx.r8.u32, ctx.r10.u32);
	// addic. r11,r9,-1
	ctx.xer.ca = ctx.r9.u32 > 0;
	ctx.r11.s64 = ctx.r9.s64 + -1;
	ctx.cr0.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// mr r7,r5
	ctx.r7.u64 = ctx.r5.u64;
	// blt 0x8b0d946c
	if (ctx.cr0.lt) goto loc_8B0D946C;
	// rlwinm r9,r11,2,0,29
	ctx.r9.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 2) & 0xFFFFFFFC;
	// addi r10,r1,-148
	ctx.r10.s64 = ctx.r1.s64 + -148;
	// add r10,r9,r10
	ctx.r10.u64 = ctx.r9.u64 + ctx.r10.u64;
loc_8B0D9438:
	// cmpwi cr6,r7,0
	ctx.cr6.compare<int32_t>(ctx.r7.s32, 0, ctx.xer);
	// beq cr6,0x8b0d946c
	if (ctx.cr6.eq) goto loc_8B0D946C;
	// lwz r9,-4(r10)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r10.u32 + -4);
	// mr r7,r23
	ctx.r7.u64 = ctx.r23.u64;
	// addi r8,r9,1
	ctx.r8.s64 = ctx.r9.s64 + 1;
	// cmplw cr6,r8,r9
	ctx.cr6.compare<uint32_t>(ctx.r8.u32, ctx.r9.u32, ctx.xer);
	// blt cr6,0x8b0d945c
	if (ctx.cr6.lt) goto loc_8B0D945C;
	// cmplwi cr6,r8,1
	ctx.cr6.compare<uint32_t>(ctx.r8.u32, 1, ctx.xer);
	// bge cr6,0x8b0d9460
	if (!ctx.cr6.lt) goto loc_8B0D9460;
loc_8B0D945C:
	// mr r7,r3
	ctx.r7.u64 = ctx.r3.u64;
loc_8B0D9460:
	// addic. r11,r11,-1
	ctx.xer.ca = ctx.r11.u32 > 0;
	ctx.r11.s64 = ctx.r11.s64 + -1;
	ctx.cr0.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// stwu r8,-4(r10)
	ea = -4 + ctx.r10.u32;
	REX_STORE_U32(ea, ctx.r8.u32);
	ctx.r10.u32 = ea;
	// bge 0x8b0d9438
	if (!ctx.cr0.lt) goto loc_8B0D9438;
loc_8B0D946C:
	// lwzx r10,r28,r29
	ctx.r10.u64 = REX_LOAD_U32(ctx.r28.u32 + ctx.r29.u32);
	// slw r9,r22,r30
	ctx.r9.u64 = ctx.r30.u8 & 0x20 ? 0 : (ctx.r22.u32 << (ctx.r30.u8 & 0x3F));
	// addi r11,r31,1
	ctx.r11.s64 = ctx.r31.s64 + 1;
	// and r10,r9,r10
	ctx.r10.u64 = ctx.r9.u64 & ctx.r10.u64;
	// cmpwi cr6,r11,3
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 3, ctx.xer);
	// stwx r10,r28,r29
	REX_STORE_U32(ctx.r28.u32 + ctx.r29.u32, ctx.r10.u32);
	// bge cr6,0x8b0d94b4
	if (!ctx.cr6.lt) goto loc_8B0D94B4;
	// rlwinm r9,r11,2,0,29
	ctx.r9.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 2) & 0xFFFFFFFC;
	// addi r10,r1,-152
	ctx.r10.s64 = ctx.r1.s64 + -152;
	// subfic r11,r11,3
	ctx.xer.ca = ctx.r11.u32 <= 3;
	ctx.r11.u64 = static_cast<uint64_t>(3) - ctx.r11.u64;
	// add r10,r9,r10
	ctx.r10.u64 = ctx.r9.u64 + ctx.r10.u64;
	// mr r9,r23
	ctx.r9.u64 = ctx.r23.u64;
	// addi r10,r10,-4
	ctx.r10.s64 = ctx.r10.s64 + -4;
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// beq cr6,0x8b0d94b4
	if (ctx.cr6.eq) goto loc_8B0D94B4;
	// mtctr r11
	ctx.ctr.u64 = ctx.r11.u64;
loc_8B0D94AC:
	// stwu r9,4(r10)
	ea = 4 + ctx.r10.u32;
	REX_STORE_U32(ea, ctx.r9.u32);
	ctx.r10.u32 = ea;
	// bdnz 0x8b0d94ac
	--ctx.ctr.u64;
	if (ctx.ctr.u32 != 0) goto loc_8B0D94AC;
loc_8B0D94B4:
	// addi r11,r21,1
	ctx.r11.s64 = ctx.r21.s64 + 1;
	// li r10,3
	ctx.r10.s64 = 3;
	// srawi r8,r11,5
	ctx.xer.ca = (ctx.r11.s32 < 0) & ((ctx.r11.u32 & 0x1F) != 0);
	ctx.r8.s64 = ctx.r11.s32 >> 5;
	// addi r9,r1,-152
	ctx.r9.s64 = ctx.r1.s64 + -152;
	// addze r6,r8
	temp.s64 = ctx.r8.s64 + ctx.xer.ca;
	ctx.xer.ca = temp.u32 < ctx.r8.u32;
	ctx.r6.s64 = temp.s64;
	// srawi r8,r11,5
	ctx.xer.ca = (ctx.r11.s32 < 0) & ((ctx.r11.u32 & 0x1F) != 0);
	ctx.r8.s64 = ctx.r11.s32 >> 5;
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// addi r10,r9,-4
	ctx.r10.s64 = ctx.r9.s64 + -4;
	// addze r9,r8
	temp.s64 = ctx.r8.s64 + ctx.xer.ca;
	ctx.xer.ca = temp.u32 < ctx.r8.u32;
	ctx.r9.s64 = temp.s64;
	// mr r8,r23
	ctx.r8.u64 = ctx.r23.u64;
	// rlwinm r9,r9,5,0,26
	ctx.r9.u64 = __builtin_rotateleft64(ctx.r9.u32 | (ctx.r9.u64 << 32), 5) & 0xFFFFFFE0;
	// subf r11,r9,r11
	ctx.r11.u64 = ctx.r11.u64 - ctx.r9.u64;
	// slw r9,r27,r11
	ctx.r9.u64 = ctx.r11.u8 & 0x20 ? 0 : (ctx.r27.u32 << (ctx.r11.u8 & 0x3F));
	// not r9,r9
	ctx.r9.u64 = ~ctx.r9.u64;
	// subfic r7,r11,32
	ctx.xer.ca = ctx.r11.u32 <= 32;
	ctx.r7.u64 = static_cast<uint64_t>(32) - ctx.r11.u64;
loc_8B0D94F0:
	// lwz r5,4(r10)
	ctx.r5.u64 = REX_LOAD_U32(ctx.r10.u32 + 4);
	// and r3,r5,r9
	ctx.r3.u64 = ctx.r5.u64 & ctx.r9.u64;
	// stw r3,-160(r1)
	REX_STORE_U32(ctx.r1.u32 + -160, ctx.r3.u32);
	// srw r5,r5,r11
	ctx.r5.u64 = ctx.r11.u8 & 0x20 ? 0 : (ctx.r5.u32 >> (ctx.r11.u8 & 0x3F));
	// or r8,r5,r8
	ctx.r8.u64 = ctx.r5.u64 | ctx.r8.u64;
	// stwu r8,4(r10)
	ea = 4 + ctx.r10.u32;
	REX_STORE_U32(ea, ctx.r8.u32);
	ctx.r10.u32 = ea;
	// lwz r8,-160(r1)
	ctx.r8.u64 = REX_LOAD_U32(ctx.r1.u32 + -160);
	// slw r8,r8,r7
	ctx.r8.u64 = ctx.r7.u8 & 0x20 ? 0 : (ctx.r8.u32 << (ctx.r7.u8 & 0x3F));
	// bdnz 0x8b0d94f0
	--ctx.ctr.u64;
	if (ctx.ctr.u32 != 0) goto loc_8B0D94F0;
	// li r10,3
	ctx.r10.s64 = 3;
	// rlwinm r8,r6,2,0,29
	ctx.r8.u64 = __builtin_rotateleft64(ctx.r6.u32 | (ctx.r6.u64 << 32), 2) & 0xFFFFFFFC;
	// addi r7,r1,-144
	ctx.r7.s64 = ctx.r1.s64 + -144;
	// li r9,2
	ctx.r9.s64 = 2;
	// addi r11,r1,-144
	ctx.r11.s64 = ctx.r1.s64 + -144;
	// subf r8,r8,r7
	ctx.r8.u64 = ctx.r7.u64 - ctx.r8.u64;
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
loc_8B0D9530:
	// cmpw cr6,r9,r6
	ctx.cr6.compare<int32_t>(ctx.r9.s32, ctx.r6.s32, ctx.xer);
	// blt cr6,0x8b0d9544
	if (ctx.cr6.lt) goto loc_8B0D9544;
	// lwz r10,0(r8)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r8.u32 + 0);
	// stw r10,0(r11)
	REX_STORE_U32(ctx.r11.u32 + 0, ctx.r10.u32);
	// b 0x8b0d9548
	goto loc_8B0D9548;
loc_8B0D9544:
	// stw r23,0(r11)
	REX_STORE_U32(ctx.r11.u32 + 0, ctx.r23.u32);
loc_8B0D9548:
	// addi r9,r9,-1
	ctx.r9.s64 = ctx.r9.s64 + -1;
	// addi r8,r8,-4
	ctx.r8.s64 = ctx.r8.s64 + -4;
	// addi r11,r11,-4
	ctx.r11.s64 = ctx.r11.s64 + -4;
	// bdnz 0x8b0d9530
	--ctx.ctr.u64;
	if (ctx.ctr.u32 != 0) goto loc_8B0D9530;
	// mr r5,r23
	ctx.r5.u64 = ctx.r23.u64;
	// li r3,2
	ctx.r3.s64 = 2;
	// b 0x8b0d96e8
	goto loc_8B0D96E8;
loc_8B0D9564:
	// lwz r5,0(r20)
	ctx.r5.u64 = REX_LOAD_U32(ctx.r20.u32 + 0);
	// cmpw cr6,r30,r5
	ctx.cr6.compare<int32_t>(ctx.r30.s32, ctx.r5.s32, ctx.xer);
	// blt cr6,0x8b0d9634
	if (ctx.cr6.lt) goto loc_8B0D9634;
	// addi r11,r1,-152
	ctx.r11.s64 = ctx.r1.s64 + -152;
	// srawi r9,r21,5
	ctx.xer.ca = (ctx.r21.s32 < 0) & ((ctx.r21.u32 & 0x1F) != 0);
	ctx.r9.s64 = ctx.r21.s32 >> 5;
	// li r7,-1
	ctx.r7.s64 = -1;
	// addze r6,r9
	temp.s64 = ctx.r9.s64 + ctx.xer.ca;
	ctx.xer.ca = temp.u32 < ctx.r9.u32;
	ctx.r6.s64 = temp.s64;
	// srawi r9,r21,5
	ctx.xer.ca = (ctx.r21.s32 < 0) & ((ctx.r21.u32 & 0x1F) != 0);
	ctx.r9.s64 = ctx.r21.s32 >> 5;
	// stw r23,0(r11)
	REX_STORE_U32(ctx.r11.u32 + 0, ctx.r23.u32);
	// stw r23,4(r11)
	REX_STORE_U32(ctx.r11.u32 + 4, ctx.r23.u32);
	// addze r8,r9
	temp.s64 = ctx.r9.s64 + ctx.xer.ca;
	ctx.xer.ca = temp.u32 < ctx.r9.u32;
	ctx.r8.s64 = temp.s64;
	// stw r23,8(r11)
	REX_STORE_U32(ctx.r11.u32 + 8, ctx.r23.u32);
	// rlwinm r11,r8,5,0,26
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r8.u32 | (ctx.r8.u64 << 32), 5) & 0xFFFFFFE0;
	// addi r9,r1,-152
	ctx.r9.s64 = ctx.r1.s64 + -152;
	// subf r11,r11,r21
	ctx.r11.u64 = ctx.r21.u64 - ctx.r11.u64;
	// addi r10,r9,-4
	ctx.r10.s64 = ctx.r9.s64 + -4;
	// slw r9,r7,r11
	ctx.r9.u64 = ctx.r11.u8 & 0x20 ? 0 : (ctx.r7.u32 << (ctx.r11.u8 & 0x3F));
	// lwz r31,-152(r1)
	ctx.r31.u64 = REX_LOAD_U32(ctx.r1.u32 + -152);
	// mr r8,r23
	ctx.r8.u64 = ctx.r23.u64;
	// not r9,r9
	ctx.r9.u64 = ~ctx.r9.u64;
	// oris r31,r31,32768
	ctx.r31.u64 = ctx.r31.u64 | 2147483648;
	// subfic r7,r11,32
	ctx.xer.ca = ctx.r11.u32 <= 32;
	ctx.r7.u64 = static_cast<uint64_t>(32) - ctx.r11.u64;
	// stw r31,-152(r1)
	REX_STORE_U32(ctx.r1.u32 + -152, ctx.r31.u32);
loc_8B0D95C0:
	// lwz r31,4(r10)
	ctx.r31.u64 = REX_LOAD_U32(ctx.r10.u32 + 4);
	// and r30,r31,r9
	ctx.r30.u64 = ctx.r31.u64 & ctx.r9.u64;
	// stw r30,-160(r1)
	REX_STORE_U32(ctx.r1.u32 + -160, ctx.r30.u32);
	// srw r31,r31,r11
	ctx.r31.u64 = ctx.r11.u8 & 0x20 ? 0 : (ctx.r31.u32 >> (ctx.r11.u8 & 0x3F));
	// or r8,r31,r8
	ctx.r8.u64 = ctx.r31.u64 | ctx.r8.u64;
	// stwu r8,4(r10)
	ea = 4 + ctx.r10.u32;
	REX_STORE_U32(ea, ctx.r8.u32);
	ctx.r10.u32 = ea;
	// lwz r8,-160(r1)
	ctx.r8.u64 = REX_LOAD_U32(ctx.r1.u32 + -160);
	// slw r8,r8,r7
	ctx.r8.u64 = ctx.r7.u8 & 0x20 ? 0 : (ctx.r8.u32 << (ctx.r7.u8 & 0x3F));
	// bdnz 0x8b0d95c0
	--ctx.ctr.u64;
	if (ctx.ctr.u32 != 0) goto loc_8B0D95C0;
	// li r10,3
	ctx.r10.s64 = 3;
	// rlwinm r8,r6,2,0,29
	ctx.r8.u64 = __builtin_rotateleft64(ctx.r6.u32 | (ctx.r6.u64 << 32), 2) & 0xFFFFFFFC;
	// addi r7,r1,-144
	ctx.r7.s64 = ctx.r1.s64 + -144;
	// li r9,2
	ctx.r9.s64 = 2;
	// addi r11,r1,-144
	ctx.r11.s64 = ctx.r1.s64 + -144;
	// subf r8,r8,r7
	ctx.r8.u64 = ctx.r7.u64 - ctx.r8.u64;
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
loc_8B0D9600:
	// cmpw cr6,r9,r6
	ctx.cr6.compare<int32_t>(ctx.r9.s32, ctx.r6.s32, ctx.xer);
	// blt cr6,0x8b0d9614
	if (ctx.cr6.lt) goto loc_8B0D9614;
	// lwz r10,0(r8)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r8.u32 + 0);
	// stw r10,0(r11)
	REX_STORE_U32(ctx.r11.u32 + 0, ctx.r10.u32);
	// b 0x8b0d9618
	goto loc_8B0D9618;
loc_8B0D9614:
	// stw r23,0(r11)
	REX_STORE_U32(ctx.r11.u32 + 0, ctx.r23.u32);
loc_8B0D9618:
	// addi r9,r9,-1
	ctx.r9.s64 = ctx.r9.s64 + -1;
	// addi r8,r8,-4
	ctx.r8.s64 = ctx.r8.s64 + -4;
	// addi r11,r11,-4
	ctx.r11.s64 = ctx.r11.s64 + -4;
	// bdnz 0x8b0d9600
	--ctx.ctr.u64;
	if (ctx.ctr.u32 != 0) goto loc_8B0D9600;
	// lwz r11,20(r20)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r20.u32 + 20);
	// add r5,r11,r5
	ctx.r5.u64 = ctx.r11.u64 + ctx.r5.u64;
	// b 0x8b0d96e8
	goto loc_8B0D96E8;
loc_8B0D9634:
	// srawi r11,r21,5
	ctx.xer.ca = (ctx.r21.s32 < 0) & ((ctx.r21.u32 & 0x1F) != 0);
	ctx.r11.s64 = ctx.r21.s32 >> 5;
	// lwz r7,-152(r1)
	ctx.r7.u64 = REX_LOAD_U32(ctx.r1.u32 + -152);
	// li r6,-1
	ctx.r6.s64 = -1;
	// lwz r9,20(r20)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r20.u32 + 20);
	// addze r3,r11
	temp.s64 = ctx.r11.s64 + ctx.xer.ca;
	ctx.xer.ca = temp.u32 < ctx.r11.u32;
	ctx.r3.s64 = temp.s64;
	// srawi r11,r21,5
	ctx.xer.ca = (ctx.r21.s32 < 0) & ((ctx.r21.u32 & 0x1F) != 0);
	ctx.r11.s64 = ctx.r21.s32 >> 5;
	// clrlwi r10,r7,1
	ctx.r10.u64 = ctx.r7.u32 & 0x7FFFFFFF;
	// addze r11,r11
	temp.s64 = ctx.r11.s64 + ctx.xer.ca;
	ctx.xer.ca = temp.u32 < ctx.r11.u32;
	ctx.r11.s64 = temp.s64;
	// stw r10,-152(r1)
	REX_STORE_U32(ctx.r1.u32 + -152, ctx.r10.u32);
	// addi r8,r1,-152
	ctx.r8.s64 = ctx.r1.s64 + -152;
	// rlwinm r11,r11,5,0,26
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 5) & 0xFFFFFFE0;
	// add r5,r9,r30
	ctx.r5.u64 = ctx.r9.u64 + ctx.r30.u64;
	// subf r11,r11,r21
	ctx.r11.u64 = ctx.r21.u64 - ctx.r11.u64;
	// mr r9,r23
	ctx.r9.u64 = ctx.r23.u64;
	// slw r10,r6,r11
	ctx.r10.u64 = ctx.r11.u8 & 0x20 ? 0 : (ctx.r6.u32 << (ctx.r11.u8 & 0x3F));
	// not r7,r10
	ctx.r7.u64 = ~ctx.r10.u64;
	// subfic r6,r11,32
	ctx.xer.ca = ctx.r11.u32 <= 32;
	ctx.r6.u64 = static_cast<uint64_t>(32) - ctx.r11.u64;
	// addi r10,r8,-4
	ctx.r10.s64 = ctx.r8.s64 + -4;
loc_8B0D967C:
	// lwz r8,4(r10)
	ctx.r8.u64 = REX_LOAD_U32(ctx.r10.u32 + 4);
	// and r31,r8,r7
	ctx.r31.u64 = ctx.r8.u64 & ctx.r7.u64;
	// stw r31,-160(r1)
	REX_STORE_U32(ctx.r1.u32 + -160, ctx.r31.u32);
	// srw r8,r8,r11
	ctx.r8.u64 = ctx.r11.u8 & 0x20 ? 0 : (ctx.r8.u32 >> (ctx.r11.u8 & 0x3F));
	// or r9,r8,r9
	ctx.r9.u64 = ctx.r8.u64 | ctx.r9.u64;
	// stwu r9,4(r10)
	ea = 4 + ctx.r10.u32;
	REX_STORE_U32(ea, ctx.r9.u32);
	ctx.r10.u32 = ea;
	// lwz r9,-160(r1)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r1.u32 + -160);
	// slw r9,r9,r6
	ctx.r9.u64 = ctx.r6.u8 & 0x20 ? 0 : (ctx.r9.u32 << (ctx.r6.u8 & 0x3F));
	// bdnz 0x8b0d967c
	--ctx.ctr.u64;
	if (ctx.ctr.u32 != 0) goto loc_8B0D967C;
	// li r10,3
	ctx.r10.s64 = 3;
	// rlwinm r8,r3,2,0,29
	ctx.r8.u64 = __builtin_rotateleft64(ctx.r3.u32 | (ctx.r3.u64 << 32), 2) & 0xFFFFFFFC;
	// addi r7,r1,-144
	ctx.r7.s64 = ctx.r1.s64 + -144;
	// li r9,2
	ctx.r9.s64 = 2;
	// addi r11,r1,-144
	ctx.r11.s64 = ctx.r1.s64 + -144;
	// subf r8,r8,r7
	ctx.r8.u64 = ctx.r7.u64 - ctx.r8.u64;
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
loc_8B0D96BC:
	// cmpw cr6,r9,r3
	ctx.cr6.compare<int32_t>(ctx.r9.s32, ctx.r3.s32, ctx.xer);
	// blt cr6,0x8b0d96d0
	if (ctx.cr6.lt) goto loc_8B0D96D0;
	// lwz r10,0(r8)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r8.u32 + 0);
	// stw r10,0(r11)
	REX_STORE_U32(ctx.r11.u32 + 0, ctx.r10.u32);
	// b 0x8b0d96d4
	goto loc_8B0D96D4;
loc_8B0D96D0:
	// stw r23,0(r11)
	REX_STORE_U32(ctx.r11.u32 + 0, ctx.r23.u32);
loc_8B0D96D4:
	// addi r9,r9,-1
	ctx.r9.s64 = ctx.r9.s64 + -1;
	// addi r8,r8,-4
	ctx.r8.s64 = ctx.r8.s64 + -4;
	// addi r11,r11,-4
	ctx.r11.s64 = ctx.r11.s64 + -4;
	// bdnz 0x8b0d96bc
	--ctx.ctr.u64;
	if (ctx.ctr.u32 != 0) goto loc_8B0D96BC;
loc_8B0D96E4:
	// mr r3,r23
	ctx.r3.u64 = ctx.r23.u64;
loc_8B0D96E8:
	// subfic r10,r21,31
	ctx.xer.ca = ctx.r21.u32 <= 31;
	ctx.r10.u64 = static_cast<uint64_t>(31) - ctx.r21.u64;
	// lwz r11,16(r20)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r20.u32 + 16);
	// subfic r9,r19,0
	ctx.xer.ca = ctx.r19.u32 <= 0;
	ctx.r9.u64 = static_cast<uint64_t>(0) - ctx.r19.u64;
	// lwz r8,-152(r1)
	ctx.r8.u64 = REX_LOAD_U32(ctx.r1.u32 + -152);
	// lis r7,-32768
	ctx.r7.s64 = -2147483648;
	// subfe r9,r9,r9
	temp.u8 = (~ctx.r9.u32 + ctx.r9.u32 < ~ctx.r9.u32) | (~ctx.r9.u32 + ctx.r9.u32 + ctx.xer.ca < ctx.xer.ca);
	ctx.r9.u64 = ~ctx.r9.u64 + ctx.r9.u64 + ctx.xer.ca;
	ctx.xer.ca = temp.u8;
	// slw r10,r5,r10
	ctx.r10.u64 = ctx.r10.u8 & 0x20 ? 0 : (ctx.r5.u32 << (ctx.r10.u8 & 0x3F));
	// and r9,r9,r7
	ctx.r9.u64 = ctx.r9.u64 & ctx.r7.u64;
	// cmpwi cr6,r11,64
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 64, ctx.xer);
	// or r10,r10,r9
	ctx.r10.u64 = ctx.r10.u64 | ctx.r9.u64;
	// or r10,r10,r8
	ctx.r10.u64 = ctx.r10.u64 | ctx.r8.u64;
	// bne cr6,0x8b0d9724
	if (!ctx.cr6.eq) goto loc_8B0D9724;
	// lwz r11,-148(r1)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r1.u32 + -148);
	// stw r11,4(r4)
	REX_STORE_U32(ctx.r4.u32 + 4, ctx.r11.u32);
	// b 0x8b0d972c
	goto loc_8B0D972C;
loc_8B0D9724:
	// cmpwi cr6,r11,32
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 32, ctx.xer);
	// bne cr6,0x8b0d9730
	if (!ctx.cr6.eq) goto loc_8B0D9730;
loc_8B0D972C:
	// stw r10,0(r4)
	REX_STORE_U32(ctx.r4.u32 + 0, ctx.r10.u32);
loc_8B0D9730:
	// b 0x8b0cb9e4
	__restgprlr_19(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0DB860) {
	REX_FUNC_PROLOGUE();
	PPCRegister temp{};
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// std r30,-24(r1)
	REX_STORE_U64(ctx.r1.u32 + -24, ctx.r30.u64);
	// std r31,-16(r1)
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.r31.u64);
	// addi r31,r1,-112
	ctx.r31.s64 = ctx.r1.s64 + -112;
	// stwu r1,-112(r1)
	ea = -112 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// mr r30,r3
	ctx.r30.u64 = ctx.r3.u64;
	// stw r3,132(r31)
	REX_STORE_U32(ctx.r31.u32 + 132, ctx.r3.u32);
	// addic r11,r3,-1
	ctx.xer.ca = ctx.r3.u32 > 0;
	ctx.r11.s64 = ctx.r3.s64 + -1;
	// li r10,-1
	ctx.r10.s64 = -1;
	// subfe. r11,r11,r3
	temp.u8 = (~ctx.r11.u32 + ctx.r3.u32 < ~ctx.r11.u32) | (~ctx.r11.u32 + ctx.r3.u32 + ctx.xer.ca < ctx.xer.ca);
	ctx.r11.u64 = ~ctx.r11.u64 + ctx.r3.u64 + ctx.xer.ca;
	ctx.xer.ca = temp.u8;
	ctx.cr0.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// stw r10,80(r31)
	REX_STORE_U32(ctx.r31.u32 + 80, ctx.r10.u32);
	// bne 0x8b0db8c0
	if (!ctx.cr0.eq) goto loc_8B0DB8C0;
	// bl 0x8b0d0288
	ctx.lr = 0x8B0DB898;
	sub_8B0D0288(ctx, base);
	// li r11,22
	ctx.r11.s64 = 22;
	// li r7,0
	ctx.r7.s64 = 0;
	// stw r11,0(r3)
	REX_STORE_U32(ctx.r3.u32 + 0, ctx.r11.u32);
	// li r6,0
	ctx.r6.s64 = 0;
	// li r5,0
	ctx.r5.s64 = 0;
	// li r4,0
	ctx.r4.s64 = 0;
	// li r3,0
	ctx.r3.s64 = 0;
	// bl 0x8b0d0148
	ctx.lr = 0x8B0DB8B8;
	sub_8B0D0148(ctx, base);
	// li r3,-1
	ctx.r3.s64 = -1;
	// b 0x8b0db900
	goto loc_8B0DB900;
loc_8B0DB8C0:
	// lwz r11,12(r30)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r30.u32 + 12);
	// rlwinm. r11,r11,0,25,25
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 0) & 0x40;
	ctx.cr0.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// beq 0x8b0db8d8
	if (ctx.cr0.eq) goto loc_8B0DB8D8;
	// li r11,0
	ctx.r11.s64 = 0;
	// stw r11,12(r30)
	REX_STORE_U32(ctx.r30.u32 + 12, ctx.r11.u32);
	// b 0x8b0db8fc
	goto loc_8B0DB8FC;
loc_8B0DB8D8:
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// bl 0x8b0d6b48
	ctx.lr = 0x8B0DB8E0;
	sub_8B0D6B48(ctx, base);
	// mr r8,r8
	ctx.r8.u64 = ctx.r8.u64;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// bl 0x8b0db7a8
	ctx.lr = 0x8B0DB8EC;
	sub_8B0DB7A8(ctx, base);
	// stw r3,80(r31)
	REX_STORE_U32(ctx.r31.u32 + 80, ctx.r3.u32);
	// mr r8,r8
	ctx.r8.u64 = ctx.r8.u64;
	// addi r12,r31,112
	ctx.r12.s64 = ctx.r31.s64 + 112;
	// bl 0x8b0db938
	ctx.lr = 0x8B0DB8FC;
	sub_8B0DB938(ctx, base);
loc_8B0DB8FC:
	// lwz r3,80(r31)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r31.u32 + 80);
loc_8B0DB900:
	// addi r1,r31,112
	ctx.r1.s64 = ctx.r31.s64 + 112;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// ld r30,-24(r1)
	ctx.r30.u64 = REX_LOAD_U64(ctx.r1.u32 + -24);
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0DB978) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9b4
	ctx.lr = 0x8B0DB980;
	__savegprlr_27(ctx, base);
	// addi r31,r1,-144
	ctx.r31.s64 = ctx.r1.s64 + -144;
	// stwu r1,-144(r1)
	ea = -144 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// mr r27,r3
	ctx.r27.u64 = ctx.r3.u64;
	// stw r3,164(r31)
	REX_STORE_U32(ctx.r31.u32 + 164, ctx.r3.u32);
	// cmpwi cr6,r3,-2
	ctx.cr6.compare<int32_t>(ctx.r3.s32, -2, ctx.xer);
	// bne cr6,0x8b0db9b0
	if (!ctx.cr6.eq) goto loc_8B0DB9B0;
	// bl 0x8b0d0288
	ctx.lr = 0x8B0DB99C;
	sub_8B0D0288(ctx, base);
	// mr r11,r3
	ctx.r11.u64 = ctx.r3.u64;
	// li r10,9
	ctx.r10.s64 = 9;
	// li r3,-1
	ctx.r3.s64 = -1;
	// stw r10,0(r11)
	REX_STORE_U32(ctx.r11.u32 + 0, ctx.r10.u32);
	// b 0x8b0dba9c
	goto loc_8B0DBA9C;
loc_8B0DB9B0:
	// cmpwi cr6,r27,0
	ctx.cr6.compare<int32_t>(ctx.r27.s32, 0, ctx.xer);
	// blt cr6,0x8b0db9c8
	if (ctx.cr6.lt) goto loc_8B0DB9C8;
	// lis r11,-29936
	ctx.r11.s64 = -1961885696;
	// lwz r11,-16892(r11)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r11.u32 + -16892);
	// cmplw cr6,r27,r11
	ctx.cr6.compare<uint32_t>(ctx.r27.u32, ctx.r11.u32, ctx.xer);
	// blt cr6,0x8b0db9f4
	if (ctx.cr6.lt) goto loc_8B0DB9F4;
loc_8B0DB9C8:
	// bl 0x8b0d0288
	ctx.lr = 0x8B0DB9CC;
	sub_8B0D0288(ctx, base);
	// li r11,9
	ctx.r11.s64 = 9;
	// li r7,0
	ctx.r7.s64 = 0;
	// stw r11,0(r3)
	REX_STORE_U32(ctx.r3.u32 + 0, ctx.r11.u32);
	// li r6,0
	ctx.r6.s64 = 0;
	// li r5,0
	ctx.r5.s64 = 0;
	// li r4,0
	ctx.r4.s64 = 0;
	// li r3,0
	ctx.r3.s64 = 0;
	// bl 0x8b0d0148
	ctx.lr = 0x8B0DB9EC;
	sub_8B0D0148(ctx, base);
	// li r3,-1
	ctx.r3.s64 = -1;
	// b 0x8b0dba9c
	goto loc_8B0DBA9C;
loc_8B0DB9F4:
	// srawi r11,r27,5
	ctx.xer.ca = (ctx.r27.s32 < 0) & ((ctx.r27.u32 & 0x1F) != 0);
	ctx.r11.s64 = ctx.r27.s32 >> 5;
	// lis r10,-29936
	ctx.r10.s64 = -1961885696;
	// rlwinm r28,r11,2,0,29
	ctx.r28.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 2) & 0xFFFFFFFC;
	// addi r29,r10,-16864
	ctx.r29.s64 = ctx.r10.s64 + -16864;
	// clrlwi r11,r27,27
	ctx.r11.u64 = ctx.r27.u32 & 0x1F;
	// mulli r30,r11,72
	ctx.r30.s64 = static_cast<int64_t>(ctx.r11.u64 * static_cast<uint64_t>(72));
	// lwzx r11,r28,r29
	ctx.r11.u64 = REX_LOAD_U32(ctx.r28.u32 + ctx.r29.u32);
	// add r11,r30,r11
	ctx.r11.u64 = ctx.r30.u64 + ctx.r11.u64;
	// lbz r11,4(r11)
	ctx.r11.u64 = REX_LOAD_U8(ctx.r11.u32 + 4);
	// clrlwi. r11,r11,31
	ctx.r11.u64 = ctx.r11.u32 & 0x1;
	ctx.cr0.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// beq 0x8b0db9c8
	if (ctx.cr0.eq) goto loc_8B0DB9C8;
	// mr r3,r27
	ctx.r3.u64 = ctx.r27.u64;
	// bl 0x8b0d9b38
	ctx.lr = 0x8B0DBA28;
	sub_8B0D9B38(ctx, base);
	// mr r8,r8
	ctx.r8.u64 = ctx.r8.u64;
	// lwzx r11,r28,r29
	ctx.r11.u64 = REX_LOAD_U32(ctx.r28.u32 + ctx.r29.u32);
	// add r11,r30,r11
	ctx.r11.u64 = ctx.r30.u64 + ctx.r11.u64;
	// lbz r11,4(r11)
	ctx.r11.u64 = REX_LOAD_U8(ctx.r11.u32 + 4);
	// clrlwi. r11,r11,31
	ctx.r11.u64 = ctx.r11.u32 & 0x1;
	ctx.cr0.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// beq 0x8b0dba78
	if (ctx.cr0.eq) goto loc_8B0DBA78;
	// mr r3,r27
	ctx.r3.u64 = ctx.r27.u64;
	// bl 0x8b0d9a68
	ctx.lr = 0x8B0DBA48;
	sub_8B0D9A68(ctx, base);
	// bl 0x8b0dcc40
	ctx.lr = 0x8B0DBA4C;
	sub_8B0DCC40(ctx, base);
	// cmpwi r3,0
	ctx.cr0.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// bne 0x8b0dba60
	if (!ctx.cr0.eq) goto loc_8B0DBA60;
	// bl 0x8b0dc5d8
	ctx.lr = 0x8B0DBA58;
	sub_8B0DC5D8(ctx, base);
	// mr r30,r3
	ctx.r30.u64 = ctx.r3.u64;
	// b 0x8b0dba64
	goto loc_8B0DBA64;
loc_8B0DBA60:
	// li r30,0
	ctx.r30.s64 = 0;
loc_8B0DBA64:
	// stw r30,80(r31)
	REX_STORE_U32(ctx.r31.u32 + 80, ctx.r30.u32);
	// cmpwi cr6,r30,0
	ctx.cr6.compare<int32_t>(ctx.r30.s32, 0, ctx.xer);
	// beq cr6,0x8b0dba8c
	if (ctx.cr6.eq) goto loc_8B0DBA8C;
	// bl 0x8b0d02c0
	ctx.lr = 0x8B0DBA74;
	sub_8B0D02C0(ctx, base);
	// stw r30,0(r3)
	REX_STORE_U32(ctx.r3.u32 + 0, ctx.r30.u32);
loc_8B0DBA78:
	// bl 0x8b0d0288
	ctx.lr = 0x8B0DBA7C;
	sub_8B0D0288(ctx, base);
	// li r11,9
	ctx.r11.s64 = 9;
	// li r10,-1
	ctx.r10.s64 = -1;
	// stw r11,0(r3)
	REX_STORE_U32(ctx.r3.u32 + 0, ctx.r11.u32);
	// stw r10,80(r31)
	REX_STORE_U32(ctx.r31.u32 + 80, ctx.r10.u32);
loc_8B0DBA8C:
	// mr r8,r8
	ctx.r8.u64 = ctx.r8.u64;
	// addi r12,r31,144
	ctx.r12.s64 = ctx.r31.s64 + 144;
	// bl 0x8b0dbac4
	ctx.lr = 0x8B0DBA98;
	sub_8B0DBAC4(ctx, base);
	// lwz r3,80(r31)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r31.u32 + 80);
loc_8B0DBA9C:
	// addi r1,r31,144
	ctx.r1.s64 = ctx.r31.s64 + 144;
	// b 0x8b0cba04
	__restgprlr_27(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0DBD04) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// std r31,-8(r1)
	REX_STORE_U64(ctx.r1.u32 + -8, ctx.r31.u64);
	// addi r31,r12,-144
	ctx.r31.s64 = ctx.r12.s64 + -144;
	// std r30,-16(r1)
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.r30.u64);
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-24(r1)
	REX_STORE_U32(ctx.r1.u32 + -24, ctx.r12.u32);
	// stwu r1,-112(r1)
	ea = -112 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lwz r30,164(r31)
	ctx.r30.u64 = REX_LOAD_U32(ctx.r31.u32 + 164);
	// b 0x8b0dbd3c
	goto loc_8B0DBD3C;
loc_8B0DBD3C:
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// bl 0x8b0d9c38
	ctx.lr = 0x8B0DBD44;
	sub_8B0D9C38(ctx, base);
	// lwz r1,0(r1)
	ctx.r1.u64 = REX_LOAD_U32(ctx.r1.u32 + 0);
	// ld r31,-8(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -8);
	// ld r30,-16(r1)
	ctx.r30.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// lwz r12,-24(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -24);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0DBDC8) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// stwu r1,-96(r1)
	ea = -96 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// bl 0x8b0df598
	ctx.lr = 0x8B0DBDD8;
	__imp__XamUserGetSigninInfo(ctx, base);
	// cmpwi r3,0
	ctx.cr0.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// blt 0x8b0dbde8
	if (ctx.cr0.lt) goto loc_8B0DBDE8;
	// li r3,0
	ctx.r3.s64 = 0;
	// b 0x8b0dbe00
	goto loc_8B0DBE00;
loc_8B0DBDE8:
	// rlwinm r11,r3,0,3,15
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r3.u32 | (ctx.r3.u64 << 32), 0) & 0x1FFF0000;
	// lis r10,7
	ctx.r10.s64 = 458752;
	// clrlwi r3,r3,16
	ctx.r3.u64 = ctx.r3.u32 & 0xFFFF;
	// cmpw cr6,r11,r10
	ctx.cr6.compare<int32_t>(ctx.r11.s32, ctx.r10.s32, ctx.xer);
	// beq cr6,0x8b0dbe00
	if (ctx.cr6.eq) goto loc_8B0DBE00;
	// li r3,1627
	ctx.r3.s64 = 1627;
loc_8B0DBE00:
	// addi r1,r1,96
	ctx.r1.s64 = ctx.r1.s64 + 96;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0DBE58) {
	REX_FUNC_PROLOGUE();
	// mr r8,r7
	ctx.r8.u64 = ctx.r7.u64;
	// mr r7,r6
	ctx.r7.u64 = ctx.r6.u64;
	// mr r6,r5
	ctx.r6.u64 = ctx.r5.u64;
	// mr r5,r4
	ctx.r5.u64 = ctx.r4.u64;
	// li r4,0
	ctx.r4.s64 = 0;
	// b 0x8b0df5a8
	__imp__XamEnumerate(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0DBF08) {
	REX_FUNC_PROLOGUE();
	// b 0x8b0df5b8
	__imp__XamInputGetCapabilities(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0DBF10) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// stwu r1,-96(r1)
	ea = -96 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// li r11,0
	ctx.r11.s64 = 0;
	// addi r7,r1,82
	ctx.r7.s64 = ctx.r1.s64 + 82;
	// sth r11,82(r1)
	REX_STORE_U16(ctx.r1.u32 + 82, ctx.r11.u16);
	// li r6,1
	ctx.r6.s64 = 1;
	// addi r5,r1,80
	ctx.r5.s64 = ctx.r1.s64 + 80;
	// li r4,14
	ctx.r4.s64 = 14;
	// li r3,3
	ctx.r3.s64 = 3;
	// bl 0x8b0df638
	ctx.lr = 0x8B0DBF3C;
	__imp__ExGetXConfigSetting(ctx, base);
	// cmpwi r3,0
	ctx.cr0.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// blt 0x8b0dc0ac
	if (ctx.cr0.lt) goto loc_8B0DC0AC;
	// lbz r11,80(r1)
	ctx.r11.u64 = REX_LOAD_U8(ctx.r1.u32 + 80);
	// cmplwi cr6,r11,110
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 110, ctx.xer);
	// bgt cr6,0x8b0dc0ac
	if (ctx.cr6.gt) goto loc_8B0DC0AC;
	// addi r11,r11,-5
	ctx.r11.s64 = ctx.r11.s64 + -5;
	// cmplwi cr6,r11,104
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 104, ctx.xer);
	// bgt cr6,0x8b0dc0ac
	if (ctx.cr6.gt) goto loc_8B0DC0AC;
	// lis r12,-29943
	ctx.r12.s64 = -1962344448;
	// addi r12,r12,-17248
	ctx.r12.s64 = ctx.r12.s64 + -17248;
	// lbzx r0,r12,r11
	ctx.r0.u64 = REX_LOAD_U8(ctx.r12.u32 + ctx.r11.u32);
	// rlwinm r0,r0,2,0,29
	ctx.r0.u64 = __builtin_rotateleft64(ctx.r0.u32 | (ctx.r0.u64 << 32), 2) & 0xFFFFFFFC;
	// lis r12,-29938
	ctx.r12.s64 = -1962016768;
	// nop 
	// addi r12,r12,-16508
	ctx.r12.s64 = ctx.r12.s64 + -16508;
	// add r12,r12,r0
	ctx.r12.u64 = ctx.r12.u64 + ctx.r0.u64;
	// mtctr r12
	ctx.ctr.u64 = ctx.r12.u64;
	// bctr 
	switch (ctx.r11.u32) {
	case 0:
		goto loc_8B0DBF8C;
	case 1:
		goto loc_8B0DBF84;
	case 2:
		goto loc_8B0DC0AC;
	case 3:
		goto loc_8B0DBF94;
	case 4:
		goto loc_8B0DC0AC;
	case 5:
		goto loc_8B0DC0AC;
	case 6:
		goto loc_8B0DC0AC;
	case 7:
		goto loc_8B0DC0AC;
	case 8:
		goto loc_8B0DBF9C;
	case 9:
		goto loc_8B0DC0AC;
	case 10:
		goto loc_8B0DC0AC;
	case 11:
		goto loc_8B0DBFA4;
	case 12:
		goto loc_8B0DC0AC;
	case 13:
		goto loc_8B0DC08C;
	case 14:
		goto loc_8B0DBFAC;
	case 15:
		goto loc_8B0DBFB4;
	case 16:
		goto loc_8B0DBFBC;
	case 17:
		goto loc_8B0DC0AC;
	case 18:
		goto loc_8B0DBFC4;
	case 19:
		goto loc_8B0DBFE4;
	case 20:
		goto loc_8B0DBFCC;
	case 21:
		goto loc_8B0DC0AC;
	case 22:
		goto loc_8B0DC0AC;
	case 23:
		goto loc_8B0DC0AC;
	case 24:
		goto loc_8B0DC0AC;
	case 25:
		goto loc_8B0DC0AC;
	case 26:
		goto loc_8B0DC07C;
	case 27:
		goto loc_8B0DBFD4;
	case 28:
		goto loc_8B0DC0AC;
	case 29:
		goto loc_8B0DBFDC;
	case 30:
		goto loc_8B0DC09C;
	case 31:
		goto loc_8B0DC0AC;
	case 32:
		goto loc_8B0DBFEC;
	case 33:
		goto loc_8B0DC0AC;
	case 34:
		goto loc_8B0DBFF4;
	case 35:
		goto loc_8B0DC0AC;
	case 36:
		goto loc_8B0DC0AC;
	case 37:
		goto loc_8B0DBFFC;
	case 38:
		goto loc_8B0DC0AC;
	case 39:
		goto loc_8B0DC00C;
	case 40:
		goto loc_8B0DC0AC;
	case 41:
		goto loc_8B0DC004;
	case 42:
		goto loc_8B0DC0AC;
	case 43:
		goto loc_8B0DC0AC;
	case 44:
		goto loc_8B0DC0AC;
	case 45:
		goto loc_8B0DC014;
	case 46:
		goto loc_8B0DC0AC;
	case 47:
		goto loc_8B0DC0AC;
	case 48:
		goto loc_8B0DC01C;
	case 49:
		goto loc_8B0DC0AC;
	case 50:
		goto loc_8B0DC0AC;
	case 51:
		goto loc_8B0DC024;
	case 52:
		goto loc_8B0DC0AC;
	case 53:
		goto loc_8B0DC0AC;
	case 54:
		goto loc_8B0DC0AC;
	case 55:
		goto loc_8B0DC0AC;
	case 56:
		goto loc_8B0DC0AC;
	case 57:
		goto loc_8B0DC0AC;
	case 58:
		goto loc_8B0DC0AC;
	case 59:
		goto loc_8B0DC0AC;
	case 60:
		goto loc_8B0DC0AC;
	case 61:
		goto loc_8B0DC0AC;
	case 62:
		goto loc_8B0DC0AC;
	case 63:
		goto loc_8B0DC0AC;
	case 64:
		goto loc_8B0DC0AC;
	case 65:
		goto loc_8B0DC0AC;
	case 66:
		goto loc_8B0DC02C;
	case 67:
		goto loc_8B0DC0AC;
	case 68:
		goto loc_8B0DC0AC;
	case 69:
		goto loc_8B0DC034;
	case 70:
		goto loc_8B0DC044;
	case 71:
		goto loc_8B0DC03C;
	case 72:
		goto loc_8B0DC0AC;
	case 73:
		goto loc_8B0DC0AC;
	case 74:
		goto loc_8B0DC0AC;
	case 75:
		goto loc_8B0DC0AC;
	case 76:
		goto loc_8B0DC0AC;
	case 77:
		goto loc_8B0DC04C;
	case 78:
		goto loc_8B0DC0AC;
	case 79:
		goto loc_8B0DC054;
	case 80:
		goto loc_8B0DC0AC;
	case 81:
		goto loc_8B0DC0AC;
	case 82:
		goto loc_8B0DC0AC;
	case 83:
		goto loc_8B0DC05C;
	case 84:
		goto loc_8B0DC0AC;
	case 85:
		goto loc_8B0DC084;
	case 86:
		goto loc_8B0DC064;
	case 87:
		goto loc_8B0DC0AC;
	case 88:
		goto loc_8B0DC06C;
	case 89:
		goto loc_8B0DC0AC;
	case 90:
		goto loc_8B0DC0AC;
	case 91:
		goto loc_8B0DC0AC;
	case 92:
		goto loc_8B0DC0AC;
	case 93:
		goto loc_8B0DC0AC;
	case 94:
		goto loc_8B0DC0AC;
	case 95:
		goto loc_8B0DC0AC;
	case 96:
		goto loc_8B0DC094;
	case 97:
		goto loc_8B0DC0AC;
	case 98:
		goto loc_8B0DC0A4;
	case 99:
		goto loc_8B0DC0AC;
	case 100:
		goto loc_8B0DC0AC;
	case 101:
		goto loc_8B0DC0AC;
	case 102:
		goto loc_8B0DC0AC;
	case 103:
		goto loc_8B0DC0AC;
	case 104:
		goto loc_8B0DC074;
	default:
		__builtin_trap(); // Switch case out of range
	}
loc_8B0DBF84:
	// li r11,1
	ctx.r11.s64 = 1;
	// b 0x8b0dc0b0
	goto loc_8B0DC0B0;
loc_8B0DBF8C:
	// li r11,2
	ctx.r11.s64 = 2;
	// b 0x8b0dc0b0
	goto loc_8B0DC0B0;
loc_8B0DBF94:
	// li r11,3
	ctx.r11.s64 = 3;
	// b 0x8b0dc0b0
	goto loc_8B0DC0B0;
loc_8B0DBF9C:
	// li r11,4
	ctx.r11.s64 = 4;
	// b 0x8b0dc0b0
	goto loc_8B0DC0B0;
loc_8B0DBFA4:
	// li r11,5
	ctx.r11.s64 = 5;
	// b 0x8b0dc0b0
	goto loc_8B0DC0B0;
loc_8B0DBFAC:
	// li r11,6
	ctx.r11.s64 = 6;
	// b 0x8b0dc0b0
	goto loc_8B0DC0B0;
loc_8B0DBFB4:
	// li r11,7
	ctx.r11.s64 = 7;
	// b 0x8b0dc0b0
	goto loc_8B0DC0B0;
loc_8B0DBFBC:
	// li r11,8
	ctx.r11.s64 = 8;
	// b 0x8b0dc0b0
	goto loc_8B0DC0B0;
loc_8B0DBFC4:
	// li r11,9
	ctx.r11.s64 = 9;
	// b 0x8b0dc0b0
	goto loc_8B0DC0B0;
loc_8B0DBFCC:
	// li r11,10
	ctx.r11.s64 = 10;
	// b 0x8b0dc0b0
	goto loc_8B0DC0B0;
loc_8B0DBFD4:
	// li r11,11
	ctx.r11.s64 = 11;
	// b 0x8b0dc0b0
	goto loc_8B0DC0B0;
loc_8B0DBFDC:
	// li r11,12
	ctx.r11.s64 = 12;
	// b 0x8b0dc0b0
	goto loc_8B0DC0B0;
loc_8B0DBFE4:
	// li r11,13
	ctx.r11.s64 = 13;
	// b 0x8b0dc0b0
	goto loc_8B0DC0B0;
loc_8B0DBFEC:
	// li r11,14
	ctx.r11.s64 = 14;
	// b 0x8b0dc0b0
	goto loc_8B0DC0B0;
loc_8B0DBFF4:
	// li r11,15
	ctx.r11.s64 = 15;
	// b 0x8b0dc0b0
	goto loc_8B0DC0B0;
loc_8B0DBFFC:
	// li r11,16
	ctx.r11.s64 = 16;
	// b 0x8b0dc0b0
	goto loc_8B0DC0B0;
loc_8B0DC004:
	// li r11,17
	ctx.r11.s64 = 17;
	// b 0x8b0dc0b0
	goto loc_8B0DC0B0;
loc_8B0DC00C:
	// li r11,18
	ctx.r11.s64 = 18;
	// b 0x8b0dc0b0
	goto loc_8B0DC0B0;
loc_8B0DC014:
	// li r11,19
	ctx.r11.s64 = 19;
	// b 0x8b0dc0b0
	goto loc_8B0DC0B0;
loc_8B0DC01C:
	// li r11,20
	ctx.r11.s64 = 20;
	// b 0x8b0dc0b0
	goto loc_8B0DC0B0;
loc_8B0DC024:
	// li r11,21
	ctx.r11.s64 = 21;
	// b 0x8b0dc0b0
	goto loc_8B0DC0B0;
loc_8B0DC02C:
	// li r11,22
	ctx.r11.s64 = 22;
	// b 0x8b0dc0b0
	goto loc_8B0DC0B0;
loc_8B0DC034:
	// li r11,23
	ctx.r11.s64 = 23;
	// b 0x8b0dc0b0
	goto loc_8B0DC0B0;
loc_8B0DC03C:
	// li r11,24
	ctx.r11.s64 = 24;
	// b 0x8b0dc0b0
	goto loc_8B0DC0B0;
loc_8B0DC044:
	// li r11,25
	ctx.r11.s64 = 25;
	// b 0x8b0dc0b0
	goto loc_8B0DC0B0;
loc_8B0DC04C:
	// li r11,26
	ctx.r11.s64 = 26;
	// b 0x8b0dc0b0
	goto loc_8B0DC0B0;
loc_8B0DC054:
	// li r11,27
	ctx.r11.s64 = 27;
	// b 0x8b0dc0b0
	goto loc_8B0DC0B0;
loc_8B0DC05C:
	// li r11,37
	ctx.r11.s64 = 37;
	// b 0x8b0dc0b0
	goto loc_8B0DC0B0;
loc_8B0DC064:
	// li r11,28
	ctx.r11.s64 = 28;
	// b 0x8b0dc0b0
	goto loc_8B0DC0B0;
loc_8B0DC06C:
	// li r11,29
	ctx.r11.s64 = 29;
	// b 0x8b0dc0b0
	goto loc_8B0DC0B0;
loc_8B0DC074:
	// li r11,30
	ctx.r11.s64 = 30;
	// b 0x8b0dc0b0
	goto loc_8B0DC0B0;
loc_8B0DC07C:
	// li r11,31
	ctx.r11.s64 = 31;
	// b 0x8b0dc0b0
	goto loc_8B0DC0B0;
loc_8B0DC084:
	// li r11,32
	ctx.r11.s64 = 32;
	// b 0x8b0dc0b0
	goto loc_8B0DC0B0;
loc_8B0DC08C:
	// li r11,33
	ctx.r11.s64 = 33;
	// b 0x8b0dc0b0
	goto loc_8B0DC0B0;
loc_8B0DC094:
	// li r11,34
	ctx.r11.s64 = 34;
	// b 0x8b0dc0b0
	goto loc_8B0DC0B0;
loc_8B0DC09C:
	// li r11,35
	ctx.r11.s64 = 35;
	// b 0x8b0dc0b0
	goto loc_8B0DC0B0;
loc_8B0DC0A4:
	// li r11,36
	ctx.r11.s64 = 36;
	// b 0x8b0dc0b0
	goto loc_8B0DC0B0;
loc_8B0DC0AC:
	// li r11,0
	ctx.r11.s64 = 0;
loc_8B0DC0B0:
	// clrlwi. r10,r11,24
	ctx.r10.u64 = ctx.r11.u32 & 0xFF;
	ctx.cr0.compare<int32_t>(ctx.r10.s32, 0, ctx.xer);
	// beq 0x8b0dc0c0
	if (ctx.cr0.eq) goto loc_8B0DC0C0;
	// cmplwi cr6,r10,37
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 37, ctx.xer);
	// ble cr6,0x8b0dc0fc
	if (!ctx.cr6.gt) goto loc_8B0DC0FC;
loc_8B0DC0C0:
	// bl 0x8b0df588
	ctx.lr = 0x8B0DC0C4;
	__imp__XGetGameRegion(ctx, base);
	// rlwinm r11,r3,24,24,31
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r3.u32 | (ctx.r3.u64 << 32), 24) & 0xFF;
	// cmplwi cr6,r11,1
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 1, ctx.xer);
	// bne cr6,0x8b0dc0e8
	if (!ctx.cr6.eq) goto loc_8B0DC0E8;
	// addi r11,r3,-257
	ctx.r11.s64 = ctx.r3.s64 + -257;
	// cntlzw r11,r11
	ctx.r11.u64 = ctx.r11.u32 == 0 ? 32 : __builtin_clz(ctx.r11.u32);
	// rlwinm r11,r11,27,31,31
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 27) & 0x1;
	// xori r11,r11,1
	ctx.r11.u64 = ctx.r11.u64 ^ 1;
	// addi r11,r11,20
	ctx.r11.s64 = ctx.r11.s64 + 20;
	// b 0x8b0dc0fc
	goto loc_8B0DC0FC;
loc_8B0DC0E8:
	// addi r11,r11,-2
	ctx.r11.s64 = ctx.r11.s64 + -2;
	// cntlzw r11,r11
	ctx.r11.u64 = ctx.r11.u32 == 0 ? 32 : __builtin_clz(ctx.r11.u32);
	// rlwinm r11,r11,27,31,31
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 27) & 0x1;
	// xori r11,r11,1
	ctx.r11.u64 = ctx.r11.u64 ^ 1;
	// addi r11,r11,35
	ctx.r11.s64 = ctx.r11.s64 + 35;
loc_8B0DC0FC:
	// clrlwi r3,r11,24
	ctx.r3.u64 = ctx.r11.u32 & 0xFF;
	// addi r1,r1,96
	ctx.r1.s64 = ctx.r1.s64 + 96;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0DC998) {
	REX_FUNC_PROLOGUE();
	PPCRegister temp{};
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9bc
	ctx.lr = 0x8B0DC9A0;
	__savegprlr_29(ctx, base);
	// stwu r1,-128(r1)
	ea = -128 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// mr r30,r3
	ctx.r30.u64 = ctx.r3.u64;
	// mr r8,r4
	ctx.r8.u64 = ctx.r4.u64;
	// mr r9,r5
	ctx.r9.u64 = ctx.r5.u64;
	// mr r29,r6
	ctx.r29.u64 = ctx.r6.u64;
	// mr r31,r7
	ctx.r31.u64 = ctx.r7.u64;
	// cmplwi cr6,r6,0
	ctx.cr6.compare<uint32_t>(ctx.r6.u32, 0, ctx.xer);
	// beq cr6,0x8b0dc9c8
	if (ctx.cr6.eq) goto loc_8B0DC9C8;
	// li r11,0
	ctx.r11.s64 = 0;
	// stw r11,0(r6)
	REX_STORE_U32(ctx.r6.u32 + 0, ctx.r11.u32);
loc_8B0DC9C8:
	// cmplwi cr6,r31,0
	ctx.cr6.compare<uint32_t>(ctx.r31.u32, 0, ctx.xer);
	// li r5,0
	ctx.r5.s64 = 0;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// beq cr6,0x8b0dca40
	if (ctx.cr6.eq) goto loc_8B0DCA40;
	// lwz r11,8(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 8);
	// li r7,259
	ctx.r7.s64 = 259;
	// lwz r6,12(r31)
	ctx.r6.u64 = REX_LOAD_U32(ctx.r31.u32 + 12);
	// addi r10,r1,88
	ctx.r10.s64 = ctx.r1.s64 + 88;
	// stw r7,0(r31)
	REX_STORE_U32(ctx.r31.u32 + 0, ctx.r7.u32);
	// mr r7,r31
	ctx.r7.u64 = ctx.r31.u64;
	// lwz r4,16(r31)
	ctx.r4.u64 = REX_LOAD_U32(ctx.r31.u32 + 16);
	// stw r11,92(r1)
	REX_STORE_U32(ctx.r1.u32 + 92, ctx.r11.u32);
	// clrlwi r11,r4,31
	ctx.r11.u64 = ctx.r4.u32 & 0x1;
	// stw r6,88(r1)
	REX_STORE_U32(ctx.r1.u32 + 88, ctx.r6.u32);
	// addic r11,r11,-1
	ctx.xer.ca = ctx.r11.u32 > 0;
	ctx.r11.s64 = ctx.r11.s64 + -1;
	// subfe r11,r11,r11
	temp.u8 = (~ctx.r11.u32 + ctx.r11.u32 < ~ctx.r11.u32) | (~ctx.r11.u32 + ctx.r11.u32 + ctx.xer.ca < ctx.xer.ca);
	ctx.r11.u64 = ~ctx.r11.u64 + ctx.r11.u64 + ctx.xer.ca;
	ctx.xer.ca = temp.u8;
	// and r6,r11,r31
	ctx.r6.u64 = ctx.r11.u64 & ctx.r31.u64;
	// bl 0x8b0df6c8
	ctx.lr = 0x8B0DCA10;
	__imp__NtWriteFile(ctx, base);
	// lis r11,-16384
	ctx.r11.s64 = -1073741824;
	// rlwinm r10,r3,0,0,1
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r3.u32 | (ctx.r3.u64 << 32), 0) & 0xC0000000;
	// cmplw cr6,r10,r11
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, ctx.r11.u32, ctx.xer);
	// beq cr6,0x8b0dcaac
	if (ctx.cr6.eq) goto loc_8B0DCAAC;
	// cmpwi cr6,r3,259
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 259, ctx.xer);
	// beq cr6,0x8b0dcaac
	if (ctx.cr6.eq) goto loc_8B0DCAAC;
	// cmplwi cr6,r29,0
	ctx.cr6.compare<uint32_t>(ctx.r29.u32, 0, ctx.xer);
	// beq cr6,0x8b0dca38
	if (ctx.cr6.eq) goto loc_8B0DCA38;
	// lwz r11,4(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 4);
	// stw r11,0(r29)
	REX_STORE_U32(ctx.r29.u32 + 0, ctx.r11.u32);
loc_8B0DCA38:
	// li r3,1
	ctx.r3.s64 = 1;
	// b 0x8b0dcab4
	goto loc_8B0DCAB4;
loc_8B0DCA40:
	// li r10,0
	ctx.r10.s64 = 0;
	// addi r7,r1,80
	ctx.r7.s64 = ctx.r1.s64 + 80;
	// li r6,0
	ctx.r6.s64 = 0;
	// li r4,0
	ctx.r4.s64 = 0;
	// bl 0x8b0df6c8
	ctx.lr = 0x8B0DCA54;
	__imp__NtWriteFile(ctx, base);
	// cmpwi cr6,r3,259
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 259, ctx.xer);
	// bne cr6,0x8b0dca7c
	if (!ctx.cr6.eq) goto loc_8B0DCA7C;
	// li r6,0
	ctx.r6.s64 = 0;
	// li r5,0
	ctx.r5.s64 = 0;
	// li r4,1
	ctx.r4.s64 = 1;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// bl 0x8b0df6b8
	ctx.lr = 0x8B0DCA70;
	__imp__NtWaitForSingleObjectEx(ctx, base);
	// cmpwi r3,0
	ctx.cr0.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// blt 0x8b0dca94
	if (ctx.cr0.lt) goto loc_8B0DCA94;
	// lwz r3,80(r1)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r1.u32 + 80);
loc_8B0DCA7C:
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// blt cr6,0x8b0dca94
	if (ctx.cr6.lt) goto loc_8B0DCA94;
	// lwz r11,84(r1)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r1.u32 + 84);
	// li r3,1
	ctx.r3.s64 = 1;
	// stw r11,0(r29)
	REX_STORE_U32(ctx.r29.u32 + 0, ctx.r11.u32);
	// b 0x8b0dcab4
	goto loc_8B0DCAB4;
loc_8B0DCA94:
	// rlwinm r11,r3,0,0,1
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r3.u32 | (ctx.r3.u64 << 32), 0) & 0xC0000000;
	// lis r10,-32768
	ctx.r10.s64 = -2147483648;
	// cmplw cr6,r11,r10
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, ctx.r10.u32, ctx.xer);
	// bne cr6,0x8b0dcaac
	if (!ctx.cr6.eq) goto loc_8B0DCAAC;
	// lwz r11,84(r1)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r1.u32 + 84);
	// stw r11,0(r29)
	REX_STORE_U32(ctx.r29.u32 + 0, ctx.r11.u32);
loc_8B0DCAAC:
	// bl 0x8b095618
	ctx.lr = 0x8B0DCAB0;
	sub_8B095618(ctx, base);
	// li r3,0
	ctx.r3.s64 = 0;
loc_8B0DCAB4:
	// addi r1,r1,128
	ctx.r1.s64 = ctx.r1.s64 + 128;
	// b 0x8b0cba0c
	__restgprlr_29(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0DCDB8) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb998
	ctx.lr = 0x8B0DCDC0;
	__savegprlr_20(ctx, base);
	// stwu r1,-192(r1)
	ea = -192 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// mr r24,r3
	ctx.r24.u64 = ctx.r3.u64;
	// li r3,0
	ctx.r3.s64 = 0;
	// mr r10,r24
	ctx.r10.u64 = ctx.r24.u64;
	// cmpwi cr6,r4,-1
	ctx.cr6.compare<int32_t>(ctx.r4.s32, -1, ctx.xer);
	// bne cr6,0x8b0dcdfc
	if (!ctx.cr6.eq) goto loc_8B0DCDFC;
	// mr r11,r24
	ctx.r11.u64 = ctx.r24.u64;
loc_8B0DCDDC:
	// lbz r9,0(r11)
	ctx.r9.u64 = REX_LOAD_U8(ctx.r11.u32 + 0);
	// addi r11,r11,1
	ctx.r11.s64 = ctx.r11.s64 + 1;
	// cmplwi cr6,r9,0
	ctx.cr6.compare<uint32_t>(ctx.r9.u32, 0, ctx.xer);
	// bne cr6,0x8b0dcddc
	if (!ctx.cr6.eq) goto loc_8B0DCDDC;
	// subf r11,r24,r11
	ctx.r11.u64 = ctx.r11.u64 - ctx.r24.u64;
	// addi r11,r11,-1
	ctx.r11.s64 = ctx.r11.s64 + -1;
	// rotlwi r11,r11,0
	ctx.r11.u64 = __builtin_rotateleft32(ctx.r11.u32, 0);
	// addi r4,r11,1
	ctx.r4.s64 = ctx.r11.s64 + 1;
loc_8B0DCDFC:
	// cmpwi cr6,r4,0
	ctx.cr6.compare<int32_t>(ctx.r4.s32, 0, ctx.xer);
	// ble cr6,0x8b0dcf94
	if (!ctx.cr6.gt) goto loc_8B0DCF94;
	// lis r9,-29938
	ctx.r9.s64 = -1962016768;
	// lis r11,-29938
	ctx.r11.s64 = -1962016768;
	// li r31,0
	ctx.r31.s64 = 0;
	// addi r5,r5,-2
	ctx.r5.s64 = ctx.r5.s64 + -2;
	// lis r29,-29938
	ctx.r29.s64 = -1962016768;
	// lis r28,-29938
	ctx.r28.s64 = -1962016768;
	// lis r27,-29938
	ctx.r27.s64 = -1962016768;
	// lis r26,-29938
	ctx.r26.s64 = -1962016768;
	// lis r25,-29938
	ctx.r25.s64 = -1962016768;
	// lis r21,-29938
	ctx.r21.s64 = -1962016768;
	// lis r20,-29938
	ctx.r20.s64 = -1962016768;
	// lis r22,-29938
	ctx.r22.s64 = -1962016768;
	// addi r23,r9,16008
	ctx.r23.s64 = ctx.r9.s64 + 16008;
	// addi r30,r11,16032
	ctx.r30.s64 = ctx.r11.s64 + 16032;
loc_8B0DCE3C:
	// lbz r8,0(r10)
	ctx.r8.u64 = REX_LOAD_U8(ctx.r10.u32 + 0);
	// li r11,0
	ctx.r11.s64 = 0;
	// lbzx r9,r8,r30
	ctx.r9.u64 = REX_LOAD_U8(ctx.r8.u32 + ctx.r30.u32);
	// extsb r9,r9
	ctx.r9.s64 = ctx.r9.s8;
	// clrlwi r9,r9,16
	ctx.r9.u64 = ctx.r9.u32 & 0xFFFF;
	// subf r7,r24,r9
	ctx.r7.u64 = ctx.r9.u64 - ctx.r24.u64;
	// add r7,r7,r10
	ctx.r7.u64 = ctx.r7.u64 + ctx.r10.u64;
	// cmpw cr6,r7,r4
	ctx.cr6.compare<int32_t>(ctx.r7.s32, ctx.r4.s32, ctx.xer);
	// bgt cr6,0x8b0dcf94
	if (ctx.cr6.gt) goto loc_8B0DCF94;
	// cmplwi cr6,r9,1
	ctx.cr6.compare<uint32_t>(ctx.r9.u32, 1, ctx.xer);
	// blt cr6,0x8b0dcee0
	if (ctx.cr6.lt) goto loc_8B0DCEE0;
	// beq cr6,0x8b0dcecc
	if (ctx.cr6.eq) goto loc_8B0DCECC;
	// cmplwi cr6,r9,3
	ctx.cr6.compare<uint32_t>(ctx.r9.u32, 3, ctx.xer);
	// blt cr6,0x8b0dceb8
	if (ctx.cr6.lt) goto loc_8B0DCEB8;
	// beq cr6,0x8b0dcea4
	if (ctx.cr6.eq) goto loc_8B0DCEA4;
	// cmplwi cr6,r9,5
	ctx.cr6.compare<uint32_t>(ctx.r9.u32, 5, ctx.xer);
	// blt cr6,0x8b0dce90
	if (ctx.cr6.lt) goto loc_8B0DCE90;
	// bne cr6,0x8b0dcef0
	if (!ctx.cr6.eq) goto loc_8B0DCEF0;
	// addi r10,r10,1
	ctx.r10.s64 = ctx.r10.s64 + 1;
	// addi r31,r31,1
	ctx.r31.s64 = ctx.r31.s64 + 1;
	// rlwinm r11,r8,6,0,25
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r8.u32 | (ctx.r8.u64 << 32), 6) & 0xFFFFFFC0;
loc_8B0DCE90:
	// lbz r8,0(r10)
	ctx.r8.u64 = REX_LOAD_U8(ctx.r10.u32 + 0);
	// addi r10,r10,1
	ctx.r10.s64 = ctx.r10.s64 + 1;
	// addi r31,r31,1
	ctx.r31.s64 = ctx.r31.s64 + 1;
	// add r11,r8,r11
	ctx.r11.u64 = ctx.r8.u64 + ctx.r11.u64;
	// rlwinm r11,r11,6,0,25
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 6) & 0xFFFFFFC0;
loc_8B0DCEA4:
	// lbz r8,0(r10)
	ctx.r8.u64 = REX_LOAD_U8(ctx.r10.u32 + 0);
	// addi r10,r10,1
	ctx.r10.s64 = ctx.r10.s64 + 1;
	// addi r31,r31,1
	ctx.r31.s64 = ctx.r31.s64 + 1;
	// add r11,r8,r11
	ctx.r11.u64 = ctx.r8.u64 + ctx.r11.u64;
	// rlwinm r11,r11,6,0,25
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 6) & 0xFFFFFFC0;
loc_8B0DCEB8:
	// lbz r8,0(r10)
	ctx.r8.u64 = REX_LOAD_U8(ctx.r10.u32 + 0);
	// addi r10,r10,1
	ctx.r10.s64 = ctx.r10.s64 + 1;
	// addi r31,r31,1
	ctx.r31.s64 = ctx.r31.s64 + 1;
	// add r11,r8,r11
	ctx.r11.u64 = ctx.r8.u64 + ctx.r11.u64;
	// rlwinm r11,r11,6,0,25
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 6) & 0xFFFFFFC0;
loc_8B0DCECC:
	// lbz r8,0(r10)
	ctx.r8.u64 = REX_LOAD_U8(ctx.r10.u32 + 0);
	// addi r10,r10,1
	ctx.r10.s64 = ctx.r10.s64 + 1;
	// addi r31,r31,1
	ctx.r31.s64 = ctx.r31.s64 + 1;
	// add r11,r8,r11
	ctx.r11.u64 = ctx.r8.u64 + ctx.r11.u64;
	// rlwinm r11,r11,6,0,25
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 6) & 0xFFFFFFC0;
loc_8B0DCEE0:
	// lbz r8,0(r10)
	ctx.r8.u64 = REX_LOAD_U8(ctx.r10.u32 + 0);
	// addi r10,r10,1
	ctx.r10.s64 = ctx.r10.s64 + 1;
	// addi r31,r31,1
	ctx.r31.s64 = ctx.r31.s64 + 1;
	// add r11,r8,r11
	ctx.r11.u64 = ctx.r8.u64 + ctx.r11.u64;
loc_8B0DCEF0:
	// rlwinm r9,r9,2,0,29
	ctx.r9.u64 = __builtin_rotateleft64(ctx.r9.u32 | (ctx.r9.u64 << 32), 2) & 0xFFFFFFFC;
	// lwz r8,15980(r22)
	ctx.r8.u64 = REX_LOAD_U32(ctx.r22.u32 + 15980);
	// lwzx r9,r9,r23
	ctx.r9.u64 = REX_LOAD_U32(ctx.r9.u32 + ctx.r23.u32);
	// subf r11,r9,r11
	ctx.r11.u64 = ctx.r11.u64 - ctx.r9.u64;
	// cmplw cr6,r11,r8
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, ctx.r8.u32, ctx.xer);
	// bgt cr6,0x8b0dcf18
	if (ctx.cr6.gt) goto loc_8B0DCF18;
	// addi r3,r3,1
	ctx.r3.s64 = ctx.r3.s64 + 1;
	// cmpw cr6,r3,r6
	ctx.cr6.compare<int32_t>(ctx.r3.s32, ctx.r6.s32, ctx.xer);
	// bgt cr6,0x8b0dcf8c
	if (ctx.cr6.gt) goto loc_8B0DCF8C;
	// b 0x8b0dcf34
	goto loc_8B0DCF34;
loc_8B0DCF18:
	// lwz r9,15984(r20)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r20.u32 + 15984);
	// cmplw cr6,r11,r9
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, ctx.r9.u32, ctx.xer);
	// ble cr6,0x8b0dcf40
	if (!ctx.cr6.gt) goto loc_8B0DCF40;
	// addi r3,r3,1
	ctx.r3.s64 = ctx.r3.s64 + 1;
	// cmpw cr6,r3,r6
	ctx.cr6.compare<int32_t>(ctx.r3.s32, ctx.r6.s32, ctx.xer);
	// bgt cr6,0x8b0dcf8c
	if (ctx.cr6.gt) goto loc_8B0DCF8C;
	// lwz r11,15976(r21)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r21.u32 + 15976);
loc_8B0DCF34:
	// sth r11,2(r5)
	REX_STORE_U16(ctx.r5.u32 + 2, ctx.r11.u16);
	// addi r5,r5,2
	ctx.r5.s64 = ctx.r5.s64 + 2;
	// b 0x8b0dcf8c
	goto loc_8B0DCF8C;
loc_8B0DCF40:
	// lwz r9,15992(r25)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r25.u32 + 15992);
	// addi r7,r3,1
	ctx.r7.s64 = ctx.r3.s64 + 1;
	// subf r11,r9,r11
	ctx.r11.u64 = ctx.r11.u64 - ctx.r9.u64;
	// cmpw cr6,r7,r6
	ctx.cr6.compare<int32_t>(ctx.r7.s32, ctx.r6.s32, ctx.xer);
	// bgt cr6,0x8b0dcf6c
	if (ctx.cr6.gt) goto loc_8B0DCF6C;
	// lwz r9,15988(r26)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r26.u32 + 15988);
	// lwz r8,16000(r27)
	ctx.r8.u64 = REX_LOAD_U32(ctx.r27.u32 + 16000);
	// srw r9,r11,r9
	ctx.r9.u64 = ctx.r9.u8 & 0x20 ? 0 : (ctx.r11.u32 >> (ctx.r9.u8 & 0x3F));
	// add r9,r9,r8
	ctx.r9.u64 = ctx.r9.u64 + ctx.r8.u64;
	// sth r9,2(r5)
	REX_STORE_U16(ctx.r5.u32 + 2, ctx.r9.u16);
	// addi r5,r5,2
	ctx.r5.s64 = ctx.r5.s64 + 2;
loc_8B0DCF6C:
	// addi r3,r7,1
	ctx.r3.s64 = ctx.r7.s64 + 1;
	// cmpw cr6,r3,r6
	ctx.cr6.compare<int32_t>(ctx.r3.s32, ctx.r6.s32, ctx.xer);
	// bgt cr6,0x8b0dcf8c
	if (ctx.cr6.gt) goto loc_8B0DCF8C;
	// lwz r9,15996(r28)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r28.u32 + 15996);
	// lwz r8,16004(r29)
	ctx.r8.u64 = REX_LOAD_U32(ctx.r29.u32 + 16004);
	// and r11,r9,r11
	ctx.r11.u64 = ctx.r9.u64 & ctx.r11.u64;
	// add r11,r11,r8
	ctx.r11.u64 = ctx.r11.u64 + ctx.r8.u64;
	// sthu r11,2(r5)
	ea = 2 + ctx.r5.u32;
	REX_STORE_U16(ea, ctx.r11.u16);
	ctx.r5.u32 = ea;
loc_8B0DCF8C:
	// cmpw cr6,r31,r4
	ctx.cr6.compare<int32_t>(ctx.r31.s32, ctx.r4.s32, ctx.xer);
	// blt cr6,0x8b0dce3c
	if (ctx.cr6.lt) goto loc_8B0DCE3C;
loc_8B0DCF94:
	// cmpwi cr6,r6,0
	ctx.cr6.compare<int32_t>(ctx.r6.s32, 0, ctx.xer);
	// beq cr6,0x8b0dcfb0
	if (ctx.cr6.eq) goto loc_8B0DCFB0;
	// cmpw cr6,r6,r3
	ctx.cr6.compare<int32_t>(ctx.r6.s32, ctx.r3.s32, ctx.xer);
	// bge cr6,0x8b0dcfb0
	if (!ctx.cr6.lt) goto loc_8B0DCFB0;
	// li r3,122
	ctx.r3.s64 = 122;
	// bl 0x8b096358
	ctx.lr = 0x8B0DCFAC;
	sub_8B096358(ctx, base);
	// li r3,0
	ctx.r3.s64 = 0;
loc_8B0DCFB0:
	// addi r1,r1,192
	ctx.r1.s64 = ctx.r1.s64 + 192;
	// b 0x8b0cb9e8
	__restgprlr_20(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0DD5A8) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// stwu r1,-96(r1)
	ea = -96 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// lis r9,-29944
	ctx.r9.s64 = -1962409984;
	// lis r8,-29938
	ctx.r8.s64 = -1962016768;
	// addi r7,r11,10860
	ctx.r7.s64 = ctx.r11.s64 + 10860;
	// addi r5,r10,10852
	ctx.r5.s64 = ctx.r10.s64 + 10852;
	// addi r4,r9,10824
	ctx.r4.s64 = ctx.r9.s64 + 10824;
	// addi r3,r8,17640
	ctx.r3.s64 = ctx.r8.s64 + 17640;
	// li r6,0
	ctx.r6.s64 = 0;
	// bl 0x8b0c6b30
	ctx.lr = 0x8B0DD5DC;
	sub_8B0C6B30(ctx, base);
	// lis r7,-29938
	ctx.r7.s64 = -1962016768;
	// addi r3,r7,-5712
	ctx.r3.s64 = ctx.r7.s64 + -5712;
	// bl 0x8b0cc3d0
	ctx.lr = 0x8B0DD5E8;
	sub_8B0CC3D0(ctx, base);
	// addi r1,r1,96
	ctx.r1.s64 = ctx.r1.s64 + 96;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0DD728) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// stwu r1,-96(r1)
	ea = -96 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// lis r9,-29938
	ctx.r9.s64 = -1962016768;
	// addi r5,r11,10992
	ctx.r5.s64 = ctx.r11.s64 + 10992;
	// addi r4,r10,10976
	ctx.r4.s64 = ctx.r10.s64 + 10976;
	// addi r3,r9,17964
	ctx.r3.s64 = ctx.r9.s64 + 17964;
	// li r6,0
	ctx.r6.s64 = 0;
	// bl 0x8b0c6aa8
	ctx.lr = 0x8B0DD754;
	sub_8B0C6AA8(ctx, base);
	// lis r8,-29938
	ctx.r8.s64 = -1962016768;
	// addi r3,r8,-5632
	ctx.r3.s64 = ctx.r8.s64 + -5632;
	// bl 0x8b0cc3d0
	ctx.lr = 0x8B0DD760;
	sub_8B0CC3D0(ctx, base);
	// addi r1,r1,96
	ctx.r1.s64 = ctx.r1.s64 + 96;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0DD900) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// stwu r1,-96(r1)
	ea = -96 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lis r8,-29938
	ctx.r8.s64 = -1962016768;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lis r10,-29942
	ctx.r10.s64 = -1962278912;
	// lis r9,-29944
	ctx.r9.s64 = -1962409984;
	// addi r3,r8,18744
	ctx.r3.s64 = ctx.r8.s64 + 18744;
	// addi r6,r11,15552
	ctx.r6.s64 = ctx.r11.s64 + 15552;
	// addi r4,r9,15524
	ctx.r4.s64 = ctx.r9.s64 + 15524;
	// li r8,0
	ctx.r8.s64 = 0;
	// li r7,16384
	ctx.r7.s64 = 16384;
	// addi r5,r10,-12688
	ctx.r5.s64 = ctx.r10.s64 + -12688;
	// bl 0x8b0c5fb8
	ctx.lr = 0x8B0DD938;
	sub_8B0C5FB8(ctx, base);
	// lis r7,-29938
	ctx.r7.s64 = -1962016768;
	// addi r3,r7,-5264
	ctx.r3.s64 = ctx.r7.s64 + -5264;
	// bl 0x8b0cc3d0
	ctx.lr = 0x8B0DD944;
	sub_8B0CC3D0(ctx, base);
	// addi r1,r1,96
	ctx.r1.s64 = ctx.r1.s64 + 96;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0DDA48) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// stwu r1,-96(r1)
	ea = -96 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// lis r9,-29938
	ctx.r9.s64 = -1962016768;
	// addi r5,r11,15496
	ctx.r5.s64 = ctx.r11.s64 + 15496;
	// addi r4,r10,19080
	ctx.r4.s64 = ctx.r10.s64 + 19080;
	// addi r3,r9,19188
	ctx.r3.s64 = ctx.r9.s64 + 19188;
	// li r6,2
	ctx.r6.s64 = 2;
	// bl 0x8b0c6aa8
	ctx.lr = 0x8B0DDA74;
	sub_8B0C6AA8(ctx, base);
	// lis r8,-29938
	ctx.r8.s64 = -1962016768;
	// addi r3,r8,-5048
	ctx.r3.s64 = ctx.r8.s64 + -5048;
	// bl 0x8b0cc3d0
	ctx.lr = 0x8B0DDA80;
	sub_8B0CC3D0(ctx, base);
	// addi r1,r1,96
	ctx.r1.s64 = ctx.r1.s64 + 96;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0DDBE0) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// stwu r1,-96(r1)
	ea = -96 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// lis r9,-29944
	ctx.r9.s64 = -1962409984;
	// lis r8,-29938
	ctx.r8.s64 = -1962016768;
	// addi r7,r11,25392
	ctx.r7.s64 = ctx.r11.s64 + 25392;
	// addi r5,r10,25384
	ctx.r5.s64 = ctx.r10.s64 + 25384;
	// addi r4,r9,25352
	ctx.r4.s64 = ctx.r9.s64 + 25352;
	// addi r3,r8,19976
	ctx.r3.s64 = ctx.r8.s64 + 19976;
	// li r6,2
	ctx.r6.s64 = 2;
	// bl 0x8b0c6b30
	ctx.lr = 0x8B0DDC14;
	sub_8B0C6B30(ctx, base);
	// lis r7,-29938
	ctx.r7.s64 = -1962016768;
	// addi r3,r7,-4744
	ctx.r3.s64 = ctx.r7.s64 + -4744;
	// bl 0x8b0cc3d0
	ctx.lr = 0x8B0DDC20;
	sub_8B0CC3D0(ctx, base);
	// addi r1,r1,96
	ctx.r1.s64 = ctx.r1.s64 + 96;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0DDD98) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// stwu r1,-96(r1)
	ea = -96 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// lis r9,-29944
	ctx.r9.s64 = -1962409984;
	// lis r8,-29938
	ctx.r8.s64 = -1962016768;
	// addi r7,r11,25908
	ctx.r7.s64 = ctx.r11.s64 + 25908;
	// addi r5,r10,25904
	ctx.r5.s64 = ctx.r10.s64 + 25904;
	// addi r4,r9,25868
	ctx.r4.s64 = ctx.r9.s64 + 25868;
	// addi r3,r8,20580
	ctx.r3.s64 = ctx.r8.s64 + 20580;
	// li r6,2
	ctx.r6.s64 = 2;
	// bl 0x8b0c6b30
	ctx.lr = 0x8B0DDDCC;
	sub_8B0C6B30(ctx, base);
	// lis r7,-29938
	ctx.r7.s64 = -1962016768;
	// addi r3,r7,-4648
	ctx.r3.s64 = ctx.r7.s64 + -4648;
	// bl 0x8b0cc3d0
	ctx.lr = 0x8B0DDDD8;
	sub_8B0CC3D0(ctx, base);
	// addi r1,r1,96
	ctx.r1.s64 = ctx.r1.s64 + 96;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0DDF28) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// stwu r1,-96(r1)
	ea = -96 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// lis r9,-29944
	ctx.r9.s64 = -1962409984;
	// lis r8,-29938
	ctx.r8.s64 = -1962016768;
	// addi r7,r11,26272
	ctx.r7.s64 = ctx.r11.s64 + 26272;
	// addi r5,r10,26264
	ctx.r5.s64 = ctx.r10.s64 + 26264;
	// addi r4,r9,26232
	ctx.r4.s64 = ctx.r9.s64 + 26232;
	// addi r3,r8,20292
	ctx.r3.s64 = ctx.r8.s64 + 20292;
	// li r6,2
	ctx.r6.s64 = 2;
	// bl 0x8b0c6b30
	ctx.lr = 0x8B0DDF5C;
	sub_8B0C6B30(ctx, base);
	// lis r7,-29938
	ctx.r7.s64 = -1962016768;
	// addi r3,r7,-4568
	ctx.r3.s64 = ctx.r7.s64 + -4568;
	// bl 0x8b0cc3d0
	ctx.lr = 0x8B0DDF68;
	sub_8B0CC3D0(ctx, base);
	// addi r1,r1,96
	ctx.r1.s64 = ctx.r1.s64 + 96;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0DE0A0) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// stwu r1,-96(r1)
	ea = -96 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// lis r9,-29944
	ctx.r9.s64 = -1962409984;
	// lis r8,-29938
	ctx.r8.s64 = -1962016768;
	// addi r7,r11,31444
	ctx.r7.s64 = ctx.r11.s64 + 31444;
	// addi r5,r10,31440
	ctx.r5.s64 = ctx.r10.s64 + 31440;
	// addi r4,r9,31412
	ctx.r4.s64 = ctx.r9.s64 + 31412;
	// addi r3,r8,21028
	ctx.r3.s64 = ctx.r8.s64 + 21028;
	// li r6,2
	ctx.r6.s64 = 2;
	// bl 0x8b0c6b30
	ctx.lr = 0x8B0DE0D4;
	sub_8B0C6B30(ctx, base);
	// lis r7,-29938
	ctx.r7.s64 = -1962016768;
	// addi r3,r7,-4368
	ctx.r3.s64 = ctx.r7.s64 + -4368;
	// bl 0x8b0cc3d0
	ctx.lr = 0x8B0DE0E0;
	sub_8B0CC3D0(ctx, base);
	// addi r1,r1,96
	ctx.r1.s64 = ctx.r1.s64 + 96;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0DE230) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// stwu r1,-96(r1)
	ea = -96 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// lis r9,-29944
	ctx.r9.s64 = -1962409984;
	// lis r8,-29938
	ctx.r8.s64 = -1962016768;
	// addi r7,r11,31792
	ctx.r7.s64 = ctx.r11.s64 + 31792;
	// addi r5,r10,15496
	ctx.r5.s64 = ctx.r10.s64 + 15496;
	// addi r4,r9,31756
	ctx.r4.s64 = ctx.r9.s64 + 31756;
	// addi r3,r8,21100
	ctx.r3.s64 = ctx.r8.s64 + 21100;
	// li r6,2
	ctx.r6.s64 = 2;
	// bl 0x8b0c6b30
	ctx.lr = 0x8B0DE264;
	sub_8B0C6B30(ctx, base);
	// lis r7,-29938
	ctx.r7.s64 = -1962016768;
	// addi r3,r7,-4288
	ctx.r3.s64 = ctx.r7.s64 + -4288;
	// bl 0x8b0cc3d0
	ctx.lr = 0x8B0DE270;
	sub_8B0CC3D0(ctx, base);
	// addi r1,r1,96
	ctx.r1.s64 = ctx.r1.s64 + 96;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0DE3F0) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// stwu r1,-96(r1)
	ea = -96 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lis r11,-29943
	ctx.r11.s64 = -1962344448;
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// lis r9,-29943
	ctx.r9.s64 = -1962344448;
	// lis r8,-29938
	ctx.r8.s64 = -1962016768;
	// addi r7,r11,-30752
	ctx.r7.s64 = ctx.r11.s64 + -30752;
	// addi r5,r10,4620
	ctx.r5.s64 = ctx.r10.s64 + 4620;
	// addi r4,r9,-30772
	ctx.r4.s64 = ctx.r9.s64 + -30772;
	// addi r3,r8,22360
	ctx.r3.s64 = ctx.r8.s64 + 22360;
	// li r6,2
	ctx.r6.s64 = 2;
	// bl 0x8b0c6b30
	ctx.lr = 0x8B0DE424;
	sub_8B0C6B30(ctx, base);
	// lis r7,-29938
	ctx.r7.s64 = -1962016768;
	// addi r3,r7,-4032
	ctx.r3.s64 = ctx.r7.s64 + -4032;
	// bl 0x8b0cc3d0
	ctx.lr = 0x8B0DE430;
	sub_8B0CC3D0(ctx, base);
	// addi r1,r1,96
	ctx.r1.s64 = ctx.r1.s64 + 96;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0DE578) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// stwu r1,-96(r1)
	ea = -96 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lis r11,-29943
	ctx.r11.s64 = -1962344448;
	// lis r10,-29943
	ctx.r10.s64 = -1962344448;
	// lis r9,-29938
	ctx.r9.s64 = -1962016768;
	// addi r5,r11,-30344
	ctx.r5.s64 = ctx.r11.s64 + -30344;
	// addi r4,r10,-30372
	ctx.r4.s64 = ctx.r10.s64 + -30372;
	// addi r3,r9,22144
	ctx.r3.s64 = ctx.r9.s64 + 22144;
	// li r6,2
	ctx.r6.s64 = 2;
	// bl 0x8b0c6aa8
	ctx.lr = 0x8B0DE5A4;
	sub_8B0C6AA8(ctx, base);
	// lis r8,-29938
	ctx.r8.s64 = -1962016768;
	// addi r3,r8,-3952
	ctx.r3.s64 = ctx.r8.s64 + -3952;
	// bl 0x8b0cc3d0
	ctx.lr = 0x8B0DE5B0;
	sub_8B0CC3D0(ctx, base);
	// addi r1,r1,96
	ctx.r1.s64 = ctx.r1.s64 + 96;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0DE6D0) {
	REX_FUNC_PROLOGUE();
	// lis r11,-29936
	ctx.r11.s64 = -1961885696;
	// li r10,0
	ctx.r10.s64 = 0;
	// stw r10,-29060(r11)
	REX_STORE_U32(ctx.r11.u32 + -29060, ctx.r10.u32);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0DE6E0) {
	REX_FUNC_PROLOGUE();
	// lis r11,-29938
	ctx.r11.s64 = -1962016768;
	// addi r3,r11,-3872
	ctx.r3.s64 = ctx.r11.s64 + -3872;
	// b 0x8b0cc3d0
	sub_8B0CC3D0(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0DE820) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// std r31,-16(r1)
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.r31.u64);
	// stwu r1,-96(r1)
	ea = -96 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lis r11,-29938
	ctx.r11.s64 = -1962016768;
	// lis r10,-29943
	ctx.r10.s64 = -1962344448;
	// lis r31,-29936
	ctx.r31.s64 = -1961885696;
	// addi r7,r11,9464
	ctx.r7.s64 = ctx.r11.s64 + 9464;
	// addi r3,r31,-24608
	ctx.r3.s64 = ctx.r31.s64 + -24608;
	// addi r5,r10,-28272
	ctx.r5.s64 = ctx.r10.s64 + -28272;
	// li r6,1
	ctx.r6.s64 = 1;
	// li r4,127
	ctx.r4.s64 = 127;
	// bl 0x8b0c7838
	ctx.lr = 0x8B0DE854;
	sub_8B0C7838(ctx, base);
	// lis r11,-29943
	ctx.r11.s64 = -1962344448;
	// addi r11,r11,-25908
	ctx.r11.s64 = ctx.r11.s64 + -25908;
	// stw r11,-24608(r31)
	REX_STORE_U32(ctx.r31.u32 + -24608, ctx.r11.u32);
	// addi r1,r1,96
	ctx.r1.s64 = ctx.r1.s64 + 96;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0DE960) {
	REX_FUNC_PROLOGUE();
	// lis r11,-29938
	ctx.r11.s64 = -1962016768;
	// addi r3,r11,17248
	ctx.r3.s64 = ctx.r11.s64 + 17248;
	// b 0x8b0c6148
	sub_8B0C6148(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0DE980) {
	REX_FUNC_PROLOGUE();
	// lis r11,-29938
	ctx.r11.s64 = -1962016768;
	// addi r3,r11,17712
	ctx.r3.s64 = ctx.r11.s64 + 17712;
	// b 0x8b0c6148
	sub_8B0C6148(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0DE9A0) {
	REX_FUNC_PROLOGUE();
	// lis r11,-29938
	ctx.r11.s64 = -1962016768;
	// addi r3,r11,17568
	ctx.r3.s64 = ctx.r11.s64 + 17568;
	// b 0x8b0c6148
	sub_8B0C6148(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0DE9C0) {
	REX_FUNC_PROLOGUE();
	// lis r11,-29938
	ctx.r11.s64 = -1962016768;
	// addi r3,r11,17492
	ctx.r3.s64 = ctx.r11.s64 + 17492;
	// b 0x8b0c6148
	sub_8B0C6148(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0DE9F0) {
	REX_FUNC_PROLOGUE();
	// lis r11,-29938
	ctx.r11.s64 = -1962016768;
	// addi r3,r11,17784
	ctx.r3.s64 = ctx.r11.s64 + 17784;
	// b 0x8b0c6148
	sub_8B0C6148(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0DEA78) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// std r31,-16(r1)
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.r31.u64);
	// stwu r1,-96(r1)
	ea = -96 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lis r10,-29938
	ctx.r10.s64 = -1962016768;
	// li r11,0
	ctx.r11.s64 = 0;
	// addi r31,r10,18608
	ctx.r31.s64 = ctx.r10.s64 + 18608;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// stw r11,12(r31)
	REX_STORE_U32(ctx.r31.u32 + 12, ctx.r11.u32);
	// bl 0x8b0906a8
	ctx.lr = 0x8B0DEAA0;
	sub_8B0906A8(ctx, base);
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0906a8
	ctx.lr = 0x8B0DEAA8;
	sub_8B0906A8(ctx, base);
	// addi r1,r1,96
	ctx.r1.s64 = ctx.r1.s64 + 96;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0DEBD8) {
	REX_FUNC_PROLOGUE();
	// lis r11,-29938
	ctx.r11.s64 = -1962016768;
	// addi r3,r11,18968
	ctx.r3.s64 = ctx.r11.s64 + 18968;
	// b 0x8b0c6148
	sub_8B0C6148(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0DEC58) {
	REX_FUNC_PROLOGUE();
	// lis r11,-29938
	ctx.r11.s64 = -1962016768;
	// addi r3,r11,19116
	ctx.r3.s64 = ctx.r11.s64 + 19116;
	// b 0x8b0c6148
	sub_8B0C6148(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0DECF8) {
	REX_FUNC_PROLOGUE();
	// lis r11,-29938
	ctx.r11.s64 = -1962016768;
	// addi r3,r11,19456
	ctx.r3.s64 = ctx.r11.s64 + 19456;
	// b 0x8b0a6530
	sub_8B0A6530(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0DED08) {
	REX_FUNC_PROLOGUE();
	// lis r11,-29938
	ctx.r11.s64 = -1962016768;
	// addi r3,r11,19676
	ctx.r3.s64 = ctx.r11.s64 + 19676;
	// b 0x8b0c6148
	sub_8B0C6148(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0DED28) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// std r31,-16(r1)
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.r31.u64);
	// stwu r1,-96(r1)
	ea = -96 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lis r9,-29938
	ctx.r9.s64 = -1962016768;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// addi r31,r9,5544
	ctx.r31.s64 = ctx.r9.s64 + 5544;
	// addi r10,r11,23756
	ctx.r10.s64 = ctx.r11.s64 + 23756;
	// li r11,0
	ctx.r11.s64 = 0;
	// stw r10,5544(r9)
	REX_STORE_U32(ctx.r9.u32 + 5544, ctx.r10.u32);
	// addi r3,r31,4
	ctx.r3.s64 = ctx.r31.s64 + 4;
	// stw r11,16(r31)
	REX_STORE_U32(ctx.r31.u32 + 16, ctx.r11.u32);
	// bl 0x8b0906a8
	ctx.lr = 0x8B0DED5C;
	sub_8B0906A8(ctx, base);
	// addi r3,r31,4
	ctx.r3.s64 = ctx.r31.s64 + 4;
	// bl 0x8b0906a8
	ctx.lr = 0x8B0DED64;
	sub_8B0906A8(ctx, base);
	// addi r1,r1,96
	ctx.r1.s64 = ctx.r1.s64 + 96;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0DEE98) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// std r31,-16(r1)
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.r31.u64);
	// stwu r1,-96(r1)
	ea = -96 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lis r11,-29938
	ctx.r11.s64 = -1962016768;
	// addi r31,r11,6476
	ctx.r31.s64 = ctx.r11.s64 + 6476;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0b3318
	ctx.lr = 0x8B0DEEB8;
	sub_8B0B3318(ctx, base);
	// li r11,-1
	ctx.r11.s64 = -1;
	// addi r3,r31,4
	ctx.r3.s64 = ctx.r31.s64 + 4;
	// sth r11,20(r31)
	REX_STORE_U16(ctx.r31.u32 + 20, ctx.r11.u16);
	// bl 0x8b0906a8
	ctx.lr = 0x8B0DEEC8;
	sub_8B0906A8(ctx, base);
	// li r11,-1
	ctx.r11.s64 = -1;
	// addi r3,r31,4
	ctx.r3.s64 = ctx.r31.s64 + 4;
	// sth r11,22(r31)
	REX_STORE_U16(ctx.r31.u32 + 22, ctx.r11.u16);
	// bl 0x8b0906a8
	ctx.lr = 0x8B0DEED8;
	sub_8B0906A8(ctx, base);
	// addi r1,r1,96
	ctx.r1.s64 = ctx.r1.s64 + 96;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0DF080) {
	REX_FUNC_PROLOGUE();
	// lis r11,-29938
	ctx.r11.s64 = -1962016768;
	// addi r3,r11,22072
	ctx.r3.s64 = ctx.r11.s64 + 22072;
	// b 0x8b0c6148
	sub_8B0C6148(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0DF0B0) {
	REX_FUNC_PROLOGUE();
	// lis r11,-29938
	ctx.r11.s64 = -1962016768;
	// addi r3,r11,22524
	ctx.r3.s64 = ctx.r11.s64 + 22524;
	// b 0x8b0c6148
	sub_8B0C6148(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0DF0F0) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// std r31,-16(r1)
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.r31.u64);
	// stwu r1,-96(r1)
	ea = -96 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lis r10,-29938
	ctx.r10.s64 = -1962016768;
	// lis r11,-29943
	ctx.r11.s64 = -1962344448;
	// addi r31,r10,9060
	ctx.r31.s64 = ctx.r10.s64 + 9060;
	// lis r10,-29943
	ctx.r10.s64 = -1962344448;
	// addi r11,r11,-27484
	ctx.r11.s64 = ctx.r11.s64 + -27484;
	// addi r10,r10,-27524
	ctx.r10.s64 = ctx.r10.s64 + -27524;
	// lwz r3,36(r31)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r31.u32 + 36);
	// stw r11,0(r31)
	REX_STORE_U32(ctx.r31.u32 + 0, ctx.r11.u32);
	// stw r10,24(r31)
	REX_STORE_U32(ctx.r31.u32 + 24, ctx.r10.u32);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0df158
	if (ctx.cr6.eq) goto loc_8B0DF158;
	// bl 0x8b090020
	ctx.lr = 0x8B0DF130;
	sub_8B090020(ctx, base);
	// lis r10,-29943
	ctx.r10.s64 = -1962344448;
	// li r11,0
	ctx.r11.s64 = 0;
	// addi r10,r10,-27640
	ctx.r10.s64 = ctx.r10.s64 + -27640;
	// stw r11,36(r31)
	REX_STORE_U32(ctx.r31.u32 + 36, ctx.r11.u32);
	// stw r10,0(r31)
	REX_STORE_U32(ctx.r31.u32 + 0, ctx.r10.u32);
	// addi r1,r1,96
	ctx.r1.s64 = ctx.r1.s64 + 96;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
loc_8B0DF158:
	// lis r11,-29943
	ctx.r11.s64 = -1962344448;
	// addi r11,r11,-27640
	ctx.r11.s64 = ctx.r11.s64 + -27640;
	// stw r11,0(r31)
	REX_STORE_U32(ctx.r31.u32 + 0, ctx.r11.u32);
	// addi r1,r1,96
	ctx.r1.s64 = ctx.r1.s64 + 96;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
}

