#include "l4d2_matchmaking_funcs.3.h"

DEFINE_REX_FUNC(sub_8B090040) {
	REX_FUNC_PROLOGUE();
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// mr r5,r4
	ctx.r5.u64 = ctx.r4.u64;
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// lwz r11,1144(r11)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r11.u32 + 1144);
	// lwz r3,0(r11)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r11.u32 + 0);
	// lwz r10,0(r3)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r9,12(r10)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r10.u32 + 12);
	// mtctr r9
	ctx.ctr.u64 = ctx.r9.u64;
	// bctr 
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	return;
}

DEFINE_REX_FUNC(sub_8B0901F0) {
	REX_FUNC_PROLOGUE();
	// lis r11,-29938
	ctx.r11.s64 = -1962016768;
	// addi r3,r11,16416
	ctx.r3.s64 = ctx.r11.s64 + 16416;
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B090200) {
	REX_FUNC_PROLOGUE();
	// lwz r3,4(r3)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r3.u32 + 4);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// bne cr6,0x8b090210
	if (!ctx.cr6.eq) goto loc_8B090210;
	// blr 
	return;
loc_8B090210:
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// li r5,0
	ctx.r5.s64 = 0;
	// addi r4,r11,1624
	ctx.r4.s64 = ctx.r11.s64 + 1624;
	// b 0x8b0bfa88
	sub_8B0BFA88(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B090288) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9b0
	ctx.lr = 0x8B090290;
	__savegprlr_26(ctx, base);
	// stwu r1,-400(r1)
	ea = -400 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// mr r28,r5
	ctx.r28.u64 = ctx.r5.u64;
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// mr r27,r4
	ctx.r27.u64 = ctx.r4.u64;
	// mr r5,r4
	ctx.r5.u64 = ctx.r4.u64;
	// addi r4,r11,1668
	ctx.r4.s64 = ctx.r11.s64 + 1668;
	// addi r3,r1,80
	ctx.r3.s64 = ctx.r1.s64 + 80;
	// bl 0x8b090220
	ctx.lr = 0x8B0902B4;
	sub_8B090220(ctx, base);
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// li r5,0
	ctx.r5.s64 = 0;
	// lwz r3,4(r31)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r31.u32 + 4);
	// bl 0x8b0bfa88
	ctx.lr = 0x8B0902C4;
	sub_8B0BFA88(ctx, base);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0902f8
	if (ctx.cr6.eq) goto loc_8B0902F8;
	// bl 0x8b0c0298
	ctx.lr = 0x8B0902D0;
	sub_8B0C0298(ctx, base);
	// mr r4,r28
	ctx.r4.u64 = ctx.r28.u64;
	// mr r30,r3
	ctx.r30.u64 = ctx.r3.u64;
	// bl 0x8b0bf328
	ctx.lr = 0x8B0902DC;
	sub_8B0BF328(ctx, base);
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// li r5,0
	ctx.r5.s64 = 0;
	// lwz r3,4(r31)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r31.u32 + 4);
	// addi r4,r11,1656
	ctx.r4.s64 = ctx.r11.s64 + 1656;
	// bl 0x8b0bfa88
	ctx.lr = 0x8B0902F0;
	sub_8B0BFA88(ctx, base);
	// mr r4,r30
	ctx.r4.u64 = ctx.r30.u64;
	// bl 0x8b0bfc00
	ctx.lr = 0x8B0902F8;
	sub_8B0BFC00(ctx, base);
loc_8B0902F8:
	// lwz r11,0(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 0);
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// lwz r10,0(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 0);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B09030C;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b090398
	if (ctx.cr6.eq) goto loc_8B090398;
	// bl 0x8b0bf248
	ctx.lr = 0x8B090318;
	sub_8B0BF248(ctx, base);
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b090398
	if (ctx.cr6.eq) goto loc_8B090398;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// addi r30,r11,1648
	ctx.r30.s64 = ctx.r11.s64 + 1648;
	// addi r29,r10,1636
	ctx.r29.s64 = ctx.r10.s64 + 1636;
loc_8B090334:
	// mr r4,r29
	ctx.r4.u64 = ctx.r29.u64;
	// mr r5,r27
	ctx.r5.u64 = ctx.r27.u64;
	// addi r3,r1,80
	ctx.r3.s64 = ctx.r1.s64 + 80;
	// bl 0x8b090220
	ctx.lr = 0x8B090344;
	sub_8B090220(ctx, base);
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// li r5,0
	ctx.r5.s64 = 0;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0bfa88
	ctx.lr = 0x8B090354;
	sub_8B0BFA88(ctx, base);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b090384
	if (ctx.cr6.eq) goto loc_8B090384;
	// bl 0x8b0c0298
	ctx.lr = 0x8B090360;
	sub_8B0C0298(ctx, base);
	// mr r4,r28
	ctx.r4.u64 = ctx.r28.u64;
	// mr r26,r3
	ctx.r26.u64 = ctx.r3.u64;
	// bl 0x8b0bf328
	ctx.lr = 0x8B09036C;
	sub_8B0BF328(ctx, base);
	// mr r4,r30
	ctx.r4.u64 = ctx.r30.u64;
	// li r5,0
	ctx.r5.s64 = 0;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0bfa88
	ctx.lr = 0x8B09037C;
	sub_8B0BFA88(ctx, base);
	// mr r4,r26
	ctx.r4.u64 = ctx.r26.u64;
	// bl 0x8b0bfc00
	ctx.lr = 0x8B090384;
	sub_8B0BFC00(ctx, base);
loc_8B090384:
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0bf280
	ctx.lr = 0x8B09038C;
	sub_8B0BF280(ctx, base);
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// bne cr6,0x8b090334
	if (!ctx.cr6.eq) goto loc_8B090334;
loc_8B090398:
	// addi r1,r1,400
	ctx.r1.s64 = ctx.r1.s64 + 400;
	// b 0x8b0cba00
	__restgprlr_26(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B090890) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// std r30,-24(r1)
	REX_STORE_U64(ctx.r1.u32 + -24, ctx.r30.u64);
	// std r31,-16(r1)
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.r31.u64);
	// stwu r1,-112(r1)
	ea = -112 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// mr r5,r4
	ctx.r5.u64 = ctx.r4.u64;
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// addi r4,r3,16
	ctx.r4.s64 = ctx.r3.s64 + 16;
	// addi r3,r1,80
	ctx.r3.s64 = ctx.r1.s64 + 80;
	// bl 0x8b0c5a88
	ctx.lr = 0x8B0908B8;
	sub_8B0C5A88(ctx, base);
	// lwz r11,12(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 12);
	// lhz r30,80(r1)
	ctx.r30.u64 = REX_LOAD_U16(ctx.r1.u32 + 80);
	// cmpw cr6,r11,r30
	ctx.cr6.compare<int32_t>(ctx.r11.s32, ctx.r30.s32, ctx.xer);
	// bgt cr6,0x8b0908e8
	if (ctx.cr6.gt) goto loc_8B0908E8;
	// addi r10,r30,1
	ctx.r10.s64 = ctx.r30.s64 + 1;
	// cmpw cr6,r11,r10
	ctx.cr6.compare<int32_t>(ctx.r11.s32, ctx.r10.s32, ctx.xer);
	// bge cr6,0x8b0908e8
	if (!ctx.cr6.lt) goto loc_8B0908E8;
	// rotlwi r4,r11,0
	ctx.r4.u64 = __builtin_rotateleft32(ctx.r11.u32, 0);
	// li r6,0
	ctx.r6.s64 = 0;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// subf r5,r4,r10
	ctx.r5.u64 = ctx.r10.u64 - ctx.r4.u64;
	// bl 0x8b0bcb60
	ctx.lr = 0x8B0908E8;
	sub_8B0BCB60(ctx, base);
loc_8B0908E8:
	// lwz r11,0(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 0);
	// rlwinm r10,r30,2,0,29
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r30.u32 | (ctx.r30.u64 << 32), 2) & 0xFFFFFFFC;
	// add r3,r10,r11
	ctx.r3.u64 = ctx.r10.u64 + ctx.r11.u64;
	// addi r1,r1,112
	ctx.r1.s64 = ctx.r1.s64 + 112;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// ld r30,-24(r1)
	ctx.r30.u64 = REX_LOAD_U64(ctx.r1.u32 + -24);
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0911C0) {
	REX_FUNC_PROLOGUE();
	// lwz r3,88(r3)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r3.u32 + 88);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0911D0) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// std r30,-24(r1)
	REX_STORE_U64(ctx.r1.u32 + -24, ctx.r30.u64);
	// std r31,-16(r1)
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.r31.u64);
	// stwu r1,-112(r1)
	ea = -112 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lis r11,-29938
	ctx.r11.s64 = -1962016768;
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// lwz r11,2364(r11)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r11.u32 + 2364);
	// lwz r30,96(r11)
	ctx.r30.u64 = REX_LOAD_U32(ctx.r11.u32 + 96);
	// cmplwi cr6,r30,0
	ctx.cr6.compare<uint32_t>(ctx.r30.u32, 0, ctx.xer);
	// beq cr6,0x8b09131c
	if (ctx.cr6.eq) goto loc_8B09131C;
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// addi r4,r3,8
	ctx.r4.s64 = ctx.r3.s64 + 8;
	// bne cr6,0x8b09120c
	if (!ctx.cr6.eq) goto loc_8B09120C;
	// li r4,0
	ctx.r4.s64 = 0;
loc_8B09120C:
	// lwz r11,0(r30)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r30.u32 + 0);
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// li r6,0
	ctx.r6.s64 = 0;
	// addi r5,r10,3532
	ctx.r5.s64 = ctx.r10.s64 + 3532;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// lwz r9,12(r11)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r11.u32 + 12);
	// mtctr r9
	ctx.ctr.u64 = ctx.r9.u64;
	// bctrl 
	ctx.lr = 0x8B09122C;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// cmplwi cr6,r31,0
	ctx.cr6.compare<uint32_t>(ctx.r31.u32, 0, ctx.xer);
	// addi r4,r31,8
	ctx.r4.s64 = ctx.r31.s64 + 8;
	// bne cr6,0x8b09123c
	if (!ctx.cr6.eq) goto loc_8B09123C;
	// li r4,0
	ctx.r4.s64 = 0;
loc_8B09123C:
	// lwz r11,0(r30)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r30.u32 + 0);
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// li r6,0
	ctx.r6.s64 = 0;
	// addi r5,r10,3520
	ctx.r5.s64 = ctx.r10.s64 + 3520;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// lwz r9,12(r11)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r11.u32 + 12);
	// mtctr r9
	ctx.ctr.u64 = ctx.r9.u64;
	// bctrl 
	ctx.lr = 0x8B09125C;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// cmplwi cr6,r31,0
	ctx.cr6.compare<uint32_t>(ctx.r31.u32, 0, ctx.xer);
	// addi r4,r31,8
	ctx.r4.s64 = ctx.r31.s64 + 8;
	// bne cr6,0x8b09126c
	if (!ctx.cr6.eq) goto loc_8B09126C;
	// li r4,0
	ctx.r4.s64 = 0;
loc_8B09126C:
	// lwz r11,0(r30)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r30.u32 + 0);
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// li r6,0
	ctx.r6.s64 = 0;
	// addi r5,r10,3504
	ctx.r5.s64 = ctx.r10.s64 + 3504;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// lwz r9,12(r11)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r11.u32 + 12);
	// mtctr r9
	ctx.ctr.u64 = ctx.r9.u64;
	// bctrl 
	ctx.lr = 0x8B09128C;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// cmplwi cr6,r31,0
	ctx.cr6.compare<uint32_t>(ctx.r31.u32, 0, ctx.xer);
	// addi r4,r31,8
	ctx.r4.s64 = ctx.r31.s64 + 8;
	// bne cr6,0x8b09129c
	if (!ctx.cr6.eq) goto loc_8B09129C;
	// li r4,0
	ctx.r4.s64 = 0;
loc_8B09129C:
	// lwz r11,0(r30)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r30.u32 + 0);
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// li r6,0
	ctx.r6.s64 = 0;
	// addi r5,r10,3492
	ctx.r5.s64 = ctx.r10.s64 + 3492;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// lwz r9,12(r11)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r11.u32 + 12);
	// mtctr r9
	ctx.ctr.u64 = ctx.r9.u64;
	// bctrl 
	ctx.lr = 0x8B0912BC;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// cmplwi cr6,r31,0
	ctx.cr6.compare<uint32_t>(ctx.r31.u32, 0, ctx.xer);
	// addi r4,r31,8
	ctx.r4.s64 = ctx.r31.s64 + 8;
	// bne cr6,0x8b0912cc
	if (!ctx.cr6.eq) goto loc_8B0912CC;
	// li r4,0
	ctx.r4.s64 = 0;
loc_8B0912CC:
	// lwz r11,0(r30)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r30.u32 + 0);
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// li r6,0
	ctx.r6.s64 = 0;
	// addi r5,r10,3480
	ctx.r5.s64 = ctx.r10.s64 + 3480;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// lwz r9,12(r11)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r11.u32 + 12);
	// mtctr r9
	ctx.ctr.u64 = ctx.r9.u64;
	// bctrl 
	ctx.lr = 0x8B0912EC;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// cmplwi cr6,r31,0
	ctx.cr6.compare<uint32_t>(ctx.r31.u32, 0, ctx.xer);
	// addi r4,r31,8
	ctx.r4.s64 = ctx.r31.s64 + 8;
	// bne cr6,0x8b0912fc
	if (!ctx.cr6.eq) goto loc_8B0912FC;
	// li r4,0
	ctx.r4.s64 = 0;
loc_8B0912FC:
	// lwz r11,0(r30)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r30.u32 + 0);
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// li r6,0
	ctx.r6.s64 = 0;
	// addi r5,r10,3460
	ctx.r5.s64 = ctx.r10.s64 + 3460;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// lwz r9,12(r11)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r11.u32 + 12);
	// mtctr r9
	ctx.ctr.u64 = ctx.r9.u64;
	// bctrl 
	ctx.lr = 0x8B09131C;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
loc_8B09131C:
	// lis r11,-29938
	ctx.r11.s64 = -1962016768;
	// lwz r3,540(r11)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r11.u32 + 540);
	// bl 0x8b090fb0
	ctx.lr = 0x8B091328;
	sub_8B090FB0(ctx, base);
	// li r3,1
	ctx.r3.s64 = 1;
	// addi r1,r1,112
	ctx.r1.s64 = ctx.r1.s64 + 112;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// ld r30,-24(r1)
	ctx.r30.u64 = REX_LOAD_U64(ctx.r1.u32 + -24);
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B091718) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb99c
	ctx.lr = 0x8B091720;
	__savegprlr_21(ctx, base);
	// stwu r1,-432(r1)
	ea = -432 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// bl 0x8b0df2c8
	ctx.lr = 0x8B091728;
	sub_8B0DF2C8(ctx, base);
	// mr r21,r3
	ctx.r21.u64 = ctx.r3.u64;
	// li r24,0
	ctx.r24.s64 = 0;
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// ble cr6,0x8b091868
	if (!ctx.cr6.gt) goto loc_8B091868;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// lis r9,-29938
	ctx.r9.s64 = -1962016768;
	// lis r8,-29944
	ctx.r8.s64 = -1962409984;
	// lis r7,-29938
	ctx.r7.s64 = -1962016768;
	// li r27,0
	ctx.r27.s64 = 0;
	// lis r30,-29938
	ctx.r30.s64 = -1962016768;
	// lis r22,-29938
	ctx.r22.s64 = -1962016768;
	// addi r23,r11,3660
	ctx.r23.s64 = ctx.r11.s64 + 3660;
	// addi r26,r10,3644
	ctx.r26.s64 = ctx.r10.s64 + 3644;
	// addi r28,r9,16628
	ctx.r28.s64 = ctx.r9.s64 + 16628;
	// addi r25,r8,2776
	ctx.r25.s64 = ctx.r8.s64 + 2776;
	// addi r29,r7,16596
	ctx.r29.s64 = ctx.r7.s64 + 16596;
loc_8B09176C:
	// mr r3,r24
	ctx.r3.u64 = ctx.r24.u64;
	// bl 0x8b0df2b8
	ctx.lr = 0x8B091774;
	sub_8B0DF2B8(ctx, base);
	// lwz r11,2548(r22)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r22.u32 + 2548);
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// mr r3,r11
	ctx.r3.u64 = ctx.r11.u64;
	// lwz r10,0(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 0);
	// lwz r9,4(r10)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r10.u32 + 4);
	// mtctr r9
	ctx.ctr.u64 = ctx.r9.u64;
	// bctrl 
	ctx.lr = 0x8B091790;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b091858
	if (ctx.cr6.eq) goto loc_8B091858;
	// lwz r11,16592(r30)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r30.u32 + 16592);
	// clrlwi r10,r11,31
	ctx.r10.u64 = ctx.r11.u32 & 0x1;
	// cmplwi cr6,r10,0
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 0, ctx.xer);
	// bne cr6,0x8b0917c0
	if (!ctx.cr6.eq) goto loc_8B0917C0;
	// ori r11,r11,1
	ctx.r11.u64 = ctx.r11.u64 | 1;
	// mr r4,r25
	ctx.r4.u64 = ctx.r25.u64;
	// stw r11,16592(r30)
	REX_STORE_U32(ctx.r30.u32 + 16592, ctx.r11.u32);
	// mr r3,r29
	ctx.r3.u64 = ctx.r29.u64;
	// bl 0x8b0c6fc0
	ctx.lr = 0x8B0917C0;
	sub_8B0C6FC0(ctx, base);
loc_8B0917C0:
	// lwz r11,0(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 0);
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// lwz r10,8(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 8);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B0917D4;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// lwzx r9,r27,r29
	ctx.r9.u64 = REX_LOAD_U32(ctx.r27.u32 + ctx.r29.u32);
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// mr r3,r9
	ctx.r3.u64 = ctx.r9.u64;
	// lwz r8,0(r9)
	ctx.r8.u64 = REX_LOAD_U32(ctx.r9.u32 + 0);
	// lwz r7,12(r8)
	ctx.r7.u64 = REX_LOAD_U32(ctx.r8.u32 + 12);
	// mtctr r7
	ctx.ctr.u64 = ctx.r7.u64;
	// bctrl 
	ctx.lr = 0x8B0917F0;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// lwz r11,16592(r30)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r30.u32 + 16592);
	// rlwinm r6,r11,0,30,30
	ctx.r6.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 0) & 0x2;
	// cmplwi cr6,r6,0
	ctx.cr6.compare<uint32_t>(ctx.r6.u32, 0, ctx.xer);
	// bne cr6,0x8b091814
	if (!ctx.cr6.eq) goto loc_8B091814;
	// ori r11,r11,2
	ctx.r11.u64 = ctx.r11.u64 | 2;
	// mr r4,r26
	ctx.r4.u64 = ctx.r26.u64;
	// stw r11,16592(r30)
	REX_STORE_U32(ctx.r30.u32 + 16592, ctx.r11.u32);
	// mr r3,r28
	ctx.r3.u64 = ctx.r28.u64;
	// bl 0x8b0c6fc0
	ctx.lr = 0x8B091814;
	sub_8B0C6FC0(ctx, base);
loc_8B091814:
	// lwz r11,0(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 0);
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// lwz r10,0(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 0);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B091828;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// rotlwi r6,r3,0
	ctx.r6.u64 = __builtin_rotateleft32(ctx.r3.u32, 0);
	// rldicl r5,r3,32,32
	ctx.r5.u64 = __builtin_rotateleft64(ctx.r3.u64, 32) & 0xFFFFFFFF;
	// mr r4,r23
	ctx.r4.u64 = ctx.r23.u64;
	// addi r3,r1,80
	ctx.r3.s64 = ctx.r1.s64 + 80;
	// bl 0x8b090220
	ctx.lr = 0x8B09183C;
	sub_8B090220(ctx, base);
	// lwzx r9,r27,r28
	ctx.r9.u64 = REX_LOAD_U32(ctx.r27.u32 + ctx.r28.u32);
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// mr r3,r9
	ctx.r3.u64 = ctx.r9.u64;
	// lwz r8,0(r9)
	ctx.r8.u64 = REX_LOAD_U32(ctx.r9.u32 + 0);
	// lwz r7,12(r8)
	ctx.r7.u64 = REX_LOAD_U32(ctx.r8.u32 + 12);
	// mtctr r7
	ctx.ctr.u64 = ctx.r7.u64;
	// bctrl 
	ctx.lr = 0x8B091858;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
loc_8B091858:
	// addi r24,r24,1
	ctx.r24.s64 = ctx.r24.s64 + 1;
	// addi r27,r27,8
	ctx.r27.s64 = ctx.r27.s64 + 8;
	// cmpw cr6,r24,r21
	ctx.cr6.compare<int32_t>(ctx.r24.s32, ctx.r21.s32, ctx.xer);
	// blt cr6,0x8b09176c
	if (ctx.cr6.lt) goto loc_8B09176C;
loc_8B091868:
	// addi r1,r1,432
	ctx.r1.s64 = ctx.r1.s64 + 432;
	// b 0x8b0cb9ec
	__restgprlr_21(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B092088) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9ac
	ctx.lr = 0x8B092090;
	__savegprlr_25(ctx, base);
	// stwu r1,-160(r1)
	ea = -160 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lis r25,-29936
	ctx.r25.s64 = -1961885696;
	// mr r27,r4
	ctx.r27.u64 = ctx.r4.u64;
	// lwz r3,-17796(r25)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r25.u32 + -17796);
	// lwz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r10,36(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 36);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B0920B0;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0925b4
	if (ctx.cr6.eq) goto loc_8B0925B4;
	// lwz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r10,4(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 4);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B0920CC;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lis r9,-29944
	ctx.r9.s64 = -1962409984;
	// addi r28,r11,1791
	ctx.r28.s64 = ctx.r11.s64 + 1791;
	// addi r4,r9,4588
	ctx.r4.s64 = ctx.r9.s64 + 4588;
	// mr r5,r28
	ctx.r5.u64 = ctx.r28.u64;
	// mr r29,r3
	ctx.r29.u64 = ctx.r3.u64;
	// bl 0x8b0c1588
	ctx.lr = 0x8B0920E8;
	sub_8B0C1588(ctx, base);
	// lis r8,-29944
	ctx.r8.s64 = -1962409984;
	// mr r30,r3
	ctx.r30.u64 = ctx.r3.u64;
	// mr r5,r28
	ctx.r5.u64 = ctx.r28.u64;
	// addi r4,r8,4576
	ctx.r4.s64 = ctx.r8.s64 + 4576;
	// mr r3,r29
	ctx.r3.u64 = ctx.r29.u64;
	// bl 0x8b0c1588
	ctx.lr = 0x8B092100;
	sub_8B0C1588(ctx, base);
	// cmplwi cr6,r30,0
	ctx.cr6.compare<uint32_t>(ctx.r30.u32, 0, ctx.xer);
	// beq cr6,0x8b092114
	if (ctx.cr6.eq) goto loc_8B092114;
	// lbz r11,0(r30)
	ctx.r11.u64 = REX_LOAD_U8(ctx.r30.u32 + 0);
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// bne cr6,0x8b092128
	if (!ctx.cr6.eq) goto loc_8B092128;
loc_8B092114:
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0925b4
	if (ctx.cr6.eq) goto loc_8B0925B4;
	// lbz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U8(ctx.r3.u32 + 0);
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// beq cr6,0x8b0925b4
	if (ctx.cr6.eq) goto loc_8B0925B4;
loc_8B092128:
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// addi r5,r11,2892
	ctx.r5.s64 = ctx.r11.s64 + 2892;
	// addi r4,r10,1764
	ctx.r4.s64 = ctx.r10.s64 + 1764;
	// mr r3,r29
	ctx.r3.u64 = ctx.r29.u64;
	// bl 0x8b0c1588
	ctx.lr = 0x8B092140;
	sub_8B0C1588(ctx, base);
	// lwz r9,0(r31)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r31.u32 + 0);
	// mr r26,r3
	ctx.r26.u64 = ctx.r3.u64;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// lwz r8,0(r9)
	ctx.r8.u64 = REX_LOAD_U32(ctx.r9.u32 + 0);
	// mtctr r8
	ctx.ctr.u64 = ctx.r8.u64;
	// bctrl 
	ctx.lr = 0x8B092158;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// lis r7,-29944
	ctx.r7.s64 = -1962409984;
	// li r5,0
	ctx.r5.s64 = 0;
	// addi r4,r7,4568
	ctx.r4.s64 = ctx.r7.s64 + 4568;
	// bl 0x8b0c1588
	ctx.lr = 0x8B092168;
	sub_8B0C1588(ctx, base);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b092184
	if (ctx.cr6.eq) goto loc_8B092184;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// addi r4,r11,4560
	ctx.r4.s64 = ctx.r11.s64 + 4560;
	// bl 0x8b0cea10
	ctx.lr = 0x8B09217C;
	sub_8B0CEA10(ctx, base);
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// beq cr6,0x8b0925b4
	if (ctx.cr6.eq) goto loc_8B0925B4;
loc_8B092184:
	// lwz r11,0(r27)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r27.u32 + 0);
	// mr r3,r27
	ctx.r3.u64 = ctx.r27.u64;
	// lwz r10,4(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 4);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B092198;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// mr r30,r3
	ctx.r30.u64 = ctx.r3.u64;
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0925b4
	if (ctx.cr6.eq) goto loc_8B0925B4;
	// lbz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U8(ctx.r3.u32 + 0);
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// beq cr6,0x8b0925b4
	if (ctx.cr6.eq) goto loc_8B0925B4;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// addi r3,r11,3492
	ctx.r3.s64 = ctx.r11.s64 + 3492;
	// bl 0x8b0cea10
	ctx.lr = 0x8B0921C0;
	sub_8B0CEA10(ctx, base);
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// bne cr6,0x8b092214
	if (!ctx.cr6.eq) goto loc_8B092214;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// addi r4,r11,4520
	ctx.r4.s64 = ctx.r11.s64 + 4520;
	// addi r3,r10,4056
	ctx.r3.s64 = ctx.r10.s64 + 4056;
	// li r5,0
	ctx.r5.s64 = 0;
	// bl 0x8b0c0c70
	ctx.lr = 0x8B0921E0;
	sub_8B0C0C70(ctx, base);
	// lwz r9,0(r31)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r31.u32 + 0);
	// mr r30,r3
	ctx.r30.u64 = ctx.r3.u64;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// mr r4,r30
	ctx.r4.u64 = ctx.r30.u64;
	// lwz r8,8(r9)
	ctx.r8.u64 = REX_LOAD_U32(ctx.r9.u32 + 8);
	// mtctr r8
	ctx.ctr.u64 = ctx.r8.u64;
	// bctrl 
	ctx.lr = 0x8B0921FC;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// cmplwi cr6,r30,0
	ctx.cr6.compare<uint32_t>(ctx.r30.u32, 0, ctx.xer);
	// beq cr6,0x8b0925b4
	if (ctx.cr6.eq) goto loc_8B0925B4;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// bl 0x8b0c04f0
	ctx.lr = 0x8B09220C;
	sub_8B0C04F0(ctx, base);
	// addi r1,r1,160
	ctx.r1.s64 = ctx.r1.s64 + 160;
	// b 0x8b0cb9fc
	__restgprlr_25(ctx, base);
	return;
loc_8B092214:
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// mr r4,r30
	ctx.r4.u64 = ctx.r30.u64;
	// addi r3,r11,3480
	ctx.r3.s64 = ctx.r11.s64 + 3480;
	// bl 0x8b0cea10
	ctx.lr = 0x8B092224;
	sub_8B0CEA10(ctx, base);
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// bne cr6,0x8b092260
	if (!ctx.cr6.eq) goto loc_8B092260;
	// li r3,36
	ctx.r3.s64 = 36;
	// bl 0x8b0bf448
	ctx.lr = 0x8B092234;
	sub_8B0BF448(ctx, base);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b092588
	if (ctx.cr6.eq) goto loc_8B092588;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// lis r9,-29944
	ctx.r9.s64 = -1962409984;
	// addi r6,r11,4508
	ctx.r6.s64 = ctx.r11.s64 + 4508;
	// addi r5,r10,4500
	ctx.r5.s64 = ctx.r10.s64 + 4500;
	// addi r4,r9,4472
	ctx.r4.s64 = ctx.r9.s64 + 4472;
	// bl 0x8b0c1300
	ctx.lr = 0x8B092258;
	sub_8B0C1300(ctx, base);
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// b 0x8b09258c
	goto loc_8B09258C;
loc_8B092260:
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// mr r4,r30
	ctx.r4.u64 = ctx.r30.u64;
	// addi r3,r11,3504
	ctx.r3.s64 = ctx.r11.s64 + 3504;
	// bl 0x8b0cea10
	ctx.lr = 0x8B092270;
	sub_8B0CEA10(ctx, base);
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// bne cr6,0x8b0922dc
	if (!ctx.cr6.eq) goto loc_8B0922DC;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// mr r3,r26
	ctx.r3.u64 = ctx.r26.u64;
	// addi r4,r11,4460
	ctx.r4.s64 = ctx.r11.s64 + 4460;
	// bl 0x8b0cea10
	ctx.lr = 0x8B092288;
	sub_8B0CEA10(ctx, base);
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// beq cr6,0x8b0925b4
	if (ctx.cr6.eq) goto loc_8B0925B4;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// addi r4,r11,4420
	ctx.r4.s64 = ctx.r11.s64 + 4420;
	// addi r3,r10,4056
	ctx.r3.s64 = ctx.r10.s64 + 4056;
	// li r5,0
	ctx.r5.s64 = 0;
	// bl 0x8b0c0c70
	ctx.lr = 0x8B0922A8;
	sub_8B0C0C70(ctx, base);
	// lwz r9,0(r31)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r31.u32 + 0);
	// mr r30,r3
	ctx.r30.u64 = ctx.r3.u64;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// mr r4,r30
	ctx.r4.u64 = ctx.r30.u64;
	// lwz r8,8(r9)
	ctx.r8.u64 = REX_LOAD_U32(ctx.r9.u32 + 8);
	// mtctr r8
	ctx.ctr.u64 = ctx.r8.u64;
	// bctrl 
	ctx.lr = 0x8B0922C4;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// cmplwi cr6,r30,0
	ctx.cr6.compare<uint32_t>(ctx.r30.u32, 0, ctx.xer);
	// beq cr6,0x8b0925b4
	if (ctx.cr6.eq) goto loc_8B0925B4;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// bl 0x8b0c04f0
	ctx.lr = 0x8B0922D4;
	sub_8B0C04F0(ctx, base);
	// addi r1,r1,160
	ctx.r1.s64 = ctx.r1.s64 + 160;
	// b 0x8b0cb9fc
	__restgprlr_25(ctx, base);
	return;
loc_8B0922DC:
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// mr r4,r30
	ctx.r4.u64 = ctx.r30.u64;
	// addi r3,r11,3520
	ctx.r3.s64 = ctx.r11.s64 + 3520;
	// bl 0x8b0cea10
	ctx.lr = 0x8B0922EC;
	sub_8B0CEA10(ctx, base);
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// bne cr6,0x8b092458
	if (!ctx.cr6.eq) goto loc_8B092458;
	// lwz r11,0(r27)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r27.u32 + 0);
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// mr r5,r28
	ctx.r5.u64 = ctx.r28.u64;
	// addi r4,r10,4412
	ctx.r4.s64 = ctx.r10.s64 + 4412;
	// mr r3,r27
	ctx.r3.u64 = ctx.r27.u64;
	// lwz r9,36(r11)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r11.u32 + 36);
	// mtctr r9
	ctx.ctr.u64 = ctx.r9.u64;
	// bctrl 
	ctx.lr = 0x8B092314;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// lis r8,-29944
	ctx.r8.s64 = -1962409984;
	// lis r7,-29944
	ctx.r7.s64 = -1962409984;
	// addi r6,r8,4056
	ctx.r6.s64 = ctx.r8.s64 + 4056;
	// mr r27,r3
	ctx.r27.u64 = ctx.r3.u64;
	// addi r4,r7,4520
	ctx.r4.s64 = ctx.r7.s64 + 4520;
	// li r5,0
	ctx.r5.s64 = 0;
	// mr r3,r6
	ctx.r3.u64 = ctx.r6.u64;
	// bl 0x8b0c0c70
	ctx.lr = 0x8B092334;
	sub_8B0C0C70(ctx, base);
	// mr r30,r3
	ctx.r30.u64 = ctx.r3.u64;
	// li r3,0
	ctx.r3.s64 = 0;
	// lis r4,-29938
	ctx.r4.s64 = -1962016768;
	// stw r3,80(r1)
	REX_STORE_U32(ctx.r1.u32 + 80, ctx.r3.u32);
	// addi r6,r1,80
	ctx.r6.s64 = ctx.r1.s64 + 80;
	// mr r5,r27
	ctx.r5.u64 = ctx.r27.u64;
	// lwz r3,540(r4)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r4.u32 + 540);
	// mr r4,r29
	ctx.r4.u64 = ctx.r29.u64;
	// lwz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r10,8(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 8);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B092364;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// mr r29,r3
	ctx.r29.u64 = ctx.r3.u64;
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0923c8
	if (ctx.cr6.eq) goto loc_8B0923C8;
	// lwz r3,80(r1)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r1.u32 + 80);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0923c8
	if (ctx.cr6.eq) goto loc_8B0923C8;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// mr r5,r28
	ctx.r5.u64 = ctx.r28.u64;
	// addi r4,r11,4404
	ctx.r4.s64 = ctx.r11.s64 + 4404;
	// bl 0x8b0c1588
	ctx.lr = 0x8B09238C;
	sub_8B0C1588(ctx, base);
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// mr r5,r3
	ctx.r5.u64 = ctx.r3.u64;
	// addi r4,r10,4380
	ctx.r4.s64 = ctx.r10.s64 + 4380;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// bl 0x8b0c0010
	ctx.lr = 0x8B0923A0;
	sub_8B0C0010(ctx, base);
	// lis r9,-29944
	ctx.r9.s64 = -1962409984;
	// li r5,0
	ctx.r5.s64 = 0;
	// addi r4,r9,2228
	ctx.r4.s64 = ctx.r9.s64 + 2228;
	// mr r3,r29
	ctx.r3.u64 = ctx.r29.u64;
	// bl 0x8b0bfc38
	ctx.lr = 0x8B0923B4;
	sub_8B0BFC38(ctx, base);
	// lis r8,-29944
	ctx.r8.s64 = -1962409984;
	// mr r5,r3
	ctx.r5.u64 = ctx.r3.u64;
	// addi r4,r8,4360
	ctx.r4.s64 = ctx.r8.s64 + 4360;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// bl 0x8b0c0148
	ctx.lr = 0x8B0923C8;
	sub_8B0C0148(ctx, base);
loc_8B0923C8:
	// lwz r11,0(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 0);
	// mr r4,r30
	ctx.r4.u64 = ctx.r30.u64;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// lwz r10,8(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 8);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B0923E0;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// li r3,36
	ctx.r3.s64 = 36;
	// bl 0x8b0bf448
	ctx.lr = 0x8B0923E8;
	sub_8B0BF448(ctx, base);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b092414
	if (ctx.cr6.eq) goto loc_8B092414;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// lis r9,-29944
	ctx.r9.s64 = -1962409984;
	// addi r6,r11,4508
	ctx.r6.s64 = ctx.r11.s64 + 4508;
	// addi r5,r10,4500
	ctx.r5.s64 = ctx.r10.s64 + 4500;
	// addi r4,r9,4472
	ctx.r4.s64 = ctx.r9.s64 + 4472;
	// bl 0x8b0c1300
	ctx.lr = 0x8B09240C;
	sub_8B0C1300(ctx, base);
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// b 0x8b092418
	goto loc_8B092418;
loc_8B092414:
	// li r31,0
	ctx.r31.s64 = 0;
loc_8B092418:
	// lwz r3,-17796(r25)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r25.u32 + -17796);
	// lwz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r10,28(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 28);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B09242C;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// lwz r9,0(r3)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// mr r4,r31
	ctx.r4.u64 = ctx.r31.u64;
	// lwz r8,8(r9)
	ctx.r8.u64 = REX_LOAD_U32(ctx.r9.u32 + 8);
	// mtctr r8
	ctx.ctr.u64 = ctx.r8.u64;
	// bctrl 
	ctx.lr = 0x8B092440;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// cmplwi cr6,r30,0
	ctx.cr6.compare<uint32_t>(ctx.r30.u32, 0, ctx.xer);
	// beq cr6,0x8b0925b4
	if (ctx.cr6.eq) goto loc_8B0925B4;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// bl 0x8b0c04f0
	ctx.lr = 0x8B092450;
	sub_8B0C04F0(ctx, base);
	// addi r1,r1,160
	ctx.r1.s64 = ctx.r1.s64 + 160;
	// b 0x8b0cb9fc
	__restgprlr_25(ctx, base);
	return;
loc_8B092458:
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// mr r4,r30
	ctx.r4.u64 = ctx.r30.u64;
	// addi r3,r11,3460
	ctx.r3.s64 = ctx.r11.s64 + 3460;
	// bl 0x8b0cea10
	ctx.lr = 0x8B092468;
	sub_8B0CEA10(ctx, base);
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// bne cr6,0x8b0924f8
	if (!ctx.cr6.eq) goto loc_8B0924F8;
	// lwz r11,0(r27)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r27.u32 + 0);
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// lis r9,-29944
	ctx.r9.s64 = -1962409984;
	// addi r5,r10,4352
	ctx.r5.s64 = ctx.r10.s64 + 4352;
	// addi r4,r9,4336
	ctx.r4.s64 = ctx.r9.s64 + 4336;
	// mr r3,r27
	ctx.r3.u64 = ctx.r27.u64;
	// lwz r8,36(r11)
	ctx.r8.u64 = REX_LOAD_U32(ctx.r11.u32 + 36);
	// mtctr r8
	ctx.ctr.u64 = ctx.r8.u64;
	// bctrl 
	ctx.lr = 0x8B092494;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// lis r7,-29944
	ctx.r7.s64 = -1962409984;
	// lis r6,-29944
	ctx.r6.s64 = -1962409984;
	// addi r11,r7,4056
	ctx.r11.s64 = ctx.r7.s64 + 4056;
	// mr r29,r3
	ctx.r29.u64 = ctx.r3.u64;
	// addi r4,r6,4296
	ctx.r4.s64 = ctx.r6.s64 + 4296;
	// li r5,0
	ctx.r5.s64 = 0;
	// mr r3,r11
	ctx.r3.u64 = ctx.r11.u64;
	// bl 0x8b0c0c70
	ctx.lr = 0x8B0924B4;
	sub_8B0C0C70(ctx, base);
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// mr r5,r29
	ctx.r5.u64 = ctx.r29.u64;
	// addi r4,r10,4272
	ctx.r4.s64 = ctx.r10.s64 + 4272;
	// mr r30,r3
	ctx.r30.u64 = ctx.r3.u64;
	// bl 0x8b0c0010
	ctx.lr = 0x8B0924C8;
	sub_8B0C0010(ctx, base);
	// lwz r9,0(r31)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r31.u32 + 0);
	// mr r4,r30
	ctx.r4.u64 = ctx.r30.u64;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// lwz r8,8(r9)
	ctx.r8.u64 = REX_LOAD_U32(ctx.r9.u32 + 8);
	// mtctr r8
	ctx.ctr.u64 = ctx.r8.u64;
	// bctrl 
	ctx.lr = 0x8B0924E0;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// cmplwi cr6,r30,0
	ctx.cr6.compare<uint32_t>(ctx.r30.u32, 0, ctx.xer);
	// beq cr6,0x8b0925b4
	if (ctx.cr6.eq) goto loc_8B0925B4;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// bl 0x8b0c04f0
	ctx.lr = 0x8B0924F0;
	sub_8B0C04F0(ctx, base);
	// addi r1,r1,160
	ctx.r1.s64 = ctx.r1.s64 + 160;
	// b 0x8b0cb9fc
	__restgprlr_25(ctx, base);
	return;
loc_8B0924F8:
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// mr r4,r30
	ctx.r4.u64 = ctx.r30.u64;
	// addi r3,r11,3532
	ctx.r3.s64 = ctx.r11.s64 + 3532;
	// bl 0x8b0cea10
	ctx.lr = 0x8B092508;
	sub_8B0CEA10(ctx, base);
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// bne cr6,0x8b0925b4
	if (!ctx.cr6.eq) goto loc_8B0925B4;
	// lwz r10,0(r27)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r27.u32 + 0);
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lis r9,-29944
	ctx.r9.s64 = -1962409984;
	// addi r31,r11,4500
	ctx.r31.s64 = ctx.r11.s64 + 4500;
	// addi r30,r9,4264
	ctx.r30.s64 = ctx.r9.s64 + 4264;
	// mr r4,r31
	ctx.r4.u64 = ctx.r31.u64;
	// lwz r8,36(r10)
	ctx.r8.u64 = REX_LOAD_U32(ctx.r10.u32 + 36);
	// mr r5,r30
	ctx.r5.u64 = ctx.r30.u64;
	// mr r3,r27
	ctx.r3.u64 = ctx.r27.u64;
	// mtctr r8
	ctx.ctr.u64 = ctx.r8.u64;
	// bctrl 
	ctx.lr = 0x8B09253C;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// mr r4,r30
	ctx.r4.u64 = ctx.r30.u64;
	// bl 0x8b0cea10
	ctx.lr = 0x8B092544;
	sub_8B0CEA10(ctx, base);
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// bne cr6,0x8b0925b4
	if (!ctx.cr6.eq) goto loc_8B0925B4;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// addi r3,r11,4192
	ctx.r3.s64 = ctx.r11.s64 + 4192;
	// bl 0x8b0df298
	ctx.lr = 0x8B092558;
	sub_8B0DF298(ctx, base);
	// li r3,36
	ctx.r3.s64 = 36;
	// bl 0x8b0bf448
	ctx.lr = 0x8B092560;
	sub_8B0BF448(ctx, base);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b092588
	if (ctx.cr6.eq) goto loc_8B092588;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// addi r6,r11,4164
	ctx.r6.s64 = ctx.r11.s64 + 4164;
	// mr r5,r31
	ctx.r5.u64 = ctx.r31.u64;
	// addi r4,r10,4136
	ctx.r4.s64 = ctx.r10.s64 + 4136;
	// bl 0x8b0c1300
	ctx.lr = 0x8B092580;
	sub_8B0C1300(ctx, base);
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// b 0x8b09258c
	goto loc_8B09258C;
loc_8B092588:
	// li r31,0
	ctx.r31.s64 = 0;
loc_8B09258C:
	// lwz r3,-17796(r25)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r25.u32 + -17796);
	// lwz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r10,28(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 28);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B0925A0;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// lwz r9,0(r3)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// mr r4,r31
	ctx.r4.u64 = ctx.r31.u64;
	// lwz r8,8(r9)
	ctx.r8.u64 = REX_LOAD_U32(ctx.r9.u32 + 8);
	// mtctr r8
	ctx.ctr.u64 = ctx.r8.u64;
	// bctrl 
	ctx.lr = 0x8B0925B4;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
loc_8B0925B4:
	// addi r1,r1,160
	ctx.r1.s64 = ctx.r1.s64 + 160;
	// b 0x8b0cb9fc
	__restgprlr_25(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B093D80) {
	REX_FUNC_PROLOGUE();
	PPCRegister temp{};
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb980
	ctx.lr = 0x8B093D88;
	__savegprlr_14(ctx, base);
	// stwu r1,-832(r1)
	ea = -832 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lis r9,-29944
	ctx.r9.s64 = -1962409984;
	// stw r4,860(r1)
	REX_STORE_U32(ctx.r1.u32 + 860, ctx.r4.u32);
	// lis r8,-29944
	ctx.r8.s64 = -1962409984;
	// stw r5,112(r1)
	REX_STORE_U32(ctx.r1.u32 + 112, ctx.r5.u32);
	// mr r31,r4
	ctx.r31.u64 = ctx.r4.u64;
	// addi r4,r9,5680
	ctx.r4.s64 = ctx.r9.s64 + 5680;
	// mr r24,r5
	ctx.r24.u64 = ctx.r5.u64;
	// addi r3,r8,5668
	ctx.r3.s64 = ctx.r8.s64 + 5668;
	// stw r4,128(r1)
	REX_STORE_U32(ctx.r1.u32 + 128, ctx.r4.u32);
	// lis r7,-29944
	ctx.r7.s64 = -1962409984;
	// lis r6,-29944
	ctx.r6.s64 = -1962409984;
	// stw r3,132(r1)
	REX_STORE_U32(ctx.r1.u32 + 132, ctx.r3.u32);
	// lis r5,-29944
	ctx.r5.s64 = -1962409984;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// li r10,1
	ctx.r10.s64 = 1;
	// addi r11,r11,5636
	ctx.r11.s64 = ctx.r11.s64 + 5636;
	// addi r9,r7,5660
	ctx.r9.s64 = ctx.r7.s64 + 5660;
	// stw r10,80(r1)
	REX_STORE_U32(ctx.r1.u32 + 80, ctx.r10.u32);
	// addi r8,r6,5648
	ctx.r8.s64 = ctx.r6.s64 + 5648;
	// stw r11,104(r1)
	REX_STORE_U32(ctx.r1.u32 + 104, ctx.r11.u32);
	// addi r4,r5,5468
	ctx.r4.s64 = ctx.r5.s64 + 5468;
	// stw r9,136(r1)
	REX_STORE_U32(ctx.r1.u32 + 136, ctx.r9.u32);
	// li r27,4
	ctx.r27.s64 = 4;
	// stw r8,140(r1)
	REX_STORE_U32(ctx.r1.u32 + 140, ctx.r8.u32);
	// li r5,4
	ctx.r5.s64 = 4;
	// stw r11,144(r1)
	REX_STORE_U32(ctx.r1.u32 + 144, ctx.r11.u32);
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// stw r10,84(r1)
	REX_STORE_U32(ctx.r1.u32 + 84, ctx.r10.u32);
	// stw r10,88(r1)
	REX_STORE_U32(ctx.r1.u32 + 88, ctx.r10.u32);
	// stw r10,92(r1)
	REX_STORE_U32(ctx.r1.u32 + 92, ctx.r10.u32);
	// stw r27,96(r1)
	REX_STORE_U32(ctx.r1.u32 + 96, ctx.r27.u32);
	// bl 0x8b0bfc38
	ctx.lr = 0x8B093E0C;
	sub_8B0BFC38(ctx, base);
	// cmpwi cr6,r3,4
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 4, ctx.xer);
	// ble cr6,0x8b093e2c
	if (!ctx.cr6.gt) goto loc_8B093E2C;
	// cmplwi cr6,r3,5
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 5, ctx.xer);
	// ble cr6,0x8b093e24
	if (!ctx.cr6.gt) goto loc_8B093E24;
	// li r21,5
	ctx.r21.s64 = 5;
	// b 0x8b093e30
	goto loc_8B093E30;
loc_8B093E24:
	// mr r21,r3
	ctx.r21.u64 = ctx.r3.u64;
	// b 0x8b093e30
	goto loc_8B093E30;
loc_8B093E2C:
	// li r21,4
	ctx.r21.s64 = 4;
loc_8B093E30:
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// li r5,0
	ctx.r5.s64 = 0;
	// addi r4,r11,3636
	ctx.r4.s64 = ctx.r11.s64 + 3636;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0bfa88
	ctx.lr = 0x8B093E44;
	sub_8B0BFA88(ctx, base);
	// mr r15,r3
	ctx.r15.u64 = ctx.r3.u64;
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0945a8
	if (ctx.cr6.eq) goto loc_8B0945A8;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// li r5,0
	ctx.r5.s64 = 0;
	// addi r4,r11,3624
	ctx.r4.s64 = ctx.r11.s64 + 3624;
	// bl 0x8b0bfc38
	ctx.lr = 0x8B093E60;
	sub_8B0BFC38(ctx, base);
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// mr r14,r3
	ctx.r14.u64 = ctx.r3.u64;
	// addi r23,r11,3592
	ctx.r23.s64 = ctx.r11.s64 + 3592;
	// li r5,0
	ctx.r5.s64 = 0;
	// mr r4,r23
	ctx.r4.u64 = ctx.r23.u64;
	// stw r23,108(r1)
	REX_STORE_U32(ctx.r1.u32 + 108, ctx.r23.u32);
	// mr r3,r15
	ctx.r3.u64 = ctx.r15.u64;
	// bl 0x8b0bfc38
	ctx.lr = 0x8B093E80;
	sub_8B0BFC38(ctx, base);
	// lis r9,-29944
	ctx.r9.s64 = -1962409984;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// stw r3,148(r1)
	REX_STORE_U32(ctx.r1.u32 + 148, ctx.r3.u32);
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// addi r22,r9,3580
	ctx.r22.s64 = ctx.r9.s64 + 3580;
	// li r25,0
	ctx.r25.s64 = 0;
	// cmpwi cr6,r14,0
	ctx.cr6.compare<int32_t>(ctx.r14.s32, 0, ctx.xer);
	// stw r22,100(r1)
	REX_STORE_U32(ctx.r1.u32 + 100, ctx.r22.u32);
	// addi r18,r11,5612
	ctx.r18.s64 = ctx.r11.s64 + 5612;
	// addi r16,r10,1791
	ctx.r16.s64 = ctx.r10.s64 + 1791;
	// ble cr6,0x8b093f94
	if (!ctx.cr6.gt) goto loc_8B093F94;
loc_8B093EAC:
	// mr r4,r22
	ctx.r4.u64 = ctx.r22.u64;
	// mr r5,r25
	ctx.r5.u64 = ctx.r25.u64;
	// addi r3,r1,160
	ctx.r3.s64 = ctx.r1.s64 + 160;
	// bl 0x8b090220
	ctx.lr = 0x8B093EBC;
	sub_8B090220(ctx, base);
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// li r5,0
	ctx.r5.s64 = 0;
	// mr r3,r15
	ctx.r3.u64 = ctx.r15.u64;
	// bl 0x8b0bfa88
	ctx.lr = 0x8B093ECC;
	sub_8B0BFA88(ctx, base);
	// mr r27,r3
	ctx.r27.u64 = ctx.r3.u64;
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b093f84
	if (ctx.cr6.eq) goto loc_8B093F84;
	// mr r4,r23
	ctx.r4.u64 = ctx.r23.u64;
	// li r5,0
	ctx.r5.s64 = 0;
	// bl 0x8b0bfc38
	ctx.lr = 0x8B093EE4;
	sub_8B0BFC38(ctx, base);
	// mr r26,r3
	ctx.r26.u64 = ctx.r3.u64;
	// li r28,0
	ctx.r28.s64 = 0;
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// ble cr6,0x8b093f84
	if (!ctx.cr6.gt) goto loc_8B093F84;
loc_8B093EF4:
	// mr r4,r18
	ctx.r4.u64 = ctx.r18.u64;
	// mr r5,r28
	ctx.r5.u64 = ctx.r28.u64;
	// addi r3,r1,416
	ctx.r3.s64 = ctx.r1.s64 + 416;
	// bl 0x8b090220
	ctx.lr = 0x8B093F04;
	sub_8B090220(ctx, base);
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// mr r5,r16
	ctx.r5.u64 = ctx.r16.u64;
	// mr r3,r27
	ctx.r3.u64 = ctx.r27.u64;
	// bl 0x8b0c1588
	ctx.lr = 0x8B093F14;
	sub_8B0C1588(ctx, base);
	// mr r29,r3
	ctx.r29.u64 = ctx.r3.u64;
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b093f78
	if (ctx.cr6.eq) goto loc_8B093F78;
	// lbz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U8(ctx.r3.u32 + 0);
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// beq cr6,0x8b093f78
	if (ctx.cr6.eq) goto loc_8B093F78;
	// li r31,0
	ctx.r31.s64 = 0;
	// cmpwi cr6,r21,0
	ctx.cr6.compare<int32_t>(ctx.r21.s32, 0, ctx.xer);
	// ble cr6,0x8b093f78
	if (!ctx.cr6.gt) goto loc_8B093F78;
	// addi r30,r1,128
	ctx.r30.s64 = ctx.r1.s64 + 128;
loc_8B093F3C:
	// mr r4,r29
	ctx.r4.u64 = ctx.r29.u64;
	// lwz r3,0(r30)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r30.u32 + 0);
	// bl 0x8b0cea10
	ctx.lr = 0x8B093F48;
	sub_8B0CEA10(ctx, base);
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// beq cr6,0x8b093f64
	if (ctx.cr6.eq) goto loc_8B093F64;
	// addi r31,r31,1
	ctx.r31.s64 = ctx.r31.s64 + 1;
	// addi r30,r30,4
	ctx.r30.s64 = ctx.r30.s64 + 4;
	// cmpw cr6,r31,r21
	ctx.cr6.compare<int32_t>(ctx.r31.s32, ctx.r21.s32, ctx.xer);
	// blt cr6,0x8b093f3c
	if (ctx.cr6.lt) goto loc_8B093F3C;
	// b 0x8b093f78
	goto loc_8B093F78;
loc_8B093F64:
	// rlwinm r10,r31,2,0,29
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r31.u32 | (ctx.r31.u64 << 32), 2) & 0xFFFFFFFC;
	// addi r11,r1,80
	ctx.r11.s64 = ctx.r1.s64 + 80;
	// lwzx r9,r10,r11
	ctx.r9.u64 = REX_LOAD_U32(ctx.r10.u32 + ctx.r11.u32);
	// addi r9,r9,-1
	ctx.r9.s64 = ctx.r9.s64 + -1;
	// stwx r9,r10,r11
	REX_STORE_U32(ctx.r10.u32 + ctx.r11.u32, ctx.r9.u32);
loc_8B093F78:
	// addi r28,r28,1
	ctx.r28.s64 = ctx.r28.s64 + 1;
	// cmpw cr6,r28,r26
	ctx.cr6.compare<int32_t>(ctx.r28.s32, ctx.r26.s32, ctx.xer);
	// blt cr6,0x8b093ef4
	if (ctx.cr6.lt) goto loc_8B093EF4;
loc_8B093F84:
	// addi r25,r25,1
	ctx.r25.s64 = ctx.r25.s64 + 1;
	// cmpw cr6,r25,r14
	ctx.cr6.compare<int32_t>(ctx.r25.s32, ctx.r14.s32, ctx.xer);
	// blt cr6,0x8b093eac
	if (ctx.cr6.lt) goto loc_8B093EAC;
	// lwz r27,96(r1)
	ctx.r27.u64 = REX_LOAD_U32(ctx.r1.u32 + 96);
loc_8B093F94:
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// li r19,0
	ctx.r19.s64 = 0;
	// cmpwi cr6,r14,0
	ctx.cr6.compare<int32_t>(ctx.r14.s32, 0, ctx.xer);
	// addi r20,r11,3876
	ctx.r20.s64 = ctx.r11.s64 + 3876;
	// addi r17,r10,3604
	ctx.r17.s64 = ctx.r10.s64 + 3604;
	// ble cr6,0x8b0942b0
	if (!ctx.cr6.gt) goto loc_8B0942B0;
loc_8B093FB0:
	// mr r5,r19
	ctx.r5.u64 = ctx.r19.u64;
	// lwz r4,100(r1)
	ctx.r4.u64 = REX_LOAD_U32(ctx.r1.u32 + 100);
	// addi r3,r1,416
	ctx.r3.s64 = ctx.r1.s64 + 416;
	// bl 0x8b090220
	ctx.lr = 0x8B093FC0;
	sub_8B090220(ctx, base);
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// li r5,0
	ctx.r5.s64 = 0;
	// mr r3,r15
	ctx.r3.u64 = ctx.r15.u64;
	// bl 0x8b0bfa88
	ctx.lr = 0x8B093FD0;
	sub_8B0BFA88(ctx, base);
	// mr r23,r3
	ctx.r23.u64 = ctx.r3.u64;
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0942a4
	if (ctx.cr6.eq) goto loc_8B0942A4;
	// li r5,0
	ctx.r5.s64 = 0;
	// lwz r4,108(r1)
	ctx.r4.u64 = REX_LOAD_U32(ctx.r1.u32 + 108);
	// bl 0x8b0bfc38
	ctx.lr = 0x8B093FE8;
	sub_8B0BFC38(ctx, base);
	// mr r22,r3
	ctx.r22.u64 = ctx.r3.u64;
	// cmpwi cr6,r3,1
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 1, ctx.xer);
	// ble cr6,0x8b0942a4
	if (!ctx.cr6.gt) goto loc_8B0942A4;
	// li r26,0
	ctx.r26.s64 = 0;
	// li r31,0
	ctx.r31.s64 = 0;
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// ble cr6,0x8b094064
	if (!ctx.cr6.gt) goto loc_8B094064;
	// lwz r30,104(r1)
	ctx.r30.u64 = REX_LOAD_U32(ctx.r1.u32 + 104);
loc_8B094008:
	// mr r4,r18
	ctx.r4.u64 = ctx.r18.u64;
	// mr r5,r31
	ctx.r5.u64 = ctx.r31.u64;
	// addi r3,r1,160
	ctx.r3.s64 = ctx.r1.s64 + 160;
	// bl 0x8b090220
	ctx.lr = 0x8B094018;
	sub_8B090220(ctx, base);
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// mr r5,r16
	ctx.r5.u64 = ctx.r16.u64;
	// mr r3,r23
	ctx.r3.u64 = ctx.r23.u64;
	// bl 0x8b0c1588
	ctx.lr = 0x8B094028;
	sub_8B0C1588(ctx, base);
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b094058
	if (ctx.cr6.eq) goto loc_8B094058;
	// lbz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U8(ctx.r3.u32 + 0);
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// beq cr6,0x8b094058
	if (ctx.cr6.eq) goto loc_8B094058;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// bl 0x8b0cea10
	ctx.lr = 0x8B094048;
	sub_8B0CEA10(ctx, base);
	// subfic r11,r3,0
	ctx.xer.ca = ctx.r3.u32 <= 0;
	ctx.r11.u64 = static_cast<uint64_t>(0) - ctx.r3.u64;
	// subfe r10,r11,r11
	temp.u8 = (~ctx.r11.u32 + ctx.r11.u32 < ~ctx.r11.u32) | (~ctx.r11.u32 + ctx.r11.u32 + ctx.xer.ca < ctx.xer.ca);
	ctx.r10.u64 = ~ctx.r11.u64 + ctx.r11.u64 + ctx.xer.ca;
	ctx.xer.ca = temp.u8;
	// rlwinm r11,r10,0,31,29
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r10.u32 | (ctx.r10.u64 << 32), 0) & 0xFFFFFFFFFFFFFFFD;
	// addi r26,r11,4
	ctx.r26.s64 = ctx.r11.s64 + 4;
loc_8B094058:
	// addi r31,r31,1
	ctx.r31.s64 = ctx.r31.s64 + 1;
	// cmpw cr6,r31,r22
	ctx.cr6.compare<int32_t>(ctx.r31.s32, ctx.r22.s32, ctx.xer);
	// blt cr6,0x8b094008
	if (ctx.cr6.lt) goto loc_8B094008;
loc_8B094064:
	// li r25,0
	ctx.r25.s64 = 0;
	// cmpwi cr6,r22,0
	ctx.cr6.compare<int32_t>(ctx.r22.s32, 0, ctx.xer);
	// ble cr6,0x8b0942a4
	if (!ctx.cr6.gt) goto loc_8B0942A4;
loc_8B094070:
	// mr r4,r17
	ctx.r4.u64 = ctx.r17.u64;
	// mr r5,r25
	ctx.r5.u64 = ctx.r25.u64;
	// addi r3,r1,160
	ctx.r3.s64 = ctx.r1.s64 + 160;
	// bl 0x8b090220
	ctx.lr = 0x8B094080;
	sub_8B090220(ctx, base);
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// li r5,0
	ctx.r5.s64 = 0;
	// mr r3,r23
	ctx.r3.u64 = ctx.r23.u64;
	// bl 0x8b0bfa88
	ctx.lr = 0x8B094090;
	sub_8B0BFA88(ctx, base);
	// mr r28,r3
	ctx.r28.u64 = ctx.r3.u64;
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b094298
	if (ctx.cr6.eq) goto loc_8B094298;
	// mr r5,r16
	ctx.r5.u64 = ctx.r16.u64;
	// mr r4,r20
	ctx.r4.u64 = ctx.r20.u64;
	// bl 0x8b0c1588
	ctx.lr = 0x8B0940A8;
	sub_8B0C1588(ctx, base);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0940bc
	if (ctx.cr6.eq) goto loc_8B0940BC;
	// lbz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U8(ctx.r3.u32 + 0);
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// bne cr6,0x8b094298
	if (!ctx.cr6.eq) goto loc_8B094298;
loc_8B0940BC:
	// lwz r11,92(r1)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r1.u32 + 92);
	// addi r10,r21,-5
	ctx.r10.s64 = ctx.r21.s64 + -5;
	// lwz r9,88(r1)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r1.u32 + 88);
	// cmplwi cr6,r26,4
	ctx.cr6.compare<uint32_t>(ctx.r26.u32, 4, ctx.xer);
	// lwz r8,84(r1)
	ctx.r8.u64 = REX_LOAD_U32(ctx.r1.u32 + 84);
	// addic r7,r10,-1
	ctx.xer.ca = ctx.r10.u32 > 0;
	ctx.r7.s64 = ctx.r10.s64 + -1;
	// add r11,r11,r9
	ctx.r11.u64 = ctx.r11.u64 + ctx.r9.u64;
	// lwz r5,80(r1)
	ctx.r5.u64 = REX_LOAD_U32(ctx.r1.u32 + 80);
	// subfe r4,r6,r6
	temp.u8 = (~ctx.r6.u32 + ctx.r6.u32 < ~ctx.r6.u32) | (~ctx.r6.u32 + ctx.r6.u32 + ctx.xer.ca < ctx.xer.ca);
	ctx.r4.u64 = ~ctx.r6.u64 + ctx.r6.u64 + ctx.xer.ca;
	ctx.xer.ca = temp.u8;
	// add r11,r11,r8
	ctx.r11.u64 = ctx.r11.u64 + ctx.r8.u64;
	// and r3,r4,r27
	ctx.r3.u64 = ctx.r4.u64 & ctx.r27.u64;
	// add r11,r11,r5
	ctx.r11.u64 = ctx.r11.u64 + ctx.r5.u64;
	// bne cr6,0x8b094100
	if (!ctx.cr6.eq) goto loc_8B094100;
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// bne cr6,0x8b094118
	if (!ctx.cr6.eq) goto loc_8B094118;
	// li r26,1
	ctx.r26.s64 = 1;
	// b 0x8b094108
	goto loc_8B094108;
loc_8B094100:
	// cmpwi cr6,r26,1
	ctx.cr6.compare<int32_t>(ctx.r26.s32, 1, ctx.xer);
	// bne cr6,0x8b094114
	if (!ctx.cr6.eq) goto loc_8B094114;
loc_8B094108:
	// cmpwi cr6,r11,0
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// bne cr6,0x8b094114
	if (!ctx.cr6.eq) goto loc_8B094114;
	// li r26,4
	ctx.r26.s64 = 4;
loc_8B094114:
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
loc_8B094118:
	// ble cr6,0x8b094150
	if (!ctx.cr6.gt) goto loc_8B094150;
	// cmpwi cr6,r11,0
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// ble cr6,0x8b094150
	if (!ctx.cr6.gt) goto loc_8B094150;
	// cmpw cr6,r3,r11
	ctx.cr6.compare<int32_t>(ctx.r3.s32, ctx.r11.s32, ctx.xer);
	// bne cr6,0x8b09413c
	if (!ctx.cr6.eq) goto loc_8B09413C;
	// li r4,1
	ctx.r4.s64 = 1;
	// li r3,0
	ctx.r3.s64 = 0;
	// bl 0x8b0df558
	ctx.lr = 0x8B094138;
	sub_8B0DF558(ctx, base);
	// b 0x8b094150
	goto loc_8B094150;
loc_8B09413C:
	// subf r10,r11,r3
	ctx.r10.u64 = ctx.r3.u64 - ctx.r11.u64;
	// xoris r9,r11,32768
	ctx.r9.u64 = ctx.r11.u64 ^ 2147483648;
	// addc r8,r10,r9
	ctx.xer.ca = ctx.r10.u32 + ctx.r9.u32 < ctx.r10.u32;
	ctx.r8.u64 = ctx.r10.u64 + ctx.r9.u64;
	// subfe r6,r7,r7
	temp.u8 = (~ctx.r7.u32 + ctx.r7.u32 < ~ctx.r7.u32) | (~ctx.r7.u32 + ctx.r7.u32 + ctx.xer.ca < ctx.xer.ca);
	ctx.r6.u64 = ~ctx.r7.u64 + ctx.r7.u64 + ctx.xer.ca;
	ctx.xer.ca = temp.u8;
	// and r3,r6,r3
	ctx.r3.u64 = ctx.r6.u64 & ctx.r3.u64;
loc_8B094150:
	// cmpwi cr6,r26,0
	ctx.cr6.compare<int32_t>(ctx.r26.s32, 0, ctx.xer);
	// bne cr6,0x8b094168
	if (!ctx.cr6.eq) goto loc_8B094168;
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// ble cr6,0x8b09419c
	if (!ctx.cr6.gt) goto loc_8B09419C;
	// li r26,4
	ctx.r26.s64 = 4;
	// b 0x8b094170
	goto loc_8B094170;
loc_8B094168:
	// cmplwi cr6,r26,4
	ctx.cr6.compare<uint32_t>(ctx.r26.u32, 4, ctx.xer);
	// bne cr6,0x8b094194
	if (!ctx.cr6.eq) goto loc_8B094194;
loc_8B094170:
	// cmpwi cr6,r27,0
	ctx.cr6.compare<int32_t>(ctx.r27.s32, 0, ctx.xer);
	// ble cr6,0x8b09420c
	if (!ctx.cr6.gt) goto loc_8B09420C;
	// mr r4,r20
	ctx.r4.u64 = ctx.r20.u64;
	// lwz r5,104(r1)
	ctx.r5.u64 = REX_LOAD_U32(ctx.r1.u32 + 104);
	// mr r3,r28
	ctx.r3.u64 = ctx.r28.u64;
	// bl 0x8b0c0010
	ctx.lr = 0x8B094188;
	sub_8B0C0010(ctx, base);
	// addi r27,r27,-1
	ctx.r27.s64 = ctx.r27.s64 + -1;
	// stw r27,96(r1)
	REX_STORE_U32(ctx.r1.u32 + 96, ctx.r27.u32);
	// b 0x8b094290
	goto loc_8B094290;
loc_8B094194:
	// cmpwi cr6,r26,1
	ctx.cr6.compare<int32_t>(ctx.r26.s32, 1, ctx.xer);
	// bne cr6,0x8b09420c
	if (!ctx.cr6.eq) goto loc_8B09420C;
loc_8B09419C:
	// li r4,3
	ctx.r4.s64 = 3;
	// li r3,0
	ctx.r3.s64 = 0;
	// bl 0x8b0df558
	ctx.lr = 0x8B0941A8;
	sub_8B0DF558(ctx, base);
	// addi r9,r1,80
	ctx.r9.s64 = ctx.r1.s64 + 80;
	// mr r11,r3
	ctx.r11.u64 = ctx.r3.u64;
	// rlwinm r10,r3,2,0,29
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r3.u32 | (ctx.r3.u64 << 32), 2) & 0xFFFFFFFC;
loc_8B0941B4:
	// lwzx r10,r10,r9
	ctx.r10.u64 = REX_LOAD_U32(ctx.r10.u32 + ctx.r9.u32);
	// cmpwi cr6,r10,0
	ctx.cr6.compare<int32_t>(ctx.r10.s32, 0, ctx.xer);
	// bne cr6,0x8b0941d4
	if (!ctx.cr6.eq) goto loc_8B0941D4;
	// addi r11,r11,1
	ctx.r11.s64 = ctx.r11.s64 + 1;
	// clrlwi r11,r11,30
	ctx.r11.u64 = ctx.r11.u32 & 0x3;
	// cmpw cr6,r11,r3
	ctx.cr6.compare<int32_t>(ctx.r11.s32, ctx.r3.s32, ctx.xer);
	// rlwinm r10,r11,2,0,29
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 2) & 0xFFFFFFFC;
	// bne cr6,0x8b0941b4
	if (!ctx.cr6.eq) goto loc_8B0941B4;
loc_8B0941D4:
	// rlwinm r31,r11,2,0,29
	ctx.r31.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 2) & 0xFFFFFFFC;
	// addi r29,r1,80
	ctx.r29.s64 = ctx.r1.s64 + 80;
	// li r26,1
	ctx.r26.s64 = 1;
	// lwzx r30,r31,r29
	ctx.r30.u64 = REX_LOAD_U32(ctx.r31.u32 + ctx.r29.u32);
	// cmpwi cr6,r30,0
	ctx.cr6.compare<int32_t>(ctx.r30.s32, 0, ctx.xer);
	// beq cr6,0x8b09420c
	if (ctx.cr6.eq) goto loc_8B09420C;
	// addi r11,r1,128
	ctx.r11.s64 = ctx.r1.s64 + 128;
	// mr r4,r20
	ctx.r4.u64 = ctx.r20.u64;
	// mr r3,r28
	ctx.r3.u64 = ctx.r28.u64;
	// lwzx r5,r31,r11
	ctx.r5.u64 = REX_LOAD_U32(ctx.r31.u32 + ctx.r11.u32);
	// bl 0x8b0c0010
	ctx.lr = 0x8B094200;
	sub_8B0C0010(ctx, base);
	// addi r10,r30,-1
	ctx.r10.s64 = ctx.r30.s64 + -1;
	// stwx r10,r31,r29
	REX_STORE_U32(ctx.r31.u32 + ctx.r29.u32, ctx.r10.u32);
	// b 0x8b09428c
	goto loc_8B09428C;
loc_8B09420C:
	// addi r4,r21,-1
	ctx.r4.s64 = ctx.r21.s64 + -1;
	// li r3,0
	ctx.r3.s64 = 0;
	// bl 0x8b0df558
	ctx.lr = 0x8B094218;
	sub_8B0DF558(ctx, base);
	// addi r10,r1,80
	ctx.r10.s64 = ctx.r1.s64 + 80;
	// rlwinm r11,r3,2,0,29
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r3.u32 | (ctx.r3.u64 << 32), 2) & 0xFFFFFFFC;
	// add r31,r11,r10
	ctx.r31.u64 = ctx.r11.u64 + ctx.r10.u64;
	// lwzx r10,r11,r10
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + ctx.r10.u32);
	// cmpwi cr6,r10,0
	ctx.cr6.compare<int32_t>(ctx.r10.s32, 0, ctx.xer);
	// bgt cr6,0x8b09426c
	if (ctx.cr6.gt) goto loc_8B09426C;
loc_8B094230:
	// addi r9,r3,1
	ctx.r9.s64 = ctx.r3.s64 + 1;
	// addi r10,r1,80
	ctx.r10.s64 = ctx.r1.s64 + 80;
	// divw r8,r9,r21
	ctx.r8.u64 = uint32_t((ctx.r21.s32 && !(ctx.r9.s32 == INT32_MIN && ctx.r21.s32 == -1)) ? ctx.r9.s32 / ctx.r21.s32 : 0);
	// rotlwi r11,r9,1
	ctx.r11.u64 = __builtin_rotateleft32(ctx.r9.u32, 1);
	// mullw r7,r8,r21
	ctx.r7.s64 = int64_t(ctx.r8.s32) * int64_t(ctx.r21.s32);
	// subf r3,r7,r9
	ctx.r3.u64 = ctx.r9.u64 - ctx.r7.u64;
	// addi r6,r11,-1
	ctx.r6.s64 = ctx.r11.s64 + -1;
	// rlwinm r11,r3,2,0,29
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r3.u32 | (ctx.r3.u64 << 32), 2) & 0xFFFFFFFC;
	// andc r5,r21,r6
	ctx.r5.u64 = ctx.r21.u64 & ~ctx.r6.u64;
	// twllei r21,0
	if (ctx.r21.s32 == 0 || ctx.r21.u32 < 0u) ppc_trap(ctx, base, 0);
	// add r31,r11,r10
	ctx.r31.u64 = ctx.r11.u64 + ctx.r10.u64;
	// twlgei r5,-1
	if (ctx.r5.s32 == -1 || ctx.r5.u32 > 4294967295u) ppc_trap(ctx, base, 0);
	// lwzx r4,r11,r10
	ctx.r4.u64 = REX_LOAD_U32(ctx.r11.u32 + ctx.r10.u32);
	// cmpwi cr6,r4,0
	ctx.cr6.compare<int32_t>(ctx.r4.s32, 0, ctx.xer);
	// ble cr6,0x8b094230
	if (!ctx.cr6.gt) goto loc_8B094230;
loc_8B09426C:
	// addi r10,r1,128
	ctx.r10.s64 = ctx.r1.s64 + 128;
	// mr r4,r20
	ctx.r4.u64 = ctx.r20.u64;
	// mr r3,r28
	ctx.r3.u64 = ctx.r28.u64;
	// lwzx r5,r11,r10
	ctx.r5.u64 = REX_LOAD_U32(ctx.r11.u32 + ctx.r10.u32);
	// bl 0x8b0c0010
	ctx.lr = 0x8B094280;
	sub_8B0C0010(ctx, base);
	// lwz r11,0(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 0);
	// addi r9,r11,-1
	ctx.r9.s64 = ctx.r11.s64 + -1;
	// stw r9,0(r31)
	REX_STORE_U32(ctx.r31.u32 + 0, ctx.r9.u32);
loc_8B09428C:
	// lwz r27,96(r1)
	ctx.r27.u64 = REX_LOAD_U32(ctx.r1.u32 + 96);
loc_8B094290:
	// stw r28,0(r24)
	REX_STORE_U32(ctx.r24.u32 + 0, ctx.r28.u32);
	// addi r24,r24,4
	ctx.r24.s64 = ctx.r24.s64 + 4;
loc_8B094298:
	// addi r25,r25,1
	ctx.r25.s64 = ctx.r25.s64 + 1;
	// cmpw cr6,r25,r22
	ctx.cr6.compare<int32_t>(ctx.r25.s32, ctx.r22.s32, ctx.xer);
	// blt cr6,0x8b094070
	if (ctx.cr6.lt) goto loc_8B094070;
loc_8B0942A4:
	// addi r19,r19,1
	ctx.r19.s64 = ctx.r19.s64 + 1;
	// cmpw cr6,r19,r14
	ctx.cr6.compare<int32_t>(ctx.r19.s32, ctx.r14.s32, ctx.xer);
	// blt cr6,0x8b093fb0
	if (ctx.cr6.lt) goto loc_8B093FB0;
loc_8B0942B0:
	// li r25,0
	ctx.r25.s64 = 0;
	// cmpwi cr6,r14,0
	ctx.cr6.compare<int32_t>(ctx.r14.s32, 0, ctx.xer);
	// ble cr6,0x8b094440
	if (!ctx.cr6.gt) goto loc_8B094440;
loc_8B0942BC:
	// mr r5,r25
	ctx.r5.u64 = ctx.r25.u64;
	// lwz r4,100(r1)
	ctx.r4.u64 = REX_LOAD_U32(ctx.r1.u32 + 100);
	// addi r3,r1,416
	ctx.r3.s64 = ctx.r1.s64 + 416;
	// bl 0x8b090220
	ctx.lr = 0x8B0942CC;
	sub_8B090220(ctx, base);
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// li r5,0
	ctx.r5.s64 = 0;
	// mr r3,r15
	ctx.r3.u64 = ctx.r15.u64;
	// bl 0x8b0bfa88
	ctx.lr = 0x8B0942DC;
	sub_8B0BFA88(ctx, base);
	// mr r28,r3
	ctx.r28.u64 = ctx.r3.u64;
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b094434
	if (ctx.cr6.eq) goto loc_8B094434;
	// li r5,0
	ctx.r5.s64 = 0;
	// lwz r4,108(r1)
	ctx.r4.u64 = REX_LOAD_U32(ctx.r1.u32 + 108);
	// bl 0x8b0bfc38
	ctx.lr = 0x8B0942F4;
	sub_8B0BFC38(ctx, base);
	// mr r26,r3
	ctx.r26.u64 = ctx.r3.u64;
	// li r29,0
	ctx.r29.s64 = 0;
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// ble cr6,0x8b094434
	if (!ctx.cr6.gt) goto loc_8B094434;
loc_8B094304:
	// mr r4,r17
	ctx.r4.u64 = ctx.r17.u64;
	// mr r5,r29
	ctx.r5.u64 = ctx.r29.u64;
	// addi r3,r1,160
	ctx.r3.s64 = ctx.r1.s64 + 160;
	// bl 0x8b090220
	ctx.lr = 0x8B094314;
	sub_8B090220(ctx, base);
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// li r5,0
	ctx.r5.s64 = 0;
	// mr r3,r28
	ctx.r3.u64 = ctx.r28.u64;
	// bl 0x8b0bfa88
	ctx.lr = 0x8B094324;
	sub_8B0BFA88(ctx, base);
	// mr r30,r3
	ctx.r30.u64 = ctx.r3.u64;
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b094428
	if (ctx.cr6.eq) goto loc_8B094428;
	// mr r5,r16
	ctx.r5.u64 = ctx.r16.u64;
	// mr r4,r20
	ctx.r4.u64 = ctx.r20.u64;
	// bl 0x8b0c1588
	ctx.lr = 0x8B09433C;
	sub_8B0C1588(ctx, base);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b094350
	if (ctx.cr6.eq) goto loc_8B094350;
	// lbz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U8(ctx.r3.u32 + 0);
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// bne cr6,0x8b094428
	if (!ctx.cr6.eq) goto loc_8B094428;
loc_8B094350:
	// addi r11,r21,-5
	ctx.r11.s64 = ctx.r21.s64 + -5;
	// lwz r10,88(r1)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r1.u32 + 88);
	// lwz r9,92(r1)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r1.u32 + 92);
	// addic r8,r11,-1
	ctx.xer.ca = ctx.r11.u32 > 0;
	ctx.r8.s64 = ctx.r11.s64 + -1;
	// lwz r6,84(r1)
	ctx.r6.u64 = REX_LOAD_U32(ctx.r1.u32 + 84);
	// add r11,r9,r10
	ctx.r11.u64 = ctx.r9.u64 + ctx.r10.u64;
	// lwz r5,80(r1)
	ctx.r5.u64 = REX_LOAD_U32(ctx.r1.u32 + 80);
	// subfe r4,r7,r7
	temp.u8 = (~ctx.r7.u32 + ctx.r7.u32 < ~ctx.r7.u32) | (~ctx.r7.u32 + ctx.r7.u32 + ctx.xer.ca < ctx.xer.ca);
	ctx.r4.u64 = ~ctx.r7.u64 + ctx.r7.u64 + ctx.xer.ca;
	ctx.xer.ca = temp.u8;
	// add r11,r11,r6
	ctx.r11.u64 = ctx.r11.u64 + ctx.r6.u64;
	// and r3,r4,r27
	ctx.r3.u64 = ctx.r4.u64 & ctx.r27.u64;
	// add r11,r11,r5
	ctx.r11.u64 = ctx.r11.u64 + ctx.r5.u64;
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// ble cr6,0x8b0943b8
	if (!ctx.cr6.gt) goto loc_8B0943B8;
	// cmpwi cr6,r11,0
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// ble cr6,0x8b0943a8
	if (!ctx.cr6.gt) goto loc_8B0943A8;
	// cmpw cr6,r3,r11
	ctx.cr6.compare<int32_t>(ctx.r3.s32, ctx.r11.s32, ctx.xer);
	// bne cr6,0x8b0943a4
	if (!ctx.cr6.eq) goto loc_8B0943A4;
	// li r4,1
	ctx.r4.s64 = 1;
	// li r3,0
	ctx.r3.s64 = 0;
	// bl 0x8b0df558
	ctx.lr = 0x8B0943A0;
	sub_8B0DF558(ctx, base);
	// b 0x8b0943a8
	goto loc_8B0943A8;
loc_8B0943A4:
	// blt cr6,0x8b0943b8
	if (ctx.cr6.lt) goto loc_8B0943B8;
loc_8B0943A8:
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// ble cr6,0x8b0943b8
	if (!ctx.cr6.gt) goto loc_8B0943B8;
	// li r3,4
	ctx.r3.s64 = 4;
	// b 0x8b0943c4
	goto loc_8B0943C4;
loc_8B0943B8:
	// li r4,3
	ctx.r4.s64 = 3;
	// li r3,0
	ctx.r3.s64 = 0;
	// bl 0x8b0df558
	ctx.lr = 0x8B0943C4;
	sub_8B0DF558(ctx, base);
loc_8B0943C4:
	// rlwinm r11,r3,2,0,29
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r3.u32 | (ctx.r3.u64 << 32), 2) & 0xFFFFFFFC;
	// addi r10,r1,80
	ctx.r10.s64 = ctx.r1.s64 + 80;
	// add r31,r11,r10
	ctx.r31.u64 = ctx.r11.u64 + ctx.r10.u64;
	// lwzx r10,r11,r10
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + ctx.r10.u32);
	// cmpwi cr6,r10,0
	ctx.cr6.compare<int32_t>(ctx.r10.s32, 0, ctx.xer);
	// bgt cr6,0x8b0943fc
	if (ctx.cr6.gt) goto loc_8B0943FC;
loc_8B0943DC:
	// addi r11,r3,1
	ctx.r11.s64 = ctx.r3.s64 + 1;
	// addi r10,r1,80
	ctx.r10.s64 = ctx.r1.s64 + 80;
	// clrlwi r3,r11,30
	ctx.r3.u64 = ctx.r11.u32 & 0x3;
	// rlwinm r11,r3,2,0,29
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r3.u32 | (ctx.r3.u64 << 32), 2) & 0xFFFFFFFC;
	// add r31,r11,r10
	ctx.r31.u64 = ctx.r11.u64 + ctx.r10.u64;
	// lwzx r10,r11,r10
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + ctx.r10.u32);
	// cmpwi cr6,r10,0
	ctx.cr6.compare<int32_t>(ctx.r10.s32, 0, ctx.xer);
	// ble cr6,0x8b0943dc
	if (!ctx.cr6.gt) goto loc_8B0943DC;
loc_8B0943FC:
	// addi r10,r1,128
	ctx.r10.s64 = ctx.r1.s64 + 128;
	// mr r4,r20
	ctx.r4.u64 = ctx.r20.u64;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// lwzx r5,r11,r10
	ctx.r5.u64 = REX_LOAD_U32(ctx.r11.u32 + ctx.r10.u32);
	// bl 0x8b0c0010
	ctx.lr = 0x8B094410;
	sub_8B0C0010(ctx, base);
	// lwz r11,0(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 0);
	// stw r30,0(r24)
	REX_STORE_U32(ctx.r24.u32 + 0, ctx.r30.u32);
	// addi r24,r24,4
	ctx.r24.s64 = ctx.r24.s64 + 4;
	// addi r9,r11,-1
	ctx.r9.s64 = ctx.r11.s64 + -1;
	// stw r9,0(r31)
	REX_STORE_U32(ctx.r31.u32 + 0, ctx.r9.u32);
	// lwz r27,96(r1)
	ctx.r27.u64 = REX_LOAD_U32(ctx.r1.u32 + 96);
loc_8B094428:
	// addi r29,r29,1
	ctx.r29.s64 = ctx.r29.s64 + 1;
	// cmpw cr6,r29,r26
	ctx.cr6.compare<int32_t>(ctx.r29.s32, ctx.r26.s32, ctx.xer);
	// blt cr6,0x8b094304
	if (ctx.cr6.lt) goto loc_8B094304;
loc_8B094434:
	// addi r25,r25,1
	ctx.r25.s64 = ctx.r25.s64 + 1;
	// cmpw cr6,r25,r14
	ctx.cr6.compare<int32_t>(ctx.r25.s32, ctx.r14.s32, ctx.xer);
	// blt cr6,0x8b0942bc
	if (ctx.cr6.lt) goto loc_8B0942BC;
loc_8B094440:
	// cmplwi cr6,r21,5
	ctx.cr6.compare<uint32_t>(ctx.r21.u32, 5, ctx.xer);
	// bne cr6,0x8b0945a8
	if (!ctx.cr6.eq) goto loc_8B0945A8;
	// lwz r11,148(r1)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r1.u32 + 148);
	// cmpwi cr6,r11,1
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 1, ctx.xer);
	// ble cr6,0x8b0945a8
	if (!ctx.cr6.gt) goto loc_8B0945A8;
	// lwz r11,92(r1)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r1.u32 + 92);
	// cmpwi cr6,r27,4
	ctx.cr6.compare<int32_t>(ctx.r27.s32, 4, ctx.xer);
	// lwz r10,88(r1)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r1.u32 + 88);
	// lwz r9,84(r1)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r1.u32 + 84);
	// add r11,r11,r10
	ctx.r11.u64 = ctx.r11.u64 + ctx.r10.u64;
	// lwz r8,80(r1)
	ctx.r8.u64 = REX_LOAD_U32(ctx.r1.u32 + 80);
	// add r11,r11,r9
	ctx.r11.u64 = ctx.r11.u64 + ctx.r9.u64;
	// add r11,r11,r8
	ctx.r11.u64 = ctx.r11.u64 + ctx.r8.u64;
	// bne cr6,0x8b094480
	if (!ctx.cr6.eq) goto loc_8B094480;
	// li r29,4
	ctx.r29.s64 = 4;
	// b 0x8b09448c
	goto loc_8B09448C;
loc_8B094480:
	// cmpwi cr6,r11,4
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 4, ctx.xer);
	// bne cr6,0x8b0945a8
	if (!ctx.cr6.eq) goto loc_8B0945A8;
	// li r29,1
	ctx.r29.s64 = 1;
loc_8B09448C:
	// lwz r31,112(r1)
	ctx.r31.u64 = REX_LOAD_U32(ctx.r1.u32 + 112);
	// li r25,0
	ctx.r25.s64 = 0;
	// mr r28,r25
	ctx.r28.u64 = ctx.r25.u64;
	// cmplw cr6,r31,r24
	ctx.cr6.compare<uint32_t>(ctx.r31.u32, ctx.r24.u32, ctx.xer);
	// bge cr6,0x8b0945a8
	if (!ctx.cr6.lt) goto loc_8B0945A8;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lwz r26,860(r1)
	ctx.r26.u64 = REX_LOAD_U32(ctx.r1.u32 + 860);
	// lwz r27,108(r1)
	ctx.r27.u64 = REX_LOAD_U32(ctx.r1.u32 + 108);
	// addi r30,r11,3616
	ctx.r30.s64 = ctx.r11.s64 + 3616;
loc_8B0944B0:
	// cmplwi cr6,r28,0
	ctx.cr6.compare<uint32_t>(ctx.r28.u32, 0, ctx.xer);
	// bne cr6,0x8b094518
	if (!ctx.cr6.eq) goto loc_8B094518;
	// mr r4,r30
	ctx.r4.u64 = ctx.r30.u64;
	// lwz r3,0(r31)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r31.u32 + 0);
	// li r5,0
	ctx.r5.s64 = 0;
	// bl 0x8b0bfd30
	ctx.lr = 0x8B0944C8;
	sub_8B0BFD30(ctx, base);
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// addi r5,r1,100
	ctx.r5.s64 = ctx.r1.s64 + 100;
	// stw r25,100(r1)
	REX_STORE_U32(ctx.r1.u32 + 100, ctx.r25.u32);
	// mr r3,r26
	ctx.r3.u64 = ctx.r26.u64;
	// bl 0x8b091540
	ctx.lr = 0x8B0944DC;
	sub_8B091540(ctx, base);
	// mr r4,r27
	ctx.r4.u64 = ctx.r27.u64;
	// li r5,0
	ctx.r5.s64 = 0;
	// lwz r3,100(r1)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r1.u32 + 100);
	// bl 0x8b0bfc38
	ctx.lr = 0x8B0944EC;
	sub_8B0BFC38(ctx, base);
	// cmpwi cr6,r3,1
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 1, ctx.xer);
	// bne cr6,0x8b0944f8
	if (!ctx.cr6.eq) goto loc_8B0944F8;
	// lwz r28,0(r31)
	ctx.r28.u64 = REX_LOAD_U32(ctx.r31.u32 + 0);
loc_8B0944F8:
	// addi r31,r31,4
	ctx.r31.s64 = ctx.r31.s64 + 4;
	// cmplw cr6,r31,r24
	ctx.cr6.compare<uint32_t>(ctx.r31.u32, ctx.r24.u32, ctx.xer);
	// blt cr6,0x8b0944b0
	if (ctx.cr6.lt) goto loc_8B0944B0;
	// cmplwi cr6,r28,0
	ctx.cr6.compare<uint32_t>(ctx.r28.u32, 0, ctx.xer);
	// bne cr6,0x8b094518
	if (!ctx.cr6.eq) goto loc_8B094518;
	// lwz r28,-4(r24)
	ctx.r28.u64 = REX_LOAD_U32(ctx.r24.u32 + -4);
	// cmplwi cr6,r28,0
	ctx.cr6.compare<uint32_t>(ctx.r28.u32, 0, ctx.xer);
	// beq cr6,0x8b0945a8
	if (ctx.cr6.eq) goto loc_8B0945A8;
loc_8B094518:
	// cmplwi cr6,r29,4
	ctx.cr6.compare<uint32_t>(ctx.r29.u32, 4, ctx.xer);
	// bne cr6,0x8b094538
	if (!ctx.cr6.eq) goto loc_8B094538;
	// mr r4,r20
	ctx.r4.u64 = ctx.r20.u64;
	// lwz r5,104(r1)
	ctx.r5.u64 = REX_LOAD_U32(ctx.r1.u32 + 104);
	// mr r3,r28
	ctx.r3.u64 = ctx.r28.u64;
	// bl 0x8b0c0010
	ctx.lr = 0x8B094530;
	sub_8B0C0010(ctx, base);
	// addi r1,r1,832
	ctx.r1.s64 = ctx.r1.s64 + 832;
	// b 0x8b0cb9d0
	__restgprlr_14(ctx, base);
	return;
loc_8B094538:
	// cmpwi cr6,r29,1
	ctx.cr6.compare<int32_t>(ctx.r29.s32, 1, ctx.xer);
	// bne cr6,0x8b0945a8
	if (!ctx.cr6.eq) goto loc_8B0945A8;
	// li r4,3
	ctx.r4.s64 = 3;
	// li r3,0
	ctx.r3.s64 = 0;
	// bl 0x8b0df558
	ctx.lr = 0x8B09454C;
	sub_8B0DF558(ctx, base);
	// addi r9,r1,80
	ctx.r9.s64 = ctx.r1.s64 + 80;
	// mr r11,r3
	ctx.r11.u64 = ctx.r3.u64;
	// rlwinm r10,r3,2,0,29
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r3.u32 | (ctx.r3.u64 << 32), 2) & 0xFFFFFFFC;
loc_8B094558:
	// lwzx r10,r10,r9
	ctx.r10.u64 = REX_LOAD_U32(ctx.r10.u32 + ctx.r9.u32);
	// cmpwi cr6,r10,0
	ctx.cr6.compare<int32_t>(ctx.r10.s32, 0, ctx.xer);
	// bne cr6,0x8b094578
	if (!ctx.cr6.eq) goto loc_8B094578;
	// addi r11,r11,1
	ctx.r11.s64 = ctx.r11.s64 + 1;
	// clrlwi r11,r11,30
	ctx.r11.u64 = ctx.r11.u32 & 0x3;
	// cmpw cr6,r11,r3
	ctx.cr6.compare<int32_t>(ctx.r11.s32, ctx.r3.s32, ctx.xer);
	// rlwinm r10,r11,2,0,29
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 2) & 0xFFFFFFFC;
	// bne cr6,0x8b094558
	if (!ctx.cr6.eq) goto loc_8B094558;
loc_8B094578:
	// rlwinm r31,r11,2,0,29
	ctx.r31.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 2) & 0xFFFFFFFC;
	// addi r29,r1,80
	ctx.r29.s64 = ctx.r1.s64 + 80;
	// lwzx r30,r31,r29
	ctx.r30.u64 = REX_LOAD_U32(ctx.r31.u32 + ctx.r29.u32);
	// cmpwi cr6,r30,0
	ctx.cr6.compare<int32_t>(ctx.r30.s32, 0, ctx.xer);
	// beq cr6,0x8b0945a8
	if (ctx.cr6.eq) goto loc_8B0945A8;
	// addi r11,r1,128
	ctx.r11.s64 = ctx.r1.s64 + 128;
	// mr r4,r20
	ctx.r4.u64 = ctx.r20.u64;
	// mr r3,r28
	ctx.r3.u64 = ctx.r28.u64;
	// lwzx r5,r31,r11
	ctx.r5.u64 = REX_LOAD_U32(ctx.r31.u32 + ctx.r11.u32);
	// bl 0x8b0c0010
	ctx.lr = 0x8B0945A0;
	sub_8B0C0010(ctx, base);
	// addi r10,r30,-1
	ctx.r10.s64 = ctx.r30.s64 + -1;
	// stwx r10,r31,r29
	REX_STORE_U32(ctx.r31.u32 + ctx.r29.u32, ctx.r10.u32);
loc_8B0945A8:
	// addi r1,r1,832
	ctx.r1.s64 = ctx.r1.s64 + 832;
	// b 0x8b0cb9d0
	__restgprlr_14(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0964B0) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// std r30,-24(r1)
	REX_STORE_U64(ctx.r1.u32 + -24, ctx.r30.u64);
	// std r31,-16(r1)
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.r31.u64);
	// stwu r1,-112(r1)
	ea = -112 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// addi r10,r11,8692
	ctx.r10.s64 = ctx.r11.s64 + 8692;
	// li r30,0
	ctx.r30.s64 = 0;
	// stw r10,0(r3)
	REX_STORE_U32(ctx.r3.u32 + 0, ctx.r10.u32);
	// addi r11,r3,4
	ctx.r11.s64 = ctx.r3.s64 + 4;
	// stw r30,4(r3)
	REX_STORE_U32(ctx.r3.u32 + 4, ctx.r30.u32);
	// li r6,1
	ctx.r6.s64 = 1;
	// stw r30,8(r3)
	REX_STORE_U32(ctx.r3.u32 + 8, ctx.r30.u32);
	// li r5,32
	ctx.r5.s64 = 32;
	// stw r30,12(r3)
	REX_STORE_U32(ctx.r3.u32 + 12, ctx.r30.u32);
	// li r4,0
	ctx.r4.s64 = 0;
	// stw r30,16(r31)
	REX_STORE_U32(ctx.r31.u32 + 16, ctx.r30.u32);
	// addi r3,r11,16
	ctx.r3.s64 = ctx.r11.s64 + 16;
	// bl 0x8b0c5a08
	ctx.lr = 0x8B096500;
	sub_8B0C5A08(ctx, base);
	// li r10,9
	ctx.r10.s64 = 9;
	// addi r11,r31,68
	ctx.r11.s64 = ctx.r31.s64 + 68;
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
loc_8B09650C:
	// stwu r30,4(r11)
	ea = 4 + ctx.r11.u32;
	REX_STORE_U32(ea, ctx.r30.u32);
	ctx.r11.u32 = ea;
	// bdnz 0x8b09650c
	--ctx.ctr.u64;
	if (ctx.ctr.u32 != 0) goto loc_8B09650C;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// addi r1,r1,112
	ctx.r1.s64 = ctx.r1.s64 + 112;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// ld r30,-24(r1)
	ctx.r30.u64 = REX_LOAD_U64(ctx.r1.u32 + -24);
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0965B0) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9bc
	ctx.lr = 0x8B0965B8;
	__savegprlr_29(ctx, base);
	// stwu r1,-112(r1)
	ea = -112 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// mr r30,r3
	ctx.r30.u64 = ctx.r3.u64;
	// mr r31,r4
	ctx.r31.u64 = ctx.r4.u64;
	// mr r29,r5
	ctx.r29.u64 = ctx.r5.u64;
	// cmplwi cr6,r4,0
	ctx.cr6.compare<uint32_t>(ctx.r4.u32, 0, ctx.xer);
	// beq cr6,0x8b096608
	if (ctx.cr6.eq) goto loc_8B096608;
	// cmplwi cr6,r5,0
	ctx.cr6.compare<uint32_t>(ctx.r5.u32, 0, ctx.xer);
	// beq cr6,0x8b096608
	if (ctx.cr6.eq) goto loc_8B096608;
	// addi r3,r3,4
	ctx.r3.s64 = ctx.r3.s64 + 4;
	// bl 0x8b096530
	ctx.lr = 0x8B0965E0;
	sub_8B096530(ctx, base);
	// lwz r11,4(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 4);
	// cmpwi cr6,r11,0
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// bgt cr6,0x8b0965f0
	if (ctx.cr6.gt) goto loc_8B0965F0;
	// stw r29,0(r3)
	REX_STORE_U32(ctx.r3.u32 + 0, ctx.r29.u32);
loc_8B0965F0:
	// addi r11,r11,1
	ctx.r11.s64 = ctx.r11.s64 + 1;
	// mr r5,r29
	ctx.r5.u64 = ctx.r29.u64;
	// stw r11,4(r3)
	REX_STORE_U32(ctx.r3.u32 + 4, ctx.r11.u32);
	// mr r4,r31
	ctx.r4.u64 = ctx.r31.u64;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// bl 0x8b096360
	ctx.lr = 0x8B096608;
	sub_8B096360(ctx, base);
loc_8B096608:
	// addi r1,r1,112
	ctx.r1.s64 = ctx.r1.s64 + 112;
	// b 0x8b0cba0c
	__restgprlr_29(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B096690) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// stwu r1,-96(r1)
	ea = -96 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// addi r3,r3,4
	ctx.r3.s64 = ctx.r3.s64 + 4;
	// bl 0x8b096530
	ctx.lr = 0x8B0966A4;
	sub_8B096530(ctx, base);
	// lwz r11,4(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 4);
	// cmpwi cr6,r11,0
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// ble cr6,0x8b0966bc
	if (!ctx.cr6.gt) goto loc_8B0966BC;
	// lwz r3,0(r3)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// bne cr6,0x8b0966c0
	if (!ctx.cr6.eq) goto loc_8B0966C0;
loc_8B0966BC:
	// li r3,0
	ctx.r3.s64 = 0;
loc_8B0966C0:
	// addi r1,r1,96
	ctx.r1.s64 = ctx.r1.s64 + 96;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0967D0) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9b4
	ctx.lr = 0x8B0967D8;
	__savegprlr_27(ctx, base);
	// stwu r1,-144(r1)
	ea = -144 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// mulli r11,r4,56
	ctx.r11.s64 = static_cast<int64_t>(ctx.r4.u64 * static_cast<uint64_t>(56));
	// add r11,r11,r3
	ctx.r11.u64 = ctx.r11.u64 + ctx.r3.u64;
	// mr r28,r3
	ctx.r28.u64 = ctx.r3.u64;
	// addi r31,r11,48
	ctx.r31.s64 = ctx.r11.s64 + 48;
	// mr r30,r4
	ctx.r30.u64 = ctx.r4.u64;
	// addi r29,r31,16
	ctx.r29.s64 = ctx.r31.s64 + 16;
	// lwz r11,64(r11)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r11.u32 + 64);
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// bne cr6,0x8b0968f8
	if (!ctx.cr6.eq) goto loc_8B0968F8;
	// li r27,0
	ctx.r27.s64 = 0;
	// addi r4,r31,48
	ctx.r4.s64 = ctx.r31.s64 + 48;
	// stw r27,12(r31)
	REX_STORE_U32(ctx.r31.u32 + 12, ctx.r27.u32);
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// stw r27,80(r1)
	REX_STORE_U32(ctx.r1.u32 + 80, ctx.r27.u32);
	// bl 0x8b0955b0
	ctx.lr = 0x8B096818;
	sub_8B0955B0(ctx, base);
	// lis r11,-29938
	ctx.r11.s64 = -1962016768;
	// mr r8,r29
	ctx.r8.u64 = ctx.r29.u64;
	// lwz r5,12(r31)
	ctx.r5.u64 = REX_LOAD_U32(ctx.r31.u32 + 12);
	// addi r7,r1,80
	ctx.r7.s64 = ctx.r1.s64 + 80;
	// li r6,100
	ctx.r6.s64 = 100;
	// mr r4,r30
	ctx.r4.u64 = ctx.r30.u64;
	// lwz r11,2364(r11)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r11.u32 + 2364);
	// lwz r3,104(r11)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r11.u32 + 104);
	// lwz r10,0(r3)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r9,8(r10)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r10.u32 + 8);
	// mtctr r9
	ctx.ctr.u64 = ctx.r9.u64;
	// bctrl 
	ctx.lr = 0x8B096848;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// bne cr6,0x8b0968d0
	if (!ctx.cr6.eq) goto loc_8B0968D0;
	// lwz r11,80(r1)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r1.u32 + 80);
	// lwz r10,8(r31)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r31.u32 + 8);
	// cmplw cr6,r11,r10
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, ctx.r10.u32, ctx.xer);
	// ble cr6,0x8b096880
	if (!ctx.cr6.gt) goto loc_8B096880;
	// lwz r3,4(r31)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r31.u32 + 4);
	// bl 0x8b090020
	ctx.lr = 0x8B09686C;
	sub_8B090020(ctx, base);
	// lwz r3,80(r1)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r1.u32 + 80);
	// bl 0x8b090000
	ctx.lr = 0x8B096874;
	sub_8B090000(ctx, base);
	// lwz r11,80(r1)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r1.u32 + 80);
	// stw r3,4(r31)
	REX_STORE_U32(ctx.r31.u32 + 4, ctx.r3.u32);
	// stw r11,8(r31)
	REX_STORE_U32(ctx.r31.u32 + 8, ctx.r11.u32);
loc_8B096880:
	// addi r7,r31,20
	ctx.r7.s64 = ctx.r31.s64 + 20;
	// lwz r5,8(r31)
	ctx.r5.u64 = REX_LOAD_U32(ctx.r31.u32 + 8);
	// li r6,0
	ctx.r6.s64 = 0;
	// lwz r4,4(r31)
	ctx.r4.u64 = REX_LOAD_U32(ctx.r31.u32 + 4);
	// lwz r3,0(r29)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r29.u32 + 0);
	// bl 0x8b0dbe58
	ctx.lr = 0x8B096898;
	sub_8B0DBE58(ctx, base);
	// cmplwi cr6,r3,997
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 997, ctx.xer);
	// bne cr6,0x8b0968bc
	if (!ctx.cr6.eq) goto loc_8B0968BC;
	// li r11,1
	ctx.r11.s64 = 1;
	// stb r11,0(r31)
	REX_STORE_U8(ctx.r31.u32 + 0, ctx.r11.u8);
	// lwz r11,284(r28)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r28.u32 + 284);
	// addi r10,r11,1
	ctx.r10.s64 = ctx.r11.s64 + 1;
	// stw r10,284(r28)
	REX_STORE_U32(ctx.r28.u32 + 284, ctx.r10.u32);
	// addi r1,r1,144
	ctx.r1.s64 = ctx.r1.s64 + 144;
	// b 0x8b0cba04
	__restgprlr_27(ctx, base);
	return;
loc_8B0968BC:
	// lwz r3,0(r29)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r29.u32 + 0);
	// bl 0x8b0dbe10
	ctx.lr = 0x8B0968C4;
	sub_8B0DBE10(ctx, base);
	// stw r27,0(r29)
	REX_STORE_U32(ctx.r29.u32 + 0, ctx.r27.u32);
	// addi r1,r1,144
	ctx.r1.s64 = ctx.r1.s64 + 144;
	// b 0x8b0cba04
	__restgprlr_27(ctx, base);
	return;
loc_8B0968D0:
	// lis r10,-29938
	ctx.r10.s64 = -1962016768;
	// lwz r11,17204(r10)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r10.u32 + 17204);
	// cmpwi cr6,r11,5
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 5, ctx.xer);
	// bge cr6,0x8b0968f4
	if (!ctx.cr6.lt) goto loc_8B0968F4;
	// addi r11,r11,1
	ctx.r11.s64 = ctx.r11.s64 + 1;
	// lis r9,-29944
	ctx.r9.s64 = -1962409984;
	// stw r11,17204(r10)
	REX_STORE_U32(ctx.r10.u32 + 17204, ctx.r11.u32);
	// addi r3,r9,8712
	ctx.r3.s64 = ctx.r9.s64 + 8712;
	// bl 0x8b0df2e8
	ctx.lr = 0x8B0968F4;
	sub_8B0DF2E8(ctx, base);
loc_8B0968F4:
	// stw r27,0(r29)
	REX_STORE_U32(ctx.r29.u32 + 0, ctx.r27.u32);
loc_8B0968F8:
	// addi r1,r1,144
	ctx.r1.s64 = ctx.r1.s64 + 144;
	// b 0x8b0cba04
	__restgprlr_27(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B096D40) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb998
	ctx.lr = 0x8B096D48;
	__savegprlr_20(ctx, base);
	// stwu r1,-512(r1)
	ea = -512 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// mr r25,r3
	ctx.r25.u64 = ctx.r3.u64;
	// mr r27,r4
	ctx.r27.u64 = ctx.r4.u64;
	// mr r3,r4
	ctx.r3.u64 = ctx.r4.u64;
	// addi r5,r11,1791
	ctx.r5.s64 = ctx.r11.s64 + 1791;
	// addi r4,r10,8928
	ctx.r4.s64 = ctx.r10.s64 + 8928;
	// bl 0x8b0c1588
	ctx.lr = 0x8B096D6C;
	sub_8B0C1588(ctx, base);
	// lis r9,-29944
	ctx.r9.s64 = -1962409984;
	// mr r24,r3
	ctx.r24.u64 = ctx.r3.u64;
	// addi r4,r9,8916
	ctx.r4.s64 = ctx.r9.s64 + 8916;
	// li r5,0
	ctx.r5.s64 = 0;
	// mr r3,r27
	ctx.r3.u64 = ctx.r27.u64;
	// bl 0x8b0bfc38
	ctx.lr = 0x8B096D84;
	sub_8B0BFC38(ctx, base);
	// lis r8,-29944
	ctx.r8.s64 = -1962409984;
	// mr r22,r3
	ctx.r22.u64 = ctx.r3.u64;
	// addi r3,r8,8908
	ctx.r3.s64 = ctx.r8.s64 + 8908;
	// mr r4,r24
	ctx.r4.u64 = ctx.r24.u64;
	// li r21,0
	ctx.r21.s64 = 0;
	// bl 0x8b0cea10
	ctx.lr = 0x8B096D9C;
	sub_8B0CEA10(ctx, base);
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// li r28,-1
	ctx.r28.s64 = -1;
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// addi r23,r11,8900
	ctx.r23.s64 = ctx.r11.s64 + 8900;
	// bne cr6,0x8b096e34
	if (!ctx.cr6.eq) goto loc_8B096E34;
	// li r29,0
	ctx.r29.s64 = 0;
	// cmpwi cr6,r22,0
	ctx.cr6.compare<int32_t>(ctx.r22.s32, 0, ctx.xer);
	// ble cr6,0x8b096e34
	if (!ctx.cr6.gt) goto loc_8B096E34;
loc_8B096DBC:
	// mr r4,r23
	ctx.r4.u64 = ctx.r23.u64;
	// mr r5,r29
	ctx.r5.u64 = ctx.r29.u64;
	// addi r3,r1,144
	ctx.r3.s64 = ctx.r1.s64 + 144;
	// bl 0x8b090220
	ctx.lr = 0x8B096DCC;
	sub_8B090220(ctx, base);
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// li r5,0
	ctx.r5.s64 = 0;
	// mr r3,r27
	ctx.r3.u64 = ctx.r27.u64;
	// bl 0x8b0bfc38
	ctx.lr = 0x8B096DDC;
	sub_8B0BFC38(ctx, base);
	// mr r4,r28
	ctx.r4.u64 = ctx.r28.u64;
	// mr r30,r3
	ctx.r30.u64 = ctx.r3.u64;
	// bl 0x8b0df348
	ctx.lr = 0x8B096DE8;
	sub_8B0DF348(ctx, base);
	// li r31,0
	ctx.r31.s64 = 0;
	// bl 0x8b0df2c8
	ctx.lr = 0x8B096DF0;
	sub_8B0DF2C8(ctx, base);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b096e28
	if (ctx.cr6.eq) goto loc_8B096E28;
loc_8B096DF8:
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0df2b8
	ctx.lr = 0x8B096E00;
	sub_8B0DF2B8(ctx, base);
	// cmpw cr6,r30,r3
	ctx.cr6.compare<int32_t>(ctx.r30.s32, ctx.r3.s32, ctx.xer);
	// bne cr6,0x8b096e18
	if (!ctx.cr6.eq) goto loc_8B096E18;
	// bl 0x8b0df338
	ctx.lr = 0x8B096E0C;
	sub_8B0DF338(ctx, base);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// bne cr6,0x8b096e18
	if (!ctx.cr6.eq) goto loc_8B096E18;
	// li r21,1
	ctx.r21.s64 = 1;
loc_8B096E18:
	// addi r31,r31,1
	ctx.r31.s64 = ctx.r31.s64 + 1;
	// bl 0x8b0df2c8
	ctx.lr = 0x8B096E20;
	sub_8B0DF2C8(ctx, base);
	// cmplw cr6,r31,r3
	ctx.cr6.compare<uint32_t>(ctx.r31.u32, ctx.r3.u32, ctx.xer);
	// blt cr6,0x8b096df8
	if (ctx.cr6.lt) goto loc_8B096DF8;
loc_8B096E28:
	// addi r29,r29,1
	ctx.r29.s64 = ctx.r29.s64 + 1;
	// cmpw cr6,r29,r22
	ctx.cr6.compare<int32_t>(ctx.r29.s32, ctx.r22.s32, ctx.xer);
	// blt cr6,0x8b096dbc
	if (ctx.cr6.lt) goto loc_8B096DBC;
loc_8B096E34:
	// li r31,0
	ctx.r31.s64 = 0;
loc_8B096E38:
	// addi r5,r1,96
	ctx.r5.s64 = ctx.r1.s64 + 96;
	// li r4,2
	ctx.r4.s64 = 2;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0dbdc8
	ctx.lr = 0x8B096E48;
	sub_8B0DBDC8(ctx, base);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// bne cr6,0x8b096e5c
	if (!ctx.cr6.eq) goto loc_8B096E5C;
	// ld r11,96(r1)
	ctx.r11.u64 = REX_LOAD_U64(ctx.r1.u32 + 96);
	// cmpldi cr6,r11,0
	ctx.cr6.compare<uint64_t>(ctx.r11.u64, 0, ctx.xer);
	// bne cr6,0x8b096e68
	if (!ctx.cr6.eq) goto loc_8B096E68;
loc_8B096E5C:
	// mr r4,r28
	ctx.r4.u64 = ctx.r28.u64;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0df348
	ctx.lr = 0x8B096E68;
	sub_8B0DF348(ctx, base);
loc_8B096E68:
	// addi r31,r31,1
	ctx.r31.s64 = ctx.r31.s64 + 1;
	// cmpwi cr6,r31,4
	ctx.cr6.compare<int32_t>(ctx.r31.s32, 4, ctx.xer);
	// blt cr6,0x8b096e38
	if (ctx.cr6.lt) goto loc_8B096E38;
	// li r26,0
	ctx.r26.s64 = 0;
	// li r28,0
	ctx.r28.s64 = 0;
	// bl 0x8b0df2c8
	ctx.lr = 0x8B096E80;
	sub_8B0DF2C8(ctx, base);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b096f54
	if (ctx.cr6.eq) goto loc_8B096F54;
	// bl 0x8b0df338
	ctx.lr = 0x8B096E8C;
	sub_8B0DF338(ctx, base);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// bne cr6,0x8b096f54
	if (!ctx.cr6.eq) goto loc_8B096F54;
	// clrlwi r11,r21,24
	ctx.r11.u64 = ctx.r21.u32 & 0xFF;
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// bne cr6,0x8b096f54
	if (!ctx.cr6.eq) goto loc_8B096F54;
	// li r29,0
	ctx.r29.s64 = 0;
	// bl 0x8b0df2c8
	ctx.lr = 0x8B096EA8;
	sub_8B0DF2C8(ctx, base);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b096f54
	if (ctx.cr6.eq) goto loc_8B096F54;
loc_8B096EB0:
	// mr r3,r29
	ctx.r3.u64 = ctx.r29.u64;
	// bl 0x8b0df2b8
	ctx.lr = 0x8B096EB8;
	sub_8B0DF2B8(ctx, base);
	// mr r30,r3
	ctx.r30.u64 = ctx.r3.u64;
	// bl 0x8b095438
	ctx.lr = 0x8B096EC0;
	sub_8B095438(ctx, base);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b096f50
	if (ctx.cr6.eq) goto loc_8B096F50;
	// lwz r11,0(r25)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r25.u32 + 0);
	// mr r4,r30
	ctx.r4.u64 = ctx.r30.u64;
	// mr r3,r25
	ctx.r3.u64 = ctx.r25.u64;
	// lwz r10,4(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 4);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B096EE0;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b096f3c
	if (ctx.cr6.eq) goto loc_8B096F3C;
	// lwz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r10,12(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 12);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B096EFC;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// mr r20,r3
	ctx.r20.u64 = ctx.r3.u64;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b09c0d8
	ctx.lr = 0x8B096F08;
	sub_8B09C0D8(ctx, base);
	// cmpwi cr6,r20,2
	ctx.cr6.compare<int32_t>(ctx.r20.s32, 2, ctx.xer);
	// bne cr6,0x8b096f3c
	if (!ctx.cr6.eq) goto loc_8B096F3C;
	// lwz r11,0(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 0);
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// lwz r10,12(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 12);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B096F24;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// cmpwi cr6,r3,2
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 2, ctx.xer);
	// beq cr6,0x8b096f3c
	if (ctx.cr6.eq) goto loc_8B096F3C;
	// mr r4,r30
	ctx.r4.u64 = ctx.r30.u64;
	// mr r3,r25
	ctx.r3.u64 = ctx.r25.u64;
	// li r28,1
	ctx.r28.s64 = 1;
	// bl 0x8b096c70
	ctx.lr = 0x8B096F3C;
	sub_8B096C70(ctx, base);
loc_8B096F3C:
	// addi r29,r29,1
	ctx.r29.s64 = ctx.r29.s64 + 1;
	// bl 0x8b0df2c8
	ctx.lr = 0x8B096F44;
	sub_8B0DF2C8(ctx, base);
	// cmplw cr6,r29,r3
	ctx.cr6.compare<uint32_t>(ctx.r29.u32, ctx.r3.u32, ctx.xer);
	// blt cr6,0x8b096eb0
	if (ctx.cr6.lt) goto loc_8B096EB0;
	// b 0x8b096f54
	goto loc_8B096F54;
loc_8B096F50:
	// li r26,1
	ctx.r26.s64 = 1;
loc_8B096F54:
	// bl 0x8b0df328
	ctx.lr = 0x8B096F58;
	sub_8B0DF328(ctx, base);
	// cmpwi cr6,r3,-1
	ctx.cr6.compare<int32_t>(ctx.r3.s32, -1, ctx.xer);
	// beq cr6,0x8b096f94
	if (ctx.cr6.eq) goto loc_8B096F94;
	// bl 0x8b0df328
	ctx.lr = 0x8B096F64;
	sub_8B0DF328(ctx, base);
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// bl 0x8b095438
	ctx.lr = 0x8B096F6C;
	sub_8B095438(ctx, base);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b096f94
	if (ctx.cr6.eq) goto loc_8B096F94;
	// cmplwi cr6,r3,2
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 2, ctx.xer);
	// bne cr6,0x8b096f94
	if (!ctx.cr6.eq) goto loc_8B096F94;
	// li r11,0
	ctx.r11.s64 = 0;
	// addi r5,r1,80
	ctx.r5.s64 = ctx.r1.s64 + 80;
	// stw r11,80(r1)
	REX_STORE_U32(ctx.r1.u32 + 80, ctx.r11.u32);
	// li r4,254
	ctx.r4.s64 = 254;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b095448
	ctx.lr = 0x8B096F94;
	sub_8B095448(ctx, base);
loc_8B096F94:
	// bl 0x8b0df2c8
	ctx.lr = 0x8B096F98;
	sub_8B0DF2C8(ctx, base);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b09706c
	if (ctx.cr6.eq) goto loc_8B09706C;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// mr r4,r24
	ctx.r4.u64 = ctx.r24.u64;
	// addi r3,r11,8892
	ctx.r3.s64 = ctx.r11.s64 + 8892;
	// bl 0x8b0cea10
	ctx.lr = 0x8B096FB0;
	sub_8B0CEA10(ctx, base);
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// bne cr6,0x8b09706c
	if (!ctx.cr6.eq) goto loc_8B09706C;
	// bl 0x8b0df338
	ctx.lr = 0x8B096FBC;
	sub_8B0DF338(ctx, base);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b09706c
	if (ctx.cr6.eq) goto loc_8B09706C;
	// li r30,0
	ctx.r30.s64 = 0;
	// cmpwi cr6,r22,0
	ctx.cr6.compare<int32_t>(ctx.r22.s32, 0, ctx.xer);
	// ble cr6,0x8b09706c
	if (!ctx.cr6.gt) goto loc_8B09706C;
loc_8B096FD0:
	// mr r4,r23
	ctx.r4.u64 = ctx.r23.u64;
	// mr r5,r30
	ctx.r5.u64 = ctx.r30.u64;
	// addi r3,r1,144
	ctx.r3.s64 = ctx.r1.s64 + 144;
	// bl 0x8b090220
	ctx.lr = 0x8B096FE0;
	sub_8B090220(ctx, base);
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// li r5,0
	ctx.r5.s64 = 0;
	// mr r3,r27
	ctx.r3.u64 = ctx.r27.u64;
	// bl 0x8b0bfc38
	ctx.lr = 0x8B096FF0;
	sub_8B0BFC38(ctx, base);
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// bl 0x8b0df318
	ctx.lr = 0x8B096FF8;
	sub_8B0DF318(ctx, base);
	// cmplw cr6,r31,r3
	ctx.cr6.compare<uint32_t>(ctx.r31.u32, ctx.r3.u32, ctx.xer);
	// bne cr6,0x8b097060
	if (!ctx.cr6.eq) goto loc_8B097060;
	// bl 0x8b0df318
	ctx.lr = 0x8B097004;
	sub_8B0DF318(ctx, base);
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// blt cr6,0x8b097050
	if (ctx.cr6.lt) goto loc_8B097050;
	// cmpwi cr6,r3,4
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 4, ctx.xer);
	// bge cr6,0x8b097050
	if (!ctx.cr6.lt) goto loc_8B097050;
	// bl 0x8b095438
	ctx.lr = 0x8B09701C;
	sub_8B095438(ctx, base);
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// beq cr6,0x8b097050
	if (ctx.cr6.eq) goto loc_8B097050;
	// addi r5,r1,96
	ctx.r5.s64 = ctx.r1.s64 + 96;
	// li r4,1
	ctx.r4.s64 = 1;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0dbdc8
	ctx.lr = 0x8B097034;
	sub_8B0DBDC8(ctx, base);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// bne cr6,0x8b097050
	if (!ctx.cr6.eq) goto loc_8B097050;
	// lwz r11,104(r1)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r1.u32 + 104);
	// rlwinm r10,r11,0,30,30
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 0) & 0x2;
	// li r11,1
	ctx.r11.s64 = 1;
	// cmplwi cr6,r10,0
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 0, ctx.xer);
	// beq cr6,0x8b097054
	if (ctx.cr6.eq) goto loc_8B097054;
loc_8B097050:
	// li r11,0
	ctx.r11.s64 = 0;
loc_8B097054:
	// clrlwi r11,r11,24
	ctx.r11.u64 = ctx.r11.u32 & 0xFF;
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// bne cr6,0x8b0970dc
	if (!ctx.cr6.eq) goto loc_8B0970DC;
loc_8B097060:
	// addi r30,r30,1
	ctx.r30.s64 = ctx.r30.s64 + 1;
	// cmpw cr6,r30,r22
	ctx.cr6.compare<int32_t>(ctx.r30.s32, ctx.r22.s32, ctx.xer);
	// blt cr6,0x8b096fd0
	if (ctx.cr6.lt) goto loc_8B096FD0;
loc_8B09706C:
	// bl 0x8b0df2c8
	ctx.lr = 0x8B097070;
	sub_8B0DF2C8(ctx, base);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b097084
	if (ctx.cr6.eq) goto loc_8B097084;
	// clrlwi r11,r21,24
	ctx.r11.u64 = ctx.r21.u32 & 0xFF;
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// bne cr6,0x8b097090
	if (!ctx.cr6.eq) goto loc_8B097090;
loc_8B097084:
	// clrlwi r11,r26,24
	ctx.r11.u64 = ctx.r26.u32 & 0xFF;
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// beq cr6,0x8b0972a8
	if (ctx.cr6.eq) goto loc_8B0972A8;
loc_8B097090:
	// lis r11,-29936
	ctx.r11.s64 = -1961885696;
	// lwz r3,-17796(r11)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r11.u32 + -17796);
	// lwz r10,0(r3)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r9,60(r10)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r10.u32 + 60);
	// mtctr r9
	ctx.ctr.u64 = ctx.r9.u64;
	// bctrl 
	ctx.lr = 0x8B0970A8;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// li r3,36
	ctx.r3.s64 = 36;
	// bl 0x8b0bf448
	ctx.lr = 0x8B0970B0;
	sub_8B0BF448(ctx, base);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b097214
	if (ctx.cr6.eq) goto loc_8B097214;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// lis r9,-29944
	ctx.r9.s64 = -1962409984;
	// addi r6,r11,8872
	ctx.r6.s64 = ctx.r11.s64 + 8872;
	// addi r5,r10,4500
	ctx.r5.s64 = ctx.r10.s64 + 4500;
	// addi r4,r9,8848
	ctx.r4.s64 = ctx.r9.s64 + 8848;
	// bl 0x8b0c1300
	ctx.lr = 0x8B0970D4;
	sub_8B0C1300(ctx, base);
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// b 0x8b097218
	goto loc_8B097218;
loc_8B0970DC:
	// lis r29,-29936
	ctx.r29.s64 = -1961885696;
	// lwz r3,-17796(r29)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r29.u32 + -17796);
	// lwz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r10,36(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 36);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B0970F4;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b097114
	if (ctx.cr6.eq) goto loc_8B097114;
	// lwz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r10,4(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 4);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B09710C;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// mr r30,r3
	ctx.r30.u64 = ctx.r3.u64;
	// b 0x8b097118
	goto loc_8B097118;
loc_8B097114:
	// li r30,0
	ctx.r30.s64 = 0;
loc_8B097118:
	// li r3,36
	ctx.r3.s64 = 36;
	// bl 0x8b0bf448
	ctx.lr = 0x8B097120;
	sub_8B0BF448(ctx, base);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b09714c
	if (ctx.cr6.eq) goto loc_8B09714C;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// lis r9,-29944
	ctx.r9.s64 = -1962409984;
	// addi r6,r11,8832
	ctx.r6.s64 = ctx.r11.s64 + 8832;
	// addi r5,r10,4500
	ctx.r5.s64 = ctx.r10.s64 + 4500;
	// addi r4,r9,8848
	ctx.r4.s64 = ctx.r9.s64 + 8848;
	// bl 0x8b0c1300
	ctx.lr = 0x8B097144;
	sub_8B0C1300(ctx, base);
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// b 0x8b097150
	goto loc_8B097150;
loc_8B09714C:
	// li r31,0
	ctx.r31.s64 = 0;
loc_8B097150:
	// cmplwi cr6,r30,0
	ctx.cr6.compare<uint32_t>(ctx.r30.u32, 0, ctx.xer);
	// beq cr6,0x8b09716c
	if (ctx.cr6.eq) goto loc_8B09716C;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// bl 0x8b0c0298
	ctx.lr = 0x8B097160;
	sub_8B0C0298(ctx, base);
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0bfc00
	ctx.lr = 0x8B09716C;
	sub_8B0BFC00(ctx, base);
loc_8B09716C:
	// lwz r3,-17796(r29)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r29.u32 + -17796);
	// lwz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r10,60(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 60);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B097180;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// lis r30,-29938
	ctx.r30.s64 = -1962016768;
	// mr r4,r31
	ctx.r4.u64 = ctx.r31.u64;
	// lwz r3,4480(r30)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r30.u32 + 4480);
	// lwz r9,0(r3)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r8,8(r9)
	ctx.r8.u64 = REX_LOAD_U32(ctx.r9.u32 + 8);
	// mtctr r8
	ctx.ctr.u64 = ctx.r8.u64;
	// bctrl 
	ctx.lr = 0x8B09719C;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// li r3,0
	ctx.r3.s64 = 0;
	// bl 0x8b0df308
	ctx.lr = 0x8B0971A4;
	sub_8B0DF308(ctx, base);
	// li r3,36
	ctx.r3.s64 = 36;
	// bl 0x8b0bf448
	ctx.lr = 0x8B0971AC;
	sub_8B0BF448(ctx, base);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0971f0
	if (ctx.cr6.eq) goto loc_8B0971F0;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// addi r5,r11,8820
	ctx.r5.s64 = ctx.r11.s64 + 8820;
	// addi r4,r10,8800
	ctx.r4.s64 = ctx.r10.s64 + 8800;
	// li r6,0
	ctx.r6.s64 = 0;
	// bl 0x8b0c1390
	ctx.lr = 0x8B0971CC;
	sub_8B0C1390(ctx, base);
	// lwz r11,4480(r30)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r30.u32 + 4480);
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// mr r3,r11
	ctx.r3.u64 = ctx.r11.u64;
	// lwz r10,0(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 0);
	// lwz r9,8(r10)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r10.u32 + 8);
	// mtctr r9
	ctx.ctr.u64 = ctx.r9.u64;
	// bctrl 
	ctx.lr = 0x8B0971E8;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// addi r1,r1,512
	ctx.r1.s64 = ctx.r1.s64 + 512;
	// b 0x8b0cb9e8
	__restgprlr_20(ctx, base);
	return;
loc_8B0971F0:
	// lwz r11,4480(r30)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r30.u32 + 4480);
	// li r4,0
	ctx.r4.s64 = 0;
	// mr r3,r11
	ctx.r3.u64 = ctx.r11.u64;
	// lwz r10,0(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 0);
	// lwz r9,8(r10)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r10.u32 + 8);
	// mtctr r9
	ctx.ctr.u64 = ctx.r9.u64;
	// bctrl 
	ctx.lr = 0x8B09720C;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// addi r1,r1,512
	ctx.r1.s64 = ctx.r1.s64 + 512;
	// b 0x8b0cb9e8
	__restgprlr_20(ctx, base);
	return;
loc_8B097214:
	// li r4,0
	ctx.r4.s64 = 0;
loc_8B097218:
	// lis r31,-29938
	ctx.r31.s64 = -1962016768;
	// lwz r3,4480(r31)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r31.u32 + 4480);
	// lwz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r10,8(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 8);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B097230;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// li r3,0
	ctx.r3.s64 = 0;
	// bl 0x8b0df308
	ctx.lr = 0x8B097238;
	sub_8B0DF308(ctx, base);
	// li r3,36
	ctx.r3.s64 = 36;
	// bl 0x8b0bf448
	ctx.lr = 0x8B097240;
	sub_8B0BF448(ctx, base);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b097284
	if (ctx.cr6.eq) goto loc_8B097284;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// addi r5,r11,8820
	ctx.r5.s64 = ctx.r11.s64 + 8820;
	// addi r4,r10,8800
	ctx.r4.s64 = ctx.r10.s64 + 8800;
	// li r6,0
	ctx.r6.s64 = 0;
	// bl 0x8b0c1390
	ctx.lr = 0x8B097260;
	sub_8B0C1390(ctx, base);
	// lwz r11,4480(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 4480);
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// mr r3,r11
	ctx.r3.u64 = ctx.r11.u64;
	// lwz r10,0(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 0);
	// lwz r9,8(r10)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r10.u32 + 8);
	// mtctr r9
	ctx.ctr.u64 = ctx.r9.u64;
	// bctrl 
	ctx.lr = 0x8B09727C;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// addi r1,r1,512
	ctx.r1.s64 = ctx.r1.s64 + 512;
	// b 0x8b0cb9e8
	__restgprlr_20(ctx, base);
	return;
loc_8B097284:
	// lwz r11,4480(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 4480);
	// li r4,0
	ctx.r4.s64 = 0;
	// mr r3,r11
	ctx.r3.u64 = ctx.r11.u64;
	// lwz r10,0(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 0);
	// lwz r9,8(r10)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r10.u32 + 8);
	// mtctr r9
	ctx.ctr.u64 = ctx.r9.u64;
	// bctrl 
	ctx.lr = 0x8B0972A0;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// addi r1,r1,512
	ctx.r1.s64 = ctx.r1.s64 + 512;
	// b 0x8b0cb9e8
	__restgprlr_20(ctx, base);
	return;
loc_8B0972A8:
	// clrlwi r11,r28,24
	ctx.r11.u64 = ctx.r28.u32 & 0xFF;
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// beq cr6,0x8b097388
	if (ctx.cr6.eq) goto loc_8B097388;
	// lwz r11,0(r25)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r25.u32 + 0);
	// mr r3,r25
	ctx.r3.u64 = ctx.r25.u64;
	// lbz r4,40(r25)
	ctx.r4.u64 = REX_LOAD_U8(ctx.r25.u32 + 40);
	// lwz r10,0(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 0);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B0972CC;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// lis r31,-29936
	ctx.r31.s64 = -1961885696;
	// lwz r3,-17796(r31)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r31.u32 + -17796);
	// lwz r9,0(r3)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r8,36(r9)
	ctx.r8.u64 = REX_LOAD_U32(ctx.r9.u32 + 36);
	// mtctr r8
	ctx.ctr.u64 = ctx.r8.u64;
	// bctrl 
	ctx.lr = 0x8B0972E4;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b097388
	if (ctx.cr6.eq) goto loc_8B097388;
	// lwz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r10,4(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 4);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B0972FC;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// lis r9,-29944
	ctx.r9.s64 = -1962409984;
	// lis r8,-29944
	ctx.r8.s64 = -1962409984;
	// addi r30,r9,5604
	ctx.r30.s64 = ctx.r9.s64 + 5604;
	// addi r4,r8,3720
	ctx.r4.s64 = ctx.r8.s64 + 3720;
	// mr r5,r30
	ctx.r5.u64 = ctx.r30.u64;
	// bl 0x8b0c1588
	ctx.lr = 0x8B097314;
	sub_8B0C1588(ctx, base);
	// mr r4,r30
	ctx.r4.u64 = ctx.r30.u64;
	// bl 0x8b0cea10
	ctx.lr = 0x8B09731C;
	sub_8B0CEA10(ctx, base);
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// bne cr6,0x8b097388
	if (!ctx.cr6.eq) goto loc_8B097388;
	// lwz r3,-17796(r31)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r31.u32 + -17796);
	// lwz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r10,60(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 60);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B097338;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// li r3,36
	ctx.r3.s64 = 36;
	// bl 0x8b0bf448
	ctx.lr = 0x8B097340;
	sub_8B0BF448(ctx, base);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b09736c
	if (ctx.cr6.eq) goto loc_8B09736C;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// lis r9,-29944
	ctx.r9.s64 = -1962409984;
	// addi r6,r11,8776
	ctx.r6.s64 = ctx.r11.s64 + 8776;
	// addi r5,r10,4500
	ctx.r5.s64 = ctx.r10.s64 + 4500;
	// addi r4,r9,4136
	ctx.r4.s64 = ctx.r9.s64 + 4136;
	// bl 0x8b0c1300
	ctx.lr = 0x8B097364;
	sub_8B0C1300(ctx, base);
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// b 0x8b097370
	goto loc_8B097370;
loc_8B09736C:
	// li r4,0
	ctx.r4.s64 = 0;
loc_8B097370:
	// lis r11,-29938
	ctx.r11.s64 = -1962016768;
	// lwz r3,4480(r11)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r11.u32 + 4480);
	// lwz r10,0(r3)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r9,8(r10)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r10.u32 + 8);
	// mtctr r9
	ctx.ctr.u64 = ctx.r9.u64;
	// bctrl 
	ctx.lr = 0x8B097388;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
loc_8B097388:
	// addi r1,r1,512
	ctx.r1.s64 = ctx.r1.s64 + 512;
	// b 0x8b0cb9e8
	__restgprlr_20(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B098B50) {
	REX_FUNC_PROLOGUE();
	PPCRegister temp{};
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9ac
	ctx.lr = 0x8B098B58;
	__savegprlr_25(ctx, base);
	// stwu r1,-240(r1)
	ea = -240 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// mr r25,r4
	ctx.r25.u64 = ctx.r4.u64;
	// mr r28,r5
	ctx.r28.u64 = ctx.r5.u64;
	// addi r5,r11,10100
	ctx.r5.s64 = ctx.r11.s64 + 10100;
	// addi r4,r10,4588
	ctx.r4.s64 = ctx.r10.s64 + 4588;
	// mr r26,r3
	ctx.r26.u64 = ctx.r3.u64;
	// mr r31,r6
	ctx.r31.u64 = ctx.r6.u64;
	// bl 0x8b0c1588
	ctx.lr = 0x8B098B80;
	sub_8B0C1588(ctx, base);
	// lis r9,-29944
	ctx.r9.s64 = -1962409984;
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// addi r3,r9,10084
	ctx.r3.s64 = ctx.r9.s64 + 10084;
	// bl 0x8b0cea10
	ctx.lr = 0x8B098B90;
	sub_8B0CEA10(ctx, base);
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// bne cr6,0x8b098ba8
	if (!ctx.cr6.eq) goto loc_8B098BA8;
	// rlwinm r11,r31,0,29,29
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r31.u32 | (ctx.r31.u64 << 32), 0) & 0x4;
	// subfic r10,r11,0
	ctx.xer.ca = ctx.r11.u32 <= 0;
	ctx.r10.u64 = static_cast<uint64_t>(0) - ctx.r11.u64;
	// subfe r8,r9,r9
	temp.u8 = (~ctx.r9.u32 + ctx.r9.u32 < ~ctx.r9.u32) | (~ctx.r9.u32 + ctx.r9.u32 + ctx.xer.ca < ctx.xer.ca);
	ctx.r8.u64 = ~ctx.r9.u64 + ctx.r9.u64 + ctx.xer.ca;
	ctx.xer.ca = temp.u8;
	// and r25,r8,r25
	ctx.r25.u64 = ctx.r8.u64 & ctx.r25.u64;
loc_8B098BA8:
	// lbz r11,1(r28)
	ctx.r11.u64 = REX_LOAD_U8(ctx.r28.u32 + 1);
	// addi r29,r28,2
	ctx.r29.s64 = ctx.r28.s64 + 2;
	// li r27,0
	ctx.r27.s64 = 0;
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// beq cr6,0x8b098bc4
	if (ctx.cr6.eq) goto loc_8B098BC4;
	// stw r29,772(r28)
	REX_STORE_U32(ctx.r28.u32 + 772, ctx.r29.u32);
	// b 0x8b098de4
	goto loc_8B098DE4;
loc_8B098BC4:
	// lis r11,-29938
	ctx.r11.s64 = -1962016768;
	// lis r10,-29938
	ctx.r10.s64 = -1962016768;
	// addi r6,r11,2996
	ctx.r6.s64 = ctx.r11.s64 + 2996;
	// addi r5,r10,2964
	ctx.r5.s64 = ctx.r10.s64 + 2964;
	// li r7,0
	ctx.r7.s64 = 0;
	// li r4,0
	ctx.r4.s64 = 0;
	// mr r3,r25
	ctx.r3.u64 = ctx.r25.u64;
	// bl 0x8b0ccd08
	ctx.lr = 0x8B098BE4;
	sub_8B0CCD08(ctx, base);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b098c50
	if (ctx.cr6.eq) goto loc_8B098C50;
	// li r10,7
	ctx.r10.s64 = 7;
	// addi r11,r1,112
	ctx.r11.s64 = ctx.r1.s64 + 112;
	// stb r27,112(r1)
	REX_STORE_U8(ctx.r1.u32 + 112, ctx.r27.u8);
	// mr r9,r27
	ctx.r9.u64 = ctx.r27.u64;
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
loc_8B098C00:
	// stbu r9,1(r11)
	ea = 1 + ctx.r11.u32;
	REX_STORE_U8(ea, ctx.r9.u8);
	ctx.r11.u32 = ea;
	// bdnz 0x8b098c00
	--ctx.ctr.u64;
	if (ctx.ctr.u32 != 0) goto loc_8B098C00;
	// li r9,6
	ctx.r9.s64 = 6;
	// addi r11,r1,112
	ctx.r11.s64 = ctx.r1.s64 + 112;
	// mr r10,r27
	ctx.r10.u64 = ctx.r27.u64;
	// mtctr r9
	ctx.ctr.u64 = ctx.r9.u64;
loc_8B098C18:
	// stdu r10,8(r11)
	ea = 8 + ctx.r11.u32;
	REX_STORE_U64(ea, ctx.r10.u64);
	ctx.r11.u32 = ea;
	// bdnz 0x8b098c18
	--ctx.ctr.u64;
	if (ctx.ctr.u32 != 0) goto loc_8B098C18;
	// stw r10,8(r11)
	REX_STORE_U32(ctx.r11.u32 + 8, ctx.r10.u32);
	// addi r4,r1,112
	ctx.r4.s64 = ctx.r1.s64 + 112;
	// bl 0x8b0a08d8
	ctx.lr = 0x8B098C2C;
	sub_8B0A08D8(ctx, base);
	// mr r29,r3
	ctx.r29.u64 = ctx.r3.u64;
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// bne cr6,0x8b098ddc
	if (!ctx.cr6.eq) goto loc_8B098DDC;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// addi r3,r11,10504
	ctx.r3.s64 = ctx.r11.s64 + 10504;
	// bl 0x8b0df2e8
	ctx.lr = 0x8B098C44;
	sub_8B0DF2E8(ctx, base);
	// li r3,0
	ctx.r3.s64 = 0;
	// addi r1,r1,240
	ctx.r1.s64 = ctx.r1.s64 + 240;
	// b 0x8b0cb9fc
	__restgprlr_25(ctx, base);
	return;
loc_8B098C50:
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// li r5,0
	ctx.r5.s64 = 0;
	// addi r4,r11,10484
	ctx.r4.s64 = ctx.r11.s64 + 10484;
	// mr r3,r26
	ctx.r3.u64 = ctx.r26.u64;
	// bl 0x8b0c1588
	ctx.lr = 0x8B098C64;
	sub_8B0C1588(ctx, base);
	// mr r30,r3
	ctx.r30.u64 = ctx.r3.u64;
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b098d34
	if (ctx.cr6.eq) goto loc_8B098D34;
	// li r10,7
	ctx.r10.s64 = 7;
	// addi r11,r1,112
	ctx.r11.s64 = ctx.r1.s64 + 112;
	// stb r27,112(r1)
	REX_STORE_U8(ctx.r1.u32 + 112, ctx.r27.u8);
	// mr r9,r27
	ctx.r9.u64 = ctx.r27.u64;
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
loc_8B098C84:
	// stbu r9,1(r11)
	ea = 1 + ctx.r11.u32;
	REX_STORE_U8(ea, ctx.r9.u8);
	ctx.r11.u32 = ea;
	// bdnz 0x8b098c84
	--ctx.ctr.u64;
	if (ctx.ctr.u32 != 0) goto loc_8B098C84;
	// li r9,6
	ctx.r9.s64 = 6;
	// addi r11,r1,112
	ctx.r11.s64 = ctx.r1.s64 + 112;
	// mr r10,r27
	ctx.r10.u64 = ctx.r27.u64;
	// mtctr r9
	ctx.ctr.u64 = ctx.r9.u64;
loc_8B098C9C:
	// stdu r10,8(r11)
	ea = 8 + ctx.r11.u32;
	REX_STORE_U64(ea, ctx.r10.u64);
	ctx.r11.u32 = ea;
	// bdnz 0x8b098c9c
	--ctx.ctr.u64;
	if (ctx.ctr.u32 != 0) goto loc_8B098C9C;
	// stw r10,8(r11)
	REX_STORE_U32(ctx.r11.u32 + 8, ctx.r10.u32);
	// mr r4,r30
	ctx.r4.u64 = ctx.r30.u64;
	// addi r3,r1,112
	ctx.r3.s64 = ctx.r1.s64 + 112;
	// bl 0x8b0994f8
	ctx.lr = 0x8B098CB4;
	sub_8B0994F8(ctx, base);
	// lis r31,-29938
	ctx.r31.s64 = -1962016768;
	// addi r5,r1,156
	ctx.r5.s64 = ctx.r1.s64 + 156;
	// addi r4,r1,112
	ctx.r4.s64 = ctx.r1.s64 + 112;
	// lwz r11,2364(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 2364);
	// lwz r3,104(r11)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r11.u32 + 104);
	// lwz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r10,60(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 60);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B098CD8;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// lwz r11,2364(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 2364);
	// addi r6,r1,80
	ctx.r6.s64 = ctx.r1.s64 + 80;
	// addi r5,r1,112
	ctx.r5.s64 = ctx.r1.s64 + 112;
	// addi r4,r1,120
	ctx.r4.s64 = ctx.r1.s64 + 120;
	// lwz r3,104(r11)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r11.u32 + 104);
	// lwz r9,0(r3)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r8,124(r9)
	ctx.r8.u64 = REX_LOAD_U32(ctx.r9.u32 + 124);
	// mtctr r8
	ctx.ctr.u64 = ctx.r8.u64;
	// bctrl 
	ctx.lr = 0x8B098CFC;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// beq cr6,0x8b098d40
	if (ctx.cr6.eq) goto loc_8B098D40;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// mr r5,r30
	ctx.r5.u64 = ctx.r30.u64;
	// addi r3,r11,10352
	ctx.r3.s64 = ctx.r11.s64 + 10352;
loc_8B098D14:
	// bl 0x8b0df2e8
	ctx.lr = 0x8B098D18;
	sub_8B0DF2E8(ctx, base);
	// lwz r11,2364(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 2364);
	// addi r4,r1,112
	ctx.r4.s64 = ctx.r1.s64 + 112;
	// lwz r3,104(r11)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r11.u32 + 104);
	// lwz r10,0(r3)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r9,64(r10)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r10.u32 + 64);
	// mtctr r9
	ctx.ctr.u64 = ctx.r9.u64;
	// bctrl 
	ctx.lr = 0x8B098D34;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
loc_8B098D34:
	// li r3,0
	ctx.r3.s64 = 0;
	// addi r1,r1,240
	ctx.r1.s64 = ctx.r1.s64 + 240;
	// b 0x8b0cb9fc
	__restgprlr_25(ctx, base);
	return;
loc_8B098D40:
	// lwz r11,2364(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 2364);
	// lwz r4,80(r1)
	ctx.r4.u64 = REX_LOAD_U32(ctx.r1.u32 + 80);
	// lwz r3,104(r11)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r11.u32 + 104);
	// lwz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r10,128(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 128);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B098D5C;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// beq cr6,0x8b098d78
	if (ctx.cr6.eq) goto loc_8B098D78;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// mr r5,r30
	ctx.r5.u64 = ctx.r30.u64;
	// addi r3,r11,10216
	ctx.r3.s64 = ctx.r11.s64 + 10216;
	// b 0x8b098d14
	goto loc_8B098D14;
loc_8B098D78:
	// addi r3,r1,88
	ctx.r3.s64 = ctx.r1.s64 + 88;
	// bl 0x8b0925c0
	ctx.lr = 0x8B098D80;
	sub_8B0925C0(ctx, base);
	// li r4,3
	ctx.r4.s64 = 3;
	// addi r3,r1,88
	ctx.r3.s64 = ctx.r1.s64 + 88;
	// bl 0x8b0c72b0
	ctx.lr = 0x8B098D8C;
	sub_8B0C72B0(ctx, base);
	// addi r3,r1,88
	ctx.r3.s64 = ctx.r1.s64 + 88;
	// lwz r4,80(r1)
	ctx.r4.u64 = REX_LOAD_U32(ctx.r1.u32 + 80);
	// bl 0x8b0c72a8
	ctx.lr = 0x8B098D98;
	sub_8B0C72A8(ctx, base);
	// li r4,0
	ctx.r4.s64 = 0;
	// addi r3,r1,88
	ctx.r3.s64 = ctx.r1.s64 + 88;
	// bl 0x8b0c72d0
	ctx.lr = 0x8B098DA4;
	sub_8B0C72D0(ctx, base);
	// li r4,1
	ctx.r4.s64 = 1;
	// addi r3,r1,88
	ctx.r3.s64 = ctx.r1.s64 + 88;
	// bl 0x8b0c7198
	ctx.lr = 0x8B098DB0;
	sub_8B0C7198(ctx, base);
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// mr r3,r29
	ctx.r3.u64 = ctx.r29.u64;
	// li r5,256
	ctx.r5.s64 = 256;
	// bl 0x8b0c3f18
	ctx.lr = 0x8B098DC0;
	sub_8B0C3F18(ctx, base);
	// addi r3,r28,258
	ctx.r3.s64 = ctx.r28.s64 + 258;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// stw r3,772(r28)
	REX_STORE_U32(ctx.r28.u32 + 772, ctx.r3.u32);
	// mr r6,r30
	ctx.r6.u64 = ctx.r30.u64;
	// addi r5,r11,10196
	ctx.r5.s64 = ctx.r11.s64 + 10196;
	// li r4,256
	ctx.r4.s64 = 256;
	// bl 0x8b0c3fd8
	ctx.lr = 0x8B098DDC;
	sub_8B0C3FD8(ctx, base);
loc_8B098DDC:
	// addi r3,r1,112
	ctx.r3.s64 = ctx.r1.s64 + 112;
	// bl 0x8b0987f8
	ctx.lr = 0x8B098DE4;
	sub_8B0987F8(ctx, base);
loc_8B098DE4:
	// bl 0x8b0df2c8
	ctx.lr = 0x8B098DE8;
	sub_8B0DF2C8(ctx, base);
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// mr r8,r3
	ctx.r8.u64 = ctx.r3.u64;
	// addi r5,r11,10164
	ctx.r5.s64 = ctx.r11.s64 + 10164;
	// mr r7,r29
	ctx.r7.u64 = ctx.r29.u64;
	// mr r6,r29
	ctx.r6.u64 = ctx.r29.u64;
	// li r4,256
	ctx.r4.s64 = 256;
	// addi r3,r28,514
	ctx.r3.s64 = ctx.r28.s64 + 514;
	// bl 0x8b0c3fd8
	ctx.lr = 0x8B098E08;
	sub_8B0C3FD8(ctx, base);
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// li r5,0
	ctx.r5.s64 = 0;
	// addi r4,r10,10152
	ctx.r4.s64 = ctx.r10.s64 + 10152;
	// mr r3,r26
	ctx.r3.u64 = ctx.r26.u64;
	// bl 0x8b0bfd30
	ctx.lr = 0x8B098E1C;
	sub_8B0BFD30(ctx, base);
	// std r3,776(r28)
	REX_STORE_U64(ctx.r28.u32 + 776, ctx.r3.u64);
	// lis r9,-29944
	ctx.r9.s64 = -1962409984;
	// li r5,0
	ctx.r5.s64 = 0;
	// addi r4,r9,10128
	ctx.r4.s64 = ctx.r9.s64 + 10128;
	// mr r3,r26
	ctx.r3.u64 = ctx.r26.u64;
	// bl 0x8b0bfd30
	ctx.lr = 0x8B098E34;
	sub_8B0BFD30(ctx, base);
	// cmpldi cr6,r3,0
	ctx.cr6.compare<uint64_t>(ctx.r3.u64, 0, ctx.xer);
	// bne cr6,0x8b098e4c
	if (!ctx.cr6.eq) goto loc_8B098E4C;
	// cmplwi cr6,r25,0
	ctx.cr6.compare<uint32_t>(ctx.r25.u32, 0, ctx.xer);
	// beq cr6,0x8b098e5c
	if (ctx.cr6.eq) goto loc_8B098E5C;
	// mr r3,r25
	ctx.r3.u64 = ctx.r25.u64;
	// bl 0x8b0a0ee0
	ctx.lr = 0x8B098E4C;
	sub_8B0A0EE0(ctx, base);
loc_8B098E4C:
	// std r3,784(r28)
	REX_STORE_U64(ctx.r28.u32 + 784, ctx.r3.u64);
	// li r3,1
	ctx.r3.s64 = 1;
	// addi r1,r1,240
	ctx.r1.s64 = ctx.r1.s64 + 240;
	// b 0x8b0cb9fc
	__restgprlr_25(ctx, base);
	return;
loc_8B098E5C:
	// std r27,784(r28)
	REX_STORE_U64(ctx.r28.u32 + 784, ctx.r27.u64);
	// li r3,1
	ctx.r3.s64 = 1;
	// addi r1,r1,240
	ctx.r1.s64 = ctx.r1.s64 + 240;
	// b 0x8b0cb9fc
	__restgprlr_25(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B099978) {
	REX_FUNC_PROLOGUE();
	// mr r10,r3
	ctx.r10.u64 = ctx.r3.u64;
	// li r3,0
	ctx.r3.s64 = 0;
	// cmplwi cr6,r10,0
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 0, ctx.xer);
	// beqlr cr6
	if (ctx.cr6.eq) return;
	// lwz r11,0(r10)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r10.u32 + 0);
	// cmplwi cr6,r4,0
	ctx.cr6.compare<uint32_t>(ctx.r4.u32, 0, ctx.xer);
	// beq cr6,0x8b0999b4
	if (ctx.cr6.eq) goto loc_8B0999B4;
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// beq cr6,0x8b0999b4
	if (ctx.cr6.eq) goto loc_8B0999B4;
	// lwz r9,0(r11)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r11.u32 + 0);
	// stw r9,0(r4)
	REX_STORE_U32(ctx.r4.u32 + 0, ctx.r9.u32);
	// lwz r8,4(r11)
	ctx.r8.u64 = REX_LOAD_U32(ctx.r11.u32 + 4);
	// stw r8,4(r4)
	REX_STORE_U32(ctx.r4.u32 + 4, ctx.r8.u32);
	// lwz r7,8(r11)
	ctx.r7.u64 = REX_LOAD_U32(ctx.r11.u32 + 8);
	// stw r7,8(r4)
	REX_STORE_U32(ctx.r4.u32 + 8, ctx.r7.u32);
loc_8B0999B4:
	// stw r4,0(r10)
	REX_STORE_U32(ctx.r10.u32 + 0, ctx.r4.u32);
	// mr r3,r11
	ctx.r3.u64 = ctx.r11.u64;
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0999C0) {
	REX_FUNC_PROLOGUE();
	// lis r11,-29938
	ctx.r11.s64 = -1962016768;
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// lwz r11,2364(r11)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r11.u32 + 2364);
	// lwz r3,104(r11)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r11.u32 + 104);
	// lwz r10,0(r3)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r9,4(r10)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r10.u32 + 4);
	// mtctr r9
	ctx.ctr.u64 = ctx.r9.u64;
	// bctr 
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	return;
}

DEFINE_REX_FUNC(sub_8B099BD0) {
	REX_FUNC_PROLOGUE();
	// lwz r11,16(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 16);
	// lwz r3,20(r3)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r3.u32 + 20);
	// mtctr r11
	ctx.ctr.u64 = ctx.r11.u64;
	// bctr 
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	return;
}

DEFINE_REX_FUNC(sub_8B099BE0) {
	REX_FUNC_PROLOGUE();
	// addi r3,r3,-8
	ctx.r3.s64 = ctx.r3.s64 + -8;
	// b 0x8b09a330
	sub_8B09A330(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B099BF0) {
	REX_FUNC_PROLOGUE();
	// addi r3,r3,8
	ctx.r3.s64 = ctx.r3.s64 + 8;
	// b 0x8b099b58
	sub_8B099B58(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B099CD0) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9b4
	ctx.lr = 0x8B099CD8;
	__savegprlr_27(ctx, base);
	// stwu r1,-128(r1)
	ea = -128 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// li r29,0
	ctx.r29.s64 = 0;
	// addi r30,r3,48
	ctx.r30.s64 = ctx.r3.s64 + 48;
	// mr r27,r4
	ctx.r27.u64 = ctx.r4.u64;
	// stw r29,8(r3)
	REX_STORE_U32(ctx.r3.u32 + 8, ctx.r29.u32);
	// li r5,144
	ctx.r5.s64 = 144;
	// li r4,0
	ctx.r4.s64 = 0;
	// std r29,40(r31)
	REX_STORE_U64(ctx.r31.u32 + 40, ctx.r29.u64);
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// bl 0x8b0cb8e0
	ctx.lr = 0x8B099D04;
	sub_8B0CB8E0(ctx, base);
	// li r10,7
	ctx.r10.s64 = 7;
	// addi r28,r31,12
	ctx.r28.s64 = ctx.r31.s64 + 12;
	// stw r29,192(r31)
	REX_STORE_U32(ctx.r31.u32 + 192, ctx.r29.u32);
	// addi r11,r28,-4
	ctx.r11.s64 = ctx.r28.s64 + -4;
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
loc_8B099D18:
	// stwu r29,4(r11)
	ea = 4 + ctx.r11.u32;
	REX_STORE_U32(ea, ctx.r29.u32);
	ctx.r11.u32 = ea;
	// bdnz 0x8b099d18
	--ctx.ctr.u64;
	if (ctx.ctr.u32 != 0) goto loc_8B099D18;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// addi r9,r11,11376
	ctx.r9.s64 = ctx.r11.s64 + 11376;
	// addi r8,r10,11368
	ctx.r8.s64 = ctx.r10.s64 + 11368;
	// stw r9,0(r31)
	REX_STORE_U32(ctx.r31.u32 + 0, ctx.r9.u32);
	// li r5,144
	ctx.r5.s64 = 144;
	// stw r8,4(r31)
	REX_STORE_U32(ctx.r31.u32 + 4, ctx.r8.u32);
	// mr r4,r27
	ctx.r4.u64 = ctx.r27.u64;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// bl 0x8b0cbb30
	ctx.lr = 0x8B099D48;
	sub_8B0CBB30(ctx, base);
	// lis r7,-29938
	ctx.r7.s64 = -1962016768;
	// mr r5,r28
	ctx.r5.u64 = ctx.r28.u64;
	// lwz r4,0(r30)
	ctx.r4.u64 = REX_LOAD_U32(ctx.r30.u32 + 0);
	// lwz r11,2364(r7)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r7.u32 + 2364);
	// lwz r3,104(r11)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r11.u32 + 104);
	// lwz r6,0(r3)
	ctx.r6.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r11,76(r6)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r6.u32 + 76);
	// mtctr r11
	ctx.ctr.u64 = ctx.r11.u64;
	// bctrl 
	ctx.lr = 0x8B099D6C;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// mr r30,r3
	ctx.r30.u64 = ctx.r3.u64;
	// cmplwi cr6,r3,997
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 997, ctx.xer);
	// beq cr6,0x8b099d98
	if (ctx.cr6.eq) goto loc_8B099D98;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// addi r3,r11,11324
	ctx.r3.s64 = ctx.r11.s64 + 11324;
	// bl 0x8b0df2e8
	ctx.lr = 0x8B099D88;
	sub_8B0DF2E8(ctx, base);
	// li r10,3
	ctx.r10.s64 = 3;
	// clrldi r9,r30,32
	ctx.r9.u64 = ctx.r30.u64 & 0xFFFFFFFF;
	// stw r10,8(r31)
	REX_STORE_U32(ctx.r31.u32 + 8, ctx.r10.u32);
	// std r9,40(r31)
	REX_STORE_U64(ctx.r31.u32 + 40, ctx.r9.u64);
loc_8B099D98:
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// addi r1,r1,128
	ctx.r1.s64 = ctx.r1.s64 + 128;
	// b 0x8b0cba04
	__restgprlr_27(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B099EF0) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// std r31,-16(r1)
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.r31.u64);
	// stwu r1,-96(r1)
	ea = -96 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// clrldi r11,r5,32
	ctx.r11.u64 = ctx.r5.u64 & 0xFFFFFFFF;
	// lwz r10,0(r3)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// std r11,40(r3)
	REX_STORE_U64(ctx.r3.u32 + 40, ctx.r11.u64);
	// lwz r9,4(r10)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r10.u32 + 4);
	// mtctr r9
	ctx.ctr.u64 = ctx.r9.u64;
	// bctrl 
	ctx.lr = 0x8B099F1C;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// cmpwi cr6,r3,4
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 4, ctx.xer);
	// bne cr6,0x8b099f54
	if (!ctx.cr6.eq) goto loc_8B099F54;
	// lis r11,-29938
	ctx.r11.s64 = -1962016768;
	// li r8,1
	ctx.r8.s64 = 1;
	// li r7,0
	ctx.r7.s64 = 0;
	// li r6,0
	ctx.r6.s64 = 0;
	// li r5,0
	ctx.r5.s64 = 0;
	// lwz r11,2364(r11)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r11.u32 + 2364);
	// addi r4,r31,64
	ctx.r4.s64 = ctx.r31.s64 + 64;
	// lwz r3,104(r11)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r11.u32 + 104);
	// lwz r10,0(r3)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r9,48(r10)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r10.u32 + 48);
	// mtctr r9
	ctx.ctr.u64 = ctx.r9.u64;
	// bctrl 
	ctx.lr = 0x8B099F54;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
loc_8B099F54:
	// addi r1,r1,96
	ctx.r1.s64 = ctx.r1.s64 + 96;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B09A180) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// std r31,-16(r1)
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.r31.u64);
	// stwu r1,-96(r1)
	ea = -96 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// addi r9,r11,11160
	ctx.r9.s64 = ctx.r11.s64 + 11160;
	// addi r8,r10,11152
	ctx.r8.s64 = ctx.r10.s64 + 11152;
	// clrlwi r7,r4,31
	ctx.r7.u64 = ctx.r4.u32 & 0x1;
	// stw r9,0(r3)
	REX_STORE_U32(ctx.r3.u32 + 0, ctx.r9.u32);
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// stw r8,4(r3)
	REX_STORE_U32(ctx.r3.u32 + 4, ctx.r8.u32);
	// cmplwi cr6,r7,0
	ctx.cr6.compare<uint32_t>(ctx.r7.u32, 0, ctx.xer);
	// beq cr6,0x8b09a1c0
	if (ctx.cr6.eq) goto loc_8B09A1C0;
	// bl 0x8b090020
	ctx.lr = 0x8B09A1BC;
	sub_8B090020(ctx, base);
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
loc_8B09A1C0:
	// addi r1,r1,96
	ctx.r1.s64 = ctx.r1.s64 + 96;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B09A240) {
	REX_FUNC_PROLOGUE();
	// lwz r11,200(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 200);
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// beq cr6,0x8b09a260
	if (ctx.cr6.eq) goto loc_8B09A260;
	// rotlwi r3,r11,0
	ctx.r3.u64 = __builtin_rotateleft32(ctx.r11.u32, 0);
	// lwz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r10,8(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 8);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctr 
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	return;
loc_8B09A260:
	// ld r3,40(r3)
	ctx.r3.u64 = REX_LOAD_U64(ctx.r3.u32 + 40);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B09A290) {
	REX_FUNC_PROLOGUE();
	// lwz r11,200(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 200);
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// beq cr6,0x8b09a2b0
	if (ctx.cr6.eq) goto loc_8B09A2B0;
	// rotlwi r3,r11,0
	ctx.r3.u64 = __builtin_rotateleft32(ctx.r11.u32, 0);
	// lwz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r10,24(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 24);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctr 
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	return;
loc_8B09A2B0:
	// b 0x8b099598
	sub_8B099598(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B09A5D0) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// std r30,-24(r1)
	REX_STORE_U64(ctx.r1.u32 + -24, ctx.r30.u64);
	// std r31,-16(r1)
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.r31.u64);
	// stwu r1,-112(r1)
	ea = -112 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// mr r30,r3
	ctx.r30.u64 = ctx.r3.u64;
	// mr r3,r4
	ctx.r3.u64 = ctx.r4.u64;
	// mr r4,r5
	ctx.r4.u64 = ctx.r5.u64;
	// lwz r31,0(r30)
	ctx.r31.u64 = REX_LOAD_U32(ctx.r30.u32 + 0);
	// bl 0x8b09a2b8
	ctx.lr = 0x8B09A5F8;
	sub_8B09A2B8(ctx, base);
	// lwz r11,80(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 80);
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// addi r5,r1,80
	ctx.r5.s64 = ctx.r1.s64 + 80;
	// li r6,0
	ctx.r6.s64 = 0;
	// li r7,8
	ctx.r7.s64 = 8;
	// mtctr r11
	ctx.ctr.u64 = ctx.r11.u64;
	// bctrl 
	ctx.lr = 0x8B09A618;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// lwz r3,80(r1)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r1.u32 + 80);
	// addi r1,r1,112
	ctx.r1.s64 = ctx.r1.s64 + 112;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// ld r30,-24(r1)
	ctx.r30.u64 = REX_LOAD_U64(ctx.r1.u32 + -24);
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B09A788) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9ac
	ctx.lr = 0x8B09A790;
	__savegprlr_25(ctx, base);
	// stwu r1,-160(r1)
	ea = -160 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// li r30,0
	ctx.r30.s64 = 0;
	// mr r28,r4
	ctx.r28.u64 = ctx.r4.u64;
	// mr r27,r5
	ctx.r27.u64 = ctx.r5.u64;
	// stw r30,8(r3)
	REX_STORE_U32(ctx.r3.u32 + 8, ctx.r30.u32);
	// li r5,144
	ctx.r5.s64 = 144;
	// li r4,0
	ctx.r4.s64 = 0;
	// std r30,40(r31)
	REX_STORE_U64(ctx.r31.u32 + 40, ctx.r30.u64);
	// addi r3,r3,48
	ctx.r3.s64 = ctx.r3.s64 + 48;
	// bl 0x8b0cb8e0
	ctx.lr = 0x8B09A7BC;
	sub_8B0CB8E0(ctx, base);
	// li r10,7
	ctx.r10.s64 = 7;
	// addi r25,r31,12
	ctx.r25.s64 = ctx.r31.s64 + 12;
	// stw r30,192(r31)
	REX_STORE_U32(ctx.r31.u32 + 192, ctx.r30.u32);
	// mr r9,r30
	ctx.r9.u64 = ctx.r30.u64;
	// addi r11,r25,-4
	ctx.r11.s64 = ctx.r25.s64 + -4;
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
loc_8B09A7D4:
	// stwu r9,4(r11)
	ea = 4 + ctx.r11.u32;
	REX_STORE_U32(ea, ctx.r9.u32);
	ctx.r11.u32 = ea;
	// bdnz 0x8b09a7d4
	--ctx.ctr.u64;
	if (ctx.ctr.u32 != 0) goto loc_8B09A7D4;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// stw r30,200(r31)
	REX_STORE_U32(ctx.r31.u32 + 200, ctx.r30.u32);
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// addi r9,r11,11912
	ctx.r9.s64 = ctx.r11.s64 + 11912;
	// addi r8,r10,11904
	ctx.r8.s64 = ctx.r10.s64 + 11904;
	// stw r9,0(r31)
	REX_STORE_U32(ctx.r31.u32 + 0, ctx.r9.u32);
	// addi r29,r31,208
	ctx.r29.s64 = ctx.r31.s64 + 208;
	// stw r8,4(r31)
	REX_STORE_U32(ctx.r31.u32 + 4, ctx.r8.u32);
	// li r6,0
	ctx.r6.s64 = 0;
	// li r5,0
	ctx.r5.s64 = 0;
	// li r4,0
	ctx.r4.s64 = 0;
	// mr r3,r29
	ctx.r3.u64 = ctx.r29.u64;
	// bl 0x8b0c8820
	ctx.lr = 0x8B09A810;
	sub_8B0C8820(ctx, base);
	// li r9,5
	ctx.r9.s64 = 5;
	// addi r10,r31,252
	ctx.r10.s64 = ctx.r31.s64 + 252;
	// addi r11,r28,-4
	ctx.r11.s64 = ctx.r28.s64 + -4;
	// mtctr r9
	ctx.ctr.u64 = ctx.r9.u64;
loc_8B09A820:
	// lwzu r9,4(r11)
	ea = 4 + ctx.r11.u32;
	ctx.r9.u64 = REX_LOAD_U32(ea);
	ctx.r11.u32 = ea;
	// stwu r9,4(r10)
	ea = 4 + ctx.r10.u32;
	REX_STORE_U32(ea, ctx.r9.u32);
	ctx.r10.u32 = ea;
	// bdnz 0x8b09a820
	--ctx.ctr.u64;
	if (ctx.ctr.u32 != 0) goto loc_8B09A820;
	// ld r28,0(r27)
	ctx.r28.u64 = REX_LOAD_U64(ctx.r27.u32 + 0);
	// bl 0x8b0df318
	ctx.lr = 0x8B09A834;
	sub_8B0DF318(ctx, base);
	// stw r30,80(r1)
	REX_STORE_U32(ctx.r1.u32 + 80, ctx.r30.u32);
	// lis r27,-29938
	ctx.r27.s64 = -1962016768;
	// mr r30,r3
	ctx.r30.u64 = ctx.r3.u64;
	// mr r5,r3
	ctx.r5.u64 = ctx.r3.u64;
	// li r8,0
	ctx.r8.s64 = 0;
	// li r7,0
	ctx.r7.s64 = 0;
	// lwz r11,2364(r27)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r27.u32 + 2364);
	// addi r6,r1,80
	ctx.r6.s64 = ctx.r1.s64 + 80;
	// mr r4,r28
	ctx.r4.u64 = ctx.r28.u64;
	// lwz r3,104(r11)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r11.u32 + 104);
	// lwz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r10,84(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 84);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B09A86C;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// mr r26,r3
	ctx.r26.u64 = ctx.r3.u64;
	// cmplwi cr6,r3,122
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 122, ctx.xer);
	// beq cr6,0x8b09a890
	if (ctx.cr6.eq) goto loc_8B09A890;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// addi r3,r11,11840
	ctx.r3.s64 = ctx.r11.s64 + 11840;
	// bl 0x8b0df2e8
	ctx.lr = 0x8B09A888;
	sub_8B0DF2E8(ctx, base);
	// clrldi r9,r26,32
	ctx.r9.u64 = ctx.r26.u64 & 0xFFFFFFFF;
	// b 0x8b09a8f8
	goto loc_8B09A8F8;
loc_8B09A890:
	// mr r3,r29
	ctx.r3.u64 = ctx.r29.u64;
	// lwz r4,80(r1)
	ctx.r4.u64 = REX_LOAD_U32(ctx.r1.u32 + 80);
	// bl 0x8b0c8148
	ctx.lr = 0x8B09A89C;
	sub_8B0C8148(ctx, base);
	// li r4,0
	ctx.r4.s64 = 0;
	// lwz r5,80(r1)
	ctx.r5.u64 = REX_LOAD_U32(ctx.r1.u32 + 80);
	// lwz r3,0(r29)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r29.u32 + 0);
	// bl 0x8b0cb8e0
	ctx.lr = 0x8B09A8AC;
	sub_8B0CB8E0(ctx, base);
	// lwz r11,2364(r27)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r27.u32 + 2364);
	// mr r8,r25
	ctx.r8.u64 = ctx.r25.u64;
	// addi r6,r1,80
	ctx.r6.s64 = ctx.r1.s64 + 80;
	// lwz r7,0(r29)
	ctx.r7.u64 = REX_LOAD_U32(ctx.r29.u32 + 0);
	// mr r5,r30
	ctx.r5.u64 = ctx.r30.u64;
	// mr r4,r28
	ctx.r4.u64 = ctx.r28.u64;
	// lwz r3,104(r11)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r11.u32 + 104);
	// lwz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r10,84(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 84);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B09A8D8;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// mr r30,r3
	ctx.r30.u64 = ctx.r3.u64;
	// cmplwi cr6,r3,997
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 997, ctx.xer);
	// beq cr6,0x8b09a904
	if (ctx.cr6.eq) goto loc_8B09A904;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// addi r3,r11,11780
	ctx.r3.s64 = ctx.r11.s64 + 11780;
	// bl 0x8b0df2e8
	ctx.lr = 0x8B09A8F4;
	sub_8B0DF2E8(ctx, base);
	// clrldi r9,r30,32
	ctx.r9.u64 = ctx.r30.u64 & 0xFFFFFFFF;
loc_8B09A8F8:
	// li r10,3
	ctx.r10.s64 = 3;
	// std r9,40(r31)
	REX_STORE_U64(ctx.r31.u32 + 40, ctx.r9.u64);
	// stw r10,8(r31)
	REX_STORE_U32(ctx.r31.u32 + 8, ctx.r10.u32);
loc_8B09A904:
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// addi r1,r1,160
	ctx.r1.s64 = ctx.r1.s64 + 160;
	// b 0x8b0cb9fc
	__restgprlr_25(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B09AE50) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9b4
	ctx.lr = 0x8B09AE58;
	__savegprlr_27(ctx, base);
	// stwu r1,-128(r1)
	ea = -128 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lwz r11,1556(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 1556);
	// mr r29,r3
	ctx.r29.u64 = ctx.r3.u64;
	// mr r27,r4
	ctx.r27.u64 = ctx.r4.u64;
	// mr r28,r5
	ctx.r28.u64 = ctx.r5.u64;
	// cmpwi cr6,r11,63
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 63, ctx.xer);
	// blt cr6,0x8b09ae88
	if (ctx.cr6.lt) goto loc_8B09AE88;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// addi r3,r11,12064
	ctx.r3.s64 = ctx.r11.s64 + 12064;
	// bl 0x8b0df2a8
	ctx.lr = 0x8B09AE80;
	sub_8B0DF2A8(ctx, base);
	// addi r1,r1,128
	ctx.r1.s64 = ctx.r1.s64 + 128;
	// b 0x8b0cba04
	__restgprlr_27(ctx, base);
	return;
loc_8B09AE88:
	// lwz r30,1556(r29)
	ctx.r30.u64 = REX_LOAD_U32(ctx.r29.u32 + 1556);
	// addi r31,r29,20
	ctx.r31.s64 = ctx.r29.s64 + 20;
	// addi r11,r30,1
	ctx.r11.s64 = ctx.r30.s64 + 1;
	// subf r10,r30,r11
	ctx.r10.u64 = ctx.r11.u64 - ctx.r30.u64;
	// stw r11,1556(r29)
	REX_STORE_U32(ctx.r29.u32 + 1556, ctx.r11.u32);
	// addic. r11,r10,-1
	ctx.xer.ca = ctx.r10.u32 > 0;
	ctx.r11.s64 = ctx.r10.s64 + -1;
	ctx.cr0.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// ble 0x8b09aec8
	if (!ctx.cr0.gt) goto loc_8B09AEC8;
	// rlwinm r10,r30,1,0,30
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r30.u32 | (ctx.r30.u64 << 32), 1) & 0xFFFFFFFE;
	// rlwinm r9,r11,1,0,30
	ctx.r9.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 1) & 0xFFFFFFFE;
	// add r10,r30,r10
	ctx.r10.u64 = ctx.r30.u64 + ctx.r10.u64;
	// add r9,r11,r9
	ctx.r9.u64 = ctx.r11.u64 + ctx.r9.u64;
	// rlwinm r11,r10,3,0,28
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r10.u32 | (ctx.r10.u64 << 32), 3) & 0xFFFFFFF8;
	// rlwinm r5,r9,3,0,28
	ctx.r5.u64 = __builtin_rotateleft64(ctx.r9.u32 | (ctx.r9.u64 << 32), 3) & 0xFFFFFFF8;
	// add r4,r11,r31
	ctx.r4.u64 = ctx.r11.u64 + ctx.r31.u64;
	// addi r3,r4,24
	ctx.r3.s64 = ctx.r4.s64 + 24;
	// bl 0x8b0cc060
	ctx.lr = 0x8B09AEC8;
	sub_8B0CC060(ctx, base);
loc_8B09AEC8:
	// cmplwi cr6,r28,0
	ctx.cr6.compare<uint32_t>(ctx.r28.u32, 0, ctx.xer);
	// beq cr6,0x8b09aef8
	if (ctx.cr6.eq) goto loc_8B09AEF8;
	// rlwinm r11,r30,1,0,30
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r30.u32 | (ctx.r30.u64 << 32), 1) & 0xFFFFFFFE;
	// ld r10,0(r28)
	ctx.r10.u64 = REX_LOAD_U64(ctx.r28.u32 + 0);
	// add r9,r30,r11
	ctx.r9.u64 = ctx.r30.u64 + ctx.r11.u64;
	// rlwinm r11,r9,3,0,28
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r9.u32 | (ctx.r9.u64 << 32), 3) & 0xFFFFFFF8;
	// add r8,r11,r31
	ctx.r8.u64 = ctx.r11.u64 + ctx.r31.u64;
	// stdx r10,r11,r31
	REX_STORE_U64(ctx.r11.u32 + ctx.r31.u32, ctx.r10.u64);
	// ld r7,8(r28)
	ctx.r7.u64 = REX_LOAD_U64(ctx.r28.u32 + 8);
	// std r7,8(r8)
	REX_STORE_U64(ctx.r8.u32 + 8, ctx.r7.u64);
	// ld r6,16(r28)
	ctx.r6.u64 = REX_LOAD_U64(ctx.r28.u32 + 16);
	// std r6,16(r8)
	REX_STORE_U64(ctx.r8.u32 + 16, ctx.r6.u64);
loc_8B09AEF8:
	// lwz r11,1536(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 1536);
	// lwz r9,16(r29)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r29.u32 + 16);
	// rlwinm r10,r11,1,0,30
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 1) & 0xFFFFFFFE;
	// cmpwi cr6,r9,0
	ctx.cr6.compare<int32_t>(ctx.r9.s32, 0, ctx.xer);
	// add r8,r11,r10
	ctx.r8.u64 = ctx.r11.u64 + ctx.r10.u64;
	// rlwinm r11,r8,3,0,28
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r8.u32 | (ctx.r8.u64 << 32), 3) & 0xFFFFFFF8;
	// add r11,r11,r31
	ctx.r11.u64 = ctx.r11.u64 + ctx.r31.u64;
	// addi r28,r11,-24
	ctx.r28.s64 = ctx.r11.s64 + -24;
	// beq cr6,0x8b09af44
	if (ctx.cr6.eq) goto loc_8B09AF44;
	// rotlwi r11,r9,0
	ctx.r11.u64 = __builtin_rotateleft32(ctx.r9.u32, 0);
	// lwz r10,4(r29)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r29.u32 + 4);
	// addi r31,r29,4
	ctx.r31.s64 = ctx.r29.s64 + 4;
	// rlwinm r9,r11,1,0,30
	ctx.r9.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 1) & 0xFFFFFFFE;
	// add r11,r11,r9
	ctx.r11.u64 = ctx.r11.u64 + ctx.r9.u64;
	// rlwinm r11,r11,2,0,29
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 2) & 0xFFFFFFFC;
	// add r10,r11,r10
	ctx.r10.u64 = ctx.r11.u64 + ctx.r10.u64;
	// lwz r9,-12(r10)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r10.u32 + -12);
	// cmplw cr6,r9,r27
	ctx.cr6.compare<uint32_t>(ctx.r9.u32, ctx.r27.u32, ctx.xer);
	// beq cr6,0x8b09afd8
	if (ctx.cr6.eq) goto loc_8B09AFD8;
loc_8B09AF44:
	// lwz r30,16(r29)
	ctx.r30.u64 = REX_LOAD_U32(ctx.r29.u32 + 16);
	// addi r31,r29,4
	ctx.r31.s64 = ctx.r29.s64 + 4;
	// lwz r11,8(r29)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r29.u32 + 8);
	// addi r10,r30,1
	ctx.r10.s64 = ctx.r30.s64 + 1;
	// cmpw cr6,r10,r11
	ctx.cr6.compare<int32_t>(ctx.r10.s32, ctx.r11.s32, ctx.xer);
	// ble cr6,0x8b09af6c
	if (!ctx.cr6.gt) goto loc_8B09AF6C;
	// subf r11,r11,r30
	ctx.r11.u64 = ctx.r30.u64 - ctx.r11.u64;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// addi r4,r11,1
	ctx.r4.s64 = ctx.r11.s64 + 1;
	// bl 0x8b099bf8
	ctx.lr = 0x8B09AF6C;
	sub_8B099BF8(ctx, base);
loc_8B09AF6C:
	// lwz r11,12(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 12);
	// addi r11,r11,1
	ctx.r11.s64 = ctx.r11.s64 + 1;
	// subf r10,r30,r11
	ctx.r10.u64 = ctx.r11.u64 - ctx.r30.u64;
	// stw r11,12(r31)
	REX_STORE_U32(ctx.r31.u32 + 12, ctx.r11.u32);
	// addic. r11,r10,-1
	ctx.xer.ca = ctx.r10.u32 > 0;
	ctx.r11.s64 = ctx.r10.s64 + -1;
	ctx.cr0.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// ble 0x8b09afac
	if (!ctx.cr0.gt) goto loc_8B09AFAC;
	// rlwinm r8,r30,1,0,30
	ctx.r8.u64 = __builtin_rotateleft64(ctx.r30.u32 | (ctx.r30.u64 << 32), 1) & 0xFFFFFFFE;
	// lwz r10,0(r31)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r31.u32 + 0);
	// rlwinm r9,r11,1,0,30
	ctx.r9.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 1) & 0xFFFFFFFE;
	// add r8,r30,r8
	ctx.r8.u64 = ctx.r30.u64 + ctx.r8.u64;
	// add r7,r11,r9
	ctx.r7.u64 = ctx.r11.u64 + ctx.r9.u64;
	// rlwinm r11,r8,2,0,29
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r8.u32 | (ctx.r8.u64 << 32), 2) & 0xFFFFFFFC;
	// rlwinm r5,r7,2,0,29
	ctx.r5.u64 = __builtin_rotateleft64(ctx.r7.u32 | (ctx.r7.u64 << 32), 2) & 0xFFFFFFFC;
	// add r4,r11,r10
	ctx.r4.u64 = ctx.r11.u64 + ctx.r10.u64;
	// addi r3,r4,12
	ctx.r3.s64 = ctx.r4.s64 + 12;
	// bl 0x8b0cc060
	ctx.lr = 0x8B09AFAC;
	sub_8B0CC060(ctx, base);
loc_8B09AFAC:
	// lwz r11,12(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 12);
	// li r8,0
	ctx.r8.s64 = 0;
	// lwz r10,0(r31)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r31.u32 + 0);
	// rlwinm r9,r11,1,0,30
	ctx.r9.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 1) & 0xFFFFFFFE;
	// add r7,r11,r9
	ctx.r7.u64 = ctx.r11.u64 + ctx.r9.u64;
	// rlwinm r11,r7,2,0,29
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r7.u32 | (ctx.r7.u64 << 32), 2) & 0xFFFFFFFC;
	// add r11,r11,r10
	ctx.r11.u64 = ctx.r11.u64 + ctx.r10.u64;
	// addi r10,r11,-12
	ctx.r10.s64 = ctx.r11.s64 + -12;
	// stw r27,-12(r11)
	REX_STORE_U32(ctx.r11.u32 + -12, ctx.r27.u32);
	// stw r8,-8(r11)
	REX_STORE_U32(ctx.r11.u32 + -8, ctx.r8.u32);
	// stw r28,-4(r11)
	REX_STORE_U32(ctx.r11.u32 + -4, ctx.r28.u32);
loc_8B09AFD8:
	// lwz r11,12(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 12);
	// lwz r10,0(r31)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r31.u32 + 0);
	// rlwinm r9,r11,1,0,30
	ctx.r9.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 1) & 0xFFFFFFFE;
	// add r11,r11,r9
	ctx.r11.u64 = ctx.r11.u64 + ctx.r9.u64;
	// rlwinm r11,r11,2,0,29
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 2) & 0xFFFFFFFC;
	// add r11,r11,r10
	ctx.r11.u64 = ctx.r11.u64 + ctx.r10.u64;
	// addi r10,r11,-8
	ctx.r10.s64 = ctx.r11.s64 + -8;
	// lwz r10,-8(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + -8);
	// addi r10,r10,1
	ctx.r10.s64 = ctx.r10.s64 + 1;
	// stw r10,-8(r11)
	REX_STORE_U32(ctx.r11.u32 + -8, ctx.r10.u32);
	// addi r1,r1,128
	ctx.r1.s64 = ctx.r1.s64 + 128;
	// b 0x8b0cba04
	__restgprlr_27(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B09BAF8) {
	REX_FUNC_PROLOGUE();
	// mr r3,r4
	ctx.r3.u64 = ctx.r4.u64;
	// b 0x8b09b958
	sub_8B09B958(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B09BB00) {
	REX_FUNC_PROLOGUE();
	PPCRegister temp{};
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9b0
	ctx.lr = 0x8B09BB08;
	__savegprlr_26(ctx, base);
	// stfd f31,-64(r1)
	ctx.fpscr.disableFlushMode();
	REX_STORE_U64(ctx.r1.u32 + -64, ctx.f31.u64);
	// stwu r1,-144(r1)
	ea = -144 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lwz r11,16(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 16);
	// mr r30,r3
	ctx.r30.u64 = ctx.r3.u64;
	// cmpwi cr6,r11,0
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// beq cr6,0x8b09bc60
	if (ctx.cr6.eq) goto loc_8B09BC60;
	// lis r11,-29938
	ctx.r11.s64 = -1962016768;
	// addi r10,r11,18576
	ctx.r10.s64 = ctx.r11.s64 + 18576;
	// lwz r11,12(r10)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r10.u32 + 12);
	// cmpwi cr6,r11,0
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// beq cr6,0x8b09bc54
	if (ctx.cr6.eq) goto loc_8B09BC54;
	// rlwinm r9,r11,1,0,30
	ctx.r9.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 1) & 0xFFFFFFFE;
	// lwz r10,0(r10)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r10.u32 + 0);
	// add r11,r11,r9
	ctx.r11.u64 = ctx.r11.u64 + ctx.r9.u64;
	// rlwinm r11,r11,2,0,29
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 2) & 0xFFFFFFFC;
	// add r11,r11,r10
	ctx.r11.u64 = ctx.r11.u64 + ctx.r10.u64;
	// addi r31,r11,-12
	ctx.r31.s64 = ctx.r11.s64 + -12;
	// cmplwi cr6,r31,0
	ctx.cr6.compare<uint32_t>(ctx.r31.u32, 0, ctx.xer);
	// beq cr6,0x8b09bc54
	if (ctx.cr6.eq) goto loc_8B09BC54;
	// lwz r11,0(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 0);
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// beq cr6,0x8b09bc54
	if (ctx.cr6.eq) goto loc_8B09BC54;
	// lwz r10,1560(r3)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r3.u32 + 1560);
	// cmplw cr6,r11,r10
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, ctx.r10.u32, ctx.xer);
	// beq cr6,0x8b09bb88
	if (ctx.cr6.eq) goto loc_8B09BB88;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// addi r3,r11,13064
	ctx.r3.s64 = ctx.r11.s64 + 13064;
	// bl 0x8b0df2a8
	ctx.lr = 0x8B09BB78;
	sub_8B0DF2A8(ctx, base);
	// li r3,0
	ctx.r3.s64 = 0;
	// addi r1,r1,144
	ctx.r1.s64 = ctx.r1.s64 + 144;
	// lfd f31,-64(r1)
	ctx.fpscr.disableFlushMode();
	ctx.f31.u64 = REX_LOAD_U64(ctx.r1.u32 + -64);
	// b 0x8b0cba00
	__restgprlr_26(ctx, base);
	return;
loc_8B09BB88:
	// lis r11,-29938
	ctx.r11.s64 = -1962016768;
	// lwz r28,4(r30)
	ctx.r28.u64 = REX_LOAD_U32(ctx.r30.u32 + 4);
	// lis r10,-29942
	ctx.r10.s64 = -1962278912;
	// lwz r27,16(r30)
	ctx.r27.u64 = REX_LOAD_U32(ctx.r30.u32 + 16);
	// mr r4,r30
	ctx.r4.u64 = ctx.r30.u64;
	// addi r3,r10,-17672
	ctx.r3.s64 = ctx.r10.s64 + -17672;
	// lwz r11,2364(r11)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r11.u32 + 2364);
	// lwz r26,104(r11)
	ctx.r26.u64 = REX_LOAD_U32(ctx.r11.u32 + 104);
	// lwz r29,0(r26)
	ctx.r29.u64 = REX_LOAD_U32(ctx.r26.u32 + 0);
	// bl 0x8b09abd8
	ctx.lr = 0x8B09BBB0;
	sub_8B09ABD8(ctx, base);
	// lwz r9,148(r29)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r29.u32 + 148);
	// mr r8,r3
	ctx.r8.u64 = ctx.r3.u64;
	// mr r7,r28
	ctx.r7.u64 = ctx.r28.u64;
	// ld r5,1568(r30)
	ctx.r5.u64 = REX_LOAD_U64(ctx.r30.u32 + 1568);
	// mr r6,r27
	ctx.r6.u64 = ctx.r27.u64;
	// lwz r4,0(r31)
	ctx.r4.u64 = REX_LOAD_U32(ctx.r31.u32 + 0);
	// mr r3,r26
	ctx.r3.u64 = ctx.r26.u64;
	// mtctr r9
	ctx.ctr.u64 = ctx.r9.u64;
	// bctrl 
	ctx.lr = 0x8B09BBD4;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b09bc10
	if (ctx.cr6.eq) goto loc_8B09BC10;
	// cmplwi cr6,r3,997
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 997, ctx.xer);
	// beq cr6,0x8b09bc10
	if (ctx.cr6.eq) goto loc_8B09BC10;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lwz r7,1556(r30)
	ctx.r7.u64 = REX_LOAD_U32(ctx.r30.u32 + 1556);
	// lwz r6,16(r30)
	ctx.r6.u64 = REX_LOAD_U32(ctx.r30.u32 + 16);
	// addi r3,r11,12984
	ctx.r3.s64 = ctx.r11.s64 + 12984;
	// ld r5,1568(r30)
	ctx.r5.u64 = REX_LOAD_U64(ctx.r30.u32 + 1568);
	// bl 0x8b0df2a8
	ctx.lr = 0x8B09BC00;
	sub_8B0DF2A8(ctx, base);
	// li r3,0
	ctx.r3.s64 = 0;
	// addi r1,r1,144
	ctx.r1.s64 = ctx.r1.s64 + 144;
	// lfd f31,-64(r1)
	ctx.fpscr.disableFlushMode();
	ctx.f31.u64 = REX_LOAD_U64(ctx.r1.u32 + -64);
	// b 0x8b0cba00
	__restgprlr_26(ctx, base);
	return;
loc_8B09BC10:
	// li r11,1
	ctx.r11.s64 = 1;
	// lfs f31,4(r31)
	ctx.fpscr.disableFlushMode();
	temp.u32 = REX_LOAD_U32(ctx.r31.u32 + 4);
	ctx.f31.f64 = double(temp.f32);
	// stb r11,8(r31)
	REX_STORE_U8(ctx.r31.u32 + 8, ctx.r11.u8);
	// bl 0x8b0df2f8
	ctx.lr = 0x8B09BC20;
	sub_8B0DF2F8(ctx, base);
	// stfd f1,32(r1)
	ctx.fpscr.disableFlushMode();
	REX_STORE_U64(ctx.r1.u32 + 32, ctx.f1.u64);
	// stfd f31,40(r1)
	REX_STORE_U64(ctx.r1.u32 + 40, ctx.f31.u64);
	// ld r5,32(r1)
	ctx.r5.u64 = REX_LOAD_U64(ctx.r1.u32 + 32);
	// ld r6,40(r1)
	ctx.r6.u64 = REX_LOAD_U64(ctx.r1.u32 + 40);
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// lwz r4,0(r31)
	ctx.r4.u64 = REX_LOAD_U32(ctx.r31.u32 + 0);
	// fmr f2,f31
	ctx.f2.f64 = ctx.f31.f64;
	// addi r3,r10,12920
	ctx.r3.s64 = ctx.r10.s64 + 12920;
	// bl 0x8b0df298
	ctx.lr = 0x8B09BC44;
	sub_8B0DF298(ctx, base);
	// li r3,1
	ctx.r3.s64 = 1;
	// addi r1,r1,144
	ctx.r1.s64 = ctx.r1.s64 + 144;
	// lfd f31,-64(r1)
	ctx.fpscr.disableFlushMode();
	ctx.f31.u64 = REX_LOAD_U64(ctx.r1.u32 + -64);
	// b 0x8b0cba00
	__restgprlr_26(ctx, base);
	return;
loc_8B09BC54:
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// addi r3,r11,12840
	ctx.r3.s64 = ctx.r11.s64 + 12840;
	// bl 0x8b0df2a8
	ctx.lr = 0x8B09BC60;
	sub_8B0DF2A8(ctx, base);
loc_8B09BC60:
	// li r3,0
	ctx.r3.s64 = 0;
	// addi r1,r1,144
	ctx.r1.s64 = ctx.r1.s64 + 144;
	// lfd f31,-64(r1)
	ctx.fpscr.disableFlushMode();
	ctx.f31.u64 = REX_LOAD_U64(ctx.r1.u32 + -64);
	// b 0x8b0cba00
	__restgprlr_26(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B09C0D8) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// std r30,-24(r1)
	REX_STORE_U64(ctx.r1.u32 + -24, ctx.r30.u64);
	// std r31,-16(r1)
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.r31.u64);
	// stwu r1,-112(r1)
	ea = -112 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// li r30,0
	ctx.r30.s64 = 0;
	// bl 0x8b0df338
	ctx.lr = 0x8B09C0F8;
	sub_8B0DF338(ctx, base);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// bne cr6,0x8b09c148
	if (!ctx.cr6.eq) goto loc_8B09C148;
	// lwz r3,16(r31)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r31.u32 + 16);
	// bl 0x8b095438
	ctx.lr = 0x8B09C108;
	sub_8B095438(ctx, base);
	// cmpwi cr6,r3,2
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 2, ctx.xer);
	// bne cr6,0x8b09c148
	if (!ctx.cr6.eq) goto loc_8B09C148;
	// stw r30,80(r1)
	REX_STORE_U32(ctx.r1.u32 + 80, ctx.r30.u32);
	// addi r5,r1,80
	ctx.r5.s64 = ctx.r1.s64 + 80;
	// li r4,254
	ctx.r4.s64 = 254;
	// lwz r3,16(r31)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r31.u32 + 16);
	// li r30,1
	ctx.r30.s64 = 1;
	// bl 0x8b095448
	ctx.lr = 0x8B09C128;
	sub_8B095448(ctx, base);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// bne cr6,0x8b09c148
	if (!ctx.cr6.eq) goto loc_8B09C148;
	// lwz r11,80(r1)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r1.u32 + 80);
	// cmpwi cr6,r11,0
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// beq cr6,0x8b09c148
	if (ctx.cr6.eq) goto loc_8B09C148;
	// li r11,2
	ctx.r11.s64 = 2;
	// stw r11,20(r31)
	REX_STORE_U32(ctx.r31.u32 + 20, ctx.r11.u32);
	// b 0x8b09c14c
	goto loc_8B09C14C;
loc_8B09C148:
	// stw r30,20(r31)
	REX_STORE_U32(ctx.r31.u32 + 20, ctx.r30.u32);
loc_8B09C14C:
	// addi r1,r1,112
	ctx.r1.s64 = ctx.r1.s64 + 112;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// ld r30,-24(r1)
	ctx.r30.u64 = REX_LOAD_U64(ctx.r1.u32 + -24);
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B09C608) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9b4
	ctx.lr = 0x8B09C610;
	__savegprlr_27(ctx, base);
	// stwu r1,-128(r1)
	ea = -128 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// mr r28,r3
	ctx.r28.u64 = ctx.r3.u64;
	// mr r3,r4
	ctx.r3.u64 = ctx.r4.u64;
	// bl 0x8b0bf248
	ctx.lr = 0x8B09C620;
	sub_8B0BF248(ctx, base);
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b09c6b8
	if (ctx.cr6.eq) goto loc_8B09C6B8;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lis r27,-29938
	ctx.r27.s64 = -1962016768;
	// addi r29,r11,13500
	ctx.r29.s64 = ctx.r11.s64 + 13500;
loc_8B09C638:
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0beee8
	ctx.lr = 0x8B09C640;
	sub_8B0BEEE8(ctx, base);
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// li r5,0
	ctx.r5.s64 = 0;
	// lwz r3,3136(r28)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r28.u32 + 3136);
	// bl 0x8b0bfa88
	ctx.lr = 0x8B09C650;
	sub_8B0BFA88(ctx, base);
	// mr r30,r3
	ctx.r30.u64 = ctx.r3.u64;
	// mr r4,r29
	ctx.r4.u64 = ctx.r29.u64;
	// li r5,0
	ctx.r5.s64 = 0;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0bfc38
	ctx.lr = 0x8B09C664;
	sub_8B0BFC38(ctx, base);
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// bne cr6,0x8b09c674
	if (!ctx.cr6.eq) goto loc_8B09C674;
	// cmplwi cr6,r30,0
	ctx.cr6.compare<uint32_t>(ctx.r30.u32, 0, ctx.xer);
	// bne cr6,0x8b09c694
	if (!ctx.cr6.eq) goto loc_8B09C694;
loc_8B09C674:
	// lwz r3,4924(r27)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r27.u32 + 4924);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b09c694
	if (ctx.cr6.eq) goto loc_8B09C694;
	// lwz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// mr r4,r31
	ctx.r4.u64 = ctx.r31.u64;
	// lwz r10,0(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 0);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B09C694;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
loc_8B09C694:
	// li r5,3
	ctx.r5.s64 = 3;
	// mr r4,r30
	ctx.r4.u64 = ctx.r30.u64;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0c0668
	ctx.lr = 0x8B09C6A4;
	sub_8B0C0668(ctx, base);
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0bf280
	ctx.lr = 0x8B09C6AC;
	sub_8B0BF280(ctx, base);
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// bne cr6,0x8b09c638
	if (!ctx.cr6.eq) goto loc_8B09C638;
loc_8B09C6B8:
	// addi r1,r1,128
	ctx.r1.s64 = ctx.r1.s64 + 128;
	// b 0x8b0cba04
	__restgprlr_27(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B09C6C0) {
	REX_FUNC_PROLOGUE();
	PPCRegister temp{};
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb980
	ctx.lr = 0x8B09C6C8;
	__savegprlr_14(ctx, base);
	// stfd f30,-168(r1)
	ctx.fpscr.disableFlushMode();
	REX_STORE_U64(ctx.r1.u32 + -168, ctx.f30.u64);
	// stfd f31,-160(r1)
	REX_STORE_U64(ctx.r1.u32 + -160, ctx.f31.u64);
	// stwu r1,-368(r1)
	ea = -368 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lwz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// stw r3,388(r1)
	REX_STORE_U32(ctx.r1.u32 + 388, ctx.r3.u32);
	// mr r30,r4
	ctx.r30.u64 = ctx.r4.u64;
	// lwz r10,8(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 8);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B09C6F0;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// lis r9,-29944
	ctx.r9.s64 = -1962409984;
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// addi r3,r9,14364
	ctx.r3.s64 = ctx.r9.s64 + 14364;
	// bl 0x8b0df298
	ctx.lr = 0x8B09C700;
	sub_8B0DF298(ctx, base);
	// ld r3,8(r31)
	ctx.r3.u64 = REX_LOAD_U64(ctx.r31.u32 + 8);
	// bl 0x8b09b8c0
	ctx.lr = 0x8B09C708;
	sub_8B09B8C0(ctx, base);
	// mr r19,r3
	ctx.r19.u64 = ctx.r3.u64;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// bl 0x8b0bf248
	ctx.lr = 0x8B09C714;
	sub_8B0BF248(ctx, base);
	// stw r3,84(r1)
	REX_STORE_U32(ctx.r1.u32 + 84, ctx.r3.u32);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b09cd7c
	if (ctx.cr6.eq) goto loc_8B09CD7C;
	// lis r27,-29944
	ctx.r27.s64 = -1962409984;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// addi r14,r27,14304
	ctx.r14.s64 = ctx.r27.s64 + 14304;
	// lis r27,-29938
	ctx.r27.s64 = -1962016768;
	// lis r3,-29944
	ctx.r3.s64 = -1962409984;
	// lis r21,-29944
	ctx.r21.s64 = -1962409984;
	// stw r27,88(r1)
	REX_STORE_U32(ctx.r1.u32 + 88, ctx.r27.u32);
	// lis r29,-29944
	ctx.r29.s64 = -1962409984;
	// lfs f30,8492(r11)
	ctx.fpscr.disableFlushMode();
	temp.u32 = REX_LOAD_U32(ctx.r11.u32 + 8492);
	ctx.f30.f64 = double(temp.f32);
	// lis r26,-29944
	ctx.r26.s64 = -1962409984;
	// addi r3,r3,14240
	ctx.r3.s64 = ctx.r3.s64 + 14240;
	// addi r9,r21,14176
	ctx.r9.s64 = ctx.r21.s64 + 14176;
	// lis r7,-29944
	ctx.r7.s64 = -1962409984;
	// stw r3,108(r1)
	REX_STORE_U32(ctx.r1.u32 + 108, ctx.r3.u32);
	// addi r29,r29,14136
	ctx.r29.s64 = ctx.r29.s64 + 14136;
	// stw r9,124(r1)
	REX_STORE_U32(ctx.r1.u32 + 124, ctx.r9.u32);
	// addi r27,r26,14072
	ctx.r27.s64 = ctx.r26.s64 + 14072;
	// lis r28,-29944
	ctx.r28.s64 = -1962409984;
	// stw r29,140(r1)
	REX_STORE_U32(ctx.r1.u32 + 140, ctx.r29.u32);
	// lis r25,-29944
	ctx.r25.s64 = -1962409984;
	// stw r27,132(r1)
	REX_STORE_U32(ctx.r1.u32 + 132, ctx.r27.u32);
	// lis r30,-29944
	ctx.r30.s64 = -1962409984;
	// lis r31,-29944
	ctx.r31.s64 = -1962409984;
	// lis r4,-29944
	ctx.r4.s64 = -1962409984;
	// lis r5,-29944
	ctx.r5.s64 = -1962409984;
	// lis r8,-29944
	ctx.r8.s64 = -1962409984;
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lis r22,-29944
	ctx.r22.s64 = -1962409984;
	// addi r3,r7,14012
	ctx.r3.s64 = ctx.r7.s64 + 14012;
	// lis r24,-29944
	ctx.r24.s64 = -1962409984;
	// lis r23,-29944
	ctx.r23.s64 = -1962409984;
	// stw r3,112(r1)
	REX_STORE_U32(ctx.r1.u32 + 112, ctx.r3.u32);
	// lis r20,-29944
	ctx.r20.s64 = -1962409984;
	// lis r6,-29944
	ctx.r6.s64 = -1962409984;
	// lis r9,-29944
	ctx.r9.s64 = -1962409984;
	// addi r28,r28,13964
	ctx.r28.s64 = ctx.r28.s64 + 13964;
	// addi r29,r25,13956
	ctx.r29.s64 = ctx.r25.s64 + 13956;
	// addi r30,r30,4568
	ctx.r30.s64 = ctx.r30.s64 + 4568;
	// stw r28,136(r1)
	REX_STORE_U32(ctx.r1.u32 + 136, ctx.r28.u32);
	// addi r31,r31,13908
	ctx.r31.s64 = ctx.r31.s64 + 13908;
	// stw r29,128(r1)
	REX_STORE_U32(ctx.r1.u32 + 128, ctx.r29.u32);
	// addi r4,r4,13840
	ctx.r4.s64 = ctx.r4.s64 + 13840;
	// stw r30,120(r1)
	REX_STORE_U32(ctx.r1.u32 + 120, ctx.r30.u32);
	// addi r5,r5,13780
	ctx.r5.s64 = ctx.r5.s64 + 13780;
	// stw r31,116(r1)
	REX_STORE_U32(ctx.r1.u32 + 116, ctx.r31.u32);
	// addi r8,r8,13764
	ctx.r8.s64 = ctx.r8.s64 + 13764;
	// stw r4,104(r1)
	REX_STORE_U32(ctx.r1.u32 + 104, ctx.r4.u32);
	// addi r27,r10,8412
	ctx.r27.s64 = ctx.r10.s64 + 8412;
	// stw r5,100(r1)
	REX_STORE_U32(ctx.r1.u32 + 100, ctx.r5.u32);
	// addi r7,r11,13720
	ctx.r7.s64 = ctx.r11.s64 + 13720;
	// stw r8,96(r1)
	REX_STORE_U32(ctx.r1.u32 + 96, ctx.r8.u32);
	// addi r15,r22,13660
	ctx.r15.s64 = ctx.r22.s64 + 13660;
	// stw r27,144(r1)
	REX_STORE_U32(ctx.r1.u32 + 144, ctx.r27.u32);
	// li r18,0
	ctx.r18.s64 = 0;
	// stw r7,92(r1)
	REX_STORE_U32(ctx.r1.u32 + 92, ctx.r7.u32);
	// addi r17,r24,13656
	ctx.r17.s64 = ctx.r24.s64 + 13656;
	// addi r16,r23,13648
	ctx.r16.s64 = ctx.r23.s64 + 13648;
	// addi r20,r20,8404
	ctx.r20.s64 = ctx.r20.s64 + 8404;
	// addi r21,r6,5424
	ctx.r21.s64 = ctx.r6.s64 + 5424;
	// addi r22,r9,1791
	ctx.r22.s64 = ctx.r9.s64 + 1791;
loc_8B09C814:
	// lwz r29,84(r1)
	ctx.r29.u64 = REX_LOAD_U32(ctx.r1.u32 + 84);
	// mr r3,r29
	ctx.r3.u64 = ctx.r29.u64;
	// bl 0x8b0beee8
	ctx.lr = 0x8B09C820;
	sub_8B0BEEE8(ctx, base);
	// lwz r31,388(r1)
	ctx.r31.u64 = REX_LOAD_U32(ctx.r1.u32 + 388);
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// li r5,0
	ctx.r5.s64 = 0;
	// mr r26,r3
	ctx.r26.u64 = ctx.r3.u64;
	// lwz r3,3136(r31)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r31.u32 + 3136);
	// bl 0x8b0bfa88
	ctx.lr = 0x8B09C838;
	sub_8B0BFA88(ctx, base);
	// mr r24,r3
	ctx.r24.u64 = ctx.r3.u64;
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// bne cr6,0x8b09c874
	if (!ctx.cr6.eq) goto loc_8B09C874;
	// li r3,36
	ctx.r3.s64 = 36;
	// bl 0x8b0bf448
	ctx.lr = 0x8B09C84C;
	sub_8B0BF448(ctx, base);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b09c864
	if (ctx.cr6.eq) goto loc_8B09C864;
	// mr r4,r26
	ctx.r4.u64 = ctx.r26.u64;
	// bl 0x8b0bf9f8
	ctx.lr = 0x8B09C85C;
	sub_8B0BF9F8(ctx, base);
	// mr r24,r3
	ctx.r24.u64 = ctx.r3.u64;
	// b 0x8b09c868
	goto loc_8B09C868;
loc_8B09C864:
	// mr r24,r18
	ctx.r24.u64 = ctx.r18.u64;
loc_8B09C868:
	// mr r4,r24
	ctx.r4.u64 = ctx.r24.u64;
	// lwz r3,3136(r31)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r31.u32 + 3136);
	// bl 0x8b0bfc00
	ctx.lr = 0x8B09C874;
	sub_8B0BFC00(ctx, base);
loc_8B09C874:
	// lwz r11,88(r1)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r1.u32 + 88);
	// lwz r3,3036(r11)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r11.u32 + 3036);
	// lwz r10,0(r3)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r9,32(r10)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r10.u32 + 32);
	// mtctr r9
	ctx.ctr.u64 = ctx.r9.u64;
	// bctrl 
	ctx.lr = 0x8B09C88C;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// lwz r8,0(r3)
	ctx.r8.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// mr r4,r26
	ctx.r4.u64 = ctx.r26.u64;
	// lwz r7,36(r8)
	ctx.r7.u64 = REX_LOAD_U32(ctx.r8.u32 + 36);
	// mtctr r7
	ctx.ctr.u64 = ctx.r7.u64;
	// bctrl 
	ctx.lr = 0x8B09C8A0;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// mr r23,r3
	ctx.r23.u64 = ctx.r3.u64;
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// bne cr6,0x8b09c8b8
	if (!ctx.cr6.eq) goto loc_8B09C8B8;
	// mr r4,r26
	ctx.r4.u64 = ctx.r26.u64;
	// lwz r3,92(r1)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r1.u32 + 92);
	// bl 0x8b0df2e8
	ctx.lr = 0x8B09C8B8;
	sub_8B0DF2E8(ctx, base);
loc_8B09C8B8:
	// mr r4,r27
	ctx.r4.u64 = ctx.r27.u64;
	// li r5,0
	ctx.r5.s64 = 0;
	// mr r3,r23
	ctx.r3.u64 = ctx.r23.u64;
	// bl 0x8b0bfa88
	ctx.lr = 0x8B09C8C8;
	sub_8B0BFA88(ctx, base);
	// mr r30,r3
	ctx.r30.u64 = ctx.r3.u64;
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b09c9ec
	if (ctx.cr6.eq) goto loc_8B09C9EC;
	// mr r5,r22
	ctx.r5.u64 = ctx.r22.u64;
	// lwz r4,96(r1)
	ctx.r4.u64 = REX_LOAD_U32(ctx.r1.u32 + 96);
	// mr r3,r23
	ctx.r3.u64 = ctx.r23.u64;
	// bl 0x8b0c1588
	ctx.lr = 0x8B09C8E4;
	sub_8B0C1588(ctx, base);
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// li r5,0
	ctx.r5.s64 = 0;
	// mr r3,r29
	ctx.r3.u64 = ctx.r29.u64;
	// bl 0x8b0bfa88
	ctx.lr = 0x8B09C8F8;
	sub_8B0BFA88(ctx, base);
	// mr r28,r3
	ctx.r28.u64 = ctx.r3.u64;
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b09ca6c
	if (ctx.cr6.eq) goto loc_8B09CA6C;
	// lbz r11,0(r31)
	ctx.r11.u64 = REX_LOAD_U8(ctx.r31.u32 + 0);
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// beq cr6,0x8b09ca6c
	if (ctx.cr6.eq) goto loc_8B09CA6C;
	// mr r5,r22
	ctx.r5.u64 = ctx.r22.u64;
	// mr r4,r21
	ctx.r4.u64 = ctx.r21.u64;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// bl 0x8b0c1588
	ctx.lr = 0x8B09C920;
	sub_8B0C1588(ctx, base);
	// mr r30,r3
	ctx.r30.u64 = ctx.r3.u64;
	// bl 0x8b0a6b60
	ctx.lr = 0x8B09C928;
	sub_8B0A6B60(ctx, base);
	// mr r29,r3
	ctx.r29.u64 = ctx.r3.u64;
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// bne cr6,0x8b09c948
	if (!ctx.cr6.eq) goto loc_8B09C948;
	// mr r5,r30
	ctx.r5.u64 = ctx.r30.u64;
	// lwz r3,100(r1)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r1.u32 + 100);
	// mr r4,r26
	ctx.r4.u64 = ctx.r26.u64;
	// bl 0x8b0df2e8
	ctx.lr = 0x8B09C944;
	sub_8B0DF2E8(ctx, base);
	// b 0x8b09cd54
	goto loc_8B09CD54;
loc_8B09C948:
	// li r5,0
	ctx.r5.s64 = 0;
	// li r4,0
	ctx.r4.s64 = 0;
	// mr r3,r28
	ctx.r3.u64 = ctx.r28.u64;
	// bl 0x8b0bfd30
	ctx.lr = 0x8B09C958;
	sub_8B0BFD30(ctx, base);
	// std r3,160(r1)
	REX_STORE_U64(ctx.r1.u32 + 160, ctx.r3.u64);
	// li r5,0
	ctx.r5.s64 = 0;
	// mr r4,r31
	ctx.r4.u64 = ctx.r31.u64;
	// mr r3,r24
	ctx.r3.u64 = ctx.r24.u64;
	// bl 0x8b0bfd30
	ctx.lr = 0x8B09C96C;
	sub_8B0BFD30(ctx, base);
	// lwz r11,0(r29)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r29.u32 + 0);
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// addi r5,r1,160
	ctx.r5.s64 = ctx.r1.s64 + 160;
	// mr r3,r29
	ctx.r3.u64 = ctx.r29.u64;
	// lwz r10,0(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 0);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B09C98C;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// clrlwi r9,r3,24
	ctx.r9.u64 = ctx.r3.u32 & 0xFF;
	// cmplwi cr6,r9,0
	ctx.cr6.compare<uint32_t>(ctx.r9.u32, 0, ctx.xer);
	// bne cr6,0x8b09c9c4
	if (!ctx.cr6.eq) goto loc_8B09C9C4;
	// li r5,0
	ctx.r5.s64 = 0;
	// li r4,0
	ctx.r4.s64 = 0;
	// mr r3,r28
	ctx.r3.u64 = ctx.r28.u64;
	// bl 0x8b0bfd30
	ctx.lr = 0x8B09C9A8;
	sub_8B0BFD30(ctx, base);
	// mr r7,r3
	ctx.r7.u64 = ctx.r3.u64;
	// mr r6,r31
	ctx.r6.u64 = ctx.r31.u64;
	// lwz r3,104(r1)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r1.u32 + 104);
	// mr r5,r30
	ctx.r5.u64 = ctx.r30.u64;
	// mr r4,r26
	ctx.r4.u64 = ctx.r26.u64;
	// bl 0x8b0df298
	ctx.lr = 0x8B09C9C0;
	sub_8B0DF298(ctx, base);
	// b 0x8b09cd54
	goto loc_8B09CD54;
loc_8B09C9C4:
	// mr r6,r31
	ctx.r6.u64 = ctx.r31.u64;
	// lwz r3,108(r1)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r1.u32 + 108);
	// mr r5,r30
	ctx.r5.u64 = ctx.r30.u64;
	// ld r7,160(r1)
	ctx.r7.u64 = REX_LOAD_U64(ctx.r1.u32 + 160);
	// mr r4,r26
	ctx.r4.u64 = ctx.r26.u64;
	// bl 0x8b0df298
	ctx.lr = 0x8B09C9DC;
	sub_8B0DF298(ctx, base);
	// mr r4,r27
	ctx.r4.u64 = ctx.r27.u64;
	// mr r3,r24
	ctx.r3.u64 = ctx.r24.u64;
	// ld r5,160(r1)
	ctx.r5.u64 = REX_LOAD_U64(ctx.r1.u32 + 160);
	// bl 0x8b0c0190
	ctx.lr = 0x8B09C9EC;
	sub_8B0C0190(ctx, base);
loc_8B09C9EC:
	// lwz r3,84(r1)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r1.u32 + 84);
	// bl 0x8b0bf2b8
	ctx.lr = 0x8B09C9F4;
	sub_8B0BF2B8(ctx, base);
	// mr r25,r3
	ctx.r25.u64 = ctx.r3.u64;
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b09cd54
	if (ctx.cr6.eq) goto loc_8B09CD54;
loc_8B09CA00:
	// mr r3,r25
	ctx.r3.u64 = ctx.r25.u64;
	// bl 0x8b0beee8
	ctx.lr = 0x8B09CA08;
	sub_8B0BEEE8(ctx, base);
	// lbz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U8(ctx.r3.u32 + 0);
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// cmplwi cr6,r11,58
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 58, ctx.xer);
	// beq cr6,0x8b09cd3c
	if (ctx.cr6.eq) goto loc_8B09CD3C;
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// li r5,0
	ctx.r5.s64 = 0;
	// mr r3,r23
	ctx.r3.u64 = ctx.r23.u64;
	// bl 0x8b0bfa88
	ctx.lr = 0x8B09CA28;
	sub_8B0BFA88(ctx, base);
	// mr r27,r3
	ctx.r27.u64 = ctx.r3.u64;
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b09cd2c
	if (ctx.cr6.eq) goto loc_8B09CD2C;
	// mr r5,r22
	ctx.r5.u64 = ctx.r22.u64;
	// mr r4,r21
	ctx.r4.u64 = ctx.r21.u64;
	// bl 0x8b0c1588
	ctx.lr = 0x8B09CA40;
	sub_8B0C1588(ctx, base);
	// mr r29,r3
	ctx.r29.u64 = ctx.r3.u64;
	// bl 0x8b0a6b60
	ctx.lr = 0x8B09CA48;
	sub_8B0A6B60(ctx, base);
	// mr r28,r3
	ctx.r28.u64 = ctx.r3.u64;
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// bne cr6,0x8b09ca80
	if (!ctx.cr6.eq) goto loc_8B09CA80;
	// mr r6,r29
	ctx.r6.u64 = ctx.r29.u64;
	// lwz r3,116(r1)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r1.u32 + 116);
	// mr r5,r31
	ctx.r5.u64 = ctx.r31.u64;
	// mr r4,r26
	ctx.r4.u64 = ctx.r26.u64;
	// bl 0x8b0df2e8
	ctx.lr = 0x8B09CA68;
	sub_8B0DF2E8(ctx, base);
	// b 0x8b09cd3c
	goto loc_8B09CD3C;
loc_8B09CA6C:
	// mr r5,r31
	ctx.r5.u64 = ctx.r31.u64;
	// lwz r3,112(r1)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r1.u32 + 112);
	// mr r4,r26
	ctx.r4.u64 = ctx.r26.u64;
	// bl 0x8b0df2e8
	ctx.lr = 0x8B09CA7C;
	sub_8B0DF2E8(ctx, base);
	// b 0x8b09cd54
	goto loc_8B09CD54;
loc_8B09CA80:
	// mr r5,r22
	ctx.r5.u64 = ctx.r22.u64;
	// lwz r4,120(r1)
	ctx.r4.u64 = REX_LOAD_U32(ctx.r1.u32 + 120);
	// mr r3,r27
	ctx.r3.u64 = ctx.r27.u64;
	// bl 0x8b0c1588
	ctx.lr = 0x8B09CA90;
	sub_8B0C1588(ctx, base);
	// mr r30,r3
	ctx.r30.u64 = ctx.r3.u64;
	// mr r3,r20
	ctx.r3.u64 = ctx.r20.u64;
	// mr r4,r30
	ctx.r4.u64 = ctx.r30.u64;
	// bl 0x8b0cea10
	ctx.lr = 0x8B09CAA0;
	sub_8B0CEA10(ctx, base);
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// bne cr6,0x8b09cbc0
	if (!ctx.cr6.eq) goto loc_8B09CBC0;
	// li r5,0
	ctx.r5.s64 = 0;
	// li r4,0
	ctx.r4.s64 = 0;
	// mr r3,r25
	ctx.r3.u64 = ctx.r25.u64;
	// bl 0x8b0bfd30
	ctx.lr = 0x8B09CAB8;
	sub_8B0BFD30(ctx, base);
	// std r3,152(r1)
	REX_STORE_U64(ctx.r1.u32 + 152, ctx.r3.u64);
	// li r5,0
	ctx.r5.s64 = 0;
	// mr r4,r31
	ctx.r4.u64 = ctx.r31.u64;
	// mr r3,r24
	ctx.r3.u64 = ctx.r24.u64;
	// bl 0x8b0bfd30
	ctx.lr = 0x8B09CACC;
	sub_8B0BFD30(ctx, base);
	// lwz r11,0(r28)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r28.u32 + 0);
	// mr r30,r3
	ctx.r30.u64 = ctx.r3.u64;
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// addi r5,r1,152
	ctx.r5.s64 = ctx.r1.s64 + 152;
	// mr r3,r28
	ctx.r3.u64 = ctx.r28.u64;
	// lwz r10,0(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 0);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B09CAEC;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// clrlwi r9,r3,24
	ctx.r9.u64 = ctx.r3.u32 & 0xFF;
	// cmplwi cr6,r9,0
	ctx.cr6.compare<uint32_t>(ctx.r9.u32, 0, ctx.xer);
	// bne cr6,0x8b09cb28
	if (!ctx.cr6.eq) goto loc_8B09CB28;
	// li r5,0
	ctx.r5.s64 = 0;
	// li r4,0
	ctx.r4.s64 = 0;
	// mr r3,r25
	ctx.r3.u64 = ctx.r25.u64;
	// bl 0x8b0bfd30
	ctx.lr = 0x8B09CB08;
	sub_8B0BFD30(ctx, base);
	// mr r8,r3
	ctx.r8.u64 = ctx.r3.u64;
	// mr r7,r30
	ctx.r7.u64 = ctx.r30.u64;
	// lwz r3,124(r1)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r1.u32 + 124);
	// mr r6,r29
	ctx.r6.u64 = ctx.r29.u64;
	// mr r5,r31
	ctx.r5.u64 = ctx.r31.u64;
	// mr r4,r26
	ctx.r4.u64 = ctx.r26.u64;
	// bl 0x8b0df298
	ctx.lr = 0x8B09CB24;
	sub_8B0DF298(ctx, base);
	// b 0x8b09cd3c
	goto loc_8B09CD3C;
loc_8B09CB28:
	// mr r3,r15
	ctx.r3.u64 = ctx.r15.u64;
	// ld r8,152(r1)
	ctx.r8.u64 = REX_LOAD_U64(ctx.r1.u32 + 152);
	// mr r7,r30
	ctx.r7.u64 = ctx.r30.u64;
	// mr r6,r29
	ctx.r6.u64 = ctx.r29.u64;
	// mr r5,r31
	ctx.r5.u64 = ctx.r31.u64;
	// mr r4,r26
	ctx.r4.u64 = ctx.r26.u64;
	// bl 0x8b0df298
	ctx.lr = 0x8B09CB44;
	sub_8B0DF298(ctx, base);
	// mr r4,r31
	ctx.r4.u64 = ctx.r31.u64;
	// mr r3,r24
	ctx.r3.u64 = ctx.r24.u64;
	// ld r5,152(r1)
	ctx.r5.u64 = REX_LOAD_U64(ctx.r1.u32 + 152);
	// bl 0x8b0c0190
	ctx.lr = 0x8B09CB54;
	sub_8B0C0190(ctx, base);
	// cmplwi cr6,r19,0
	ctx.cr6.compare<uint32_t>(ctx.r19.u32, 0, ctx.xer);
	// beq cr6,0x8b09cd3c
	if (ctx.cr6.eq) goto loc_8B09CD3C;
	// addi r11,r1,184
	ctx.r11.s64 = ctx.r1.s64 + 184;
	// stw r18,176(r1)
	REX_STORE_U32(ctx.r1.u32 + 176, ctx.r18.u32);
	// mr r4,r16
	ctx.r4.u64 = ctx.r16.u64;
	// li r5,0
	ctx.r5.s64 = 0;
	// mr r3,r27
	ctx.r3.u64 = ctx.r27.u64;
	// std r18,0(r11)
	REX_STORE_U64(ctx.r11.u32 + 0, ctx.r18.u64);
	// std r18,8(r11)
	REX_STORE_U64(ctx.r11.u32 + 8, ctx.r18.u64);
	// bl 0x8b0bfc38
	ctx.lr = 0x8B09CB7C;
	sub_8B0BFC38(ctx, base);
	// ld r10,152(r1)
	ctx.r10.u64 = REX_LOAD_U64(ctx.r1.u32 + 152);
	// li r9,2
	ctx.r9.s64 = 2;
	// stw r3,176(r1)
	REX_STORE_U32(ctx.r1.u32 + 176, ctx.r3.u32);
	// mr r4,r17
	ctx.r4.u64 = ctx.r17.u64;
	// lwz r31,0(r19)
	ctx.r31.u64 = REX_LOAD_U32(ctx.r19.u32 + 0);
	// stb r9,184(r1)
	REX_STORE_U8(ctx.r1.u32 + 184, ctx.r9.u8);
	// li r5,0
	ctx.r5.s64 = 0;
	// mr r3,r23
	ctx.r3.u64 = ctx.r23.u64;
	// std r10,192(r1)
	REX_STORE_U64(ctx.r1.u32 + 192, ctx.r10.u64);
	// bl 0x8b0bfc38
	ctx.lr = 0x8B09CBA4;
	sub_8B0BFC38(ctx, base);
	// lwz r8,0(r31)
	ctx.r8.u64 = REX_LOAD_U32(ctx.r31.u32 + 0);
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// mr r3,r19
	ctx.r3.u64 = ctx.r19.u64;
	// addi r5,r1,176
	ctx.r5.s64 = ctx.r1.s64 + 176;
	// mtctr r8
	ctx.ctr.u64 = ctx.r8.u64;
	// bctrl 
	ctx.lr = 0x8B09CBBC;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// b 0x8b09cd3c
	goto loc_8B09CD3C;
loc_8B09CBC0:
	// mr r4,r30
	ctx.r4.u64 = ctx.r30.u64;
	// lwz r3,128(r1)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r1.u32 + 128);
	// bl 0x8b0cea10
	ctx.lr = 0x8B09CBCC;
	sub_8B0CEA10(ctx, base);
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// bne cr6,0x8b09cd14
	if (!ctx.cr6.eq) goto loc_8B09CD14;
	// li r4,0
	ctx.r4.s64 = 0;
	// fmr f1,f30
	ctx.fpscr.disableFlushMode();
	ctx.f1.f64 = ctx.f30.f64;
	// mr r3,r25
	ctx.r3.u64 = ctx.r25.u64;
	// bl 0x8b0bfee0
	ctx.lr = 0x8B09CBE4;
	sub_8B0BFEE0(ctx, base);
	// stfs f1,80(r1)
	ctx.fpscr.disableFlushMode();
	temp.f32 = float(ctx.f1.f64);
	REX_STORE_U32(ctx.r1.u32 + 80, temp.u32);
	// mr r4,r31
	ctx.r4.u64 = ctx.r31.u64;
	// fmr f1,f30
	ctx.f1.f64 = ctx.f30.f64;
	// mr r3,r24
	ctx.r3.u64 = ctx.r24.u64;
	// bl 0x8b0bfee0
	ctx.lr = 0x8B09CBF8;
	sub_8B0BFEE0(ctx, base);
	// lwz r11,0(r28)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r28.u32 + 0);
	// addi r5,r1,80
	ctx.r5.s64 = ctx.r1.s64 + 80;
	// fmr f31,f1
	ctx.fpscr.disableFlushMode();
	ctx.f31.f64 = ctx.f1.f64;
	// mr r3,r28
	ctx.r3.u64 = ctx.r28.u64;
	// lwz r10,4(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 4);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B09CC14;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// clrlwi r9,r3,24
	ctx.r9.u64 = ctx.r3.u32 & 0xFF;
	// cmplwi cr6,r9,0
	ctx.cr6.compare<uint32_t>(ctx.r9.u32, 0, ctx.xer);
	// bne cr6,0x8b09cc60
	if (!ctx.cr6.eq) goto loc_8B09CC60;
	// li r4,0
	ctx.r4.s64 = 0;
	// fmr f1,f30
	ctx.fpscr.disableFlushMode();
	ctx.f1.f64 = ctx.f30.f64;
	// mr r3,r25
	ctx.r3.u64 = ctx.r25.u64;
	// bl 0x8b0bfee0
	ctx.lr = 0x8B09CC30;
	sub_8B0BFEE0(ctx, base);
	// fmr f2,f1
	ctx.fpscr.disableFlushMode();
	ctx.f2.f64 = ctx.f1.f64;
	// stfd f2,56(r1)
	REX_STORE_U64(ctx.r1.u32 + 56, ctx.f2.u64);
	// ld r8,56(r1)
	ctx.r8.u64 = REX_LOAD_U64(ctx.r1.u32 + 56);
	// stfd f31,48(r1)
	REX_STORE_U64(ctx.r1.u32 + 48, ctx.f31.u64);
	// ld r7,48(r1)
	ctx.r7.u64 = REX_LOAD_U64(ctx.r1.u32 + 48);
	// mr r6,r29
	ctx.r6.u64 = ctx.r29.u64;
	// lwz r3,132(r1)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r1.u32 + 132);
	// mr r5,r31
	ctx.r5.u64 = ctx.r31.u64;
	// fmr f1,f31
	ctx.f1.f64 = ctx.f31.f64;
	// mr r4,r26
	ctx.r4.u64 = ctx.r26.u64;
	// bl 0x8b0df298
	ctx.lr = 0x8B09CC5C;
	sub_8B0DF298(ctx, base);
	// b 0x8b09cd3c
	goto loc_8B09CD3C;
loc_8B09CC60:
	// lfs f2,80(r1)
	ctx.fpscr.disableFlushMode();
	temp.u32 = REX_LOAD_U32(ctx.r1.u32 + 80);
	ctx.f2.f64 = double(temp.f32);
	// mr r3,r14
	ctx.r3.u64 = ctx.r14.u64;
	// stfd f2,56(r1)
	REX_STORE_U64(ctx.r1.u32 + 56, ctx.f2.u64);
	// ld r8,56(r1)
	ctx.r8.u64 = REX_LOAD_U64(ctx.r1.u32 + 56);
	// stfd f31,48(r1)
	REX_STORE_U64(ctx.r1.u32 + 48, ctx.f31.u64);
	// ld r7,48(r1)
	ctx.r7.u64 = REX_LOAD_U64(ctx.r1.u32 + 48);
	// mr r6,r29
	ctx.r6.u64 = ctx.r29.u64;
	// fmr f1,f31
	ctx.f1.f64 = ctx.f31.f64;
	// mr r5,r31
	ctx.r5.u64 = ctx.r31.u64;
	// mr r4,r26
	ctx.r4.u64 = ctx.r26.u64;
	// bl 0x8b0df298
	ctx.lr = 0x8B09CC8C;
	sub_8B0DF298(ctx, base);
	// mr r4,r31
	ctx.r4.u64 = ctx.r31.u64;
	// mr r3,r24
	ctx.r3.u64 = ctx.r24.u64;
	// lfs f1,80(r1)
	ctx.fpscr.disableFlushMode();
	temp.u32 = REX_LOAD_U32(ctx.r1.u32 + 80);
	ctx.f1.f64 = double(temp.f32);
	// bl 0x8b0c0208
	ctx.lr = 0x8B09CC9C;
	sub_8B0C0208(ctx, base);
	// cmplwi cr6,r19,0
	ctx.cr6.compare<uint32_t>(ctx.r19.u32, 0, ctx.xer);
	// beq cr6,0x8b09cd3c
	if (ctx.cr6.eq) goto loc_8B09CD3C;
	// addi r11,r1,184
	ctx.r11.s64 = ctx.r1.s64 + 184;
	// stw r18,176(r1)
	REX_STORE_U32(ctx.r1.u32 + 176, ctx.r18.u32);
	// mr r4,r16
	ctx.r4.u64 = ctx.r16.u64;
	// li r5,0
	ctx.r5.s64 = 0;
	// mr r3,r27
	ctx.r3.u64 = ctx.r27.u64;
	// std r18,0(r11)
	REX_STORE_U64(ctx.r11.u32 + 0, ctx.r18.u64);
	// std r18,8(r11)
	REX_STORE_U64(ctx.r11.u32 + 8, ctx.r18.u64);
	// bl 0x8b0bfc38
	ctx.lr = 0x8B09CCC4;
	sub_8B0BFC38(ctx, base);
	// lfs f0,80(r1)
	ctx.fpscr.disableFlushMode();
	temp.u32 = REX_LOAD_U32(ctx.r1.u32 + 80);
	ctx.f0.f64 = double(temp.f32);
	// fctidz f13,f0
	ctx.f13.s64 = std::isnan(ctx.f0.f64) ? int64_t(0x8000000000000000ULL) : (ctx.f0.f64 > double(LLONG_MAX)) ? LLONG_MAX : simde_mm_cvttsd_si64(simde_mm_load_sd(&ctx.f0.f64));
	// stfd f13,168(r1)
	REX_STORE_U64(ctx.r1.u32 + 168, ctx.f13.u64);
	// li r10,5
	ctx.r10.s64 = 5;
	// stw r3,176(r1)
	REX_STORE_U32(ctx.r1.u32 + 176, ctx.r3.u32);
	// mr r4,r17
	ctx.r4.u64 = ctx.r17.u64;
	// lwz r31,0(r19)
	ctx.r31.u64 = REX_LOAD_U32(ctx.r19.u32 + 0);
	// stb r10,184(r1)
	REX_STORE_U8(ctx.r1.u32 + 184, ctx.r10.u8);
	// li r5,0
	ctx.r5.s64 = 0;
	// mr r3,r23
	ctx.r3.u64 = ctx.r23.u64;
	// ld r9,168(r1)
	ctx.r9.u64 = REX_LOAD_U64(ctx.r1.u32 + 168);
	// std r9,192(r1)
	REX_STORE_U64(ctx.r1.u32 + 192, ctx.r9.u64);
	// bl 0x8b0bfc38
	ctx.lr = 0x8B09CCF8;
	sub_8B0BFC38(ctx, base);
	// lwz r8,0(r31)
	ctx.r8.u64 = REX_LOAD_U32(ctx.r31.u32 + 0);
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// mr r3,r19
	ctx.r3.u64 = ctx.r19.u64;
	// addi r5,r1,176
	ctx.r5.s64 = ctx.r1.s64 + 176;
	// mtctr r8
	ctx.ctr.u64 = ctx.r8.u64;
	// bctrl 
	ctx.lr = 0x8B09CD10;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// b 0x8b09cd3c
	goto loc_8B09CD3C;
loc_8B09CD14:
	// mr r6,r30
	ctx.r6.u64 = ctx.r30.u64;
	// lwz r3,136(r1)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r1.u32 + 136);
	// mr r5,r31
	ctx.r5.u64 = ctx.r31.u64;
	// mr r4,r26
	ctx.r4.u64 = ctx.r26.u64;
	// bl 0x8b0df2e8
	ctx.lr = 0x8B09CD28;
	sub_8B0DF2E8(ctx, base);
	// b 0x8b09cd3c
	goto loc_8B09CD3C;
loc_8B09CD2C:
	// mr r5,r31
	ctx.r5.u64 = ctx.r31.u64;
	// lwz r3,140(r1)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r1.u32 + 140);
	// mr r4,r26
	ctx.r4.u64 = ctx.r26.u64;
	// bl 0x8b0df2e8
	ctx.lr = 0x8B09CD3C;
	sub_8B0DF2E8(ctx, base);
loc_8B09CD3C:
	// mr r3,r25
	ctx.r3.u64 = ctx.r25.u64;
	// bl 0x8b0bf2f0
	ctx.lr = 0x8B09CD44;
	sub_8B0BF2F0(ctx, base);
	// mr r25,r3
	ctx.r25.u64 = ctx.r3.u64;
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// bne cr6,0x8b09ca00
	if (!ctx.cr6.eq) goto loc_8B09CA00;
	// lwz r27,144(r1)
	ctx.r27.u64 = REX_LOAD_U32(ctx.r1.u32 + 144);
loc_8B09CD54:
	// cmplwi cr6,r23,0
	ctx.cr6.compare<uint32_t>(ctx.r23.u32, 0, ctx.xer);
	// beq cr6,0x8b09cd64
	if (ctx.cr6.eq) goto loc_8B09CD64;
	// mr r3,r23
	ctx.r3.u64 = ctx.r23.u64;
	// bl 0x8b0c04f0
	ctx.lr = 0x8B09CD64;
	sub_8B0C04F0(ctx, base);
loc_8B09CD64:
	// lwz r3,84(r1)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r1.u32 + 84);
	// bl 0x8b0bf280
	ctx.lr = 0x8B09CD6C;
	sub_8B0BF280(ctx, base);
	// stw r3,84(r1)
	REX_STORE_U32(ctx.r1.u32 + 84, ctx.r3.u32);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// bne cr6,0x8b09c814
	if (!ctx.cr6.eq) goto loc_8B09C814;
	// lwz r31,388(r1)
	ctx.r31.u64 = REX_LOAD_U32(ctx.r1.u32 + 388);
loc_8B09CD7C:
	// cmplwi cr6,r19,0
	ctx.cr6.compare<uint32_t>(ctx.r19.u32, 0, ctx.xer);
	// beq cr6,0x8b09cd9c
	if (ctx.cr6.eq) goto loc_8B09CD9C;
	// lwz r11,0(r19)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r19.u32 + 0);
	// mr r3,r19
	ctx.r3.u64 = ctx.r19.u64;
	// lwz r10,4(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 4);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B09CD98;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// b 0x8b09cda8
	goto loc_8B09CDA8;
loc_8B09CD9C:
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// addi r3,r11,13568
	ctx.r3.s64 = ctx.r11.s64 + 13568;
	// bl 0x8b0df2a8
	ctx.lr = 0x8B09CDA8;
	sub_8B0DF2A8(ctx, base);
loc_8B09CDA8:
	// lwz r11,0(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 0);
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// lwz r10,8(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 8);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B09CDBC;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// lis r9,-29944
	ctx.r9.s64 = -1962409984;
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// addi r3,r9,13512
	ctx.r3.s64 = ctx.r9.s64 + 13512;
	// bl 0x8b0df298
	ctx.lr = 0x8B09CDCC;
	sub_8B0DF298(ctx, base);
	// addi r1,r1,368
	ctx.r1.s64 = ctx.r1.s64 + 368;
	// lfd f30,-168(r1)
	ctx.fpscr.disableFlushMode();
	ctx.f30.u64 = REX_LOAD_U64(ctx.r1.u32 + -168);
	// lfd f31,-160(r1)
	ctx.f31.u64 = REX_LOAD_U64(ctx.r1.u32 + -160);
	// b 0x8b0cb9d0
	__restgprlr_14(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B09E840) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// std r30,-24(r1)
	REX_STORE_U64(ctx.r1.u32 + -24, ctx.r30.u64);
	// std r31,-16(r1)
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.r31.u64);
	// stwu r1,-112(r1)
	ea = -112 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// addi r3,r3,372
	ctx.r3.s64 = ctx.r3.s64 + 372;
	// mr r30,r4
	ctx.r30.u64 = ctx.r4.u64;
	// bl 0x8b0906a8
	ctx.lr = 0x8B09E864;
	sub_8B0906A8(ctx, base);
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// clrlwi r10,r30,31
	ctx.r10.u64 = ctx.r30.u32 & 0x1;
	// addi r9,r11,14616
	ctx.r9.s64 = ctx.r11.s64 + 14616;
	// cmplwi cr6,r10,0
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 0, ctx.xer);
	// stw r9,0(r31)
	REX_STORE_U32(ctx.r31.u32 + 0, ctx.r9.u32);
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// beq cr6,0x8b09e888
	if (ctx.cr6.eq) goto loc_8B09E888;
	// bl 0x8b090020
	ctx.lr = 0x8B09E884;
	sub_8B090020(ctx, base);
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
loc_8B09E888:
	// addi r1,r1,112
	ctx.r1.s64 = ctx.r1.s64 + 112;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// ld r30,-24(r1)
	ctx.r30.u64 = REX_LOAD_U64(ctx.r1.u32 + -24);
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B09EF00) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9bc
	ctx.lr = 0x8B09EF08;
	__savegprlr_29(ctx, base);
	// stwu r1,-112(r1)
	ea = -112 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// mr r30,r4
	ctx.r30.u64 = ctx.r4.u64;
	// bl 0x8b09e8e8
	ctx.lr = 0x8B09EF14;
	sub_8B09E8E8(ctx, base);
	// mr r29,r3
	ctx.r29.u64 = ctx.r3.u64;
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// bne cr6,0x8b09ef28
	if (!ctx.cr6.eq) goto loc_8B09EF28;
	// addi r1,r1,112
	ctx.r1.s64 = ctx.r1.s64 + 112;
	// b 0x8b0cba0c
	__restgprlr_29(ctx, base);
	return;
loc_8B09EF28:
	// li r3,36
	ctx.r3.s64 = 36;
	// bl 0x8b0bf448
	ctx.lr = 0x8B09EF30;
	sub_8B0BF448(ctx, base);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b09ef4c
	if (ctx.cr6.eq) goto loc_8B09EF4C;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// addi r4,r11,9244
	ctx.r4.s64 = ctx.r11.s64 + 9244;
	// bl 0x8b0bf9f8
	ctx.lr = 0x8B09EF44;
	sub_8B0BF9F8(ctx, base);
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// b 0x8b09ef50
	goto loc_8B09EF50;
loc_8B09EF4C:
	// li r31,0
	ctx.r31.s64 = 0;
loc_8B09EF50:
	// li r4,0
	ctx.r4.s64 = 0;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// bl 0x8b0c7198
	ctx.lr = 0x8B09EF5C;
	sub_8B0C7198(ctx, base);
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// mr r5,r3
	ctx.r5.u64 = ctx.r3.u64;
	// addi r4,r11,15620
	ctx.r4.s64 = ctx.r11.s64 + 15620;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0c0010
	ctx.lr = 0x8B09EF70;
	sub_8B0C0010(ctx, base);
	// mr r4,r29
	ctx.r4.u64 = ctx.r29.u64;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0bfc00
	ctx.lr = 0x8B09EF7C;
	sub_8B0BFC00(ctx, base);
	// lis r10,-29938
	ctx.r10.s64 = -1962016768;
	// mr r4,r31
	ctx.r4.u64 = ctx.r31.u64;
	// lwz r3,4480(r10)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r10.u32 + 4480);
	// lwz r9,0(r3)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r8,8(r9)
	ctx.r8.u64 = REX_LOAD_U32(ctx.r9.u32 + 8);
	// mtctr r8
	ctx.ctr.u64 = ctx.r8.u64;
	// bctrl 
	ctx.lr = 0x8B09EF98;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// li r3,1
	ctx.r3.s64 = 1;
	// addi r1,r1,112
	ctx.r1.s64 = ctx.r1.s64 + 112;
	// b 0x8b0cba0c
	__restgprlr_29(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B09F2D0) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9b4
	ctx.lr = 0x8B09F2D8;
	__savegprlr_27(ctx, base);
	// stwu r1,-128(r1)
	ea = -128 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lwz r11,84(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 84);
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// mr r27,r4
	ctx.r27.u64 = ctx.r4.u64;
	// li r28,0
	ctx.r28.s64 = 0;
	// cmpwi cr6,r11,0
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// ble cr6,0x8b09f330
	if (!ctx.cr6.gt) goto loc_8B09F330;
	// li r30,0
	ctx.r30.s64 = 0;
loc_8B09F2F8:
	// lwz r11,72(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 72);
	// lwzx r29,r30,r11
	ctx.r29.u64 = REX_LOAD_U32(ctx.r30.u32 + ctx.r11.u32);
	// mr r3,r29
	ctx.r3.u64 = ctx.r29.u64;
	// bl 0x8b0beee8
	ctx.lr = 0x8B09F308;
	sub_8B0BEEE8(ctx, base);
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// mr r3,r27
	ctx.r3.u64 = ctx.r27.u64;
	// bl 0x8b0cea10
	ctx.lr = 0x8B09F314;
	sub_8B0CEA10(ctx, base);
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// beq cr6,0x8b09f388
	if (ctx.cr6.eq) goto loc_8B09F388;
	// lwz r11,84(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 84);
	// addi r28,r28,1
	ctx.r28.s64 = ctx.r28.s64 + 1;
	// addi r30,r30,4
	ctx.r30.s64 = ctx.r30.s64 + 4;
	// cmpw cr6,r28,r11
	ctx.cr6.compare<int32_t>(ctx.r28.s32, ctx.r11.s32, ctx.xer);
	// blt cr6,0x8b09f2f8
	if (ctx.cr6.lt) goto loc_8B09F2F8;
loc_8B09F330:
	// lwz r11,100(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 100);
	// li r28,0
	ctx.r28.s64 = 0;
	// cmpwi cr6,r11,0
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// ble cr6,0x8b09f37c
	if (!ctx.cr6.gt) goto loc_8B09F37C;
	// li r30,0
	ctx.r30.s64 = 0;
loc_8B09F344:
	// lwz r11,88(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 88);
	// lwzx r29,r11,r30
	ctx.r29.u64 = REX_LOAD_U32(ctx.r11.u32 + ctx.r30.u32);
	// mr r3,r29
	ctx.r3.u64 = ctx.r29.u64;
	// bl 0x8b0beee8
	ctx.lr = 0x8B09F354;
	sub_8B0BEEE8(ctx, base);
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// mr r3,r27
	ctx.r3.u64 = ctx.r27.u64;
	// bl 0x8b0cea10
	ctx.lr = 0x8B09F360;
	sub_8B0CEA10(ctx, base);
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// beq cr6,0x8b09f388
	if (ctx.cr6.eq) goto loc_8B09F388;
	// lwz r11,100(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 100);
	// addi r28,r28,1
	ctx.r28.s64 = ctx.r28.s64 + 1;
	// addi r30,r30,4
	ctx.r30.s64 = ctx.r30.s64 + 4;
	// cmpw cr6,r28,r11
	ctx.cr6.compare<int32_t>(ctx.r28.s32, ctx.r11.s32, ctx.xer);
	// blt cr6,0x8b09f344
	if (ctx.cr6.lt) goto loc_8B09F344;
loc_8B09F37C:
	// li r3,0
	ctx.r3.s64 = 0;
	// addi r1,r1,128
	ctx.r1.s64 = ctx.r1.s64 + 128;
	// b 0x8b0cba04
	__restgprlr_27(ctx, base);
	return;
loc_8B09F388:
	// mr r3,r29
	ctx.r3.u64 = ctx.r29.u64;
	// addi r1,r1,128
	ctx.r1.s64 = ctx.r1.s64 + 128;
	// b 0x8b0cba04
	__restgprlr_27(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B09F488) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9bc
	ctx.lr = 0x8B09F490;
	__savegprlr_29(ctx, base);
	// stwu r1,-112(r1)
	ea = -112 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// mr r29,r3
	ctx.r29.u64 = ctx.r3.u64;
	// cmplwi cr6,r4,0
	ctx.cr6.compare<uint32_t>(ctx.r4.u32, 0, ctx.xer);
	// beq cr6,0x8b09f588
	if (ctx.cr6.eq) goto loc_8B09F588;
	// lwz r9,16(r3)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r3.u32 + 16);
	// addi r3,r3,4
	ctx.r3.s64 = ctx.r3.s64 + 4;
	// li r11,0
	ctx.r11.s64 = 0;
	// cmpwi cr6,r9,0
	ctx.cr6.compare<int32_t>(ctx.r9.s32, 0, ctx.xer);
	// ble cr6,0x8b09f4d4
	if (!ctx.cr6.gt) goto loc_8B09F4D4;
	// lwz r10,0(r3)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
loc_8B09F4B8:
	// lwz r8,0(r10)
	ctx.r8.u64 = REX_LOAD_U32(ctx.r10.u32 + 0);
	// cmplw cr6,r8,r4
	ctx.cr6.compare<uint32_t>(ctx.r8.u32, ctx.r4.u32, ctx.xer);
	// beq cr6,0x8b09f4dc
	if (ctx.cr6.eq) goto loc_8B09F4DC;
	// addi r11,r11,1
	ctx.r11.s64 = ctx.r11.s64 + 1;
	// addi r10,r10,4
	ctx.r10.s64 = ctx.r10.s64 + 4;
	// cmpw cr6,r11,r9
	ctx.cr6.compare<int32_t>(ctx.r11.s32, ctx.r9.s32, ctx.xer);
	// blt cr6,0x8b09f4b8
	if (ctx.cr6.lt) goto loc_8B09F4B8;
loc_8B09F4D4:
	// li r30,-1
	ctx.r30.s64 = -1;
	// b 0x8b09f4f8
	goto loc_8B09F4F8;
loc_8B09F4DC:
	// mr r30,r11
	ctx.r30.u64 = ctx.r11.u64;
	// cmpwi cr6,r11,0
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// blt cr6,0x8b09f4f8
	if (ctx.cr6.lt) goto loc_8B09F4F8;
	// lwz r10,16(r29)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r29.u32 + 16);
	// cmpw cr6,r11,r10
	ctx.cr6.compare<int32_t>(ctx.r11.s32, ctx.r10.s32, ctx.xer);
	// li r11,1
	ctx.r11.s64 = 1;
	// blt cr6,0x8b09f4fc
	if (ctx.cr6.lt) goto loc_8B09F4FC;
loc_8B09F4F8:
	// li r11,0
	ctx.r11.s64 = 0;
loc_8B09F4FC:
	// clrlwi r11,r11,24
	ctx.r11.u64 = ctx.r11.u32 & 0xFF;
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// beq cr6,0x8b09f588
	if (ctx.cr6.eq) goto loc_8B09F588;
	// lwz r10,20(r29)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r29.u32 + 20);
	// rlwinm r11,r30,2,0,29
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r30.u32 | (ctx.r30.u64 << 32), 2) & 0xFFFFFFFC;
	// addi r31,r29,20
	ctx.r31.s64 = ctx.r29.s64 + 20;
	// lwzx r9,r11,r10
	ctx.r9.u64 = REX_LOAD_U32(ctx.r11.u32 + ctx.r10.u32);
	// addi r9,r9,-1
	ctx.r9.s64 = ctx.r9.s64 + -1;
	// stwx r9,r11,r10
	REX_STORE_U32(ctx.r11.u32 + ctx.r10.u32, ctx.r9.u32);
	// lwz r8,20(r29)
	ctx.r8.u64 = REX_LOAD_U32(ctx.r29.u32 + 20);
	// lwzx r7,r11,r8
	ctx.r7.u64 = REX_LOAD_U32(ctx.r11.u32 + ctx.r8.u32);
	// cmpwi cr6,r7,0
	ctx.cr6.compare<int32_t>(ctx.r7.s32, 0, ctx.xer);
	// bgt cr6,0x8b09f588
	if (ctx.cr6.gt) goto loc_8B09F588;
	// mr r4,r30
	ctx.r4.u64 = ctx.r30.u64;
	// bl 0x8b09f398
	ctx.lr = 0x8B09F538;
	sub_8B09F398(ctx, base);
	// mr r4,r30
	ctx.r4.u64 = ctx.r30.u64;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b09f398
	ctx.lr = 0x8B09F544;
	sub_8B09F398(ctx, base);
	// lwz r11,48(r29)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r29.u32 + 48);
	// li r8,0
	ctx.r8.s64 = 0;
	// cmpwi cr6,r11,0
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// ble cr6,0x8b09f588
	if (!ctx.cr6.gt) goto loc_8B09F588;
	// li r11,0
	ctx.r11.s64 = 0;
loc_8B09F558:
	// lwz r10,36(r29)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r29.u32 + 36);
	// lwzx r9,r10,r11
	ctx.r9.u64 = REX_LOAD_U32(ctx.r10.u32 + ctx.r11.u32);
	// cmpw cr6,r9,r30
	ctx.cr6.compare<int32_t>(ctx.r9.s32, ctx.r30.s32, ctx.xer);
	// blt cr6,0x8b09f574
	if (ctx.cr6.lt) goto loc_8B09F574;
	// rotlwi r9,r9,0
	ctx.r9.u64 = __builtin_rotateleft32(ctx.r9.u32, 0);
	// addi r9,r9,-1
	ctx.r9.s64 = ctx.r9.s64 + -1;
	// stwx r9,r10,r11
	REX_STORE_U32(ctx.r10.u32 + ctx.r11.u32, ctx.r9.u32);
loc_8B09F574:
	// lwz r10,48(r29)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r29.u32 + 48);
	// addi r8,r8,1
	ctx.r8.s64 = ctx.r8.s64 + 1;
	// addi r11,r11,4
	ctx.r11.s64 = ctx.r11.s64 + 4;
	// cmpw cr6,r8,r10
	ctx.cr6.compare<int32_t>(ctx.r8.s32, ctx.r10.s32, ctx.xer);
	// blt cr6,0x8b09f558
	if (ctx.cr6.lt) goto loc_8B09F558;
loc_8B09F588:
	// addi r1,r1,112
	ctx.r1.s64 = ctx.r1.s64 + 112;
	// b 0x8b0cba0c
	__restgprlr_29(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B09F7E8) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9b0
	ctx.lr = 0x8B09F7F0;
	__savegprlr_26(ctx, base);
	// stwu r1,-144(r1)
	ea = -144 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// mr r30,r3
	ctx.r30.u64 = ctx.r3.u64;
	// stw r4,172(r1)
	REX_STORE_U32(ctx.r1.u32 + 172, ctx.r4.u32);
	// mr r3,r4
	ctx.r3.u64 = ctx.r4.u64;
	// mr r28,r4
	ctx.r28.u64 = ctx.r4.u64;
	// bl 0x8b0beee8
	ctx.lr = 0x8B09F808;
	sub_8B0BEEE8(ctx, base);
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// addi r3,r11,9244
	ctx.r3.s64 = ctx.r11.s64 + 9244;
	// bl 0x8b0cea10
	ctx.lr = 0x8B09F818;
	sub_8B0CEA10(ctx, base);
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// bne cr6,0x8b09f86c
	if (!ctx.cr6.eq) goto loc_8B09F86C;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// li r5,0
	ctx.r5.s64 = 0;
	// addi r4,r11,15712
	ctx.r4.s64 = ctx.r11.s64 + 15712;
	// mr r3,r28
	ctx.r3.u64 = ctx.r28.u64;
	// bl 0x8b0bfe68
	ctx.lr = 0x8B09F834;
	sub_8B0BFE68(ctx, base);
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b09f86c
	if (ctx.cr6.eq) goto loc_8B09F86C;
	// mr r3,r28
	ctx.r3.u64 = ctx.r28.u64;
	// bl 0x8b0c04f0
	ctx.lr = 0x8B09F848;
	sub_8B0C04F0(ctx, base);
	// lis r11,-29938
	ctx.r11.s64 = -1962016768;
	// mr r4,r31
	ctx.r4.u64 = ctx.r31.u64;
	// lwz r3,4312(r11)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r11.u32 + 4312);
	// lwz r10,0(r3)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r9,4(r10)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r10.u32 + 4);
	// mtctr r9
	ctx.ctr.u64 = ctx.r9.u64;
	// bctrl 
	ctx.lr = 0x8B09F864;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// addi r1,r1,144
	ctx.r1.s64 = ctx.r1.s64 + 144;
	// b 0x8b0cba00
	__restgprlr_26(ctx, base);
	return;
loc_8B09F86C:
	// lbz r11,52(r30)
	ctx.r11.u64 = REX_LOAD_U8(ctx.r30.u32 + 52);
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// beq cr6,0x8b09f89c
	if (ctx.cr6.eq) goto loc_8B09F89C;
	// lbz r11,53(r30)
	ctx.r11.u64 = REX_LOAD_U8(ctx.r30.u32 + 53);
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// bne cr6,0x8b09f89c
	if (!ctx.cr6.eq) goto loc_8B09F89C;
	// addi r3,r30,56
	ctx.r3.s64 = ctx.r30.s64 + 56;
	// lwz r4,68(r30)
	ctx.r4.u64 = REX_LOAD_U32(ctx.r30.u32 + 68);
	// addi r5,r1,172
	ctx.r5.s64 = ctx.r1.s64 + 172;
	// bl 0x8b09f3f8
	ctx.lr = 0x8B09F894;
	sub_8B09F3F8(ctx, base);
	// addi r1,r1,144
	ctx.r1.s64 = ctx.r1.s64 + 144;
	// b 0x8b0cba00
	__restgprlr_26(ctx, base);
	return;
loc_8B09F89C:
	// li r11,1
	ctx.r11.s64 = 1;
	// addi r26,r30,88
	ctx.r26.s64 = ctx.r30.s64 + 88;
	// stb r11,52(r30)
	REX_STORE_U8(ctx.r30.u32 + 52, ctx.r11.u8);
	// addi r5,r1,172
	ctx.r5.s64 = ctx.r1.s64 + 172;
	// li r4,0
	ctx.r4.s64 = 0;
	// mr r3,r26
	ctx.r3.u64 = ctx.r26.u64;
	// bl 0x8b09f3f8
	ctx.lr = 0x8B09F8B8;
	sub_8B09F3F8(ctx, base);
	// lis r10,-29938
	ctx.r10.s64 = -1962016768;
	// mr r4,r28
	ctx.r4.u64 = ctx.r28.u64;
	// lwz r11,3036(r10)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r10.u32 + 3036);
	// addi r3,r11,4
	ctx.r3.s64 = ctx.r11.s64 + 4;
	// lwz r9,4(r11)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r11.u32 + 4);
	// lwz r8,0(r9)
	ctx.r8.u64 = REX_LOAD_U32(ctx.r9.u32 + 0);
	// mtctr r8
	ctx.ctr.u64 = ctx.r8.u64;
	// bctrl 
	ctx.lr = 0x8B09F8D8;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// li r27,0
	ctx.r27.s64 = 0;
	// lwz r4,48(r30)
	ctx.r4.u64 = REX_LOAD_U32(ctx.r30.u32 + 48);
	// addi r31,r30,36
	ctx.r31.s64 = ctx.r30.s64 + 36;
	// stw r27,80(r1)
	REX_STORE_U32(ctx.r1.u32 + 80, ctx.r27.u32);
	// addi r5,r1,80
	ctx.r5.s64 = ctx.r1.s64 + 80;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b09f3f8
	ctx.lr = 0x8B09F8F4;
	sub_8B09F3F8(ctx, base);
	// lwz r7,48(r30)
	ctx.r7.u64 = REX_LOAD_U32(ctx.r30.u32 + 48);
	// lwz r11,36(r30)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r30.u32 + 36);
	// rlwinm r10,r7,2,0,29
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r7.u32 | (ctx.r7.u64 << 32), 2) & 0xFFFFFFFC;
	// lwz r6,16(r30)
	ctx.r6.u64 = REX_LOAD_U32(ctx.r30.u32 + 16);
	// add r5,r10,r11
	ctx.r5.u64 = ctx.r10.u64 + ctx.r11.u64;
	// lwz r4,-4(r5)
	ctx.r4.u64 = REX_LOAD_U32(ctx.r5.u32 + -4);
	// cmpw cr6,r4,r6
	ctx.cr6.compare<int32_t>(ctx.r4.s32, ctx.r6.s32, ctx.xer);
	// bge cr6,0x8b09f988
	if (!ctx.cr6.lt) goto loc_8B09F988;
loc_8B09F914:
	// lwz r10,12(r31)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r31.u32 + 12);
	// mr r4,r28
	ctx.r4.u64 = ctx.r28.u64;
	// lwz r11,0(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 0);
	// rlwinm r10,r10,2,0,29
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r10.u32 | (ctx.r10.u64 << 32), 2) & 0xFFFFFFFC;
	// lwz r9,4(r30)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r30.u32 + 4);
	// add r8,r10,r11
	ctx.r8.u64 = ctx.r10.u64 + ctx.r11.u64;
	// lwz r7,-4(r8)
	ctx.r7.u64 = REX_LOAD_U32(ctx.r8.u32 + -4);
	// rlwinm r6,r7,2,0,29
	ctx.r6.u64 = __builtin_rotateleft64(ctx.r7.u32 | (ctx.r7.u64 << 32), 2) & 0xFFFFFFFC;
	// lwzx r3,r6,r9
	ctx.r3.u64 = REX_LOAD_U32(ctx.r6.u32 + ctx.r9.u32);
	// lwz r5,0(r3)
	ctx.r5.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r11,0(r5)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r5.u32 + 0);
	// mtctr r11
	ctx.ctr.u64 = ctx.r11.u64;
	// bctrl 
	ctx.lr = 0x8B09F948;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// lwz r10,12(r31)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r31.u32 + 12);
	// lwz r11,0(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 0);
	// rlwinm r10,r10,2,0,29
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r10.u32 | (ctx.r10.u64 << 32), 2) & 0xFFFFFFFC;
	// add r11,r10,r11
	ctx.r11.u64 = ctx.r10.u64 + ctx.r11.u64;
	// addi r10,r11,-4
	ctx.r10.s64 = ctx.r11.s64 + -4;
	// lwz r10,-4(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + -4);
	// addi r9,r10,1
	ctx.r9.s64 = ctx.r10.s64 + 1;
	// stw r9,-4(r11)
	REX_STORE_U32(ctx.r11.u32 + -4, ctx.r9.u32);
	// lwz r11,0(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 0);
	// lwz r8,16(r30)
	ctx.r8.u64 = REX_LOAD_U32(ctx.r30.u32 + 16);
	// lwz r7,12(r31)
	ctx.r7.u64 = REX_LOAD_U32(ctx.r31.u32 + 12);
	// rlwinm r10,r7,2,0,29
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r7.u32 | (ctx.r7.u64 << 32), 2) & 0xFFFFFFFC;
	// add r6,r10,r11
	ctx.r6.u64 = ctx.r10.u64 + ctx.r11.u64;
	// lwz r5,-4(r6)
	ctx.r5.u64 = REX_LOAD_U32(ctx.r6.u32 + -4);
	// cmpw cr6,r5,r8
	ctx.cr6.compare<int32_t>(ctx.r5.s32, ctx.r8.s32, ctx.xer);
	// blt cr6,0x8b09f914
	if (ctx.cr6.lt) goto loc_8B09F914;
loc_8B09F988:
	// lwz r11,12(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 12);
	// addi r11,r11,-1
	ctx.r11.s64 = ctx.r11.s64 + -1;
	// stw r11,12(r31)
	REX_STORE_U32(ctx.r31.u32 + 12, ctx.r11.u32);
	// lwz r10,68(r30)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r30.u32 + 68);
	// cmpwi cr6,r10,0
	ctx.cr6.compare<int32_t>(ctx.r10.s32, 0, ctx.xer);
	// stb r27,52(r30)
	REX_STORE_U8(ctx.r30.u32 + 52, ctx.r27.u8);
	// ble cr6,0x8b09f9f4
	if (!ctx.cr6.gt) goto loc_8B09F9F4;
	// lwz r10,56(r30)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r30.u32 + 56);
	// addi r31,r30,56
	ctx.r31.s64 = ctx.r30.s64 + 56;
	// lwz r9,68(r30)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r30.u32 + 68);
	// addic. r11,r9,-1
	ctx.xer.ca = ctx.r9.u32 > 0;
	ctx.r11.s64 = ctx.r9.s64 + -1;
	ctx.cr0.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// lwz r29,0(r10)
	ctx.r29.u64 = REX_LOAD_U32(ctx.r10.u32 + 0);
	// ble 0x8b09f9cc
	if (!ctx.cr0.gt) goto loc_8B09F9CC;
	// lwz r3,0(r31)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r31.u32 + 0);
	// rlwinm r5,r11,2,0,29
	ctx.r5.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 2) & 0xFFFFFFFC;
	// addi r4,r3,4
	ctx.r4.s64 = ctx.r3.s64 + 4;
	// bl 0x8b0cc060
	ctx.lr = 0x8B09F9CC;
	sub_8B0CC060(ctx, base);
loc_8B09F9CC:
	// lwz r11,12(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 12);
	// mr r4,r29
	ctx.r4.u64 = ctx.r29.u64;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// addi r11,r11,-1
	ctx.r11.s64 = ctx.r11.s64 + -1;
	// stw r11,12(r31)
	REX_STORE_U32(ctx.r31.u32 + 12, ctx.r11.u32);
	// lwz r10,0(r30)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r30.u32 + 0);
	// lwz r9,8(r10)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r10.u32 + 8);
	// mtctr r9
	ctx.ctr.u64 = ctx.r9.u64;
	// bctrl 
	ctx.lr = 0x8B09F9F0;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// b 0x8b09faa4
	goto loc_8B09FAA4;
loc_8B09F9F4:
	// lwz r11,84(r30)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r30.u32 + 84);
	// mr r29,r27
	ctx.r29.u64 = ctx.r27.u64;
	// cmpwi cr6,r11,0
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// ble cr6,0x8b09fa28
	if (!ctx.cr6.gt) goto loc_8B09FA28;
	// mr r31,r27
	ctx.r31.u64 = ctx.r27.u64;
loc_8B09FA08:
	// lwz r11,72(r30)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r30.u32 + 72);
	// lwzx r3,r31,r11
	ctx.r3.u64 = REX_LOAD_U32(ctx.r31.u32 + ctx.r11.u32);
	// bl 0x8b0c04f0
	ctx.lr = 0x8B09FA14;
	sub_8B0C04F0(ctx, base);
	// lwz r10,84(r30)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r30.u32 + 84);
	// addi r29,r29,1
	ctx.r29.s64 = ctx.r29.s64 + 1;
	// addi r31,r31,4
	ctx.r31.s64 = ctx.r31.s64 + 4;
	// cmpw cr6,r29,r10
	ctx.cr6.compare<int32_t>(ctx.r29.s32, ctx.r10.s32, ctx.xer);
	// blt cr6,0x8b09fa08
	if (ctx.cr6.lt) goto loc_8B09FA08;
loc_8B09FA28:
	// lwz r11,80(r30)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r30.u32 + 80);
	// lis r31,-29944
	ctx.r31.s64 = -1962409984;
	// stw r27,84(r30)
	REX_STORE_U32(ctx.r30.u32 + 84, ctx.r27.u32);
	// cmpwi cr6,r11,0
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// blt cr6,0x8b09fa68
	if (ctx.cr6.lt) goto loc_8B09FA68;
	// lwz r4,72(r30)
	ctx.r4.u64 = REX_LOAD_U32(ctx.r30.u32 + 72);
	// cmplwi cr6,r4,0
	ctx.cr6.compare<uint32_t>(ctx.r4.u32, 0, ctx.xer);
	// beq cr6,0x8b09fa64
	if (ctx.cr6.eq) goto loc_8B09FA64;
	// lwz r11,1144(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 1144);
	// lwz r3,0(r11)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r11.u32 + 0);
	// lwz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r10,20(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 20);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B09FA60;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// stw r27,72(r30)
	REX_STORE_U32(ctx.r30.u32 + 72, ctx.r27.u32);
loc_8B09FA64:
	// stw r27,76(r30)
	REX_STORE_U32(ctx.r30.u32 + 76, ctx.r27.u32);
loc_8B09FA68:
	// lwz r11,8(r26)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r26.u32 + 8);
	// stw r27,12(r26)
	REX_STORE_U32(ctx.r26.u32 + 12, ctx.r27.u32);
	// cmpwi cr6,r11,0
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// blt cr6,0x8b09faa4
	if (ctx.cr6.lt) goto loc_8B09FAA4;
	// lwz r4,0(r26)
	ctx.r4.u64 = REX_LOAD_U32(ctx.r26.u32 + 0);
	// cmplwi cr6,r4,0
	ctx.cr6.compare<uint32_t>(ctx.r4.u32, 0, ctx.xer);
	// beq cr6,0x8b09faa0
	if (ctx.cr6.eq) goto loc_8B09FAA0;
	// lwz r11,1144(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 1144);
	// lwz r3,0(r11)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r11.u32 + 0);
	// lwz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r10,20(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 20);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B09FA9C;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// stw r27,0(r26)
	REX_STORE_U32(ctx.r26.u32 + 0, ctx.r27.u32);
loc_8B09FAA0:
	// stw r27,4(r26)
	REX_STORE_U32(ctx.r26.u32 + 4, ctx.r27.u32);
loc_8B09FAA4:
	// cmplwi cr6,r28,0
	ctx.cr6.compare<uint32_t>(ctx.r28.u32, 0, ctx.xer);
	// beq cr6,0x8b09fab4
	if (ctx.cr6.eq) goto loc_8B09FAB4;
	// mr r3,r28
	ctx.r3.u64 = ctx.r28.u64;
	// bl 0x8b0c04f0
	ctx.lr = 0x8B09FAB4;
	sub_8B0C04F0(ctx, base);
loc_8B09FAB4:
	// addi r1,r1,144
	ctx.r1.s64 = ctx.r1.s64 + 144;
	// b 0x8b0cba00
	__restgprlr_26(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0A0610) {
	REX_FUNC_PROLOGUE();
	// addi r3,r3,8
	ctx.r3.s64 = ctx.r3.s64 + 8;
	// b 0x8b09b4e0
	sub_8B09B4E0(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0A0618) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// std r31,-16(r1)
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.r31.u64);
	// stwu r1,-96(r1)
	ea = -96 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lwz r4,192(r3)
	ctx.r4.u64 = REX_LOAD_U32(ctx.r3.u32 + 192);
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// addi r3,r11,16520
	ctx.r3.s64 = ctx.r11.s64 + 16520;
	// bl 0x8b0df298
	ctx.lr = 0x8B0A063C;
	sub_8B0DF298(ctx, base);
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b09fd50
	ctx.lr = 0x8B0A0644;
	sub_8B09FD50(ctx, base);
	// addi r1,r1,96
	ctx.r1.s64 = ctx.r1.s64 + 96;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0A0658) {
	REX_FUNC_PROLOGUE();
	// ld r3,184(r3)
	ctx.r3.u64 = REX_LOAD_U64(ctx.r3.u32 + 184);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0A0660) {
	REX_FUNC_PROLOGUE();
	// addi r3,r3,24
	ctx.r3.s64 = ctx.r3.s64 + 24;
	// b 0x8b0994a8
	sub_8B0994A8(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0A0758) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9bc
	ctx.lr = 0x8B0A0760;
	__savegprlr_29(ctx, base);
	// stwu r1,-112(r1)
	ea = -112 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// mr r30,r3
	ctx.r30.u64 = ctx.r3.u64;
	// li r3,36
	ctx.r3.s64 = 36;
	// mr r29,r4
	ctx.r29.u64 = ctx.r4.u64;
	// bl 0x8b0bf448
	ctx.lr = 0x8B0A0774;
	sub_8B0BF448(ctx, base);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0a0790
	if (ctx.cr6.eq) goto loc_8B0A0790;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// addi r4,r11,16588
	ctx.r4.s64 = ctx.r11.s64 + 16588;
	// bl 0x8b0bf9f8
	ctx.lr = 0x8B0A0788;
	sub_8B0BF9F8(ctx, base);
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// b 0x8b0a0794
	goto loc_8B0A0794;
loc_8B0A0790:
	// li r31,0
	ctx.r31.s64 = 0;
loc_8B0A0794:
	// li r5,1
	ctx.r5.s64 = 1;
	// mr r4,r29
	ctx.r4.u64 = ctx.r29.u64;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0c0668
	ctx.lr = 0x8B0A07A4;
	sub_8B0C0668(ctx, base);
	// mr r4,r31
	ctx.r4.u64 = ctx.r31.u64;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// bl 0x8b09ff28
	ctx.lr = 0x8B0A07B0;
	sub_8B09FF28(ctx, base);
	// cmplwi cr6,r31,0
	ctx.cr6.compare<uint32_t>(ctx.r31.u32, 0, ctx.xer);
	// beq cr6,0x8b0a07c0
	if (ctx.cr6.eq) goto loc_8B0A07C0;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0c04f0
	ctx.lr = 0x8B0A07C0;
	sub_8B0C04F0(ctx, base);
loc_8B0A07C0:
	// addi r1,r1,112
	ctx.r1.s64 = ctx.r1.s64 + 112;
	// b 0x8b0cba0c
	__restgprlr_29(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0A07F0) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// std r31,-16(r1)
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.r31.u64);
	// stwu r1,-96(r1)
	ea = -96 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// lwz r3,152(r3)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r3.u32 + 152);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0a081c
	if (ctx.cr6.eq) goto loc_8B0A081C;
	// bl 0x8b0aaf48
	ctx.lr = 0x8B0A0814;
	sub_8B0AAF48(ctx, base);
	// li r11,0
	ctx.r11.s64 = 0;
	// stw r11,152(r31)
	REX_STORE_U32(ctx.r31.u32 + 152, ctx.r11.u32);
loc_8B0A081C:
	// li r11,5
	ctx.r11.s64 = 5;
	// addi r4,r31,156
	ctx.r4.s64 = ctx.r31.s64 + 156;
	// stw r11,192(r31)
	REX_STORE_U32(ctx.r31.u32 + 192, ctx.r11.u32);
	// addi r3,r31,8
	ctx.r3.s64 = ctx.r31.s64 + 8;
	// bl 0x8b09ba10
	ctx.lr = 0x8B0A0830;
	sub_8B09BA10(ctx, base);
	// addi r1,r1,96
	ctx.r1.s64 = ctx.r1.s64 + 96;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0A0988) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// std r30,-24(r1)
	REX_STORE_U64(ctx.r1.u32 + -24, ctx.r30.u64);
	// std r31,-16(r1)
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.r31.u64);
	// stwu r1,-112(r1)
	ea = -112 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// mr r30,r3
	ctx.r30.u64 = ctx.r3.u64;
	// mr r31,r4
	ctx.r31.u64 = ctx.r4.u64;
	// cmplwi cr6,r4,0
	ctx.cr6.compare<uint32_t>(ctx.r4.u32, 0, ctx.xer);
	// beq cr6,0x8b0a09d4
	if (ctx.cr6.eq) goto loc_8B0A09D4;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// li r5,0
	ctx.r5.s64 = 0;
	// addi r4,r11,3636
	ctx.r4.s64 = ctx.r11.s64 + 3636;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0bfa88
	ctx.lr = 0x8B0A09C0;
	sub_8B0BFA88(ctx, base);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// bne cr6,0x8b0a09d4
	if (!ctx.cr6.eq) goto loc_8B0A09D4;
	// mr r4,r31
	ctx.r4.u64 = ctx.r31.u64;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// bl 0x8b0a01f8
	ctx.lr = 0x8B0A09D4;
	sub_8B0A01F8(ctx, base);
loc_8B0A09D4:
	// addi r1,r1,112
	ctx.r1.s64 = ctx.r1.s64 + 112;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// ld r30,-24(r1)
	ctx.r30.u64 = REX_LOAD_U64(ctx.r1.u32 + -24);
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0A0B38) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// std r30,-24(r1)
	REX_STORE_U64(ctx.r1.u32 + -24, ctx.r30.u64);
	// std r31,-16(r1)
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.r31.u64);
	// stwu r1,-112(r1)
	ea = -112 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// mr r30,r3
	ctx.r30.u64 = ctx.r3.u64;
	// li r11,4
	ctx.r11.s64 = 4;
	// li r3,36
	ctx.r3.s64 = 36;
	// stw r11,248(r30)
	REX_STORE_U32(ctx.r30.u32 + 248, ctx.r11.u32);
	// bl 0x8b0bf448
	ctx.lr = 0x8B0A0B60;
	sub_8B0BF448(ctx, base);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0a0b7c
	if (ctx.cr6.eq) goto loc_8B0A0B7C;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// addi r4,r11,17092
	ctx.r4.s64 = ctx.r11.s64 + 17092;
	// bl 0x8b0bf9f8
	ctx.lr = 0x8B0A0B74;
	sub_8B0BF9F8(ctx, base);
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// b 0x8b0a0b80
	goto loc_8B0A0B80;
loc_8B0A0B7C:
	// li r31,0
	ctx.r31.s64 = 0;
loc_8B0A0B80:
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// mr r5,r30
	ctx.r5.u64 = ctx.r30.u64;
	// addi r4,r11,16280
	ctx.r4.s64 = ctx.r11.s64 + 16280;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0c0250
	ctx.lr = 0x8B0A0B94;
	sub_8B0C0250(ctx, base);
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// lis r9,-29944
	ctx.r9.s64 = -1962409984;
	// addi r5,r10,17084
	ctx.r5.s64 = ctx.r10.s64 + 17084;
	// addi r4,r9,17076
	ctx.r4.s64 = ctx.r9.s64 + 17076;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0c0010
	ctx.lr = 0x8B0A0BAC;
	sub_8B0C0010(ctx, base);
	// lwz r8,0(r30)
	ctx.r8.u64 = REX_LOAD_U32(ctx.r30.u32 + 0);
	// mr r4,r31
	ctx.r4.u64 = ctx.r31.u64;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// lwz r7,48(r8)
	ctx.r7.u64 = REX_LOAD_U32(ctx.r8.u32 + 48);
	// mtctr r7
	ctx.ctr.u64 = ctx.r7.u64;
	// bctrl 
	ctx.lr = 0x8B0A0BC4;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// addi r1,r1,112
	ctx.r1.s64 = ctx.r1.s64 + 112;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// ld r30,-24(r1)
	ctx.r30.u64 = REX_LOAD_U64(ctx.r1.u32 + -24);
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0A0EE0) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// std r31,-16(r1)
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.r31.u64);
	// stwu r1,-96(r1)
	ea = -96 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// li r5,0
	ctx.r5.s64 = 0;
	// addi r4,r11,10128
	ctx.r4.s64 = ctx.r11.s64 + 10128;
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// lwz r3,180(r3)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r3.u32 + 180);
	// bl 0x8b0bfd30
	ctx.lr = 0x8B0A0F08;
	sub_8B0BFD30(ctx, base);
	// cmpldi cr6,r3,0
	ctx.cr6.compare<uint64_t>(ctx.r3.u64, 0, ctx.xer);
	// bne cr6,0x8b0a0f14
	if (!ctx.cr6.eq) goto loc_8B0A0F14;
	// ld r3,16(r31)
	ctx.r3.u64 = REX_LOAD_U64(ctx.r31.u32 + 16);
loc_8B0A0F14:
	// addi r1,r1,96
	ctx.r1.s64 = ctx.r1.s64 + 96;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0A10F8) {
	REX_FUNC_PROLOGUE();
	PPCRegister temp{};
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb994
	ctx.lr = 0x8B0A1100;
	__savegprlr_19(ctx, base);
	// stwu r1,-464(r1)
	ea = -464 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lwz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// mr r21,r3
	ctx.r21.u64 = ctx.r3.u64;
	// lwz r10,44(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 44);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B0A1118;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// clrlwi r9,r3,24
	ctx.r9.u64 = ctx.r3.u32 & 0xFF;
	// cmplwi cr6,r9,0
	ctx.cr6.compare<uint32_t>(ctx.r9.u32, 0, ctx.xer);
	// bne cr6,0x8b0a12e4
	if (!ctx.cr6.eq) goto loc_8B0A12E4;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lfs f13,176(r21)
	ctx.fpscr.disableFlushMode();
	temp.u32 = REX_LOAD_U32(ctx.r21.u32 + 176);
	ctx.f13.f64 = double(temp.f32);
	// lfs f0,8492(r11)
	temp.u32 = REX_LOAD_U32(ctx.r11.u32 + 8492);
	ctx.f0.f64 = double(temp.f32);
	// fcmpu cr6,f13,f0
	ctx.cr6.compare(ctx.f13.f64, ctx.f0.f64);
	// blt cr6,0x8b0a12e4
	if (ctx.cr6.lt) goto loc_8B0A12E4;
	// bl 0x8b0df2f8
	ctx.lr = 0x8B0A113C;
	sub_8B0DF2F8(ctx, base);
	// lfs f0,176(r21)
	ctx.fpscr.disableFlushMode();
	temp.u32 = REX_LOAD_U32(ctx.r21.u32 + 176);
	ctx.f0.f64 = double(temp.f32);
	// fsub f13,f1,f0
	ctx.f13.f64 = ctx.f1.f64 - ctx.f0.f64;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lfd f0,17272(r11)
	ctx.f0.u64 = REX_LOAD_U64(ctx.r11.u32 + 17272);
	// fcmpu cr6,f13,f0
	ctx.cr6.compare(ctx.f13.f64, ctx.f0.f64);
	// blt cr6,0x8b0a12e4
	if (ctx.cr6.lt) goto loc_8B0A12E4;
	// bl 0x8b0df2f8
	ctx.lr = 0x8B0A1158;
	sub_8B0DF2F8(ctx, base);
	// frsp f0,f1
	ctx.fpscr.disableFlushMode();
	ctx.f0.f64 = double(float(ctx.f1.f64));
	// stfs f0,176(r21)
	temp.f32 = float(ctx.f0.f64);
	REX_STORE_U32(ctx.r21.u32 + 176, temp.u32);
	// li r11,0
	ctx.r11.s64 = 0;
	// addi r5,r1,80
	ctx.r5.s64 = ctx.r1.s64 + 80;
	// ld r4,184(r21)
	ctx.r4.u64 = REX_LOAD_U64(ctx.r21.u32 + 184);
	// lwz r3,180(r21)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r21.u32 + 180);
	// stw r11,80(r1)
	REX_STORE_U32(ctx.r1.u32 + 80, ctx.r11.u32);
	// bl 0x8b091540
	ctx.lr = 0x8B0A1178;
	sub_8B091540(ctx, base);
	// lwz r24,80(r1)
	ctx.r24.u64 = REX_LOAD_U32(ctx.r1.u32 + 80);
	// cmplwi cr6,r24,0
	ctx.cr6.compare<uint32_t>(ctx.r24.u32, 0, ctx.xer);
	// beq cr6,0x8b0a12e4
	if (ctx.cr6.eq) goto loc_8B0A12E4;
	// li r29,0
	ctx.r29.s64 = 0;
	// bl 0x8b0df2c8
	ctx.lr = 0x8B0A118C;
	sub_8B0DF2C8(ctx, base);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0a12e4
	if (ctx.cr6.eq) goto loc_8B0A12E4;
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// lis r9,-29944
	ctx.r9.s64 = -1962409984;
	// lis r8,-29944
	ctx.r8.s64 = -1962409984;
	// lis r7,-29944
	ctx.r7.s64 = -1962409984;
	// lis r6,-29944
	ctx.r6.s64 = -1962409984;
	// lis r5,-29944
	ctx.r5.s64 = -1962409984;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lis r22,-29938
	ctx.r22.s64 = -1962016768;
	// addi r28,r10,16504
	ctx.r28.s64 = ctx.r10.s64 + 16504;
	// addi r27,r9,3616
	ctx.r27.s64 = ctx.r9.s64 + 3616;
	// addi r26,r8,17184
	ctx.r26.s64 = ctx.r8.s64 + 17184;
	// addi r20,r7,17244
	ctx.r20.s64 = ctx.r7.s64 + 17244;
	// addi r19,r6,17236
	ctx.r19.s64 = ctx.r6.s64 + 17236;
	// addi r23,r5,17220
	ctx.r23.s64 = ctx.r5.s64 + 17220;
	// addi r25,r11,1791
	ctx.r25.s64 = ctx.r11.s64 + 1791;
loc_8B0A11D0:
	// mr r3,r29
	ctx.r3.u64 = ctx.r29.u64;
	// li r31,0
	ctx.r31.s64 = 0;
	// bl 0x8b0df2b8
	ctx.lr = 0x8B0A11DC;
	sub_8B0DF2B8(ctx, base);
	// mr r30,r3
	ctx.r30.u64 = ctx.r3.u64;
	// mr r3,r29
	ctx.r3.u64 = ctx.r29.u64;
	// bl 0x8b0df2d8
	ctx.lr = 0x8B0A11E8;
	sub_8B0DF2D8(ctx, base);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// bne cr6,0x8b0a1210
	if (!ctx.cr6.eq) goto loc_8B0A1210;
	// lwz r11,2364(r22)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r22.u32 + 2364);
	// mr r4,r30
	ctx.r4.u64 = ctx.r30.u64;
	// lwz r3,80(r11)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r11.u32 + 80);
	// lwz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r10,0(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 0);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B0A120C;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
loc_8B0A1210:
	// mr r4,r23
	ctx.r4.u64 = ctx.r23.u64;
	// mr r5,r29
	ctx.r5.u64 = ctx.r29.u64;
	// addi r3,r1,96
	ctx.r3.s64 = ctx.r1.s64 + 96;
	// bl 0x8b090220
	ctx.lr = 0x8B0A1220;
	sub_8B090220(ctx, base);
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// mr r5,r25
	ctx.r5.u64 = ctx.r25.u64;
	// mr r3,r24
	ctx.r3.u64 = ctx.r24.u64;
	// bl 0x8b0c1588
	ctx.lr = 0x8B0A1230;
	sub_8B0C1588(ctx, base);
	// clrlwi r11,r31,24
	ctx.r11.u64 = ctx.r31.u32 & 0xFF;
	// mr r30,r19
	ctx.r30.u64 = ctx.r19.u64;
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// bne cr6,0x8b0a1244
	if (!ctx.cr6.eq) goto loc_8B0A1244;
	// mr r30,r25
	ctx.r30.u64 = ctx.r25.u64;
loc_8B0A1244:
	// lbz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U8(ctx.r3.u32 + 0);
	// lbz r10,0(r30)
	ctx.r10.u64 = REX_LOAD_U8(ctx.r30.u32 + 0);
	// cmplw cr6,r11,r10
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, ctx.r10.u32, ctx.xer);
	// beq cr6,0x8b0a12d4
	if (ctx.cr6.eq) goto loc_8B0A12D4;
	// li r3,36
	ctx.r3.s64 = 36;
	// bl 0x8b0bf448
	ctx.lr = 0x8B0A125C;
	sub_8B0BF448(ctx, base);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0a1274
	if (ctx.cr6.eq) goto loc_8B0A1274;
	// mr r4,r20
	ctx.r4.u64 = ctx.r20.u64;
	// bl 0x8b0bf9f8
	ctx.lr = 0x8B0A126C;
	sub_8B0BF9F8(ctx, base);
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// b 0x8b0a1278
	goto loc_8B0A1278;
loc_8B0A1274:
	// li r31,0
	ctx.r31.s64 = 0;
loc_8B0A1278:
	// mr r4,r26
	ctx.r4.u64 = ctx.r26.u64;
	// mr r5,r29
	ctx.r5.u64 = ctx.r29.u64;
	// addi r3,r1,96
	ctx.r3.s64 = ctx.r1.s64 + 96;
	// bl 0x8b090220
	ctx.lr = 0x8B0A1288;
	sub_8B090220(ctx, base);
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// li r5,0
	ctx.r5.s64 = 0;
	// mr r3,r24
	ctx.r3.u64 = ctx.r24.u64;
	// bl 0x8b0bfd30
	ctx.lr = 0x8B0A1298;
	sub_8B0BFD30(ctx, base);
	// mr r5,r3
	ctx.r5.u64 = ctx.r3.u64;
	// mr r4,r27
	ctx.r4.u64 = ctx.r27.u64;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0c0190
	ctx.lr = 0x8B0A12A8;
	sub_8B0C0190(ctx, base);
	// mr r4,r28
	ctx.r4.u64 = ctx.r28.u64;
	// mr r5,r30
	ctx.r5.u64 = ctx.r30.u64;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0c0010
	ctx.lr = 0x8B0A12B8;
	sub_8B0C0010(ctx, base);
	// mr r4,r31
	ctx.r4.u64 = ctx.r31.u64;
	// mr r3,r21
	ctx.r3.u64 = ctx.r21.u64;
	// bl 0x8b09ff28
	ctx.lr = 0x8B0A12C4;
	sub_8B09FF28(ctx, base);
	// cmplwi cr6,r31,0
	ctx.cr6.compare<uint32_t>(ctx.r31.u32, 0, ctx.xer);
	// beq cr6,0x8b0a12d4
	if (ctx.cr6.eq) goto loc_8B0A12D4;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0c04f0
	ctx.lr = 0x8B0A12D4;
	sub_8B0C04F0(ctx, base);
loc_8B0A12D4:
	// addi r29,r29,1
	ctx.r29.s64 = ctx.r29.s64 + 1;
	// bl 0x8b0df2c8
	ctx.lr = 0x8B0A12DC;
	sub_8B0DF2C8(ctx, base);
	// cmplw cr6,r29,r3
	ctx.cr6.compare<uint32_t>(ctx.r29.u32, ctx.r3.u32, ctx.xer);
	// blt cr6,0x8b0a11d0
	if (ctx.cr6.lt) goto loc_8B0A11D0;
loc_8B0A12E4:
	// addi r1,r1,464
	ctx.r1.s64 = ctx.r1.s64 + 464;
	// b 0x8b0cb9e4
	__restgprlr_19(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0A1B38) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9b8
	ctx.lr = 0x8B0A1B40;
	__savegprlr_28(ctx, base);
	// stwu r1,-128(r1)
	ea = -128 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// addi r28,r11,3616
	ctx.r28.s64 = ctx.r11.s64 + 3616;
	// mr r3,r4
	ctx.r3.u64 = ctx.r4.u64;
	// li r5,0
	ctx.r5.s64 = 0;
	// mr r4,r28
	ctx.r4.u64 = ctx.r28.u64;
	// bl 0x8b0bfd30
	ctx.lr = 0x8B0A1B60;
	sub_8B0BFD30(ctx, base);
	// li r30,0
	ctx.r30.s64 = 0;
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// lwz r3,180(r31)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r31.u32 + 180);
	// addi r5,r1,80
	ctx.r5.s64 = ctx.r1.s64 + 80;
	// stw r30,80(r1)
	REX_STORE_U32(ctx.r1.u32 + 80, ctx.r30.u32);
	// bl 0x8b091540
	ctx.lr = 0x8B0A1B78;
	sub_8B091540(ctx, base);
	// lwz r3,80(r1)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r1.u32 + 80);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0a1c24
	if (ctx.cr6.eq) goto loc_8B0A1C24;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// li r5,0
	ctx.r5.s64 = 0;
	// addi r4,r11,16356
	ctx.r4.s64 = ctx.r11.s64 + 16356;
	// bl 0x8b0bfd30
	ctx.lr = 0x8B0A1B94;
	sub_8B0BFD30(ctx, base);
	// lwz r10,0(r31)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r31.u32 + 0);
	// mr r29,r3
	ctx.r29.u64 = ctx.r3.u64;
	// li r4,0
	ctx.r4.s64 = 0;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// lwz r9,28(r10)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r10.u32 + 28);
	// mtctr r9
	ctx.ctr.u64 = ctx.r9.u64;
	// bctrl 
	ctx.lr = 0x8B0A1BB0;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// cmpld cr6,r29,r3
	ctx.cr6.compare<uint64_t>(ctx.r29.u64, ctx.r3.u64, ctx.xer);
	// bne cr6,0x8b0a1bcc
	if (!ctx.cr6.eq) goto loc_8B0A1BCC;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// addi r3,r11,17516
	ctx.r3.s64 = ctx.r11.s64 + 17516;
	// bl 0x8b0df2e8
	ctx.lr = 0x8B0A1BC4;
	sub_8B0DF2E8(ctx, base);
	// addi r1,r1,128
	ctx.r1.s64 = ctx.r1.s64 + 128;
	// b 0x8b0cba08
	__restgprlr_28(ctx, base);
	return;
loc_8B0A1BCC:
	// li r3,36
	ctx.r3.s64 = 36;
	// bl 0x8b0bf448
	ctx.lr = 0x8B0A1BD4;
	sub_8B0BF448(ctx, base);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0a1bec
	if (ctx.cr6.eq) goto loc_8B0A1BEC;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// addi r4,r11,17488
	ctx.r4.s64 = ctx.r11.s64 + 17488;
	// bl 0x8b0bf9f8
	ctx.lr = 0x8B0A1BE8;
	sub_8B0BF9F8(ctx, base);
	// mr r30,r3
	ctx.r30.u64 = ctx.r3.u64;
loc_8B0A1BEC:
	// mr r4,r28
	ctx.r4.u64 = ctx.r28.u64;
	// mr r5,r29
	ctx.r5.u64 = ctx.r29.u64;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// bl 0x8b0c0190
	ctx.lr = 0x8B0A1BFC;
	sub_8B0C0190(ctx, base);
	// mr r4,r30
	ctx.r4.u64 = ctx.r30.u64;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b09ff28
	ctx.lr = 0x8B0A1C08;
	sub_8B09FF28(ctx, base);
	// mr r4,r29
	ctx.r4.u64 = ctx.r29.u64;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0a1578
	ctx.lr = 0x8B0A1C14;
	sub_8B0A1578(ctx, base);
	// cmplwi cr6,r30,0
	ctx.cr6.compare<uint32_t>(ctx.r30.u32, 0, ctx.xer);
	// beq cr6,0x8b0a1c24
	if (ctx.cr6.eq) goto loc_8B0A1C24;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// bl 0x8b0c04f0
	ctx.lr = 0x8B0A1C24;
	sub_8B0C04F0(ctx, base);
loc_8B0A1C24:
	// addi r1,r1,128
	ctx.r1.s64 = ctx.r1.s64 + 128;
	// b 0x8b0cba08
	__restgprlr_28(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0A24A8) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9b4
	ctx.lr = 0x8B0A24B0;
	__savegprlr_27(ctx, base);
	// stwu r1,-144(r1)
	ea = -144 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// mr r28,r4
	ctx.r28.u64 = ctx.r4.u64;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// mr r27,r3
	ctx.r27.u64 = ctx.r3.u64;
	// li r5,0
	ctx.r5.s64 = 0;
	// addi r4,r11,3616
	ctx.r4.s64 = ctx.r11.s64 + 3616;
	// mr r3,r28
	ctx.r3.u64 = ctx.r28.u64;
	// bl 0x8b0bfd30
	ctx.lr = 0x8B0A24D0;
	sub_8B0BFD30(ctx, base);
	// li r10,0
	ctx.r10.s64 = 0;
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// lwz r3,180(r27)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r27.u32 + 180);
	// addi r5,r1,80
	ctx.r5.s64 = ctx.r1.s64 + 80;
	// stw r10,80(r1)
	REX_STORE_U32(ctx.r1.u32 + 80, ctx.r10.u32);
	// bl 0x8b091540
	ctx.lr = 0x8B0A24E8;
	sub_8B091540(ctx, base);
	// lwz r29,80(r1)
	ctx.r29.u64 = REX_LOAD_U32(ctx.r1.u32 + 80);
	// cmplwi cr6,r29,0
	ctx.cr6.compare<uint32_t>(ctx.r29.u32, 0, ctx.xer);
	// beq cr6,0x8b0a2570
	if (ctx.cr6.eq) goto loc_8B0A2570;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// li r5,0
	ctx.r5.s64 = 0;
	// addi r31,r11,17280
	ctx.r31.s64 = ctx.r11.s64 + 17280;
	// mr r3,r29
	ctx.r3.u64 = ctx.r29.u64;
	// mr r4,r31
	ctx.r4.u64 = ctx.r31.u64;
	// bl 0x8b0bfa88
	ctx.lr = 0x8B0A250C;
	sub_8B0BFA88(ctx, base);
	// mr r30,r3
	ctx.r30.u64 = ctx.r3.u64;
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0a252c
	if (ctx.cr6.eq) goto loc_8B0A252C;
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// mr r3,r29
	ctx.r3.u64 = ctx.r29.u64;
	// bl 0x8b0bf1a0
	ctx.lr = 0x8B0A2524;
	sub_8B0BF1A0(ctx, base);
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// bl 0x8b0c04f0
	ctx.lr = 0x8B0A252C;
	sub_8B0C04F0(ctx, base);
loc_8B0A252C:
	// mr r4,r31
	ctx.r4.u64 = ctx.r31.u64;
	// li r5,0
	ctx.r5.s64 = 0;
	// mr r3,r28
	ctx.r3.u64 = ctx.r28.u64;
	// bl 0x8b0bfa88
	ctx.lr = 0x8B0A253C;
	sub_8B0BFA88(ctx, base);
	// mr r30,r3
	ctx.r30.u64 = ctx.r3.u64;
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0a2564
	if (ctx.cr6.eq) goto loc_8B0A2564;
	// mr r4,r31
	ctx.r4.u64 = ctx.r31.u64;
	// li r5,1
	ctx.r5.s64 = 1;
	// mr r3,r29
	ctx.r3.u64 = ctx.r29.u64;
	// bl 0x8b0bfa88
	ctx.lr = 0x8B0A2558;
	sub_8B0BFA88(ctx, base);
	// mr r4,r30
	ctx.r4.u64 = ctx.r30.u64;
	// li r5,1
	ctx.r5.s64 = 1;
	// bl 0x8b0c0668
	ctx.lr = 0x8B0A2564;
	sub_8B0C0668(ctx, base);
loc_8B0A2564:
	// mr r4,r29
	ctx.r4.u64 = ctx.r29.u64;
	// mr r3,r27
	ctx.r3.u64 = ctx.r27.u64;
	// bl 0x8b0a0758
	ctx.lr = 0x8B0A2570;
	sub_8B0A0758(ctx, base);
loc_8B0A2570:
	// addi r1,r1,144
	ctx.r1.s64 = ctx.r1.s64 + 144;
	// b 0x8b0cba04
	__restgprlr_27(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0A28F0) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb99c
	ctx.lr = 0x8B0A28F8;
	__savegprlr_21(ctx, base);
	// stwu r1,-496(r1)
	ea = -496 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// mr r30,r3
	ctx.r30.u64 = ctx.r3.u64;
	// li r3,36
	ctx.r3.s64 = 36;
	// bl 0x8b0bf448
	ctx.lr = 0x8B0A2908;
	sub_8B0BF448(ctx, base);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0a2924
	if (ctx.cr6.eq) goto loc_8B0A2924;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// addi r4,r11,17052
	ctx.r4.s64 = ctx.r11.s64 + 17052;
	// bl 0x8b0bf9f8
	ctx.lr = 0x8B0A291C;
	sub_8B0BF9F8(ctx, base);
	// mr r23,r3
	ctx.r23.u64 = ctx.r3.u64;
	// b 0x8b0a2928
	goto loc_8B0A2928;
loc_8B0A2924:
	// li r23,0
	ctx.r23.s64 = 0;
loc_8B0A2928:
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// ld r5,16(r30)
	ctx.r5.u64 = REX_LOAD_U64(ctx.r30.u32 + 16);
	// mr r3,r23
	ctx.r3.u64 = ctx.r23.u64;
	// addi r4,r11,17044
	ctx.r4.s64 = ctx.r11.s64 + 17044;
	// bl 0x8b0c0190
	ctx.lr = 0x8B0A293C;
	sub_8B0C0190(ctx, base);
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// mr r3,r23
	ctx.r3.u64 = ctx.r23.u64;
	// ld r5,184(r30)
	ctx.r5.u64 = REX_LOAD_U64(ctx.r30.u32 + 184);
	// addi r22,r11,16356
	ctx.r22.s64 = ctx.r11.s64 + 16356;
	// mr r4,r22
	ctx.r4.u64 = ctx.r22.u64;
	// bl 0x8b0c0190
	ctx.lr = 0x8B0A2954;
	sub_8B0C0190(ctx, base);
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// li r5,0
	ctx.r5.s64 = 0;
	// lwz r3,180(r30)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r30.u32 + 180);
	// addi r4,r10,3636
	ctx.r4.s64 = ctx.r10.s64 + 3636;
	// bl 0x8b0bfa88
	ctx.lr = 0x8B0A2968;
	sub_8B0BFA88(ctx, base);
	// mr r25,r3
	ctx.r25.u64 = ctx.r3.u64;
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0a2a98
	if (ctx.cr6.eq) goto loc_8B0A2A98;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// li r5,0
	ctx.r5.s64 = 0;
	// addi r4,r11,3624
	ctx.r4.s64 = ctx.r11.s64 + 3624;
	// bl 0x8b0bfc38
	ctx.lr = 0x8B0A2984;
	sub_8B0BFC38(ctx, base);
	// mr r21,r3
	ctx.r21.u64 = ctx.r3.u64;
	// li r27,1
	ctx.r27.s64 = 1;
	// cmpwi cr6,r3,1
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 1, ctx.xer);
	// ble cr6,0x8b0a2a98
	if (!ctx.cr6.gt) goto loc_8B0A2A98;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// lis r9,-29944
	ctx.r9.s64 = -1962409984;
	// lis r8,-29944
	ctx.r8.s64 = -1962409984;
	// addi r24,r11,17872
	ctx.r24.s64 = ctx.r11.s64 + 17872;
	// addi r29,r10,17864
	ctx.r29.s64 = ctx.r10.s64 + 17864;
	// addi r28,r9,1791
	ctx.r28.s64 = ctx.r9.s64 + 1791;
	// addi r26,r8,3580
	ctx.r26.s64 = ctx.r8.s64 + 3580;
loc_8B0A29B4:
	// mr r4,r26
	ctx.r4.u64 = ctx.r26.u64;
	// mr r5,r27
	ctx.r5.u64 = ctx.r27.u64;
	// addi r3,r1,144
	ctx.r3.s64 = ctx.r1.s64 + 144;
	// bl 0x8b090220
	ctx.lr = 0x8B0A29C4;
	sub_8B090220(ctx, base);
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// li r5,0
	ctx.r5.s64 = 0;
	// mr r3,r25
	ctx.r3.u64 = ctx.r25.u64;
	// bl 0x8b0bfa88
	ctx.lr = 0x8B0A29D4;
	sub_8B0BFA88(ctx, base);
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0a2a8c
	if (ctx.cr6.eq) goto loc_8B0A2A8C;
	// addi r4,r30,24
	ctx.r4.s64 = ctx.r30.s64 + 24;
	// addi r3,r1,80
	ctx.r3.s64 = ctx.r1.s64 + 80;
	// li r5,60
	ctx.r5.s64 = 60;
	// bl 0x8b0cbb30
	ctx.lr = 0x8B0A29F0;
	sub_8B0CBB30(ctx, base);
	// mr r5,r28
	ctx.r5.u64 = ctx.r28.u64;
	// mr r4,r29
	ctx.r4.u64 = ctx.r29.u64;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0c1588
	ctx.lr = 0x8B0A2A00;
	sub_8B0C1588(ctx, base);
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// addi r3,r1,88
	ctx.r3.s64 = ctx.r1.s64 + 88;
	// bl 0x8b099558
	ctx.lr = 0x8B0A2A0C;
	sub_8B099558(ctx, base);
	// addi r11,r1,88
	ctx.r11.s64 = ctx.r1.s64 + 88;
	// addi r10,r30,192
	ctx.r10.s64 = ctx.r30.s64 + 192;
	// addi r8,r11,36
	ctx.r8.s64 = ctx.r11.s64 + 36;
loc_8B0A2A18:
	// lbz r9,0(r11)
	ctx.r9.u64 = REX_LOAD_U8(ctx.r11.u32 + 0);
	// lbz r7,0(r10)
	ctx.r7.u64 = REX_LOAD_U8(ctx.r10.u32 + 0);
	// subf. r9,r7,r9
	ctx.r9.u64 = ctx.r9.u64 - ctx.r7.u64;
	ctx.cr0.compare<int32_t>(ctx.r9.s32, 0, ctx.xer);
	// bne 0x8b0a2a38
	if (!ctx.cr0.eq) goto loc_8B0A2A38;
	// addi r11,r11,1
	ctx.r11.s64 = ctx.r11.s64 + 1;
	// addi r10,r10,1
	ctx.r10.s64 = ctx.r10.s64 + 1;
	// cmpw cr6,r11,r8
	ctx.cr6.compare<int32_t>(ctx.r11.s32, ctx.r8.s32, ctx.xer);
	// bne cr6,0x8b0a2a18
	if (!ctx.cr6.eq) goto loc_8B0A2A18;
loc_8B0A2A38:
	// cmpwi cr6,r9,0
	ctx.cr6.compare<int32_t>(ctx.r9.s32, 0, ctx.xer);
	// beq cr6,0x8b0a2a8c
	if (ctx.cr6.eq) goto loc_8B0A2A8C;
	// mr r4,r22
	ctx.r4.u64 = ctx.r22.u64;
	// li r5,0
	ctx.r5.s64 = 0;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0bfd30
	ctx.lr = 0x8B0A2A50;
	sub_8B0BFD30(ctx, base);
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// addi r5,r1,80
	ctx.r5.s64 = ctx.r1.s64 + 80;
	// lwz r3,152(r30)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r30.u32 + 152);
	// mr r4,r31
	ctx.r4.u64 = ctx.r31.u64;
	// bl 0x8b0aa8c0
	ctx.lr = 0x8B0A2A64;
	sub_8B0AA8C0(ctx, base);
	// clrlwi r11,r3,24
	ctx.r11.u64 = ctx.r3.u32 & 0xFF;
	// mr r4,r31
	ctx.r4.u64 = ctx.r31.u64;
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// beq cr6,0x8b0a2a84
	if (ctx.cr6.eq) goto loc_8B0A2A84;
	// mr r5,r23
	ctx.r5.u64 = ctx.r23.u64;
	// lwz r3,152(r30)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r30.u32 + 152);
	// bl 0x8b0aa5a0
	ctx.lr = 0x8B0A2A80;
	sub_8B0AA5A0(ctx, base);
	// b 0x8b0a2a8c
	goto loc_8B0A2A8C;
loc_8B0A2A84:
	// mr r3,r24
	ctx.r3.u64 = ctx.r24.u64;
	// bl 0x8b0df2e8
	ctx.lr = 0x8B0A2A8C;
	sub_8B0DF2E8(ctx, base);
loc_8B0A2A8C:
	// addi r27,r27,1
	ctx.r27.s64 = ctx.r27.s64 + 1;
	// cmpw cr6,r27,r21
	ctx.cr6.compare<int32_t>(ctx.r27.s32, ctx.r21.s32, ctx.xer);
	// blt cr6,0x8b0a29b4
	if (ctx.cr6.lt) goto loc_8B0A29B4;
loc_8B0A2A98:
	// cmplwi cr6,r23,0
	ctx.cr6.compare<uint32_t>(ctx.r23.u32, 0, ctx.xer);
	// beq cr6,0x8b0a2aa8
	if (ctx.cr6.eq) goto loc_8B0A2AA8;
	// mr r3,r23
	ctx.r3.u64 = ctx.r23.u64;
	// bl 0x8b0c04f0
	ctx.lr = 0x8B0A2AA8;
	sub_8B0C04F0(ctx, base);
loc_8B0A2AA8:
	// addi r1,r1,496
	ctx.r1.s64 = ctx.r1.s64 + 496;
	// b 0x8b0cb9ec
	__restgprlr_21(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0A30B8) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9b4
	ctx.lr = 0x8B0A30C0;
	__savegprlr_27(ctx, base);
	// stwu r1,-128(r1)
	ea = -128 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lwz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// mr r30,r4
	ctx.r30.u64 = ctx.r4.u64;
	// lwz r10,28(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 28);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B0A30DC;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// lwz r11,248(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 248);
	// mr r27,r3
	ctx.r27.u64 = ctx.r3.u64;
	// cmpwi cr6,r11,3
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 3, ctx.xer);
	// beq cr6,0x8b0a30f4
	if (ctx.cr6.eq) goto loc_8B0A30F4;
	// cmpwi cr6,r11,5
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 5, ctx.xer);
	// bne cr6,0x8b0a3100
	if (!ctx.cr6.eq) goto loc_8B0A3100;
loc_8B0A30F4:
	// mr r4,r30
	ctx.r4.u64 = ctx.r30.u64;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0a1578
	ctx.lr = 0x8B0A3100;
	sub_8B0A1578(ctx, base);
loc_8B0A3100:
	// lwz r11,0(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 0);
	// li r4,0
	ctx.r4.s64 = 0;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// li r28,0
	ctx.r28.s64 = 0;
	// lwz r10,28(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 28);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B0A311C;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// lwz r9,248(r31)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r31.u32 + 248);
	// mr r29,r3
	ctx.r29.u64 = ctx.r3.u64;
	// cmpwi cr6,r9,2
	ctx.cr6.compare<int32_t>(ctx.r9.s32, 2, ctx.xer);
	// bne cr6,0x8b0a3138
	if (!ctx.cr6.eq) goto loc_8B0A3138;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// addi r28,r11,17624
	ctx.r28.s64 = ctx.r11.s64 + 17624;
	// b 0x8b0a31f4
	goto loc_8B0A31F4;
loc_8B0A3138:
	// cmpld cr6,r27,r30
	ctx.cr6.compare<uint64_t>(ctx.r27.u64, ctx.r30.u64, ctx.xer);
	// bne cr6,0x8b0a32cc
	if (!ctx.cr6.eq) goto loc_8B0A32CC;
	// ld r11,184(r31)
	ctx.r11.u64 = REX_LOAD_U64(ctx.r31.u32 + 184);
	// cmpld cr6,r29,r11
	ctx.cr6.compare<uint64_t>(ctx.r29.u64, ctx.r11.u64, ctx.xer);
	// beq cr6,0x8b0a31e8
	if (ctx.cr6.eq) goto loc_8B0A31E8;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// mr r4,r29
	ctx.r4.u64 = ctx.r29.u64;
	// addi r3,r11,18056
	ctx.r3.s64 = ctx.r11.s64 + 18056;
	// bl 0x8b0df298
	ctx.lr = 0x8B0A315C;
	sub_8B0DF298(ctx, base);
	// li r3,36
	ctx.r3.s64 = 36;
	// bl 0x8b0bf448
	ctx.lr = 0x8B0A3164;
	sub_8B0BF448(ctx, base);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0a3180
	if (ctx.cr6.eq) goto loc_8B0A3180;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// addi r4,r11,17456
	ctx.r4.s64 = ctx.r11.s64 + 17456;
	// bl 0x8b0bf9f8
	ctx.lr = 0x8B0A3178;
	sub_8B0BF9F8(ctx, base);
	// mr r30,r3
	ctx.r30.u64 = ctx.r3.u64;
	// b 0x8b0a3184
	goto loc_8B0A3184;
loc_8B0A3180:
	// li r30,0
	ctx.r30.s64 = 0;
loc_8B0A3184:
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// addi r5,r11,4560
	ctx.r5.s64 = ctx.r11.s64 + 4560;
	// addi r4,r10,4072
	ctx.r4.s64 = ctx.r10.s64 + 4072;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// bl 0x8b0c0010
	ctx.lr = 0x8B0A319C;
	sub_8B0C0010(ctx, base);
	// lis r9,-29944
	ctx.r9.s64 = -1962409984;
	// mr r5,r29
	ctx.r5.u64 = ctx.r29.u64;
	// addi r4,r9,3616
	ctx.r4.s64 = ctx.r9.s64 + 3616;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// bl 0x8b0c0190
	ctx.lr = 0x8B0A31B0;
	sub_8B0C0190(ctx, base);
	// lis r8,-29944
	ctx.r8.s64 = -1962409984;
	// lis r7,-29944
	ctx.r7.s64 = -1962409984;
	// addi r5,r8,18048
	ctx.r5.s64 = ctx.r8.s64 + 18048;
	// addi r4,r7,18036
	ctx.r4.s64 = ctx.r7.s64 + 18036;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// bl 0x8b0c0010
	ctx.lr = 0x8B0A31C8;
	sub_8B0C0010(ctx, base);
	// lwz r6,0(r31)
	ctx.r6.u64 = REX_LOAD_U32(ctx.r31.u32 + 0);
	// mr r4,r30
	ctx.r4.u64 = ctx.r30.u64;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// lwz r5,48(r6)
	ctx.r5.u64 = REX_LOAD_U32(ctx.r6.u32 + 48);
	// mtctr r5
	ctx.ctr.u64 = ctx.r5.u64;
	// bctrl 
	ctx.lr = 0x8B0A31E0;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// addi r1,r1,128
	ctx.r1.s64 = ctx.r1.s64 + 128;
	// b 0x8b0cba04
	__restgprlr_27(ctx, base);
	return;
loc_8B0A31E8:
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// addi r3,r11,17980
	ctx.r3.s64 = ctx.r11.s64 + 17980;
	// bl 0x8b0df298
	ctx.lr = 0x8B0A31F4;
	sub_8B0DF298(ctx, base);
loc_8B0A31F4:
	// li r3,36
	ctx.r3.s64 = 36;
	// bl 0x8b0bf448
	ctx.lr = 0x8B0A31FC;
	sub_8B0BF448(ctx, base);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0a3218
	if (ctx.cr6.eq) goto loc_8B0A3218;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// addi r4,r11,17092
	ctx.r4.s64 = ctx.r11.s64 + 17092;
	// bl 0x8b0bf9f8
	ctx.lr = 0x8B0A3210;
	sub_8B0BF9F8(ctx, base);
	// mr r30,r3
	ctx.r30.u64 = ctx.r3.u64;
	// b 0x8b0a321c
	goto loc_8B0A321C;
loc_8B0A3218:
	// li r30,0
	ctx.r30.s64 = 0;
loc_8B0A321C:
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// mr r5,r31
	ctx.r5.u64 = ctx.r31.u64;
	// addi r4,r11,16280
	ctx.r4.s64 = ctx.r11.s64 + 16280;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// bl 0x8b0c0250
	ctx.lr = 0x8B0A3230;
	sub_8B0C0250(ctx, base);
	// cmplwi cr6,r28,0
	ctx.cr6.compare<uint32_t>(ctx.r28.u32, 0, ctx.xer);
	// beq cr6,0x8b0a324c
	if (ctx.cr6.eq) goto loc_8B0A324C;
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// li r11,4
	ctx.r11.s64 = 4;
	// mr r5,r28
	ctx.r5.u64 = ctx.r28.u64;
	// addi r4,r10,17076
	ctx.r4.s64 = ctx.r10.s64 + 17076;
	// b 0x8b0a32a8
	goto loc_8B0A32A8;
loc_8B0A324C:
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lwz r3,180(r31)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r31.u32 + 180);
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// addi r5,r11,1791
	ctx.r5.s64 = ctx.r11.s64 + 1791;
	// addi r4,r10,11228
	ctx.r4.s64 = ctx.r10.s64 + 11228;
	// bl 0x8b0c1588
	ctx.lr = 0x8B0A3264;
	sub_8B0C1588(ctx, base);
	// lis r9,-29944
	ctx.r9.s64 = -1962409984;
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// addi r3,r9,11204
	ctx.r3.s64 = ctx.r9.s64 + 11204;
	// bl 0x8b0cea10
	ctx.lr = 0x8B0A3274;
	sub_8B0CEA10(ctx, base);
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// bne cr6,0x8b0a3294
	if (!ctx.cr6.eq) goto loc_8B0A3294;
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// lis r9,-29944
	ctx.r9.s64 = -1962409984;
	// li r11,4
	ctx.r11.s64 = 4;
	// addi r5,r10,17480
	ctx.r5.s64 = ctx.r10.s64 + 17480;
	// addi r4,r9,17076
	ctx.r4.s64 = ctx.r9.s64 + 17076;
	// b 0x8b0a32a8
	goto loc_8B0A32A8;
loc_8B0A3294:
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// lis r9,-29944
	ctx.r9.s64 = -1962409984;
	// li r11,5
	ctx.r11.s64 = 5;
	// addi r5,r10,3904
	ctx.r5.s64 = ctx.r10.s64 + 3904;
	// addi r4,r9,8928
	ctx.r4.s64 = ctx.r9.s64 + 8928;
loc_8B0A32A8:
	// stw r11,248(r31)
	REX_STORE_U32(ctx.r31.u32 + 248, ctx.r11.u32);
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// bl 0x8b0c0010
	ctx.lr = 0x8B0A32B4;
	sub_8B0C0010(ctx, base);
	// lwz r11,0(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 0);
	// mr r4,r30
	ctx.r4.u64 = ctx.r30.u64;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// lwz r10,48(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 48);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B0A32CC;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
loc_8B0A32CC:
	// addi r1,r1,128
	ctx.r1.s64 = ctx.r1.s64 + 128;
	// b 0x8b0cba04
	__restgprlr_27(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0A3948) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// std r31,-16(r1)
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.r31.u64);
	// stwu r1,-96(r1)
	ea = -96 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lis r10,-29938
	ctx.r10.s64 = -1962016768;
	// stw r3,116(r1)
	REX_STORE_U32(ctx.r1.u32 + 116, ctx.r3.u32);
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// addi r31,r10,19100
	ctx.r31.s64 = ctx.r10.s64 + 19100;
	// li r11,0
	ctx.r11.s64 = 0;
	// lwz r9,12(r31)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r31.u32 + 12);
	// cmpwi cr6,r9,0
	ctx.cr6.compare<int32_t>(ctx.r9.s32, 0, ctx.xer);
	// ble cr6,0x8b0a39a4
	if (!ctx.cr6.gt) goto loc_8B0A39A4;
	// lwz r10,0(r31)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r31.u32 + 0);
loc_8B0A397C:
	// lwz r8,0(r10)
	ctx.r8.u64 = REX_LOAD_U32(ctx.r10.u32 + 0);
	// cmplw cr6,r8,r4
	ctx.cr6.compare<uint32_t>(ctx.r8.u32, ctx.r4.u32, ctx.xer);
	// beq cr6,0x8b0a399c
	if (ctx.cr6.eq) goto loc_8B0A399C;
	// addi r11,r11,1
	ctx.r11.s64 = ctx.r11.s64 + 1;
	// addi r10,r10,4
	ctx.r10.s64 = ctx.r10.s64 + 4;
	// cmpw cr6,r11,r9
	ctx.cr6.compare<int32_t>(ctx.r11.s32, ctx.r9.s32, ctx.xer);
	// blt cr6,0x8b0a397c
	if (ctx.cr6.lt) goto loc_8B0A397C;
	// b 0x8b0a39a4
	goto loc_8B0A39A4;
loc_8B0A399C:
	// cmpwi cr6,r11,-1
	ctx.cr6.compare<int32_t>(ctx.r11.s32, -1, ctx.xer);
	// bne cr6,0x8b0a39d4
	if (!ctx.cr6.eq) goto loc_8B0A39D4;
loc_8B0A39A4:
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// addi r3,r11,18428
	ctx.r3.s64 = ctx.r11.s64 + 18428;
	// bl 0x8b0df298
	ctx.lr = 0x8B0A39B0;
	sub_8B0DF298(ctx, base);
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// addi r5,r1,116
	ctx.r5.s64 = ctx.r1.s64 + 116;
	// lwz r4,12(r31)
	ctx.r4.u64 = REX_LOAD_U32(ctx.r31.u32 + 12);
	// bl 0x8b09f3f8
	ctx.lr = 0x8B0A39C0;
	sub_8B09F3F8(ctx, base);
	// addi r1,r1,96
	ctx.r1.s64 = ctx.r1.s64 + 96;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
loc_8B0A39D4:
	// lis r10,-29938
	ctx.r10.s64 = -1962016768;
	// li r11,0
	ctx.r11.s64 = 0;
	// addi r31,r10,19260
	ctx.r31.s64 = ctx.r10.s64 + 19260;
	// lwz r9,12(r31)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r31.u32 + 12);
	// cmpwi cr6,r9,0
	ctx.cr6.compare<int32_t>(ctx.r9.s32, 0, ctx.xer);
	// ble cr6,0x8b0a3a18
	if (!ctx.cr6.gt) goto loc_8B0A3A18;
	// lwz r10,0(r31)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r31.u32 + 0);
loc_8B0A39F0:
	// lwz r8,0(r10)
	ctx.r8.u64 = REX_LOAD_U32(ctx.r10.u32 + 0);
	// cmplw cr6,r8,r4
	ctx.cr6.compare<uint32_t>(ctx.r8.u32, ctx.r4.u32, ctx.xer);
	// beq cr6,0x8b0a3a10
	if (ctx.cr6.eq) goto loc_8B0A3A10;
	// addi r11,r11,1
	ctx.r11.s64 = ctx.r11.s64 + 1;
	// addi r10,r10,4
	ctx.r10.s64 = ctx.r10.s64 + 4;
	// cmpw cr6,r11,r9
	ctx.cr6.compare<int32_t>(ctx.r11.s32, ctx.r9.s32, ctx.xer);
	// blt cr6,0x8b0a39f0
	if (ctx.cr6.lt) goto loc_8B0A39F0;
	// b 0x8b0a3a18
	goto loc_8B0A3A18;
loc_8B0A3A10:
	// cmpwi cr6,r11,-1
	ctx.cr6.compare<int32_t>(ctx.r11.s32, -1, ctx.xer);
	// bne cr6,0x8b0a3a48
	if (!ctx.cr6.eq) goto loc_8B0A3A48;
loc_8B0A3A18:
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// addi r3,r11,18360
	ctx.r3.s64 = ctx.r11.s64 + 18360;
	// bl 0x8b0df298
	ctx.lr = 0x8B0A3A24;
	sub_8B0DF298(ctx, base);
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// addi r5,r1,116
	ctx.r5.s64 = ctx.r1.s64 + 116;
	// lwz r4,12(r31)
	ctx.r4.u64 = REX_LOAD_U32(ctx.r31.u32 + 12);
	// bl 0x8b09f3f8
	ctx.lr = 0x8B0A3A34;
	sub_8B09F3F8(ctx, base);
	// addi r1,r1,96
	ctx.r1.s64 = ctx.r1.s64 + 96;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
loc_8B0A3A48:
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// addi r3,r11,18308
	ctx.r3.s64 = ctx.r11.s64 + 18308;
	// bl 0x8b0df3c8
	ctx.lr = 0x8B0A3A54;
	sub_8B0DF3C8(ctx, base);
	// addi r1,r1,96
	ctx.r1.s64 = ctx.r1.s64 + 96;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0A3C98) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9b8
	ctx.lr = 0x8B0A3CA0;
	__savegprlr_28(ctx, base);
	// stwu r1,-128(r1)
	ea = -128 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// mr r28,r3
	ctx.r28.u64 = ctx.r3.u64;
	// addi r30,r11,4056
	ctx.r30.s64 = ctx.r11.s64 + 4056;
	// mr r31,r4
	ctx.r31.u64 = ctx.r4.u64;
	// mr r3,r4
	ctx.r3.u64 = ctx.r4.u64;
	// li r5,0
	ctx.r5.s64 = 0;
	// mr r4,r30
	ctx.r4.u64 = ctx.r30.u64;
	// bl 0x8b0bfa88
	ctx.lr = 0x8B0A3CC4;
	sub_8B0BFA88(ctx, base);
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// mr r3,r28
	ctx.r3.u64 = ctx.r28.u64;
	// bl 0x8b0a3880
	ctx.lr = 0x8B0A3CD0;
	sub_8B0A3880(ctx, base);
	// li r3,36
	ctx.r3.s64 = 36;
	// bl 0x8b0bf448
	ctx.lr = 0x8B0A3CD8;
	sub_8B0BF448(ctx, base);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0a3cf4
	if (ctx.cr6.eq) goto loc_8B0A3CF4;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// addi r4,r11,18648
	ctx.r4.s64 = ctx.r11.s64 + 18648;
	// bl 0x8b0bf9f8
	ctx.lr = 0x8B0A3CEC;
	sub_8B0BF9F8(ctx, base);
	// mr r29,r3
	ctx.r29.u64 = ctx.r3.u64;
	// b 0x8b0a3cf8
	goto loc_8B0A3CF8;
loc_8B0A3CF4:
	// li r29,0
	ctx.r29.s64 = 0;
loc_8B0A3CF8:
	// mr r4,r30
	ctx.r4.u64 = ctx.r30.u64;
	// li r5,0
	ctx.r5.s64 = 0;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0bfa88
	ctx.lr = 0x8B0A3D08;
	sub_8B0BFA88(ctx, base);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0a3d20
	if (ctx.cr6.eq) goto loc_8B0A3D20;
	// bl 0x8b0c0298
	ctx.lr = 0x8B0A3D14;
	sub_8B0C0298(ctx, base);
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// mr r3,r29
	ctx.r3.u64 = ctx.r29.u64;
	// bl 0x8b0bfc00
	ctx.lr = 0x8B0A3D20;
	sub_8B0BFC00(ctx, base);
loc_8B0A3D20:
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// li r5,0
	ctx.r5.s64 = 0;
	// addi r4,r11,9608
	ctx.r4.s64 = ctx.r11.s64 + 9608;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0bfa88
	ctx.lr = 0x8B0A3D34;
	sub_8B0BFA88(ctx, base);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0a3d4c
	if (ctx.cr6.eq) goto loc_8B0A3D4C;
	// bl 0x8b0c0298
	ctx.lr = 0x8B0A3D40;
	sub_8B0C0298(ctx, base);
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// mr r3,r29
	ctx.r3.u64 = ctx.r29.u64;
	// bl 0x8b0bfc00
	ctx.lr = 0x8B0A3D4C;
	sub_8B0BFC00(ctx, base);
loc_8B0A3D4C:
	// mr r4,r29
	ctx.r4.u64 = ctx.r29.u64;
	// mr r3,r28
	ctx.r3.u64 = ctx.r28.u64;
	// bl 0x8b09ff28
	ctx.lr = 0x8B0A3D58;
	sub_8B09FF28(ctx, base);
	// cmplwi cr6,r29,0
	ctx.cr6.compare<uint32_t>(ctx.r29.u32, 0, ctx.xer);
	// beq cr6,0x8b0a3d68
	if (ctx.cr6.eq) goto loc_8B0A3D68;
	// mr r3,r29
	ctx.r3.u64 = ctx.r29.u64;
	// bl 0x8b0c04f0
	ctx.lr = 0x8B0A3D68;
	sub_8B0C04F0(ctx, base);
loc_8B0A3D68:
	// addi r1,r1,128
	ctx.r1.s64 = ctx.r1.s64 + 128;
	// b 0x8b0cba08
	__restgprlr_28(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0A47A8) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9a4
	ctx.lr = 0x8B0A47B0;
	__savegprlr_23(ctx, base);
	// stwu r1,-768(r1)
	ea = -768 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// mr r3,r4
	ctx.r3.u64 = ctx.r4.u64;
	// mr r27,r4
	ctx.r27.u64 = ctx.r4.u64;
	// bl 0x8b0beee8
	ctx.lr = 0x8B0A47C4;
	sub_8B0BEEE8(ctx, base);
	// lwz r11,248(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 248);
	// mr r30,r3
	ctx.r30.u64 = ctx.r3.u64;
	// cmpwi cr6,r11,2
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 2, ctx.xer);
	// beq cr6,0x8b0a4c44
	if (ctx.cr6.eq) goto loc_8B0A4C44;
	// cmpwi cr6,r11,3
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 3, ctx.xer);
	// bne cr6,0x8b0a4c88
	if (!ctx.cr6.eq) goto loc_8B0A4C88;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// addi r4,r11,17728
	ctx.r4.s64 = ctx.r11.s64 + 17728;
	// bl 0x8b0cea10
	ctx.lr = 0x8B0A47E8;
	sub_8B0CEA10(ctx, base);
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// bne cr6,0x8b0a4804
	if (!ctx.cr6.eq) goto loc_8B0A4804;
	// mr r4,r27
	ctx.r4.u64 = ctx.r27.u64;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0a2ca0
	ctx.lr = 0x8B0A47FC;
	sub_8B0A2CA0(ctx, base);
	// addi r1,r1,768
	ctx.r1.s64 = ctx.r1.s64 + 768;
	// b 0x8b0cb9f4
	__restgprlr_23(ctx, base);
	return;
loc_8B0A4804:
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// addi r4,r11,17596
	ctx.r4.s64 = ctx.r11.s64 + 17596;
	// bl 0x8b0cea10
	ctx.lr = 0x8B0A4814;
	sub_8B0CEA10(ctx, base);
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// bne cr6,0x8b0a4844
	if (!ctx.cr6.eq) goto loc_8B0A4844;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// li r5,0
	ctx.r5.s64 = 0;
	// addi r4,r11,3616
	ctx.r4.s64 = ctx.r11.s64 + 3616;
	// mr r3,r27
	ctx.r3.u64 = ctx.r27.u64;
	// bl 0x8b0bfd30
	ctx.lr = 0x8B0A4830;
	sub_8B0BFD30(ctx, base);
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
loc_8B0A4838:
	// bl 0x8b0a1578
	ctx.lr = 0x8B0A483C;
	sub_8B0A1578(ctx, base);
	// addi r1,r1,768
	ctx.r1.s64 = ctx.r1.s64 + 768;
	// b 0x8b0cb9f4
	__restgprlr_23(ctx, base);
	return;
loc_8B0A4844:
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// addi r4,r11,17488
	ctx.r4.s64 = ctx.r11.s64 + 17488;
	// bl 0x8b0cea10
	ctx.lr = 0x8B0A4854;
	sub_8B0CEA10(ctx, base);
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// bne cr6,0x8b0a4894
	if (!ctx.cr6.eq) goto loc_8B0A4894;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// li r5,0
	ctx.r5.s64 = 0;
	// addi r4,r11,3616
	ctx.r4.s64 = ctx.r11.s64 + 3616;
	// mr r3,r27
	ctx.r3.u64 = ctx.r27.u64;
	// bl 0x8b0bfd30
	ctx.lr = 0x8B0A4870;
	sub_8B0BFD30(ctx, base);
	// ld r10,184(r31)
	ctx.r10.u64 = REX_LOAD_U64(ctx.r31.u32 + 184);
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// cmpld cr6,r3,r10
	ctx.cr6.compare<uint64_t>(ctx.r3.u64, ctx.r10.u64, ctx.xer);
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bne cr6,0x8b0a4838
	if (!ctx.cr6.eq) goto loc_8B0A4838;
	// mr r4,r27
	ctx.r4.u64 = ctx.r27.u64;
	// bl 0x8b0a0b38
	ctx.lr = 0x8B0A488C;
	sub_8B0A0B38(ctx, base);
	// addi r1,r1,768
	ctx.r1.s64 = ctx.r1.s64 + 768;
	// b 0x8b0cb9f4
	__restgprlr_23(ctx, base);
	return;
loc_8B0A4894:
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// addi r4,r11,16552
	ctx.r4.s64 = ctx.r11.s64 + 16552;
	// bl 0x8b0cea10
	ctx.lr = 0x8B0A48A4;
	sub_8B0CEA10(ctx, base);
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// bne cr6,0x8b0a48c0
	if (!ctx.cr6.eq) goto loc_8B0A48C0;
	// mr r4,r27
	ctx.r4.u64 = ctx.r27.u64;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0a2f10
	ctx.lr = 0x8B0A48B8;
	sub_8B0A2F10(ctx, base);
	// addi r1,r1,768
	ctx.r1.s64 = ctx.r1.s64 + 768;
	// b 0x8b0cb9f4
	__restgprlr_23(ctx, base);
	return;
loc_8B0A48C0:
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// addi r4,r11,16588
	ctx.r4.s64 = ctx.r11.s64 + 16588;
	// bl 0x8b0cea10
	ctx.lr = 0x8B0A48D0;
	sub_8B0CEA10(ctx, base);
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// bne cr6,0x8b0a48ec
	if (!ctx.cr6.eq) goto loc_8B0A48EC;
	// mr r4,r27
	ctx.r4.u64 = ctx.r27.u64;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0a3010
	ctx.lr = 0x8B0A48E4;
	sub_8B0A3010(ctx, base);
	// addi r1,r1,768
	ctx.r1.s64 = ctx.r1.s64 + 768;
	// b 0x8b0cb9f4
	__restgprlr_23(ctx, base);
	return;
loc_8B0A48EC:
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// addi r4,r11,18228
	ctx.r4.s64 = ctx.r11.s64 + 18228;
	// bl 0x8b0cea10
	ctx.lr = 0x8B0A48FC;
	sub_8B0CEA10(ctx, base);
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// bne cr6,0x8b0a4bdc
	if (!ctx.cr6.eq) goto loc_8B0A4BDC;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// addi r5,r11,1791
	ctx.r5.s64 = ctx.r11.s64 + 1791;
	// addi r4,r10,13248
	ctx.r4.s64 = ctx.r10.s64 + 13248;
	// mr r3,r27
	ctx.r3.u64 = ctx.r27.u64;
	// bl 0x8b0c1588
	ctx.lr = 0x8B0A491C;
	sub_8B0C1588(ctx, base);
	// mr r30,r3
	ctx.r30.u64 = ctx.r3.u64;
	// addi r3,r1,112
	ctx.r3.s64 = ctx.r1.s64 + 112;
	// mr r4,r30
	ctx.r4.u64 = ctx.r30.u64;
	// bl 0x8b0994f8
	ctx.lr = 0x8B0A492C;
	sub_8B0994F8(ctx, base);
	// lwz r3,160(r31)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r31.u32 + 160);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0a494c
	if (ctx.cr6.eq) goto loc_8B0A494C;
	// lbz r11,172(r31)
	ctx.r11.u64 = REX_LOAD_U8(ctx.r31.u32 + 172);
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// bne cr6,0x8b0a494c
	if (!ctx.cr6.eq) goto loc_8B0A494C;
	// li r4,0
	ctx.r4.s64 = 0;
	// bl 0x8b099978
	ctx.lr = 0x8B0A494C;
	sub_8B099978(ctx, base);
loc_8B0A494C:
	// li r23,0
	ctx.r23.s64 = 0;
	// addi r5,r31,164
	ctx.r5.s64 = ctx.r31.s64 + 164;
	// stw r23,160(r31)
	REX_STORE_U32(ctx.r31.u32 + 160, ctx.r23.u32);
	// addi r4,r1,112
	ctx.r4.s64 = ctx.r1.s64 + 112;
	// addi r3,r31,8
	ctx.r3.s64 = ctx.r31.s64 + 8;
	// bl 0x8b09b1a0
	ctx.lr = 0x8B0A4964;
	sub_8B09B1A0(ctx, base);
	// stw r3,160(r31)
	REX_STORE_U32(ctx.r31.u32 + 160, ctx.r3.u32);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// bne cr6,0x8b0a49e4
	if (!ctx.cr6.eq) goto loc_8B0A49E4;
	// li r3,36
	ctx.r3.s64 = 36;
	// bl 0x8b0bf448
	ctx.lr = 0x8B0A4978;
	sub_8B0BF448(ctx, base);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0a4994
	if (ctx.cr6.eq) goto loc_8B0A4994;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// addi r4,r11,17092
	ctx.r4.s64 = ctx.r11.s64 + 17092;
	// bl 0x8b0bf9f8
	ctx.lr = 0x8B0A498C;
	sub_8B0BF9F8(ctx, base);
	// mr r30,r3
	ctx.r30.u64 = ctx.r3.u64;
	// b 0x8b0a4998
	goto loc_8B0A4998;
loc_8B0A4994:
	// mr r30,r23
	ctx.r30.u64 = ctx.r23.u64;
loc_8B0A4998:
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// mr r5,r31
	ctx.r5.u64 = ctx.r31.u64;
	// addi r4,r11,16280
	ctx.r4.s64 = ctx.r11.s64 + 16280;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// bl 0x8b0c0250
	ctx.lr = 0x8B0A49AC;
	sub_8B0C0250(ctx, base);
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// lis r9,-29944
	ctx.r9.s64 = -1962409984;
	// addi r5,r10,17480
	ctx.r5.s64 = ctx.r10.s64 + 17480;
	// addi r4,r9,17076
	ctx.r4.s64 = ctx.r9.s64 + 17076;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// bl 0x8b0c0010
	ctx.lr = 0x8B0A49C4;
	sub_8B0C0010(ctx, base);
	// lwz r8,0(r31)
	ctx.r8.u64 = REX_LOAD_U32(ctx.r31.u32 + 0);
	// mr r4,r30
	ctx.r4.u64 = ctx.r30.u64;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// lwz r7,48(r8)
	ctx.r7.u64 = REX_LOAD_U32(ctx.r8.u32 + 48);
	// mtctr r7
	ctx.ctr.u64 = ctx.r7.u64;
	// bctrl 
	ctx.lr = 0x8B0A49DC;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// addi r1,r1,768
	ctx.r1.s64 = ctx.r1.s64 + 768;
	// b 0x8b0cb9f4
	__restgprlr_23(ctx, base);
	return;
loc_8B0A49E4:
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// li r5,0
	ctx.r5.s64 = 0;
	// addi r24,r11,16356
	ctx.r24.s64 = ctx.r11.s64 + 16356;
	// mr r3,r27
	ctx.r3.u64 = ctx.r27.u64;
	// mr r4,r24
	ctx.r4.u64 = ctx.r24.u64;
	// bl 0x8b0bfd30
	ctx.lr = 0x8B0A49FC;
	sub_8B0BFD30(ctx, base);
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// li r5,0
	ctx.r5.s64 = 0;
	// lwz r3,152(r31)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r31.u32 + 152);
	// bl 0x8b0aab78
	ctx.lr = 0x8B0A4A0C;
	sub_8B0AAB78(ctx, base);
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// mr r4,r30
	ctx.r4.u64 = ctx.r30.u64;
	// addi r3,r11,19024
	ctx.r3.s64 = ctx.r11.s64 + 19024;
	// bl 0x8b0df298
	ctx.lr = 0x8B0A4A1C;
	sub_8B0DF298(ctx, base);
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// li r5,0
	ctx.r5.s64 = 0;
	// lwz r3,180(r31)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r31.u32 + 180);
	// addi r4,r10,4888
	ctx.r4.s64 = ctx.r10.s64 + 4888;
	// bl 0x8b0bfc38
	ctx.lr = 0x8B0A4A30;
	sub_8B0BFC38(ctx, base);
	// mr r26,r3
	ctx.r26.u64 = ctx.r3.u64;
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// beq cr6,0x8b0a4b40
	if (ctx.cr6.eq) goto loc_8B0A4B40;
	// mr r30,r23
	ctx.r30.u64 = ctx.r23.u64;
	// stw r23,80(r1)
	REX_STORE_U32(ctx.r1.u32 + 80, ctx.r23.u32);
	// stw r23,84(r1)
	REX_STORE_U32(ctx.r1.u32 + 84, ctx.r23.u32);
	// mr r29,r23
	ctx.r29.u64 = ctx.r23.u64;
	// stw r23,92(r1)
	REX_STORE_U32(ctx.r1.u32 + 92, ctx.r23.u32);
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// stw r23,88(r1)
	REX_STORE_U32(ctx.r1.u32 + 88, ctx.r23.u32);
	// ble cr6,0x8b0a4aec
	if (!ctx.cr6.gt) goto loc_8B0A4AEC;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// addi r28,r11,18912
	ctx.r28.s64 = ctx.r11.s64 + 18912;
	// addi r25,r10,17200
	ctx.r25.s64 = ctx.r10.s64 + 17200;
loc_8B0A4A6C:
	// mr r4,r25
	ctx.r4.u64 = ctx.r25.u64;
	// mr r5,r29
	ctx.r5.u64 = ctx.r29.u64;
	// addi r3,r1,176
	ctx.r3.s64 = ctx.r1.s64 + 176;
	// bl 0x8b090220
	ctx.lr = 0x8B0A4A7C;
	sub_8B090220(ctx, base);
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// li r5,0
	ctx.r5.s64 = 0;
	// lwz r3,180(r31)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r31.u32 + 180);
	// bl 0x8b0bfa88
	ctx.lr = 0x8B0A4A8C;
	sub_8B0BFA88(ctx, base);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0a4ae0
	if (ctx.cr6.eq) goto loc_8B0A4AE0;
	// mr r4,r24
	ctx.r4.u64 = ctx.r24.u64;
	// li r5,0
	ctx.r5.s64 = 0;
	// bl 0x8b0bfd30
	ctx.lr = 0x8B0A4AA0;
	sub_8B0BFD30(ctx, base);
	// mr r5,r3
	ctx.r5.u64 = ctx.r3.u64;
	// std r3,96(r1)
	REX_STORE_U64(ctx.r1.u32 + 96, ctx.r3.u64);
	// mr r4,r28
	ctx.r4.u64 = ctx.r28.u64;
	// addi r3,r1,432
	ctx.r3.s64 = ctx.r1.s64 + 432;
	// bl 0x8b090220
	ctx.lr = 0x8B0A4AB4;
	sub_8B090220(ctx, base);
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// li r5,0
	ctx.r5.s64 = 0;
	// mr r3,r27
	ctx.r3.u64 = ctx.r27.u64;
	// bl 0x8b0c1588
	ctx.lr = 0x8B0A4AC4;
	sub_8B0C1588(ctx, base);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// bne cr6,0x8b0a4ae0
	if (!ctx.cr6.eq) goto loc_8B0A4AE0;
	// addi r5,r1,96
	ctx.r5.s64 = ctx.r1.s64 + 96;
	// mr r4,r30
	ctx.r4.u64 = ctx.r30.u64;
	// addi r3,r1,80
	ctx.r3.s64 = ctx.r1.s64 + 80;
	// bl 0x8b09d980
	ctx.lr = 0x8B0A4ADC;
	sub_8B09D980(ctx, base);
	// lwz r30,92(r1)
	ctx.r30.u64 = REX_LOAD_U32(ctx.r1.u32 + 92);
loc_8B0A4AE0:
	// addi r29,r29,1
	ctx.r29.s64 = ctx.r29.s64 + 1;
	// cmpw cr6,r29,r26
	ctx.cr6.compare<int32_t>(ctx.r29.s32, ctx.r26.s32, ctx.xer);
	// blt cr6,0x8b0a4a6c
	if (ctx.cr6.lt) goto loc_8B0A4A6C;
loc_8B0A4AEC:
	// cmpwi cr6,r30,0
	ctx.cr6.compare<int32_t>(ctx.r30.s32, 0, ctx.xer);
	// ble cr6,0x8b0a4b2c
	if (!ctx.cr6.gt) goto loc_8B0A4B2C;
	// lwz r11,80(r1)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r1.u32 + 80);
	// addi r28,r11,-8
	ctx.r28.s64 = ctx.r11.s64 + -8;
loc_8B0A4AFC:
	// ldu r29,8(r28)
	ea = 8 + ctx.r28.u32;
	ctx.r29.u64 = REX_LOAD_U64(ea);
	ctx.r28.u32 = ea;
	// lwz r3,152(r31)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r31.u32 + 152);
	// mr r4,r29
	ctx.r4.u64 = ctx.r29.u64;
	// bl 0x8b0aad70
	ctx.lr = 0x8B0A4B0C;
	sub_8B0AAD70(ctx, base);
	// lwz r11,0(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 0);
	// mr r4,r29
	ctx.r4.u64 = ctx.r29.u64;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// lwz r10,40(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 40);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B0A4B24;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// addic. r30,r30,-1
	ctx.xer.ca = ctx.r30.u32 > 0;
	ctx.r30.s64 = ctx.r30.s64 + -1;
	ctx.cr0.compare<int32_t>(ctx.r30.s32, 0, ctx.xer);
	// bne 0x8b0a4afc
	if (!ctx.cr0.eq) goto loc_8B0A4AFC;
loc_8B0A4B2C:
	// stw r23,92(r1)
	REX_STORE_U32(ctx.r1.u32 + 92, ctx.r23.u32);
	// addi r3,r1,80
	ctx.r3.s64 = ctx.r1.s64 + 80;
	// bl 0x8b0906a8
	ctx.lr = 0x8B0A4B38;
	sub_8B0906A8(ctx, base);
	// addi r3,r1,80
	ctx.r3.s64 = ctx.r1.s64 + 80;
	// bl 0x8b0906a8
	ctx.lr = 0x8B0A4B40;
	sub_8B0906A8(ctx, base);
loc_8B0A4B40:
	// li r3,36
	ctx.r3.s64 = 36;
	// bl 0x8b0bf448
	ctx.lr = 0x8B0A4B48;
	sub_8B0BF448(ctx, base);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0a4b64
	if (ctx.cr6.eq) goto loc_8B0A4B64;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// addi r4,r11,17456
	ctx.r4.s64 = ctx.r11.s64 + 17456;
	// bl 0x8b0bf9f8
	ctx.lr = 0x8B0A4B5C;
	sub_8B0BF9F8(ctx, base);
	// mr r30,r3
	ctx.r30.u64 = ctx.r3.u64;
	// b 0x8b0a4b68
	goto loc_8B0A4B68;
loc_8B0A4B64:
	// mr r30,r23
	ctx.r30.u64 = ctx.r23.u64;
loc_8B0A4B68:
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// addi r5,r11,4560
	ctx.r5.s64 = ctx.r11.s64 + 4560;
	// addi r4,r10,4072
	ctx.r4.s64 = ctx.r10.s64 + 4072;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// bl 0x8b0c0010
	ctx.lr = 0x8B0A4B80;
	sub_8B0C0010(ctx, base);
	// mr r4,r24
	ctx.r4.u64 = ctx.r24.u64;
	// li r5,0
	ctx.r5.s64 = 0;
	// mr r3,r27
	ctx.r3.u64 = ctx.r27.u64;
	// bl 0x8b0bfd30
	ctx.lr = 0x8B0A4B90;
	sub_8B0BFD30(ctx, base);
	// lis r9,-29944
	ctx.r9.s64 = -1962409984;
	// mr r5,r3
	ctx.r5.u64 = ctx.r3.u64;
	// addi r4,r9,3616
	ctx.r4.s64 = ctx.r9.s64 + 3616;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// bl 0x8b0c0190
	ctx.lr = 0x8B0A4BA4;
	sub_8B0C0190(ctx, base);
	// lis r8,-29944
	ctx.r8.s64 = -1962409984;
	// lis r7,-29944
	ctx.r7.s64 = -1962409984;
	// addi r5,r8,17448
	ctx.r5.s64 = ctx.r8.s64 + 17448;
	// addi r4,r7,18036
	ctx.r4.s64 = ctx.r7.s64 + 18036;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// bl 0x8b0c0010
	ctx.lr = 0x8B0A4BBC;
	sub_8B0C0010(ctx, base);
	// lwz r6,0(r31)
	ctx.r6.u64 = REX_LOAD_U32(ctx.r31.u32 + 0);
	// mr r4,r30
	ctx.r4.u64 = ctx.r30.u64;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// lwz r5,48(r6)
	ctx.r5.u64 = REX_LOAD_U32(ctx.r6.u32 + 48);
	// mtctr r5
	ctx.ctr.u64 = ctx.r5.u64;
	// bctrl 
	ctx.lr = 0x8B0A4BD4;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// addi r1,r1,768
	ctx.r1.s64 = ctx.r1.s64 + 768;
	// b 0x8b0cb9f4
	__restgprlr_23(ctx, base);
	return;
loc_8B0A4BDC:
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// addi r4,r11,18648
	ctx.r4.s64 = ctx.r11.s64 + 18648;
	// bl 0x8b0cea10
	ctx.lr = 0x8B0A4BEC;
	sub_8B0CEA10(ctx, base);
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// mr r4,r27
	ctx.r4.u64 = ctx.r27.u64;
	// bne cr6,0x8b0a4c34
	if (!ctx.cr6.eq) goto loc_8B0A4C34;
	// li r5,0
	ctx.r5.s64 = 0;
	// lwz r3,180(r31)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r31.u32 + 180);
	// bl 0x8b0c0668
	ctx.lr = 0x8B0A4C04;
	sub_8B0C0668(ctx, base);
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// li r5,0
	ctx.r5.s64 = 0;
	// addi r4,r11,4056
	ctx.r4.s64 = ctx.r11.s64 + 4056;
	// mr r3,r27
	ctx.r3.u64 = ctx.r27.u64;
	// bl 0x8b0bfa88
	ctx.lr = 0x8B0A4C18;
	sub_8B0BFA88(ctx, base);
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0a0988
	ctx.lr = 0x8B0A4C24;
	sub_8B0A0988(ctx, base);
	// mr r3,r27
	ctx.r3.u64 = ctx.r27.u64;
	// bl 0x8b098140
	ctx.lr = 0x8B0A4C2C;
	sub_8B098140(ctx, base);
	// addi r1,r1,768
	ctx.r1.s64 = ctx.r1.s64 + 768;
	// b 0x8b0cb9f4
	__restgprlr_23(ctx, base);
	return;
loc_8B0A4C34:
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b09ffa8
	ctx.lr = 0x8B0A4C3C;
	sub_8B09FFA8(ctx, base);
	// addi r1,r1,768
	ctx.r1.s64 = ctx.r1.s64 + 768;
	// b 0x8b0cb9f4
	__restgprlr_23(ctx, base);
	return;
loc_8B0A4C44:
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// addi r4,r11,17728
	ctx.r4.s64 = ctx.r11.s64 + 17728;
	// bl 0x8b0cea10
	ctx.lr = 0x8B0A4C54;
	sub_8B0CEA10(ctx, base);
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// bne cr6,0x8b0a4c88
	if (!ctx.cr6.eq) goto loc_8B0A4C88;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// li r5,0
	ctx.r5.s64 = 0;
	// addi r4,r11,16356
	ctx.r4.s64 = ctx.r11.s64 + 16356;
	// mr r3,r27
	ctx.r3.u64 = ctx.r27.u64;
	// bl 0x8b0bfd30
	ctx.lr = 0x8B0A4C70;
	sub_8B0BFD30(ctx, base);
	// ld r10,184(r31)
	ctx.r10.u64 = REX_LOAD_U64(ctx.r31.u32 + 184);
	// cmpld cr6,r3,r10
	ctx.cr6.compare<uint64_t>(ctx.r3.u64, ctx.r10.u64, ctx.xer);
	// bne cr6,0x8b0a4c88
	if (!ctx.cr6.eq) goto loc_8B0A4C88;
	// mr r4,r27
	ctx.r4.u64 = ctx.r27.u64;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0a2ab0
	ctx.lr = 0x8B0A4C88;
	sub_8B0A2AB0(ctx, base);
loc_8B0A4C88:
	// addi r1,r1,768
	ctx.r1.s64 = ctx.r1.s64 + 768;
	// b 0x8b0cb9f4
	__restgprlr_23(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0A5C08) {
	REX_FUNC_PROLOGUE();
	PPCRegister temp{};
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9b4
	ctx.lr = 0x8B0A5C10;
	__savegprlr_27(ctx, base);
	// stwu r1,-176(r1)
	ea = -176 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// mr r27,r3
	ctx.r27.u64 = ctx.r3.u64;
	// mr r30,r4
	ctx.r30.u64 = ctx.r4.u64;
	// cmplwi cr6,r4,0
	ctx.cr6.compare<uint32_t>(ctx.r4.u32, 0, ctx.xer);
	// beq cr6,0x8b0a5dc0
	if (ctx.cr6.eq) goto loc_8B0A5DC0;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// addi r31,r11,5604
	ctx.r31.s64 = ctx.r11.s64 + 5604;
	// addi r4,r10,3720
	ctx.r4.s64 = ctx.r10.s64 + 3720;
	// mr r5,r31
	ctx.r5.u64 = ctx.r31.u64;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// bl 0x8b0c1588
	ctx.lr = 0x8B0A5C40;
	sub_8B0C1588(ctx, base);
	// lis r9,-29944
	ctx.r9.s64 = -1962409984;
	// lis r8,-29944
	ctx.r8.s64 = -1962409984;
	// mr r28,r3
	ctx.r28.u64 = ctx.r3.u64;
	// addi r5,r9,1791
	ctx.r5.s64 = ctx.r9.s64 + 1791;
	// addi r4,r8,5356
	ctx.r4.s64 = ctx.r8.s64 + 5356;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// bl 0x8b0c1588
	ctx.lr = 0x8B0A5C5C;
	sub_8B0C1588(ctx, base);
	// lis r7,-29938
	ctx.r7.s64 = -1962016768;
	// mr r4,r28
	ctx.r4.u64 = ctx.r28.u64;
	// mr r29,r3
	ctx.r29.u64 = ctx.r3.u64;
	// lwz r3,2548(r7)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r7.u32 + 2548);
	// bl 0x8b096770
	ctx.lr = 0x8B0A5C70;
	sub_8B096770(ctx, base);
	// lis r6,-29944
	ctx.r6.s64 = -1962409984;
	// mr r4,r29
	ctx.r4.u64 = ctx.r29.u64;
	// addi r3,r6,20272
	ctx.r3.s64 = ctx.r6.s64 + 20272;
	// bl 0x8b0cea10
	ctx.lr = 0x8B0A5C80;
	sub_8B0CEA10(ctx, base);
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// bne cr6,0x8b0a5cc8
	if (!ctx.cr6.eq) goto loc_8B0A5CC8;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// mr r4,r28
	ctx.r4.u64 = ctx.r28.u64;
	// bl 0x8b0cea10
	ctx.lr = 0x8B0A5C94;
	sub_8B0CEA10(ctx, base);
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// bne cr6,0x8b0a5cac
	if (!ctx.cr6.eq) goto loc_8B0A5CAC;
	// bl 0x8b0a4ef0
	ctx.lr = 0x8B0A5CA0;
	sub_8B0A4EF0(ctx, base);
	// clrlwi r11,r3,24
	ctx.r11.u64 = ctx.r3.u32 & 0xFF;
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// beq cr6,0x8b0a5dc0
	if (ctx.cr6.eq) goto loc_8B0A5DC0;
loc_8B0A5CAC:
	// li r3,32
	ctx.r3.s64 = 32;
	// bl 0x8b090000
	ctx.lr = 0x8B0A5CB4;
	sub_8B090000(ctx, base);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0a5d7c
	if (ctx.cr6.eq) goto loc_8B0A5D7C;
	// mr r4,r30
	ctx.r4.u64 = ctx.r30.u64;
	// bl 0x8b0b62e0
	ctx.lr = 0x8B0A5CC4;
	sub_8B0B62E0(ctx, base);
	// b 0x8b0a5d80
	goto loc_8B0A5D80;
loc_8B0A5CC8:
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// mr r4,r29
	ctx.r4.u64 = ctx.r29.u64;
	// addi r3,r11,20252
	ctx.r3.s64 = ctx.r11.s64 + 20252;
	// bl 0x8b0cea10
	ctx.lr = 0x8B0A5CD8;
	sub_8B0CEA10(ctx, base);
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// bne cr6,0x8b0a5d3c
	if (!ctx.cr6.eq) goto loc_8B0A5D3C;
	// lis r11,-29938
	ctx.r11.s64 = -1962016768;
	// li r5,84
	ctx.r5.s64 = 84;
	// addi r31,r11,19288
	ctx.r31.s64 = ctx.r11.s64 + 19288;
	// li r4,0
	ctx.r4.s64 = 0;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0cb8e0
	ctx.lr = 0x8B0A5CF8;
	sub_8B0CB8E0(ctx, base);
	// bl 0x8b0df328
	ctx.lr = 0x8B0A5CFC;
	sub_8B0DF328(ctx, base);
	// li r4,1
	ctx.r4.s64 = 1;
	// addi r5,r1,80
	ctx.r5.s64 = ctx.r1.s64 + 80;
	// bl 0x8b0dbdc8
	ctx.lr = 0x8B0A5D08;
	sub_8B0DBDC8(ctx, base);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// bne cr6,0x8b0a5d18
	if (!ctx.cr6.eq) goto loc_8B0A5D18;
	// ld r11,80(r1)
	ctx.r11.u64 = REX_LOAD_U64(ctx.r1.u32 + 80);
	// std r11,0(r31)
	REX_STORE_U64(ctx.r31.u32 + 0, ctx.r11.u64);
loc_8B0A5D18:
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// li r5,0
	ctx.r5.s64 = 0;
	// addi r4,r11,11968
	ctx.r4.s64 = ctx.r11.s64 + 11968;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// bl 0x8b0bfd30
	ctx.lr = 0x8B0A5D2C;
	sub_8B0BFD30(ctx, base);
	// std r3,20(r31)
	REX_STORE_U64(ctx.r31.u32 + 20, ctx.r3.u64);
	// bl 0x8b0a5a10
	ctx.lr = 0x8B0A5D34;
	sub_8B0A5A10(ctx, base);
	// addi r1,r1,176
	ctx.r1.s64 = ctx.r1.s64 + 176;
	// b 0x8b0cba04
	__restgprlr_27(ctx, base);
	return;
loc_8B0A5D3C:
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// mr r4,r28
	ctx.r4.u64 = ctx.r28.u64;
	// bl 0x8b0cea10
	ctx.lr = 0x8B0A5D48;
	sub_8B0CEA10(ctx, base);
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// bne cr6,0x8b0a5d60
	if (!ctx.cr6.eq) goto loc_8B0A5D60;
	// bl 0x8b0a4ef0
	ctx.lr = 0x8B0A5D54;
	sub_8B0A4EF0(ctx, base);
	// clrlwi r11,r3,24
	ctx.r11.u64 = ctx.r3.u32 & 0xFF;
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// beq cr6,0x8b0a5dc0
	if (ctx.cr6.eq) goto loc_8B0A5DC0;
loc_8B0A5D60:
	// li r3,44
	ctx.r3.s64 = 44;
	// bl 0x8b090000
	ctx.lr = 0x8B0A5D68;
	sub_8B090000(ctx, base);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0a5d7c
	if (ctx.cr6.eq) goto loc_8B0A5D7C;
	// mr r4,r30
	ctx.r4.u64 = ctx.r30.u64;
	// bl 0x8b0b4508
	ctx.lr = 0x8B0A5D78;
	sub_8B0B4508(ctx, base);
	// b 0x8b0a5d80
	goto loc_8B0A5D80;
loc_8B0A5D7C:
	// li r3,0
	ctx.r3.s64 = 0;
loc_8B0A5D80:
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0a5dc0
	if (ctx.cr6.eq) goto loc_8B0A5DC0;
	// lwz r11,0(r27)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r27.u32 + 0);
	// mr r3,r27
	ctx.r3.u64 = ctx.r27.u64;
	// lwz r10,60(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 60);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B0A5DA0;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// lis r9,-29944
	ctx.r9.s64 = -1962409984;
	// mr r4,r28
	ctx.r4.u64 = ctx.r28.u64;
	// addi r3,r9,3712
	ctx.r3.s64 = ctx.r9.s64 + 3712;
	// bl 0x8b0cea10
	ctx.lr = 0x8B0A5DB0;
	sub_8B0CEA10(ctx, base);
	// addic r8,r3,-1
	ctx.xer.ca = ctx.r3.u32 > 0;
	ctx.r8.s64 = ctx.r3.s64 + -1;
	// subfe r3,r8,r3
	temp.u8 = (~ctx.r8.u32 + ctx.r3.u32 < ~ctx.r8.u32) | (~ctx.r8.u32 + ctx.r3.u32 + ctx.xer.ca < ctx.xer.ca);
	ctx.r3.u64 = ~ctx.r8.u64 + ctx.r3.u64 + ctx.xer.ca;
	ctx.xer.ca = temp.u8;
	// bl 0x8b0a5138
	ctx.lr = 0x8B0A5DBC;
	sub_8B0A5138(ctx, base);
	// stw r31,8(r27)
	REX_STORE_U32(ctx.r27.u32 + 8, ctx.r31.u32);
loc_8B0A5DC0:
	// addi r1,r1,176
	ctx.r1.s64 = ctx.r1.s64 + 176;
	// b 0x8b0cba04
	__restgprlr_27(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0A6228) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb980
	ctx.lr = 0x8B0A6230;
	__savegprlr_14(ctx, base);
	// stwu r1,-512(r1)
	ea = -512 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// stw r4,540(r1)
	REX_STORE_U32(ctx.r1.u32 + 540, ctx.r4.u32);
	// mr r26,r3
	ctx.r26.u64 = ctx.r3.u64;
	// addi r3,r11,20752
	ctx.r3.s64 = ctx.r11.s64 + 20752;
	// mr r25,r4
	ctx.r25.u64 = ctx.r4.u64;
	// lwz r4,0(r4)
	ctx.r4.u64 = REX_LOAD_U32(ctx.r4.u32 + 0);
	// bl 0x8b0df298
	ctx.lr = 0x8B0A6250;
	sub_8B0DF298(ctx, base);
	// lwz r10,0(r25)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r25.u32 + 0);
	// li r11,0
	ctx.r11.s64 = 0;
	// cmplwi cr6,r10,0
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 0, ctx.xer);
	// stw r11,84(r1)
	REX_STORE_U32(ctx.r1.u32 + 84, ctx.r11.u32);
	// ble cr6,0x8b0a647c
	if (!ctx.cr6.gt) goto loc_8B0A647C;
	// stw r11,80(r1)
	REX_STORE_U32(ctx.r1.u32 + 80, ctx.r11.u32);
	// lis r7,-29944
	ctx.r7.s64 = -1962409984;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lis r31,-29944
	ctx.r31.s64 = -1962409984;
	// lis r30,-29944
	ctx.r30.s64 = -1962409984;
	// lis r29,-29944
	ctx.r29.s64 = -1962409984;
	// lis r3,-29944
	ctx.r3.s64 = -1962409984;
	// lis r4,-29944
	ctx.r4.s64 = -1962409984;
	// lis r5,-29944
	ctx.r5.s64 = -1962409984;
	// lis r6,-29944
	ctx.r6.s64 = -1962409984;
	// lis r8,-29944
	ctx.r8.s64 = -1962409984;
	// lis r9,-29944
	ctx.r9.s64 = -1962409984;
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// addi r7,r7,20712
	ctx.r7.s64 = ctx.r7.s64 + 20712;
	// addi r11,r11,20632
	ctx.r11.s64 = ctx.r11.s64 + 20632;
	// addi r24,r31,13764
	ctx.r24.s64 = ctx.r31.s64 + 13764;
	// stw r7,92(r1)
	REX_STORE_U32(ctx.r1.u32 + 92, ctx.r7.u32);
	// addi r23,r30,8412
	ctx.r23.s64 = ctx.r30.s64 + 8412;
	// stw r11,88(r1)
	REX_STORE_U32(ctx.r1.u32 + 88, ctx.r11.u32);
	// addi r22,r29,20620
	ctx.r22.s64 = ctx.r29.s64 + 20620;
	// addi r21,r3,20612
	ctx.r21.s64 = ctx.r3.s64 + 20612;
	// addi r20,r4,20604
	ctx.r20.s64 = ctx.r4.s64 + 20604;
	// addi r14,r5,14812
	ctx.r14.s64 = ctx.r5.s64 + 14812;
	// addi r18,r6,20544
	ctx.r18.s64 = ctx.r6.s64 + 20544;
	// addi r17,r8,20496
	ctx.r17.s64 = ctx.r8.s64 + 20496;
	// addi r16,r9,20488
	ctx.r16.s64 = ctx.r9.s64 + 20488;
	// addi r15,r10,1791
	ctx.r15.s64 = ctx.r10.s64 + 1791;
loc_8B0A62D0:
	// lwz r11,4(r25)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r25.u32 + 4);
	// mr r3,r26
	ctx.r3.u64 = ctx.r26.u64;
	// lwz r10,80(r1)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r1.u32 + 80);
	// add r29,r10,r11
	ctx.r29.u64 = ctx.r10.u64 + ctx.r11.u64;
	// lwz r4,0(r29)
	ctx.r4.u64 = REX_LOAD_U32(ctx.r29.u32 + 0);
	// bl 0x8b0a6068
	ctx.lr = 0x8B0A62E8;
	sub_8B0A6068(ctx, base);
	// mr r28,r3
	ctx.r28.u64 = ctx.r3.u64;
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// bne cr6,0x8b0a6304
	if (!ctx.cr6.eq) goto loc_8B0A6304;
	// lwz r3,88(r1)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r1.u32 + 88);
	// lwz r4,0(r29)
	ctx.r4.u64 = REX_LOAD_U32(ctx.r29.u32 + 0);
	// bl 0x8b0df2a8
	ctx.lr = 0x8B0A6300;
	sub_8B0DF2A8(ctx, base);
	// b 0x8b0a6458
	goto loc_8B0A6458;
loc_8B0A6304:
	// mr r5,r15
	ctx.r5.u64 = ctx.r15.u64;
	// mr r4,r16
	ctx.r4.u64 = ctx.r16.u64;
	// mr r3,r28
	ctx.r3.u64 = ctx.r28.u64;
	// bl 0x8b0c1588
	ctx.lr = 0x8B0A6314;
	sub_8B0C1588(ctx, base);
	// mr r27,r3
	ctx.r27.u64 = ctx.r3.u64;
	// mr r3,r17
	ctx.r3.u64 = ctx.r17.u64;
	// lwz r4,0(r29)
	ctx.r4.u64 = REX_LOAD_U32(ctx.r29.u32 + 0);
	// mr r5,r27
	ctx.r5.u64 = ctx.r27.u64;
	// lwz r6,4(r29)
	ctx.r6.u64 = REX_LOAD_U32(ctx.r29.u32 + 4);
	// bl 0x8b0df298
	ctx.lr = 0x8B0A632C;
	sub_8B0DF298(ctx, base);
	// lwz r11,8(r29)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r29.u32 + 8);
	// li r19,0
	ctx.r19.s64 = 0;
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// ble cr6,0x8b0a6458
	if (!ctx.cr6.gt) goto loc_8B0A6458;
	// li r25,0
	ctx.r25.s64 = 0;
loc_8B0A6340:
	// lwz r11,12(r29)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r29.u32 + 12);
	// add r31,r11,r25
	ctx.r31.u64 = ctx.r11.u64 + ctx.r25.u64;
	// lwz r6,8(r31)
	ctx.r6.u64 = REX_LOAD_U32(ctx.r31.u32 + 8);
	// cmplwi cr6,r6,0
	ctx.cr6.compare<uint32_t>(ctx.r6.u32, 0, ctx.xer);
	// bne cr6,0x8b0a6374
	if (!ctx.cr6.eq) goto loc_8B0A6374;
	// ld r11,16(r31)
	ctx.r11.u64 = REX_LOAD_U64(ctx.r31.u32 + 16);
	// cmpdi cr6,r11,0
	ctx.cr6.compare<int64_t>(ctx.r11.s64, 0, ctx.xer);
	// bne cr6,0x8b0a6374
	if (!ctx.cr6.eq) goto loc_8B0A6374;
	// addi r4,r31,24
	ctx.r4.s64 = ctx.r31.s64 + 24;
	// lwz r3,92(r1)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r1.u32 + 92);
	// ld r5,0(r31)
	ctx.r5.u64 = REX_LOAD_U64(ctx.r31.u32 + 0);
	// bl 0x8b0df298
	ctx.lr = 0x8B0A6370;
	sub_8B0DF298(ctx, base);
	// b 0x8b0a6440
	goto loc_8B0A6440;
loc_8B0A6374:
	// mr r3,r18
	ctx.r3.u64 = ctx.r18.u64;
	// ld r5,0(r31)
	ctx.r5.u64 = REX_LOAD_U64(ctx.r31.u32 + 0);
	// addi r4,r31,24
	ctx.r4.s64 = ctx.r31.s64 + 24;
	// ld r7,16(r31)
	ctx.r7.u64 = REX_LOAD_U64(ctx.r31.u32 + 16);
	// bl 0x8b0df298
	ctx.lr = 0x8B0A6388;
	sub_8B0DF298(ctx, base);
	// lwz r11,24(r26)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r26.u32 + 24);
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// bne cr6,0x8b0a63b8
	if (!ctx.cr6.eq) goto loc_8B0A63B8;
	// li r3,36
	ctx.r3.s64 = 36;
	// bl 0x8b0bf448
	ctx.lr = 0x8B0A639C;
	sub_8B0BF448(ctx, base);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0a63b0
	if (ctx.cr6.eq) goto loc_8B0A63B0;
	// mr r4,r14
	ctx.r4.u64 = ctx.r14.u64;
	// bl 0x8b0bf9f8
	ctx.lr = 0x8B0A63AC;
	sub_8B0BF9F8(ctx, base);
	// b 0x8b0a63b4
	goto loc_8B0A63B4;
loc_8B0A63B0:
	// li r3,0
	ctx.r3.s64 = 0;
loc_8B0A63B4:
	// stw r3,24(r26)
	REX_STORE_U32(ctx.r26.u32 + 24, ctx.r3.u32);
loc_8B0A63B8:
	// mr r4,r20
	ctx.r4.u64 = ctx.r20.u64;
	// ld r5,0(r31)
	ctx.r5.u64 = REX_LOAD_U64(ctx.r31.u32 + 0);
	// mr r6,r27
	ctx.r6.u64 = ctx.r27.u64;
	// addi r3,r1,96
	ctx.r3.s64 = ctx.r1.s64 + 96;
	// bl 0x8b090220
	ctx.lr = 0x8B0A63CC;
	sub_8B090220(ctx, base);
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// li r5,1
	ctx.r5.s64 = 1;
	// lwz r3,24(r26)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r26.u32 + 24);
	// bl 0x8b0bfa88
	ctx.lr = 0x8B0A63DC;
	sub_8B0BFA88(ctx, base);
	// mr r4,r21
	ctx.r4.u64 = ctx.r21.u64;
	// lwz r5,8(r31)
	ctx.r5.u64 = REX_LOAD_U32(ctx.r31.u32 + 8);
	// mr r30,r3
	ctx.r30.u64 = ctx.r3.u64;
	// bl 0x8b0c0190
	ctx.lr = 0x8B0A63EC;
	sub_8B0C0190(ctx, base);
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// mr r4,r22
	ctx.r4.u64 = ctx.r22.u64;
	// lwz r5,4(r29)
	ctx.r5.u64 = REX_LOAD_U32(ctx.r29.u32 + 4);
	// bl 0x8b0c0190
	ctx.lr = 0x8B0A63FC;
	sub_8B0C0190(ctx, base);
	// mr r4,r23
	ctx.r4.u64 = ctx.r23.u64;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// ld r5,16(r31)
	ctx.r5.u64 = REX_LOAD_U64(ctx.r31.u32 + 16);
	// bl 0x8b0c0190
	ctx.lr = 0x8B0A640C;
	sub_8B0C0190(ctx, base);
	// mr r4,r24
	ctx.r4.u64 = ctx.r24.u64;
	// li r5,0
	ctx.r5.s64 = 0;
	// mr r3,r28
	ctx.r3.u64 = ctx.r28.u64;
	// bl 0x8b0c1588
	ctx.lr = 0x8B0A641C;
	sub_8B0C1588(ctx, base);
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0a6440
	if (ctx.cr6.eq) goto loc_8B0A6440;
	// lbz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U8(ctx.r3.u32 + 0);
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// beq cr6,0x8b0a6440
	if (ctx.cr6.eq) goto loc_8B0A6440;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// ld r5,16(r31)
	ctx.r5.u64 = REX_LOAD_U64(ctx.r31.u32 + 16);
	// bl 0x8b0c0190
	ctx.lr = 0x8B0A6440;
	sub_8B0C0190(ctx, base);
loc_8B0A6440:
	// lwz r11,8(r29)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r29.u32 + 8);
	// addi r19,r19,1
	ctx.r19.s64 = ctx.r19.s64 + 1;
	// addi r25,r25,48
	ctx.r25.s64 = ctx.r25.s64 + 48;
	// cmplw cr6,r19,r11
	ctx.cr6.compare<uint32_t>(ctx.r19.u32, ctx.r11.u32, ctx.xer);
	// blt cr6,0x8b0a6340
	if (ctx.cr6.lt) goto loc_8B0A6340;
	// lwz r25,540(r1)
	ctx.r25.u64 = REX_LOAD_U32(ctx.r1.u32 + 540);
loc_8B0A6458:
	// lwz r11,84(r1)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r1.u32 + 84);
	// lwz r10,80(r1)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r1.u32 + 80);
	// lwz r9,0(r25)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r25.u32 + 0);
	// addi r11,r11,1
	ctx.r11.s64 = ctx.r11.s64 + 1;
	// addi r8,r10,16
	ctx.r8.s64 = ctx.r10.s64 + 16;
	// stw r11,84(r1)
	REX_STORE_U32(ctx.r1.u32 + 84, ctx.r11.u32);
	// cmplw cr6,r11,r9
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, ctx.r9.u32, ctx.xer);
	// stw r8,80(r1)
	REX_STORE_U32(ctx.r1.u32 + 80, ctx.r8.u32);
	// blt cr6,0x8b0a62d0
	if (ctx.cr6.lt) goto loc_8B0A62D0;
loc_8B0A647C:
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// addi r3,r11,20436
	ctx.r3.s64 = ctx.r11.s64 + 20436;
	// bl 0x8b0df298
	ctx.lr = 0x8B0A6488;
	sub_8B0DF298(ctx, base);
	// addi r1,r1,512
	ctx.r1.s64 = ctx.r1.s64 + 512;
	// b 0x8b0cb9d0
	__restgprlr_14(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0A6DA0) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// std r30,-24(r1)
	REX_STORE_U64(ctx.r1.u32 + -24, ctx.r30.u64);
	// std r31,-16(r1)
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.r31.u64);
	// stwu r1,-112(r1)
	ea = -112 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// lwz r3,16(r3)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r3.u32 + 16);
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// addi r10,r11,21280
	ctx.r10.s64 = ctx.r11.s64 + 21280;
	// stw r10,0(r31)
	REX_STORE_U32(ctx.r31.u32 + 0, ctx.r10.u32);
	// beq cr6,0x8b0a6dd4
	if (ctx.cr6.eq) goto loc_8B0A6DD4;
	// bl 0x8b0c04f0
	ctx.lr = 0x8B0A6DD4;
	sub_8B0C04F0(ctx, base);
loc_8B0A6DD4:
	// li r30,0
	ctx.r30.s64 = 0;
	// addi r11,r31,28
	ctx.r11.s64 = ctx.r31.s64 + 28;
	// stw r30,16(r31)
	REX_STORE_U32(ctx.r31.u32 + 16, ctx.r30.u32);
	// lwz r3,32(r31)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r31.u32 + 32);
	// bl 0x8b090020
	ctx.lr = 0x8B0A6DE8;
	sub_8B090020(ctx, base);
	// stw r30,28(r31)
	REX_STORE_U32(ctx.r31.u32 + 28, ctx.r30.u32);
	// stw r30,32(r31)
	REX_STORE_U32(ctx.r31.u32 + 32, ctx.r30.u32);
	// addi r11,r31,20
	ctx.r11.s64 = ctx.r31.s64 + 20;
	// lwz r3,24(r31)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r31.u32 + 24);
	// bl 0x8b090020
	ctx.lr = 0x8B0A6DFC;
	sub_8B090020(ctx, base);
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// addi r10,r11,21168
	ctx.r10.s64 = ctx.r11.s64 + 21168;
	// stw r30,20(r31)
	REX_STORE_U32(ctx.r31.u32 + 20, ctx.r30.u32);
	// stw r30,24(r31)
	REX_STORE_U32(ctx.r31.u32 + 24, ctx.r30.u32);
	// stw r10,0(r31)
	REX_STORE_U32(ctx.r31.u32 + 0, ctx.r10.u32);
	// addi r1,r1,112
	ctx.r1.s64 = ctx.r1.s64 + 112;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// ld r30,-24(r1)
	ctx.r30.u64 = REX_LOAD_U64(ctx.r1.u32 + -24);
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0A6FD0) {
	REX_FUNC_PROLOGUE();
	// lis r8,-29938
	ctx.r8.s64 = -1962016768;
	// lis r11,-29938
	ctx.r11.s64 = -1962016768;
	// addi r11,r11,19640
	ctx.r11.s64 = ctx.r11.s64 + 19640;
	// lwz r9,19648(r8)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r8.u32 + 19648);
	// clrlwi r10,r9,31
	ctx.r10.u64 = ctx.r9.u32 & 0x1;
	// cmplwi cr6,r10,0
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 0, ctx.xer);
	// bne cr6,0x8b0a7018
	if (!ctx.cr6.eq) goto loc_8B0A7018;
	// ori r9,r9,1
	ctx.r9.u64 = ctx.r9.u64 | 1;
	// lis r10,0
	ctx.r10.s64 = 0;
	// stw r9,19648(r8)
	REX_STORE_U32(ctx.r8.u32 + 19648, ctx.r9.u32);
	// li r9,1
	ctx.r9.s64 = 1;
	// ori r10,r10,65535
	ctx.r10.u64 = ctx.r10.u64 | 65535;
	// sth r9,6(r11)
	REX_STORE_U16(ctx.r11.u32 + 6, ctx.r9.u16);
	// mr r7,r10
	ctx.r7.u64 = ctx.r10.u64;
	// sth r10,0(r11)
	REX_STORE_U16(ctx.r11.u32 + 0, ctx.r10.u16);
	// mr r6,r10
	ctx.r6.u64 = ctx.r10.u64;
	// sth r10,2(r11)
	REX_STORE_U16(ctx.r11.u32 + 2, ctx.r10.u16);
	// sth r10,4(r11)
	REX_STORE_U16(ctx.r11.u32 + 4, ctx.r10.u16);
loc_8B0A7018:
	// clrlwi r10,r4,16
	ctx.r10.u64 = ctx.r4.u32 & 0xFFFF;
	// cmplwi cr6,r10,65535
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 65535, ctx.xer);
	// beq cr6,0x8b0a703c
	if (ctx.cr6.eq) goto loc_8B0A703C;
	// rlwinm r11,r10,3,0,28
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r10.u32 | (ctx.r10.u64 << 32), 3) & 0xFFFFFFF8;
	// lwz r9,4(r3)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r3.u32 + 4);
	// add r11,r10,r11
	ctx.r11.u64 = ctx.r10.u64 + ctx.r11.u64;
	// rlwinm r11,r11,3,0,28
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 3) & 0xFFFFFFF8;
	// add r3,r11,r9
	ctx.r3.u64 = ctx.r11.u64 + ctx.r9.u64;
	// blr 
	return;
loc_8B0A703C:
	// mr r3,r11
	ctx.r3.u64 = ctx.r11.u64;
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0A7280) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// std r30,-24(r1)
	REX_STORE_U64(ctx.r1.u32 + -24, ctx.r30.u64);
	// std r31,-16(r1)
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.r31.u64);
	// stwu r1,-112(r1)
	ea = -112 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// mr r30,r3
	ctx.r30.u64 = ctx.r3.u64;
	// mr r31,r4
	ctx.r31.u64 = ctx.r4.u64;
	// li r3,2
	ctx.r3.s64 = 2;
	// addi r4,r11,21496
	ctx.r4.s64 = ctx.r11.s64 + 21496;
	// bl 0x8b0df3a8
	ctx.lr = 0x8B0A72AC;
	sub_8B0DF3A8(ctx, base);
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// li r9,2
	ctx.r9.s64 = 2;
	// addi r8,r10,1800
	ctx.r8.s64 = ctx.r10.s64 + 1800;
	// stw r9,84(r1)
	REX_STORE_U32(ctx.r1.u32 + 84, ctx.r9.u32);
	// li r5,1
	ctx.r5.s64 = 1;
	// stw r8,80(r1)
	REX_STORE_U32(ctx.r1.u32 + 80, ctx.r8.u32);
	// addi r4,r1,80
	ctx.r4.s64 = ctx.r1.s64 + 80;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0bf510
	ctx.lr = 0x8B0A72D0;
	sub_8B0BF510(ctx, base);
	// lwz r7,4(r30)
	ctx.r7.u64 = REX_LOAD_U32(ctx.r30.u32 + 4);
	// cmplwi cr6,r7,0
	ctx.cr6.compare<uint32_t>(ctx.r7.u32, 0, ctx.xer);
	// beq cr6,0x8b0a72f4
	if (ctx.cr6.eq) goto loc_8B0A72F4;
	// rotlwi r3,r7,0
	ctx.r3.u64 = __builtin_rotateleft32(ctx.r7.u32, 0);
	// mr r4,r31
	ctx.r4.u64 = ctx.r31.u64;
	// lwz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r10,4(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 4);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B0A72F4;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
loc_8B0A72F4:
	// addi r1,r1,112
	ctx.r1.s64 = ctx.r1.s64 + 112;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// ld r30,-24(r1)
	ctx.r30.u64 = REX_LOAD_U64(ctx.r1.u32 + -24);
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0A7468) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// std r30,-24(r1)
	REX_STORE_U64(ctx.r1.u32 + -24, ctx.r30.u64);
	// std r31,-16(r1)
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.r31.u64);
	// stwu r1,-112(r1)
	ea = -112 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// mr r30,r4
	ctx.r30.u64 = ctx.r4.u64;
	// bl 0x8b0a6fd0
	ctx.lr = 0x8B0A7488;
	sub_8B0A6FD0(ctx, base);
	// lhz r4,4(r3)
	ctx.r4.u64 = REX_LOAD_U16(ctx.r3.u32 + 4);
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0a6fd0
	ctx.lr = 0x8B0A7494;
	sub_8B0A6FD0(ctx, base);
	// lhz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U16(ctx.r3.u32 + 0);
	// clrlwi r10,r30,16
	ctx.r10.u64 = ctx.r30.u32 & 0xFFFF;
	// subf r9,r11,r10
	ctx.r9.u64 = ctx.r10.u64 - ctx.r11.u64;
	// cntlzw r8,r9
	ctx.r8.u64 = ctx.r9.u32 == 0 ? 32 : __builtin_clz(ctx.r9.u32);
	// rlwinm r3,r8,27,31,31
	ctx.r3.u64 = __builtin_rotateleft64(ctx.r8.u32 | (ctx.r8.u64 << 32), 27) & 0x1;
	// addi r1,r1,112
	ctx.r1.s64 = ctx.r1.s64 + 112;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// ld r30,-24(r1)
	ctx.r30.u64 = REX_LOAD_U64(ctx.r1.u32 + -24);
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0A7878) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9b0
	ctx.lr = 0x8B0A7880;
	__savegprlr_26(ctx, base);
	// stwu r1,-144(r1)
	ea = -144 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// mr r30,r4
	ctx.r30.u64 = ctx.r4.u64;
	// bl 0x8b0a6fd0
	ctx.lr = 0x8B0A7890;
	sub_8B0A6FD0(ctx, base);
	// mr r11,r3
	ctx.r11.u64 = ctx.r3.u64;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// lhz r29,0(r11)
	ctx.r29.u64 = REX_LOAD_U16(ctx.r11.u32 + 0);
	// mr r4,r29
	ctx.r4.u64 = ctx.r29.u64;
	// bl 0x8b0a6fd0
	ctx.lr = 0x8B0A78A4;
	sub_8B0A6FD0(ctx, base);
	// rlwinm r11,r30,3,13,28
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r30.u32 | (ctx.r30.u64 << 32), 3) & 0x7FFF8;
	// clrlwi r27,r30,16
	ctx.r27.u64 = ctx.r30.u32 & 0xFFFF;
	// lhz r10,2(r3)
	ctx.r10.u64 = REX_LOAD_U16(ctx.r3.u32 + 2);
	// lwz r9,4(r31)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r31.u32 + 4);
	// mr r4,r29
	ctx.r4.u64 = ctx.r29.u64;
	// add r8,r27,r11
	ctx.r8.u64 = ctx.r27.u64 + ctx.r11.u64;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// rlwinm r26,r8,3,0,28
	ctx.r26.u64 = __builtin_rotateleft64(ctx.r8.u32 | (ctx.r8.u64 << 32), 3) & 0xFFFFFFF8;
	// sthx r10,r9,r26
	REX_STORE_U16(ctx.r9.u32 + ctx.r26.u32, ctx.r10.u16);
	// bl 0x8b0a6fd0
	ctx.lr = 0x8B0A78CC;
	sub_8B0A6FD0(ctx, base);
	// lhz r7,2(r3)
	ctx.r7.u64 = REX_LOAD_U16(ctx.r3.u32 + 2);
	// cmplwi cr6,r7,65535
	ctx.cr6.compare<uint32_t>(ctx.r7.u32, 65535, ctx.xer);
	// beq cr6,0x8b0a7900
	if (ctx.cr6.eq) goto loc_8B0A7900;
	// mr r4,r29
	ctx.r4.u64 = ctx.r29.u64;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0a6fd0
	ctx.lr = 0x8B0A78E4;
	sub_8B0A6FD0(ctx, base);
	// lhz r10,2(r3)
	ctx.r10.u64 = REX_LOAD_U16(ctx.r3.u32 + 2);
	// lwz r9,4(r31)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r31.u32 + 4);
	// rotlwi r11,r10,3
	ctx.r11.u64 = __builtin_rotateleft32(ctx.r10.u32, 3);
	// add r8,r10,r11
	ctx.r8.u64 = ctx.r10.u64 + ctx.r11.u64;
	// rlwinm r11,r8,3,0,28
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r8.u32 | (ctx.r8.u64 << 32), 3) & 0xFFFFFFF8;
	// add r7,r11,r9
	ctx.r7.u64 = ctx.r11.u64 + ctx.r9.u64;
	// sth r30,4(r7)
	REX_STORE_U16(ctx.r7.u32 + 4, ctx.r30.u16);
loc_8B0A7900:
	// clrlwi r28,r29,16
	ctx.r28.u64 = ctx.r29.u32 & 0xFFFF;
	// cmplwi cr6,r28,65535
	ctx.cr6.compare<uint32_t>(ctx.r28.u32, 65535, ctx.xer);
	// beq cr6,0x8b0a7934
	if (ctx.cr6.eq) goto loc_8B0A7934;
	// mr r4,r30
	ctx.r4.u64 = ctx.r30.u64;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0a6fd0
	ctx.lr = 0x8B0A7918;
	sub_8B0A6FD0(ctx, base);
	// rlwinm r11,r28,3,0,28
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r28.u32 | (ctx.r28.u64 << 32), 3) & 0xFFFFFFF8;
	// lwz r10,4(r31)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r31.u32 + 4);
	// add r11,r28,r11
	ctx.r11.u64 = ctx.r28.u64 + ctx.r11.u64;
	// lhz r9,4(r3)
	ctx.r9.u64 = REX_LOAD_U16(ctx.r3.u32 + 4);
	// rlwinm r11,r11,3,0,28
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 3) & 0xFFFFFFF8;
	// add r8,r11,r10
	ctx.r8.u64 = ctx.r11.u64 + ctx.r10.u64;
	// sth r9,4(r8)
	REX_STORE_U16(ctx.r8.u32 + 4, ctx.r9.u16);
loc_8B0A7934:
	// lhz r11,16(r31)
	ctx.r11.u64 = REX_LOAD_U16(ctx.r31.u32 + 16);
	// cmplw cr6,r27,r11
	ctx.cr6.compare<uint32_t>(ctx.r27.u32, ctx.r11.u32, ctx.xer);
	// beq cr6,0x8b0a79b4
	if (ctx.cr6.eq) goto loc_8B0A79B4;
	// mr r4,r30
	ctx.r4.u64 = ctx.r30.u64;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0a6fd0
	ctx.lr = 0x8B0A794C;
	sub_8B0A6FD0(ctx, base);
	// lhz r4,4(r3)
	ctx.r4.u64 = REX_LOAD_U16(ctx.r3.u32 + 4);
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0a6fd0
	ctx.lr = 0x8B0A7958;
	sub_8B0A6FD0(ctx, base);
	// lhz r11,2(r3)
	ctx.r11.u64 = REX_LOAD_U16(ctx.r3.u32 + 2);
	// mr r4,r30
	ctx.r4.u64 = ctx.r30.u64;
	// cmplw cr6,r11,r27
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, ctx.r27.u32, ctx.xer);
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bne cr6,0x8b0a7990
	if (!ctx.cr6.eq) goto loc_8B0A7990;
	// bl 0x8b0a6fd0
	ctx.lr = 0x8B0A7970;
	sub_8B0A6FD0(ctx, base);
	// lhz r9,4(r3)
	ctx.r9.u64 = REX_LOAD_U16(ctx.r3.u32 + 4);
	// lwz r10,4(r31)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r31.u32 + 4);
	// rotlwi r11,r9,3
	ctx.r11.u64 = __builtin_rotateleft32(ctx.r9.u32, 3);
	// add r8,r9,r11
	ctx.r8.u64 = ctx.r9.u64 + ctx.r11.u64;
	// rlwinm r11,r8,3,0,28
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r8.u32 | (ctx.r8.u64 << 32), 3) & 0xFFFFFFF8;
	// add r7,r11,r10
	ctx.r7.u64 = ctx.r11.u64 + ctx.r10.u64;
	// sth r29,2(r7)
	REX_STORE_U16(ctx.r7.u32 + 2, ctx.r29.u16);
	// b 0x8b0a79b8
	goto loc_8B0A79B8;
loc_8B0A7990:
	// bl 0x8b0a6fd0
	ctx.lr = 0x8B0A7994;
	sub_8B0A6FD0(ctx, base);
	// lhz r10,4(r3)
	ctx.r10.u64 = REX_LOAD_U16(ctx.r3.u32 + 4);
	// lwz r9,4(r31)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r31.u32 + 4);
	// mr r11,r10
	ctx.r11.u64 = ctx.r10.u64;
	// rotlwi r10,r10,3
	ctx.r10.u64 = __builtin_rotateleft32(ctx.r10.u32, 3);
	// add r8,r11,r10
	ctx.r8.u64 = ctx.r11.u64 + ctx.r10.u64;
	// rlwinm r7,r8,3,0,28
	ctx.r7.u64 = __builtin_rotateleft64(ctx.r8.u32 | (ctx.r8.u64 << 32), 3) & 0xFFFFFFF8;
	// sthx r29,r7,r9
	REX_STORE_U16(ctx.r7.u32 + ctx.r9.u32, ctx.r29.u16);
	// b 0x8b0a79b8
	goto loc_8B0A79B8;
loc_8B0A79B4:
	// sth r29,16(r31)
	REX_STORE_U16(ctx.r31.u32 + 16, ctx.r29.u16);
loc_8B0A79B8:
	// rlwinm r11,r28,3,0,28
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r28.u32 | (ctx.r28.u64 << 32), 3) & 0xFFFFFFF8;
	// lwz r10,4(r31)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r31.u32 + 4);
	// cmplwi cr6,r27,65535
	ctx.cr6.compare<uint32_t>(ctx.r27.u32, 65535, ctx.xer);
	// add r11,r28,r11
	ctx.r11.u64 = ctx.r28.u64 + ctx.r11.u64;
	// rlwinm r11,r11,3,0,28
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 3) & 0xFFFFFFF8;
	// add r10,r11,r10
	ctx.r10.u64 = ctx.r11.u64 + ctx.r10.u64;
	// sth r30,2(r10)
	REX_STORE_U16(ctx.r10.u32 + 2, ctx.r30.u16);
	// beq cr6,0x8b0a79e4
	if (ctx.cr6.eq) goto loc_8B0A79E4;
	// lwz r11,4(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 4);
	// add r11,r11,r26
	ctx.r11.u64 = ctx.r11.u64 + ctx.r26.u64;
	// sth r29,4(r11)
	REX_STORE_U16(ctx.r11.u32 + 4, ctx.r29.u16);
loc_8B0A79E4:
	// addi r1,r1,144
	ctx.r1.s64 = ctx.r1.s64 + 144;
	// b 0x8b0cba00
	__restgprlr_26(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0A8790) {
	REX_FUNC_PROLOGUE();
	PPCRegister temp{};
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// std r31,-16(r1)
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.r31.u64);
	// stwu r1,-96(r1)
	ea = -96 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// clrlwi r31,r4,16
	ctx.r31.u64 = ctx.r4.u32 & 0xFFFF;
	// cmpwi cr6,r31,0
	ctx.cr6.compare<int32_t>(ctx.r31.s32, 0, ctx.xer);
	// blt cr6,0x8b0a87bc
	if (ctx.cr6.lt) goto loc_8B0A87BC;
	// lwz r11,8(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 8);
	// cmpw cr6,r31,r11
	ctx.cr6.compare<int32_t>(ctx.r31.s32, ctx.r11.s32, ctx.xer);
	// li r11,1
	ctx.r11.s64 = 1;
	// blt cr6,0x8b0a87c0
	if (ctx.cr6.lt) goto loc_8B0A87C0;
loc_8B0A87BC:
	// li r11,0
	ctx.r11.s64 = 0;
loc_8B0A87C0:
	// clrlwi r11,r11,24
	ctx.r11.u64 = ctx.r11.u32 & 0xFF;
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// bne cr6,0x8b0a87e4
	if (!ctx.cr6.eq) goto loc_8B0A87E4;
loc_8B0A87CC:
	// li r3,0
	ctx.r3.s64 = 0;
	// addi r1,r1,96
	ctx.r1.s64 = ctx.r1.s64 + 96;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
loc_8B0A87E4:
	// lhz r11,22(r3)
	ctx.r11.u64 = REX_LOAD_U16(ctx.r3.u32 + 22);
	// cmplw cr6,r31,r11
	ctx.cr6.compare<uint32_t>(ctx.r31.u32, ctx.r11.u32, ctx.xer);
	// bgt cr6,0x8b0a87cc
	if (ctx.cr6.gt) goto loc_8B0A87CC;
	// bl 0x8b0a6fd0
	ctx.lr = 0x8B0A87F4;
	sub_8B0A6FD0(ctx, base);
	// lhz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U16(ctx.r3.u32 + 0);
	// subf r10,r11,r31
	ctx.r10.u64 = ctx.r31.u64 - ctx.r11.u64;
	// addic r9,r10,-1
	ctx.xer.ca = ctx.r10.u32 > 0;
	ctx.r9.s64 = ctx.r10.s64 + -1;
	// subfe r3,r9,r10
	temp.u8 = (~ctx.r9.u32 + ctx.r10.u32 < ~ctx.r9.u32) | (~ctx.r9.u32 + ctx.r10.u32 + ctx.xer.ca < ctx.xer.ca);
	ctx.r3.u64 = ~ctx.r9.u64 + ctx.r10.u64 + ctx.xer.ca;
	ctx.xer.ca = temp.u8;
	// addi r1,r1,96
	ctx.r1.s64 = ctx.r1.s64 + 96;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0A8A68) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// std r30,-24(r1)
	REX_STORE_U64(ctx.r1.u32 + -24, ctx.r30.u64);
	// std r31,-16(r1)
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.r31.u64);
	// stwu r1,-112(r1)
	ea = -112 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// mr r30,r3
	ctx.r30.u64 = ctx.r3.u64;
	// mr r31,r4
	ctx.r31.u64 = ctx.r4.u64;
	// bl 0x8b0a6fd0
	ctx.lr = 0x8B0A8A88;
	sub_8B0A6FD0(ctx, base);
	// lhz r11,2(r3)
	ctx.r11.u64 = REX_LOAD_U16(ctx.r3.u32 + 2);
	// mr r4,r31
	ctx.r4.u64 = ctx.r31.u64;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// cmplwi cr6,r11,65535
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 65535, ctx.xer);
	// beq cr6,0x8b0a8b80
	if (ctx.cr6.eq) goto loc_8B0A8B80;
	// bl 0x8b0a6fd0
	ctx.lr = 0x8B0A8AA0;
	sub_8B0A6FD0(ctx, base);
	// lis r4,-29938
	ctx.r4.s64 = -1962016768;
	// lis r10,0
	ctx.r10.s64 = 0;
	// lhz r3,2(r3)
	ctx.r3.u64 = REX_LOAD_U16(ctx.r3.u32 + 2);
	// lis r11,-29938
	ctx.r11.s64 = -1962016768;
	// ori r10,r10,65535
	ctx.r10.u64 = ctx.r10.u64 | 65535;
	// addi r11,r11,19640
	ctx.r11.s64 = ctx.r11.s64 + 19640;
	// lwz r9,19648(r4)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r4.u32 + 19648);
loc_8B0A8ABC:
	// clrlwi r8,r9,31
	ctx.r8.u64 = ctx.r9.u32 & 0x1;
	// cmplwi cr6,r8,0
	ctx.cr6.compare<uint32_t>(ctx.r8.u32, 0, ctx.xer);
	// bne cr6,0x8b0a8aec
	if (!ctx.cr6.eq) goto loc_8B0A8AEC;
	// ori r9,r9,1
	ctx.r9.u64 = ctx.r9.u64 | 1;
	// sth r10,0(r11)
	REX_STORE_U16(ctx.r11.u32 + 0, ctx.r10.u16);
	// li r6,1
	ctx.r6.s64 = 1;
	// sth r10,2(r11)
	REX_STORE_U16(ctx.r11.u32 + 2, ctx.r10.u16);
	// mr r8,r10
	ctx.r8.u64 = ctx.r10.u64;
	// stw r9,19648(r4)
	REX_STORE_U32(ctx.r4.u32 + 19648, ctx.r9.u32);
	// mr r7,r10
	ctx.r7.u64 = ctx.r10.u64;
	// sth r10,4(r11)
	REX_STORE_U16(ctx.r11.u32 + 4, ctx.r10.u16);
	// sth r6,6(r11)
	REX_STORE_U16(ctx.r11.u32 + 6, ctx.r6.u16);
loc_8B0A8AEC:
	// clrlwi r5,r3,16
	ctx.r5.u64 = ctx.r3.u32 & 0xFFFF;
	// cmplwi cr6,r5,65535
	ctx.cr6.compare<uint32_t>(ctx.r5.u32, 65535, ctx.xer);
	// beq cr6,0x8b0a8b10
	if (ctx.cr6.eq) goto loc_8B0A8B10;
	// rlwinm r8,r5,3,0,28
	ctx.r8.u64 = __builtin_rotateleft64(ctx.r5.u32 | (ctx.r5.u64 << 32), 3) & 0xFFFFFFF8;
	// lwz r7,4(r30)
	ctx.r7.u64 = REX_LOAD_U32(ctx.r30.u32 + 4);
	// add r8,r5,r8
	ctx.r8.u64 = ctx.r5.u64 + ctx.r8.u64;
	// rlwinm r8,r8,3,0,28
	ctx.r8.u64 = __builtin_rotateleft64(ctx.r8.u32 | (ctx.r8.u64 << 32), 3) & 0xFFFFFFF8;
	// add r8,r8,r7
	ctx.r8.u64 = ctx.r8.u64 + ctx.r7.u64;
	// b 0x8b0a8b14
	goto loc_8B0A8B14;
loc_8B0A8B10:
	// mr r8,r11
	ctx.r8.u64 = ctx.r11.u64;
loc_8B0A8B14:
	// lhz r8,0(r8)
	ctx.r8.u64 = REX_LOAD_U16(ctx.r8.u32 + 0);
	// cmplwi cr6,r8,65535
	ctx.cr6.compare<uint32_t>(ctx.r8.u32, 65535, ctx.xer);
	// beq cr6,0x8b0a8cbc
	if (ctx.cr6.eq) goto loc_8B0A8CBC;
	// clrlwi r8,r9,31
	ctx.r8.u64 = ctx.r9.u32 & 0x1;
	// cmplwi cr6,r8,0
	ctx.cr6.compare<uint32_t>(ctx.r8.u32, 0, ctx.xer);
	// bne cr6,0x8b0a8b50
	if (!ctx.cr6.eq) goto loc_8B0A8B50;
	// ori r9,r9,1
	ctx.r9.u64 = ctx.r9.u64 | 1;
	// sth r10,0(r11)
	REX_STORE_U16(ctx.r11.u32 + 0, ctx.r10.u16);
	// li r6,1
	ctx.r6.s64 = 1;
	// sth r10,2(r11)
	REX_STORE_U16(ctx.r11.u32 + 2, ctx.r10.u16);
	// mr r8,r10
	ctx.r8.u64 = ctx.r10.u64;
	// stw r9,19648(r4)
	REX_STORE_U32(ctx.r4.u32 + 19648, ctx.r9.u32);
	// mr r7,r10
	ctx.r7.u64 = ctx.r10.u64;
	// sth r10,4(r11)
	REX_STORE_U16(ctx.r11.u32 + 4, ctx.r10.u16);
	// sth r6,6(r11)
	REX_STORE_U16(ctx.r11.u32 + 6, ctx.r6.u16);
loc_8B0A8B50:
	// cmplwi cr6,r5,65535
	ctx.cr6.compare<uint32_t>(ctx.r5.u32, 65535, ctx.xer);
	// beq cr6,0x8b0a8b74
	if (ctx.cr6.eq) goto loc_8B0A8B74;
	// rlwinm r8,r5,3,0,28
	ctx.r8.u64 = __builtin_rotateleft64(ctx.r5.u32 | (ctx.r5.u64 << 32), 3) & 0xFFFFFFF8;
	// lwz r7,4(r30)
	ctx.r7.u64 = REX_LOAD_U32(ctx.r30.u32 + 4);
	// add r8,r5,r8
	ctx.r8.u64 = ctx.r5.u64 + ctx.r8.u64;
	// rlwinm r8,r8,3,0,28
	ctx.r8.u64 = __builtin_rotateleft64(ctx.r8.u32 | (ctx.r8.u64 << 32), 3) & 0xFFFFFFF8;
	// add r8,r8,r7
	ctx.r8.u64 = ctx.r8.u64 + ctx.r7.u64;
	// lhz r3,0(r8)
	ctx.r3.u64 = REX_LOAD_U16(ctx.r8.u32 + 0);
	// b 0x8b0a8abc
	goto loc_8B0A8ABC;
loc_8B0A8B74:
	// lhz r3,0(r11)
	ctx.r3.u64 = REX_LOAD_U16(ctx.r11.u32 + 0);
	// mr r8,r11
	ctx.r8.u64 = ctx.r11.u64;
	// b 0x8b0a8abc
	goto loc_8B0A8ABC;
loc_8B0A8B80:
	// bl 0x8b0a6fd0
	ctx.lr = 0x8B0A8B84;
	sub_8B0A6FD0(ctx, base);
	// lis r4,-29938
	ctx.r4.s64 = -1962016768;
	// lis r10,0
	ctx.r10.s64 = 0;
	// lhz r3,4(r3)
	ctx.r3.u64 = REX_LOAD_U16(ctx.r3.u32 + 4);
	// lis r11,-29938
	ctx.r11.s64 = -1962016768;
	// ori r10,r10,65535
	ctx.r10.u64 = ctx.r10.u64 | 65535;
	// addi r11,r11,19640
	ctx.r11.s64 = ctx.r11.s64 + 19640;
	// lwz r9,19648(r4)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r4.u32 + 19648);
loc_8B0A8BA0:
	// clrlwi r8,r9,31
	ctx.r8.u64 = ctx.r9.u32 & 0x1;
	// cmplwi cr6,r8,0
	ctx.cr6.compare<uint32_t>(ctx.r8.u32, 0, ctx.xer);
	// bne cr6,0x8b0a8bd0
	if (!ctx.cr6.eq) goto loc_8B0A8BD0;
	// ori r9,r9,1
	ctx.r9.u64 = ctx.r9.u64 | 1;
	// sth r10,0(r11)
	REX_STORE_U16(ctx.r11.u32 + 0, ctx.r10.u16);
	// li r6,1
	ctx.r6.s64 = 1;
	// sth r10,2(r11)
	REX_STORE_U16(ctx.r11.u32 + 2, ctx.r10.u16);
	// mr r8,r10
	ctx.r8.u64 = ctx.r10.u64;
	// stw r9,19648(r4)
	REX_STORE_U32(ctx.r4.u32 + 19648, ctx.r9.u32);
	// mr r7,r10
	ctx.r7.u64 = ctx.r10.u64;
	// sth r10,4(r11)
	REX_STORE_U16(ctx.r11.u32 + 4, ctx.r10.u16);
	// sth r6,6(r11)
	REX_STORE_U16(ctx.r11.u32 + 6, ctx.r6.u16);
loc_8B0A8BD0:
	// clrlwi r31,r31,16
	ctx.r31.u64 = ctx.r31.u32 & 0xFFFF;
	// cmplwi cr6,r31,65535
	ctx.cr6.compare<uint32_t>(ctx.r31.u32, 65535, ctx.xer);
	// beq cr6,0x8b0a8bf4
	if (ctx.cr6.eq) goto loc_8B0A8BF4;
	// rlwinm r8,r31,3,0,28
	ctx.r8.u64 = __builtin_rotateleft64(ctx.r31.u32 | (ctx.r31.u64 << 32), 3) & 0xFFFFFFF8;
	// lwz r7,4(r30)
	ctx.r7.u64 = REX_LOAD_U32(ctx.r30.u32 + 4);
	// add r8,r31,r8
	ctx.r8.u64 = ctx.r31.u64 + ctx.r8.u64;
	// rlwinm r8,r8,3,0,28
	ctx.r8.u64 = __builtin_rotateleft64(ctx.r8.u32 | (ctx.r8.u64 << 32), 3) & 0xFFFFFFF8;
	// add r8,r8,r7
	ctx.r8.u64 = ctx.r8.u64 + ctx.r7.u64;
	// b 0x8b0a8bf8
	goto loc_8B0A8BF8;
loc_8B0A8BF4:
	// mr r8,r11
	ctx.r8.u64 = ctx.r11.u64;
loc_8B0A8BF8:
	// clrlwi r7,r9,31
	ctx.r7.u64 = ctx.r9.u32 & 0x1;
	// lhz r5,4(r8)
	ctx.r5.u64 = REX_LOAD_U16(ctx.r8.u32 + 4);
	// cmplwi cr6,r7,0
	ctx.cr6.compare<uint32_t>(ctx.r7.u32, 0, ctx.xer);
	// bne cr6,0x8b0a8c2c
	if (!ctx.cr6.eq) goto loc_8B0A8C2C;
	// ori r9,r9,1
	ctx.r9.u64 = ctx.r9.u64 | 1;
	// sth r10,0(r11)
	REX_STORE_U16(ctx.r11.u32 + 0, ctx.r10.u16);
	// li r6,1
	ctx.r6.s64 = 1;
	// sth r10,2(r11)
	REX_STORE_U16(ctx.r11.u32 + 2, ctx.r10.u16);
	// mr r8,r10
	ctx.r8.u64 = ctx.r10.u64;
	// stw r9,19648(r4)
	REX_STORE_U32(ctx.r4.u32 + 19648, ctx.r9.u32);
	// mr r7,r10
	ctx.r7.u64 = ctx.r10.u64;
	// sth r10,4(r11)
	REX_STORE_U16(ctx.r11.u32 + 4, ctx.r10.u16);
	// sth r6,6(r11)
	REX_STORE_U16(ctx.r11.u32 + 6, ctx.r6.u16);
loc_8B0A8C2C:
	// clrlwi r8,r5,16
	ctx.r8.u64 = ctx.r5.u32 & 0xFFFF;
	// cmplwi cr6,r8,65535
	ctx.cr6.compare<uint32_t>(ctx.r8.u32, 65535, ctx.xer);
	// beq cr6,0x8b0a8c50
	if (ctx.cr6.eq) goto loc_8B0A8C50;
	// rlwinm r6,r8,3,0,28
	ctx.r6.u64 = __builtin_rotateleft64(ctx.r8.u32 | (ctx.r8.u64 << 32), 3) & 0xFFFFFFF8;
	// lwz r7,4(r30)
	ctx.r7.u64 = REX_LOAD_U32(ctx.r30.u32 + 4);
	// add r8,r8,r6
	ctx.r8.u64 = ctx.r8.u64 + ctx.r6.u64;
	// rlwinm r8,r8,3,0,28
	ctx.r8.u64 = __builtin_rotateleft64(ctx.r8.u32 | (ctx.r8.u64 << 32), 3) & 0xFFFFFFF8;
	// add r8,r8,r7
	ctx.r8.u64 = ctx.r8.u64 + ctx.r7.u64;
	// b 0x8b0a8c54
	goto loc_8B0A8C54;
loc_8B0A8C50:
	// mr r8,r11
	ctx.r8.u64 = ctx.r11.u64;
loc_8B0A8C54:
	// lhz r8,2(r8)
	ctx.r8.u64 = REX_LOAD_U16(ctx.r8.u32 + 2);
	// cmplw cr6,r8,r31
	ctx.cr6.compare<uint32_t>(ctx.r8.u32, ctx.r31.u32, ctx.xer);
	// bne cr6,0x8b0a8cbc
	if (!ctx.cr6.eq) goto loc_8B0A8CBC;
	// clrlwi r5,r3,16
	ctx.r5.u64 = ctx.r3.u32 & 0xFFFF;
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// cmplwi cr6,r5,65535
	ctx.cr6.compare<uint32_t>(ctx.r5.u32, 65535, ctx.xer);
	// beq cr6,0x8b0a8cbc
	if (ctx.cr6.eq) goto loc_8B0A8CBC;
	// clrlwi r8,r9,31
	ctx.r8.u64 = ctx.r9.u32 & 0x1;
	// cmplwi cr6,r8,0
	ctx.cr6.compare<uint32_t>(ctx.r8.u32, 0, ctx.xer);
	// bne cr6,0x8b0a8ca0
	if (!ctx.cr6.eq) goto loc_8B0A8CA0;
	// ori r9,r9,1
	ctx.r9.u64 = ctx.r9.u64 | 1;
	// sth r10,0(r11)
	REX_STORE_U16(ctx.r11.u32 + 0, ctx.r10.u16);
	// li r6,1
	ctx.r6.s64 = 1;
	// sth r10,2(r11)
	REX_STORE_U16(ctx.r11.u32 + 2, ctx.r10.u16);
	// mr r8,r10
	ctx.r8.u64 = ctx.r10.u64;
	// stw r9,19648(r4)
	REX_STORE_U32(ctx.r4.u32 + 19648, ctx.r9.u32);
	// mr r7,r10
	ctx.r7.u64 = ctx.r10.u64;
	// sth r10,4(r11)
	REX_STORE_U16(ctx.r11.u32 + 4, ctx.r10.u16);
	// sth r6,6(r11)
	REX_STORE_U16(ctx.r11.u32 + 6, ctx.r6.u16);
loc_8B0A8CA0:
	// rlwinm r8,r5,3,0,28
	ctx.r8.u64 = __builtin_rotateleft64(ctx.r5.u32 | (ctx.r5.u64 << 32), 3) & 0xFFFFFFF8;
	// lwz r7,4(r30)
	ctx.r7.u64 = REX_LOAD_U32(ctx.r30.u32 + 4);
	// add r8,r5,r8
	ctx.r8.u64 = ctx.r5.u64 + ctx.r8.u64;
	// rlwinm r8,r8,3,0,28
	ctx.r8.u64 = __builtin_rotateleft64(ctx.r8.u32 | (ctx.r8.u64 << 32), 3) & 0xFFFFFFF8;
	// add r8,r8,r7
	ctx.r8.u64 = ctx.r8.u64 + ctx.r7.u64;
	// lhz r3,4(r8)
	ctx.r3.u64 = REX_LOAD_U16(ctx.r8.u32 + 4);
	// b 0x8b0a8ba0
	goto loc_8B0A8BA0;
loc_8B0A8CBC:
	// addi r1,r1,112
	ctx.r1.s64 = ctx.r1.s64 + 112;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// ld r30,-24(r1)
	ctx.r30.u64 = REX_LOAD_U64(ctx.r1.u32 + -24);
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0A9EE0) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9a8
	ctx.lr = 0x8B0A9EE8;
	__savegprlr_24(ctx, base);
	// stwu r1,-160(r1)
	ea = -160 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// clrlwi r24,r4,16
	ctx.r24.u64 = ctx.r4.u32 & 0xFFFF;
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// mr r25,r4
	ctx.r25.u64 = ctx.r4.u64;
	// cmplwi cr6,r24,65535
	ctx.cr6.compare<uint32_t>(ctx.r24.u32, 65535, ctx.xer);
	// beq cr6,0x8b0aa2ac
	if (ctx.cr6.eq) goto loc_8B0AA2AC;
	// bl 0x8b0a6fd0
	ctx.lr = 0x8B0A9F04;
	sub_8B0A6FD0(ctx, base);
	// lhz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U16(ctx.r3.u32 + 0);
	// cmplwi cr6,r11,65535
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 65535, ctx.xer);
	// beq cr6,0x8b0aa014
	if (ctx.cr6.eq) goto loc_8B0AA014;
	// mr r4,r25
	ctx.r4.u64 = ctx.r25.u64;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0a6fd0
	ctx.lr = 0x8B0A9F1C;
	sub_8B0A6FD0(ctx, base);
	// lhz r11,2(r3)
	ctx.r11.u64 = REX_LOAD_U16(ctx.r3.u32 + 2);
	// cmplwi cr6,r11,65535
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 65535, ctx.xer);
	// beq cr6,0x8b0aa014
	if (ctx.cr6.eq) goto loc_8B0AA014;
	// mr r4,r25
	ctx.r4.u64 = ctx.r25.u64;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0a6fd0
	ctx.lr = 0x8B0A9F34;
	sub_8B0A6FD0(ctx, base);
	// lis r4,-29938
	ctx.r4.s64 = -1962016768;
	// lis r10,0
	ctx.r10.s64 = 0;
	// lhz r30,2(r3)
	ctx.r30.u64 = REX_LOAD_U16(ctx.r3.u32 + 2);
	// lis r11,-29938
	ctx.r11.s64 = -1962016768;
	// ori r9,r10,65535
	ctx.r9.u64 = ctx.r10.u64 | 65535;
	// addi r11,r11,19640
	ctx.r11.s64 = ctx.r11.s64 + 19640;
	// lwz r10,19648(r4)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r4.u32 + 19648);
loc_8B0A9F50:
	// clrlwi r8,r10,31
	ctx.r8.u64 = ctx.r10.u32 & 0x1;
	// cmplwi cr6,r8,0
	ctx.cr6.compare<uint32_t>(ctx.r8.u32, 0, ctx.xer);
	// bne cr6,0x8b0a9f80
	if (!ctx.cr6.eq) goto loc_8B0A9F80;
	// ori r10,r10,1
	ctx.r10.u64 = ctx.r10.u64 | 1;
	// sth r9,0(r11)
	REX_STORE_U16(ctx.r11.u32 + 0, ctx.r9.u16);
	// li r6,1
	ctx.r6.s64 = 1;
	// sth r9,2(r11)
	REX_STORE_U16(ctx.r11.u32 + 2, ctx.r9.u16);
	// mr r8,r9
	ctx.r8.u64 = ctx.r9.u64;
	// stw r10,19648(r4)
	REX_STORE_U32(ctx.r4.u32 + 19648, ctx.r10.u32);
	// mr r7,r9
	ctx.r7.u64 = ctx.r9.u64;
	// sth r9,4(r11)
	REX_STORE_U16(ctx.r11.u32 + 4, ctx.r9.u16);
	// sth r6,6(r11)
	REX_STORE_U16(ctx.r11.u32 + 6, ctx.r6.u16);
loc_8B0A9F80:
	// clrlwi r5,r30,16
	ctx.r5.u64 = ctx.r30.u32 & 0xFFFF;
	// cmplwi cr6,r5,65535
	ctx.cr6.compare<uint32_t>(ctx.r5.u32, 65535, ctx.xer);
	// beq cr6,0x8b0a9fa4
	if (ctx.cr6.eq) goto loc_8B0A9FA4;
	// rlwinm r8,r5,3,0,28
	ctx.r8.u64 = __builtin_rotateleft64(ctx.r5.u32 | (ctx.r5.u64 << 32), 3) & 0xFFFFFFF8;
	// lwz r7,4(r31)
	ctx.r7.u64 = REX_LOAD_U32(ctx.r31.u32 + 4);
	// add r8,r5,r8
	ctx.r8.u64 = ctx.r5.u64 + ctx.r8.u64;
	// rlwinm r8,r8,3,0,28
	ctx.r8.u64 = __builtin_rotateleft64(ctx.r8.u32 | (ctx.r8.u64 << 32), 3) & 0xFFFFFFF8;
	// add r8,r8,r7
	ctx.r8.u64 = ctx.r8.u64 + ctx.r7.u64;
	// b 0x8b0a9fa8
	goto loc_8B0A9FA8;
loc_8B0A9FA4:
	// mr r8,r11
	ctx.r8.u64 = ctx.r11.u64;
loc_8B0A9FA8:
	// lhz r8,0(r8)
	ctx.r8.u64 = REX_LOAD_U16(ctx.r8.u32 + 0);
	// cmplwi cr6,r8,65535
	ctx.cr6.compare<uint32_t>(ctx.r8.u32, 65535, ctx.xer);
	// beq cr6,0x8b0aa018
	if (ctx.cr6.eq) goto loc_8B0AA018;
	// clrlwi r8,r10,31
	ctx.r8.u64 = ctx.r10.u32 & 0x1;
	// cmplwi cr6,r8,0
	ctx.cr6.compare<uint32_t>(ctx.r8.u32, 0, ctx.xer);
	// bne cr6,0x8b0a9fe4
	if (!ctx.cr6.eq) goto loc_8B0A9FE4;
	// ori r10,r10,1
	ctx.r10.u64 = ctx.r10.u64 | 1;
	// sth r9,0(r11)
	REX_STORE_U16(ctx.r11.u32 + 0, ctx.r9.u16);
	// li r6,1
	ctx.r6.s64 = 1;
	// sth r9,2(r11)
	REX_STORE_U16(ctx.r11.u32 + 2, ctx.r9.u16);
	// mr r8,r9
	ctx.r8.u64 = ctx.r9.u64;
	// stw r10,19648(r4)
	REX_STORE_U32(ctx.r4.u32 + 19648, ctx.r10.u32);
	// mr r7,r9
	ctx.r7.u64 = ctx.r9.u64;
	// sth r9,4(r11)
	REX_STORE_U16(ctx.r11.u32 + 4, ctx.r9.u16);
	// sth r6,6(r11)
	REX_STORE_U16(ctx.r11.u32 + 6, ctx.r6.u16);
loc_8B0A9FE4:
	// cmplwi cr6,r5,65535
	ctx.cr6.compare<uint32_t>(ctx.r5.u32, 65535, ctx.xer);
	// beq cr6,0x8b0aa008
	if (ctx.cr6.eq) goto loc_8B0AA008;
	// rlwinm r8,r5,3,0,28
	ctx.r8.u64 = __builtin_rotateleft64(ctx.r5.u32 | (ctx.r5.u64 << 32), 3) & 0xFFFFFFF8;
	// lwz r7,4(r31)
	ctx.r7.u64 = REX_LOAD_U32(ctx.r31.u32 + 4);
	// add r8,r5,r8
	ctx.r8.u64 = ctx.r5.u64 + ctx.r8.u64;
	// rlwinm r8,r8,3,0,28
	ctx.r8.u64 = __builtin_rotateleft64(ctx.r8.u32 | (ctx.r8.u64 << 32), 3) & 0xFFFFFFF8;
	// add r8,r8,r7
	ctx.r8.u64 = ctx.r8.u64 + ctx.r7.u64;
	// lhz r30,0(r8)
	ctx.r30.u64 = REX_LOAD_U16(ctx.r8.u32 + 0);
	// b 0x8b0a9f50
	goto loc_8B0A9F50;
loc_8B0AA008:
	// lhz r30,0(r11)
	ctx.r30.u64 = REX_LOAD_U16(ctx.r11.u32 + 0);
	// mr r8,r11
	ctx.r8.u64 = ctx.r11.u64;
	// b 0x8b0a9f50
	goto loc_8B0A9F50;
loc_8B0AA014:
	// mr r30,r25
	ctx.r30.u64 = ctx.r25.u64;
loc_8B0AA018:
	// mr r4,r30
	ctx.r4.u64 = ctx.r30.u64;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0a6fd0
	ctx.lr = 0x8B0AA024;
	sub_8B0A6FD0(ctx, base);
	// lhz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U16(ctx.r3.u32 + 0);
	// mr r4,r30
	ctx.r4.u64 = ctx.r30.u64;
	// cmplwi cr6,r11,65535
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 65535, ctx.xer);
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// beq cr6,0x8b0aa044
	if (ctx.cr6.eq) goto loc_8B0AA044;
	// bl 0x8b0a6fd0
	ctx.lr = 0x8B0AA03C;
	sub_8B0A6FD0(ctx, base);
	// lhz r28,0(r3)
	ctx.r28.u64 = REX_LOAD_U16(ctx.r3.u32 + 0);
	// b 0x8b0aa04c
	goto loc_8B0AA04C;
loc_8B0AA044:
	// bl 0x8b0a6fd0
	ctx.lr = 0x8B0AA048;
	sub_8B0A6FD0(ctx, base);
	// lhz r28,2(r3)
	ctx.r28.u64 = REX_LOAD_U16(ctx.r3.u32 + 2);
loc_8B0AA04C:
	// clrlwi r26,r28,16
	ctx.r26.u64 = ctx.r28.u32 & 0xFFFF;
	// cmplwi cr6,r26,65535
	ctx.cr6.compare<uint32_t>(ctx.r26.u32, 65535, ctx.xer);
	// beq cr6,0x8b0aa080
	if (ctx.cr6.eq) goto loc_8B0AA080;
	// mr r4,r30
	ctx.r4.u64 = ctx.r30.u64;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0a6fd0
	ctx.lr = 0x8B0AA064;
	sub_8B0A6FD0(ctx, base);
	// rlwinm r11,r26,3,0,28
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r26.u32 | (ctx.r26.u64 << 32), 3) & 0xFFFFFFF8;
	// lwz r10,4(r31)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r31.u32 + 4);
	// add r11,r26,r11
	ctx.r11.u64 = ctx.r26.u64 + ctx.r11.u64;
	// lhz r9,4(r3)
	ctx.r9.u64 = REX_LOAD_U16(ctx.r3.u32 + 4);
	// rlwinm r11,r11,3,0,28
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 3) & 0xFFFFFFF8;
	// add r8,r11,r10
	ctx.r8.u64 = ctx.r11.u64 + ctx.r10.u64;
	// sth r9,4(r8)
	REX_STORE_U16(ctx.r8.u32 + 4, ctx.r9.u16);
loc_8B0AA080:
	// lhz r11,16(r31)
	ctx.r11.u64 = REX_LOAD_U16(ctx.r31.u32 + 16);
	// clrlwi r29,r30,16
	ctx.r29.u64 = ctx.r30.u32 & 0xFFFF;
	// cmplw cr6,r29,r11
	ctx.cr6.compare<uint32_t>(ctx.r29.u32, ctx.r11.u32, ctx.xer);
	// beq cr6,0x8b0aa0f8
	if (ctx.cr6.eq) goto loc_8B0AA0F8;
	// mr r4,r30
	ctx.r4.u64 = ctx.r30.u64;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0a7468
	ctx.lr = 0x8B0AA09C;
	sub_8B0A7468(ctx, base);
	// clrlwi r11,r3,24
	ctx.r11.u64 = ctx.r3.u32 & 0xFF;
	// mr r4,r30
	ctx.r4.u64 = ctx.r30.u64;
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// beq cr6,0x8b0aa0d4
	if (ctx.cr6.eq) goto loc_8B0AA0D4;
	// bl 0x8b0a6fd0
	ctx.lr = 0x8B0AA0B4;
	sub_8B0A6FD0(ctx, base);
	// lhz r11,4(r3)
	ctx.r11.u64 = REX_LOAD_U16(ctx.r3.u32 + 4);
	// lwz r9,4(r31)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r31.u32 + 4);
	// mr r10,r11
	ctx.r10.u64 = ctx.r11.u64;
	// rotlwi r11,r11,3
	ctx.r11.u64 = __builtin_rotateleft32(ctx.r11.u32, 3);
	// add r8,r10,r11
	ctx.r8.u64 = ctx.r10.u64 + ctx.r11.u64;
	// rlwinm r7,r8,3,0,28
	ctx.r7.u64 = __builtin_rotateleft64(ctx.r8.u32 | (ctx.r8.u64 << 32), 3) & 0xFFFFFFF8;
	// sthx r28,r7,r9
	REX_STORE_U16(ctx.r7.u32 + ctx.r9.u32, ctx.r28.u16);
	// b 0x8b0aa0fc
	goto loc_8B0AA0FC;
loc_8B0AA0D4:
	// bl 0x8b0a6fd0
	ctx.lr = 0x8B0AA0D8;
	sub_8B0A6FD0(ctx, base);
	// lhz r10,4(r3)
	ctx.r10.u64 = REX_LOAD_U16(ctx.r3.u32 + 4);
	// lwz r9,4(r31)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r31.u32 + 4);
	// rotlwi r11,r10,3
	ctx.r11.u64 = __builtin_rotateleft32(ctx.r10.u32, 3);
	// add r8,r10,r11
	ctx.r8.u64 = ctx.r10.u64 + ctx.r11.u64;
	// rlwinm r11,r8,3,0,28
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r8.u32 | (ctx.r8.u64 << 32), 3) & 0xFFFFFFF8;
	// add r7,r11,r9
	ctx.r7.u64 = ctx.r11.u64 + ctx.r9.u64;
	// sth r28,2(r7)
	REX_STORE_U16(ctx.r7.u32 + 2, ctx.r28.u16);
	// b 0x8b0aa0fc
	goto loc_8B0AA0FC;
loc_8B0AA0F8:
	// sth r28,16(r31)
	REX_STORE_U16(ctx.r31.u32 + 16, ctx.r28.u16);
loc_8B0AA0FC:
	// mr r4,r30
	ctx.r4.u64 = ctx.r30.u64;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0a6fd0
	ctx.lr = 0x8B0AA108;
	sub_8B0A6FD0(ctx, base);
	// lhz r27,6(r3)
	ctx.r27.u64 = REX_LOAD_U16(ctx.r3.u32 + 6);
	// cmplw cr6,r29,r24
	ctx.cr6.compare<uint32_t>(ctx.r29.u32, ctx.r24.u32, ctx.xer);
	// beq cr6,0x8b0aa290
	if (ctx.cr6.eq) goto loc_8B0AA290;
	// mr r4,r25
	ctx.r4.u64 = ctx.r25.u64;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0a6fd0
	ctx.lr = 0x8B0AA120;
	sub_8B0A6FD0(ctx, base);
	// rlwinm r11,r29,3,0,28
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r29.u32 | (ctx.r29.u64 << 32), 3) & 0xFFFFFFF8;
	// lhz r10,4(r3)
	ctx.r10.u64 = REX_LOAD_U16(ctx.r3.u32 + 4);
	// mr r4,r25
	ctx.r4.u64 = ctx.r25.u64;
	// add r9,r29,r11
	ctx.r9.u64 = ctx.r29.u64 + ctx.r11.u64;
	// lwz r11,4(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 4);
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// rlwinm r29,r9,3,0,28
	ctx.r29.u64 = __builtin_rotateleft64(ctx.r9.u32 | (ctx.r9.u64 << 32), 3) & 0xFFFFFFF8;
	// add r8,r29,r11
	ctx.r8.u64 = ctx.r29.u64 + ctx.r11.u64;
	// sth r10,4(r8)
	REX_STORE_U16(ctx.r8.u32 + 4, ctx.r10.u16);
	// bl 0x8b0a6fd0
	ctx.lr = 0x8B0AA148;
	sub_8B0A6FD0(ctx, base);
	// lwz r11,4(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 4);
	// lhz r7,2(r3)
	ctx.r7.u64 = REX_LOAD_U16(ctx.r3.u32 + 2);
	// mr r4,r25
	ctx.r4.u64 = ctx.r25.u64;
	// add r6,r29,r11
	ctx.r6.u64 = ctx.r29.u64 + ctx.r11.u64;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// sth r7,2(r6)
	REX_STORE_U16(ctx.r6.u32 + 2, ctx.r7.u16);
	// bl 0x8b0a6fd0
	ctx.lr = 0x8B0AA164;
	sub_8B0A6FD0(ctx, base);
	// lhz r4,0(r3)
	ctx.r4.u64 = REX_LOAD_U16(ctx.r3.u32 + 0);
	// lwz r5,4(r31)
	ctx.r5.u64 = REX_LOAD_U32(ctx.r31.u32 + 4);
	// sthx r4,r29,r5
	REX_STORE_U16(ctx.r29.u32 + ctx.r5.u32, ctx.r4.u16);
	// lhz r3,16(r31)
	ctx.r3.u64 = REX_LOAD_U16(ctx.r31.u32 + 16);
	// cmplw cr6,r24,r3
	ctx.cr6.compare<uint32_t>(ctx.r24.u32, ctx.r3.u32, ctx.xer);
	// beq cr6,0x8b0aa1e8
	if (ctx.cr6.eq) goto loc_8B0AA1E8;
	// mr r4,r25
	ctx.r4.u64 = ctx.r25.u64;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0a7468
	ctx.lr = 0x8B0AA188;
	sub_8B0A7468(ctx, base);
	// clrlwi r11,r3,24
	ctx.r11.u64 = ctx.r3.u32 & 0xFF;
	// mr r4,r25
	ctx.r4.u64 = ctx.r25.u64;
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// beq cr6,0x8b0aa1c0
	if (ctx.cr6.eq) goto loc_8B0AA1C0;
	// bl 0x8b0a6fd0
	ctx.lr = 0x8B0AA1A0;
	sub_8B0A6FD0(ctx, base);
	// lhz r11,4(r3)
	ctx.r11.u64 = REX_LOAD_U16(ctx.r3.u32 + 4);
	// lwz r9,4(r31)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r31.u32 + 4);
	// mr r10,r11
	ctx.r10.u64 = ctx.r11.u64;
	// rotlwi r11,r11,3
	ctx.r11.u64 = __builtin_rotateleft32(ctx.r11.u32, 3);
	// add r8,r10,r11
	ctx.r8.u64 = ctx.r10.u64 + ctx.r11.u64;
	// rlwinm r7,r8,3,0,28
	ctx.r7.u64 = __builtin_rotateleft64(ctx.r8.u32 | (ctx.r8.u64 << 32), 3) & 0xFFFFFFF8;
	// sthx r30,r7,r9
	REX_STORE_U16(ctx.r7.u32 + ctx.r9.u32, ctx.r30.u16);
	// b 0x8b0aa1ec
	goto loc_8B0AA1EC;
loc_8B0AA1C0:
	// bl 0x8b0a6fd0
	ctx.lr = 0x8B0AA1C4;
	sub_8B0A6FD0(ctx, base);
	// lhz r9,4(r3)
	ctx.r9.u64 = REX_LOAD_U16(ctx.r3.u32 + 4);
	// lwz r10,4(r31)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r31.u32 + 4);
	// mr r11,r9
	ctx.r11.u64 = ctx.r9.u64;
	// rotlwi r9,r9,3
	ctx.r9.u64 = __builtin_rotateleft32(ctx.r9.u32, 3);
	// add r8,r11,r9
	ctx.r8.u64 = ctx.r11.u64 + ctx.r9.u64;
	// rlwinm r11,r8,3,0,28
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r8.u32 | (ctx.r8.u64 << 32), 3) & 0xFFFFFFF8;
	// add r7,r11,r10
	ctx.r7.u64 = ctx.r11.u64 + ctx.r10.u64;
	// sth r30,2(r7)
	REX_STORE_U16(ctx.r7.u32 + 2, ctx.r30.u16);
	// b 0x8b0aa1ec
	goto loc_8B0AA1EC;
loc_8B0AA1E8:
	// sth r30,16(r31)
	REX_STORE_U16(ctx.r31.u32 + 16, ctx.r30.u16);
loc_8B0AA1EC:
	// mr r4,r30
	ctx.r4.u64 = ctx.r30.u64;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0a6fd0
	ctx.lr = 0x8B0AA1F8;
	sub_8B0A6FD0(ctx, base);
	// lhz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U16(ctx.r3.u32 + 0);
	// cmplwi cr6,r11,65535
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 65535, ctx.xer);
	// beq cr6,0x8b0aa230
	if (ctx.cr6.eq) goto loc_8B0AA230;
	// mr r4,r30
	ctx.r4.u64 = ctx.r30.u64;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0a6fd0
	ctx.lr = 0x8B0AA210;
	sub_8B0A6FD0(ctx, base);
	// lhz r9,0(r3)
	ctx.r9.u64 = REX_LOAD_U16(ctx.r3.u32 + 0);
	// lwz r10,4(r31)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r31.u32 + 4);
	// mr r11,r9
	ctx.r11.u64 = ctx.r9.u64;
	// rotlwi r9,r9,3
	ctx.r9.u64 = __builtin_rotateleft32(ctx.r9.u32, 3);
	// add r8,r11,r9
	ctx.r8.u64 = ctx.r11.u64 + ctx.r9.u64;
	// rlwinm r11,r8,3,0,28
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r8.u32 | (ctx.r8.u64 << 32), 3) & 0xFFFFFFF8;
	// add r7,r11,r10
	ctx.r7.u64 = ctx.r11.u64 + ctx.r10.u64;
	// sth r30,4(r7)
	REX_STORE_U16(ctx.r7.u32 + 4, ctx.r30.u16);
loc_8B0AA230:
	// mr r4,r30
	ctx.r4.u64 = ctx.r30.u64;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0a6fd0
	ctx.lr = 0x8B0AA23C;
	sub_8B0A6FD0(ctx, base);
	// lhz r11,2(r3)
	ctx.r11.u64 = REX_LOAD_U16(ctx.r3.u32 + 2);
	// cmplwi cr6,r11,65535
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 65535, ctx.xer);
	// beq cr6,0x8b0aa274
	if (ctx.cr6.eq) goto loc_8B0AA274;
	// mr r4,r30
	ctx.r4.u64 = ctx.r30.u64;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0a6fd0
	ctx.lr = 0x8B0AA254;
	sub_8B0A6FD0(ctx, base);
	// lhz r9,2(r3)
	ctx.r9.u64 = REX_LOAD_U16(ctx.r3.u32 + 2);
	// lwz r10,4(r31)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r31.u32 + 4);
	// mr r11,r9
	ctx.r11.u64 = ctx.r9.u64;
	// rotlwi r9,r9,3
	ctx.r9.u64 = __builtin_rotateleft32(ctx.r9.u32, 3);
	// add r8,r11,r9
	ctx.r8.u64 = ctx.r11.u64 + ctx.r9.u64;
	// rlwinm r11,r8,3,0,28
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r8.u32 | (ctx.r8.u64 << 32), 3) & 0xFFFFFFF8;
	// add r7,r11,r10
	ctx.r7.u64 = ctx.r11.u64 + ctx.r10.u64;
	// sth r30,4(r7)
	REX_STORE_U16(ctx.r7.u32 + 4, ctx.r30.u16);
loc_8B0AA274:
	// mr r4,r25
	ctx.r4.u64 = ctx.r25.u64;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0a6fd0
	ctx.lr = 0x8B0AA280;
	sub_8B0A6FD0(ctx, base);
	// lwz r11,4(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 4);
	// lhz r10,6(r3)
	ctx.r10.u64 = REX_LOAD_U16(ctx.r3.u32 + 6);
	// add r9,r29,r11
	ctx.r9.u64 = ctx.r29.u64 + ctx.r11.u64;
	// sth r10,6(r9)
	REX_STORE_U16(ctx.r9.u32 + 6, ctx.r10.u16);
loc_8B0AA290:
	// cmplwi cr6,r26,65535
	ctx.cr6.compare<uint32_t>(ctx.r26.u32, 65535, ctx.xer);
	// beq cr6,0x8b0aa2ac
	if (ctx.cr6.eq) goto loc_8B0AA2AC;
	// cmpwi cr6,r27,1
	ctx.cr6.compare<int32_t>(ctx.r27.s32, 1, ctx.xer);
	// bne cr6,0x8b0aa2ac
	if (!ctx.cr6.eq) goto loc_8B0AA2AC;
	// mr r4,r28
	ctx.r4.u64 = ctx.r28.u64;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0a8ea8
	ctx.lr = 0x8B0AA2AC;
	sub_8B0A8EA8(ctx, base);
loc_8B0AA2AC:
	// addi r1,r1,160
	ctx.r1.s64 = ctx.r1.s64 + 160;
	// b 0x8b0cb9f8
	__restgprlr_24(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0AA8C0) {
	REX_FUNC_PROLOGUE();
	PPCRegister temp{};
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9b0
	ctx.lr = 0x8B0AA8C8;
	__savegprlr_26(ctx, base);
	// stwu r1,-672(r1)
	ea = -672 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// std r4,288(r1)
	REX_STORE_U64(ctx.r1.u32 + 288, ctx.r4.u64);
	// addi r26,r3,12
	ctx.r26.s64 = ctx.r3.s64 + 12;
	// mr r27,r3
	ctx.r27.u64 = ctx.r3.u64;
	// mr r29,r4
	ctx.r29.u64 = ctx.r4.u64;
	// addi r4,r1,288
	ctx.r4.s64 = ctx.r1.s64 + 288;
	// mr r3,r26
	ctx.r3.u64 = ctx.r26.u64;
	// mr r28,r5
	ctx.r28.u64 = ctx.r5.u64;
	// bl 0x8b0a8818
	ctx.lr = 0x8B0AA8EC;
	sub_8B0A8818(ctx, base);
	// clrlwi r11,r3,16
	ctx.r11.u64 = ctx.r3.u32 & 0xFFFF;
	// cmplwi cr6,r11,65535
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 65535, ctx.xer);
	// beq cr6,0x8b0aa914
	if (ctx.cr6.eq) goto loc_8B0AA914;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// mr r4,r29
	ctx.r4.u64 = ctx.r29.u64;
	// addi r3,r11,22320
	ctx.r3.s64 = ctx.r11.s64 + 22320;
	// bl 0x8b0df2e8
	ctx.lr = 0x8B0AA908;
	sub_8B0DF2E8(ctx, base);
	// li r3,0
	ctx.r3.s64 = 0;
	// addi r1,r1,672
	ctx.r1.s64 = ctx.r1.s64 + 672;
	// b 0x8b0cba00
	__restgprlr_26(ctx, base);
	return;
loc_8B0AA914:
	// addi r31,r28,8
	ctx.r31.s64 = ctx.r28.s64 + 8;
	// addi r3,r1,176
	ctx.r3.s64 = ctx.r1.s64 + 176;
	// mr r4,r31
	ctx.r4.u64 = ctx.r31.u64;
	// li r5,36
	ctx.r5.s64 = 36;
	// bl 0x8b0cbb30
	ctx.lr = 0x8B0AA928;
	sub_8B0CBB30(ctx, base);
	// lis r30,-29938
	ctx.r30.s64 = -1962016768;
	// addi r6,r1,80
	ctx.r6.s64 = ctx.r1.s64 + 80;
	// mr r5,r28
	ctx.r5.u64 = ctx.r28.u64;
	// mr r4,r31
	ctx.r4.u64 = ctx.r31.u64;
	// lwz r11,2364(r30)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r30.u32 + 2364);
	// lwz r3,104(r11)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r11.u32 + 104);
	// lwz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r10,124(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 124);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B0AA950;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// mr r5,r3
	ctx.r5.u64 = ctx.r3.u64;
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// beq cr6,0x8b0aa978
	if (ctx.cr6.eq) goto loc_8B0AA978;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// mr r4,r29
	ctx.r4.u64 = ctx.r29.u64;
	// addi r3,r11,22208
	ctx.r3.s64 = ctx.r11.s64 + 22208;
	// bl 0x8b0df2e8
	ctx.lr = 0x8B0AA96C;
	sub_8B0DF2E8(ctx, base);
	// li r3,0
	ctx.r3.s64 = 0;
	// addi r1,r1,672
	ctx.r1.s64 = ctx.r1.s64 + 672;
	// b 0x8b0cba00
	__restgprlr_26(ctx, base);
	return;
loc_8B0AA978:
	// lwz r11,2364(r30)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r30.u32 + 2364);
	// lwz r4,80(r1)
	ctx.r4.u64 = REX_LOAD_U32(ctx.r1.u32 + 80);
	// lwz r3,104(r11)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r11.u32 + 104);
	// lwz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r10,128(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 128);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B0AA994;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// mr r5,r3
	ctx.r5.u64 = ctx.r3.u64;
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// beq cr6,0x8b0aa9d8
	if (ctx.cr6.eq) goto loc_8B0AA9D8;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// mr r4,r29
	ctx.r4.u64 = ctx.r29.u64;
	// addi r3,r11,22096
	ctx.r3.s64 = ctx.r11.s64 + 22096;
	// bl 0x8b0df2e8
	ctx.lr = 0x8B0AA9B0;
	sub_8B0DF2E8(ctx, base);
	// lwz r11,2364(r30)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r30.u32 + 2364);
	// lwz r4,80(r1)
	ctx.r4.u64 = REX_LOAD_U32(ctx.r1.u32 + 80);
	// lwz r3,104(r11)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r11.u32 + 104);
	// lwz r10,0(r3)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r9,32(r10)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r10.u32 + 32);
	// mtctr r9
	ctx.ctr.u64 = ctx.r9.u64;
	// bctrl 
	ctx.lr = 0x8B0AA9CC;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// li r3,0
	ctx.r3.s64 = 0;
	// addi r1,r1,672
	ctx.r1.s64 = ctx.r1.s64 + 672;
	// b 0x8b0cba00
	__restgprlr_26(ctx, base);
	return;
loc_8B0AA9D8:
	// li r4,0
	ctx.r4.s64 = 0;
	// addi r3,r1,88
	ctx.r3.s64 = ctx.r1.s64 + 88;
	// bl 0x8b0c72a8
	ctx.lr = 0x8B0AA9E4;
	sub_8B0C72A8(ctx, base);
	// li r4,0
	ctx.r4.s64 = 0;
	// addi r3,r1,88
	ctx.r3.s64 = ctx.r1.s64 + 88;
	// bl 0x8b0c72d0
	ctx.lr = 0x8B0AA9F0;
	sub_8B0C72D0(ctx, base);
	// li r4,3
	ctx.r4.s64 = 3;
	// addi r3,r1,88
	ctx.r3.s64 = ctx.r1.s64 + 88;
	// bl 0x8b0c72b0
	ctx.lr = 0x8B0AA9FC;
	sub_8B0C72B0(ctx, base);
	// li r4,3
	ctx.r4.s64 = 3;
	// addi r3,r1,88
	ctx.r3.s64 = ctx.r1.s64 + 88;
	// bl 0x8b0c72b0
	ctx.lr = 0x8B0AAA08;
	sub_8B0C72B0(ctx, base);
	// addi r3,r1,88
	ctx.r3.s64 = ctx.r1.s64 + 88;
	// lwz r4,80(r1)
	ctx.r4.u64 = REX_LOAD_U32(ctx.r1.u32 + 80);
	// bl 0x8b0c72a8
	ctx.lr = 0x8B0AAA14;
	sub_8B0C72A8(ctx, base);
	// li r4,0
	ctx.r4.s64 = 0;
	// addi r3,r1,88
	ctx.r3.s64 = ctx.r1.s64 + 88;
	// bl 0x8b0c72d0
	ctx.lr = 0x8B0AAA20;
	sub_8B0C72D0(ctx, base);
	// li r3,12
	ctx.r3.s64 = 12;
	// bl 0x8b090000
	ctx.lr = 0x8B0AAA28;
	sub_8B090000(ctx, base);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0aaa50
	if (ctx.cr6.eq) goto loc_8B0AAA50;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// stw r27,4(r3)
	REX_STORE_U32(ctx.r3.u32 + 4, ctx.r27.u32);
	// li r10,0
	ctx.r10.s64 = 0;
	// addi r9,r11,21356
	ctx.r9.s64 = ctx.r11.s64 + 21356;
	// stw r10,8(r3)
	REX_STORE_U32(ctx.r3.u32 + 8, ctx.r10.u32);
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// stw r9,0(r3)
	REX_STORE_U32(ctx.r3.u32 + 0, ctx.r9.u32);
	// b 0x8b0aaa54
	goto loc_8B0AAA54;
loc_8B0AAA50:
	// li r31,0
	ctx.r31.s64 = 0;
loc_8B0AAA54:
	// lwz r11,2364(r30)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r30.u32 + 2364);
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// addi r3,r1,352
	ctx.r3.s64 = ctx.r1.s64 + 352;
	// ld r5,0(r28)
	ctx.r5.u64 = REX_LOAD_U64(ctx.r28.u32 + 0);
	// addi r4,r10,22076
	ctx.r4.s64 = ctx.r10.s64 + 22076;
	// lwz r30,76(r11)
	ctx.r30.u64 = REX_LOAD_U32(ctx.r11.u32 + 76);
	// bl 0x8b090220
	ctx.lr = 0x8B0AAA70;
	sub_8B090220(ctx, base);
	// lwz r9,0(r30)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r30.u32 + 0);
	// mr r6,r3
	ctx.r6.u64 = ctx.r3.u64;
	// mr r7,r31
	ctx.r7.u64 = ctx.r31.u64;
	// lwz r4,8(r27)
	ctx.r4.u64 = REX_LOAD_U32(ctx.r27.u32 + 8);
	// addi r5,r1,88
	ctx.r5.s64 = ctx.r1.s64 + 88;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// lwz r8,48(r9)
	ctx.r8.u64 = REX_LOAD_U32(ctx.r9.u32 + 48);
	// mtctr r8
	ctx.ctr.u64 = ctx.r8.u64;
	// bctrl 
	ctx.lr = 0x8B0AAA94;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// lwz r7,80(r1)
	ctx.r7.u64 = REX_LOAD_U32(ctx.r1.u32 + 80);
	// mr r30,r3
	ctx.r30.u64 = ctx.r3.u64;
	// addi r3,r1,124
	ctx.r3.s64 = ctx.r1.s64 + 124;
	// std r29,112(r1)
	REX_STORE_U64(ctx.r1.u32 + 112, ctx.r29.u64);
	// addi r4,r1,176
	ctx.r4.s64 = ctx.r1.s64 + 176;
	// li r5,36
	ctx.r5.s64 = 36;
	// stw r7,120(r1)
	REX_STORE_U32(ctx.r1.u32 + 120, ctx.r7.u32);
	// bl 0x8b0cbb30
	ctx.lr = 0x8B0AAAB4;
	sub_8B0CBB30(ctx, base);
	// li r11,7
	ctx.r11.s64 = 7;
	// stw r30,160(r1)
	REX_STORE_U32(ctx.r1.u32 + 160, ctx.r30.u32);
	// addi r10,r1,104
	ctx.r10.s64 = ctx.r1.s64 + 104;
	// stw r31,164(r1)
	REX_STORE_U32(ctx.r1.u32 + 164, ctx.r31.u32);
	// addi r9,r1,224
	ctx.r9.s64 = ctx.r1.s64 + 224;
	// std r29,224(r1)
	REX_STORE_U64(ctx.r1.u32 + 224, ctx.r29.u64);
	// mtctr r11
	ctx.ctr.u64 = ctx.r11.u64;
loc_8B0AAAD0:
	// ldu r11,8(r10)
	ea = 8 + ctx.r10.u32;
	ctx.r11.u64 = REX_LOAD_U64(ea);
	ctx.r10.u32 = ea;
	// stdu r11,8(r9)
	ea = 8 + ctx.r9.u32;
	REX_STORE_U64(ea, ctx.r11.u64);
	ctx.r9.u32 = ea;
	// bdnz 0x8b0aaad0
	--ctx.ctr.u64;
	if (ctx.ctr.u32 != 0) goto loc_8B0AAAD0;
	// addi r4,r1,224
	ctx.r4.s64 = ctx.r1.s64 + 224;
	// mr r3,r26
	ctx.r3.u64 = ctx.r26.u64;
	// bl 0x8b0aa680
	ctx.lr = 0x8B0AAAE8;
	sub_8B0AA680(ctx, base);
	// lbz r11,0(r28)
	ctx.r11.u64 = REX_LOAD_U8(ctx.r28.u32 + 0);
	// rlwinm r11,r11,0,0,26
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 0) & 0xFFFFFFE0;
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// beq cr6,0x8b0aab0c
	if (ctx.cr6.eq) goto loc_8B0AAB0C;
	// cmplwi cr6,r11,64
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 64, ctx.xer);
	// beq cr6,0x8b0aab0c
	if (ctx.cr6.eq) goto loc_8B0AAB0C;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// addi r31,r11,22064
	ctx.r31.s64 = ctx.r11.s64 + 22064;
	// b 0x8b0aab14
	goto loc_8B0AAB14;
loc_8B0AAB0C:
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// addi r31,r11,22060
	ctx.r31.s64 = ctx.r11.s64 + 22060;
loc_8B0AAB14:
	// li r4,1
	ctx.r4.s64 = 1;
	// addi r3,r1,88
	ctx.r3.s64 = ctx.r1.s64 + 88;
	// bl 0x8b0c7198
	ctx.lr = 0x8B0AAB20;
	sub_8B0C7198(ctx, base);
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// mr r6,r3
	ctx.r6.u64 = ctx.r3.u64;
	// ld r5,0(r28)
	ctx.r5.u64 = REX_LOAD_U64(ctx.r28.u32 + 0);
	// addi r3,r11,21928
	ctx.r3.s64 = ctx.r11.s64 + 21928;
	// mr r4,r29
	ctx.r4.u64 = ctx.r29.u64;
	// mr r7,r30
	ctx.r7.u64 = ctx.r30.u64;
	// mr r8,r31
	ctx.r8.u64 = ctx.r31.u64;
	// bl 0x8b0df298
	ctx.lr = 0x8B0AAB40;
	sub_8B0DF298(ctx, base);
	// lis r10,-29938
	ctx.r10.s64 = -1962016768;
	// lwz r8,0(r30)
	ctx.r8.u64 = REX_LOAD_U32(ctx.r30.u32 + 0);
	// li r5,0
	ctx.r5.s64 = 0;
	// addi r9,r10,19676
	ctx.r9.s64 = ctx.r10.s64 + 19676;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// lwz r7,128(r8)
	ctx.r7.u64 = REX_LOAD_U32(ctx.r8.u32 + 128);
	// lwz r11,28(r9)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r9.u32 + 28);
	// mtctr r7
	ctx.ctr.u64 = ctx.r7.u64;
	// lfs f1,44(r11)
	ctx.fpscr.disableFlushMode();
	temp.u32 = REX_LOAD_U32(ctx.r11.u32 + 44);
	ctx.f1.f64 = double(temp.f32);
	// bctrl 
	ctx.lr = 0x8B0AAB68;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// li r3,1
	ctx.r3.s64 = 1;
	// addi r1,r1,672
	ctx.r1.s64 = ctx.r1.s64 + 672;
	// b 0x8b0cba00
	__restgprlr_26(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0AB5A0) {
	REX_FUNC_PROLOGUE();
	// lis r11,-29938
	ctx.r11.s64 = -1962016768;
	// li r5,0
	ctx.r5.s64 = 0;
	// li r4,0
	ctx.r4.s64 = 0;
	// lwz r3,5512(r11)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r11.u32 + 5512);
	// lwz r10,0(r3)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r9,20(r10)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r10.u32 + 20);
	// mtctr r9
	ctx.ctr.u64 = ctx.r9.u64;
	// bctr 
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	return;
}

DEFINE_REX_FUNC(sub_8B0AB5C0) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9a4
	ctx.lr = 0x8B0AB5C8;
	__savegprlr_23(ctx, base);
	// stwu r1,-432(r1)
	ea = -432 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lis r11,-29936
	ctx.r11.s64 = -1961885696;
	// mr r23,r4
	ctx.r23.u64 = ctx.r4.u64;
	// lwz r3,-17796(r11)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r11.u32 + -17796);
	// lwz r10,0(r3)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r9,36(r10)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r10.u32 + 36);
	// mtctr r9
	ctx.ctr.u64 = ctx.r9.u64;
	// bctrl 
	ctx.lr = 0x8B0AB5E8;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0ab6f0
	if (ctx.cr6.eq) goto loc_8B0AB6F0;
	// lwz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r10,4(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 4);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B0AB600;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// li r30,0
	ctx.r30.s64 = 0;
	// addi r5,r1,80
	ctx.r5.s64 = ctx.r1.s64 + 80;
	// mr r4,r23
	ctx.r4.u64 = ctx.r23.u64;
	// stw r30,80(r1)
	REX_STORE_U32(ctx.r1.u32 + 80, ctx.r30.u32);
	// bl 0x8b091540
	ctx.lr = 0x8B0AB614;
	sub_8B091540(ctx, base);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0ab6f0
	if (ctx.cr6.eq) goto loc_8B0AB6F0;
	// lwz r24,80(r1)
	ctx.r24.u64 = REX_LOAD_U32(ctx.r1.u32 + 80);
	// cmplwi cr6,r24,0
	ctx.cr6.compare<uint32_t>(ctx.r24.u32, 0, ctx.xer);
	// beq cr6,0x8b0ab6f0
	if (ctx.cr6.eq) goto loc_8B0AB6F0;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// addi r27,r11,1791
	ctx.r27.s64 = ctx.r11.s64 + 1791;
	// addi r26,r10,2776
	ctx.r26.s64 = ctx.r10.s64 + 2776;
	// mr r5,r27
	ctx.r5.u64 = ctx.r27.u64;
	// mr r4,r26
	ctx.r4.u64 = ctx.r26.u64;
	// bl 0x8b0c1588
	ctx.lr = 0x8B0AB644;
	sub_8B0C1588(ctx, base);
	// li r4,40
	ctx.r4.s64 = 40;
	// bl 0x8b0ccee0
	ctx.lr = 0x8B0AB64C;
	sub_8B0CCEE0(ctx, base);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0ab6f0
	if (ctx.cr6.eq) goto loc_8B0AB6F0;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// li r5,0
	ctx.r5.s64 = 0;
	// addi r4,r11,3592
	ctx.r4.s64 = ctx.r11.s64 + 3592;
	// mr r3,r24
	ctx.r3.u64 = ctx.r24.u64;
	// bl 0x8b0bfc38
	ctx.lr = 0x8B0AB668;
	sub_8B0BFC38(ctx, base);
	// mr r25,r3
	ctx.r25.u64 = ctx.r3.u64;
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// ble cr6,0x8b0ab6f0
	if (!ctx.cr6.gt) goto loc_8B0AB6F0;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// addi r28,r11,3616
	ctx.r28.s64 = ctx.r11.s64 + 3616;
	// addi r29,r10,3604
	ctx.r29.s64 = ctx.r10.s64 + 3604;
loc_8B0AB684:
	// mr r4,r29
	ctx.r4.u64 = ctx.r29.u64;
	// mr r5,r30
	ctx.r5.u64 = ctx.r30.u64;
	// addi r3,r1,96
	ctx.r3.s64 = ctx.r1.s64 + 96;
	// bl 0x8b090220
	ctx.lr = 0x8B0AB694;
	sub_8B090220(ctx, base);
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// li r5,0
	ctx.r5.s64 = 0;
	// mr r3,r24
	ctx.r3.u64 = ctx.r24.u64;
	// bl 0x8b0bfa88
	ctx.lr = 0x8B0AB6A4;
	sub_8B0BFA88(ctx, base);
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0ab6e4
	if (ctx.cr6.eq) goto loc_8B0AB6E4;
	// mr r5,r27
	ctx.r5.u64 = ctx.r27.u64;
	// mr r4,r26
	ctx.r4.u64 = ctx.r26.u64;
	// bl 0x8b0c1588
	ctx.lr = 0x8B0AB6BC;
	sub_8B0C1588(ctx, base);
	// li r4,40
	ctx.r4.s64 = 40;
	// bl 0x8b0ccee0
	ctx.lr = 0x8B0AB6C4;
	sub_8B0CCEE0(ctx, base);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// bne cr6,0x8b0ab6e4
	if (!ctx.cr6.eq) goto loc_8B0AB6E4;
	// mr r4,r28
	ctx.r4.u64 = ctx.r28.u64;
	// li r5,0
	ctx.r5.s64 = 0;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0bfd30
	ctx.lr = 0x8B0AB6DC;
	sub_8B0BFD30(ctx, base);
	// cmpldi cr6,r3,0
	ctx.cr6.compare<uint64_t>(ctx.r3.u64, 0, ctx.xer);
	// bne cr6,0x8b0ab6f4
	if (!ctx.cr6.eq) goto loc_8B0AB6F4;
loc_8B0AB6E4:
	// addi r30,r30,1
	ctx.r30.s64 = ctx.r30.s64 + 1;
	// cmpw cr6,r30,r25
	ctx.cr6.compare<int32_t>(ctx.r30.s32, ctx.r25.s32, ctx.xer);
	// blt cr6,0x8b0ab684
	if (ctx.cr6.lt) goto loc_8B0AB684;
loc_8B0AB6F0:
	// mr r3,r23
	ctx.r3.u64 = ctx.r23.u64;
loc_8B0AB6F4:
	// addi r1,r1,432
	ctx.r1.s64 = ctx.r1.s64 + 432;
	// b 0x8b0cb9f4
	__restgprlr_23(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0AB898) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// std r30,-24(r1)
	REX_STORE_U64(ctx.r1.u32 + -24, ctx.r30.u64);
	// std r31,-16(r1)
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.r31.u64);
	// stwu r1,-112(r1)
	ea = -112 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// mr r30,r4
	ctx.r30.u64 = ctx.r4.u64;
	// bl 0x8b0ab700
	ctx.lr = 0x8B0AB8B8;
	sub_8B0AB700(ctx, base);
	// clrlwi r11,r3,24
	ctx.r11.u64 = ctx.r3.u32 & 0xFF;
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// beq cr6,0x8b0ab8cc
	if (ctx.cr6.eq) goto loc_8B0AB8CC;
	// li r3,0
	ctx.r3.s64 = 0;
	// b 0x8b0ab8f0
	goto loc_8B0AB8F0;
loc_8B0AB8CC:
	// lwz r11,0(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 0);
	// mr r4,r30
	ctx.r4.u64 = ctx.r30.u64;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// lwz r10,8(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 8);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B0AB8E4;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// clrlwi r9,r3,24
	ctx.r9.u64 = ctx.r3.u32 & 0xFF;
	// cntlzw r8,r9
	ctx.r8.u64 = ctx.r9.u32 == 0 ? 32 : __builtin_clz(ctx.r9.u32);
	// rlwinm r3,r8,27,31,31
	ctx.r3.u64 = __builtin_rotateleft64(ctx.r8.u32 | (ctx.r8.u64 << 32), 27) & 0x1;
loc_8B0AB8F0:
	// addi r1,r1,112
	ctx.r1.s64 = ctx.r1.s64 + 112;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// ld r30,-24(r1)
	ctx.r30.u64 = REX_LOAD_U64(ctx.r1.u32 + -24);
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0AB908) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9b0
	ctx.lr = 0x8B0AB910;
	__savegprlr_26(ctx, base);
	// stwu r1,-144(r1)
	ea = -144 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// mr r26,r3
	ctx.r26.u64 = ctx.r3.u64;
	// bl 0x8b0ab5c0
	ctx.lr = 0x8B0AB91C;
	sub_8B0AB5C0(ctx, base);
	// mr r27,r3
	ctx.r27.u64 = ctx.r3.u64;
	// bl 0x8b099380
	ctx.lr = 0x8B0AB924;
	sub_8B099380(ctx, base);
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// bge cr6,0x8b0aba10
	if (!ctx.cr6.lt) goto loc_8B0ABA10;
	// li r28,0
	ctx.r28.s64 = 0;
	// lis r29,-29938
	ctx.r29.s64 = -1962016768;
	// mr r31,r28
	ctx.r31.u64 = ctx.r28.u64;
loc_8B0AB938:
	// bl 0x8b0df2c8
	ctx.lr = 0x8B0AB93C;
	sub_8B0DF2C8(ctx, base);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0ab974
	if (ctx.cr6.eq) goto loc_8B0AB974;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0df358
	ctx.lr = 0x8B0AB94C;
	sub_8B0DF358(ctx, base);
	// mr r30,r3
	ctx.r30.u64 = ctx.r3.u64;
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// blt cr6,0x8b0ab974
	if (ctx.cr6.lt) goto loc_8B0AB974;
	// bl 0x8b0df2c8
	ctx.lr = 0x8B0AB95C;
	sub_8B0DF2C8(ctx, base);
	// cmpw cr6,r30,r3
	ctx.cr6.compare<int32_t>(ctx.r30.s32, ctx.r3.s32, ctx.xer);
	// bge cr6,0x8b0ab974
	if (!ctx.cr6.lt) goto loc_8B0AB974;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// bl 0x8b0df2d8
	ctx.lr = 0x8B0AB96C;
	sub_8B0DF2D8(ctx, base);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// bne cr6,0x8b0ab9b0
	if (!ctx.cr6.eq) goto loc_8B0AB9B0;
loc_8B0AB974:
	// stw r28,80(r1)
	REX_STORE_U32(ctx.r1.u32 + 80, ctx.r28.u32);
	// addi r6,r1,80
	ctx.r6.s64 = ctx.r1.s64 + 80;
	// lwz r11,2364(r29)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r29.u32 + 2364);
	// mr r5,r27
	ctx.r5.u64 = ctx.r27.u64;
	// mr r4,r31
	ctx.r4.u64 = ctx.r31.u64;
	// lwz r3,104(r11)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r11.u32 + 104);
	// lwz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r10,144(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 144);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B0AB99C;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// bne cr6,0x8b0ab9b0
	if (!ctx.cr6.eq) goto loc_8B0AB9B0;
	// lwz r11,80(r1)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r1.u32 + 80);
	// cmpwi cr6,r11,0
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// bne cr6,0x8b0ab9f8
	if (!ctx.cr6.eq) goto loc_8B0AB9F8;
loc_8B0AB9B0:
	// addi r31,r31,1
	ctx.r31.s64 = ctx.r31.s64 + 1;
	// cmplwi cr6,r31,4
	ctx.cr6.compare<uint32_t>(ctx.r31.u32, 4, ctx.xer);
	// blt cr6,0x8b0ab938
	if (ctx.cr6.lt) goto loc_8B0AB938;
	// lwz r9,16(r26)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r26.u32 + 16);
	// mr r10,r28
	ctx.r10.u64 = ctx.r28.u64;
	// cmpwi cr6,r9,0
	ctx.cr6.compare<int32_t>(ctx.r9.s32, 0, ctx.xer);
	// ble cr6,0x8b0aba10
	if (!ctx.cr6.gt) goto loc_8B0ABA10;
	// lwz r11,4(r26)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r26.u32 + 4);
loc_8B0AB9D0:
	// ld r8,0(r11)
	ctx.r8.u64 = REX_LOAD_U64(ctx.r11.u32 + 0);
	// cmpld cr6,r8,r27
	ctx.cr6.compare<uint64_t>(ctx.r8.u64, ctx.r27.u64, ctx.xer);
	// beq cr6,0x8b0aba04
	if (ctx.cr6.eq) goto loc_8B0ABA04;
	// addi r10,r10,1
	ctx.r10.s64 = ctx.r10.s64 + 1;
	// addi r11,r11,8
	ctx.r11.s64 = ctx.r11.s64 + 8;
	// cmpw cr6,r10,r9
	ctx.cr6.compare<int32_t>(ctx.r10.s32, ctx.r9.s32, ctx.xer);
	// blt cr6,0x8b0ab9d0
	if (ctx.cr6.lt) goto loc_8B0AB9D0;
	// li r3,0
	ctx.r3.s64 = 0;
	// addi r1,r1,144
	ctx.r1.s64 = ctx.r1.s64 + 144;
	// b 0x8b0cba00
	__restgprlr_26(ctx, base);
	return;
loc_8B0AB9F8:
	// li r3,1
	ctx.r3.s64 = 1;
	// addi r1,r1,144
	ctx.r1.s64 = ctx.r1.s64 + 144;
	// b 0x8b0cba00
	__restgprlr_26(ctx, base);
	return;
loc_8B0ABA04:
	// cmpwi cr6,r10,-1
	ctx.cr6.compare<int32_t>(ctx.r10.s32, -1, ctx.xer);
	// li r3,1
	ctx.r3.s64 = 1;
	// bne cr6,0x8b0aba14
	if (!ctx.cr6.eq) goto loc_8B0ABA14;
loc_8B0ABA10:
	// li r3,0
	ctx.r3.s64 = 0;
loc_8B0ABA14:
	// addi r1,r1,144
	ctx.r1.s64 = ctx.r1.s64 + 144;
	// b 0x8b0cba00
	__restgprlr_26(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0ABED0) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9ac
	ctx.lr = 0x8B0ABED8;
	__savegprlr_25(ctx, base);
	// stwu r1,-160(r1)
	ea = -160 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// mr r27,r3
	ctx.r27.u64 = ctx.r3.u64;
	// lwz r3,12(r3)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r3.u32 + 12);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0abff4
	if (ctx.cr6.eq) goto loc_8B0ABFF4;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// li r5,0
	ctx.r5.s64 = 0;
	// addi r4,r11,24128
	ctx.r4.s64 = ctx.r11.s64 + 24128;
	// bl 0x8b0bfa88
	ctx.lr = 0x8B0ABEFC;
	sub_8B0BFA88(ctx, base);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0abff4
	if (ctx.cr6.eq) goto loc_8B0ABFF4;
	// bl 0x8b0bf2b8
	ctx.lr = 0x8B0ABF08;
	sub_8B0BF2B8(ctx, base);
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0abff4
	if (ctx.cr6.eq) goto loc_8B0ABFF4;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// lis r9,-29944
	ctx.r9.s64 = -1962409984;
	// addi r29,r11,24056
	ctx.r29.s64 = ctx.r11.s64 + 24056;
	// addi r28,r10,23984
	ctx.r28.s64 = ctx.r10.s64 + 23984;
	// addi r30,r9,1791
	ctx.r30.s64 = ctx.r9.s64 + 1791;
loc_8B0ABF2C:
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0beee8
	ctx.lr = 0x8B0ABF34;
	sub_8B0BEEE8(ctx, base);
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// addi r3,r1,80
	ctx.r3.s64 = ctx.r1.s64 + 80;
	// li r5,1
	ctx.r5.s64 = 1;
	// bl 0x8b0c6f90
	ctx.lr = 0x8B0ABF44;
	sub_8B0C6F90(ctx, base);
	// addi r3,r1,80
	ctx.r3.s64 = ctx.r1.s64 + 80;
	// bl 0x8b0c69f8
	ctx.lr = 0x8B0ABF4C;
	sub_8B0C69F8(ctx, base);
	// clrlwi r11,r3,24
	ctx.r11.u64 = ctx.r3.u32 & 0xFF;
	// mr r5,r30
	ctx.r5.u64 = ctx.r30.u64;
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// li r4,0
	ctx.r4.s64 = 0;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bne cr6,0x8b0abf88
	if (!ctx.cr6.eq) goto loc_8B0ABF88;
	// bl 0x8b0c1588
	ctx.lr = 0x8B0ABF68;
	sub_8B0C1588(ctx, base);
	// mr r26,r3
	ctx.r26.u64 = ctx.r3.u64;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0beee8
	ctx.lr = 0x8B0ABF74;
	sub_8B0BEEE8(ctx, base);
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// mr r3,r28
	ctx.r3.u64 = ctx.r28.u64;
	// mr r5,r26
	ctx.r5.u64 = ctx.r26.u64;
	// bl 0x8b0df2e8
	ctx.lr = 0x8B0ABF84;
	sub_8B0DF2E8(ctx, base);
	// b 0x8b0abfe0
	goto loc_8B0ABFE0;
loc_8B0ABF88:
	// lwz r11,84(r1)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r1.u32 + 84);
	// lwz r26,36(r11)
	ctx.r26.u64 = REX_LOAD_U32(ctx.r11.u32 + 36);
	// bl 0x8b0c1588
	ctx.lr = 0x8B0ABF94;
	sub_8B0C1588(ctx, base);
	// mr r25,r3
	ctx.r25.u64 = ctx.r3.u64;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0beee8
	ctx.lr = 0x8B0ABFA0;
	sub_8B0BEEE8(ctx, base);
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// mr r3,r29
	ctx.r3.u64 = ctx.r29.u64;
	// mr r5,r26
	ctx.r5.u64 = ctx.r26.u64;
	// mr r6,r25
	ctx.r6.u64 = ctx.r25.u64;
	// bl 0x8b0df298
	ctx.lr = 0x8B0ABFB4;
	sub_8B0DF298(ctx, base);
	// mr r5,r30
	ctx.r5.u64 = ctx.r30.u64;
	// li r4,0
	ctx.r4.s64 = 0;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0c1588
	ctx.lr = 0x8B0ABFC4;
	sub_8B0C1588(ctx, base);
	// lwz r11,80(r1)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r1.u32 + 80);
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// mr r3,r11
	ctx.r3.u64 = ctx.r11.u64;
	// lwz r10,0(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 0);
	// lwz r9,12(r10)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r10.u32 + 12);
	// mtctr r9
	ctx.ctr.u64 = ctx.r9.u64;
	// bctrl 
	ctx.lr = 0x8B0ABFE0;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
loc_8B0ABFE0:
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0bf2f0
	ctx.lr = 0x8B0ABFE8;
	sub_8B0BF2F0(ctx, base);
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// bne cr6,0x8b0abf2c
	if (!ctx.cr6.eq) goto loc_8B0ABF2C;
loc_8B0ABFF4:
	// li r3,36
	ctx.r3.s64 = 36;
	// bl 0x8b0bf448
	ctx.lr = 0x8B0ABFFC;
	sub_8B0BF448(ctx, base);
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0ac040
	if (ctx.cr6.eq) goto loc_8B0AC040;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lwz r3,12(r27)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r27.u32 + 12);
	// li r5,0
	ctx.r5.s64 = 0;
	// addi r30,r11,2768
	ctx.r30.s64 = ctx.r11.s64 + 2768;
	// mr r4,r30
	ctx.r4.u64 = ctx.r30.u64;
	// bl 0x8b0bfc38
	ctx.lr = 0x8B0AC020;
	sub_8B0BFC38(ctx, base);
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// mr r6,r3
	ctx.r6.u64 = ctx.r3.u64;
	// mr r5,r30
	ctx.r5.u64 = ctx.r30.u64;
	// addi r4,r10,23960
	ctx.r4.s64 = ctx.r10.s64 + 23960;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0c1390
	ctx.lr = 0x8B0AC038;
	sub_8B0C1390(ctx, base);
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// b 0x8b0ac044
	goto loc_8B0AC044;
loc_8B0AC040:
	// li r31,0
	ctx.r31.s64 = 0;
loc_8B0AC044:
	// lis r11,-29936
	ctx.r11.s64 = -1961885696;
	// lwz r3,-17796(r11)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r11.u32 + -17796);
	// lwz r10,0(r3)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r9,28(r10)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r10.u32 + 28);
	// mtctr r9
	ctx.ctr.u64 = ctx.r9.u64;
	// bctrl 
	ctx.lr = 0x8B0AC05C;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// lwz r8,0(r3)
	ctx.r8.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// mr r4,r31
	ctx.r4.u64 = ctx.r31.u64;
	// lwz r7,8(r8)
	ctx.r7.u64 = REX_LOAD_U32(ctx.r8.u32 + 8);
	// mtctr r7
	ctx.ctr.u64 = ctx.r7.u64;
	// bctrl 
	ctx.lr = 0x8B0AC070;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// addi r1,r1,160
	ctx.r1.s64 = ctx.r1.s64 + 160;
	// b 0x8b0cb9fc
	__restgprlr_25(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0AC3D0) {
	REX_FUNC_PROLOGUE();
	PPCRegister temp{};
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9b4
	ctx.lr = 0x8B0AC3D8;
	__savegprlr_27(ctx, base);
	// stwu r1,-160(r1)
	ea = -160 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lwz r11,16(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 16);
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// mr r27,r4
	ctx.r27.u64 = ctx.r4.u64;
	// cmpwi cr6,r11,20
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 20, ctx.xer);
	// blt cr6,0x8b0ac54c
	if (ctx.cr6.lt) goto loc_8B0AC54C;
	// bl 0x8b0ac368
	ctx.lr = 0x8B0AC3F4;
	sub_8B0AC368(ctx, base);
	// mr r28,r3
	ctx.r28.u64 = ctx.r3.u64;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0ac368
	ctx.lr = 0x8B0AC400;
	sub_8B0AC368(ctx, base);
	// xoris r30,r3,52755
	ctx.r30.u64 = ctx.r3.u64 ^ 3457351680;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// xori r30,r30,24312
	ctx.r30.u64 = ctx.r30.u64 ^ 24312;
	// bl 0x8b0ac368
	ctx.lr = 0x8B0AC410;
	sub_8B0AC368(ctx, base);
	// xoris r29,r3,32421
	ctx.r29.u64 = ctx.r3.u64 ^ 2124742656;
	// cmpwi cr6,r28,0
	ctx.cr6.compare<int32_t>(ctx.r28.s32, 0, ctx.xer);
	// xori r29,r29,23472
	ctx.r29.u64 = ctx.r29.u64 ^ 23472;
	// blt cr6,0x8b0ac54c
	if (ctx.cr6.lt) goto loc_8B0AC54C;
	// addi r11,r28,7
	ctx.r11.s64 = ctx.r28.s64 + 7;
	// lwz r10,12(r31)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r31.u32 + 12);
	// lwz r9,16(r31)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r31.u32 + 16);
	// srawi r8,r11,3
	ctx.xer.ca = (ctx.r11.s32 < 0) & ((ctx.r11.u32 & 0x7) != 0);
	ctx.r8.s64 = ctx.r11.s32 >> 3;
	// addze r11,r8
	temp.s64 = ctx.r8.s64 + ctx.xer.ca;
	ctx.xer.ca = temp.u32 < ctx.r8.u32;
	ctx.r11.s64 = temp.s64;
	// add r11,r11,r10
	ctx.r11.u64 = ctx.r11.u64 + ctx.r10.u64;
	// addi r7,r11,8
	ctx.r7.s64 = ctx.r11.s64 + 8;
	// cmpw cr6,r7,r9
	ctx.cr6.compare<int32_t>(ctx.r7.s32, ctx.r9.s32, ctx.xer);
	// bgt cr6,0x8b0ac54c
	if (ctx.cr6.gt) goto loc_8B0AC54C;
	// li r4,1
	ctx.r4.s64 = 1;
	// addi r3,r1,96
	ctx.r3.s64 = ctx.r1.s64 + 96;
	// bl 0x8b0be130
	ctx.lr = 0x8B0AC450;
	sub_8B0BE130(ctx, base);
	// li r10,7
	ctx.r10.s64 = 7;
	// addi r11,r1,80
	ctx.r11.s64 = ctx.r1.s64 + 80;
	// li r9,0
	ctx.r9.s64 = 0;
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
loc_8B0AC460:
	// stbu r9,1(r11)
	ea = 1 + ctx.r11.u32;
	REX_STORE_U8(ea, ctx.r9.u8);
	ctx.r11.u32 = ea;
	// bdnz 0x8b0ac460
	--ctx.ctr.u64;
	if (ctx.ctr.u32 != 0) goto loc_8B0AC460;
	// stw r30,80(r1)
	REX_STORE_U32(ctx.r1.u32 + 80, ctx.r30.u32);
	// addi r4,r1,80
	ctx.r4.s64 = ctx.r1.s64 + 80;
	// stw r29,84(r1)
	REX_STORE_U32(ctx.r1.u32 + 84, ctx.r29.u32);
	// addi r3,r1,96
	ctx.r3.s64 = ctx.r1.s64 + 96;
	// bl 0x8b0be720
	ctx.lr = 0x8B0AC47C;
	sub_8B0BE720(ctx, base);
	// addi r4,r28,16
	ctx.r4.s64 = ctx.r28.s64 + 16;
	// mr r3,r27
	ctx.r3.u64 = ctx.r27.u64;
	// bl 0x8b0c8148
	ctx.lr = 0x8B0AC488;
	sub_8B0C8148(ctx, base);
	// lwz r9,32(r31)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r31.u32 + 32);
	// lwz r11,12(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 12);
	// cmpwi cr6,r28,0
	ctx.cr6.compare<int32_t>(ctx.r28.s32, 0, ctx.xer);
	// lwz r7,16(r27)
	ctx.r7.u64 = REX_LOAD_U32(ctx.r27.u32 + 16);
	// lwz r6,32(r27)
	ctx.r6.u64 = REX_LOAD_U32(ctx.r27.u32 + 32);
	// subf r11,r9,r11
	ctx.r11.u64 = ctx.r11.u64 - ctx.r9.u64;
	// lwz r10,0(r31)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r31.u32 + 0);
	// lwz r8,0(r27)
	ctx.r8.u64 = REX_LOAD_U32(ctx.r27.u32 + 0);
	// subf r9,r6,r7
	ctx.r9.u64 = ctx.r7.u64 - ctx.r6.u64;
	// add r29,r11,r10
	ctx.r29.u64 = ctx.r11.u64 + ctx.r10.u64;
	// add r31,r9,r8
	ctx.r31.u64 = ctx.r9.u64 + ctx.r8.u64;
	// ble cr6,0x8b0ac4e4
	if (!ctx.cr6.gt) goto loc_8B0AC4E4;
	// addi r11,r28,-1
	ctx.r11.s64 = ctx.r28.s64 + -1;
	// rlwinm r11,r11,29,3,31
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 29) & 0x1FFFFFFF;
	// addi r30,r11,1
	ctx.r30.s64 = ctx.r11.s64 + 1;
loc_8B0AC4C4:
	// mr r5,r31
	ctx.r5.u64 = ctx.r31.u64;
	// mr r4,r29
	ctx.r4.u64 = ctx.r29.u64;
	// addi r3,r1,96
	ctx.r3.s64 = ctx.r1.s64 + 96;
	// bl 0x8b0be3e8
	ctx.lr = 0x8B0AC4D4;
	sub_8B0BE3E8(ctx, base);
	// addic. r30,r30,-1
	ctx.xer.ca = ctx.r30.u32 > 0;
	ctx.r30.s64 = ctx.r30.s64 + -1;
	ctx.cr0.compare<int32_t>(ctx.r30.s32, 0, ctx.xer);
	// addi r31,r31,8
	ctx.r31.s64 = ctx.r31.s64 + 8;
	// addi r29,r29,8
	ctx.r29.s64 = ctx.r29.s64 + 8;
	// bne 0x8b0ac4c4
	if (!ctx.cr0.eq) goto loc_8B0AC4C4;
loc_8B0AC4E4:
	// li r10,7
	ctx.r10.s64 = 7;
	// li r9,0
	ctx.r9.s64 = 0;
	// addi r11,r1,88
	ctx.r11.s64 = ctx.r1.s64 + 88;
	// stb r9,88(r1)
	REX_STORE_U8(ctx.r1.u32 + 88, ctx.r9.u8);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
loc_8B0AC4F8:
	// stbu r9,1(r11)
	ea = 1 + ctx.r11.u32;
	REX_STORE_U8(ea, ctx.r9.u8);
	ctx.r11.u32 = ea;
	// bdnz 0x8b0ac4f8
	--ctx.ctr.u64;
	if (ctx.ctr.u32 != 0) goto loc_8B0AC4F8;
	// addi r5,r1,88
	ctx.r5.s64 = ctx.r1.s64 + 88;
	// mr r4,r29
	ctx.r4.u64 = ctx.r29.u64;
	// addi r3,r1,96
	ctx.r3.s64 = ctx.r1.s64 + 96;
	// bl 0x8b0be3e8
	ctx.lr = 0x8B0AC510;
	sub_8B0BE3E8(ctx, base);
	// addi r11,r1,88
	ctx.r11.s64 = ctx.r1.s64 + 88;
	// addi r10,r1,80
	ctx.r10.s64 = ctx.r1.s64 + 80;
	// addi r8,r11,8
	ctx.r8.s64 = ctx.r11.s64 + 8;
loc_8B0AC51C:
	// lbz r9,0(r11)
	ctx.r9.u64 = REX_LOAD_U8(ctx.r11.u32 + 0);
	// lbz r7,0(r10)
	ctx.r7.u64 = REX_LOAD_U8(ctx.r10.u32 + 0);
	// subf. r9,r7,r9
	ctx.r9.u64 = ctx.r9.u64 - ctx.r7.u64;
	ctx.cr0.compare<int32_t>(ctx.r9.s32, 0, ctx.xer);
	// bne 0x8b0ac53c
	if (!ctx.cr0.eq) goto loc_8B0AC53C;
	// addi r11,r11,1
	ctx.r11.s64 = ctx.r11.s64 + 1;
	// addi r10,r10,1
	ctx.r10.s64 = ctx.r10.s64 + 1;
	// cmpw cr6,r11,r8
	ctx.cr6.compare<int32_t>(ctx.r11.s32, ctx.r8.s32, ctx.xer);
	// bne cr6,0x8b0ac51c
	if (!ctx.cr6.eq) goto loc_8B0AC51C;
loc_8B0AC53C:
	// cmpwi cr6,r9,0
	ctx.cr6.compare<int32_t>(ctx.r9.s32, 0, ctx.xer);
	// beq cr6,0x8b0ac558
	if (ctx.cr6.eq) goto loc_8B0AC558;
	// addi r3,r1,96
	ctx.r3.s64 = ctx.r1.s64 + 96;
	// bl 0x8b0be1d0
	ctx.lr = 0x8B0AC54C;
	sub_8B0BE1D0(ctx, base);
loc_8B0AC54C:
	// li r3,0
	ctx.r3.s64 = 0;
	// addi r1,r1,160
	ctx.r1.s64 = ctx.r1.s64 + 160;
	// b 0x8b0cba04
	__restgprlr_27(ctx, base);
	return;
loc_8B0AC558:
	// mr r5,r28
	ctx.r5.u64 = ctx.r28.u64;
	// li r4,0
	ctx.r4.s64 = 0;
	// mr r3,r27
	ctx.r3.u64 = ctx.r27.u64;
	// bl 0x8b0c86a8
	ctx.lr = 0x8B0AC568;
	sub_8B0C86A8(ctx, base);
	// addi r3,r1,96
	ctx.r3.s64 = ctx.r1.s64 + 96;
	// bl 0x8b0be1d0
	ctx.lr = 0x8B0AC570;
	sub_8B0BE1D0(ctx, base);
	// li r3,1
	ctx.r3.s64 = 1;
	// addi r1,r1,160
	ctx.r1.s64 = ctx.r1.s64 + 160;
	// b 0x8b0cba04
	__restgprlr_27(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0ACB78) {
	REX_FUNC_PROLOGUE();
	PPCRegister temp{};
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9b4
	ctx.lr = 0x8B0ACB80;
	__savegprlr_27(ctx, base);
	// stfd f30,-64(r1)
	ctx.fpscr.disableFlushMode();
	REX_STORE_U64(ctx.r1.u32 + -64, ctx.f30.u64);
	// stfd f31,-56(r1)
	REX_STORE_U64(ctx.r1.u32 + -56, ctx.f31.u64);
	// stwu r1,-144(r1)
	ea = -144 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lis r10,-29938
	ctx.r10.s64 = -1962016768;
	// lis r11,-29938
	ctx.r11.s64 = -1962016768;
	// mr r30,r3
	ctx.r30.u64 = ctx.r3.u64;
	// addi r28,r11,19816
	ctx.r28.s64 = ctx.r11.s64 + 19816;
	// lwz r11,19824(r10)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r10.u32 + 19824);
	// clrlwi r9,r11,31
	ctx.r9.u64 = ctx.r11.u32 & 0x1;
	// cmplwi cr6,r9,0
	ctx.cr6.compare<uint32_t>(ctx.r9.u32, 0, ctx.xer);
	// bne cr6,0x8b0acbc4
	if (!ctx.cr6.eq) goto loc_8B0ACBC4;
	// ori r11,r11,1
	ctx.r11.u64 = ctx.r11.u64 | 1;
	// lis r9,-29944
	ctx.r9.s64 = -1962409984;
	// stw r11,19824(r10)
	REX_STORE_U32(ctx.r10.u32 + 19824, ctx.r11.u32);
	// mr r3,r28
	ctx.r3.u64 = ctx.r28.u64;
	// addi r4,r9,24672
	ctx.r4.s64 = ctx.r9.s64 + 24672;
	// bl 0x8b0c6f58
	ctx.lr = 0x8B0ACBC4;
	sub_8B0C6F58(ctx, base);
loc_8B0ACBC4:
	// li r29,0
	ctx.r29.s64 = 0;
	// bl 0x8b0df2c8
	ctx.lr = 0x8B0ACBCC;
	sub_8B0DF2C8(ctx, base);
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// ble cr6,0x8b0acc88
	if (!ctx.cr6.gt) goto loc_8B0ACC88;
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// addi r27,r11,2768
	ctx.r27.s64 = ctx.r11.s64 + 2768;
	// lfd f31,24664(r10)
	ctx.fpscr.disableFlushMode();
	ctx.f31.u64 = REX_LOAD_U64(ctx.r10.u32 + 24664);
loc_8B0ACBE4:
	// mr r3,r29
	ctx.r3.u64 = ctx.r29.u64;
	// bl 0x8b0df2b8
	ctx.lr = 0x8B0ACBEC;
	sub_8B0DF2B8(ctx, base);
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// blt cr6,0x8b0acc50
	if (ctx.cr6.lt) goto loc_8B0ACC50;
	// cmpwi cr6,r3,4
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 4, ctx.xer);
	// bge cr6,0x8b0acc50
	if (!ctx.cr6.lt) goto loc_8B0ACC50;
	// add r11,r3,r30
	ctx.r11.u64 = ctx.r3.u64 + ctx.r30.u64;
	// lbz r10,24(r11)
	ctx.r10.u64 = REX_LOAD_U8(ctx.r11.u32 + 24);
	// cmplwi cr6,r10,0
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 0, ctx.xer);
	// beq cr6,0x8b0acc50
	if (ctx.cr6.eq) goto loc_8B0ACC50;
	// lwz r11,12(r30)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r30.u32 + 12);
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// beq cr6,0x8b0acc50
	if (ctx.cr6.eq) goto loc_8B0ACC50;
	// lwz r11,4(r28)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r28.u32 + 4);
	// lfs f30,44(r11)
	ctx.fpscr.disableFlushMode();
	temp.u32 = REX_LOAD_U32(ctx.r11.u32 + 44);
	ctx.f30.f64 = double(temp.f32);
	// bl 0x8b0df2f8
	ctx.lr = 0x8B0ACC28;
	sub_8B0DF2F8(ctx, base);
	// fsub f0,f1,f30
	ctx.fpscr.disableFlushMode();
	ctx.f0.f64 = ctx.f1.f64 - ctx.f30.f64;
	// fcmpu cr6,f0,f31
	ctx.cr6.compare(ctx.f0.f64, ctx.f31.f64);
	// ble cr6,0x8b0acc50
	if (!ctx.cr6.gt) goto loc_8B0ACC50;
	// mr r4,r27
	ctx.r4.u64 = ctx.r27.u64;
	// lwz r3,12(r30)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r30.u32 + 12);
	// li r5,0
	ctx.r5.s64 = 0;
	// bl 0x8b0bfc38
	ctx.lr = 0x8B0ACC44;
	sub_8B0BFC38(ctx, base);
	// lwz r11,28(r30)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r30.u32 + 28);
	// cmpw cr6,r3,r11
	ctx.cr6.compare<int32_t>(ctx.r3.s32, ctx.r11.s32, ctx.xer);
	// bgt cr6,0x8b0acc70
	if (ctx.cr6.gt) goto loc_8B0ACC70;
loc_8B0ACC50:
	// addi r29,r29,1
	ctx.r29.s64 = ctx.r29.s64 + 1;
	// bl 0x8b0df2c8
	ctx.lr = 0x8B0ACC58;
	sub_8B0DF2C8(ctx, base);
	// cmpw cr6,r29,r3
	ctx.cr6.compare<int32_t>(ctx.r29.s32, ctx.r3.s32, ctx.xer);
	// blt cr6,0x8b0acbe4
	if (ctx.cr6.lt) goto loc_8B0ACBE4;
	// addi r1,r1,144
	ctx.r1.s64 = ctx.r1.s64 + 144;
	// lfd f30,-64(r1)
	ctx.fpscr.disableFlushMode();
	ctx.f30.u64 = REX_LOAD_U64(ctx.r1.u32 + -64);
	// lfd f31,-56(r1)
	ctx.f31.u64 = REX_LOAD_U64(ctx.r1.u32 + -56);
	// b 0x8b0cba04
	__restgprlr_27(ctx, base);
	return;
loc_8B0ACC70:
	// add r11,r31,r30
	ctx.r11.u64 = ctx.r31.u64 + ctx.r30.u64;
	// li r10,0
	ctx.r10.s64 = 0;
	// mr r4,r31
	ctx.r4.u64 = ctx.r31.u64;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// stb r10,24(r11)
	REX_STORE_U8(ctx.r11.u32 + 24, ctx.r10.u8);
	// bl 0x8b0aca00
	ctx.lr = 0x8B0ACC88;
	sub_8B0ACA00(ctx, base);
loc_8B0ACC88:
	// addi r1,r1,144
	ctx.r1.s64 = ctx.r1.s64 + 144;
	// lfd f30,-64(r1)
	ctx.fpscr.disableFlushMode();
	ctx.f30.u64 = REX_LOAD_U64(ctx.r1.u32 + -64);
	// lfd f31,-56(r1)
	ctx.f31.u64 = REX_LOAD_U64(ctx.r1.u32 + -56);
	// b 0x8b0cba04
	__restgprlr_27(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0AD6B0) {
	REX_FUNC_PROLOGUE();
	// lwz r3,28(r3)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r3.u32 + 28);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0AD6B8) {
	REX_FUNC_PROLOGUE();
	// cmpwi cr6,r4,0
	ctx.cr6.compare<int32_t>(ctx.r4.s32, 0, ctx.xer);
	// blt cr6,0x8b0ad6d0
	if (ctx.cr6.lt) goto loc_8B0AD6D0;
	// lwz r11,28(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 28);
	// cmpw cr6,r4,r11
	ctx.cr6.compare<int32_t>(ctx.r4.s32, ctx.r11.s32, ctx.xer);
	// li r11,1
	ctx.r11.s64 = 1;
	// blt cr6,0x8b0ad6d4
	if (ctx.cr6.lt) goto loc_8B0AD6D4;
loc_8B0AD6D0:
	// li r11,0
	ctx.r11.s64 = 0;
loc_8B0AD6D4:
	// clrlwi r11,r11,24
	ctx.r11.u64 = ctx.r11.u32 & 0xFF;
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// beq cr6,0x8b0ad6f0
	if (ctx.cr6.eq) goto loc_8B0AD6F0;
	// lwz r11,16(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 16);
	// rlwinm r10,r4,2,0,29
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r4.u32 | (ctx.r4.u64 << 32), 2) & 0xFFFFFFFC;
	// lwzx r3,r10,r11
	ctx.r3.u64 = REX_LOAD_U32(ctx.r10.u32 + ctx.r11.u32);
	// blr 
	return;
loc_8B0AD6F0:
	// li r3,0
	ctx.r3.s64 = 0;
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0AD6F8) {
	REX_FUNC_PROLOGUE();
	// mr r5,r4
	ctx.r5.u64 = ctx.r4.u64;
	// addi r4,r3,16
	ctx.r4.s64 = ctx.r3.s64 + 16;
	// b 0x8b0b8728
	sub_8B0B8728(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0AD708) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9b8
	ctx.lr = 0x8B0AD710;
	__savegprlr_28(ctx, base);
	// stwu r1,-128(r1)
	ea = -128 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lwz r11,28(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 28);
	// mr r28,r3
	ctx.r28.u64 = ctx.r3.u64;
	// li r29,0
	ctx.r29.s64 = 0;
	// cmpwi cr6,r11,0
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// ble cr6,0x8b0ad798
	if (!ctx.cr6.gt) goto loc_8B0AD798;
	// addi r30,r3,16
	ctx.r30.s64 = ctx.r3.s64 + 16;
	// li r31,0
	ctx.r31.s64 = 0;
loc_8B0AD730:
	// lwz r11,0(r30)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r30.u32 + 0);
	// lwzx r11,r11,r31
	ctx.r11.u64 = REX_LOAD_U32(ctx.r11.u32 + ctx.r31.u32);
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// beq cr6,0x8b0ad74c
	if (ctx.cr6.eq) goto loc_8B0AD74C;
	// lbz r11,4(r11)
	ctx.r11.u64 = REX_LOAD_U8(ctx.r11.u32 + 4);
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// beq cr6,0x8b0ad784
	if (ctx.cr6.eq) goto loc_8B0AD784;
loc_8B0AD74C:
	// lwz r11,12(r30)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r30.u32 + 12);
	// subf r10,r29,r11
	ctx.r10.u64 = ctx.r11.u64 - ctx.r29.u64;
	// addic. r11,r10,-1
	ctx.xer.ca = ctx.r10.u32 > 0;
	ctx.r11.s64 = ctx.r10.s64 + -1;
	ctx.cr0.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// ble 0x8b0ad770
	if (!ctx.cr0.gt) goto loc_8B0AD770;
	// lwz r10,0(r30)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r30.u32 + 0);
	// rlwinm r5,r11,2,0,29
	ctx.r5.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 2) & 0xFFFFFFFC;
	// add r3,r10,r31
	ctx.r3.u64 = ctx.r10.u64 + ctx.r31.u64;
	// addi r4,r3,4
	ctx.r4.s64 = ctx.r3.s64 + 4;
	// bl 0x8b0cc060
	ctx.lr = 0x8B0AD770;
	sub_8B0CC060(ctx, base);
loc_8B0AD770:
	// lwz r11,12(r30)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r30.u32 + 12);
	// addi r29,r29,-1
	ctx.r29.s64 = ctx.r29.s64 + -1;
	// addi r31,r31,-4
	ctx.r31.s64 = ctx.r31.s64 + -4;
	// addi r11,r11,-1
	ctx.r11.s64 = ctx.r11.s64 + -1;
	// stw r11,12(r30)
	REX_STORE_U32(ctx.r30.u32 + 12, ctx.r11.u32);
loc_8B0AD784:
	// lwz r11,28(r28)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r28.u32 + 28);
	// addi r29,r29,1
	ctx.r29.s64 = ctx.r29.s64 + 1;
	// addi r31,r31,4
	ctx.r31.s64 = ctx.r31.s64 + 4;
	// cmpw cr6,r29,r11
	ctx.cr6.compare<int32_t>(ctx.r29.s32, ctx.r11.s32, ctx.xer);
	// blt cr6,0x8b0ad730
	if (ctx.cr6.lt) goto loc_8B0AD730;
loc_8B0AD798:
	// addi r1,r1,128
	ctx.r1.s64 = ctx.r1.s64 + 128;
	// b 0x8b0cba08
	__restgprlr_28(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0AD848) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9b4
	ctx.lr = 0x8B0AD850;
	__savegprlr_27(ctx, base);
	// stwu r1,-128(r1)
	ea = -128 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// addi r9,r11,25716
	ctx.r9.s64 = ctx.r11.s64 + 25716;
	// addi r8,r10,25708
	ctx.r8.s64 = ctx.r10.s64 + 25708;
	// stw r9,0(r3)
	REX_STORE_U32(ctx.r3.u32 + 0, ctx.r9.u32);
	// addi r30,r3,16
	ctx.r30.s64 = ctx.r3.s64 + 16;
	// stw r8,4(r3)
	REX_STORE_U32(ctx.r3.u32 + 4, ctx.r8.u32);
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// bl 0x8b0ad7a0
	ctx.lr = 0x8B0AD87C;
	sub_8B0AD7A0(ctx, base);
	// addi r29,r31,32
	ctx.r29.s64 = ctx.r31.s64 + 32;
	// mr r3,r29
	ctx.r3.u64 = ctx.r29.u64;
	// bl 0x8b0ad7a0
	ctx.lr = 0x8B0AD888;
	sub_8B0AD7A0(ctx, base);
	// li r27,0
	ctx.r27.s64 = 0;
	// addi r28,r31,64
	ctx.r28.s64 = ctx.r31.s64 + 64;
	// stw r27,76(r31)
	REX_STORE_U32(ctx.r31.u32 + 76, ctx.r27.u32);
	// mr r3,r28
	ctx.r3.u64 = ctx.r28.u64;
	// bl 0x8b0906a8
	ctx.lr = 0x8B0AD89C;
	sub_8B0906A8(ctx, base);
	// mr r3,r28
	ctx.r3.u64 = ctx.r28.u64;
	// bl 0x8b0906a8
	ctx.lr = 0x8B0AD8A4;
	sub_8B0906A8(ctx, base);
	// stw r27,44(r31)
	REX_STORE_U32(ctx.r31.u32 + 44, ctx.r27.u32);
	// mr r3,r29
	ctx.r3.u64 = ctx.r29.u64;
	// bl 0x8b0906a8
	ctx.lr = 0x8B0AD8B0;
	sub_8B0906A8(ctx, base);
	// mr r3,r29
	ctx.r3.u64 = ctx.r29.u64;
	// bl 0x8b0906a8
	ctx.lr = 0x8B0AD8B8;
	sub_8B0906A8(ctx, base);
	// stw r27,28(r31)
	REX_STORE_U32(ctx.r31.u32 + 28, ctx.r27.u32);
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// bl 0x8b0906a8
	ctx.lr = 0x8B0AD8C4;
	sub_8B0906A8(ctx, base);
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// bl 0x8b0906a8
	ctx.lr = 0x8B0AD8CC;
	sub_8B0906A8(ctx, base);
	// addi r1,r1,128
	ctx.r1.s64 = ctx.r1.s64 + 128;
	// b 0x8b0cba04
	__restgprlr_27(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0ADA30) {
	REX_FUNC_PROLOGUE();
	PPCRegister temp{};
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// std r31,-16(r1)
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.r31.u64);
	// stwu r1,-96(r1)
	ea = -96 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// stb r4,8(r3)
	REX_STORE_U8(ctx.r3.u32 + 8, ctx.r4.u8);
	// clrlwi r10,r4,24
	ctx.r10.u64 = ctx.r4.u32 & 0xFF;
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// cmplwi cr6,r10,0
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 0, ctx.xer);
	// lfs f0,8492(r11)
	ctx.fpscr.disableFlushMode();
	temp.u32 = REX_LOAD_U32(ctx.r11.u32 + 8492);
	ctx.f0.f64 = double(temp.f32);
	// stfs f0,12(r3)
	temp.f32 = float(ctx.f0.f64);
	REX_STORE_U32(ctx.r3.u32 + 12, temp.u32);
	// bne cr6,0x8b0ada78
	if (!ctx.cr6.eq) goto loc_8B0ADA78;
	// addi r3,r3,16
	ctx.r3.s64 = ctx.r3.s64 + 16;
	// bl 0x8b0ad7a0
	ctx.lr = 0x8B0ADA68;
	sub_8B0AD7A0(ctx, base);
	// addi r3,r31,32
	ctx.r3.s64 = ctx.r31.s64 + 32;
	// bl 0x8b0ad7a0
	ctx.lr = 0x8B0ADA70;
	sub_8B0AD7A0(ctx, base);
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0ad8d8
	ctx.lr = 0x8B0ADA78;
	sub_8B0AD8D8(ctx, base);
loc_8B0ADA78:
	// addi r1,r1,96
	ctx.r1.s64 = ctx.r1.s64 + 96;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0ADAE0) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// std r30,-24(r1)
	REX_STORE_U64(ctx.r1.u32 + -24, ctx.r30.u64);
	// std r31,-16(r1)
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.r31.u64);
	// stwu r1,-112(r1)
	ea = -112 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// mr r31,r4
	ctx.r31.u64 = ctx.r4.u64;
	// addi r4,r11,26392
	ctx.r4.s64 = ctx.r11.s64 + 26392;
	// addi r3,r10,4952
	ctx.r3.s64 = ctx.r10.s64 + 4952;
	// li r5,0
	ctx.r5.s64 = 0;
	// bl 0x8b0c0c70
	ctx.lr = 0x8B0ADB10;
	sub_8B0C0C70(ctx, base);
	// lis r9,-29938
	ctx.r9.s64 = -1962016768;
	// mr r30,r3
	ctx.r30.u64 = ctx.r3.u64;
	// lwz r3,3036(r9)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r9.u32 + 3036);
	// lwz r8,0(r3)
	ctx.r8.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r7,64(r8)
	ctx.r7.u64 = REX_LOAD_U32(ctx.r8.u32 + 64);
	// mtctr r7
	ctx.ctr.u64 = ctx.r7.u64;
	// bctrl 
	ctx.lr = 0x8B0ADB2C;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// lwz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lis r5,-29944
	ctx.r5.s64 = -1962409984;
	// mr r6,r31
	ctx.r6.u64 = ctx.r31.u64;
	// mr r4,r30
	ctx.r4.u64 = ctx.r30.u64;
	// addi r5,r5,4944
	ctx.r5.s64 = ctx.r5.s64 + 4944;
	// lwz r10,4(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 4);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B0ADB4C;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// bl 0x8b0991a8
	ctx.lr = 0x8B0ADB50;
	sub_8B0991A8(ctx, base);
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// bl 0x8b0bf328
	ctx.lr = 0x8B0ADB5C;
	sub_8B0BF328(ctx, base);
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// li r5,3
	ctx.r5.s64 = 3;
	// mr r4,r31
	ctx.r4.u64 = ctx.r31.u64;
	// bl 0x8b0c0668
	ctx.lr = 0x8B0ADB6C;
	sub_8B0C0668(ctx, base);
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// addi r1,r1,112
	ctx.r1.s64 = ctx.r1.s64 + 112;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// ld r30,-24(r1)
	ctx.r30.u64 = REX_LOAD_U64(ctx.r1.u32 + -24);
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0ADF78) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9bc
	ctx.lr = 0x8B0ADF80;
	__savegprlr_29(ctx, base);
	// stwu r1,-112(r1)
	ea = -112 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// mr r29,r4
	ctx.r29.u64 = ctx.r4.u64;
	// mr r31,r5
	ctx.r31.u64 = ctx.r5.u64;
	// addi r4,r11,26392
	ctx.r4.s64 = ctx.r11.s64 + 26392;
	// addi r3,r10,4952
	ctx.r3.s64 = ctx.r10.s64 + 4952;
	// li r5,0
	ctx.r5.s64 = 0;
	// bl 0x8b0c0c70
	ctx.lr = 0x8B0ADFA4;
	sub_8B0C0C70(ctx, base);
	// lis r9,-29938
	ctx.r9.s64 = -1962016768;
	// mr r30,r3
	ctx.r30.u64 = ctx.r3.u64;
	// lwz r3,3036(r9)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r9.u32 + 3036);
	// lwz r8,0(r3)
	ctx.r8.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r7,64(r8)
	ctx.r7.u64 = REX_LOAD_U32(ctx.r8.u32 + 64);
	// mtctr r7
	ctx.ctr.u64 = ctx.r7.u64;
	// bctrl 
	ctx.lr = 0x8B0ADFC0;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// lwz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lis r5,-29944
	ctx.r5.s64 = -1962409984;
	// mr r6,r29
	ctx.r6.u64 = ctx.r29.u64;
	// mr r4,r30
	ctx.r4.u64 = ctx.r30.u64;
	// addi r5,r5,26836
	ctx.r5.s64 = ctx.r5.s64 + 26836;
	// lwz r10,4(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 4);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B0ADFE0;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// li r5,3
	ctx.r5.s64 = 3;
	// mr r4,r29
	ctx.r4.u64 = ctx.r29.u64;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// bl 0x8b0c0668
	ctx.lr = 0x8B0ADFF0;
	sub_8B0C0668(ctx, base);
	// lis r9,-29938
	ctx.r9.s64 = -1962016768;
	// lwz r11,2364(r9)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r9.u32 + 2364);
	// lwz r3,76(r11)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r11.u32 + 76);
	// lwz r8,0(r3)
	ctx.r8.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r7,20(r8)
	ctx.r7.u64 = REX_LOAD_U32(ctx.r8.u32 + 20);
	// mtctr r7
	ctx.ctr.u64 = ctx.r7.u64;
	// bctrl 
	ctx.lr = 0x8B0AE00C;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// lbz r6,21(r31)
	ctx.r6.u64 = REX_LOAD_U8(ctx.r31.u32 + 21);
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// mr r5,r3
	ctx.r5.u64 = ctx.r3.u64;
	// clrlwi r4,r6,31
	ctx.r4.u64 = ctx.r6.u32 & 0x1;
	// addi r29,r11,1788
	ctx.r29.s64 = ctx.r11.s64 + 1788;
	// cmplwi cr6,r4,0
	ctx.cr6.compare<uint32_t>(ctx.r4.u32, 0, ctx.xer);
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bne cr6,0x8b0ae038
	if (!ctx.cr6.eq) goto loc_8B0AE038;
	// mr r4,r5
	ctx.r4.u64 = ctx.r5.u64;
	// bl 0x8b0ac2c0
	ctx.lr = 0x8B0AE034;
	sub_8B0AC2C0(ctx, base);
	// b 0x8b0ae040
	goto loc_8B0AE040;
loc_8B0AE038:
	// mr r4,r29
	ctx.r4.u64 = ctx.r29.u64;
	// bl 0x8b0c8b60
	ctx.lr = 0x8B0AE040;
	sub_8B0C8B60(ctx, base);
loc_8B0AE040:
	// lbz r11,21(r31)
	ctx.r11.u64 = REX_LOAD_U8(ctx.r31.u32 + 21);
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// clrlwi r10,r11,31
	ctx.r10.u64 = ctx.r11.u32 & 0x1;
	// cmplwi cr6,r10,0
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 0, ctx.xer);
	// bne cr6,0x8b0ae060
	if (!ctx.cr6.eq) goto loc_8B0AE060;
	// li r4,0
	ctx.r4.s64 = 0;
	// bl 0x8b0ac2c0
	ctx.lr = 0x8B0AE05C;
	sub_8B0AC2C0(ctx, base);
	// b 0x8b0ae06c
	goto loc_8B0AE06C;
loc_8B0AE060:
	// mr r4,r29
	ctx.r4.u64 = ctx.r29.u64;
	// li r5,0
	ctx.r5.s64 = 0;
	// bl 0x8b0c8b60
	ctx.lr = 0x8B0AE06C;
	sub_8B0C8B60(ctx, base);
loc_8B0AE06C:
	// mr r4,r31
	ctx.r4.u64 = ctx.r31.u64;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// bl 0x8b0c2960
	ctx.lr = 0x8B0AE078;
	sub_8B0C2960(ctx, base);
	// lbz r11,21(r31)
	ctx.r11.u64 = REX_LOAD_U8(ctx.r31.u32 + 21);
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// clrlwi r10,r11,31
	ctx.r10.u64 = ctx.r11.u32 & 0x1;
	// cmplwi cr6,r10,0
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 0, ctx.xer);
	// bne cr6,0x8b0ae098
	if (!ctx.cr6.eq) goto loc_8B0AE098;
	// li r4,0
	ctx.r4.s64 = 0;
	// bl 0x8b0ac2c0
	ctx.lr = 0x8B0AE094;
	sub_8B0AC2C0(ctx, base);
	// b 0x8b0ae0a4
	goto loc_8B0AE0A4;
loc_8B0AE098:
	// mr r4,r29
	ctx.r4.u64 = ctx.r29.u64;
	// li r5,0
	ctx.r5.s64 = 0;
	// bl 0x8b0c8b60
	ctx.lr = 0x8B0AE0A4;
	sub_8B0C8B60(ctx, base);
loc_8B0AE0A4:
	// cmplwi cr6,r30,0
	ctx.cr6.compare<uint32_t>(ctx.r30.u32, 0, ctx.xer);
	// beq cr6,0x8b0ae0b4
	if (ctx.cr6.eq) goto loc_8B0AE0B4;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// bl 0x8b0c04f0
	ctx.lr = 0x8B0AE0B4;
	sub_8B0C04F0(ctx, base);
loc_8B0AE0B4:
	// addi r1,r1,112
	ctx.r1.s64 = ctx.r1.s64 + 112;
	// b 0x8b0cba0c
	__restgprlr_29(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0AE2B8) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// std r30,-24(r1)
	REX_STORE_U64(ctx.r1.u32 + -24, ctx.r30.u64);
	// std r31,-16(r1)
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.r31.u64);
	// stwu r1,-112(r1)
	ea = -112 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// mr r30,r4
	ctx.r30.u64 = ctx.r4.u64;
	// lwz r4,24(r3)
	ctx.r4.u64 = REX_LOAD_U32(ctx.r3.u32 + 24);
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// cmpwi cr6,r4,2
	ctx.cr6.compare<int32_t>(ctx.r4.s32, 2, ctx.xer);
	// bge cr6,0x8b0ae2f0
	if (!ctx.cr6.lt) goto loc_8B0AE2F0;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// addi r3,r11,26896
	ctx.r3.s64 = ctx.r11.s64 + 26896;
	// bl 0x8b0df2a8
	ctx.lr = 0x8B0AE2EC;
	sub_8B0DF2A8(ctx, base);
	// b 0x8b0ae34c
	goto loc_8B0AE34C;
loc_8B0AE2F0:
	// lis r11,-29938
	ctx.r11.s64 = -1962016768;
	// lwz r3,3036(r11)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r11.u32 + 3036);
	// lwz r10,0(r3)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r9,64(r10)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r10.u32 + 64);
	// mtctr r9
	ctx.ctr.u64 = ctx.r9.u64;
	// bctrl 
	ctx.lr = 0x8B0AE308;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// lwz r8,0(r3)
	ctx.r8.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// mr r5,r30
	ctx.r5.u64 = ctx.r30.u64;
	// lwz r4,8(r31)
	ctx.r4.u64 = REX_LOAD_U32(ctx.r31.u32 + 8);
	// lwz r7,28(r8)
	ctx.r7.u64 = REX_LOAD_U32(ctx.r8.u32 + 28);
	// mtctr r7
	ctx.ctr.u64 = ctx.r7.u64;
	// bctrl 
	ctx.lr = 0x8B0AE320;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// li r5,0
	ctx.r5.s64 = 0;
	// lwz r3,8(r31)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r31.u32 + 8);
	// mr r4,r30
	ctx.r4.u64 = ctx.r30.u64;
	// bl 0x8b0c0668
	ctx.lr = 0x8B0AE330;
	sub_8B0C0668(ctx, base);
	// lwz r3,28(r31)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r31.u32 + 28);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0ae344
	if (ctx.cr6.eq) goto loc_8B0AE344;
	// mr r4,r30
	ctx.r4.u64 = ctx.r30.u64;
	// bl 0x8b0a3c98
	ctx.lr = 0x8B0AE344;
	sub_8B0A3C98(ctx, base);
loc_8B0AE344:
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// bl 0x8b098140
	ctx.lr = 0x8B0AE34C;
	sub_8B098140(ctx, base);
loc_8B0AE34C:
	// addi r1,r1,112
	ctx.r1.s64 = ctx.r1.s64 + 112;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// ld r30,-24(r1)
	ctx.r30.u64 = REX_LOAD_U64(ctx.r1.u32 + -24);
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0AE4E8) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// std r30,-24(r1)
	REX_STORE_U64(ctx.r1.u32 + -24, ctx.r30.u64);
	// std r31,-16(r1)
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.r31.u64);
	// stwu r1,-112(r1)
	ea = -112 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// lwz r3,32(r3)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r3.u32 + 32);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0ae524
	if (ctx.cr6.eq) goto loc_8B0AE524;
	// lwz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r10,12(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 12);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B0AE51C;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// li r9,0
	ctx.r9.s64 = 0;
	// stw r9,32(r31)
	REX_STORE_U32(ctx.r31.u32 + 32, ctx.r9.u32);
loc_8B0AE524:
	// li r11,2
	ctx.r11.s64 = 2;
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// stw r11,24(r31)
	REX_STORE_U32(ctx.r31.u32 + 24, ctx.r11.u32);
	// lis r9,-29944
	ctx.r9.s64 = -1962409984;
	// addi r4,r10,27016
	ctx.r4.s64 = ctx.r10.s64 + 27016;
	// addi r3,r9,4056
	ctx.r3.s64 = ctx.r9.s64 + 4056;
	// li r5,0
	ctx.r5.s64 = 0;
	// bl 0x8b0c0c70
	ctx.lr = 0x8B0AE544;
	sub_8B0C0C70(ctx, base);
	// lwz r8,0(r31)
	ctx.r8.u64 = REX_LOAD_U32(ctx.r31.u32 + 0);
	// mr r30,r3
	ctx.r30.u64 = ctx.r3.u64;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// mr r4,r30
	ctx.r4.u64 = ctx.r30.u64;
	// lwz r7,8(r8)
	ctx.r7.u64 = REX_LOAD_U32(ctx.r8.u32 + 8);
	// mtctr r7
	ctx.ctr.u64 = ctx.r7.u64;
	// bctrl 
	ctx.lr = 0x8B0AE560;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// cmplwi cr6,r30,0
	ctx.cr6.compare<uint32_t>(ctx.r30.u32, 0, ctx.xer);
	// beq cr6,0x8b0ae570
	if (ctx.cr6.eq) goto loc_8B0AE570;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// bl 0x8b0c04f0
	ctx.lr = 0x8B0AE570;
	sub_8B0C04F0(ctx, base);
loc_8B0AE570:
	// addi r1,r1,112
	ctx.r1.s64 = ctx.r1.s64 + 112;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// ld r30,-24(r1)
	ctx.r30.u64 = REX_LOAD_U64(ctx.r1.u32 + -24);
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0AEA08) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9b8
	ctx.lr = 0x8B0AEA10;
	__savegprlr_28(ctx, base);
	// stwu r1,-256(r1)
	ea = -256 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// li r11,7
	ctx.r11.s64 = 7;
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// stw r11,24(r3)
	REX_STORE_U32(ctx.r3.u32 + 24, ctx.r11.u32);
	// lis r9,-29944
	ctx.r9.s64 = -1962409984;
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// addi r4,r10,27480
	ctx.r4.s64 = ctx.r10.s64 + 27480;
	// addi r3,r9,4056
	ctx.r3.s64 = ctx.r9.s64 + 4056;
	// li r5,0
	ctx.r5.s64 = 0;
	// bl 0x8b0c0c70
	ctx.lr = 0x8B0AEA38;
	sub_8B0C0C70(ctx, base);
	// lis r8,-29944
	ctx.r8.s64 = -1962409984;
	// li r5,0
	ctx.r5.s64 = 0;
	// addi r4,r8,27464
	ctx.r4.s64 = ctx.r8.s64 + 27464;
	// mr r28,r3
	ctx.r28.u64 = ctx.r3.u64;
	// bl 0x8b0bfa88
	ctx.lr = 0x8B0AEA4C;
	sub_8B0BFA88(ctx, base);
	// mr r30,r3
	ctx.r30.u64 = ctx.r3.u64;
	// lwz r3,28(r31)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r31.u32 + 28);
	// bl 0x8b0a0ee0
	ctx.lr = 0x8B0AEA58;
	sub_8B0A0EE0(ctx, base);
	// lis r7,-29938
	ctx.r7.s64 = -1962016768;
	// mr r29,r3
	ctx.r29.u64 = ctx.r3.u64;
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// lwz r11,2364(r7)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r7.u32 + 2364);
	// lwz r3,76(r11)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r11.u32 + 76);
	// lwz r6,0(r3)
	ctx.r6.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r5,32(r6)
	ctx.r5.u64 = REX_LOAD_U32(ctx.r6.u32 + 32);
	// mtctr r5
	ctx.ctr.u64 = ctx.r5.u64;
	// bctrl 
	ctx.lr = 0x8B0AEA7C;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// lis r4,-29944
	ctx.r4.s64 = -1962409984;
	// mr r5,r29
	ctx.r5.u64 = ctx.r29.u64;
	// addi r4,r4,27448
	ctx.r4.s64 = ctx.r4.s64 + 27448;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// bl 0x8b0c0190
	ctx.lr = 0x8B0AEA90;
	sub_8B0C0190(ctx, base);
	// lwz r3,36(r31)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r31.u32 + 36);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0aeab0
	if (ctx.cr6.eq) goto loc_8B0AEAB0;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// li r5,1
	ctx.r5.s64 = 1;
	// addi r4,r11,3832
	ctx.r4.s64 = ctx.r11.s64 + 3832;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// bl 0x8b0c0148
	ctx.lr = 0x8B0AEAB0;
	sub_8B0C0148(ctx, base);
loc_8B0AEAB0:
	// lwz r3,36(r31)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r31.u32 + 36);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0aeb20
	if (ctx.cr6.eq) goto loc_8B0AEB20;
	// bl 0x8b0b91d0
	ctx.lr = 0x8B0AEAC0;
	sub_8B0B91D0(ctx, base);
	// lis r11,-29938
	ctx.r11.s64 = -1962016768;
	// lis r10,-29938
	ctx.r10.s64 = -1962016768;
	// addi r5,r11,2964
	ctx.r5.s64 = ctx.r11.s64 + 2964;
	// addi r6,r10,4764
	ctx.r6.s64 = ctx.r10.s64 + 4764;
	// li r4,0
	ctx.r4.s64 = 0;
	// li r7,0
	ctx.r7.s64 = 0;
	// bl 0x8b0ccd08
	ctx.lr = 0x8B0AEADC;
	sub_8B0CCD08(ctx, base);
	// mr r29,r3
	ctx.r29.u64 = ctx.r3.u64;
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0aeb20
	if (ctx.cr6.eq) goto loc_8B0AEB20;
	// li r11,0
	ctx.r11.s64 = 0;
	// li r5,120
	ctx.r5.s64 = 120;
	// li r4,0
	ctx.r4.s64 = 0;
	// stb r11,80(r1)
	REX_STORE_U8(ctx.r1.u32 + 80, ctx.r11.u8);
	// addi r3,r1,81
	ctx.r3.s64 = ctx.r1.s64 + 81;
	// bl 0x8b0cb8e0
	ctx.lr = 0x8B0AEB00;
	sub_8B0CB8E0(ctx, base);
	// addi r4,r1,80
	ctx.r4.s64 = ctx.r1.s64 + 80;
	// mr r3,r29
	ctx.r3.u64 = ctx.r29.u64;
	// bl 0x8b0a0660
	ctx.lr = 0x8B0AEB0C;
	sub_8B0A0660(ctx, base);
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// addi r5,r1,80
	ctx.r5.s64 = ctx.r1.s64 + 80;
	// addi r4,r10,13248
	ctx.r4.s64 = ctx.r10.s64 + 13248;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// bl 0x8b0c0010
	ctx.lr = 0x8B0AEB20;
	sub_8B0C0010(ctx, base);
loc_8B0AEB20:
	// lwz r11,0(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 0);
	// mr r4,r28
	ctx.r4.u64 = ctx.r28.u64;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// lwz r10,8(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 8);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B0AEB38;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// li r5,0
	ctx.r5.s64 = 0;
	// lwz r3,28(r31)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r31.u32 + 28);
	// li r4,1
	ctx.r4.s64 = 1;
	// bl 0x8b0a0610
	ctx.lr = 0x8B0AEB48;
	sub_8B0A0610(ctx, base);
	// lwz r3,36(r31)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r31.u32 + 36);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0aeb64
	if (ctx.cr6.eq) goto loc_8B0AEB64;
	// lwz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r10,16(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 16);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B0AEB64;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
loc_8B0AEB64:
	// cmplwi cr6,r28,0
	ctx.cr6.compare<uint32_t>(ctx.r28.u32, 0, ctx.xer);
	// beq cr6,0x8b0aeb74
	if (ctx.cr6.eq) goto loc_8B0AEB74;
	// mr r3,r28
	ctx.r3.u64 = ctx.r28.u64;
	// bl 0x8b0c04f0
	ctx.lr = 0x8B0AEB74;
	sub_8B0C04F0(ctx, base);
loc_8B0AEB74:
	// addi r1,r1,256
	ctx.r1.s64 = ctx.r1.s64 + 256;
	// b 0x8b0cba08
	__restgprlr_28(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0AEFD8) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9bc
	ctx.lr = 0x8B0AEFE0;
	__savegprlr_29(ctx, base);
	// stwu r1,-128(r1)
	ea = -128 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lwz r4,24(r3)
	ctx.r4.u64 = REX_LOAD_U32(ctx.r3.u32 + 24);
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// addi r3,r11,27864
	ctx.r3.s64 = ctx.r11.s64 + 27864;
	// bl 0x8b0df298
	ctx.lr = 0x8B0AEFF8;
	sub_8B0DF298(ctx, base);
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// addi r3,r10,27848
	ctx.r3.s64 = ctx.r10.s64 + 27848;
	// bl 0x8b0df298
	ctx.lr = 0x8B0AF004;
	sub_8B0DF298(ctx, base);
	// lwz r9,0(r31)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r31.u32 + 0);
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// lwz r8,0(r9)
	ctx.r8.u64 = REX_LOAD_U32(ctx.r9.u32 + 0);
	// mtctr r8
	ctx.ctr.u64 = ctx.r8.u64;
	// bctrl 
	ctx.lr = 0x8B0AF018;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// lis r7,-29944
	ctx.r7.s64 = -1962409984;
	// li r30,1
	ctx.r30.s64 = 1;
	// addi r29,r7,1800
	ctx.r29.s64 = ctx.r7.s64 + 1800;
	// stw r30,84(r1)
	REX_STORE_U32(ctx.r1.u32 + 84, ctx.r30.u32);
	// li r5,1
	ctx.r5.s64 = 1;
	// stw r29,80(r1)
	REX_STORE_U32(ctx.r1.u32 + 80, ctx.r29.u32);
	// addi r4,r1,80
	ctx.r4.s64 = ctx.r1.s64 + 80;
	// bl 0x8b0bf510
	ctx.lr = 0x8B0AF038;
	sub_8B0BF510(ctx, base);
	// lis r6,-29944
	ctx.r6.s64 = -1962409984;
	// addi r3,r6,27832
	ctx.r3.s64 = ctx.r6.s64 + 27832;
	// bl 0x8b0df298
	ctx.lr = 0x8B0AF044;
	sub_8B0DF298(ctx, base);
	// lwz r5,0(r31)
	ctx.r5.u64 = REX_LOAD_U32(ctx.r31.u32 + 0);
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// lwz r4,4(r5)
	ctx.r4.u64 = REX_LOAD_U32(ctx.r5.u32 + 4);
	// mtctr r4
	ctx.ctr.u64 = ctx.r4.u64;
	// bctrl 
	ctx.lr = 0x8B0AF058;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// stw r29,88(r1)
	REX_STORE_U32(ctx.r1.u32 + 88, ctx.r29.u32);
	// li r5,1
	ctx.r5.s64 = 1;
	// stw r30,92(r1)
	REX_STORE_U32(ctx.r1.u32 + 92, ctx.r30.u32);
	// addi r4,r1,88
	ctx.r4.s64 = ctx.r1.s64 + 88;
	// bl 0x8b0bf510
	ctx.lr = 0x8B0AF06C;
	sub_8B0BF510(ctx, base);
	// lwz r3,32(r31)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r31.u32 + 32);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0af084
	if (ctx.cr6.eq) goto loc_8B0AF084;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// addi r3,r11,27800
	ctx.r3.s64 = ctx.r11.s64 + 27800;
	// b 0x8b0af08c
	goto loc_8B0AF08C;
loc_8B0AF084:
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// addi r3,r11,27768
	ctx.r3.s64 = ctx.r11.s64 + 27768;
loc_8B0AF08C:
	// bl 0x8b0df298
	ctx.lr = 0x8B0AF090;
	sub_8B0DF298(ctx, base);
	// lwz r11,28(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 28);
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// beq cr6,0x8b0af0b4
	if (ctx.cr6.eq) goto loc_8B0AF0B4;
	// rotlwi r3,r11,0
	ctx.r3.u64 = __builtin_rotateleft32(ctx.r11.u32, 0);
	// lwz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r10,32(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 32);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B0AF0B0;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// b 0x8b0af0c0
	goto loc_8B0AF0C0;
loc_8B0AF0B4:
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// addi r3,r11,27748
	ctx.r3.s64 = ctx.r11.s64 + 27748;
	// bl 0x8b0df298
	ctx.lr = 0x8B0AF0C0;
	sub_8B0DF298(ctx, base);
loc_8B0AF0C0:
	// lwz r11,36(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 36);
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// beq cr6,0x8b0af0e8
	if (ctx.cr6.eq) goto loc_8B0AF0E8;
	// rotlwi r3,r11,0
	ctx.r3.u64 = __builtin_rotateleft32(ctx.r11.u32, 0);
	// lwz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r10,24(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 24);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B0AF0E0;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// addi r1,r1,128
	ctx.r1.s64 = ctx.r1.s64 + 128;
	// b 0x8b0cba0c
	__restgprlr_29(ctx, base);
	return;
loc_8B0AF0E8:
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// addi r3,r11,27728
	ctx.r3.s64 = ctx.r11.s64 + 27728;
	// bl 0x8b0df298
	ctx.lr = 0x8B0AF0F4;
	sub_8B0DF298(ctx, base);
	// addi r1,r1,128
	ctx.r1.s64 = ctx.r1.s64 + 128;
	// b 0x8b0cba0c
	__restgprlr_29(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0AF9C0) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9bc
	ctx.lr = 0x8B0AF9C8;
	__savegprlr_29(ctx, base);
	// stwu r1,-112(r1)
	ea = -112 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lis r29,-29938
	ctx.r29.s64 = -1962016768;
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// li r5,0
	ctx.r5.s64 = 0;
	// li r4,0
	ctx.r4.s64 = 0;
	// lwz r11,2364(r29)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r29.u32 + 2364);
	// lwz r3,76(r11)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r11.u32 + 76);
	// lwz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r10,36(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 36);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B0AF9F4;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// lwz r9,24(r31)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r31.u32 + 24);
	// cmpwi cr6,r9,2
	ctx.cr6.compare<int32_t>(ctx.r9.s32, 2, ctx.xer);
	// ble cr6,0x8b0afac0
	if (!ctx.cr6.gt) goto loc_8B0AFAC0;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lwz r3,8(r31)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r31.u32 + 8);
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// addi r30,r11,10100
	ctx.r30.s64 = ctx.r11.s64 + 10100;
	// addi r4,r10,4588
	ctx.r4.s64 = ctx.r10.s64 + 4588;
	// mr r5,r30
	ctx.r5.u64 = ctx.r30.u64;
	// bl 0x8b0c1588
	ctx.lr = 0x8B0AFA1C;
	sub_8B0C1588(ctx, base);
	// mr r4,r30
	ctx.r4.u64 = ctx.r30.u64;
	// bl 0x8b0cea10
	ctx.lr = 0x8B0AFA24;
	sub_8B0CEA10(ctx, base);
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// bne cr6,0x8b0afaa0
	if (!ctx.cr6.eq) goto loc_8B0AFAA0;
	// lwz r11,2364(r29)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r29.u32 + 2364);
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// li r6,0
	ctx.r6.s64 = 0;
	// addi r4,r10,3532
	ctx.r4.s64 = ctx.r10.s64 + 3532;
	// li r5,0
	ctx.r5.s64 = 0;
	// lwz r3,96(r11)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r11.u32 + 96);
	// lwz r9,0(r3)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r8,24(r9)
	ctx.r8.u64 = REX_LOAD_U32(ctx.r9.u32 + 24);
	// mtctr r8
	ctx.ctr.u64 = ctx.r8.u64;
	// bctrl 
	ctx.lr = 0x8B0AFA54;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// mr r30,r3
	ctx.r30.u64 = ctx.r3.u64;
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0afaa0
	if (ctx.cr6.eq) goto loc_8B0AFAA0;
	// lwz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// lis r9,-29944
	ctx.r9.s64 = -1962409984;
	// addi r5,r10,4264
	ctx.r5.s64 = ctx.r10.s64 + 4264;
	// addi r4,r9,4500
	ctx.r4.s64 = ctx.r9.s64 + 4500;
	// lwz r8,56(r11)
	ctx.r8.u64 = REX_LOAD_U32(ctx.r11.u32 + 56);
	// mtctr r8
	ctx.ctr.u64 = ctx.r8.u64;
	// bctrl 
	ctx.lr = 0x8B0AFA80;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// lwz r11,2364(r29)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r29.u32 + 2364);
	// li r5,0
	ctx.r5.s64 = 0;
	// mr r4,r30
	ctx.r4.u64 = ctx.r30.u64;
	// lwz r3,96(r11)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r11.u32 + 96);
	// lwz r7,0(r3)
	ctx.r7.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r6,28(r7)
	ctx.r6.u64 = REX_LOAD_U32(ctx.r7.u32 + 28);
	// mtctr r6
	ctx.ctr.u64 = ctx.r6.u64;
	// bctrl 
	ctx.lr = 0x8B0AFAA0;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
loc_8B0AFAA0:
	// lwz r11,2364(r29)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r29.u32 + 2364);
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// addi r4,r10,27560
	ctx.r4.s64 = ctx.r10.s64 + 27560;
	// lwz r3,84(r11)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r11.u32 + 84);
	// lwz r9,0(r3)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r8,416(r9)
	ctx.r8.u64 = REX_LOAD_U32(ctx.r9.u32 + 416);
	// mtctr r8
	ctx.ctr.u64 = ctx.r8.u64;
	// bctrl 
	ctx.lr = 0x8B0AFAC0;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
loc_8B0AFAC0:
	// lwz r3,36(r31)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r31.u32 + 36);
	// li r30,0
	ctx.r30.s64 = 0;
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0afae4
	if (ctx.cr6.eq) goto loc_8B0AFAE4;
	// lwz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r10,20(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 20);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B0AFAE0;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// stw r30,36(r31)
	REX_STORE_U32(ctx.r31.u32 + 36, ctx.r30.u32);
loc_8B0AFAE4:
	// lwz r3,32(r31)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r31.u32 + 32);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0afb04
	if (ctx.cr6.eq) goto loc_8B0AFB04;
	// lwz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r10,12(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 12);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B0AFB00;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// stw r30,32(r31)
	REX_STORE_U32(ctx.r31.u32 + 32, ctx.r30.u32);
loc_8B0AFB04:
	// lwz r3,28(r31)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r31.u32 + 28);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0afb24
	if (ctx.cr6.eq) goto loc_8B0AFB24;
	// lwz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r10,20(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 20);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B0AFB20;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// stw r30,28(r31)
	REX_STORE_U32(ctx.r31.u32 + 28, ctx.r30.u32);
loc_8B0AFB24:
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0aee08
	ctx.lr = 0x8B0AFB2C;
	sub_8B0AEE08(ctx, base);
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b090020
	ctx.lr = 0x8B0AFB34;
	sub_8B090020(ctx, base);
	// lwz r11,2364(r29)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r29.u32 + 2364);
	// li r4,0
	ctx.r4.s64 = 0;
	// lwz r3,76(r11)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r11.u32 + 76);
	// lwz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r10,32(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 32);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B0AFB50;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// addi r1,r1,112
	ctx.r1.s64 = ctx.r1.s64 + 112;
	// b 0x8b0cba0c
	__restgprlr_29(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0AFFA8) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9b4
	ctx.lr = 0x8B0AFFB0;
	__savegprlr_27(ctx, base);
	// stwu r1,-384(r1)
	ea = -384 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// mr r30,r3
	ctx.r30.u64 = ctx.r3.u64;
	// mr r3,r4
	ctx.r3.u64 = ctx.r4.u64;
	// mr r31,r4
	ctx.r31.u64 = ctx.r4.u64;
	// bl 0x8b0beee8
	ctx.lr = 0x8B0AFFC4;
	sub_8B0BEEE8(ctx, base);
	// lwz r11,28(r30)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r30.u32 + 28);
	// mr r29,r3
	ctx.r29.u64 = ctx.r3.u64;
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// beq cr6,0x8b0affec
	if (ctx.cr6.eq) goto loc_8B0AFFEC;
	// lwz r10,4(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 4);
	// addi r3,r11,4
	ctx.r3.s64 = ctx.r11.s64 + 4;
	// mr r4,r31
	ctx.r4.u64 = ctx.r31.u64;
	// lwz r9,0(r10)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r10.u32 + 0);
	// mtctr r9
	ctx.ctr.u64 = ctx.r9.u64;
	// bctrl 
	ctx.lr = 0x8B0AFFEC;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
loc_8B0AFFEC:
	// lwz r11,32(r30)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r30.u32 + 32);
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// beq cr6,0x8b0b0010
	if (ctx.cr6.eq) goto loc_8B0B0010;
	// lwz r10,4(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 4);
	// addi r3,r11,4
	ctx.r3.s64 = ctx.r11.s64 + 4;
	// mr r4,r31
	ctx.r4.u64 = ctx.r31.u64;
	// lwz r9,0(r10)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r10.u32 + 0);
	// mtctr r9
	ctx.ctr.u64 = ctx.r9.u64;
	// bctrl 
	ctx.lr = 0x8B0B0010;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
loc_8B0B0010:
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// mr r4,r29
	ctx.r4.u64 = ctx.r29.u64;
	// addi r3,r11,4000
	ctx.r3.s64 = ctx.r11.s64 + 4000;
	// bl 0x8b0cea10
	ctx.lr = 0x8B0B0020;
	sub_8B0CEA10(ctx, base);
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// bne cr6,0x8b0b01a4
	if (!ctx.cr6.eq) goto loc_8B0B01A4;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// li r5,0
	ctx.r5.s64 = 0;
	// addi r4,r11,3988
	ctx.r4.s64 = ctx.r11.s64 + 3988;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0bfc38
	ctx.lr = 0x8B0B003C;
	sub_8B0BFC38(ctx, base);
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// mr r29,r3
	ctx.r29.u64 = ctx.r3.u64;
	// addi r4,r10,3984
	ctx.r4.s64 = ctx.r10.s64 + 3984;
	// li r5,0
	ctx.r5.s64 = 0;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0bfc38
	ctx.lr = 0x8B0B0054;
	sub_8B0BFC38(ctx, base);
	// cmpwi cr6,r29,2
	ctx.cr6.compare<int32_t>(ctx.r29.s32, 2, ctx.xer);
	// blt cr6,0x8b0b08c0
	if (ctx.cr6.lt) goto loc_8B0B08C0;
	// cmpwi cr6,r3,2
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 2, ctx.xer);
	// bge cr6,0x8b0b08c0
	if (!ctx.cr6.lt) goto loc_8B0B08C0;
	// lwz r11,20(r30)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r30.u32 + 20);
	// cmpwi cr6,r11,6
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 6, ctx.xer);
	// beq cr6,0x8b0b0150
	if (ctx.cr6.eq) goto loc_8B0B0150;
	// cmpwi cr6,r11,7
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 7, ctx.xer);
	// beq cr6,0x8b0b0150
	if (ctx.cr6.eq) goto loc_8B0B0150;
	// cmpwi cr6,r11,8
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 8, ctx.xer);
	// bne cr6,0x8b0b08c0
	if (!ctx.cr6.eq) goto loc_8B0B08C0;
	// li r11,2
	ctx.r11.s64 = 2;
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// stw r11,20(r30)
	REX_STORE_U32(ctx.r30.u32 + 20, ctx.r11.u32);
	// lis r9,-29944
	ctx.r9.s64 = -1962409984;
	// addi r29,r10,4056
	ctx.r29.s64 = ctx.r10.s64 + 4056;
	// addi r4,r9,27016
	ctx.r4.s64 = ctx.r9.s64 + 27016;
	// mr r3,r29
	ctx.r3.u64 = ctx.r29.u64;
	// li r5,0
	ctx.r5.s64 = 0;
	// bl 0x8b0c0c70
	ctx.lr = 0x8B0B00A4;
	sub_8B0C0C70(ctx, base);
	// lis r8,-29938
	ctx.r8.s64 = -1962016768;
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// lwz r3,3036(r8)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r8.u32 + 3036);
	// lwz r7,0(r3)
	ctx.r7.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r6,64(r7)
	ctx.r6.u64 = REX_LOAD_U32(ctx.r7.u32 + 64);
	// mtctr r6
	ctx.ctr.u64 = ctx.r6.u64;
	// bctrl 
	ctx.lr = 0x8B0B00C0;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// mr r28,r3
	ctx.r28.u64 = ctx.r3.u64;
	// mr r4,r29
	ctx.r4.u64 = ctx.r29.u64;
	// li r5,0
	ctx.r5.s64 = 0;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// lwz r29,0(r28)
	ctx.r29.u64 = REX_LOAD_U32(ctx.r28.u32 + 0);
	// bl 0x8b0bfa88
	ctx.lr = 0x8B0B00D8;
	sub_8B0BFA88(ctx, base);
	// lwz r11,8(r29)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r29.u32 + 8);
	// mr r5,r3
	ctx.r5.u64 = ctx.r3.u64;
	// mr r3,r28
	ctx.r3.u64 = ctx.r28.u64;
	// lwz r4,4(r30)
	ctx.r4.u64 = REX_LOAD_U32(ctx.r30.u32 + 4);
	// li r6,1
	ctx.r6.s64 = 1;
	// mtctr r11
	ctx.ctr.u64 = ctx.r11.u64;
	// bctrl 
	ctx.lr = 0x8B0B00F4;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// lwz r10,-4(r30)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r30.u32 + -4);
	// addi r3,r30,-4
	ctx.r3.s64 = ctx.r30.s64 + -4;
	// mr r4,r31
	ctx.r4.u64 = ctx.r31.u64;
	// lwz r9,8(r10)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r10.u32 + 8);
	// mtctr r9
	ctx.ctr.u64 = ctx.r9.u64;
	// bctrl 
	ctx.lr = 0x8B0B010C;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// cmplwi cr6,r31,0
	ctx.cr6.compare<uint32_t>(ctx.r31.u32, 0, ctx.xer);
	// beq cr6,0x8b0b011c
	if (ctx.cr6.eq) goto loc_8B0B011C;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0c04f0
	ctx.lr = 0x8B0B011C;
	sub_8B0C04F0(ctx, base);
loc_8B0B011C:
	// li r3,36
	ctx.r3.s64 = 36;
	// bl 0x8b0bf448
	ctx.lr = 0x8B0B0124;
	sub_8B0BF448(ctx, base);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0b0180
	if (ctx.cr6.eq) goto loc_8B0B0180;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// lis r9,-29944
	ctx.r9.s64 = -1962409984;
	// addi r6,r11,4040
	ctx.r6.s64 = ctx.r11.s64 + 4040;
	// addi r5,r10,4072
	ctx.r5.s64 = ctx.r10.s64 + 4072;
	// addi r4,r9,4080
	ctx.r4.s64 = ctx.r9.s64 + 4080;
	// bl 0x8b0c1300
	ctx.lr = 0x8B0B0148;
	sub_8B0C1300(ctx, base);
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// b 0x8b0b0184
	goto loc_8B0B0184;
loc_8B0B0150:
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// addi r3,r11,28576
	ctx.r3.s64 = ctx.r11.s64 + 28576;
	// bl 0x8b0df298
	ctx.lr = 0x8B0B015C;
	sub_8B0DF298(ctx, base);
loc_8B0B015C:
	// li r3,36
	ctx.r3.s64 = 36;
	// bl 0x8b0bf448
	ctx.lr = 0x8B0B0164;
	sub_8B0BF448(ctx, base);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0b0180
	if (ctx.cr6.eq) goto loc_8B0B0180;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// addi r4,r11,19592
	ctx.r4.s64 = ctx.r11.s64 + 19592;
	// bl 0x8b0bf9f8
	ctx.lr = 0x8B0B0178;
	sub_8B0BF9F8(ctx, base);
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// b 0x8b0b0184
	goto loc_8B0B0184;
loc_8B0B0180:
	// li r4,0
	ctx.r4.s64 = 0;
loc_8B0B0184:
	// lis r11,-29938
	ctx.r11.s64 = -1962016768;
	// lwz r3,4480(r11)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r11.u32 + 4480);
	// lwz r10,0(r3)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r9,8(r10)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r10.u32 + 8);
	// mtctr r9
	ctx.ctr.u64 = ctx.r9.u64;
	// bctrl 
	ctx.lr = 0x8B0B019C;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// addi r1,r1,384
	ctx.r1.s64 = ctx.r1.s64 + 384;
	// b 0x8b0cba04
	__restgprlr_27(ctx, base);
	return;
loc_8B0B01A4:
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// mr r4,r29
	ctx.r4.u64 = ctx.r29.u64;
	// addi r3,r11,4136
	ctx.r3.s64 = ctx.r11.s64 + 4136;
	// bl 0x8b0cea10
	ctx.lr = 0x8B0B01B4;
	sub_8B0CEA10(ctx, base);
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// bne cr6,0x8b0b0290
	if (!ctx.cr6.eq) goto loc_8B0B0290;
	// lwz r11,20(r30)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r30.u32 + 20);
	// cmpwi cr6,r11,6
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 6, ctx.xer);
	// beq cr6,0x8b0b01d0
	if (ctx.cr6.eq) goto loc_8B0B01D0;
	// cmpwi cr6,r11,7
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 7, ctx.xer);
	// bne cr6,0x8b0b08c0
	if (!ctx.cr6.eq) goto loc_8B0B08C0;
loc_8B0B01D0:
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// addi r5,r11,1791
	ctx.r5.s64 = ctx.r11.s64 + 1791;
	// addi r4,r10,4500
	ctx.r4.s64 = ctx.r10.s64 + 4500;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0c1588
	ctx.lr = 0x8B0B01E8;
	sub_8B0C1588(ctx, base);
	// lis r9,-29944
	ctx.r9.s64 = -1962409984;
	// mr r29,r3
	ctx.r29.u64 = ctx.r3.u64;
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// addi r3,r9,28544
	ctx.r3.s64 = ctx.r9.s64 + 28544;
	// bl 0x8b0df298
	ctx.lr = 0x8B0B01FC;
	sub_8B0DF298(ctx, base);
	// lis r8,-29944
	ctx.r8.s64 = -1962409984;
	// mr r3,r29
	ctx.r3.u64 = ctx.r29.u64;
	// addi r4,r8,28512
	ctx.r4.s64 = ctx.r8.s64 + 28512;
	// bl 0x8b0c3c50
	ctx.lr = 0x8B0B020C;
	sub_8B0C3C50(ctx, base);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// bne cr6,0x8b0b0230
	if (!ctx.cr6.eq) goto loc_8B0B0230;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// mr r3,r29
	ctx.r3.u64 = ctx.r29.u64;
	// addi r4,r11,4164
	ctx.r4.s64 = ctx.r11.s64 + 4164;
	// bl 0x8b0c3c50
	ctx.lr = 0x8B0B0224;
	sub_8B0C3C50(ctx, base);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// li r11,0
	ctx.r11.s64 = 0;
	// beq cr6,0x8b0b0234
	if (ctx.cr6.eq) goto loc_8B0B0234;
loc_8B0B0230:
	// li r11,1
	ctx.r11.s64 = 1;
loc_8B0B0234:
	// clrlwi r11,r11,24
	ctx.r11.u64 = ctx.r11.u32 & 0xFF;
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// beq cr6,0x8b0b015c
	if (ctx.cr6.eq) goto loc_8B0B015C;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// addi r5,r11,4636
	ctx.r5.s64 = ctx.r11.s64 + 4636;
	// addi r4,r10,28496
	ctx.r4.s64 = ctx.r10.s64 + 28496;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0c0010
	ctx.lr = 0x8B0B0258;
	sub_8B0C0010(ctx, base);
	// lis r29,-29938
	ctx.r29.s64 = -1962016768;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// lwz r11,4480(r29)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r29.u32 + 4480);
	// lwz r31,0(r11)
	ctx.r31.u64 = REX_LOAD_U32(ctx.r11.u32 + 0);
	// bl 0x8b0c0298
	ctx.lr = 0x8B0B026C;
	sub_8B0C0298(ctx, base);
	// lwz r9,12(r31)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r31.u32 + 12);
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// lwz r3,4480(r29)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r29.u32 + 4480);
	// mtctr r9
	ctx.ctr.u64 = ctx.r9.u64;
	// bctrl 
	ctx.lr = 0x8B0B0280;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
loc_8B0B0280:
	// addi r3,r30,-4
	ctx.r3.s64 = ctx.r30.s64 + -4;
	// bl 0x8b0aed18
	ctx.lr = 0x8B0B0288;
	sub_8B0AED18(ctx, base);
	// addi r1,r1,384
	ctx.r1.s64 = ctx.r1.s64 + 384;
	// b 0x8b0cba04
	__restgprlr_27(ctx, base);
	return;
loc_8B0B0290:
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// mr r4,r29
	ctx.r4.u64 = ctx.r29.u64;
	// addi r3,r11,28480
	ctx.r3.s64 = ctx.r11.s64 + 28480;
	// bl 0x8b0cea10
	ctx.lr = 0x8B0B02A0;
	sub_8B0CEA10(ctx, base);
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// beq cr6,0x8b0b0280
	if (ctx.cr6.eq) goto loc_8B0B0280;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// mr r4,r29
	ctx.r4.u64 = ctx.r29.u64;
	// addi r3,r11,28452
	ctx.r3.s64 = ctx.r11.s64 + 28452;
	// bl 0x8b0cea10
	ctx.lr = 0x8B0B02B8;
	sub_8B0CEA10(ctx, base);
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// bne cr6,0x8b0b02dc
	if (!ctx.cr6.eq) goto loc_8B0B02DC;
	// lwz r11,20(r30)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r30.u32 + 20);
	// cmpwi cr6,r11,6
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 6, ctx.xer);
	// bne cr6,0x8b0b08c0
	if (!ctx.cr6.eq) goto loc_8B0B08C0;
	// addi r3,r30,-4
	ctx.r3.s64 = ctx.r30.s64 + -4;
	// bl 0x8b0aea08
	ctx.lr = 0x8B0B02D4;
	sub_8B0AEA08(ctx, base);
	// addi r1,r1,384
	ctx.r1.s64 = ctx.r1.s64 + 384;
	// b 0x8b0cba04
	__restgprlr_27(ctx, base);
	return;
loc_8B0B02DC:
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// mr r4,r29
	ctx.r4.u64 = ctx.r29.u64;
	// addi r3,r11,17652
	ctx.r3.s64 = ctx.r11.s64 + 17652;
	// bl 0x8b0cea10
	ctx.lr = 0x8B0B02EC;
	sub_8B0CEA10(ctx, base);
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// bne cr6,0x8b0b032c
	if (!ctx.cr6.eq) goto loc_8B0B032C;
	// addi r30,r30,-4
	ctx.r30.s64 = ctx.r30.s64 + -4;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// li r5,0
	ctx.r5.s64 = 0;
	// addi r4,r11,3624
	ctx.r4.s64 = ctx.r11.s64 + 3624;
	// lwz r31,0(r30)
	ctx.r31.u64 = REX_LOAD_U32(ctx.r30.u32 + 0);
	// bl 0x8b0bfc38
	ctx.lr = 0x8B0B0310;
	sub_8B0BFC38(ctx, base);
	// lwz r10,36(r31)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r31.u32 + 36);
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B0B0324;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// addi r1,r1,384
	ctx.r1.s64 = ctx.r1.s64 + 384;
	// b 0x8b0cba04
	__restgprlr_27(ctx, base);
	return;
loc_8B0B032C:
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// mr r4,r29
	ctx.r4.u64 = ctx.r29.u64;
	// addi r3,r11,9244
	ctx.r3.s64 = ctx.r11.s64 + 9244;
	// bl 0x8b0cea10
	ctx.lr = 0x8B0B033C;
	sub_8B0CEA10(ctx, base);
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// bne cr6,0x8b0b0390
	if (!ctx.cr6.eq) goto loc_8B0B0390;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0bf248
	ctx.lr = 0x8B0B034C;
	sub_8B0BF248(ctx, base);
	// bl 0x8b0beee8
	ctx.lr = 0x8B0B0350;
	sub_8B0BEEE8(ctx, base);
	// lwz r11,24(r30)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r30.u32 + 24);
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// beq cr6,0x8b0b08c0
	if (ctx.cr6.eq) goto loc_8B0B08C0;
	// lwz r11,20(r30)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r30.u32 + 20);
	// cmpwi cr6,r11,1
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 1, ctx.xer);
	// ble cr6,0x8b0b08c0
	if (!ctx.cr6.gt) goto loc_8B0B08C0;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// addi r4,r11,8764
	ctx.r4.s64 = ctx.r11.s64 + 8764;
	// bl 0x8b0cea10
	ctx.lr = 0x8B0B0374;
	sub_8B0CEA10(ctx, base);
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// bne cr6,0x8b0b08c0
	if (!ctx.cr6.eq) goto loc_8B0B08C0;
	// mr r4,r31
	ctx.r4.u64 = ctx.r31.u64;
	// lwz r3,24(r30)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r30.u32 + 24);
	// bl 0x8b0a36b0
	ctx.lr = 0x8B0B0388;
	sub_8B0A36B0(ctx, base);
	// addi r1,r1,384
	ctx.r1.s64 = ctx.r1.s64 + 384;
	// b 0x8b0cba04
	__restgprlr_27(ctx, base);
	return;
loc_8B0B0390:
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// mr r4,r29
	ctx.r4.u64 = ctx.r29.u64;
	// addi r3,r11,28428
	ctx.r3.s64 = ctx.r11.s64 + 28428;
	// bl 0x8b0cea10
	ctx.lr = 0x8B0B03A0;
	sub_8B0CEA10(ctx, base);
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// bne cr6,0x8b0b03cc
	if (!ctx.cr6.eq) goto loc_8B0B03CC;
	// lwz r3,24(r30)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r30.u32 + 24);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0b08c0
	if (ctx.cr6.eq) goto loc_8B0B08C0;
	// lwz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r10,80(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 80);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B0B03C4;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// addi r1,r1,384
	ctx.r1.s64 = ctx.r1.s64 + 384;
	// b 0x8b0cba04
	__restgprlr_27(ctx, base);
	return;
loc_8B0B03CC:
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// mr r4,r29
	ctx.r4.u64 = ctx.r29.u64;
	// addi r27,r11,4080
	ctx.r27.s64 = ctx.r11.s64 + 4080;
	// mr r3,r27
	ctx.r3.u64 = ctx.r27.u64;
	// bl 0x8b0cea10
	ctx.lr = 0x8B0B03E0;
	sub_8B0CEA10(ctx, base);
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// bne cr6,0x8b0b051c
	if (!ctx.cr6.eq) goto loc_8B0B051C;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// addi r29,r11,1791
	ctx.r29.s64 = ctx.r11.s64 + 1791;
	// addi r4,r10,4072
	ctx.r4.s64 = ctx.r10.s64 + 4072;
	// mr r5,r29
	ctx.r5.u64 = ctx.r29.u64;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0c1588
	ctx.lr = 0x8B0B0404;
	sub_8B0C1588(ctx, base);
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// addi r28,r11,28164
	ctx.r28.s64 = ctx.r11.s64 + 28164;
	// mr r3,r28
	ctx.r3.u64 = ctx.r28.u64;
	// bl 0x8b0cea10
	ctx.lr = 0x8B0B0418;
	sub_8B0CEA10(ctx, base);
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// bne cr6,0x8b0b08c0
	if (!ctx.cr6.eq) goto loc_8B0B08C0;
	// lwz r11,32(r30)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r30.u32 + 32);
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// beq cr6,0x8b0b08c0
	if (ctx.cr6.eq) goto loc_8B0B08C0;
	// lwz r11,20(r30)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r30.u32 + 20);
	// cmpwi cr6,r11,3
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 3, ctx.xer);
	// bne cr6,0x8b0b08c0
	if (!ctx.cr6.eq) goto loc_8B0B08C0;
	// mr r5,r29
	ctx.r5.u64 = ctx.r29.u64;
	// mr r4,r28
	ctx.r4.u64 = ctx.r28.u64;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0c1588
	ctx.lr = 0x8B0B0448;
	sub_8B0C1588(ctx, base);
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// mr r29,r3
	ctx.r29.u64 = ctx.r3.u64;
	// addi r4,r11,28416
	ctx.r4.s64 = ctx.r11.s64 + 28416;
	// li r5,0
	ctx.r5.s64 = 0;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0bfc38
	ctx.lr = 0x8B0B0460;
	sub_8B0BFC38(ctx, base);
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// mr r28,r3
	ctx.r28.u64 = ctx.r3.u64;
	// addi r3,r10,28408
	ctx.r3.s64 = ctx.r10.s64 + 28408;
	// mr r4,r29
	ctx.r4.u64 = ctx.r29.u64;
	// bl 0x8b0cea10
	ctx.lr = 0x8B0B0474;
	sub_8B0CEA10(ctx, base);
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// bne cr6,0x8b0b048c
	if (!ctx.cr6.eq) goto loc_8B0B048C;
	// li r11,4
	ctx.r11.s64 = 4;
	// stw r11,20(r30)
	REX_STORE_U32(ctx.r30.u32 + 20, ctx.r11.u32);
	// addi r1,r1,384
	ctx.r1.s64 = ctx.r1.s64 + 384;
	// b 0x8b0cba04
	__restgprlr_27(ctx, base);
	return;
loc_8B0B048C:
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// addi r4,r11,28372
	ctx.r4.s64 = ctx.r11.s64 + 28372;
	// addi r3,r10,4056
	ctx.r3.s64 = ctx.r10.s64 + 4056;
	// li r5,0
	ctx.r5.s64 = 0;
	// bl 0x8b0c0c70
	ctx.lr = 0x8B0B04A4;
	sub_8B0C0C70(ctx, base);
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// cmpwi cr6,r28,0
	ctx.cr6.compare<int32_t>(ctx.r28.s32, 0, ctx.xer);
	// mr r5,r29
	ctx.r5.u64 = ctx.r29.u64;
	// addi r3,r1,80
	ctx.r3.s64 = ctx.r1.s64 + 80;
	// ble cr6,0x8b0b04cc
	if (!ctx.cr6.gt) goto loc_8B0B04CC;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// mr r6,r28
	ctx.r6.u64 = ctx.r28.u64;
	// addi r4,r11,28356
	ctx.r4.s64 = ctx.r11.s64 + 28356;
	// bl 0x8b090220
	ctx.lr = 0x8B0B04C8;
	sub_8B090220(ctx, base);
	// b 0x8b0b04d8
	goto loc_8B0B04D8;
loc_8B0B04CC:
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// addi r4,r11,28344
	ctx.r4.s64 = ctx.r11.s64 + 28344;
	// bl 0x8b090220
	ctx.lr = 0x8B0B04D8;
	sub_8B090220(ctx, base);
loc_8B0B04D8:
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// mr r5,r3
	ctx.r5.u64 = ctx.r3.u64;
	// addi r4,r10,28324
	ctx.r4.s64 = ctx.r10.s64 + 28324;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0c0010
	ctx.lr = 0x8B0B04EC;
	sub_8B0C0010(ctx, base);
	// lwz r11,-4(r30)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r30.u32 + -4);
	// addi r3,r30,-4
	ctx.r3.s64 = ctx.r30.s64 + -4;
	// mr r4,r31
	ctx.r4.u64 = ctx.r31.u64;
	// lwz r10,8(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 8);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B0B0504;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// cmplwi cr6,r31,0
	ctx.cr6.compare<uint32_t>(ctx.r31.u32, 0, ctx.xer);
	// beq cr6,0x8b0b08c0
	if (ctx.cr6.eq) goto loc_8B0B08C0;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0c04f0
	ctx.lr = 0x8B0B0514;
	sub_8B0C04F0(ctx, base);
	// addi r1,r1,384
	ctx.r1.s64 = ctx.r1.s64 + 384;
	// b 0x8b0cba04
	__restgprlr_27(ctx, base);
	return;
loc_8B0B051C:
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// mr r4,r29
	ctx.r4.u64 = ctx.r29.u64;
	// addi r3,r11,28292
	ctx.r3.s64 = ctx.r11.s64 + 28292;
	// bl 0x8b0cea10
	ctx.lr = 0x8B0B052C;
	sub_8B0CEA10(ctx, base);
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// bne cr6,0x8b0b054c
	if (!ctx.cr6.eq) goto loc_8B0B054C;
	// li r11,6
	ctx.r11.s64 = 6;
	// addi r3,r30,-4
	ctx.r3.s64 = ctx.r30.s64 + -4;
	// stw r11,20(r30)
	REX_STORE_U32(ctx.r30.u32 + 20, ctx.r11.u32);
	// bl 0x8b0aee98
	ctx.lr = 0x8B0B0544;
	sub_8B0AEE98(ctx, base);
	// addi r1,r1,384
	ctx.r1.s64 = ctx.r1.s64 + 384;
	// b 0x8b0cba04
	__restgprlr_27(ctx, base);
	return;
loc_8B0B054C:
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// mr r4,r29
	ctx.r4.u64 = ctx.r29.u64;
	// addi r3,r11,28264
	ctx.r3.s64 = ctx.r11.s64 + 28264;
	// bl 0x8b0cea10
	ctx.lr = 0x8B0B055C;
	sub_8B0CEA10(ctx, base);
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// beq cr6,0x8b0b07f8
	if (ctx.cr6.eq) goto loc_8B0B07F8;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// mr r4,r29
	ctx.r4.u64 = ctx.r29.u64;
	// addi r3,r11,28232
	ctx.r3.s64 = ctx.r11.s64 + 28232;
	// bl 0x8b0cea10
	ctx.lr = 0x8B0B0574;
	sub_8B0CEA10(ctx, base);
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// beq cr6,0x8b0b07f8
	if (ctx.cr6.eq) goto loc_8B0B07F8;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// mr r4,r29
	ctx.r4.u64 = ctx.r29.u64;
	// addi r3,r11,17092
	ctx.r3.s64 = ctx.r11.s64 + 17092;
	// bl 0x8b0cea10
	ctx.lr = 0x8B0B058C;
	sub_8B0CEA10(ctx, base);
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// bne cr6,0x8b0b0790
	if (!ctx.cr6.eq) goto loc_8B0B0790;
	// lwz r11,24(r30)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r30.u32 + 24);
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// beq cr6,0x8b0b08c0
	if (ctx.cr6.eq) goto loc_8B0B08C0;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// li r5,0
	ctx.r5.s64 = 0;
	// addi r4,r11,16280
	ctx.r4.s64 = ctx.r11.s64 + 16280;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0bfe68
	ctx.lr = 0x8B0B05B4;
	sub_8B0BFE68(ctx, base);
	// lwz r10,24(r30)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r30.u32 + 24);
	// cmplw cr6,r3,r10
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, ctx.r10.u32, ctx.xer);
	// bne cr6,0x8b0b08c0
	if (!ctx.cr6.eq) goto loc_8B0B08C0;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// li r5,0
	ctx.r5.s64 = 0;
	// addi r29,r11,17076
	ctx.r29.s64 = ctx.r11.s64 + 17076;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// mr r4,r29
	ctx.r4.u64 = ctx.r29.u64;
	// bl 0x8b0c1588
	ctx.lr = 0x8B0B05D8;
	sub_8B0C1588(ctx, base);
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0b06b0
	if (ctx.cr6.eq) goto loc_8B0B06B0;
	// lwz r3,24(r30)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r30.u32 + 24);
	// lwz r28,20(r30)
	ctx.r28.u64 = REX_LOAD_U32(ctx.r30.u32 + 20);
	// lwz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r10,20(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 20);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B0B05FC;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// li r9,1
	ctx.r9.s64 = 1;
	// li r8,0
	ctx.r8.s64 = 0;
	// stw r9,20(r30)
	REX_STORE_U32(ctx.r30.u32 + 20, ctx.r9.u32);
	// li r3,36
	ctx.r3.s64 = 36;
	// stw r8,24(r30)
	REX_STORE_U32(ctx.r30.u32 + 24, ctx.r8.u32);
	// bl 0x8b0bf448
	ctx.lr = 0x8B0B0614;
	sub_8B0BF448(ctx, base);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0b0640
	if (ctx.cr6.eq) goto loc_8B0B0640;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// mr r7,r29
	ctx.r7.u64 = ctx.r29.u64;
	// mr r6,r29
	ctx.r6.u64 = ctx.r29.u64;
	// addi r5,r11,4072
	ctx.r5.s64 = ctx.r11.s64 + 4072;
	// mr r4,r27
	ctx.r4.u64 = ctx.r27.u64;
	// mr r8,r31
	ctx.r8.u64 = ctx.r31.u64;
	// bl 0x8b0c1438
	ctx.lr = 0x8B0B0638;
	sub_8B0C1438(ctx, base);
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// b 0x8b0b0644
	goto loc_8B0B0644;
loc_8B0B0640:
	// li r4,0
	ctx.r4.s64 = 0;
loc_8B0B0644:
	// lis r11,-29938
	ctx.r11.s64 = -1962016768;
	// lwz r3,4480(r11)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r11.u32 + 4480);
	// lwz r10,0(r3)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r9,8(r10)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r10.u32 + 8);
	// mtctr r9
	ctx.ctr.u64 = ctx.r9.u64;
	// bctrl 
	ctx.lr = 0x8B0B065C;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// lis r8,-29944
	ctx.r8.s64 = -1962409984;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// addi r4,r8,17480
	ctx.r4.s64 = ctx.r8.s64 + 17480;
	// bl 0x8b0cea10
	ctx.lr = 0x8B0B066C;
	sub_8B0CEA10(ctx, base);
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// bne cr6,0x8b0b08c0
	if (!ctx.cr6.eq) goto loc_8B0B08C0;
	// cmpwi cr6,r28,7
	ctx.cr6.compare<int32_t>(ctx.r28.s32, 7, ctx.xer);
	// beq cr6,0x8b0b0684
	if (ctx.cr6.eq) goto loc_8B0B0684;
	// cmpwi cr6,r28,8
	ctx.cr6.compare<int32_t>(ctx.r28.s32, 8, ctx.xer);
	// bne cr6,0x8b0b08c0
	if (!ctx.cr6.eq) goto loc_8B0B08C0;
loc_8B0B0684:
	// lis r11,-29938
	ctx.r11.s64 = -1962016768;
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// addi r4,r10,27560
	ctx.r4.s64 = ctx.r10.s64 + 27560;
	// lwz r11,2364(r11)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r11.u32 + 2364);
	// lwz r3,84(r11)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r11.u32 + 84);
	// lwz r9,0(r3)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r8,416(r9)
	ctx.r8.u64 = REX_LOAD_U32(ctx.r9.u32 + 416);
	// mtctr r8
	ctx.ctr.u64 = ctx.r8.u64;
	// bctrl 
	ctx.lr = 0x8B0B06A8;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// addi r1,r1,384
	ctx.r1.s64 = ctx.r1.s64 + 384;
	// b 0x8b0cba04
	__restgprlr_27(ctx, base);
	return;
loc_8B0B06B0:
	// lwz r11,20(r30)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r30.u32 + 20);
	// cmpwi cr6,r11,1
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 1, ctx.xer);
	// bne cr6,0x8b0b08c0
	if (!ctx.cr6.eq) goto loc_8B0B08C0;
	// li r3,36
	ctx.r3.s64 = 36;
	// bl 0x8b0bf448
	ctx.lr = 0x8B0B06C4;
	sub_8B0BF448(ctx, base);
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// addi r31,r11,4072
	ctx.r31.s64 = ctx.r11.s64 + 4072;
	// beq cr6,0x8b0b06f0
	if (ctx.cr6.eq) goto loc_8B0B06F0;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// mr r5,r31
	ctx.r5.u64 = ctx.r31.u64;
	// addi r6,r11,4048
	ctx.r6.s64 = ctx.r11.s64 + 4048;
	// mr r4,r27
	ctx.r4.u64 = ctx.r27.u64;
	// bl 0x8b0c1300
	ctx.lr = 0x8B0B06E8;
	sub_8B0C1300(ctx, base);
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// b 0x8b0b06f4
	goto loc_8B0B06F4;
loc_8B0B06F0:
	// li r4,0
	ctx.r4.s64 = 0;
loc_8B0B06F4:
	// lis r29,-29938
	ctx.r29.s64 = -1962016768;
	// lwz r3,4480(r29)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r29.u32 + 4480);
	// lwz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r10,8(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 8);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B0B070C;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// lis r9,-29944
	ctx.r9.s64 = -1962409984;
	// lwz r3,4(r30)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r30.u32 + 4);
	// li r5,0
	ctx.r5.s64 = 0;
	// addi r4,r9,4588
	ctx.r4.s64 = ctx.r9.s64 + 4588;
	// bl 0x8b0c1588
	ctx.lr = 0x8B0B0720;
	sub_8B0C1588(ctx, base);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0b0738
	if (ctx.cr6.eq) goto loc_8B0B0738;
	// addi r3,r30,-4
	ctx.r3.s64 = ctx.r30.s64 + -4;
	// bl 0x8b0ae938
	ctx.lr = 0x8B0B0730;
	sub_8B0AE938(ctx, base);
	// addi r1,r1,384
	ctx.r1.s64 = ctx.r1.s64 + 384;
	// b 0x8b0cba04
	__restgprlr_27(ctx, base);
	return;
loc_8B0B0738:
	// li r11,2
	ctx.r11.s64 = 2;
	// li r3,36
	ctx.r3.s64 = 36;
	// stw r11,20(r30)
	REX_STORE_U32(ctx.r30.u32 + 20, ctx.r11.u32);
	// bl 0x8b0bf448
	ctx.lr = 0x8B0B0748;
	sub_8B0BF448(ctx, base);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0b076c
	if (ctx.cr6.eq) goto loc_8B0B076C;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// mr r5,r31
	ctx.r5.u64 = ctx.r31.u64;
	// addi r6,r11,4040
	ctx.r6.s64 = ctx.r11.s64 + 4040;
	// mr r4,r27
	ctx.r4.u64 = ctx.r27.u64;
	// bl 0x8b0c1300
	ctx.lr = 0x8B0B0764;
	sub_8B0C1300(ctx, base);
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// b 0x8b0b0770
	goto loc_8B0B0770;
loc_8B0B076C:
	// li r4,0
	ctx.r4.s64 = 0;
loc_8B0B0770:
	// lwz r11,4480(r29)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r29.u32 + 4480);
	// mr r3,r11
	ctx.r3.u64 = ctx.r11.u64;
	// lwz r10,0(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 0);
	// lwz r9,8(r10)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r10.u32 + 8);
	// mtctr r9
	ctx.ctr.u64 = ctx.r9.u64;
	// bctrl 
	ctx.lr = 0x8B0B0788;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// addi r1,r1,384
	ctx.r1.s64 = ctx.r1.s64 + 384;
	// b 0x8b0cba04
	__restgprlr_27(ctx, base);
	return;
loc_8B0B0790:
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// mr r4,r29
	ctx.r4.u64 = ctx.r29.u64;
	// addi r3,r11,16292
	ctx.r3.s64 = ctx.r11.s64 + 16292;
	// bl 0x8b0cea10
	ctx.lr = 0x8B0B07A0;
	sub_8B0CEA10(ctx, base);
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// bne cr6,0x8b0b08c0
	if (!ctx.cr6.eq) goto loc_8B0B08C0;
	// lwz r11,24(r30)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r30.u32 + 24);
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// beq cr6,0x8b0b08c0
	if (ctx.cr6.eq) goto loc_8B0B08C0;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// li r5,0
	ctx.r5.s64 = 0;
	// addi r4,r11,16280
	ctx.r4.s64 = ctx.r11.s64 + 16280;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0bfe68
	ctx.lr = 0x8B0B07C8;
	sub_8B0BFE68(ctx, base);
	// lwz r10,24(r30)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r30.u32 + 24);
	// cmplw cr6,r3,r10
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, ctx.r10.u32, ctx.xer);
	// bne cr6,0x8b0b08c0
	if (!ctx.cr6.eq) goto loc_8B0B08C0;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0bf248
	ctx.lr = 0x8B0B07DC;
	sub_8B0BF248(ctx, base);
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0b08c0
	if (ctx.cr6.eq) goto loc_8B0B08C0;
	// addi r3,r30,-4
	ctx.r3.s64 = ctx.r30.s64 + -4;
	// bl 0x8b0afb58
	ctx.lr = 0x8B0B07F0;
	sub_8B0AFB58(ctx, base);
	// addi r1,r1,384
	ctx.r1.s64 = ctx.r1.s64 + 384;
	// b 0x8b0cba04
	__restgprlr_27(ctx, base);
	return;
loc_8B0B07F8:
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// li r5,0
	ctx.r5.s64 = 0;
	// addi r4,r11,28028
	ctx.r4.s64 = ctx.r11.s64 + 28028;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0bfa88
	ctx.lr = 0x8B0B080C;
	sub_8B0BFA88(ctx, base);
	// lwz r10,20(r30)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r30.u32 + 20);
	// mr r28,r3
	ctx.r28.u64 = ctx.r3.u64;
	// cmpwi cr6,r10,3
	ctx.cr6.compare<int32_t>(ctx.r10.s32, 3, ctx.xer);
	// bne cr6,0x8b0b08c0
	if (!ctx.cr6.eq) goto loc_8B0B08C0;
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0b08c0
	if (ctx.cr6.eq) goto loc_8B0B08C0;
	// lwz r11,32(r30)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r30.u32 + 32);
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// beq cr6,0x8b0b08c0
	if (ctx.cr6.eq) goto loc_8B0B08C0;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// addi r4,r11,28080
	ctx.r4.s64 = ctx.r11.s64 + 28080;
	// addi r3,r10,4056
	ctx.r3.s64 = ctx.r10.s64 + 4056;
	// li r5,0
	ctx.r5.s64 = 0;
	// bl 0x8b0c0c70
	ctx.lr = 0x8B0B0848;
	sub_8B0C0C70(ctx, base);
	// lis r9,-29944
	ctx.r9.s64 = -1962409984;
	// li r5,0
	ctx.r5.s64 = 0;
	// addi r4,r9,27464
	ctx.r4.s64 = ctx.r9.s64 + 27464;
	// mr r29,r3
	ctx.r29.u64 = ctx.r3.u64;
	// bl 0x8b0bfa88
	ctx.lr = 0x8B0B085C;
	sub_8B0BFA88(ctx, base);
	// mr r4,r28
	ctx.r4.u64 = ctx.r28.u64;
	// li r5,1
	ctx.r5.s64 = 1;
	// bl 0x8b0c0668
	ctx.lr = 0x8B0B0868;
	sub_8B0C0668(ctx, base);
	// addi r30,r30,-4
	ctx.r30.s64 = ctx.r30.s64 + -4;
	// mr r4,r29
	ctx.r4.u64 = ctx.r29.u64;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// lwz r8,0(r30)
	ctx.r8.u64 = REX_LOAD_U32(ctx.r30.u32 + 0);
	// lwz r7,8(r8)
	ctx.r7.u64 = REX_LOAD_U32(ctx.r8.u32 + 8);
	// mtctr r7
	ctx.ctr.u64 = ctx.r7.u64;
	// bctrl 
	ctx.lr = 0x8B0B0884;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// lis r6,-29944
	ctx.r6.s64 = -1962409984;
	// li r5,0
	ctx.r5.s64 = 0;
	// addi r4,r6,28220
	ctx.r4.s64 = ctx.r6.s64 + 28220;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0bfe68
	ctx.lr = 0x8B0B0898;
	sub_8B0BFE68(ctx, base);
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// bne cr6,0x8b0b08ac
	if (!ctx.cr6.eq) goto loc_8B0B08AC;
	// li r4,0
	ctx.r4.s64 = 0;
loc_8B0B08AC:
	// bl 0x8b0aeb80
	ctx.lr = 0x8B0B08B0;
	sub_8B0AEB80(ctx, base);
	// cmplwi cr6,r29,0
	ctx.cr6.compare<uint32_t>(ctx.r29.u32, 0, ctx.xer);
	// beq cr6,0x8b0b08c0
	if (ctx.cr6.eq) goto loc_8B0B08C0;
	// mr r3,r29
	ctx.r3.u64 = ctx.r29.u64;
	// bl 0x8b0c04f0
	ctx.lr = 0x8B0B08C0;
	sub_8B0C04F0(ctx, base);
loc_8B0B08C0:
	// addi r1,r1,384
	ctx.r1.s64 = ctx.r1.s64 + 384;
	// b 0x8b0cba04
	__restgprlr_27(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0B31C0) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9a8
	ctx.lr = 0x8B0B31C8;
	__savegprlr_24(ctx, base);
	// stwu r1,-160(r1)
	ea = -160 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lhz r27,16(r3)
	ctx.r27.u64 = REX_LOAD_U16(ctx.r3.u32 + 16);
	// mr r28,r3
	ctx.r28.u64 = ctx.r3.u64;
	// mr r24,r4
	ctx.r24.u64 = ctx.r4.u64;
	// mr r25,r27
	ctx.r25.u64 = ctx.r27.u64;
	// cmplwi cr6,r27,65535
	ctx.cr6.compare<uint32_t>(ctx.r27.u32, 65535, ctx.xer);
	// beq cr6,0x8b0b3308
	if (ctx.cr6.eq) goto loc_8B0B3308;
	// lis r10,0
	ctx.r10.s64 = 0;
	// lis r11,-29938
	ctx.r11.s64 = -1962016768;
	// ori r30,r10,65535
	ctx.r30.u64 = ctx.r10.u64 | 65535;
	// lis r26,-29938
	ctx.r26.s64 = -1962016768;
	// addi r31,r11,20792
	ctx.r31.s64 = ctx.r11.s64 + 20792;
loc_8B0B31F8:
	// lwz r11,4(r28)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r28.u32 + 4);
	// rlwinm r29,r25,5,0,26
	ctx.r29.u64 = __builtin_rotateleft64(ctx.r25.u32 | (ctx.r25.u64 << 32), 5) & 0xFFFFFFE0;
	// lwz r10,0(r28)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r28.u32 + 0);
	// mr r3,r24
	ctx.r3.u64 = ctx.r24.u64;
	// add r11,r11,r29
	ctx.r11.u64 = ctx.r11.u64 + ctx.r29.u64;
	// addi r4,r11,8
	ctx.r4.s64 = ctx.r11.s64 + 8;
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B0B3218;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// clrlwi r9,r3,24
	ctx.r9.u64 = ctx.r3.u32 & 0xFF;
	// cmplwi cr6,r9,0
	ctx.cr6.compare<uint32_t>(ctx.r9.u32, 0, ctx.xer);
	// beq cr6,0x8b0b3280
	if (ctx.cr6.eq) goto loc_8B0B3280;
	// lwz r11,20800(r26)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r26.u32 + 20800);
	// clrlwi r10,r11,31
	ctx.r10.u64 = ctx.r11.u32 & 0x1;
	// cmplwi cr6,r10,0
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 0, ctx.xer);
	// bne cr6,0x8b0b325c
	if (!ctx.cr6.eq) goto loc_8B0B325C;
	// ori r11,r11,1
	ctx.r11.u64 = ctx.r11.u64 | 1;
	// sth r30,0(r31)
	REX_STORE_U16(ctx.r31.u32 + 0, ctx.r30.u16);
	// mr r10,r30
	ctx.r10.u64 = ctx.r30.u64;
	// sth r30,2(r31)
	REX_STORE_U16(ctx.r31.u32 + 2, ctx.r30.u16);
	// li r10,1
	ctx.r10.s64 = 1;
	// stw r11,20800(r26)
	REX_STORE_U32(ctx.r26.u32 + 20800, ctx.r11.u32);
	// mr r9,r30
	ctx.r9.u64 = ctx.r30.u64;
	// sth r30,4(r31)
	REX_STORE_U16(ctx.r31.u32 + 4, ctx.r30.u16);
	// mr r11,r30
	ctx.r11.u64 = ctx.r30.u64;
	// sth r10,6(r31)
	REX_STORE_U16(ctx.r31.u32 + 6, ctx.r10.u16);
loc_8B0B325C:
	// cmplwi cr6,r25,65535
	ctx.cr6.compare<uint32_t>(ctx.r25.u32, 65535, ctx.xer);
	// beq cr6,0x8b0b3274
	if (ctx.cr6.eq) goto loc_8B0B3274;
	// lwz r11,4(r28)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r28.u32 + 4);
	// add r11,r11,r29
	ctx.r11.u64 = ctx.r11.u64 + ctx.r29.u64;
	// lhz r27,0(r11)
	ctx.r27.u64 = REX_LOAD_U16(ctx.r11.u32 + 0);
	// b 0x8b0b32fc
	goto loc_8B0B32FC;
loc_8B0B3274:
	// lhz r27,0(r31)
	ctx.r27.u64 = REX_LOAD_U16(ctx.r31.u32 + 0);
	// mr r11,r31
	ctx.r11.u64 = ctx.r31.u64;
	// b 0x8b0b32fc
	goto loc_8B0B32FC;
loc_8B0B3280:
	// lwz r11,4(r28)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r28.u32 + 4);
	// mr r4,r24
	ctx.r4.u64 = ctx.r24.u64;
	// lwz r10,0(r28)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r28.u32 + 0);
	// add r11,r11,r29
	ctx.r11.u64 = ctx.r11.u64 + ctx.r29.u64;
	// addi r3,r11,8
	ctx.r3.s64 = ctx.r11.s64 + 8;
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B0B329C;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// clrlwi r9,r3,24
	ctx.r9.u64 = ctx.r3.u32 & 0xFF;
	// cmplwi cr6,r9,0
	ctx.cr6.compare<uint32_t>(ctx.r9.u32, 0, ctx.xer);
	// beq cr6,0x8b0b3308
	if (ctx.cr6.eq) goto loc_8B0B3308;
	// lwz r11,20800(r26)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r26.u32 + 20800);
	// clrlwi r10,r11,31
	ctx.r10.u64 = ctx.r11.u32 & 0x1;
	// cmplwi cr6,r10,0
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 0, ctx.xer);
	// bne cr6,0x8b0b32e0
	if (!ctx.cr6.eq) goto loc_8B0B32E0;
	// ori r11,r11,1
	ctx.r11.u64 = ctx.r11.u64 | 1;
	// sth r30,0(r31)
	REX_STORE_U16(ctx.r31.u32 + 0, ctx.r30.u16);
	// mr r10,r30
	ctx.r10.u64 = ctx.r30.u64;
	// sth r30,2(r31)
	REX_STORE_U16(ctx.r31.u32 + 2, ctx.r30.u16);
	// li r10,1
	ctx.r10.s64 = 1;
	// stw r11,20800(r26)
	REX_STORE_U32(ctx.r26.u32 + 20800, ctx.r11.u32);
	// mr r9,r30
	ctx.r9.u64 = ctx.r30.u64;
	// sth r30,4(r31)
	REX_STORE_U16(ctx.r31.u32 + 4, ctx.r30.u16);
	// mr r11,r30
	ctx.r11.u64 = ctx.r30.u64;
	// sth r10,6(r31)
	REX_STORE_U16(ctx.r31.u32 + 6, ctx.r10.u16);
loc_8B0B32E0:
	// cmplwi cr6,r25,65535
	ctx.cr6.compare<uint32_t>(ctx.r25.u32, 65535, ctx.xer);
	// beq cr6,0x8b0b32f4
	if (ctx.cr6.eq) goto loc_8B0B32F4;
	// lwz r11,4(r28)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r28.u32 + 4);
	// add r11,r11,r29
	ctx.r11.u64 = ctx.r11.u64 + ctx.r29.u64;
	// b 0x8b0b32f8
	goto loc_8B0B32F8;
loc_8B0B32F4:
	// mr r11,r31
	ctx.r11.u64 = ctx.r31.u64;
loc_8B0B32F8:
	// lhz r27,2(r11)
	ctx.r27.u64 = REX_LOAD_U16(ctx.r11.u32 + 2);
loc_8B0B32FC:
	// clrlwi r25,r27,16
	ctx.r25.u64 = ctx.r27.u32 & 0xFFFF;
	// cmplwi cr6,r25,65535
	ctx.cr6.compare<uint32_t>(ctx.r25.u32, 65535, ctx.xer);
	// bne cr6,0x8b0b31f8
	if (!ctx.cr6.eq) goto loc_8B0B31F8;
loc_8B0B3308:
	// mr r3,r27
	ctx.r3.u64 = ctx.r27.u64;
	// addi r1,r1,160
	ctx.r1.s64 = ctx.r1.s64 + 160;
	// b 0x8b0cb9f8
	__restgprlr_24(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0B3538) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9b0
	ctx.lr = 0x8B0B3540;
	__savegprlr_26(ctx, base);
	// stwu r1,-144(r1)
	ea = -144 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lis r29,-29938
	ctx.r29.s64 = -1962016768;
	// lis r11,-29938
	ctx.r11.s64 = -1962016768;
	// lis r10,0
	ctx.r10.s64 = 0;
	// addi r31,r11,20792
	ctx.r31.s64 = ctx.r11.s64 + 20792;
	// mr r26,r3
	ctx.r26.u64 = ctx.r3.u64;
	// lwz r11,20800(r29)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r29.u32 + 20800);
	// mr r27,r4
	ctx.r27.u64 = ctx.r4.u64;
	// ori r30,r10,65535
	ctx.r30.u64 = ctx.r10.u64 | 65535;
	// clrlwi r9,r11,31
	ctx.r9.u64 = ctx.r11.u32 & 0x1;
	// cmplwi cr6,r9,0
	ctx.cr6.compare<uint32_t>(ctx.r9.u32, 0, ctx.xer);
	// bne cr6,0x8b0b3598
	if (!ctx.cr6.eq) goto loc_8B0B3598;
	// ori r11,r11,1
	ctx.r11.u64 = ctx.r11.u64 | 1;
	// sth r30,0(r31)
	REX_STORE_U16(ctx.r31.u32 + 0, ctx.r30.u16);
	// mr r10,r30
	ctx.r10.u64 = ctx.r30.u64;
	// sth r30,2(r31)
	REX_STORE_U16(ctx.r31.u32 + 2, ctx.r30.u16);
	// li r10,1
	ctx.r10.s64 = 1;
	// stw r11,20800(r29)
	REX_STORE_U32(ctx.r29.u32 + 20800, ctx.r11.u32);
	// mr r9,r30
	ctx.r9.u64 = ctx.r30.u64;
	// sth r30,4(r31)
	REX_STORE_U16(ctx.r31.u32 + 4, ctx.r30.u16);
	// mr r11,r30
	ctx.r11.u64 = ctx.r30.u64;
	// sth r10,6(r31)
	REX_STORE_U16(ctx.r31.u32 + 6, ctx.r10.u16);
loc_8B0B3598:
	// clrlwi r11,r27,16
	ctx.r11.u64 = ctx.r27.u32 & 0xFFFF;
	// cmplwi cr6,r11,65535
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 65535, ctx.xer);
	// beq cr6,0x8b0b35b4
	if (ctx.cr6.eq) goto loc_8B0B35B4;
	// lwz r10,4(r26)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r26.u32 + 4);
	// rlwinm r11,r11,5,0,26
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 5) & 0xFFFFFFE0;
	// add r11,r11,r10
	ctx.r11.u64 = ctx.r11.u64 + ctx.r10.u64;
	// b 0x8b0b35b8
	goto loc_8B0B35B8;
loc_8B0B35B4:
	// mr r11,r31
	ctx.r11.u64 = ctx.r31.u64;
loc_8B0B35B8:
	// lhz r11,2(r11)
	ctx.r11.u64 = REX_LOAD_U16(ctx.r11.u32 + 2);
	// mr r4,r27
	ctx.r4.u64 = ctx.r27.u64;
	// mr r3,r26
	ctx.r3.u64 = ctx.r26.u64;
	// cmplwi cr6,r11,65535
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 65535, ctx.xer);
	// beq cr6,0x8b0b3690
	if (ctx.cr6.eq) goto loc_8B0B3690;
	// bl 0x8b0b2268
	ctx.lr = 0x8B0B35D0;
	sub_8B0B2268(ctx, base);
	// lwz r11,20800(r29)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r29.u32 + 20800);
loc_8B0B35D4:
	// clrlwi r10,r11,31
	ctx.r10.u64 = ctx.r11.u32 & 0x1;
	// cmplwi cr6,r10,0
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 0, ctx.xer);
	// bne cr6,0x8b0b3608
	if (!ctx.cr6.eq) goto loc_8B0B3608;
	// mr r10,r30
	ctx.r10.u64 = ctx.r30.u64;
	// sth r30,0(r31)
	REX_STORE_U16(ctx.r31.u32 + 0, ctx.r30.u16);
	// ori r11,r11,1
	ctx.r11.u64 = ctx.r11.u64 | 1;
	// sth r30,2(r31)
	REX_STORE_U16(ctx.r31.u32 + 2, ctx.r30.u16);
	// li r10,1
	ctx.r10.s64 = 1;
	// sth r30,4(r31)
	REX_STORE_U16(ctx.r31.u32 + 4, ctx.r30.u16);
	// mr r9,r30
	ctx.r9.u64 = ctx.r30.u64;
	// stw r11,20800(r29)
	REX_STORE_U32(ctx.r29.u32 + 20800, ctx.r11.u32);
	// mr r8,r30
	ctx.r8.u64 = ctx.r30.u64;
	// sth r10,6(r31)
	REX_STORE_U16(ctx.r31.u32 + 6, ctx.r10.u16);
loc_8B0B3608:
	// clrlwi r7,r3,16
	ctx.r7.u64 = ctx.r3.u32 & 0xFFFF;
	// cmplwi cr6,r7,65535
	ctx.cr6.compare<uint32_t>(ctx.r7.u32, 65535, ctx.xer);
	// beq cr6,0x8b0b3624
	if (ctx.cr6.eq) goto loc_8B0B3624;
	// lwz r9,4(r26)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r26.u32 + 4);
	// rlwinm r10,r7,5,0,26
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r7.u32 | (ctx.r7.u64 << 32), 5) & 0xFFFFFFE0;
	// add r10,r10,r9
	ctx.r10.u64 = ctx.r10.u64 + ctx.r9.u64;
	// b 0x8b0b3628
	goto loc_8B0B3628;
loc_8B0B3624:
	// mr r10,r31
	ctx.r10.u64 = ctx.r31.u64;
loc_8B0B3628:
	// lhz r10,0(r10)
	ctx.r10.u64 = REX_LOAD_U16(ctx.r10.u32 + 0);
	// cmplwi cr6,r10,65535
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 65535, ctx.xer);
	// beq cr6,0x8b0b3720
	if (ctx.cr6.eq) goto loc_8B0B3720;
	// clrlwi r10,r11,31
	ctx.r10.u64 = ctx.r11.u32 & 0x1;
	// cmplwi cr6,r10,0
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 0, ctx.xer);
	// bne cr6,0x8b0b3668
	if (!ctx.cr6.eq) goto loc_8B0B3668;
	// mr r10,r30
	ctx.r10.u64 = ctx.r30.u64;
	// sth r30,0(r31)
	REX_STORE_U16(ctx.r31.u32 + 0, ctx.r30.u16);
	// ori r11,r11,1
	ctx.r11.u64 = ctx.r11.u64 | 1;
	// sth r30,2(r31)
	REX_STORE_U16(ctx.r31.u32 + 2, ctx.r30.u16);
	// li r10,1
	ctx.r10.s64 = 1;
	// sth r30,4(r31)
	REX_STORE_U16(ctx.r31.u32 + 4, ctx.r30.u16);
	// mr r9,r30
	ctx.r9.u64 = ctx.r30.u64;
	// stw r11,20800(r29)
	REX_STORE_U32(ctx.r29.u32 + 20800, ctx.r11.u32);
	// mr r8,r30
	ctx.r8.u64 = ctx.r30.u64;
	// sth r10,6(r31)
	REX_STORE_U16(ctx.r31.u32 + 6, ctx.r10.u16);
loc_8B0B3668:
	// cmplwi cr6,r7,65535
	ctx.cr6.compare<uint32_t>(ctx.r7.u32, 65535, ctx.xer);
	// beq cr6,0x8b0b3684
	if (ctx.cr6.eq) goto loc_8B0B3684;
	// lwz r9,4(r26)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r26.u32 + 4);
	// rlwinm r10,r7,5,0,26
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r7.u32 | (ctx.r7.u64 << 32), 5) & 0xFFFFFFE0;
	// add r10,r10,r9
	ctx.r10.u64 = ctx.r10.u64 + ctx.r9.u64;
	// lhz r3,0(r10)
	ctx.r3.u64 = REX_LOAD_U16(ctx.r10.u32 + 0);
	// b 0x8b0b35d4
	goto loc_8B0B35D4;
loc_8B0B3684:
	// lhz r3,0(r31)
	ctx.r3.u64 = REX_LOAD_U16(ctx.r31.u32 + 0);
	// mr r10,r31
	ctx.r10.u64 = ctx.r31.u64;
	// b 0x8b0b35d4
	goto loc_8B0B35D4;
loc_8B0B3690:
	// bl 0x8b0b2190
	ctx.lr = 0x8B0B3694;
	sub_8B0B2190(ctx, base);
	// mr r28,r3
	ctx.r28.u64 = ctx.r3.u64;
	// mr r4,r27
	ctx.r4.u64 = ctx.r27.u64;
	// mr r3,r26
	ctx.r3.u64 = ctx.r26.u64;
	// bl 0x8b0b22d0
	ctx.lr = 0x8B0B36A4;
	sub_8B0B22D0(ctx, base);
	// clrlwi r11,r3,24
	ctx.r11.u64 = ctx.r3.u32 & 0xFF;
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// beq cr6,0x8b0b371c
	if (ctx.cr6.eq) goto loc_8B0B371C;
loc_8B0B36B0:
	// clrlwi r8,r28,16
	ctx.r8.u64 = ctx.r28.u32 & 0xFFFF;
	// cmplwi cr6,r8,65535
	ctx.cr6.compare<uint32_t>(ctx.r8.u32, 65535, ctx.xer);
	// beq cr6,0x8b0b371c
	if (ctx.cr6.eq) goto loc_8B0B371C;
	// lwz r11,20800(r29)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r29.u32 + 20800);
	// clrlwi r10,r11,31
	ctx.r10.u64 = ctx.r11.u32 & 0x1;
	// cmplwi cr6,r10,0
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 0, ctx.xer);
	// bne cr6,0x8b0b36f4
	if (!ctx.cr6.eq) goto loc_8B0B36F4;
	// ori r11,r11,1
	ctx.r11.u64 = ctx.r11.u64 | 1;
	// sth r30,0(r31)
	REX_STORE_U16(ctx.r31.u32 + 0, ctx.r30.u16);
	// mr r10,r30
	ctx.r10.u64 = ctx.r30.u64;
	// sth r30,2(r31)
	REX_STORE_U16(ctx.r31.u32 + 2, ctx.r30.u16);
	// li r10,1
	ctx.r10.s64 = 1;
	// stw r11,20800(r29)
	REX_STORE_U32(ctx.r29.u32 + 20800, ctx.r11.u32);
	// mr r9,r30
	ctx.r9.u64 = ctx.r30.u64;
	// sth r30,4(r31)
	REX_STORE_U16(ctx.r31.u32 + 4, ctx.r30.u16);
	// mr r11,r30
	ctx.r11.u64 = ctx.r30.u64;
	// sth r10,6(r31)
	REX_STORE_U16(ctx.r31.u32 + 6, ctx.r10.u16);
loc_8B0B36F4:
	// lwz r10,4(r26)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r26.u32 + 4);
	// rlwinm r11,r8,5,0,26
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r8.u32 | (ctx.r8.u64 << 32), 5) & 0xFFFFFFE0;
	// mr r4,r28
	ctx.r4.u64 = ctx.r28.u64;
	// add r11,r11,r10
	ctx.r11.u64 = ctx.r11.u64 + ctx.r10.u64;
	// mr r3,r26
	ctx.r3.u64 = ctx.r26.u64;
	// lhz r28,4(r11)
	ctx.r28.u64 = REX_LOAD_U16(ctx.r11.u32 + 4);
	// bl 0x8b0b22d0
	ctx.lr = 0x8B0B3710;
	sub_8B0B22D0(ctx, base);
	// clrlwi r11,r3,24
	ctx.r11.u64 = ctx.r3.u32 & 0xFF;
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// bne cr6,0x8b0b36b0
	if (!ctx.cr6.eq) goto loc_8B0B36B0;
loc_8B0B371C:
	// mr r3,r28
	ctx.r3.u64 = ctx.r28.u64;
loc_8B0B3720:
	// addi r1,r1,144
	ctx.r1.s64 = ctx.r1.s64 + 144;
	// b 0x8b0cba00
	__restgprlr_26(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0B49E8) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// std r30,-24(r1)
	REX_STORE_U64(ctx.r1.u32 + -24, ctx.r30.u64);
	// std r31,-16(r1)
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.r31.u64);
	// stwu r1,-112(r1)
	ea = -112 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// mr r30,r4
	ctx.r30.u64 = ctx.r4.u64;
	// bl 0x8b0b45f0
	ctx.lr = 0x8B0B4A08;
	sub_8B0B45F0(ctx, base);
	// clrlwi r11,r30,31
	ctx.r11.u64 = ctx.r30.u32 & 0x1;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// beq cr6,0x8b0b4a20
	if (ctx.cr6.eq) goto loc_8B0B4A20;
	// bl 0x8b090020
	ctx.lr = 0x8B0B4A1C;
	sub_8B090020(ctx, base);
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
loc_8B0B4A20:
	// addi r1,r1,112
	ctx.r1.s64 = ctx.r1.s64 + 112;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// ld r30,-24(r1)
	ctx.r30.u64 = REX_LOAD_U64(ctx.r1.u32 + -24);
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0B4AB0) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9a8
	ctx.lr = 0x8B0B4AB8;
	__savegprlr_24(ctx, base);
	// stwu r1,-176(r1)
	ea = -176 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// mr r29,r3
	ctx.r29.u64 = ctx.r3.u64;
	// bl 0x8b0bc2e0
	ctx.lr = 0x8B0B4AC4;
	sub_8B0BC2E0(ctx, base);
	// lwz r11,0(r29)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r29.u32 + 0);
	// li r24,0
	ctx.r24.s64 = 0;
	// mr r3,r29
	ctx.r3.u64 = ctx.r29.u64;
	// mr r28,r24
	ctx.r28.u64 = ctx.r24.u64;
	// lwz r10,40(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 40);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B0B4AE0;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// lis r11,-29938
	ctx.r11.s64 = -1962016768;
	// mr r25,r3
	ctx.r25.u64 = ctx.r3.u64;
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// addi r26,r11,6476
	ctx.r26.s64 = ctx.r11.s64 + 6476;
	// ble cr6,0x8b0b4bac
	if (!ctx.cr6.gt) goto loc_8B0B4BAC;
loc_8B0B4AF4:
	// lwz r11,0(r29)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r29.u32 + 0);
	// mr r4,r28
	ctx.r4.u64 = ctx.r28.u64;
	// mr r3,r29
	ctx.r3.u64 = ctx.r29.u64;
	// lwz r10,44(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 44);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B0B4B0C;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// mr r27,r3
	ctx.r27.u64 = ctx.r3.u64;
	// mr r3,r26
	ctx.r3.u64 = ctx.r26.u64;
	// addi r4,r1,80
	ctx.r4.s64 = ctx.r1.s64 + 80;
	// ld r9,0(r27)
	ctx.r9.u64 = REX_LOAD_U64(ctx.r27.u32 + 0);
	// std r9,80(r1)
	REX_STORE_U64(ctx.r1.u32 + 80, ctx.r9.u64);
	// bl 0x8b0b31c0
	ctx.lr = 0x8B0B4B24;
	sub_8B0B31C0(ctx, base);
	// clrlwi r8,r3,16
	ctx.r8.u64 = ctx.r3.u32 & 0xFFFF;
	// cmplwi cr6,r8,65535
	ctx.cr6.compare<uint32_t>(ctx.r8.u32, 65535, ctx.xer);
	// bne cr6,0x8b0b4ba0
	if (!ctx.cr6.eq) goto loc_8B0B4BA0;
	// lwz r11,180(r29)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r29.u32 + 180);
	// addi r31,r11,24
	ctx.r31.s64 = ctx.r11.s64 + 24;
	// lwz r11,28(r11)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r11.u32 + 28);
	// lwz r30,12(r31)
	ctx.r30.u64 = REX_LOAD_U32(ctx.r31.u32 + 12);
	// addi r10,r30,1
	ctx.r10.s64 = ctx.r30.s64 + 1;
	// cmpw cr6,r10,r11
	ctx.cr6.compare<int32_t>(ctx.r10.s32, ctx.r11.s32, ctx.xer);
	// ble cr6,0x8b0b4b5c
	if (!ctx.cr6.gt) goto loc_8B0B4B5C;
	// subf r11,r11,r30
	ctx.r11.u64 = ctx.r30.u64 - ctx.r11.u64;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// addi r4,r11,1
	ctx.r4.s64 = ctx.r11.s64 + 1;
	// bl 0x8b0bc490
	ctx.lr = 0x8B0B4B5C;
	sub_8B0BC490(ctx, base);
loc_8B0B4B5C:
	// lwz r11,12(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 12);
	// addi r11,r11,1
	ctx.r11.s64 = ctx.r11.s64 + 1;
	// subf r10,r30,r11
	ctx.r10.u64 = ctx.r11.u64 - ctx.r30.u64;
	// stw r11,12(r31)
	REX_STORE_U32(ctx.r31.u32 + 12, ctx.r11.u32);
	// addic. r11,r10,-1
	ctx.xer.ca = ctx.r10.u32 > 0;
	ctx.r11.s64 = ctx.r10.s64 + -1;
	ctx.cr0.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// ble 0x8b0b4b8c
	if (!ctx.cr0.gt) goto loc_8B0B4B8C;
	// lwz r9,0(r31)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r31.u32 + 0);
	// rlwinm r10,r30,2,0,29
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r30.u32 | (ctx.r30.u64 << 32), 2) & 0xFFFFFFFC;
	// rlwinm r5,r11,2,0,29
	ctx.r5.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 2) & 0xFFFFFFFC;
	// add r4,r10,r9
	ctx.r4.u64 = ctx.r10.u64 + ctx.r9.u64;
	// addi r3,r4,4
	ctx.r3.s64 = ctx.r4.s64 + 4;
	// bl 0x8b0cc060
	ctx.lr = 0x8B0B4B8C;
	sub_8B0CC060(ctx, base);
loc_8B0B4B8C:
	// lwz r10,0(r31)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r31.u32 + 0);
	// rlwinm r11,r30,2,0,29
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r30.u32 | (ctx.r30.u64 << 32), 2) & 0xFFFFFFFC;
	// add. r11,r11,r10
	ctx.r11.u64 = ctx.r11.u64 + ctx.r10.u64;
	ctx.cr0.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// beq 0x8b0b4ba0
	if (ctx.cr0.eq) goto loc_8B0B4BA0;
	// stw r27,0(r11)
	REX_STORE_U32(ctx.r11.u32 + 0, ctx.r27.u32);
loc_8B0B4BA0:
	// addi r28,r28,1
	ctx.r28.s64 = ctx.r28.s64 + 1;
	// cmpw cr6,r28,r25
	ctx.cr6.compare<int32_t>(ctx.r28.s32, ctx.r25.s32, ctx.xer);
	// blt cr6,0x8b0b4af4
	if (ctx.cr6.lt) goto loc_8B0B4AF4;
loc_8B0B4BAC:
	// lwz r31,180(r29)
	ctx.r31.u64 = REX_LOAD_U32(ctx.r29.u32 + 180);
	// lwz r4,36(r31)
	ctx.r4.u64 = REX_LOAD_U32(ctx.r31.u32 + 36);
	// cmpwi cr6,r4,0
	ctx.cr6.compare<int32_t>(ctx.r4.s32, 0, ctx.xer);
	// bne cr6,0x8b0b4bfc
	if (!ctx.cr6.eq) goto loc_8B0B4BFC;
	// li r10,4
	ctx.r10.s64 = 4;
	// mr r3,r26
	ctx.r3.u64 = ctx.r26.u64;
	// stw r10,20(r31)
	REX_STORE_U32(ctx.r31.u32 + 20, ctx.r10.u32);
	// mr r11,r24
	ctx.r11.u64 = ctx.r24.u64;
	// stw r24,28(r26)
	REX_STORE_U32(ctx.r26.u32 + 28, ctx.r24.u32);
	// bl 0x8b0b3318
	ctx.lr = 0x8B0B4BD4;
	sub_8B0B3318(ctx, base);
	// lwz r4,8(r31)
	ctx.r4.u64 = REX_LOAD_U32(ctx.r31.u32 + 8);
	// stw r24,8(r31)
	REX_STORE_U32(ctx.r31.u32 + 8, ctx.r24.u32);
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// stw r24,12(r31)
	REX_STORE_U32(ctx.r31.u32 + 12, ctx.r24.u32);
	// lwz r9,0(r31)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r31.u32 + 0);
	// lwz r8,40(r9)
	ctx.r8.u64 = REX_LOAD_U32(ctx.r9.u32 + 40);
	// mtctr r8
	ctx.ctr.u64 = ctx.r8.u64;
	// bctrl 
	ctx.lr = 0x8B0B4BF4;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// addi r1,r1,176
	ctx.r1.s64 = ctx.r1.s64 + 176;
	// b 0x8b0cb9f8
	__restgprlr_24(ctx, base);
	return;
loc_8B0B4BFC:
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// addi r3,r11,29756
	ctx.r3.s64 = ctx.r11.s64 + 29756;
	// bl 0x8b0df298
	ctx.lr = 0x8B0B4C08;
	sub_8B0DF298(ctx, base);
	// lwz r9,180(r29)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r29.u32 + 180);
	// li r10,2
	ctx.r10.s64 = 2;
	// stw r10,20(r9)
	REX_STORE_U32(ctx.r9.u32 + 20, ctx.r10.u32);
	// addi r1,r1,176
	ctx.r1.s64 = ctx.r1.s64 + 176;
	// b 0x8b0cb9f8
	__restgprlr_24(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0B4DF8) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9bc
	ctx.lr = 0x8B0B4E00;
	__savegprlr_29(ctx, base);
	// stwu r1,-176(r1)
	ea = -176 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// ld r11,0(r4)
	ctx.r11.u64 = REX_LOAD_U64(ctx.r4.u32 + 0);
	// mr r29,r4
	ctx.r29.u64 = ctx.r4.u64;
	// addi r4,r1,112
	ctx.r4.s64 = ctx.r1.s64 + 112;
	// mr r30,r3
	ctx.r30.u64 = ctx.r3.u64;
	// mr r31,r5
	ctx.r31.u64 = ctx.r5.u64;
	// std r11,112(r1)
	REX_STORE_U64(ctx.r1.u32 + 112, ctx.r11.u64);
	// bl 0x8b0b31c0
	ctx.lr = 0x8B0B4E20;
	sub_8B0B31C0(ctx, base);
	// clrlwi r11,r3,16
	ctx.r11.u64 = ctx.r3.u32 & 0xFFFF;
	// ld r9,0(r31)
	ctx.r9.u64 = REX_LOAD_U64(ctx.r31.u32 + 0);
	// cmplwi cr6,r11,65535
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 65535, ctx.xer);
	// beq cr6,0x8b0b4e54
	if (ctx.cr6.eq) goto loc_8B0B4E54;
	// lwz r10,4(r30)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r30.u32 + 4);
	// rlwinm r11,r11,5,0,26
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 5) & 0xFFFFFFE0;
	// add r11,r11,r10
	ctx.r11.u64 = ctx.r11.u64 + ctx.r10.u64;
	// addi r8,r11,16
	ctx.r8.s64 = ctx.r11.s64 + 16;
	// std r9,16(r11)
	REX_STORE_U64(ctx.r11.u32 + 16, ctx.r9.u64);
	// ld r7,8(r31)
	ctx.r7.u64 = REX_LOAD_U64(ctx.r31.u32 + 8);
	// std r7,24(r11)
	REX_STORE_U64(ctx.r11.u32 + 24, ctx.r7.u64);
	// addi r1,r1,176
	ctx.r1.s64 = ctx.r1.s64 + 176;
	// b 0x8b0cba0c
	__restgprlr_29(ctx, base);
	return;
loc_8B0B4E54:
	// ld r11,0(r29)
	ctx.r11.u64 = REX_LOAD_U64(ctx.r29.u32 + 0);
	// addi r10,r1,88
	ctx.r10.s64 = ctx.r1.s64 + 88;
	// ld r8,8(r31)
	ctx.r8.u64 = REX_LOAD_U64(ctx.r31.u32 + 8);
	// addi r4,r1,80
	ctx.r4.s64 = ctx.r1.s64 + 80;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// std r11,80(r1)
	REX_STORE_U64(ctx.r1.u32 + 80, ctx.r11.u64);
	// std r9,0(r10)
	REX_STORE_U64(ctx.r10.u32 + 0, ctx.r9.u64);
	// std r8,8(r10)
	REX_STORE_U64(ctx.r10.u32 + 8, ctx.r8.u64);
	// bl 0x8b0b4c20
	ctx.lr = 0x8B0B4E78;
	sub_8B0B4C20(ctx, base);
	// addi r1,r1,176
	ctx.r1.s64 = ctx.r1.s64 + 176;
	// b 0x8b0cba0c
	__restgprlr_29(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0B4E80) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9bc
	ctx.lr = 0x8B0B4E88;
	__savegprlr_29(ctx, base);
	// stwu r1,-272(r1)
	ea = -272 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lwz r11,36(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 36);
	// mr r30,r3
	ctx.r30.u64 = ctx.r3.u64;
	// cmpwi cr6,r11,0
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// bne cr6,0x8b0b4ea8
	if (!ctx.cr6.eq) goto loc_8B0B4EA8;
	// bl 0x8b0b4a38
	ctx.lr = 0x8B0B4EA0;
	sub_8B0B4A38(ctx, base);
	// addi r1,r1,272
	ctx.r1.s64 = ctx.r1.s64 + 272;
	// b 0x8b0cba0c
	__restgprlr_29(ctx, base);
	return;
loc_8B0B4EA8:
	// li r3,36
	ctx.r3.s64 = 36;
	// bl 0x8b0bf448
	ctx.lr = 0x8B0B4EB0;
	sub_8B0BF448(ctx, base);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0b4ee8
	if (ctx.cr6.eq) goto loc_8B0B4EE8;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// addi r6,r11,28164
	ctx.r6.s64 = ctx.r11.s64 + 28164;
	// lis r9,-29944
	ctx.r9.s64 = -1962409984;
	// lis r4,-29944
	ctx.r4.s64 = -1962409984;
	// mr r7,r6
	ctx.r7.u64 = ctx.r6.u64;
	// addi r8,r10,29864
	ctx.r8.s64 = ctx.r10.s64 + 29864;
	// addi r5,r9,4072
	ctx.r5.s64 = ctx.r9.s64 + 4072;
	// addi r4,r4,4080
	ctx.r4.s64 = ctx.r4.s64 + 4080;
	// bl 0x8b0c1438
	ctx.lr = 0x8B0B4EE0;
	sub_8B0C1438(ctx, base);
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// b 0x8b0b4eec
	goto loc_8B0B4EEC;
loc_8B0B4EE8:
	// li r31,0
	ctx.r31.s64 = 0;
loc_8B0B4EEC:
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lwz r5,36(r30)
	ctx.r5.u64 = REX_LOAD_U32(ctx.r30.u32 + 36);
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// addi r4,r11,28416
	ctx.r4.s64 = ctx.r11.s64 + 28416;
	// bl 0x8b0c0148
	ctx.lr = 0x8B0B4F00;
	sub_8B0C0148(ctx, base);
	// lwz r10,0(r30)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r30.u32 + 0);
	// mr r4,r31
	ctx.r4.u64 = ctx.r31.u64;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// lwz r9,48(r10)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r10.u32 + 48);
	// mtctr r9
	ctx.ctr.u64 = ctx.r9.u64;
	// bctrl 
	ctx.lr = 0x8B0B4F18;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// lwz r8,24(r30)
	ctx.r8.u64 = REX_LOAD_U32(ctx.r30.u32 + 24);
	// addi r31,r30,24
	ctx.r31.s64 = ctx.r30.s64 + 24;
	// lwz r7,36(r30)
	ctx.r7.u64 = REX_LOAD_U32(ctx.r30.u32 + 36);
	// addic. r11,r7,-1
	ctx.xer.ca = ctx.r7.u32 > 0;
	ctx.r11.s64 = ctx.r7.s64 + -1;
	ctx.cr0.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// lwz r29,0(r8)
	ctx.r29.u64 = REX_LOAD_U32(ctx.r8.u32 + 0);
	// ble 0x8b0b4f40
	if (!ctx.cr0.gt) goto loc_8B0B4F40;
	// lwz r3,0(r31)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r31.u32 + 0);
	// rlwinm r5,r11,2,0,29
	ctx.r5.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 2) & 0xFFFFFFFC;
	// addi r4,r3,4
	ctx.r4.s64 = ctx.r3.s64 + 4;
	// bl 0x8b0cc060
	ctx.lr = 0x8B0B4F40;
	sub_8B0CC060(ctx, base);
loc_8B0B4F40:
	// lwz r11,12(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 12);
	// addi r11,r11,-1
	ctx.r11.s64 = ctx.r11.s64 + -1;
	// stw r11,12(r31)
	REX_STORE_U32(ctx.r31.u32 + 12, ctx.r11.u32);
	// ld r11,0(r29)
	ctx.r11.u64 = REX_LOAD_U64(ctx.r29.u32 + 0);
	// cmpldi cr6,r11,0
	ctx.cr6.compare<uint64_t>(ctx.r11.u64, 0, ctx.xer);
	// std r11,80(r1)
	REX_STORE_U64(ctx.r1.u32 + 80, ctx.r11.u64);
	// beq cr6,0x8b0b4f80
	if (ctx.cr6.eq) goto loc_8B0B4F80;
	// bl 0x8b0df2f8
	ctx.lr = 0x8B0B4F60;
	sub_8B0DF2F8(ctx, base);
	// lis r11,-29938
	ctx.r11.s64 = -1962016768;
	// stfd f1,96(r1)
	ctx.fpscr.disableFlushMode();
	REX_STORE_U64(ctx.r1.u32 + 96, ctx.f1.u64);
	// addi r5,r1,96
	ctx.r5.s64 = ctx.r1.s64 + 96;
	// addi r3,r11,6476
	ctx.r3.s64 = ctx.r11.s64 + 6476;
	// addi r4,r1,80
	ctx.r4.s64 = ctx.r1.s64 + 80;
	// lwz r11,28(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 28);
	// stw r11,104(r1)
	REX_STORE_U32(ctx.r1.u32 + 104, ctx.r11.u32);
	// bl 0x8b0b4df8
	ctx.lr = 0x8B0B4F80;
	sub_8B0B4DF8(ctx, base);
loc_8B0B4F80:
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lwz r3,8(r30)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r30.u32 + 8);
	// li r5,1
	ctx.r5.s64 = 1;
	// addi r4,r11,9156
	ctx.r4.s64 = ctx.r11.s64 + 9156;
	// bl 0x8b0bfa88
	ctx.lr = 0x8B0B4F94;
	sub_8B0BFA88(ctx, base);
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0b4fe8
	if (ctx.cr6.eq) goto loc_8B0B4FE8;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// ld r5,0(r29)
	ctx.r5.u64 = REX_LOAD_U64(ctx.r29.u32 + 0);
	// addi r4,r11,13260
	ctx.r4.s64 = ctx.r11.s64 + 13260;
	// bl 0x8b0c0190
	ctx.lr = 0x8B0B4FB0;
	sub_8B0C0190(ctx, base);
	// li r10,0
	ctx.r10.s64 = 0;
	// li r5,120
	ctx.r5.s64 = 120;
	// li r4,0
	ctx.r4.s64 = 0;
	// stb r10,112(r1)
	REX_STORE_U8(ctx.r1.u32 + 112, ctx.r10.u8);
	// addi r3,r1,113
	ctx.r3.s64 = ctx.r1.s64 + 113;
	// bl 0x8b0cb8e0
	ctx.lr = 0x8B0B4FC8;
	sub_8B0CB8E0(ctx, base);
	// addi r4,r1,112
	ctx.r4.s64 = ctx.r1.s64 + 112;
	// mr r3,r29
	ctx.r3.u64 = ctx.r29.u64;
	// bl 0x8b0994a8
	ctx.lr = 0x8B0B4FD4;
	sub_8B0994A8(ctx, base);
	// lis r9,-29944
	ctx.r9.s64 = -1962409984;
	// addi r5,r1,112
	ctx.r5.s64 = ctx.r1.s64 + 112;
	// addi r4,r9,13248
	ctx.r4.s64 = ctx.r9.s64 + 13248;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0c0010
	ctx.lr = 0x8B0B4FE8;
	sub_8B0C0010(ctx, base);
loc_8B0B4FE8:
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lwz r31,36(r30)
	ctx.r31.u64 = REX_LOAD_U32(ctx.r30.u32 + 36);
	// li r5,0
	ctx.r5.s64 = 0;
	// lwz r3,8(r30)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r30.u32 + 8);
	// addi r4,r11,11968
	ctx.r4.s64 = ctx.r11.s64 + 11968;
	// bl 0x8b0bfd30
	ctx.lr = 0x8B0B5000;
	sub_8B0BFD30(ctx, base);
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// addi r3,r10,29808
	ctx.r3.s64 = ctx.r10.s64 + 29808;
	// mr r5,r31
	ctx.r5.u64 = ctx.r31.u64;
	// bl 0x8b0df298
	ctx.lr = 0x8B0B5014;
	sub_8B0DF298(ctx, base);
	// li r9,3
	ctx.r9.s64 = 3;
	// lwz r8,0(r30)
	ctx.r8.u64 = REX_LOAD_U32(ctx.r30.u32 + 0);
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// stw r9,20(r30)
	REX_STORE_U32(ctx.r30.u32 + 20, ctx.r9.u32);
	// lwz r7,52(r8)
	ctx.r7.u64 = REX_LOAD_U32(ctx.r8.u32 + 52);
	// mtctr r7
	ctx.ctr.u64 = ctx.r7.u64;
	// bctrl 
	ctx.lr = 0x8B0B5030;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// stw r3,40(r30)
	REX_STORE_U32(ctx.r30.u32 + 40, ctx.r3.u32);
	// addi r1,r1,272
	ctx.r1.s64 = ctx.r1.s64 + 272;
	// b 0x8b0cba0c
	__restgprlr_29(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0B56F0) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// std r30,-24(r1)
	REX_STORE_U64(ctx.r1.u32 + -24, ctx.r30.u64);
	// std r31,-16(r1)
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.r31.u64);
	// stwu r1,-112(r1)
	ea = -112 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// stw r5,8(r3)
	REX_STORE_U32(ctx.r3.u32 + 8, ctx.r5.u32);
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// addi r9,r11,30108
	ctx.r9.s64 = ctx.r11.s64 + 30108;
	// addi r8,r10,30100
	ctx.r8.s64 = ctx.r10.s64 + 30100;
	// stw r9,0(r3)
	REX_STORE_U32(ctx.r3.u32 + 0, ctx.r9.u32);
	// li r3,36
	ctx.r3.s64 = 36;
	// stw r8,4(r31)
	REX_STORE_U32(ctx.r31.u32 + 4, ctx.r8.u32);
	// mr r30,r4
	ctx.r30.u64 = ctx.r4.u64;
	// stw r5,12(r31)
	REX_STORE_U32(ctx.r31.u32 + 12, ctx.r5.u32);
	// bl 0x8b0bf448
	ctx.lr = 0x8B0B5734;
	sub_8B0BF448(ctx, base);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0b575c
	if (ctx.cr6.eq) goto loc_8B0B575C;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// lis r9,-29944
	ctx.r9.s64 = -1962409984;
	// addi r6,r11,4560
	ctx.r6.s64 = ctx.r11.s64 + 4560;
	// addi r5,r10,4568
	ctx.r5.s64 = ctx.r10.s64 + 4568;
	// addi r4,r9,27336
	ctx.r4.s64 = ctx.r9.s64 + 27336;
	// bl 0x8b0c1300
	ctx.lr = 0x8B0B5758;
	sub_8B0C1300(ctx, base);
	// b 0x8b0b5760
	goto loc_8B0B5760;
loc_8B0B575C:
	// li r3,0
	ctx.r3.s64 = 0;
loc_8B0B5760:
	// li r11,2
	ctx.r11.s64 = 2;
	// stw r3,16(r31)
	REX_STORE_U32(ctx.r31.u32 + 16, ctx.r3.u32);
	// stw r3,20(r31)
	REX_STORE_U32(ctx.r31.u32 + 20, ctx.r3.u32);
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// stw r11,24(r31)
	REX_STORE_U32(ctx.r31.u32 + 24, ctx.r11.u32);
	// stw r30,28(r31)
	REX_STORE_U32(ctx.r31.u32 + 28, ctx.r30.u32);
	// addi r3,r10,30040
	ctx.r3.s64 = ctx.r10.s64 + 30040;
	// bl 0x8b0df298
	ctx.lr = 0x8B0B5780;
	sub_8B0DF298(ctx, base);
	// lis r9,-29944
	ctx.r9.s64 = -1962409984;
	// li r8,1
	ctx.r8.s64 = 1;
	// lwz r3,8(r31)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r31.u32 + 8);
	// addi r7,r9,1800
	ctx.r7.s64 = ctx.r9.s64 + 1800;
	// stw r8,84(r1)
	REX_STORE_U32(ctx.r1.u32 + 84, ctx.r8.u32);
	// li r5,1
	ctx.r5.s64 = 1;
	// stw r7,80(r1)
	REX_STORE_U32(ctx.r1.u32 + 80, ctx.r7.u32);
	// addi r4,r1,80
	ctx.r4.s64 = ctx.r1.s64 + 80;
	// bl 0x8b0bf510
	ctx.lr = 0x8B0B57A4;
	sub_8B0BF510(ctx, base);
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// addi r1,r1,112
	ctx.r1.s64 = ctx.r1.s64 + 112;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// ld r30,-24(r1)
	ctx.r30.u64 = REX_LOAD_U64(ctx.r1.u32 + -24);
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0B5850) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9b8
	ctx.lr = 0x8B0B5858;
	__savegprlr_28(ctx, base);
	// stwu r1,-128(r1)
	ea = -128 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// mr r29,r3
	ctx.r29.u64 = ctx.r3.u64;
	// mr r3,r4
	ctx.r3.u64 = ctx.r4.u64;
	// mr r31,r4
	ctx.r31.u64 = ctx.r4.u64;
	// bl 0x8b0beee8
	ctx.lr = 0x8B0B586C;
	sub_8B0BEEE8(ctx, base);
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// mr r28,r3
	ctx.r28.u64 = ctx.r3.u64;
	// addi r5,r11,1791
	ctx.r5.s64 = ctx.r11.s64 + 1791;
	// addi r4,r10,3900
	ctx.r4.s64 = ctx.r10.s64 + 3900;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0c1588
	ctx.lr = 0x8B0B5888;
	sub_8B0C1588(ctx, base);
	// lis r9,-29944
	ctx.r9.s64 = -1962409984;
	// mr r30,r3
	ctx.r30.u64 = ctx.r3.u64;
	// addi r4,r9,3904
	ctx.r4.s64 = ctx.r9.s64 + 3904;
	// bl 0x8b0cea10
	ctx.lr = 0x8B0B5898;
	sub_8B0CEA10(ctx, base);
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// beq cr6,0x8b0b58f0
	if (ctx.cr6.eq) goto loc_8B0B58F0;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// addi r4,r11,16332
	ctx.r4.s64 = ctx.r11.s64 + 16332;
	// bl 0x8b0cea10
	ctx.lr = 0x8B0B58B0;
	sub_8B0CEA10(ctx, base);
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// beq cr6,0x8b0b58f0
	if (ctx.cr6.eq) goto loc_8B0B58F0;
	// lbz r11,0(r30)
	ctx.r11.u64 = REX_LOAD_U8(ctx.r30.u32 + 0);
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// beq cr6,0x8b0b58dc
	if (ctx.cr6.eq) goto loc_8B0B58DC;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// addi r4,r11,28668
	ctx.r4.s64 = ctx.r11.s64 + 28668;
	// bl 0x8b0cea10
	ctx.lr = 0x8B0B58D4;
	sub_8B0CEA10(ctx, base);
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// bne cr6,0x8b0b591c
	if (!ctx.cr6.eq) goto loc_8B0B591C;
loc_8B0B58DC:
	// mr r4,r31
	ctx.r4.u64 = ctx.r31.u64;
	// mr r3,r29
	ctx.r3.u64 = ctx.r29.u64;
	// bl 0x8b0b5540
	ctx.lr = 0x8B0B58E8;
	sub_8B0B5540(ctx, base);
	// addi r1,r1,128
	ctx.r1.s64 = ctx.r1.s64 + 128;
	// b 0x8b0cba08
	__restgprlr_28(ctx, base);
	return;
loc_8B0B58F0:
	// lwz r11,28(r29)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r29.u32 + 28);
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// beq cr6,0x8b0b591c
	if (ctx.cr6.eq) goto loc_8B0B591C;
	// rotlwi r3,r11,0
	ctx.r3.u64 = __builtin_rotateleft32(ctx.r11.u32, 0);
	// mr r4,r31
	ctx.r4.u64 = ctx.r31.u64;
	// lwz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r10,24(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 24);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B0B5914;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// addi r1,r1,128
	ctx.r1.s64 = ctx.r1.s64 + 128;
	// b 0x8b0cba08
	__restgprlr_28(ctx, base);
	return;
loc_8B0B591C:
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// mr r4,r28
	ctx.r4.u64 = ctx.r28.u64;
	// addi r3,r11,28612
	ctx.r3.s64 = ctx.r11.s64 + 28612;
	// bl 0x8b0df2a8
	ctx.lr = 0x8B0B592C;
	sub_8B0DF2A8(ctx, base);
	// addi r1,r1,128
	ctx.r1.s64 = ctx.r1.s64 + 128;
	// b 0x8b0cba08
	__restgprlr_28(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0B63C0) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9bc
	ctx.lr = 0x8B0B63C8;
	__savegprlr_29(ctx, base);
	// stwu r1,-112(r1)
	ea = -112 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lwz r11,24(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 24);
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// lis r30,-29938
	ctx.r30.s64 = -1962016768;
	// cmpwi cr6,r11,5
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 5, ctx.xer);
	// beq cr6,0x8b0b6400
	if (ctx.cr6.eq) goto loc_8B0B6400;
	// lwz r11,2364(r30)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r30.u32 + 2364);
	// li r5,0
	ctx.r5.s64 = 0;
	// li r4,0
	ctx.r4.s64 = 0;
	// lwz r3,76(r11)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r11.u32 + 76);
	// lwz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r10,36(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 36);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B0B6400;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
loc_8B0B6400:
	// lwz r11,24(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 24);
	// li r29,0
	ctx.r29.s64 = 0;
	// cmpwi cr6,r11,3
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 3, ctx.xer);
	// beq cr6,0x8b0b6418
	if (ctx.cr6.eq) goto loc_8B0B6418;
	// cmpwi cr6,r11,4
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 4, ctx.xer);
	// bne cr6,0x8b0b643c
	if (!ctx.cr6.eq) goto loc_8B0B643C;
loc_8B0B6418:
	// stw r29,24(r31)
	REX_STORE_U32(ctx.r31.u32 + 24, ctx.r29.u32);
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// lwz r11,2364(r30)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r30.u32 + 2364);
	// lwz r3,84(r11)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r11.u32 + 84);
	// addi r4,r10,27560
	ctx.r4.s64 = ctx.r10.s64 + 27560;
	// lwz r9,0(r3)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r8,416(r9)
	ctx.r8.u64 = REX_LOAD_U32(ctx.r9.u32 + 416);
	// mtctr r8
	ctx.ctr.u64 = ctx.r8.u64;
	// bctrl 
	ctx.lr = 0x8B0B643C;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
loc_8B0B643C:
	// lwz r3,28(r31)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r31.u32 + 28);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0b645c
	if (ctx.cr6.eq) goto loc_8B0B645C;
	// lwz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r10,20(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 20);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B0B6458;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// stw r29,28(r31)
	REX_STORE_U32(ctx.r31.u32 + 28, ctx.r29.u32);
loc_8B0B645C:
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0b57c0
	ctx.lr = 0x8B0B6464;
	sub_8B0B57C0(ctx, base);
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b090020
	ctx.lr = 0x8B0B646C;
	sub_8B090020(ctx, base);
	// addi r1,r1,112
	ctx.r1.s64 = ctx.r1.s64 + 112;
	// b 0x8b0cba0c
	__restgprlr_29(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0B6478) {
	REX_FUNC_PROLOGUE();
	// lwz r11,440(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 440);
	// lwz r10,440(r4)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r4.u32 + 440);
	// cmpw cr6,r11,r10
	ctx.cr6.compare<int32_t>(ctx.r11.s32, ctx.r10.s32, ctx.xer);
	// beq cr6,0x8b0b6498
	if (ctx.cr6.eq) goto loc_8B0B6498;
	// li r3,-1
	ctx.r3.s64 = -1;
	// bltlr cr6
	if (ctx.cr6.lt) return;
	// li r3,1
	ctx.r3.s64 = 1;
	// blr 
	return;
loc_8B0B6498:
	// li r3,0
	ctx.r3.s64 = 0;
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0B6540) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// std r31,-16(r1)
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.r31.u64);
	// stwu r1,-96(r1)
	ea = -96 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lwz r11,444(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 444);
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// beq cr6,0x8b0b6580
	if (ctx.cr6.eq) goto loc_8B0B6580;
	// lis r11,-29938
	ctx.r11.s64 = -1962016768;
	// lwz r4,444(r3)
	ctx.r4.u64 = REX_LOAD_U32(ctx.r3.u32 + 444);
	// lwz r11,2364(r11)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r11.u32 + 2364);
	// lwz r3,104(r11)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r11.u32 + 104);
	// lwz r10,0(r3)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r9,32(r10)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r10.u32 + 32);
	// mtctr r9
	ctx.ctr.u64 = ctx.r9.u64;
	// bctrl 
	ctx.lr = 0x8B0B6580;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
loc_8B0B6580:
	// li r5,448
	ctx.r5.s64 = 448;
	// li r4,0
	ctx.r4.s64 = 0;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0cb8e0
	ctx.lr = 0x8B0B6590;
	sub_8B0CB8E0(ctx, base);
	// addi r1,r1,96
	ctx.r1.s64 = ctx.r1.s64 + 96;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0B65A8) {
	REX_FUNC_PROLOGUE();
	// lwz r11,4(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 4);
	// addi r11,r11,-3
	ctx.r11.s64 = ctx.r11.s64 + -3;
	// cntlzw r10,r11
	ctx.r10.u64 = ctx.r11.u32 == 0 ? 32 : __builtin_clz(ctx.r11.u32);
	// rlwinm r3,r10,27,31,31
	ctx.r3.u64 = __builtin_rotateleft64(ctx.r10.u32 | (ctx.r10.u64 << 32), 27) & 0x1;
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0B65C8) {
	REX_FUNC_PROLOGUE();
	// lwz r11,4(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 4);
	// addi r11,r11,-4
	ctx.r11.s64 = ctx.r11.s64 + -4;
	// cntlzw r10,r11
	ctx.r10.u64 = ctx.r11.u32 == 0 ? 32 : __builtin_clz(ctx.r11.u32);
	// rlwinm r3,r10,27,31,31
	ctx.r3.u64 = __builtin_rotateleft64(ctx.r10.u32 | (ctx.r10.u64 << 32), 27) & 0x1;
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0B6658) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9bc
	ctx.lr = 0x8B0B6660;
	__savegprlr_29(ctx, base);
	// stwu r1,-112(r1)
	ea = -112 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// mr r29,r3
	ctx.r29.u64 = ctx.r3.u64;
	// mr r3,r4
	ctx.r3.u64 = ctx.r4.u64;
	// mr r30,r4
	ctx.r30.u64 = ctx.r4.u64;
	// bl 0x8b0beee8
	ctx.lr = 0x8B0B6674;
	sub_8B0BEEE8(ctx, base);
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// addi r3,r11,30452
	ctx.r3.s64 = ctx.r11.s64 + 30452;
	// bl 0x8b0cea10
	ctx.lr = 0x8B0B6684;
	sub_8B0CEA10(ctx, base);
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// bne cr6,0x8b0b6718
	if (!ctx.cr6.eq) goto loc_8B0B6718;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// li r5,0
	ctx.r5.s64 = 0;
	// addi r4,r11,30444
	ctx.r4.s64 = ctx.r11.s64 + 30444;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// bl 0x8b0bfc38
	ctx.lr = 0x8B0B66A0;
	sub_8B0BFC38(ctx, base);
	// lis r10,12632
	ctx.r10.s64 = 827850752;
	// ori r9,r10,11597
	ctx.r9.u64 = ctx.r10.u64 | 11597;
	// cmpw cr6,r3,r9
	ctx.cr6.compare<int32_t>(ctx.r3.s32, ctx.r9.s32, ctx.xer);
	// bne cr6,0x8b0b6718
	if (!ctx.cr6.eq) goto loc_8B0B6718;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// li r5,0
	ctx.r5.s64 = 0;
	// addi r4,r11,30436
	ctx.r4.s64 = ctx.r11.s64 + 30436;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// addi r31,r29,460
	ctx.r31.s64 = ctx.r29.s64 + 460;
	// bl 0x8b0bfc38
	ctx.lr = 0x8B0B66C8;
	sub_8B0BFC38(ctx, base);
	// cmpw cr6,r3,r31
	ctx.cr6.compare<int32_t>(ctx.r3.s32, ctx.r31.s32, ctx.xer);
	// bne cr6,0x8b0b6718
	if (!ctx.cr6.eq) goto loc_8B0B6718;
	// lis r11,-29938
	ctx.r11.s64 = -1962016768;
	// mr r4,r29
	ctx.r4.u64 = ctx.r29.u64;
	// lwz r3,4480(r11)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r11.u32 + 4480);
	// lwz r10,0(r3)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r9,4(r10)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r10.u32 + 4);
	// mtctr r9
	ctx.ctr.u64 = ctx.r9.u64;
	// bctrl 
	ctx.lr = 0x8B0B66EC;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// li r8,2
	ctx.r8.s64 = 2;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// stw r8,4(r29)
	REX_STORE_U32(ctx.r29.u32 + 4, ctx.r8.u32);
	// bl 0x8b0bf248
	ctx.lr = 0x8B0B66FC;
	sub_8B0BF248(ctx, base);
	// stw r3,0(r31)
	REX_STORE_U32(ctx.r31.u32 + 0, ctx.r3.u32);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// bne cr6,0x8b0b670c
	if (!ctx.cr6.eq) goto loc_8B0B670C;
	// stw r30,0(r31)
	REX_STORE_U32(ctx.r31.u32 + 0, ctx.r30.u32);
loc_8B0B670C:
	// lwz r3,0(r31)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r31.u32 + 0);
	// bl 0x8b0c0298
	ctx.lr = 0x8B0B6714;
	sub_8B0C0298(ctx, base);
	// stw r3,0(r31)
	REX_STORE_U32(ctx.r31.u32 + 0, ctx.r3.u32);
loc_8B0B6718:
	// addi r1,r1,112
	ctx.r1.s64 = ctx.r1.s64 + 112;
	// b 0x8b0cba0c
	__restgprlr_29(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0B68C8) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// std r31,-16(r1)
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.r31.u64);
	// stwu r1,-96(r1)
	ea = -96 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// clrlwi r10,r4,31
	ctx.r10.u64 = ctx.r4.u32 & 0x1;
	// addi r9,r11,30420
	ctx.r9.s64 = ctx.r11.s64 + 30420;
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// cmplwi cr6,r10,0
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 0, ctx.xer);
	// stw r9,0(r3)
	REX_STORE_U32(ctx.r3.u32 + 0, ctx.r9.u32);
	// beq cr6,0x8b0b68fc
	if (ctx.cr6.eq) goto loc_8B0B68FC;
	// bl 0x8b090020
	ctx.lr = 0x8B0B68F8;
	sub_8B090020(ctx, base);
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
loc_8B0B68FC:
	// addi r1,r1,96
	ctx.r1.s64 = ctx.r1.s64 + 96;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0B6940) {
	REX_FUNC_PROLOGUE();
	PPCRegister temp{};
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// std r30,-24(r1)
	REX_STORE_U64(ctx.r1.u32 + -24, ctx.r30.u64);
	// std r31,-16(r1)
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.r31.u64);
	// stwu r1,-112(r1)
	ea = -112 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// mr r11,r4
	ctx.r11.u64 = ctx.r4.u64;
	// lwz r4,8(r3)
	ctx.r4.u64 = REX_LOAD_U32(ctx.r3.u32 + 8);
	// mr r30,r3
	ctx.r30.u64 = ctx.r3.u64;
	// cmpwi cr6,r4,0
	ctx.cr6.compare<int32_t>(ctx.r4.s32, 0, ctx.xer);
	// blt cr6,0x8b0b6a00
	if (ctx.cr6.lt) goto loc_8B0B6A00;
	// lwz r3,4(r3)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r3.u32 + 4);
	// li r6,448
	ctx.r6.s64 = 448;
	// add r31,r3,r11
	ctx.r31.u64 = ctx.r3.u64 + ctx.r11.u64;
	// mr r5,r31
	ctx.r5.u64 = ctx.r31.u64;
	// bl 0x8b090160
	ctx.lr = 0x8B0B697C;
	sub_8B090160(ctx, base);
	// cmpw cr6,r3,r31
	ctx.cr6.compare<int32_t>(ctx.r3.s32, ctx.r31.s32, ctx.xer);
	// bge cr6,0x8b0b69b0
	if (!ctx.cr6.lt) goto loc_8B0B69B0;
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// bne cr6,0x8b0b699c
	if (!ctx.cr6.eq) goto loc_8B0B699C;
	// cmpwi cr6,r31,-1
	ctx.cr6.compare<int32_t>(ctx.r31.s32, -1, ctx.xer);
	// bgt cr6,0x8b0b699c
	if (ctx.cr6.gt) goto loc_8B0B699C;
	// li r3,-1
	ctx.r3.s64 = -1;
	// b 0x8b0b69b0
	goto loc_8B0B69B0;
loc_8B0B699C:
	// add r11,r3,r31
	ctx.r11.u64 = ctx.r3.u64 + ctx.r31.u64;
	// srawi r10,r11,1
	ctx.xer.ca = (ctx.r11.s32 < 0) & ((ctx.r11.u32 & 0x1) != 0);
	ctx.r10.s64 = ctx.r11.s32 >> 1;
	// addze r3,r10
	temp.s64 = ctx.r10.s64 + ctx.xer.ca;
	ctx.xer.ca = temp.u32 < ctx.r10.u32;
	ctx.r3.s64 = temp.s64;
	// cmpw cr6,r3,r31
	ctx.cr6.compare<int32_t>(ctx.r3.s32, ctx.r31.s32, ctx.xer);
	// blt cr6,0x8b0b699c
	if (ctx.cr6.lt) goto loc_8B0B699C;
loc_8B0B69B0:
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lwz r4,0(r30)
	ctx.r4.u64 = REX_LOAD_U32(ctx.r30.u32 + 0);
	// stw r3,4(r30)
	REX_STORE_U32(ctx.r30.u32 + 4, ctx.r3.u32);
	// cmplwi cr6,r4,0
	ctx.cr6.compare<uint32_t>(ctx.r4.u32, 0, ctx.xer);
	// lwz r11,1144(r11)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r11.u32 + 1144);
	// beq cr6,0x8b0b69e4
	if (ctx.cr6.eq) goto loc_8B0B69E4;
	// mulli r5,r3,448
	ctx.r5.s64 = static_cast<int64_t>(ctx.r3.u64 * static_cast<uint64_t>(448));
	// lwz r3,0(r11)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r11.u32 + 0);
	// lwz r10,0(r3)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r9,12(r10)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r10.u32 + 12);
	// mtctr r9
	ctx.ctr.u64 = ctx.r9.u64;
	// bctrl 
	ctx.lr = 0x8B0B69E0;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// b 0x8b0b69fc
	goto loc_8B0B69FC;
loc_8B0B69E4:
	// mulli r4,r3,448
	ctx.r4.s64 = static_cast<int64_t>(ctx.r3.u64 * static_cast<uint64_t>(448));
	// lwz r3,0(r11)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r11.u32 + 0);
	// lwz r10,0(r3)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r9,4(r10)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r10.u32 + 4);
	// mtctr r9
	ctx.ctr.u64 = ctx.r9.u64;
	// bctrl 
	ctx.lr = 0x8B0B69FC;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
loc_8B0B69FC:
	// stw r3,0(r30)
	REX_STORE_U32(ctx.r30.u32 + 0, ctx.r3.u32);
loc_8B0B6A00:
	// addi r1,r1,112
	ctx.r1.s64 = ctx.r1.s64 + 112;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// ld r30,-24(r1)
	ctx.r30.u64 = REX_LOAD_U64(ctx.r1.u32 + -24);
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0B6CF8) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// std r31,-16(r1)
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.r31.u64);
	// stwu r1,-96(r1)
	ea = -96 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lwz r10,16(r3)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r3.u32 + 16);
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// lwz r11,40(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 40);
	// cmpw cr6,r11,r10
	ctx.cr6.compare<int32_t>(ctx.r11.s32, ctx.r10.s32, ctx.xer);
	// bge cr6,0x8b0b6d70
	if (!ctx.cr6.lt) goto loc_8B0B6D70;
	// lwz r3,44(r3)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r3.u32 + 44);
	// lwz r10,4(r3)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r3.u32 + 4);
	// cmpwi cr6,r10,4
	ctx.cr6.compare<int32_t>(ctx.r10.s32, 4, ctx.xer);
	// beq cr6,0x8b0b6d70
	if (ctx.cr6.eq) goto loc_8B0B6D70;
	// lwz r10,4(r31)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r31.u32 + 4);
	// rlwinm r11,r11,2,0,29
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 2) & 0xFFFFFFFC;
	// lwzx r4,r11,r10
	ctx.r4.u64 = REX_LOAD_U32(ctx.r11.u32 + ctx.r10.u32);
	// bl 0x8b0b6ae8
	ctx.lr = 0x8B0B6D3C;
	sub_8B0B6AE8(ctx, base);
	// clrlwi r11,r3,24
	ctx.r11.u64 = ctx.r3.u32 & 0xFF;
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// beq cr6,0x8b0b6d70
	if (ctx.cr6.eq) goto loc_8B0B6D70;
	// lwz r11,40(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 40);
	// li r10,1
	ctx.r10.s64 = 1;
	// addi r9,r11,1
	ctx.r9.s64 = ctx.r11.s64 + 1;
	// stw r10,36(r31)
	REX_STORE_U32(ctx.r31.u32 + 36, ctx.r10.u32);
	// stw r9,40(r31)
	REX_STORE_U32(ctx.r31.u32 + 40, ctx.r9.u32);
	// addi r1,r1,96
	ctx.r1.s64 = ctx.r1.s64 + 96;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
loc_8B0B6D70:
	// li r11,2
	ctx.r11.s64 = 2;
	// stw r11,36(r31)
	REX_STORE_U32(ctx.r31.u32 + 36, ctx.r11.u32);
	// addi r1,r1,96
	ctx.r1.s64 = ctx.r1.s64 + 96;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0B6EB0) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9bc
	ctx.lr = 0x8B0B6EB8;
	__savegprlr_29(ctx, base);
	// stwu r1,-112(r1)
	ea = -112 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lwz r10,12(r3)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r3.u32 + 12);
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// lwz r11,4(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 4);
	// mr r30,r4
	ctx.r30.u64 = ctx.r4.u64;
	// addi r9,r10,1
	ctx.r9.s64 = ctx.r10.s64 + 1;
	// mr r29,r5
	ctx.r29.u64 = ctx.r5.u64;
	// cmpw cr6,r9,r11
	ctx.cr6.compare<int32_t>(ctx.r9.s32, ctx.r11.s32, ctx.xer);
	// ble cr6,0x8b0b6ee8
	if (!ctx.cr6.gt) goto loc_8B0B6EE8;
	// subf r11,r11,r10
	ctx.r11.u64 = ctx.r10.u64 - ctx.r11.u64;
	// addi r4,r11,1
	ctx.r4.s64 = ctx.r11.s64 + 1;
	// bl 0x8b0b6940
	ctx.lr = 0x8B0B6EE8;
	sub_8B0B6940(ctx, base);
loc_8B0B6EE8:
	// lwz r11,12(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 12);
	// addi r11,r11,1
	ctx.r11.s64 = ctx.r11.s64 + 1;
	// subf r10,r30,r11
	ctx.r10.u64 = ctx.r11.u64 - ctx.r30.u64;
	// stw r11,12(r31)
	REX_STORE_U32(ctx.r31.u32 + 12, ctx.r11.u32);
	// addic. r11,r10,-1
	ctx.xer.ca = ctx.r10.u32 > 0;
	ctx.r11.s64 = ctx.r10.s64 + -1;
	ctx.cr0.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// ble 0x8b0b6f18
	if (!ctx.cr0.gt) goto loc_8B0B6F18;
	// lwz r9,0(r31)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r31.u32 + 0);
	// mulli r10,r30,448
	ctx.r10.s64 = static_cast<int64_t>(ctx.r30.u64 * static_cast<uint64_t>(448));
	// add r4,r10,r9
	ctx.r4.u64 = ctx.r10.u64 + ctx.r9.u64;
	// mulli r5,r11,448
	ctx.r5.s64 = static_cast<int64_t>(ctx.r11.u64 * static_cast<uint64_t>(448));
	// addi r3,r4,448
	ctx.r3.s64 = ctx.r4.s64 + 448;
	// bl 0x8b0cc060
	ctx.lr = 0x8B0B6F18;
	sub_8B0CC060(ctx, base);
loc_8B0B6F18:
	// lwz r10,0(r31)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r31.u32 + 0);
	// mulli r11,r30,448
	ctx.r11.s64 = static_cast<int64_t>(ctx.r30.u64 * static_cast<uint64_t>(448));
	// add. r3,r11,r10
	ctx.r3.u64 = ctx.r11.u64 + ctx.r10.u64;
	ctx.cr0.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// beq 0x8b0b6f34
	if (ctx.cr0.eq) goto loc_8B0B6F34;
	// li r5,448
	ctx.r5.s64 = 448;
	// mr r4,r29
	ctx.r4.u64 = ctx.r29.u64;
	// bl 0x8b0cbb30
	ctx.lr = 0x8B0B6F34;
	sub_8B0CBB30(ctx, base);
loc_8B0B6F34:
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// addi r1,r1,112
	ctx.r1.s64 = ctx.r1.s64 + 112;
	// b 0x8b0cba0c
	__restgprlr_29(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0B6FE0) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9bc
	ctx.lr = 0x8B0B6FE8;
	__savegprlr_29(ctx, base);
	// stwu r1,-112(r1)
	ea = -112 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// lwz r3,100(r3)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r3.u32 + 100);
	// li r29,0
	ctx.r29.s64 = 0;
	// lwz r11,12(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 12);
	// cmpwi cr6,r11,1
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 1, ctx.xer);
	// beq cr6,0x8b0b7018
	if (ctx.cr6.eq) goto loc_8B0B7018;
	// cmpwi cr6,r11,2
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 2, ctx.xer);
	// beq cr6,0x8b0b7018
	if (ctx.cr6.eq) goto loc_8B0B7018;
	// cmpwi cr6,r11,4
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 4, ctx.xer);
	// li r11,1
	ctx.r11.s64 = 1;
	// bne cr6,0x8b0b701c
	if (!ctx.cr6.eq) goto loc_8B0B701C;
loc_8B0B7018:
	// mr r11,r29
	ctx.r11.u64 = ctx.r29.u64;
loc_8B0B701C:
	// clrlwi r11,r11,24
	ctx.r11.u64 = ctx.r11.u32 & 0xFF;
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// bne cr6,0x8b0b7034
	if (!ctx.cr6.eq) goto loc_8B0B7034;
	// li r3,1
	ctx.r3.s64 = 1;
	// addi r1,r1,112
	ctx.r1.s64 = ctx.r1.s64 + 112;
	// b 0x8b0cba0c
	__restgprlr_29(ctx, base);
	return;
loc_8B0B7034:
	// lwz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r10,4(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 4);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B0B7044;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// stw r29,100(r31)
	REX_STORE_U32(ctx.r31.u32 + 100, ctx.r29.u32);
	// lwz r3,8(r31)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r31.u32 + 8);
	// bl 0x8b0dbe10
	ctx.lr = 0x8B0B7050;
	sub_8B0DBE10(ctx, base);
	// lis r9,-29944
	ctx.r9.s64 = -1962409984;
	// stw r29,8(r31)
	REX_STORE_U32(ctx.r31.u32 + 8, ctx.r29.u32);
	// addi r30,r31,104
	ctx.r30.s64 = ctx.r31.s64 + 104;
	// addi r8,r9,30644
	ctx.r8.s64 = ctx.r9.s64 + 30644;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// stw r8,0(r31)
	REX_STORE_U32(ctx.r31.u32 + 0, ctx.r8.u32);
	// stw r29,116(r31)
	REX_STORE_U32(ctx.r31.u32 + 116, ctx.r29.u32);
	// bl 0x8b0906a8
	ctx.lr = 0x8B0B7070;
	sub_8B0906A8(ctx, base);
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// bl 0x8b0906a8
	ctx.lr = 0x8B0B7078;
	sub_8B0906A8(ctx, base);
	// addi r3,r31,40
	ctx.r3.s64 = ctx.r31.s64 + 40;
	// bl 0x8b0906a8
	ctx.lr = 0x8B0B7080;
	sub_8B0906A8(ctx, base);
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b090020
	ctx.lr = 0x8B0B7088;
	sub_8B090020(ctx, base);
	// li r3,0
	ctx.r3.s64 = 0;
	// addi r1,r1,112
	ctx.r1.s64 = ctx.r1.s64 + 112;
	// b 0x8b0cba0c
	__restgprlr_29(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0B72D8) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb990
	ctx.lr = 0x8B0B72E0;
	__savegprlr_18(ctx, base);
	// stwu r1,-288(r1)
	ea = -288 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// li r20,0
	ctx.r20.s64 = 0;
	// mr r30,r4
	ctx.r30.u64 = ctx.r4.u64;
	// stw r20,0(r7)
	REX_STORE_U32(ctx.r7.u32 + 0, ctx.r20.u32);
	// mr r3,r5
	ctx.r3.u64 = ctx.r5.u64;
	// li r5,1
	ctx.r5.s64 = 1;
	// mr r4,r7
	ctx.r4.u64 = ctx.r7.u64;
	// mr r31,r6
	ctx.r31.u64 = ctx.r6.u64;
	// mr r24,r7
	ctx.r24.u64 = ctx.r7.u64;
	// mr r18,r8
	ctx.r18.u64 = ctx.r8.u64;
	// bl 0x8b0dbe70
	ctx.lr = 0x8B0B730C;
	sub_8B0DBE70(ctx, base);
	// lwz r3,0(r30)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r30.u32 + 0);
	// bl 0x8b0dbe10
	ctx.lr = 0x8B0B7314;
	sub_8B0DBE10(ctx, base);
	// stw r20,0(r30)
	REX_STORE_U32(ctx.r30.u32 + 0, ctx.r20.u32);
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lwz r4,0(r24)
	ctx.r4.u64 = REX_LOAD_U32(ctx.r24.u32 + 0);
	// addi r3,r11,30732
	ctx.r3.s64 = ctx.r11.s64 + 30732;
	// bl 0x8b0df298
	ctx.lr = 0x8B0B7328;
	sub_8B0DF298(ctx, base);
	// lwz r10,0(r24)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r24.u32 + 0);
	// cmplwi cr6,r10,0
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 0, ctx.xer);
	// beq cr6,0x8b0b7568
	if (ctx.cr6.eq) goto loc_8B0B7568;
	// lis r11,-29936
	ctx.r11.s64 = -1961885696;
	// lwz r31,0(r31)
	ctx.r31.u64 = REX_LOAD_U32(ctx.r31.u32 + 0);
	// lwz r3,-17796(r11)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r11.u32 + -17796);
	// lwz r10,0(r3)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r9,32(r10)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r10.u32 + 32);
	// mtctr r9
	ctx.ctr.u64 = ctx.r9.u64;
	// bctrl 
	ctx.lr = 0x8B0B7350;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// lwz r8,0(r3)
	ctx.r8.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r7,4(r8)
	ctx.r7.u64 = REX_LOAD_U32(ctx.r8.u32 + 4);
	// mtctr r7
	ctx.ctr.u64 = ctx.r7.u64;
	// bctrl 
	ctx.lr = 0x8B0B7360;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// lwz r6,0(r24)
	ctx.r6.u64 = REX_LOAD_U32(ctx.r24.u32 + 0);
	// mr r25,r20
	ctx.r25.u64 = ctx.r20.u64;
	// mr r22,r20
	ctx.r22.u64 = ctx.r20.u64;
	// stw r20,128(r1)
	REX_STORE_U32(ctx.r1.u32 + 128, ctx.r20.u32);
	// mr r29,r20
	ctx.r29.u64 = ctx.r20.u64;
	// stw r20,132(r1)
	REX_STORE_U32(ctx.r1.u32 + 132, ctx.r20.u32);
	// mr r27,r20
	ctx.r27.u64 = ctx.r20.u64;
	// stw r20,136(r1)
	REX_STORE_U32(ctx.r1.u32 + 136, ctx.r20.u32);
	// mr r26,r20
	ctx.r26.u64 = ctx.r20.u64;
	// stw r20,140(r1)
	REX_STORE_U32(ctx.r1.u32 + 140, ctx.r20.u32);
	// mr r23,r20
	ctx.r23.u64 = ctx.r20.u64;
	// stw r20,144(r1)
	REX_STORE_U32(ctx.r1.u32 + 144, ctx.r20.u32);
	// mr r30,r20
	ctx.r30.u64 = ctx.r20.u64;
	// stw r20,148(r1)
	REX_STORE_U32(ctx.r1.u32 + 148, ctx.r20.u32);
	// mr r28,r20
	ctx.r28.u64 = ctx.r20.u64;
	// stw r20,152(r1)
	REX_STORE_U32(ctx.r1.u32 + 152, ctx.r20.u32);
	// rotlwi r19,r3,0
	ctx.r19.u64 = __builtin_rotateleft32(ctx.r3.u32, 0);
	// stw r20,156(r1)
	REX_STORE_U32(ctx.r1.u32 + 156, ctx.r20.u32);
	// mr r21,r20
	ctx.r21.u64 = ctx.r20.u64;
	// cmplwi cr6,r6,0
	ctx.cr6.compare<uint32_t>(ctx.r6.u32, 0, ctx.xer);
	// ble cr6,0x8b0b74a0
	if (!ctx.cr6.gt) goto loc_8B0B74A0;
	// mr r30,r31
	ctx.r30.u64 = ctx.r31.u64;
loc_8B0B73B8:
	// addi r11,r27,1
	ctx.r11.s64 = ctx.r27.s64 + 1;
	// mr r31,r27
	ctx.r31.u64 = ctx.r27.u64;
	// cmpw cr6,r11,r22
	ctx.cr6.compare<int32_t>(ctx.r11.s32, ctx.r22.s32, ctx.xer);
	// ble cr6,0x8b0b73e4
	if (!ctx.cr6.gt) goto loc_8B0B73E4;
	// subf r11,r22,r27
	ctx.r11.u64 = ctx.r27.u64 - ctx.r22.u64;
	// addi r3,r1,128
	ctx.r3.s64 = ctx.r1.s64 + 128;
	// addi r4,r11,1
	ctx.r4.s64 = ctx.r11.s64 + 1;
	// bl 0x8b0bc490
	ctx.lr = 0x8B0B73D8;
	sub_8B0BC490(ctx, base);
	// lwz r27,140(r1)
	ctx.r27.u64 = REX_LOAD_U32(ctx.r1.u32 + 140);
	// lwz r22,132(r1)
	ctx.r22.u64 = REX_LOAD_U32(ctx.r1.u32 + 132);
	// lwz r25,128(r1)
	ctx.r25.u64 = REX_LOAD_U32(ctx.r1.u32 + 128);
loc_8B0B73E4:
	// addi r27,r27,1
	ctx.r27.s64 = ctx.r27.s64 + 1;
	// subf r11,r31,r27
	ctx.r11.u64 = ctx.r27.u64 - ctx.r31.u64;
	// stw r27,140(r1)
	REX_STORE_U32(ctx.r1.u32 + 140, ctx.r27.u32);
	// addic. r11,r11,-1
	ctx.xer.ca = ctx.r11.u32 > 0;
	ctx.r11.s64 = ctx.r11.s64 + -1;
	ctx.cr0.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// ble 0x8b0b740c
	if (!ctx.cr0.gt) goto loc_8B0B740C;
	// rlwinm r10,r31,2,0,29
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r31.u32 | (ctx.r31.u64 << 32), 2) & 0xFFFFFFFC;
	// rlwinm r5,r11,2,0,29
	ctx.r5.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 2) & 0xFFFFFFFC;
	// add r4,r10,r25
	ctx.r4.u64 = ctx.r10.u64 + ctx.r25.u64;
	// addi r3,r4,4
	ctx.r3.s64 = ctx.r4.s64 + 4;
	// bl 0x8b0cc060
	ctx.lr = 0x8B0B740C;
	sub_8B0CC060(ctx, base);
loc_8B0B740C:
	// rlwinm r11,r31,2,0,29
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r31.u32 | (ctx.r31.u64 << 32), 2) & 0xFFFFFFFC;
	// add. r11,r11,r25
	ctx.r11.u64 = ctx.r11.u64 + ctx.r25.u64;
	ctx.cr0.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// beq 0x8b0b7420
	if (ctx.cr0.eq) goto loc_8B0B7420;
	// lwz r10,0(r30)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r30.u32 + 0);
	// stw r10,0(r11)
	REX_STORE_U32(ctx.r11.u32 + 0, ctx.r10.u32);
loc_8B0B7420:
	// addi r11,r28,1
	ctx.r11.s64 = ctx.r28.s64 + 1;
	// mr r31,r28
	ctx.r31.u64 = ctx.r28.u64;
	// cmpw cr6,r11,r23
	ctx.cr6.compare<int32_t>(ctx.r11.s32, ctx.r23.s32, ctx.xer);
	// ble cr6,0x8b0b744c
	if (!ctx.cr6.gt) goto loc_8B0B744C;
	// subf r11,r23,r28
	ctx.r11.u64 = ctx.r28.u64 - ctx.r23.u64;
	// addi r3,r1,144
	ctx.r3.s64 = ctx.r1.s64 + 144;
	// addi r4,r11,1
	ctx.r4.s64 = ctx.r11.s64 + 1;
	// bl 0x8b0bc490
	ctx.lr = 0x8B0B7440;
	sub_8B0BC490(ctx, base);
	// lwz r28,156(r1)
	ctx.r28.u64 = REX_LOAD_U32(ctx.r1.u32 + 156);
	// lwz r23,148(r1)
	ctx.r23.u64 = REX_LOAD_U32(ctx.r1.u32 + 148);
	// lwz r26,144(r1)
	ctx.r26.u64 = REX_LOAD_U32(ctx.r1.u32 + 144);
loc_8B0B744C:
	// addi r28,r28,1
	ctx.r28.s64 = ctx.r28.s64 + 1;
	// subf r11,r31,r28
	ctx.r11.u64 = ctx.r28.u64 - ctx.r31.u64;
	// stw r28,156(r1)
	REX_STORE_U32(ctx.r1.u32 + 156, ctx.r28.u32);
	// addic. r11,r11,-1
	ctx.xer.ca = ctx.r11.u32 > 0;
	ctx.r11.s64 = ctx.r11.s64 + -1;
	ctx.cr0.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// ble 0x8b0b7474
	if (!ctx.cr0.gt) goto loc_8B0B7474;
	// rlwinm r10,r31,2,0,29
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r31.u32 | (ctx.r31.u64 << 32), 2) & 0xFFFFFFFC;
	// rlwinm r5,r11,2,0,29
	ctx.r5.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 2) & 0xFFFFFFFC;
	// add r4,r10,r26
	ctx.r4.u64 = ctx.r10.u64 + ctx.r26.u64;
	// addi r3,r4,4
	ctx.r3.s64 = ctx.r4.s64 + 4;
	// bl 0x8b0cc060
	ctx.lr = 0x8B0B7474;
	sub_8B0CC060(ctx, base);
loc_8B0B7474:
	// rlwinm r11,r31,2,0,29
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r31.u32 | (ctx.r31.u64 << 32), 2) & 0xFFFFFFFC;
	// add. r11,r11,r26
	ctx.r11.u64 = ctx.r11.u64 + ctx.r26.u64;
	ctx.cr0.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// beq 0x8b0b7484
	if (ctx.cr0.eq) goto loc_8B0B7484;
	// stw r19,0(r11)
	REX_STORE_U32(ctx.r11.u32 + 0, ctx.r19.u32);
loc_8B0B7484:
	// lwz r11,0(r24)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r24.u32 + 0);
	// addi r21,r21,1
	ctx.r21.s64 = ctx.r21.s64 + 1;
	// addi r30,r30,208
	ctx.r30.s64 = ctx.r30.s64 + 208;
	// cmplw cr6,r21,r11
	ctx.cr6.compare<uint32_t>(ctx.r21.u32, ctx.r11.u32, ctx.xer);
	// blt cr6,0x8b0b73b8
	if (ctx.cr6.lt) goto loc_8B0B73B8;
	// lwz r29,136(r1)
	ctx.r29.u64 = REX_LOAD_U32(ctx.r1.u32 + 136);
	// lwz r30,152(r1)
	ctx.r30.u64 = REX_LOAD_U32(ctx.r1.u32 + 152);
loc_8B0B74A0:
	// lis r11,-29938
	ctx.r11.s64 = -1962016768;
	// stw r20,0(r18)
	REX_STORE_U32(ctx.r18.u32 + 0, ctx.r20.u32);
	// lwz r8,0(r24)
	ctx.r8.u64 = REX_LOAD_U32(ctx.r24.u32 + 0);
	// li r10,8
	ctx.r10.s64 = 8;
	// mr r9,r25
	ctx.r9.u64 = ctx.r25.u64;
	// stw r18,116(r1)
	REX_STORE_U32(ctx.r1.u32 + 116, ctx.r18.u32);
	// stw r10,84(r1)
	REX_STORE_U32(ctx.r1.u32 + 84, ctx.r10.u32);
	// mr r10,r26
	ctx.r10.u64 = ctx.r26.u64;
	// li r7,0
	ctx.r7.s64 = 0;
	// stw r20,108(r1)
	REX_STORE_U32(ctx.r1.u32 + 108, ctx.r20.u32);
	// lwz r11,2364(r11)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r11.u32 + 2364);
	// li r6,0
	ctx.r6.s64 = 0;
	// li r5,0
	ctx.r5.s64 = 0;
	// stw r20,100(r1)
	REX_STORE_U32(ctx.r1.u32 + 100, ctx.r20.u32);
	// li r4,0
	ctx.r4.s64 = 0;
	// stw r20,92(r1)
	REX_STORE_U32(ctx.r1.u32 + 92, ctx.r20.u32);
	// lwz r3,104(r11)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r11.u32 + 104);
	// lwz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r11,28(r11)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r11.u32 + 28);
	// mtctr r11
	ctx.ctr.u64 = ctx.r11.u64;
	// bctrl 
	ctx.lr = 0x8B0B74F4;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0b7574
	if (ctx.cr6.eq) goto loc_8B0B7574;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// addi r3,r11,30664
	ctx.r3.s64 = ctx.r11.s64 + 30664;
	// bl 0x8b0df2e8
	ctx.lr = 0x8B0B750C;
	sub_8B0DF2E8(ctx, base);
	// lis r31,-29944
	ctx.r31.s64 = -1962409984;
	// cmpwi cr6,r30,0
	ctx.cr6.compare<int32_t>(ctx.r30.s32, 0, ctx.xer);
	// blt cr6,0x8b0b753c
	if (ctx.cr6.lt) goto loc_8B0B753C;
	// cmplwi cr6,r26,0
	ctx.cr6.compare<uint32_t>(ctx.r26.u32, 0, ctx.xer);
	// beq cr6,0x8b0b753c
	if (ctx.cr6.eq) goto loc_8B0B753C;
	// lwz r11,1144(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 1144);
	// mr r4,r26
	ctx.r4.u64 = ctx.r26.u64;
	// lwz r3,0(r11)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r11.u32 + 0);
	// lwz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r10,20(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 20);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B0B753C;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
loc_8B0B753C:
	// cmpwi cr6,r29,0
	ctx.cr6.compare<int32_t>(ctx.r29.s32, 0, ctx.xer);
	// blt cr6,0x8b0b7568
	if (ctx.cr6.lt) goto loc_8B0B7568;
	// cmplwi cr6,r25,0
	ctx.cr6.compare<uint32_t>(ctx.r25.u32, 0, ctx.xer);
	// beq cr6,0x8b0b7568
	if (ctx.cr6.eq) goto loc_8B0B7568;
	// lwz r11,1144(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 1144);
	// mr r4,r25
	ctx.r4.u64 = ctx.r25.u64;
	// lwz r3,0(r11)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r11.u32 + 0);
	// lwz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r10,20(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 20);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B0B7568;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
loc_8B0B7568:
	// li r3,0
	ctx.r3.s64 = 0;
	// addi r1,r1,288
	ctx.r1.s64 = ctx.r1.s64 + 288;
	// b 0x8b0cb9e0
	__restgprlr_18(ctx, base);
	return;
loc_8B0B7574:
	// lis r31,-29944
	ctx.r31.s64 = -1962409984;
	// cmpwi cr6,r30,0
	ctx.cr6.compare<int32_t>(ctx.r30.s32, 0, ctx.xer);
	// blt cr6,0x8b0b75a4
	if (ctx.cr6.lt) goto loc_8B0B75A4;
	// cmplwi cr6,r26,0
	ctx.cr6.compare<uint32_t>(ctx.r26.u32, 0, ctx.xer);
	// beq cr6,0x8b0b75a4
	if (ctx.cr6.eq) goto loc_8B0B75A4;
	// lwz r11,1144(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 1144);
	// mr r4,r26
	ctx.r4.u64 = ctx.r26.u64;
	// lwz r3,0(r11)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r11.u32 + 0);
	// lwz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r10,20(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 20);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B0B75A4;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
loc_8B0B75A4:
	// cmpwi cr6,r29,0
	ctx.cr6.compare<int32_t>(ctx.r29.s32, 0, ctx.xer);
	// blt cr6,0x8b0b75d0
	if (ctx.cr6.lt) goto loc_8B0B75D0;
	// cmplwi cr6,r25,0
	ctx.cr6.compare<uint32_t>(ctx.r25.u32, 0, ctx.xer);
	// beq cr6,0x8b0b75d0
	if (ctx.cr6.eq) goto loc_8B0B75D0;
	// lwz r11,1144(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 1144);
	// mr r4,r25
	ctx.r4.u64 = ctx.r25.u64;
	// lwz r3,0(r11)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r11.u32 + 0);
	// lwz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r10,20(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 20);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B0B75D0;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
loc_8B0B75D0:
	// li r3,1
	ctx.r3.s64 = 1;
	// addi r1,r1,288
	ctx.r1.s64 = ctx.r1.s64 + 288;
	// b 0x8b0cb9e0
	__restgprlr_18(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0B8088) {
	REX_FUNC_PROLOGUE();
	PPCRegister temp{};
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// std r30,-24(r1)
	REX_STORE_U64(ctx.r1.u32 + -24, ctx.r30.u64);
	// std r31,-16(r1)
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.r31.u64);
	// stwu r1,-112(r1)
	ea = -112 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// li r30,0
	ctx.r30.s64 = 0;
	// addi r3,r3,4
	ctx.r3.s64 = ctx.r3.s64 + 4;
	// li r4,0
	ctx.r4.s64 = 0;
	// stw r30,0(r31)
	REX_STORE_U32(ctx.r31.u32 + 0, ctx.r30.u32);
	// bl 0x8b0df488
	ctx.lr = 0x8B0B80B4;
	sub_8B0DF488(ctx, base);
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// lis r9,-29944
	ctx.r9.s64 = -1962409984;
	// stw r30,8(r31)
	REX_STORE_U32(ctx.r31.u32 + 8, ctx.r30.u32);
	// li r11,50
	ctx.r11.s64 = 50;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// stw r11,12(r31)
	REX_STORE_U32(ctx.r31.u32 + 12, ctx.r11.u32);
	// lfs f0,31860(r10)
	ctx.fpscr.disableFlushMode();
	temp.u32 = REX_LOAD_U32(ctx.r10.u32 + 31860);
	ctx.f0.f64 = double(temp.f32);
	// stw r11,16(r31)
	REX_STORE_U32(ctx.r31.u32 + 16, ctx.r11.u32);
	// lfs f13,8492(r9)
	temp.u32 = REX_LOAD_U32(ctx.r9.u32 + 8492);
	ctx.f13.f64 = double(temp.f32);
	// stfs f0,20(r31)
	temp.f32 = float(ctx.f0.f64);
	REX_STORE_U32(ctx.r31.u32 + 20, temp.u32);
	// stfs f0,24(r31)
	temp.f32 = float(ctx.f0.f64);
	REX_STORE_U32(ctx.r31.u32 + 24, temp.u32);
	// stfs f13,28(r31)
	temp.f32 = float(ctx.f13.f64);
	REX_STORE_U32(ctx.r31.u32 + 28, temp.u32);
	// addi r1,r1,112
	ctx.r1.s64 = ctx.r1.s64 + 112;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// ld r30,-24(r1)
	ctx.r30.u64 = REX_LOAD_U64(ctx.r1.u32 + -24);
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0B82C8) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// std r31,-16(r1)
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.r31.u64);
	// stwu r1,-96(r1)
	ea = -96 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// lwz r3,12(r3)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r3.u32 + 12);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0b82f8
	if (ctx.cr6.eq) goto loc_8B0B82F8;
	// lwz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r10,12(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 12);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B0B82F8;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
loc_8B0B82F8:
	// li r11,0
	ctx.r11.s64 = 0;
	// li r4,1
	ctx.r4.s64 = 1;
	// stw r11,12(r31)
	REX_STORE_U32(ctx.r31.u32 + 12, ctx.r11.u32);
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// lwz r10,0(r31)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r31.u32 + 0);
	// lwz r9,20(r10)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r10.u32 + 20);
	// mtctr r9
	ctx.ctr.u64 = ctx.r9.u64;
	// bctrl 
	ctx.lr = 0x8B0B8318;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// addi r1,r1,96
	ctx.r1.s64 = ctx.r1.s64 + 96;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0B8590) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9ac
	ctx.lr = 0x8B0B8598;
	__savegprlr_25(ctx, base);
	// stwu r1,-400(r1)
	ea = -400 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// mr r25,r3
	ctx.r25.u64 = ctx.r3.u64;
	// mr r27,r4
	ctx.r27.u64 = ctx.r4.u64;
	// mr r3,r4
	ctx.r3.u64 = ctx.r4.u64;
	// addi r4,r11,5400
	ctx.r4.s64 = ctx.r11.s64 + 5400;
	// li r5,0
	ctx.r5.s64 = 0;
	// bl 0x8b0bfc38
	ctx.lr = 0x8B0B85B8;
	sub_8B0BFC38(ctx, base);
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// mr r30,r3
	ctx.r30.u64 = ctx.r3.u64;
	// mr r3,r27
	ctx.r3.u64 = ctx.r27.u64;
	// addi r4,r10,5392
	ctx.r4.s64 = ctx.r10.s64 + 5392;
	// li r5,0
	ctx.r5.s64 = 0;
	// bl 0x8b0bfc38
	ctx.lr = 0x8B0B85D0;
	sub_8B0BFC38(ctx, base);
	// lis r9,-29944
	ctx.r9.s64 = -1962409984;
	// mr r26,r3
	ctx.r26.u64 = ctx.r3.u64;
	// addi r4,r9,32356
	ctx.r4.s64 = ctx.r9.s64 + 32356;
	// li r5,0
	ctx.r5.s64 = 0;
	// mr r3,r27
	ctx.r3.u64 = ctx.r27.u64;
	// bl 0x8b0bfa88
	ctx.lr = 0x8B0B85E8;
	sub_8B0BFA88(ctx, base);
	// lis r8,-29938
	ctx.r8.s64 = -1962016768;
	// mr r29,r3
	ctx.r29.u64 = ctx.r3.u64;
	// addi r7,r8,21568
	ctx.r7.s64 = ctx.r8.s64 + 21568;
	// lwz r11,28(r7)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r7.u32 + 28);
	// lwz r6,48(r11)
	ctx.r6.u64 = REX_LOAD_U32(ctx.r11.u32 + 48);
	// cmpwi cr6,r6,0
	ctx.cr6.compare<int32_t>(ctx.r6.s32, 0, ctx.xer);
	// beq cr6,0x8b0b8670
	if (ctx.cr6.eq) goto loc_8B0B8670;
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0b8670
	if (ctx.cr6.eq) goto loc_8B0B8670;
	// cmpwi cr6,r30,0
	ctx.cr6.compare<int32_t>(ctx.r30.s32, 0, ctx.xer);
	// beq cr6,0x8b0b8670
	if (ctx.cr6.eq) goto loc_8B0B8670;
	// cmpw cr6,r30,r26
	ctx.cr6.compare<int32_t>(ctx.r30.s32, ctx.r26.s32, ctx.xer);
	// bgt cr6,0x8b0b8670
	if (ctx.cr6.gt) goto loc_8B0B8670;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// addi r28,r11,1788
	ctx.r28.s64 = ctx.r11.s64 + 1788;
loc_8B0B8624:
	// mr r4,r28
	ctx.r4.u64 = ctx.r28.u64;
	// mr r5,r30
	ctx.r5.u64 = ctx.r30.u64;
	// addi r3,r1,80
	ctx.r3.s64 = ctx.r1.s64 + 80;
	// bl 0x8b090220
	ctx.lr = 0x8B0B8634;
	sub_8B090220(ctx, base);
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// li r5,0
	ctx.r5.s64 = 0;
	// mr r3,r29
	ctx.r3.u64 = ctx.r29.u64;
	// bl 0x8b0bfa88
	ctx.lr = 0x8B0B8644;
	sub_8B0BFA88(ctx, base);
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0b8664
	if (ctx.cr6.eq) goto loc_8B0B8664;
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// mr r3,r29
	ctx.r3.u64 = ctx.r29.u64;
	// bl 0x8b0bf1a0
	ctx.lr = 0x8B0B865C;
	sub_8B0BF1A0(ctx, base);
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0c04f0
	ctx.lr = 0x8B0B8664;
	sub_8B0C04F0(ctx, base);
loc_8B0B8664:
	// addi r30,r30,1
	ctx.r30.s64 = ctx.r30.s64 + 1;
	// cmpw cr6,r30,r26
	ctx.cr6.compare<int32_t>(ctx.r30.s32, ctx.r26.s32, ctx.xer);
	// ble cr6,0x8b0b8624
	if (!ctx.cr6.gt) goto loc_8B0B8624;
loc_8B0B8670:
	// mr r4,r27
	ctx.r4.u64 = ctx.r27.u64;
	// mr r3,r25
	ctx.r3.u64 = ctx.r25.u64;
	// bl 0x8b0bd588
	ctx.lr = 0x8B0B867C;
	sub_8B0BD588(ctx, base);
	// addi r1,r1,400
	ctx.r1.s64 = ctx.r1.s64 + 400;
	// b 0x8b0cb9fc
	__restgprlr_25(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0B88F0) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// std r31,-16(r1)
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.r31.u64);
	// stwu r1,-96(r1)
	ea = -96 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lis r9,-29938
	ctx.r9.s64 = -1962016768;
	// lwz r11,21540(r9)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r9.u32 + 21540);
	// clrlwi r10,r11,31
	ctx.r10.u64 = ctx.r11.u32 & 0x1;
	// cmplwi cr6,r10,0
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 0, ctx.xer);
	// bne cr6,0x8b0b8960
	if (!ctx.cr6.eq) goto loc_8B0B8960;
	// lis r8,-29938
	ctx.r8.s64 = -1962016768;
	// ori r11,r11,1
	ctx.r11.u64 = ctx.r11.u64 | 1;
	// addi r31,r8,21524
	ctx.r31.s64 = ctx.r8.s64 + 21524;
	// stw r11,21540(r9)
	REX_STORE_U32(ctx.r9.u32 + 21540, ctx.r11.u32);
	// li r11,0
	ctx.r11.s64 = 0;
	// li r9,0
	ctx.r9.s64 = 0;
	// stw r10,21524(r8)
	REX_STORE_U32(ctx.r8.u32 + 21524, ctx.r10.u32);
	// lis r7,-29938
	ctx.r7.s64 = -1962016768;
	// stw r11,4(r31)
	REX_STORE_U32(ctx.r31.u32 + 4, ctx.r11.u32);
	// addi r3,r7,-4136
	ctx.r3.s64 = ctx.r7.s64 + -4136;
	// stw r9,8(r31)
	REX_STORE_U32(ctx.r31.u32 + 8, ctx.r9.u32);
	// stw r10,12(r31)
	REX_STORE_U32(ctx.r31.u32 + 12, ctx.r10.u32);
	// bl 0x8b0cc3d0
	ctx.lr = 0x8B0B8948;
	sub_8B0CC3D0(ctx, base);
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// addi r1,r1,96
	ctx.r1.s64 = ctx.r1.s64 + 96;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
loc_8B0B8960:
	// lis r11,-29938
	ctx.r11.s64 = -1962016768;
	// addi r3,r11,21524
	ctx.r3.s64 = ctx.r11.s64 + 21524;
	// addi r1,r1,96
	ctx.r1.s64 = ctx.r1.s64 + 96;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0B8F68) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// std r30,-24(r1)
	REX_STORE_U64(ctx.r1.u32 + -24, ctx.r30.u64);
	// std r31,-16(r1)
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.r31.u64);
	// stwu r1,-112(r1)
	ea = -112 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// mr r30,r3
	ctx.r30.u64 = ctx.r3.u64;
	// bl 0x8b0bc2e0
	ctx.lr = 0x8B0B8F84;
	sub_8B0BC2E0(ctx, base);
	// lwz r3,180(r30)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r30.u32 + 180);
	// bl 0x8b0b8bb0
	ctx.lr = 0x8B0B8F8C;
	sub_8B0B8BB0(ctx, base);
	// li r3,36
	ctx.r3.s64 = 36;
	// bl 0x8b0bf448
	ctx.lr = 0x8B0B8F94;
	sub_8B0BF448(ctx, base);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0b8fc0
	if (ctx.cr6.eq) goto loc_8B0B8FC0;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// lis r9,-29944
	ctx.r9.s64 = -1962409984;
	// addi r6,r11,9324
	ctx.r6.s64 = ctx.r11.s64 + 9324;
	// addi r5,r10,9316
	ctx.r5.s64 = ctx.r10.s64 + 9316;
	// addi r4,r9,32260
	ctx.r4.s64 = ctx.r9.s64 + 32260;
	// bl 0x8b0c1300
	ctx.lr = 0x8B0B8FB8;
	sub_8B0C1300(ctx, base);
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// b 0x8b0b8fc4
	goto loc_8B0B8FC4;
loc_8B0B8FC0:
	// li r31,0
	ctx.r31.s64 = 0;
loc_8B0B8FC4:
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lwz r5,180(r30)
	ctx.r5.u64 = REX_LOAD_U32(ctx.r30.u32 + 180);
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// addi r4,r11,32256
	ctx.r4.s64 = ctx.r11.s64 + 32256;
	// bl 0x8b0c0250
	ctx.lr = 0x8B0B8FD8;
	sub_8B0C0250(ctx, base);
	// lis r10,-29936
	ctx.r10.s64 = -1961885696;
	// lwz r3,-17796(r10)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r10.u32 + -17796);
	// lwz r9,0(r3)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r8,28(r9)
	ctx.r8.u64 = REX_LOAD_U32(ctx.r9.u32 + 28);
	// mtctr r8
	ctx.ctr.u64 = ctx.r8.u64;
	// bctrl 
	ctx.lr = 0x8B0B8FF0;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// lwz r7,0(r3)
	ctx.r7.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// mr r4,r31
	ctx.r4.u64 = ctx.r31.u64;
	// lwz r6,8(r7)
	ctx.r6.u64 = REX_LOAD_U32(ctx.r7.u32 + 8);
	// mtctr r6
	ctx.ctr.u64 = ctx.r6.u64;
	// bctrl 
	ctx.lr = 0x8B0B9004;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// addi r1,r1,112
	ctx.r1.s64 = ctx.r1.s64 + 112;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// ld r30,-24(r1)
	ctx.r30.u64 = REX_LOAD_U64(ctx.r1.u32 + -24);
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0B91D0) {
	REX_FUNC_PROLOGUE();
	// lwz r10,44(r3)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r3.u32 + 44);
	// mr r11,r3
	ctx.r11.u64 = ctx.r3.u64;
	// cmpwi cr6,r10,3
	ctx.cr6.compare<int32_t>(ctx.r10.s32, 3, ctx.xer);
	// beq cr6,0x8b0b91fc
	if (ctx.cr6.eq) goto loc_8B0B91FC;
	// cmpwi cr6,r10,4
	ctx.cr6.compare<int32_t>(ctx.r10.s32, 4, ctx.xer);
	// beq cr6,0x8b0b91f4
	if (ctx.cr6.eq) goto loc_8B0B91F4;
	// lwz r3,68(r3)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r3.u32 + 68);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// bnelr cr6
	if (!ctx.cr6.eq) return;
loc_8B0B91F4:
	// lwz r3,72(r11)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r11.u32 + 72);
	// blr 
	return;
loc_8B0B91FC:
	// lwz r3,68(r11)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r11.u32 + 68);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0B93C0) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// std r30,-24(r1)
	REX_STORE_U64(ctx.r1.u32 + -24, ctx.r30.u64);
	// std r31,-16(r1)
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.r31.u64);
	// stwu r1,-112(r1)
	ea = -112 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// lwz r3,68(r3)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r3.u32 + 68);
	// li r30,0
	ctx.r30.s64 = 0;
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0b93fc
	if (ctx.cr6.eq) goto loc_8B0B93FC;
	// lwz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r10,20(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 20);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B0B93F8;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// stw r30,68(r31)
	REX_STORE_U32(ctx.r31.u32 + 68, ctx.r30.u32);
loc_8B0B93FC:
	// lwz r3,72(r31)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r31.u32 + 72);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0b941c
	if (ctx.cr6.eq) goto loc_8B0B941C;
	// lwz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r10,20(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 20);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B0B9418;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// stw r30,72(r31)
	REX_STORE_U32(ctx.r31.u32 + 72, ctx.r30.u32);
loc_8B0B941C:
	// lwz r3,76(r31)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r31.u32 + 76);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0b943c
	if (ctx.cr6.eq) goto loc_8B0B943C;
	// lwz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r10,12(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 12);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B0B9438;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// stw r30,76(r31)
	REX_STORE_U32(ctx.r31.u32 + 76, ctx.r30.u32);
loc_8B0B943C:
	// lwz r3,100(r31)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r31.u32 + 100);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0b945c
	if (ctx.cr6.eq) goto loc_8B0B945C;
	// lwz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r10,8(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 8);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B0B9458;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// stw r30,100(r31)
	REX_STORE_U32(ctx.r31.u32 + 100, ctx.r30.u32);
loc_8B0B945C:
	// lwz r3,96(r31)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r31.u32 + 96);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0b947c
	if (ctx.cr6.eq) goto loc_8B0B947C;
	// lwz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r10,12(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 12);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B0B9478;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// stw r30,96(r31)
	REX_STORE_U32(ctx.r31.u32 + 96, ctx.r30.u32);
loc_8B0B947C:
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0b1b08
	ctx.lr = 0x8B0B9484;
	sub_8B0B1B08(ctx, base);
	// addi r1,r1,112
	ctx.r1.s64 = ctx.r1.s64 + 112;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// ld r30,-24(r1)
	ctx.r30.u64 = REX_LOAD_U64(ctx.r1.u32 + -24);
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0B9660) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// std r30,-24(r1)
	REX_STORE_U64(ctx.r1.u32 + -24, ctx.r30.u64);
	// std r31,-16(r1)
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.r31.u64);
	// stwu r1,-112(r1)
	ea = -112 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// mr r30,r3
	ctx.r30.u64 = ctx.r3.u64;
	// li r3,264
	ctx.r3.s64 = 264;
	// bl 0x8b090000
	ctx.lr = 0x8B0B9680;
	sub_8B090000(ctx, base);
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0b96ac
	if (ctx.cr6.eq) goto loc_8B0B96AC;
	// lwz r4,8(r30)
	ctx.r4.u64 = REX_LOAD_U32(ctx.r30.u32 + 8);
	// bl 0x8b0a2578
	ctx.lr = 0x8B0B9694;
	sub_8B0A2578(ctx, base);
	// lis r11,-29943
	ctx.r11.s64 = -1962344448;
	// stw r30,256(r31)
	REX_STORE_U32(ctx.r31.u32 + 256, ctx.r30.u32);
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// addi r10,r11,-32484
	ctx.r10.s64 = ctx.r11.s64 + -32484;
	// stw r10,0(r31)
	REX_STORE_U32(ctx.r31.u32 + 0, ctx.r10.u32);
	// b 0x8b0b96b0
	goto loc_8B0B96B0;
loc_8B0B96AC:
	// li r3,0
	ctx.r3.s64 = 0;
loc_8B0B96B0:
	// addi r1,r1,112
	ctx.r1.s64 = ctx.r1.s64 + 112;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// ld r30,-24(r1)
	ctx.r30.u64 = REX_LOAD_U64(ctx.r1.u32 + -24);
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0B9958) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// std r30,-24(r1)
	REX_STORE_U64(ctx.r1.u32 + -24, ctx.r30.u64);
	// std r31,-16(r1)
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.r31.u64);
	// stwu r1,-112(r1)
	ea = -112 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lis r11,-29938
	ctx.r11.s64 = -1962016768;
	// mr r30,r3
	ctx.r30.u64 = ctx.r3.u64;
	// addi r10,r11,21816
	ctx.r10.s64 = ctx.r11.s64 + 21816;
	// lwz r11,28(r10)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r10.u32 + 28);
	// lwz r9,48(r11)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r11.u32 + 48);
	// cmpwi cr6,r9,0
	ctx.cr6.compare<int32_t>(ctx.r9.s32, 0, ctx.xer);
	// beq cr6,0x8b0b99dc
	if (ctx.cr6.eq) goto loc_8B0B99DC;
	// li r3,36
	ctx.r3.s64 = 36;
	// bl 0x8b0bf448
	ctx.lr = 0x8B0B9990;
	sub_8B0BF448(ctx, base);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0b99ac
	if (ctx.cr6.eq) goto loc_8B0B99AC;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// addi r4,r11,28196
	ctx.r4.s64 = ctx.r11.s64 + 28196;
	// bl 0x8b0bf9f8
	ctx.lr = 0x8B0B99A4;
	sub_8B0BF9F8(ctx, base);
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// b 0x8b0b99b0
	goto loc_8B0B99B0;
loc_8B0B99AC:
	// li r31,0
	ctx.r31.s64 = 0;
loc_8B0B99B0:
	// lwz r3,64(r30)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r30.u32 + 64);
	// mr r4,r31
	ctx.r4.u64 = ctx.r31.u64;
	// lwz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r10,12(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 12);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B0B99C8;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// cmplwi cr6,r31,0
	ctx.cr6.compare<uint32_t>(ctx.r31.u32, 0, ctx.xer);
	// beq cr6,0x8b0b9a28
	if (ctx.cr6.eq) goto loc_8B0B9A28;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0c04f0
	ctx.lr = 0x8B0B99D8;
	sub_8B0C04F0(ctx, base);
	// b 0x8b0b9a28
	goto loc_8B0B9A28;
loc_8B0B99DC:
	// li r11,0
	ctx.r11.s64 = 0;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// stw r11,48(r30)
	REX_STORE_U32(ctx.r30.u32 + 48, ctx.r11.u32);
	// bl 0x8b0b9170
	ctx.lr = 0x8B0B99EC;
	sub_8B0B9170(ctx, base);
	// li r3,36
	ctx.r3.s64 = 36;
	// bl 0x8b0bf448
	ctx.lr = 0x8B0B99F4;
	sub_8B0BF448(ctx, base);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0b9a10
	if (ctx.cr6.eq) goto loc_8B0B9A10;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// addi r4,r11,28292
	ctx.r4.s64 = ctx.r11.s64 + 28292;
	// bl 0x8b0bf9f8
	ctx.lr = 0x8B0B9A08;
	sub_8B0BF9F8(ctx, base);
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// b 0x8b0b9a14
	goto loc_8B0B9A14;
loc_8B0B9A10:
	// li r4,0
	ctx.r4.s64 = 0;
loc_8B0B9A14:
	// lwz r11,0(r30)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r30.u32 + 0);
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// lwz r10,48(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 48);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B0B9A28;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
loc_8B0B9A28:
	// addi r1,r1,112
	ctx.r1.s64 = ctx.r1.s64 + 112;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// ld r30,-24(r1)
	ctx.r30.u64 = REX_LOAD_U64(ctx.r1.u32 + -24);
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0B9DA8) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9bc
	ctx.lr = 0x8B0B9DB0;
	__savegprlr_29(ctx, base);
	// stwu r1,-112(r1)
	ea = -112 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// mr r3,r4
	ctx.r3.u64 = ctx.r4.u64;
	// mr r29,r4
	ctx.r29.u64 = ctx.r4.u64;
	// bl 0x8b0beee8
	ctx.lr = 0x8B0B9DC4;
	sub_8B0BEEE8(ctx, base);
	// lis r11,-29943
	ctx.r11.s64 = -1962344448;
	// mr r30,r3
	ctx.r30.u64 = ctx.r3.u64;
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// addi r3,r11,-32112
	ctx.r3.s64 = ctx.r11.s64 + -32112;
	// bl 0x8b0cea10
	ctx.lr = 0x8B0B9DD8;
	sub_8B0CEA10(ctx, base);
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// bne cr6,0x8b0b9e3c
	if (!ctx.cr6.eq) goto loc_8B0B9E3C;
	// mr r3,r29
	ctx.r3.u64 = ctx.r29.u64;
	// bl 0x8b0bf248
	ctx.lr = 0x8B0B9DE8;
	sub_8B0BF248(ctx, base);
	// mr r30,r3
	ctx.r30.u64 = ctx.r3.u64;
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0b9e28
	if (ctx.cr6.eq) goto loc_8B0B9E28;
	// li r5,0
	ctx.r5.s64 = 0;
	// lwz r3,8(r31)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r31.u32 + 8);
	// mr r4,r30
	ctx.r4.u64 = ctx.r30.u64;
	// bl 0x8b0c0668
	ctx.lr = 0x8B0B9E04;
	sub_8B0C0668(ctx, base);
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// bl 0x8b0c0298
	ctx.lr = 0x8B0B9E0C;
	sub_8B0C0298(ctx, base);
	// mr r30,r3
	ctx.r30.u64 = ctx.r3.u64;
	// lwz r3,84(r31)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r31.u32 + 84);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0b9e20
	if (ctx.cr6.eq) goto loc_8B0B9E20;
	// bl 0x8b0c04f0
	ctx.lr = 0x8B0B9E20;
	sub_8B0C04F0(ctx, base);
loc_8B0B9E20:
	// stw r30,84(r31)
	REX_STORE_U32(ctx.r31.u32 + 84, ctx.r30.u32);
	// stw r30,88(r31)
	REX_STORE_U32(ctx.r31.u32 + 88, ctx.r30.u32);
loc_8B0B9E28:
	// mr r4,r29
	ctx.r4.u64 = ctx.r29.u64;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0b9860
	ctx.lr = 0x8B0B9E34;
	sub_8B0B9860(ctx, base);
	// addi r1,r1,112
	ctx.r1.s64 = ctx.r1.s64 + 112;
	// b 0x8b0cba0c
	__restgprlr_29(ctx, base);
	return;
loc_8B0B9E3C:
	// lis r11,-29943
	ctx.r11.s64 = -1962344448;
	// mr r4,r30
	ctx.r4.u64 = ctx.r30.u64;
	// addi r3,r11,-32140
	ctx.r3.s64 = ctx.r11.s64 + -32140;
	// bl 0x8b0cea10
	ctx.lr = 0x8B0B9E4C;
	sub_8B0CEA10(ctx, base);
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// bne cr6,0x8b0b9e9c
	if (!ctx.cr6.eq) goto loc_8B0B9E9C;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lwz r3,8(r31)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r31.u32 + 8);
	// lis r10,-29943
	ctx.r10.s64 = -1962344448;
	// addi r5,r11,1791
	ctx.r5.s64 = ctx.r11.s64 + 1791;
	// addi r4,r10,-32156
	ctx.r4.s64 = ctx.r10.s64 + -32156;
	// bl 0x8b0c1588
	ctx.lr = 0x8B0B9E6C;
	sub_8B0C1588(ctx, base);
	// lis r9,-29944
	ctx.r9.s64 = -1962409984;
	// addi r4,r9,10100
	ctx.r4.s64 = ctx.r9.s64 + 10100;
	// bl 0x8b0cea10
	ctx.lr = 0x8B0B9E78;
	sub_8B0CEA10(ctx, base);
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bne cr6,0x8b0b9e90
	if (!ctx.cr6.eq) goto loc_8B0B9E90;
	// bl 0x8b0b9958
	ctx.lr = 0x8B0B9E88;
	sub_8B0B9958(ctx, base);
	// addi r1,r1,112
	ctx.r1.s64 = ctx.r1.s64 + 112;
	// b 0x8b0cba0c
	__restgprlr_29(ctx, base);
	return;
loc_8B0B9E90:
	// bl 0x8b0b9a40
	ctx.lr = 0x8B0B9E94;
	sub_8B0B9A40(ctx, base);
	// addi r1,r1,112
	ctx.r1.s64 = ctx.r1.s64 + 112;
	// b 0x8b0cba0c
	__restgprlr_29(ctx, base);
	return;
loc_8B0B9E9C:
	// lis r11,-29943
	ctx.r11.s64 = -1962344448;
	// mr r4,r30
	ctx.r4.u64 = ctx.r30.u64;
	// addi r3,r11,-32188
	ctx.r3.s64 = ctx.r11.s64 + -32188;
	// bl 0x8b0cea10
	ctx.lr = 0x8B0B9EAC;
	sub_8B0CEA10(ctx, base);
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// bne cr6,0x8b0b9e28
	if (!ctx.cr6.eq) goto loc_8B0B9E28;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0b94a0
	ctx.lr = 0x8B0B9EBC;
	sub_8B0B94A0(ctx, base);
	// addi r1,r1,112
	ctx.r1.s64 = ctx.r1.s64 + 112;
	// b 0x8b0cba0c
	__restgprlr_29(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0BA228) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9bc
	ctx.lr = 0x8B0BA230;
	__savegprlr_29(ctx, base);
	// stwu r1,-112(r1)
	ea = -112 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lwz r11,48(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 48);
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// cmpwi cr6,r11,0
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// beq cr6,0x8b0ba298
	if (ctx.cr6.eq) goto loc_8B0BA298;
	// cmpwi cr6,r11,2
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 2, ctx.xer);
	// bne cr6,0x8b0ba3a8
	if (!ctx.cr6.eq) goto loc_8B0BA3A8;
	// lwz r3,76(r3)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r3.u32 + 76);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0ba3a8
	if (ctx.cr6.eq) goto loc_8B0BA3A8;
	// lwz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r10,8(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 8);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B0BA268;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// lwz r3,76(r31)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r31.u32 + 76);
	// lwz r9,0(r3)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r8,16(r9)
	ctx.r8.u64 = REX_LOAD_U32(ctx.r9.u32 + 16);
	// mtctr r8
	ctx.ctr.u64 = ctx.r8.u64;
	// bctrl 
	ctx.lr = 0x8B0BA27C;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// clrlwi r7,r3,24
	ctx.r7.u64 = ctx.r3.u32 & 0xFF;
	// cmplwi cr6,r7,0
	ctx.cr6.compare<uint32_t>(ctx.r7.u32, 0, ctx.xer);
	// beq cr6,0x8b0ba3a8
	if (ctx.cr6.eq) goto loc_8B0BA3A8;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0b9b90
	ctx.lr = 0x8B0BA290;
	sub_8B0B9B90(ctx, base);
	// addi r1,r1,112
	ctx.r1.s64 = ctx.r1.s64 + 112;
	// b 0x8b0cba0c
	__restgprlr_29(ctx, base);
	return;
loc_8B0BA298:
	// lwz r3,64(r31)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r31.u32 + 64);
	// lwz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r10,4(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 4);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B0BA2AC;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// lis r9,-29944
	ctx.r9.s64 = -1962409984;
	// li r5,0
	ctx.r5.s64 = 0;
	// addi r4,r9,28028
	ctx.r4.s64 = ctx.r9.s64 + 28028;
	// bl 0x8b0bfa88
	ctx.lr = 0x8B0BA2BC;
	sub_8B0BFA88(ctx, base);
	// mr r29,r3
	ctx.r29.u64 = ctx.r3.u64;
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0ba3a8
	if (ctx.cr6.eq) goto loc_8B0BA3A8;
	// li r3,36
	ctx.r3.s64 = 36;
	// bl 0x8b0bf448
	ctx.lr = 0x8B0BA2D0;
	sub_8B0BF448(ctx, base);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0ba3a0
	if (ctx.cr6.eq) goto loc_8B0BA3A0;
	// lis r11,-29943
	ctx.r11.s64 = -1962344448;
	// addi r4,r11,-32248
	ctx.r4.s64 = ctx.r11.s64 + -32248;
	// bl 0x8b0bf9f8
	ctx.lr = 0x8B0BA2E4;
	sub_8B0BF9F8(ctx, base);
	// mr r30,r3
	ctx.r30.u64 = ctx.r3.u64;
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0ba3a0
	if (ctx.cr6.eq) goto loc_8B0BA3A0;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// addi r5,r11,3616
	ctx.r5.s64 = ctx.r11.s64 + 3616;
	// addi r4,r10,3900
	ctx.r4.s64 = ctx.r10.s64 + 3900;
	// bl 0x8b0c0010
	ctx.lr = 0x8B0BA304;
	sub_8B0C0010(ctx, base);
	// lis r9,-29944
	ctx.r9.s64 = -1962409984;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// ld r5,56(r31)
	ctx.r5.u64 = REX_LOAD_U64(ctx.r31.u32 + 56);
	// addi r4,r9,16316
	ctx.r4.s64 = ctx.r9.s64 + 16316;
	// bl 0x8b0c0190
	ctx.lr = 0x8B0BA318;
	sub_8B0C0190(ctx, base);
	// mr r3,r29
	ctx.r3.u64 = ctx.r29.u64;
	// bl 0x8b0c0298
	ctx.lr = 0x8B0BA320;
	sub_8B0C0298(ctx, base);
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// bl 0x8b0bfc00
	ctx.lr = 0x8B0BA32C;
	sub_8B0BFC00(ctx, base);
	// lis r8,-29944
	ctx.r8.s64 = -1962409984;
	// lis r7,-29944
	ctx.r7.s64 = -1962409984;
	// addi r5,r8,10084
	ctx.r5.s64 = ctx.r8.s64 + 10084;
	// addi r4,r7,4588
	ctx.r4.s64 = ctx.r7.s64 + 4588;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// bl 0x8b0c0010
	ctx.lr = 0x8B0BA344;
	sub_8B0C0010(ctx, base);
	// lis r6,-29944
	ctx.r6.s64 = -1962409984;
	// li r5,2
	ctx.r5.s64 = 2;
	// addi r4,r6,3840
	ctx.r4.s64 = ctx.r6.s64 + 3840;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// bl 0x8b0c0148
	ctx.lr = 0x8B0BA358;
	sub_8B0C0148(ctx, base);
	// lwz r11,44(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 44);
	// cmpwi cr6,r11,3
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 3, ctx.xer);
	// beq cr6,0x8b0ba380
	if (ctx.cr6.eq) goto loc_8B0BA380;
	// cmpwi cr6,r11,4
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 4, ctx.xer);
	// beq cr6,0x8b0ba378
	if (ctx.cr6.eq) goto loc_8B0BA378;
	// lwz r3,68(r31)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r31.u32 + 68);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// bne cr6,0x8b0ba384
	if (!ctx.cr6.eq) goto loc_8B0BA384;
loc_8B0BA378:
	// lwz r3,72(r31)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r31.u32 + 72);
	// b 0x8b0ba384
	goto loc_8B0BA384;
loc_8B0BA380:
	// lwz r3,68(r31)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r31.u32 + 68);
loc_8B0BA384:
	// lwz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// mr r4,r30
	ctx.r4.u64 = ctx.r30.u64;
	// lwz r10,24(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 24);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B0BA398;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// bl 0x8b0c04f0
	ctx.lr = 0x8B0BA3A0;
	sub_8B0C04F0(ctx, base);
loc_8B0BA3A0:
	// li r11,3
	ctx.r11.s64 = 3;
	// stw r11,48(r31)
	REX_STORE_U32(ctx.r31.u32 + 48, ctx.r11.u32);
loc_8B0BA3A8:
	// addi r1,r1,112
	ctx.r1.s64 = ctx.r1.s64 + 112;
	// b 0x8b0cba0c
	__restgprlr_29(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0BAD28) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// std r30,-24(r1)
	REX_STORE_U64(ctx.r1.u32 + -24, ctx.r30.u64);
	// std r31,-16(r1)
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.r31.u64);
	// stwu r1,-112(r1)
	ea = -112 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// lwz r3,12(r3)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r3.u32 + 12);
	// li r30,0
	ctx.r30.s64 = 0;
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0bad64
	if (ctx.cr6.eq) goto loc_8B0BAD64;
	// lwz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r10,16(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 16);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B0BAD60;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// stw r30,12(r31)
	REX_STORE_U32(ctx.r31.u32 + 12, ctx.r30.u32);
loc_8B0BAD64:
	// lwz r11,784(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 784);
	// cmpwi cr6,r11,2
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 2, ctx.xer);
	// beq cr6,0x8b0bad8c
	if (ctx.cr6.eq) goto loc_8B0BAD8C;
	// cmpwi cr6,r11,3
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 3, ctx.xer);
	// ble cr6,0x8b0bada0
	if (!ctx.cr6.gt) goto loc_8B0BADA0;
	// cmpwi cr6,r11,5
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 5, ctx.xer);
	// bgt cr6,0x8b0bada0
	if (ctx.cr6.gt) goto loc_8B0BADA0;
	// addi r3,r31,296
	ctx.r3.s64 = ctx.r31.s64 + 296;
	// bl 0x8b0b6540
	ctx.lr = 0x8B0BAD88;
	sub_8B0B6540(ctx, base);
	// b 0x8b0bada0
	goto loc_8B0BADA0;
loc_8B0BAD8C:
	// lwz r3,16(r31)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r31.u32 + 16);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0bad9c
	if (ctx.cr6.eq) goto loc_8B0BAD9C;
	// bl 0x8b0b71e0
	ctx.lr = 0x8B0BAD9C;
	sub_8B0B71E0(ctx, base);
loc_8B0BAD9C:
	// stw r30,16(r31)
	REX_STORE_U32(ctx.r31.u32 + 16, ctx.r30.u32);
loc_8B0BADA0:
	// lwz r11,0(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 0);
	// li r4,1
	ctx.r4.s64 = 1;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// lwz r10,4(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 4);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B0BADB8;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// addi r1,r1,112
	ctx.r1.s64 = ctx.r1.s64 + 112;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// ld r30,-24(r1)
	ctx.r30.u64 = REX_LOAD_U64(ctx.r1.u32 + -24);
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0BAEB8) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9ac
	ctx.lr = 0x8B0BAEC0;
	__savegprlr_25(ctx, base);
	// stwu r1,-176(r1)
	ea = -176 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// mr r27,r3
	ctx.r27.u64 = ctx.r3.u64;
	// li r4,100
	ctx.r4.s64 = 100;
	// li r3,5
	ctx.r3.s64 = 5;
	// bl 0x8b0df558
	ctx.lr = 0x8B0BAED4;
	sub_8B0DF558(ctx, base);
	// lis r30,-29938
	ctx.r30.s64 = -1962016768;
	// clrlwi r28,r3,24
	ctx.r28.u64 = ctx.r3.u32 & 0xFF;
	// li r29,0
	ctx.r29.s64 = 0;
	// lwz r11,2548(r30)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r30.u32 + 2548);
	// lwz r31,0(r11)
	ctx.r31.u64 = REX_LOAD_U32(ctx.r11.u32 + 0);
	// bl 0x8b0df318
	ctx.lr = 0x8B0BAEEC;
	sub_8B0DF318(ctx, base);
	// lwz r11,4(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 4);
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// lwz r3,2548(r30)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r30.u32 + 2548);
	// mtctr r11
	ctx.ctr.u64 = ctx.r11.u64;
	// bctrl 
	ctx.lr = 0x8B0BAF00;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0baf88
	if (ctx.cr6.eq) goto loc_8B0BAF88;
	// lwz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r10,8(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 8);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B0BAF18;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// mr r11,r3
	ctx.r11.u64 = ctx.r3.u64;
loc_8B0BAF20:
	// lbz r10,0(r11)
	ctx.r10.u64 = REX_LOAD_U8(ctx.r11.u32 + 0);
	// addi r11,r11,1
	ctx.r11.s64 = ctx.r11.s64 + 1;
	// cmplwi cr6,r10,0
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 0, ctx.xer);
	// bne cr6,0x8b0baf20
	if (!ctx.cr6.eq) goto loc_8B0BAF20;
	// subf r11,r31,r11
	ctx.r11.u64 = ctx.r11.u64 - ctx.r31.u64;
	// addi r3,r1,96
	ctx.r3.s64 = ctx.r1.s64 + 96;
	// addi r11,r11,-1
	ctx.r11.s64 = ctx.r11.s64 + -1;
	// rotlwi r30,r11,0
	ctx.r30.u64 = __builtin_rotateleft32(ctx.r11.u32, 0);
	// bl 0x8b0c73c0
	ctx.lr = 0x8B0BAF44;
	sub_8B0C73C0(ctx, base);
	// mr r5,r30
	ctx.r5.u64 = ctx.r30.u64;
	// mr r4,r31
	ctx.r4.u64 = ctx.r31.u64;
	// addi r3,r1,96
	ctx.r3.s64 = ctx.r1.s64 + 96;
	// bl 0x8b0c73e0
	ctx.lr = 0x8B0BAF54;
	sub_8B0C73E0(ctx, base);
	// addi r3,r1,96
	ctx.r3.s64 = ctx.r1.s64 + 96;
	// bl 0x8b0c73d0
	ctx.lr = 0x8B0BAF5C;
	sub_8B0C73D0(ctx, base);
	// clrlwi r10,r28,24
	ctx.r10.u64 = ctx.r28.u32 & 0xFF;
	// rlwinm r9,r28,8,16,23
	ctx.r9.u64 = __builtin_rotateleft64(ctx.r28.u32 | (ctx.r28.u64 << 32), 8) & 0xFF00;
	// lwz r3,96(r1)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r1.u32 + 96);
	// or r8,r9,r10
	ctx.r8.u64 = ctx.r9.u64 | ctx.r10.u64;
	// rlwinm r7,r8,8,0,23
	ctx.r7.u64 = __builtin_rotateleft64(ctx.r8.u32 | (ctx.r8.u64 << 32), 8) & 0xFFFFFF00;
	// or r6,r7,r10
	ctx.r6.u64 = ctx.r7.u64 | ctx.r10.u64;
	// rlwinm r5,r6,8,0,23
	ctx.r5.u64 = __builtin_rotateleft64(ctx.r6.u32 | (ctx.r6.u64 << 32), 8) & 0xFFFFFF00;
	// or r4,r5,r10
	ctx.r4.u64 = ctx.r5.u64 | ctx.r10.u64;
	// xor r29,r4,r3
	ctx.r29.u64 = ctx.r4.u64 ^ ctx.r3.u64;
	// cmplwi cr6,r29,0
	ctx.cr6.compare<uint32_t>(ctx.r29.u32, 0, ctx.xer);
	// bne cr6,0x8b0baf8c
	if (!ctx.cr6.eq) goto loc_8B0BAF8C;
loc_8B0BAF88:
	// li r28,0
	ctx.r28.s64 = 0;
loc_8B0BAF8C:
	// lis r10,-29938
	ctx.r10.s64 = -1962016768;
	// lis r11,-29938
	ctx.r11.s64 = -1962016768;
	// addi r31,r11,21888
	ctx.r31.s64 = ctx.r11.s64 + 21888;
	// lwz r11,21896(r10)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r10.u32 + 21896);
	// clrlwi r9,r11,31
	ctx.r9.u64 = ctx.r11.u32 & 0x1;
	// cmplwi cr6,r9,0
	ctx.cr6.compare<uint32_t>(ctx.r9.u32, 0, ctx.xer);
	// bne cr6,0x8b0bafc0
	if (!ctx.cr6.eq) goto loc_8B0BAFC0;
	// ori r11,r11,1
	ctx.r11.u64 = ctx.r11.u64 | 1;
	// lis r9,-29943
	ctx.r9.s64 = -1962344448;
	// stw r11,21896(r10)
	REX_STORE_U32(ctx.r10.u32 + 21896, ctx.r11.u32);
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// addi r4,r9,-31484
	ctx.r4.s64 = ctx.r9.s64 + -31484;
	// bl 0x8b0c6f58
	ctx.lr = 0x8B0BAFC0;
	sub_8B0C6F58(ctx, base);
loc_8B0BAFC0:
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0c69f8
	ctx.lr = 0x8B0BAFC8;
	sub_8B0C69F8(ctx, base);
	// clrlwi r11,r3,24
	ctx.r11.u64 = ctx.r3.u32 & 0xFF;
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// beq cr6,0x8b0bafe0
	if (ctx.cr6.eq) goto loc_8B0BAFE0;
	// lwz r11,4(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 4);
	// lwz r30,36(r11)
	ctx.r30.u64 = REX_LOAD_U32(ctx.r11.u32 + 36);
	// b 0x8b0bafe8
	goto loc_8B0BAFE8;
loc_8B0BAFE0:
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// addi r30,r11,1791
	ctx.r30.s64 = ctx.r11.s64 + 1791;
loc_8B0BAFE8:
	// lbz r11,0(r30)
	ctx.r11.u64 = REX_LOAD_U8(ctx.r30.u32 + 0);
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// bne cr6,0x8b0baffc
	if (!ctx.cr6.eq) goto loc_8B0BAFFC;
	// lis r11,-29943
	ctx.r11.s64 = -1962344448;
	// addi r30,r11,-31492
	ctx.r30.s64 = ctx.r11.s64 + -31492;
loc_8B0BAFFC:
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lwz r3,760(r27)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r27.u32 + 760);
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// addi r5,r11,5788
	ctx.r5.s64 = ctx.r11.s64 + 5788;
	// addi r4,r10,5920
	ctx.r4.s64 = ctx.r10.s64 + 5920;
	// addi r31,r27,36
	ctx.r31.s64 = ctx.r27.s64 + 36;
	// bl 0x8b0c1588
	ctx.lr = 0x8B0BB018;
	sub_8B0C1588(ctx, base);
	// lis r9,-29944
	ctx.r9.s64 = -1962409984;
	// li r5,0
	ctx.r5.s64 = 0;
	// addi r4,r9,5468
	ctx.r4.s64 = ctx.r9.s64 + 5468;
	// mr r26,r3
	ctx.r26.u64 = ctx.r3.u64;
	// lwz r3,760(r27)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r27.u32 + 760);
	// bl 0x8b0bfc38
	ctx.lr = 0x8B0BB030;
	sub_8B0BFC38(ctx, base);
	// lis r8,-29944
	ctx.r8.s64 = -1962409984;
	// li r5,0
	ctx.r5.s64 = 0;
	// addi r4,r8,5432
	ctx.r4.s64 = ctx.r8.s64 + 5432;
	// mr r25,r3
	ctx.r25.u64 = ctx.r3.u64;
	// lwz r3,760(r27)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r27.u32 + 760);
	// bl 0x8b0bfc38
	ctx.lr = 0x8B0BB048;
	sub_8B0BFC38(ctx, base);
	// lis r6,-29943
	ctx.r6.s64 = -1962344448;
	// mr r7,r3
	ctx.r7.u64 = ctx.r3.u64;
	// stw r29,84(r1)
	REX_STORE_U32(ctx.r1.u32 + 84, ctx.r29.u32);
	// addi r5,r6,-31556
	ctx.r5.s64 = ctx.r6.s64 + -31556;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// mr r6,r30
	ctx.r6.u64 = ctx.r30.u64;
	// li r4,260
	ctx.r4.s64 = 260;
	// mr r8,r25
	ctx.r8.u64 = ctx.r25.u64;
	// mr r9,r26
	ctx.r9.u64 = ctx.r26.u64;
	// clrlwi r10,r28,24
	ctx.r10.u64 = ctx.r28.u32 & 0xFF;
	// bl 0x8b0c3fd8
	ctx.lr = 0x8B0BB074;
	sub_8B0C3FD8(ctx, base);
	// lis r5,-29943
	ctx.r5.s64 = -1962344448;
	// mr r4,r31
	ctx.r4.u64 = ctx.r31.u64;
	// addi r3,r5,-31580
	ctx.r3.s64 = ctx.r5.s64 + -31580;
	// bl 0x8b0df298
	ctx.lr = 0x8B0BB084;
	sub_8B0DF298(ctx, base);
	// addi r1,r1,176
	ctx.r1.s64 = ctx.r1.s64 + 176;
	// b 0x8b0cb9fc
	__restgprlr_25(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0BB6D0) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9bc
	ctx.lr = 0x8B0BB6D8;
	__savegprlr_29(ctx, base);
	// stwu r1,-112(r1)
	ea = -112 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lwz r10,12(r3)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r3.u32 + 12);
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// lwz r11,4(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 4);
	// mr r30,r4
	ctx.r30.u64 = ctx.r4.u64;
	// addi r9,r10,1
	ctx.r9.s64 = ctx.r10.s64 + 1;
	// mr r29,r5
	ctx.r29.u64 = ctx.r5.u64;
	// cmpw cr6,r9,r11
	ctx.cr6.compare<int32_t>(ctx.r9.s32, ctx.r11.s32, ctx.xer);
	// ble cr6,0x8b0bb708
	if (!ctx.cr6.gt) goto loc_8B0BB708;
	// subf r11,r11,r10
	ctx.r11.u64 = ctx.r10.u64 - ctx.r11.u64;
	// addi r4,r11,1
	ctx.r4.s64 = ctx.r11.s64 + 1;
	// bl 0x8b0bb110
	ctx.lr = 0x8B0BB708;
	sub_8B0BB110(ctx, base);
loc_8B0BB708:
	// lwz r11,12(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 12);
	// addi r11,r11,1
	ctx.r11.s64 = ctx.r11.s64 + 1;
	// subf r10,r30,r11
	ctx.r10.u64 = ctx.r11.u64 - ctx.r30.u64;
	// stw r11,12(r31)
	REX_STORE_U32(ctx.r31.u32 + 12, ctx.r11.u32);
	// addic. r11,r10,-1
	ctx.xer.ca = ctx.r10.u32 > 0;
	ctx.r11.s64 = ctx.r10.s64 + -1;
	ctx.cr0.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// ble 0x8b0bb738
	if (!ctx.cr0.gt) goto loc_8B0BB738;
	// lwz r9,0(r31)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r31.u32 + 0);
	// rlwinm r10,r30,1,0,30
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r30.u32 | (ctx.r30.u64 << 32), 1) & 0xFFFFFFFE;
	// rlwinm r5,r11,1,0,30
	ctx.r5.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 1) & 0xFFFFFFFE;
	// add r4,r10,r9
	ctx.r4.u64 = ctx.r10.u64 + ctx.r9.u64;
	// addi r3,r4,2
	ctx.r3.s64 = ctx.r4.s64 + 2;
	// bl 0x8b0cc060
	ctx.lr = 0x8B0BB738;
	sub_8B0CC060(ctx, base);
loc_8B0BB738:
	// lwz r10,0(r31)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r31.u32 + 0);
	// rlwinm r11,r30,1,0,30
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r30.u32 | (ctx.r30.u64 << 32), 1) & 0xFFFFFFFE;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// add. r11,r11,r10
	ctx.r11.u64 = ctx.r11.u64 + ctx.r10.u64;
	ctx.cr0.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// beq 0x8b0bb754
	if (ctx.cr0.eq) goto loc_8B0BB754;
	// lhz r10,0(r29)
	ctx.r10.u64 = REX_LOAD_U16(ctx.r29.u32 + 0);
	// sth r10,0(r11)
	REX_STORE_U16(ctx.r11.u32 + 0, ctx.r10.u16);
loc_8B0BB754:
	// addi r1,r1,112
	ctx.r1.s64 = ctx.r1.s64 + 112;
	// b 0x8b0cba0c
	__restgprlr_29(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0BB920) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9bc
	ctx.lr = 0x8B0BB928;
	__savegprlr_29(ctx, base);
	// stwu r1,-112(r1)
	ea = -112 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lis r11,-29943
	ctx.r11.s64 = -1962344448;
	// lis r10,-29943
	ctx.r10.s64 = -1962344448;
	// addi r9,r11,-31252
	ctx.r9.s64 = ctx.r11.s64 + -31252;
	// addi r8,r10,-31260
	ctx.r8.s64 = ctx.r10.s64 + -31260;
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// stw r9,0(r3)
	REX_STORE_U32(ctx.r3.u32 + 0, ctx.r9.u32);
	// stw r8,4(r3)
	REX_STORE_U32(ctx.r3.u32 + 4, ctx.r8.u32);
	// lwz r3,780(r3)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r3.u32 + 780);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0bb958
	if (ctx.cr6.eq) goto loc_8B0BB958;
	// bl 0x8b0c04f0
	ctx.lr = 0x8B0BB958;
	sub_8B0C04F0(ctx, base);
loc_8B0BB958:
	// li r29,0
	ctx.r29.s64 = 0;
	// addi r30,r31,744
	ctx.r30.s64 = ctx.r31.s64 + 744;
	// stw r29,756(r31)
	REX_STORE_U32(ctx.r31.u32 + 756, ctx.r29.u32);
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// bl 0x8b0906a8
	ctx.lr = 0x8B0BB96C;
	sub_8B0906A8(ctx, base);
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// bl 0x8b0906a8
	ctx.lr = 0x8B0BB974;
	sub_8B0906A8(ctx, base);
	// stw r29,32(r31)
	REX_STORE_U32(ctx.r31.u32 + 32, ctx.r29.u32);
	// addi r30,r31,20
	ctx.r30.s64 = ctx.r31.s64 + 20;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// bl 0x8b0906a8
	ctx.lr = 0x8B0BB984;
	sub_8B0906A8(ctx, base);
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// bl 0x8b0906a8
	ctx.lr = 0x8B0BB98C;
	sub_8B0906A8(ctx, base);
	// addi r1,r1,112
	ctx.r1.s64 = ctx.r1.s64 + 112;
	// b 0x8b0cba0c
	__restgprlr_29(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0BBB48) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9b0
	ctx.lr = 0x8B0BBB50;
	__savegprlr_26(ctx, base);
	// stwu r1,-464(r1)
	ea = -464 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// mr r26,r3
	ctx.r26.u64 = ctx.r3.u64;
	// cmpwi cr6,r5,8
	ctx.cr6.compare<int32_t>(ctx.r5.s32, 8, ctx.xer);
	// blt cr6,0x8b0bc028
	if (ctx.cr6.lt) goto loc_8B0BC028;
	// li r30,0
	ctx.r30.s64 = 0;
	// li r11,-1
	ctx.r11.s64 = -1;
	// stb r30,100(r1)
	REX_STORE_U8(ctx.r1.u32 + 100, ctx.r30.u8);
	// li r7,-1
	ctx.r7.s64 = -1;
	// stw r30,96(r1)
	REX_STORE_U32(ctx.r1.u32 + 96, ctx.r30.u32);
	// li r6,0
	ctx.r6.s64 = 0;
	// stw r11,104(r1)
	REX_STORE_U32(ctx.r1.u32 + 104, ctx.r11.u32);
	// addi r3,r1,96
	ctx.r3.s64 = ctx.r1.s64 + 96;
	// stw r30,108(r1)
	REX_STORE_U32(ctx.r1.u32 + 108, ctx.r30.u32);
	// bl 0x8b0c9768
	ctx.lr = 0x8B0BBB88;
	sub_8B0C9768(ctx, base);
	// lis r11,-29943
	ctx.r11.s64 = -1962344448;
	// lwz r9,116(r1)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r1.u32 + 116);
	// li r27,32
	ctx.r27.s64 = 32;
	// addi r28,r11,-25896
	ctx.r28.s64 = ctx.r11.s64 + -25896;
	// lwz r7,124(r1)
	ctx.r7.u64 = REX_LOAD_U32(ctx.r1.u32 + 124);
	// li r29,1
	ctx.r29.s64 = 1;
	// cmpwi cr6,r9,32
	ctx.cr6.compare<int32_t>(ctx.r9.s32, 32, ctx.xer);
	// lwz r11,120(r1)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r1.u32 + 120);
	// blt cr6,0x8b0bbc4c
	if (ctx.cr6.lt) goto loc_8B0BBC4C;
	// addic. r9,r9,-32
	ctx.xer.ca = ctx.r9.u32 > 31;
	ctx.r9.s64 = ctx.r9.s64 + -32;
	ctx.cr0.compare<int32_t>(ctx.r9.s32, 0, ctx.xer);
	// stw r9,116(r1)
	REX_STORE_U32(ctx.r1.u32 + 116, ctx.r9.u32);
	// beq 0x8b0bbbc0
	if (ctx.cr0.eq) goto loc_8B0BBBC0;
	// mr r10,r30
	ctx.r10.u64 = ctx.r30.u64;
	// b 0x8b0bbcb0
	goto loc_8B0BBCB0;
loc_8B0BBBC0:
	// lwz r7,124(r1)
	ctx.r7.u64 = REX_LOAD_U32(ctx.r1.u32 + 124);
	// mr r9,r27
	ctx.r9.u64 = ctx.r27.u64;
	// stw r27,116(r1)
	REX_STORE_U32(ctx.r1.u32 + 116, ctx.r27.u32);
	// cmplw cr6,r11,r7
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, ctx.r7.u32, ctx.xer);
	// bne cr6,0x8b0bbc18
	if (!ctx.cr6.eq) goto loc_8B0BBC18;
	// li r29,1
	ctx.r29.s64 = 1;
	// stw r30,112(r1)
	REX_STORE_U32(ctx.r1.u32 + 112, ctx.r30.u32);
	// addi r11,r11,4
	ctx.r11.s64 = ctx.r11.s64 + 4;
	// mr r10,r30
	ctx.r10.u64 = ctx.r30.u64;
	// stw r29,116(r1)
	REX_STORE_U32(ctx.r1.u32 + 116, ctx.r29.u32);
	// mr r9,r29
	ctx.r9.u64 = ctx.r29.u64;
	// stw r11,120(r1)
	REX_STORE_U32(ctx.r1.u32 + 120, ctx.r11.u32);
loc_8B0BBBF0:
	// subfic r8,r9,32
	ctx.xer.ca = ctx.r9.u32 <= 32;
	ctx.r8.u64 = static_cast<uint64_t>(32) - ctx.r9.u64;
	// cmplw cr6,r11,r7
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, ctx.r7.u32, ctx.xer);
	// bne cr6,0x8b0bbd38
	if (!ctx.cr6.eq) goto loc_8B0BBD38;
	// addi r7,r11,4
	ctx.r7.s64 = ctx.r11.s64 + 4;
	// stb r29,100(r1)
	REX_STORE_U8(ctx.r1.u32 + 100, ctx.r29.u8);
	// mr r9,r29
	ctx.r9.u64 = ctx.r29.u64;
	// stw r29,116(r1)
	REX_STORE_U32(ctx.r1.u32 + 116, ctx.r29.u32);
	// mr r11,r30
	ctx.r11.u64 = ctx.r30.u64;
	// stw r7,120(r1)
	REX_STORE_U32(ctx.r1.u32 + 120, ctx.r7.u32);
	// b 0x8b0bbd60
	goto loc_8B0BBD60;
loc_8B0BBC18:
	// ble cr6,0x8b0bbc2c
	if (!ctx.cr6.gt) goto loc_8B0BBC2C;
	// mr r10,r30
	ctx.r10.u64 = ctx.r30.u64;
	// stb r29,100(r1)
	REX_STORE_U8(ctx.r1.u32 + 100, ctx.r29.u8);
	// stw r30,112(r1)
	REX_STORE_U32(ctx.r1.u32 + 112, ctx.r30.u32);
	// b 0x8b0bbcbc
	goto loc_8B0BBCBC;
loc_8B0BBC2C:
	// lwz r10,0(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 0);
	// addi r8,r1,80
	ctx.r8.s64 = ctx.r1.s64 + 80;
	// addi r11,r11,4
	ctx.r11.s64 = ctx.r11.s64 + 4;
	// stw r11,120(r1)
	REX_STORE_U32(ctx.r1.u32 + 120, ctx.r11.u32);
	// stwbrx r10,0,r8
	REX_STORE_U32(ctx.r8.u32, __builtin_bswap32(ctx.r10.u32));
	// lwz r10,80(r1)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r1.u32 + 80);
	// stw r10,112(r1)
	REX_STORE_U32(ctx.r1.u32 + 112, ctx.r10.u32);
	// b 0x8b0bbcbc
	goto loc_8B0BBCBC;
loc_8B0BBC4C:
	// subfic r8,r9,32
	ctx.xer.ca = ctx.r9.u32 <= 32;
	ctx.r8.u64 = static_cast<uint64_t>(32) - ctx.r9.u64;
	// cmplw cr6,r11,r7
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, ctx.r7.u32, ctx.xer);
	// bne cr6,0x8b0bbc6c
	if (!ctx.cr6.eq) goto loc_8B0BBC6C;
	// mr r9,r29
	ctx.r9.u64 = ctx.r29.u64;
	// stb r29,100(r1)
	REX_STORE_U8(ctx.r1.u32 + 100, ctx.r29.u8);
	// mr r10,r30
	ctx.r10.u64 = ctx.r30.u64;
	// stw r29,116(r1)
	REX_STORE_U32(ctx.r1.u32 + 116, ctx.r29.u32);
	// b 0x8b0bbc8c
	goto loc_8B0BBC8C;
loc_8B0BBC6C:
	// ble cr6,0x8b0bbc7c
	if (!ctx.cr6.gt) goto loc_8B0BBC7C;
	// mr r10,r30
	ctx.r10.u64 = ctx.r30.u64;
	// stb r29,100(r1)
	REX_STORE_U8(ctx.r1.u32 + 100, ctx.r29.u8);
	// b 0x8b0bbc94
	goto loc_8B0BBC94;
loc_8B0BBC7C:
	// lwz r10,0(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 0);
	// addi r6,r1,80
	ctx.r6.s64 = ctx.r1.s64 + 80;
	// stwbrx r10,0,r6
	REX_STORE_U32(ctx.r6.u32, __builtin_bswap32(ctx.r10.u32));
	// lwz r10,80(r1)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r1.u32 + 80);
loc_8B0BBC8C:
	// addi r11,r11,4
	ctx.r11.s64 = ctx.r11.s64 + 4;
	// stw r11,120(r1)
	REX_STORE_U32(ctx.r1.u32 + 120, ctx.r11.u32);
loc_8B0BBC94:
	// lbz r5,100(r1)
	ctx.r5.u64 = REX_LOAD_U8(ctx.r1.u32 + 100);
	// stw r10,112(r1)
	REX_STORE_U32(ctx.r1.u32 + 112, ctx.r10.u32);
	// cmplwi cr6,r5,0
	ctx.cr6.compare<uint32_t>(ctx.r5.u32, 0, ctx.xer);
	// bne cr6,0x8b0bbcb4
	if (!ctx.cr6.eq) goto loc_8B0BBCB4;
	// subfic r9,r8,32
	ctx.xer.ca = ctx.r8.u32 <= 32;
	ctx.r9.u64 = static_cast<uint64_t>(32) - ctx.r8.u64;
	// srw r10,r10,r8
	ctx.r10.u64 = ctx.r8.u8 & 0x20 ? 0 : (ctx.r10.u32 >> (ctx.r8.u8 & 0x3F));
	// stw r9,116(r1)
	REX_STORE_U32(ctx.r1.u32 + 116, ctx.r9.u32);
loc_8B0BBCB0:
	// stw r10,112(r1)
	REX_STORE_U32(ctx.r1.u32 + 112, ctx.r10.u32);
loc_8B0BBCB4:
	// cmpwi cr6,r9,32
	ctx.cr6.compare<int32_t>(ctx.r9.s32, 32, ctx.xer);
	// blt cr6,0x8b0bbbf0
	if (ctx.cr6.lt) goto loc_8B0BBBF0;
loc_8B0BBCBC:
	// lwz r8,128(r28)
	ctx.r8.u64 = REX_LOAD_U32(ctx.r28.u32 + 128);
	// addic. r9,r9,-32
	ctx.xer.ca = ctx.r9.u32 > 31;
	ctx.r9.s64 = ctx.r9.s64 + -32;
	ctx.cr0.compare<int32_t>(ctx.r9.s32, 0, ctx.xer);
	// stw r9,116(r1)
	REX_STORE_U32(ctx.r1.u32 + 116, ctx.r9.u32);
	// and r10,r10,r8
	ctx.r10.u64 = ctx.r10.u64 & ctx.r8.u64;
	// beq 0x8b0bbcdc
	if (ctx.cr0.eq) goto loc_8B0BBCDC;
	// stw r30,112(r1)
	REX_STORE_U32(ctx.r1.u32 + 112, ctx.r30.u32);
	// mr r11,r10
	ctx.r11.u64 = ctx.r10.u64;
	// b 0x8b0bbd9c
	goto loc_8B0BBD9C;
loc_8B0BBCDC:
	// cmplw cr6,r11,r7
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, ctx.r7.u32, ctx.xer);
	// stw r27,116(r1)
	REX_STORE_U32(ctx.r1.u32 + 116, ctx.r27.u32);
	// bne cr6,0x8b0bbd00
	if (!ctx.cr6.eq) goto loc_8B0BBD00;
	// addi r11,r11,4
	ctx.r11.s64 = ctx.r11.s64 + 4;
	// stw r29,116(r1)
	REX_STORE_U32(ctx.r1.u32 + 116, ctx.r29.u32);
	// stw r30,112(r1)
	REX_STORE_U32(ctx.r1.u32 + 112, ctx.r30.u32);
	// stw r11,120(r1)
	REX_STORE_U32(ctx.r1.u32 + 120, ctx.r11.u32);
	// mr r11,r10
	ctx.r11.u64 = ctx.r10.u64;
	// b 0x8b0bbd9c
	goto loc_8B0BBD9C;
loc_8B0BBD00:
	// ble cr6,0x8b0bbd14
	if (!ctx.cr6.gt) goto loc_8B0BBD14;
	// stb r29,100(r1)
	REX_STORE_U8(ctx.r1.u32 + 100, ctx.r29.u8);
	// mr r11,r10
	ctx.r11.u64 = ctx.r10.u64;
	// stw r30,112(r1)
	REX_STORE_U32(ctx.r1.u32 + 112, ctx.r30.u32);
	// b 0x8b0bbd9c
	goto loc_8B0BBD9C;
loc_8B0BBD14:
	// lwz r9,0(r11)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r11.u32 + 0);
	// addi r8,r1,80
	ctx.r8.s64 = ctx.r1.s64 + 80;
	// addi r7,r11,4
	ctx.r7.s64 = ctx.r11.s64 + 4;
	// mr r11,r10
	ctx.r11.u64 = ctx.r10.u64;
	// stw r7,120(r1)
	REX_STORE_U32(ctx.r1.u32 + 120, ctx.r7.u32);
	// stwbrx r9,0,r8
	REX_STORE_U32(ctx.r8.u32, __builtin_bswap32(ctx.r9.u32));
	// lwz r6,80(r1)
	ctx.r6.u64 = REX_LOAD_U32(ctx.r1.u32 + 80);
	// stw r6,112(r1)
	REX_STORE_U32(ctx.r1.u32 + 112, ctx.r6.u32);
	// b 0x8b0bbd9c
	goto loc_8B0BBD9C;
loc_8B0BBD38:
	// ble cr6,0x8b0bbd48
	if (!ctx.cr6.gt) goto loc_8B0BBD48;
	// mr r11,r30
	ctx.r11.u64 = ctx.r30.u64;
	// stb r29,100(r1)
	REX_STORE_U8(ctx.r1.u32 + 100, ctx.r29.u8);
	// b 0x8b0bbd60
	goto loc_8B0BBD60;
loc_8B0BBD48:
	// lwz r7,0(r11)
	ctx.r7.u64 = REX_LOAD_U32(ctx.r11.u32 + 0);
	// addi r6,r1,80
	ctx.r6.s64 = ctx.r1.s64 + 80;
	// addi r5,r11,4
	ctx.r5.s64 = ctx.r11.s64 + 4;
	// stw r5,120(r1)
	REX_STORE_U32(ctx.r1.u32 + 120, ctx.r5.u32);
	// stwbrx r7,0,r6
	REX_STORE_U32(ctx.r6.u32, __builtin_bswap32(ctx.r7.u32));
	// lwz r11,80(r1)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r1.u32 + 80);
loc_8B0BBD60:
	// lbz r6,100(r1)
	ctx.r6.u64 = REX_LOAD_U8(ctx.r1.u32 + 100);
	// stw r11,112(r1)
	REX_STORE_U32(ctx.r1.u32 + 112, ctx.r11.u32);
	// cmplwi cr6,r6,0
	ctx.cr6.compare<uint32_t>(ctx.r6.u32, 0, ctx.xer);
	// beq cr6,0x8b0bbd78
	if (ctx.cr6.eq) goto loc_8B0BBD78;
	// mr r11,r30
	ctx.r11.u64 = ctx.r30.u64;
	// b 0x8b0bbd9c
	goto loc_8B0BBD9C;
loc_8B0BBD78:
	// rlwinm r7,r8,2,0,29
	ctx.r7.u64 = __builtin_rotateleft64(ctx.r8.u32 | (ctx.r8.u64 << 32), 2) & 0xFFFFFFFC;
	// srw r6,r11,r8
	ctx.r6.u64 = ctx.r8.u8 & 0x20 ? 0 : (ctx.r11.u32 >> (ctx.r8.u8 & 0x3F));
	// lwzx r5,r7,r28
	ctx.r5.u64 = REX_LOAD_U32(ctx.r7.u32 + ctx.r28.u32);
	// subfic r4,r8,32
	ctx.xer.ca = ctx.r8.u32 <= 32;
	ctx.r4.u64 = static_cast<uint64_t>(32) - ctx.r8.u64;
	// stw r6,112(r1)
	REX_STORE_U32(ctx.r1.u32 + 112, ctx.r6.u32);
	// and r3,r5,r11
	ctx.r3.u64 = ctx.r5.u64 & ctx.r11.u64;
	// stw r4,116(r1)
	REX_STORE_U32(ctx.r1.u32 + 116, ctx.r4.u32);
	// slw r11,r3,r9
	ctx.r11.u64 = ctx.r9.u8 & 0x20 ? 0 : (ctx.r3.u32 << (ctx.r9.u8 & 0x3F));
	// or r11,r11,r10
	ctx.r11.u64 = ctx.r11.u64 | ctx.r10.u64;
loc_8B0BBD9C:
	// lwz r10,740(r26)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r26.u32 + 740);
	// cmplw cr6,r11,r10
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, ctx.r10.u32, ctx.xer);
	// bne cr6,0x8b0bc028
	if (!ctx.cr6.eq) goto loc_8B0BC028;
	// li r5,259
	ctx.r5.s64 = 259;
	// stb r30,144(r1)
	REX_STORE_U8(ctx.r1.u32 + 144, ctx.r30.u8);
	// li r4,0
	ctx.r4.s64 = 0;
	// addi r3,r1,145
	ctx.r3.s64 = ctx.r1.s64 + 145;
	// bl 0x8b0cb8e0
	ctx.lr = 0x8B0BBDBC;
	sub_8B0CB8E0(ctx, base);
	// li r7,0
	ctx.r7.s64 = 0;
	// li r6,1
	ctx.r6.s64 = 1;
	// li r5,260
	ctx.r5.s64 = 260;
	// addi r4,r1,144
	ctx.r4.s64 = ctx.r1.s64 + 144;
	// addi r3,r1,96
	ctx.r3.s64 = ctx.r1.s64 + 96;
	// bl 0x8b0c97b8
	ctx.lr = 0x8B0BBDD4;
	sub_8B0C97B8(ctx, base);
	// lbz r11,144(r1)
	ctx.r11.u64 = REX_LOAD_U8(ctx.r1.u32 + 144);
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// bne cr6,0x8b0bbe04
	if (!ctx.cr6.eq) goto loc_8B0BBE04;
	// lis r11,-29943
	ctx.r11.s64 = -1962344448;
	// addi r3,r11,-30868
	ctx.r3.s64 = ctx.r11.s64 + -30868;
	// bl 0x8b0df2e8
	ctx.lr = 0x8B0BBDEC;
	sub_8B0DF2E8(ctx, base);
	// addi r3,r26,296
	ctx.r3.s64 = ctx.r26.s64 + 296;
	// bl 0x8b0b6540
	ctx.lr = 0x8B0BBDF4;
	sub_8B0B6540(ctx, base);
	// li r10,3
	ctx.r10.s64 = 3;
	// stw r10,784(r26)
	REX_STORE_U32(ctx.r26.u32 + 784, ctx.r10.u32);
	// addi r1,r1,464
	ctx.r1.s64 = ctx.r1.s64 + 464;
	// b 0x8b0cba00
	__restgprlr_26(ctx, base);
	return;
loc_8B0BBE04:
	// lis r11,-29943
	ctx.r11.s64 = -1962344448;
	// addi r4,r1,144
	ctx.r4.s64 = ctx.r1.s64 + 144;
	// addi r3,r11,-30876
	ctx.r3.s64 = ctx.r11.s64 + -30876;
	// bl 0x8b0cea10
	ctx.lr = 0x8B0BBE14;
	sub_8B0CEA10(ctx, base);
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// bne cr6,0x8b0bbe40
	if (!ctx.cr6.eq) goto loc_8B0BBE40;
	// lis r11,-29943
	ctx.r11.s64 = -1962344448;
	// addi r3,r11,-30904
	ctx.r3.s64 = ctx.r11.s64 + -30904;
	// bl 0x8b0df2e8
	ctx.lr = 0x8B0BBE28;
	sub_8B0DF2E8(ctx, base);
	// addi r3,r26,296
	ctx.r3.s64 = ctx.r26.s64 + 296;
	// bl 0x8b0b6540
	ctx.lr = 0x8B0BBE30;
	sub_8B0B6540(ctx, base);
	// li r10,3
	ctx.r10.s64 = 3;
	// stw r10,784(r26)
	REX_STORE_U32(ctx.r26.u32 + 784, ctx.r10.u32);
	// addi r1,r1,464
	ctx.r1.s64 = ctx.r1.s64 + 464;
	// b 0x8b0cba00
	__restgprlr_26(ctx, base);
	return;
loc_8B0BBE40:
	// lis r11,-29943
	ctx.r11.s64 = -1962344448;
	// addi r4,r1,144
	ctx.r4.s64 = ctx.r1.s64 + 144;
	// addi r3,r11,-30912
	ctx.r3.s64 = ctx.r11.s64 + -30912;
	// bl 0x8b0cea10
	ctx.lr = 0x8B0BBE50;
	sub_8B0CEA10(ctx, base);
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// bne cr6,0x8b0bbe7c
	if (!ctx.cr6.eq) goto loc_8B0BBE7C;
	// lis r11,-29943
	ctx.r11.s64 = -1962344448;
	// addi r3,r11,-30976
	ctx.r3.s64 = ctx.r11.s64 + -30976;
	// bl 0x8b0df2e8
	ctx.lr = 0x8B0BBE64;
	sub_8B0DF2E8(ctx, base);
	// addi r3,r26,296
	ctx.r3.s64 = ctx.r26.s64 + 296;
	// bl 0x8b0b6540
	ctx.lr = 0x8B0BBE6C;
	sub_8B0B6540(ctx, base);
	// li r10,6
	ctx.r10.s64 = 6;
	// stw r10,784(r26)
	REX_STORE_U32(ctx.r26.u32 + 784, ctx.r10.u32);
	// addi r1,r1,464
	ctx.r1.s64 = ctx.r1.s64 + 464;
	// b 0x8b0cba00
	__restgprlr_26(ctx, base);
	return;
loc_8B0BBE7C:
	// addi r31,r26,528
	ctx.r31.s64 = ctx.r26.s64 + 528;
	// addi r4,r1,144
	ctx.r4.s64 = ctx.r1.s64 + 144;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0cea10
	ctx.lr = 0x8B0BBE8C;
	sub_8B0CEA10(ctx, base);
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// beq cr6,0x8b0bbec0
	if (ctx.cr6.eq) goto loc_8B0BBEC0;
	// lis r11,-29943
	ctx.r11.s64 = -1962344448;
	// mr r5,r31
	ctx.r5.u64 = ctx.r31.u64;
	// addi r3,r11,-31040
	ctx.r3.s64 = ctx.r11.s64 + -31040;
	// addi r4,r1,144
	ctx.r4.s64 = ctx.r1.s64 + 144;
	// bl 0x8b0df2e8
	ctx.lr = 0x8B0BBEA8;
	sub_8B0DF2E8(ctx, base);
	// addi r3,r26,296
	ctx.r3.s64 = ctx.r26.s64 + 296;
	// bl 0x8b0b6540
	ctx.lr = 0x8B0BBEB0;
	sub_8B0B6540(ctx, base);
	// li r10,3
	ctx.r10.s64 = 3;
	// stw r10,784(r26)
	REX_STORE_U32(ctx.r26.u32 + 784, ctx.r10.u32);
	// addi r1,r1,464
	ctx.r1.s64 = ctx.r1.s64 + 464;
	// b 0x8b0cba00
	__restgprlr_26(ctx, base);
	return;
loc_8B0BBEC0:
	// addi r31,r26,744
	ctx.r31.s64 = ctx.r26.s64 + 744;
	// stw r30,756(r26)
	REX_STORE_U32(ctx.r26.u32 + 756, ctx.r30.u32);
loc_8B0BBEC8:
	// lwz r10,116(r1)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r1.u32 + 116);
	// cmpwi cr6,r10,16
	ctx.cr6.compare<int32_t>(ctx.r10.s32, 16, ctx.xer);
	// blt cr6,0x8b0bbf4c
	if (ctx.cr6.lt) goto loc_8B0BBF4C;
	// lwz r11,64(r28)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r28.u32 + 64);
	// addic. r10,r10,-16
	ctx.xer.ca = ctx.r10.u32 > 15;
	ctx.r10.s64 = ctx.r10.s64 + -16;
	ctx.cr0.compare<int32_t>(ctx.r10.s32, 0, ctx.xer);
	// lwz r9,112(r1)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r1.u32 + 112);
	// stw r10,116(r1)
	REX_STORE_U32(ctx.r1.u32 + 116, ctx.r10.u32);
	// and r11,r9,r11
	ctx.r11.u64 = ctx.r9.u64 & ctx.r11.u64;
	// beq 0x8b0bbef8
	if (ctx.cr0.eq) goto loc_8B0BBEF8;
	// rlwinm r10,r9,16,16,31
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r9.u32 | (ctx.r9.u64 << 32), 16) & 0xFFFF;
	// stw r10,112(r1)
	REX_STORE_U32(ctx.r1.u32 + 112, ctx.r10.u32);
	// b 0x8b0bbfe4
	goto loc_8B0BBFE4;
loc_8B0BBEF8:
	// lwz r10,120(r1)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r1.u32 + 120);
	// lwz r9,124(r1)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r1.u32 + 124);
	// stw r27,116(r1)
	REX_STORE_U32(ctx.r1.u32 + 116, ctx.r27.u32);
	// cmplw cr6,r10,r9
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, ctx.r9.u32, ctx.xer);
	// bne cr6,0x8b0bbf20
	if (!ctx.cr6.eq) goto loc_8B0BBF20;
	// addi r10,r10,4
	ctx.r10.s64 = ctx.r10.s64 + 4;
	// stw r29,116(r1)
	REX_STORE_U32(ctx.r1.u32 + 116, ctx.r29.u32);
	// stw r30,112(r1)
	REX_STORE_U32(ctx.r1.u32 + 112, ctx.r30.u32);
	// stw r10,120(r1)
	REX_STORE_U32(ctx.r1.u32 + 120, ctx.r10.u32);
	// b 0x8b0bbfe4
	goto loc_8B0BBFE4;
loc_8B0BBF20:
	// ble cr6,0x8b0bbf30
	if (!ctx.cr6.gt) goto loc_8B0BBF30;
	// stb r29,100(r1)
	REX_STORE_U8(ctx.r1.u32 + 100, ctx.r29.u8);
	// stw r30,112(r1)
	REX_STORE_U32(ctx.r1.u32 + 112, ctx.r30.u32);
	// b 0x8b0bbfe4
	goto loc_8B0BBFE4;
loc_8B0BBF30:
	// lwz r9,0(r10)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r10.u32 + 0);
	// addi r8,r1,136
	ctx.r8.s64 = ctx.r1.s64 + 136;
	// addi r7,r10,4
	ctx.r7.s64 = ctx.r10.s64 + 4;
	// stw r7,120(r1)
	REX_STORE_U32(ctx.r1.u32 + 120, ctx.r7.u32);
	// stwbrx r9,0,r8
	REX_STORE_U32(ctx.r8.u32, __builtin_bswap32(ctx.r9.u32));
	// lwz r6,136(r1)
	ctx.r6.u64 = REX_LOAD_U32(ctx.r1.u32 + 136);
	// b 0x8b0bbfe0
	goto loc_8B0BBFE0;
loc_8B0BBF4C:
	// lwz r11,120(r1)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r1.u32 + 120);
	// subfic r9,r10,16
	ctx.xer.ca = ctx.r10.u32 <= 16;
	ctx.r9.u64 = static_cast<uint64_t>(16) - ctx.r10.u64;
	// lwz r8,124(r1)
	ctx.r8.u64 = REX_LOAD_U32(ctx.r1.u32 + 124);
	// lwz r7,112(r1)
	ctx.r7.u64 = REX_LOAD_U32(ctx.r1.u32 + 112);
	// cmplw cr6,r11,r8
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, ctx.r8.u32, ctx.xer);
	// bne cr6,0x8b0bbf80
	if (!ctx.cr6.eq) goto loc_8B0BBF80;
	// addi r8,r11,4
	ctx.r8.s64 = ctx.r11.s64 + 4;
	// stb r29,100(r1)
	REX_STORE_U8(ctx.r1.u32 + 100, ctx.r29.u8);
	// mr r10,r29
	ctx.r10.u64 = ctx.r29.u64;
	// stw r29,116(r1)
	REX_STORE_U32(ctx.r1.u32 + 116, ctx.r29.u32);
	// mr r11,r30
	ctx.r11.u64 = ctx.r30.u64;
	// stw r8,120(r1)
	REX_STORE_U32(ctx.r1.u32 + 120, ctx.r8.u32);
	// b 0x8b0bbfa8
	goto loc_8B0BBFA8;
loc_8B0BBF80:
	// ble cr6,0x8b0bbf90
	if (!ctx.cr6.gt) goto loc_8B0BBF90;
	// mr r11,r30
	ctx.r11.u64 = ctx.r30.u64;
	// stb r29,100(r1)
	REX_STORE_U8(ctx.r1.u32 + 100, ctx.r29.u8);
	// b 0x8b0bbfa8
	goto loc_8B0BBFA8;
loc_8B0BBF90:
	// lwz r8,0(r11)
	ctx.r8.u64 = REX_LOAD_U32(ctx.r11.u32 + 0);
	// addi r6,r1,132
	ctx.r6.s64 = ctx.r1.s64 + 132;
	// addi r5,r11,4
	ctx.r5.s64 = ctx.r11.s64 + 4;
	// stw r5,120(r1)
	REX_STORE_U32(ctx.r1.u32 + 120, ctx.r5.u32);
	// stwbrx r8,0,r6
	REX_STORE_U32(ctx.r6.u32, __builtin_bswap32(ctx.r8.u32));
	// lwz r11,132(r1)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r1.u32 + 132);
loc_8B0BBFA8:
	// lbz r6,100(r1)
	ctx.r6.u64 = REX_LOAD_U8(ctx.r1.u32 + 100);
	// stw r11,112(r1)
	REX_STORE_U32(ctx.r1.u32 + 112, ctx.r11.u32);
	// cmplwi cr6,r6,0
	ctx.cr6.compare<uint32_t>(ctx.r6.u32, 0, ctx.xer);
	// beq cr6,0x8b0bbfc0
	if (ctx.cr6.eq) goto loc_8B0BBFC0;
	// mr r11,r30
	ctx.r11.u64 = ctx.r30.u64;
	// b 0x8b0bbfe4
	goto loc_8B0BBFE4;
loc_8B0BBFC0:
	// rlwinm r8,r9,2,0,29
	ctx.r8.u64 = __builtin_rotateleft64(ctx.r9.u32 | (ctx.r9.u64 << 32), 2) & 0xFFFFFFFC;
	// srw r6,r11,r9
	ctx.r6.u64 = ctx.r9.u8 & 0x20 ? 0 : (ctx.r11.u32 >> (ctx.r9.u8 & 0x3F));
	// lwzx r5,r8,r28
	ctx.r5.u64 = REX_LOAD_U32(ctx.r8.u32 + ctx.r28.u32);
	// subfic r4,r9,32
	ctx.xer.ca = ctx.r9.u32 <= 32;
	ctx.r4.u64 = static_cast<uint64_t>(32) - ctx.r9.u64;
	// and r3,r5,r11
	ctx.r3.u64 = ctx.r5.u64 & ctx.r11.u64;
	// stw r4,116(r1)
	REX_STORE_U32(ctx.r1.u32 + 116, ctx.r4.u32);
	// slw r11,r3,r10
	ctx.r11.u64 = ctx.r10.u8 & 0x20 ? 0 : (ctx.r3.u32 << (ctx.r10.u8 & 0x3F));
	// or r11,r11,r7
	ctx.r11.u64 = ctx.r11.u64 | ctx.r7.u64;
loc_8B0BBFE0:
	// stw r6,112(r1)
	REX_STORE_U32(ctx.r1.u32 + 112, ctx.r6.u32);
loc_8B0BBFE4:
	// clrlwi r11,r11,16
	ctx.r11.u64 = ctx.r11.u32 & 0xFFFF;
	// sth r11,80(r1)
	REX_STORE_U16(ctx.r1.u32 + 80, ctx.r11.u16);
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// beq cr6,0x8b0bc010
	if (ctx.cr6.eq) goto loc_8B0BC010;
	// cmplwi cr6,r11,65535
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 65535, ctx.xer);
	// beq cr6,0x8b0bc010
	if (ctx.cr6.eq) goto loc_8B0BC010;
	// addi r5,r1,80
	ctx.r5.s64 = ctx.r1.s64 + 80;
	// lwz r4,12(r31)
	ctx.r4.u64 = REX_LOAD_U32(ctx.r31.u32 + 12);
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0bb6d0
	ctx.lr = 0x8B0BC00C;
	sub_8B0BB6D0(ctx, base);
	// b 0x8b0bbec8
	goto loc_8B0BBEC8;
loc_8B0BC010:
	// lis r11,-29943
	ctx.r11.s64 = -1962344448;
	// lwz r4,756(r26)
	ctx.r4.u64 = REX_LOAD_U32(ctx.r26.u32 + 756);
	// addi r3,r11,-31092
	ctx.r3.s64 = ctx.r11.s64 + -31092;
	// bl 0x8b0df2e8
	ctx.lr = 0x8B0BC020;
	sub_8B0DF2E8(ctx, base);
	// mr r3,r26
	ctx.r3.u64 = ctx.r26.u64;
	// bl 0x8b0bb450
	ctx.lr = 0x8B0BC028;
	sub_8B0BB450(ctx, base);
loc_8B0BC028:
	// addi r1,r1,464
	ctx.r1.s64 = ctx.r1.s64 + 464;
	// b 0x8b0cba00
	__restgprlr_26(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0BD8D8) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9b0
	ctx.lr = 0x8B0BD8E0;
	__savegprlr_26(ctx, base);
	// stwu r1,-208(r1)
	ea = -208 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lwz r11,44(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 44);
	// lis r10,-29943
	ctx.r10.s64 = -1962344448;
	// mr r28,r3
	ctx.r28.u64 = ctx.r3.u64;
	// addi r3,r10,-29788
	ctx.r3.s64 = ctx.r10.s64 + -29788;
	// lwz r4,0(r11)
	ctx.r4.u64 = REX_LOAD_U32(ctx.r11.u32 + 0);
	// bl 0x8b0df298
	ctx.lr = 0x8B0BD8FC;
	sub_8B0DF298(ctx, base);
	// lwz r11,44(r28)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r28.u32 + 44);
	// li r26,0
	ctx.r26.s64 = 0;
	// mr r27,r26
	ctx.r27.u64 = ctx.r26.u64;
	// lwz r9,0(r11)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r11.u32 + 0);
	// cmplwi cr6,r9,0
	ctx.cr6.compare<uint32_t>(ctx.r9.u32, 0, ctx.xer);
	// ble cr6,0x8b0bd9c0
	if (!ctx.cr6.gt) goto loc_8B0BD9C0;
	// addi r31,r28,148
	ctx.r31.s64 = ctx.r28.s64 + 148;
	// mr r29,r26
	ctx.r29.u64 = ctx.r26.u64;
loc_8B0BD91C:
	// lwz r11,4(r11)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r11.u32 + 4);
	// addi r3,r1,80
	ctx.r3.s64 = ctx.r1.s64 + 80;
	// li r5,60
	ctx.r5.s64 = 60;
	// add r4,r11,r29
	ctx.r4.u64 = ctx.r11.u64 + ctx.r29.u64;
	// bl 0x8b0cbb30
	ctx.lr = 0x8B0BD930;
	sub_8B0CBB30(ctx, base);
	// lwz r30,12(r31)
	ctx.r30.u64 = REX_LOAD_U32(ctx.r31.u32 + 12);
	// lwz r11,4(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 4);
	// addi r10,r30,1
	ctx.r10.s64 = ctx.r30.s64 + 1;
	// stw r26,140(r1)
	REX_STORE_U32(ctx.r1.u32 + 140, ctx.r26.u32);
	// cmpw cr6,r10,r11
	ctx.cr6.compare<int32_t>(ctx.r10.s32, ctx.r11.s32, ctx.xer);
	// ble cr6,0x8b0bd95c
	if (!ctx.cr6.gt) goto loc_8B0BD95C;
	// rotlwi r10,r30,0
	ctx.r10.u64 = __builtin_rotateleft32(ctx.r30.u32, 0);
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// subf r11,r11,r10
	ctx.r11.u64 = ctx.r10.u64 - ctx.r11.u64;
	// addi r4,r11,1
	ctx.r4.s64 = ctx.r11.s64 + 1;
	// bl 0x8b0bc3b8
	ctx.lr = 0x8B0BD95C;
	sub_8B0BC3B8(ctx, base);
loc_8B0BD95C:
	// lwz r11,12(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 12);
	// addi r11,r11,1
	ctx.r11.s64 = ctx.r11.s64 + 1;
	// subf r10,r30,r11
	ctx.r10.u64 = ctx.r11.u64 - ctx.r30.u64;
	// stw r11,12(r31)
	REX_STORE_U32(ctx.r31.u32 + 12, ctx.r11.u32);
	// addic. r11,r10,-1
	ctx.xer.ca = ctx.r10.u32 > 0;
	ctx.r11.s64 = ctx.r10.s64 + -1;
	ctx.cr0.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// ble 0x8b0bd98c
	if (!ctx.cr0.gt) goto loc_8B0BD98C;
	// lwz r9,0(r31)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r31.u32 + 0);
	// rlwinm r10,r30,6,0,25
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r30.u32 | (ctx.r30.u64 << 32), 6) & 0xFFFFFFC0;
	// rlwinm r5,r11,6,0,25
	ctx.r5.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 6) & 0xFFFFFFC0;
	// add r4,r10,r9
	ctx.r4.u64 = ctx.r10.u64 + ctx.r9.u64;
	// addi r3,r4,64
	ctx.r3.s64 = ctx.r4.s64 + 64;
	// bl 0x8b0cc060
	ctx.lr = 0x8B0BD98C;
	sub_8B0CC060(ctx, base);
loc_8B0BD98C:
	// lwz r10,0(r31)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r31.u32 + 0);
	// rlwinm r11,r30,6,0,25
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r30.u32 | (ctx.r30.u64 << 32), 6) & 0xFFFFFFC0;
	// add. r3,r11,r10
	ctx.r3.u64 = ctx.r11.u64 + ctx.r10.u64;
	ctx.cr0.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// beq 0x8b0bd9a8
	if (ctx.cr0.eq) goto loc_8B0BD9A8;
	// addi r4,r1,80
	ctx.r4.s64 = ctx.r1.s64 + 80;
	// li r5,64
	ctx.r5.s64 = 64;
	// bl 0x8b0cbb30
	ctx.lr = 0x8B0BD9A8;
	sub_8B0CBB30(ctx, base);
loc_8B0BD9A8:
	// lwz r11,44(r28)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r28.u32 + 44);
	// addi r27,r27,1
	ctx.r27.s64 = ctx.r27.s64 + 1;
	// addi r29,r29,92
	ctx.r29.s64 = ctx.r29.s64 + 92;
	// lwz r10,0(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 0);
	// cmplw cr6,r27,r10
	ctx.cr6.compare<uint32_t>(ctx.r27.u32, ctx.r10.u32, ctx.xer);
	// blt cr6,0x8b0bd91c
	if (ctx.cr6.lt) goto loc_8B0BD91C;
loc_8B0BD9C0:
	// lwz r4,160(r28)
	ctx.r4.u64 = REX_LOAD_U32(ctx.r28.u32 + 160);
	// cmpwi cr6,r4,0
	ctx.cr6.compare<int32_t>(ctx.r4.s32, 0, ctx.xer);
	// bne cr6,0x8b0bd9ec
	if (!ctx.cr6.eq) goto loc_8B0BD9EC;
	// lwz r11,0(r28)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r28.u32 + 0);
	// mr r3,r28
	ctx.r3.u64 = ctx.r28.u64;
	// lwz r4,140(r28)
	ctx.r4.u64 = REX_LOAD_U32(ctx.r28.u32 + 140);
	// lwz r10,28(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 28);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B0BD9E4;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// addi r1,r1,208
	ctx.r1.s64 = ctx.r1.s64 + 208;
	// b 0x8b0cba00
	__restgprlr_26(ctx, base);
	return;
loc_8B0BD9EC:
	// lis r11,-29943
	ctx.r11.s64 = -1962344448;
	// addi r3,r11,-29828
	ctx.r3.s64 = ctx.r11.s64 + -29828;
	// bl 0x8b0df298
	ctx.lr = 0x8B0BD9F8;
	sub_8B0DF298(ctx, base);
	// mr r3,r28
	ctx.r3.u64 = ctx.r28.u64;
	// bl 0x8b0bd3b8
	ctx.lr = 0x8B0BDA00;
	sub_8B0BD3B8(ctx, base);
	// addi r1,r1,208
	ctx.r1.s64 = ctx.r1.s64 + 208;
	// b 0x8b0cba00
	__restgprlr_26(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0BDB18) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// stwu r1,-96(r1)
	ea = -96 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// bl 0x8b0cd4e0
	ctx.lr = 0x8B0BDB28;
	sub_8B0CD4E0(ctx, base);
	// frsp f1,f1
	ctx.fpscr.disableFlushMode();
	ctx.f1.f64 = double(float(ctx.f1.f64));
	// addi r1,r1,96
	ctx.r1.s64 = ctx.r1.s64 + 96;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0BDC98) {
	REX_FUNC_PROLOGUE();
	// mr r3,r4
	ctx.r3.u64 = ctx.r4.u64;
	// mr r4,r5
	ctx.r4.u64 = ctx.r5.u64;
	// b 0x8b0bdb40
	sub_8B0BDB40(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0BDCA8) {
	REX_FUNC_PROLOGUE();
	// fsqrts f1,f1
	ctx.fpscr.disableFlushMode();
	ctx.f1.f64 = double(float(sqrt(ctx.f1.f64)));
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0BDCB0) {
	REX_FUNC_PROLOGUE();
	PPCRegister temp{};
	// fsqrts f13,f1
	ctx.fpscr.disableFlushMode();
	ctx.f13.f64 = double(float(sqrt(ctx.f1.f64)));
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lfs f0,32132(r11)
	temp.u32 = REX_LOAD_U32(ctx.r11.u32 + 32132);
	ctx.f0.f64 = double(temp.f32);
	// fdivs f1,f0,f13
	ctx.f1.f64 = double(float(ctx.f0.f64 / ctx.f13.f64));
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0BDD18) {
	REX_FUNC_PROLOGUE();
	PPCRegister temp{};
	// lfs f12,4(r3)
	ctx.fpscr.disableFlushMode();
	temp.u32 = REX_LOAD_U32(ctx.r3.u32 + 4);
	ctx.f12.f64 = double(temp.f32);
	// lis r11,-29943
	ctx.r11.s64 = -1962344448;
	// fmuls f11,f12,f12
	ctx.f11.f64 = double(float(ctx.f12.f64 * ctx.f12.f64));
	// lfs f10,0(r3)
	temp.u32 = REX_LOAD_U32(ctx.r3.u32 + 0);
	ctx.f10.f64 = double(temp.f32);
	// lfs f9,8(r3)
	temp.u32 = REX_LOAD_U32(ctx.r3.u32 + 8);
	ctx.f9.f64 = double(temp.f32);
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// lfs f0,-29644(r11)
	temp.u32 = REX_LOAD_U32(ctx.r11.u32 + -29644);
	ctx.f0.f64 = double(temp.f32);
	// lfs f13,32132(r10)
	temp.u32 = REX_LOAD_U32(ctx.r10.u32 + 32132);
	ctx.f13.f64 = double(temp.f32);
	// fmadds f8,f10,f10,f11
	ctx.f8.f64 = double(float(std::fma(ctx.f10.f64, ctx.f10.f64, ctx.f11.f64)));
	// fmadds f7,f9,f9,f8
	ctx.f7.f64 = double(float(std::fma(ctx.f9.f64, ctx.f9.f64, ctx.f8.f64)));
	// fsqrts f6,f7
	ctx.f6.f64 = double(float(sqrt(ctx.f7.f64)));
	// fadds f5,f6,f0
	ctx.f5.f64 = double(float(ctx.f6.f64 + ctx.f0.f64));
	// fdivs f4,f13,f5
	ctx.f4.f64 = double(float(ctx.f13.f64 / ctx.f5.f64));
	// fmuls f3,f10,f4
	ctx.f3.f64 = double(float(ctx.f10.f64 * ctx.f4.f64));
	// stfs f3,0(r3)
	temp.f32 = float(ctx.f3.f64);
	REX_STORE_U32(ctx.r3.u32 + 0, temp.u32);
	// fmuls f2,f12,f4
	ctx.f2.f64 = double(float(ctx.f12.f64 * ctx.f4.f64));
	// stfs f2,4(r3)
	temp.f32 = float(ctx.f2.f64);
	REX_STORE_U32(ctx.r3.u32 + 4, temp.u32);
	// fmuls f1,f9,f4
	ctx.f1.f64 = double(float(ctx.f9.f64 * ctx.f4.f64));
	// stfs f1,8(r3)
	temp.f32 = float(ctx.f1.f64);
	REX_STORE_U32(ctx.r3.u32 + 8, temp.u32);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0BDE00) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// std r31,-16(r1)
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.r31.u64);
	// stfd f29,-40(r1)
	ctx.fpscr.disableFlushMode();
	REX_STORE_U64(ctx.r1.u32 + -40, ctx.f29.u64);
	// stfd f30,-32(r1)
	REX_STORE_U64(ctx.r1.u32 + -32, ctx.f30.u64);
	// stfd f31,-24(r1)
	REX_STORE_U64(ctx.r1.u32 + -24, ctx.f31.u64);
	// stwu r1,-128(r1)
	ea = -128 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lis r11,-29938
	ctx.r11.s64 = -1962016768;
	// fmr f31,f1
	ctx.f31.f64 = ctx.f1.f64;
	// fmr f30,f2
	ctx.f30.f64 = ctx.f2.f64;
	// mr r31,r6
	ctx.r31.u64 = ctx.r6.u64;
	// fmr f29,f3
	ctx.f29.f64 = ctx.f3.f64;
	// lbz r10,23696(r11)
	ctx.r10.u64 = REX_LOAD_U8(ctx.r11.u32 + 23696);
	// cmplwi cr6,r10,0
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 0, ctx.xer);
	// bne cr6,0x8b0bde68
	if (!ctx.cr6.eq) goto loc_8B0BDE68;
	// li r10,1
	ctx.r10.s64 = 1;
	// stb r10,23696(r11)
	REX_STORE_U8(ctx.r11.u32 + 23696, ctx.r10.u8);
	// bl 0x8b0bdd98
	ctx.lr = 0x8B0BDE48;
	sub_8B0BDD98(ctx, base);
	// mr r6,r31
	ctx.r6.u64 = ctx.r31.u64;
	// fmr f3,f29
	ctx.fpscr.disableFlushMode();
	ctx.f3.f64 = ctx.f29.f64;
	// fmr f2,f30
	ctx.f2.f64 = ctx.f30.f64;
	// fmr f1,f31
	ctx.f1.f64 = ctx.f31.f64;
	// bl 0x8b0be968
	ctx.lr = 0x8B0BDE5C;
	sub_8B0BE968(ctx, base);
	// lis r3,12609
	ctx.r3.s64 = 826343424;
	// ori r3,r3,22822
	ctx.r3.u64 = ctx.r3.u64 | 22822;
	// bl 0x8b0be920
	ctx.lr = 0x8B0BDE68;
	sub_8B0BE920(ctx, base);
loc_8B0BDE68:
	// addi r1,r1,128
	ctx.r1.s64 = ctx.r1.s64 + 128;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// lfd f29,-40(r1)
	ctx.fpscr.disableFlushMode();
	ctx.f29.u64 = REX_LOAD_U64(ctx.r1.u32 + -40);
	// lfd f30,-32(r1)
	ctx.f30.u64 = REX_LOAD_U64(ctx.r1.u32 + -32);
	// lfd f31,-24(r1)
	ctx.f31.u64 = REX_LOAD_U64(ctx.r1.u32 + -24);
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0BE130) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9bc
	ctx.lr = 0x8B0BE138;
	__savegprlr_29(ctx, base);
	// stwu r1,-112(r1)
	ea = -112 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lis r31,-29937
	ctx.r31.s64 = -1961951232;
	// mr r30,r3
	ctx.r30.u64 = ctx.r3.u64;
	// mr r29,r4
	ctx.r29.u64 = ctx.r4.u64;
	// lwz r11,-25408(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + -25408);
	// cmpwi cr6,r11,0
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// bne cr6,0x8b0be160
	if (!ctx.cr6.eq) goto loc_8B0BE160;
	// bl 0x8b0bdf88
	ctx.lr = 0x8B0BE158;
	sub_8B0BDF88(ctx, base);
	// li r11,1
	ctx.r11.s64 = 1;
	// stw r11,-25408(r31)
	REX_STORE_U32(ctx.r31.u32 + -25408, ctx.r11.u32);
loc_8B0BE160:
	// cmpwi cr6,r29,1
	ctx.cr6.compare<int32_t>(ctx.r29.s32, 1, ctx.xer);
	// bge cr6,0x8b0be178
	if (!ctx.cr6.lt) goto loc_8B0BE178;
	// li r10,1
	ctx.r10.s64 = 1;
	// li r11,8
	ctx.r11.s64 = 8;
	// stw r10,0(r30)
	REX_STORE_U32(ctx.r30.u32 + 0, ctx.r10.u32);
	// b 0x8b0be180
	goto loc_8B0BE180;
loc_8B0BE178:
	// rlwinm r11,r29,4,0,27
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r29.u32 | (ctx.r29.u64 << 32), 4) & 0xFFFFFFF0;
	// stw r29,0(r30)
	REX_STORE_U32(ctx.r30.u32 + 0, ctx.r29.u32);
loc_8B0BE180:
	// lis r10,5461
	ctx.r10.s64 = 357892096;
	// stw r11,4(r30)
	REX_STORE_U32(ctx.r30.u32 + 4, ctx.r11.u32);
	// rotlwi r11,r11,0
	ctx.r11.u64 = __builtin_rotateleft32(ctx.r11.u32, 0);
	// ori r9,r10,21845
	ctx.r9.u64 = ctx.r10.u64 | 21845;
	// cmplw cr6,r11,r9
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, ctx.r9.u32, ctx.xer);
	// bgt cr6,0x8b0be1b8
	if (ctx.cr6.gt) goto loc_8B0BE1B8;
	// rlwinm r10,r11,1,0,30
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 1) & 0xFFFFFFFE;
	// add r11,r11,r10
	ctx.r11.u64 = ctx.r11.u64 + ctx.r10.u64;
	// rlwinm r3,r11,2,0,29
	ctx.r3.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 2) & 0xFFFFFFFC;
	// bl 0x8b090000
	ctx.lr = 0x8B0BE1A8;
	sub_8B090000(ctx, base);
	// stw r3,8(r30)
	REX_STORE_U32(ctx.r30.u32 + 8, ctx.r3.u32);
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// addi r1,r1,112
	ctx.r1.s64 = ctx.r1.s64 + 112;
	// b 0x8b0cba0c
	__restgprlr_29(ctx, base);
	return;
loc_8B0BE1B8:
	// li r3,-1
	ctx.r3.s64 = -1;
	// bl 0x8b090000
	ctx.lr = 0x8B0BE1C0;
	sub_8B090000(ctx, base);
	// stw r3,8(r30)
	REX_STORE_U32(ctx.r30.u32 + 8, ctx.r3.u32);
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// addi r1,r1,112
	ctx.r1.s64 = ctx.r1.s64 + 112;
	// b 0x8b0cba0c
	__restgprlr_29(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0BE3E8) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9a4
	ctx.lr = 0x8B0BE3F0;
	__savegprlr_23(ctx, base);
	// lbz r11,0(r4)
	ctx.r11.u64 = REX_LOAD_U8(ctx.r4.u32 + 0);
	// lbz r10,4(r4)
	ctx.r10.u64 = REX_LOAD_U8(ctx.r4.u32 + 4);
	// lbz r9,1(r4)
	ctx.r9.u64 = REX_LOAD_U8(ctx.r4.u32 + 1);
	// rotlwi r8,r11,8
	ctx.r8.u64 = __builtin_rotateleft32(ctx.r11.u32, 8);
	// lbz r7,5(r4)
	ctx.r7.u64 = REX_LOAD_U8(ctx.r4.u32 + 5);
	// rotlwi r6,r10,8
	ctx.r6.u64 = __builtin_rotateleft32(ctx.r10.u32, 8);
	// or r11,r8,r9
	ctx.r11.u64 = ctx.r8.u64 | ctx.r9.u64;
	// lbz r10,2(r4)
	ctx.r10.u64 = REX_LOAD_U8(ctx.r4.u32 + 2);
	// or r9,r6,r7
	ctx.r9.u64 = ctx.r6.u64 | ctx.r7.u64;
	// lbz r8,6(r4)
	ctx.r8.u64 = REX_LOAD_U8(ctx.r4.u32 + 6);
	// rlwinm r7,r11,8,0,23
	ctx.r7.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 8) & 0xFFFFFF00;
	// lwz r6,4(r3)
	ctx.r6.u64 = REX_LOAD_U32(ctx.r3.u32 + 4);
	// rlwinm r11,r9,8,0,23
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r9.u32 | (ctx.r9.u64 << 32), 8) & 0xFFFFFF00;
	// lbz r9,3(r4)
	ctx.r9.u64 = REX_LOAD_U8(ctx.r4.u32 + 3);
	// or r7,r7,r10
	ctx.r7.u64 = ctx.r7.u64 | ctx.r10.u64;
	// lbz r4,7(r4)
	ctx.r4.u64 = REX_LOAD_U8(ctx.r4.u32 + 7);
	// or r11,r11,r8
	ctx.r11.u64 = ctx.r11.u64 | ctx.r8.u64;
	// rlwinm r10,r7,8,0,23
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r7.u32 | (ctx.r7.u64 << 32), 8) & 0xFFFFFF00;
	// rlwinm r8,r11,8,0,23
	ctx.r8.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 8) & 0xFFFFFF00;
	// addic. r11,r6,-1
	ctx.xer.ca = ctx.r6.u32 > 0;
	ctx.r11.s64 = ctx.r6.s64 + -1;
	ctx.cr0.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// or r9,r10,r9
	ctx.r9.u64 = ctx.r10.u64 | ctx.r9.u64;
	// or r8,r8,r4
	ctx.r8.u64 = ctx.r8.u64 | ctx.r4.u64;
	// ble 0x8b0be574
	if (!ctx.cr0.gt) goto loc_8B0BE574;
	// rlwinm r10,r11,1,0,30
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 1) & 0xFFFFFFFE;
	// lwz r7,8(r3)
	ctx.r7.u64 = REX_LOAD_U32(ctx.r3.u32 + 8);
	// addi r6,r11,-1
	ctx.r6.s64 = ctx.r11.s64 + -1;
	// add r4,r11,r10
	ctx.r4.u64 = ctx.r11.u64 + ctx.r10.u64;
	// rlwinm r11,r6,31,1,31
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r6.u32 | (ctx.r6.u64 << 32), 31) & 0x7FFFFFFF;
	// rlwinm r10,r4,2,0,29
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r4.u32 | (ctx.r4.u64 << 32), 2) & 0xFFFFFFFC;
	// addi r6,r11,1
	ctx.r6.s64 = ctx.r11.s64 + 1;
	// add r11,r10,r7
	ctx.r11.u64 = ctx.r10.u64 + ctx.r7.u64;
	// addi r7,r11,24
	ctx.r7.s64 = ctx.r11.s64 + 24;
	// addi r10,r11,16
	ctx.r10.s64 = ctx.r11.s64 + 16;
	// lis r11,-29938
	ctx.r11.s64 = -1962016768;
	// mtctr r6
	ctx.ctr.u64 = ctx.r6.u64;
	// addi r11,r11,23744
	ctx.r11.s64 = ctx.r11.s64 + 23744;
loc_8B0BE480:
	// mr r4,r8
	ctx.r4.u64 = ctx.r8.u64;
	// lwz r3,-8(r10)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r10.u32 + -8);
	// rlwinm r30,r8,16,22,31
	ctx.r30.u64 = __builtin_rotateleft64(ctx.r8.u32 | (ctx.r8.u64 << 32), 16) & 0x3FF;
	// lwzu r6,-24(r7)
	ea = -24 + ctx.r7.u32;
	ctx.r6.u64 = REX_LOAD_U32(ea);
	ctx.r7.u32 = ea;
	// rlwimi r4,r8,2,12,21
	ctx.r4.u64 = (__builtin_rotateleft64(ctx.r8.u32 | (ctx.r8.u64 << 32), 2) & 0xFFC00) | (ctx.r4.u64 & 0xFFFFFFFFFFF003FF);
	// lwz r29,-12(r10)
	ctx.r29.u64 = REX_LOAD_U32(ctx.r10.u32 + -12);
	// rlwinm r31,r8,18,12,21
	ctx.r31.u64 = __builtin_rotateleft64(ctx.r8.u32 | (ctx.r8.u64 << 32), 18) & 0xFFC00;
	// lwz r28,-20(r10)
	ctx.r28.u64 = REX_LOAD_U32(ctx.r10.u32 + -20);
	// clrlwi r27,r4,12
	ctx.r27.u64 = ctx.r4.u32 & 0xFFFFF;
	// or r31,r31,r30
	ctx.r31.u64 = ctx.r31.u64 | ctx.r30.u64;
	// lwz r30,-28(r10)
	ctx.r30.u64 = REX_LOAD_U32(ctx.r10.u32 + -28);
	// addi r26,r11,8192
	ctx.r26.s64 = ctx.r11.s64 + 8192;
	// lwzu r4,-24(r10)
	ea = -24 + ctx.r10.u32;
	ctx.r4.u64 = REX_LOAD_U32(ea);
	ctx.r10.u32 = ea;
	// xor r25,r27,r31
	ctx.r25.u64 = ctx.r27.u64 ^ ctx.r31.u64;
	// addi r24,r11,12288
	ctx.r24.s64 = ctx.r11.s64 + 12288;
	// and r3,r25,r3
	ctx.r3.u64 = ctx.r25.u64 & ctx.r3.u64;
	// addi r25,r11,4096
	ctx.r25.s64 = ctx.r11.s64 + 4096;
	// xor r6,r6,r3
	ctx.r6.u64 = ctx.r6.u64 ^ ctx.r3.u64;
	// xor r27,r3,r27
	ctx.r27.u64 = ctx.r3.u64 ^ ctx.r27.u64;
	// xor r6,r6,r31
	ctx.r6.u64 = ctx.r6.u64 ^ ctx.r31.u64;
	// xor r3,r29,r27
	ctx.r3.u64 = ctx.r29.u64 ^ ctx.r27.u64;
	// rlwinm r29,r6,24,8,29
	ctx.r29.u64 = __builtin_rotateleft64(ctx.r6.u32 | (ctx.r6.u64 << 32), 24) & 0xFFFFFC;
	// rlwinm r31,r3,24,8,29
	ctx.r31.u64 = __builtin_rotateleft64(ctx.r3.u32 | (ctx.r3.u64 << 32), 24) & 0xFFFFFC;
	// rlwinm r3,r3,2,20,29
	ctx.r3.u64 = __builtin_rotateleft64(ctx.r3.u32 | (ctx.r3.u64 << 32), 2) & 0xFFC;
	// rlwinm r6,r6,2,20,29
	ctx.r6.u64 = __builtin_rotateleft64(ctx.r6.u32 | (ctx.r6.u64 << 32), 2) & 0xFFC;
	// addi r27,r11,8192
	ctx.r27.s64 = ctx.r11.s64 + 8192;
	// lwzx r29,r29,r11
	ctx.r29.u64 = REX_LOAD_U32(ctx.r29.u32 + ctx.r11.u32);
	// addi r23,r11,4096
	ctx.r23.s64 = ctx.r11.s64 + 4096;
	// lwzx r31,r31,r26
	ctx.r31.u64 = REX_LOAD_U32(ctx.r31.u32 + ctx.r26.u32);
	// addi r26,r11,12288
	ctx.r26.s64 = ctx.r11.s64 + 12288;
	// lwzx r3,r3,r24
	ctx.r3.u64 = REX_LOAD_U32(ctx.r3.u32 + ctx.r24.u32);
	// or r31,r31,r29
	ctx.r31.u64 = ctx.r31.u64 | ctx.r29.u64;
	// lwzx r6,r6,r25
	ctx.r6.u64 = REX_LOAD_U32(ctx.r6.u32 + ctx.r25.u32);
	// or r3,r31,r3
	ctx.r3.u64 = ctx.r31.u64 | ctx.r3.u64;
	// or r6,r3,r6
	ctx.r6.u64 = ctx.r3.u64 | ctx.r6.u64;
	// xor r9,r6,r9
	ctx.r9.u64 = ctx.r6.u64 ^ ctx.r9.u64;
	// mr r3,r9
	ctx.r3.u64 = ctx.r9.u64;
	// rlwinm r31,r9,16,22,31
	ctx.r31.u64 = __builtin_rotateleft64(ctx.r9.u32 | (ctx.r9.u64 << 32), 16) & 0x3FF;
	// rlwimi r3,r9,2,12,21
	ctx.r3.u64 = (__builtin_rotateleft64(ctx.r9.u32 | (ctx.r9.u64 << 32), 2) & 0xFFC00) | (ctx.r3.u64 & 0xFFFFFFFFFFF003FF);
	// rlwinm r6,r9,18,12,21
	ctx.r6.u64 = __builtin_rotateleft64(ctx.r9.u32 | (ctx.r9.u64 << 32), 18) & 0xFFC00;
	// clrlwi r3,r3,12
	ctx.r3.u64 = ctx.r3.u32 & 0xFFFFF;
	// or r6,r6,r31
	ctx.r6.u64 = ctx.r6.u64 | ctx.r31.u64;
	// xor r31,r3,r6
	ctx.r31.u64 = ctx.r3.u64 ^ ctx.r6.u64;
	// and r31,r31,r28
	ctx.r31.u64 = ctx.r31.u64 & ctx.r28.u64;
	// xor r3,r31,r3
	ctx.r3.u64 = ctx.r31.u64 ^ ctx.r3.u64;
	// xor r31,r30,r31
	ctx.r31.u64 = ctx.r30.u64 ^ ctx.r31.u64;
	// xor r4,r4,r3
	ctx.r4.u64 = ctx.r4.u64 ^ ctx.r3.u64;
	// xor r3,r31,r6
	ctx.r3.u64 = ctx.r31.u64 ^ ctx.r6.u64;
	// rlwinm r6,r4,24,8,29
	ctx.r6.u64 = __builtin_rotateleft64(ctx.r4.u32 | (ctx.r4.u64 << 32), 24) & 0xFFFFFC;
	// rlwinm r31,r3,24,8,29
	ctx.r31.u64 = __builtin_rotateleft64(ctx.r3.u32 | (ctx.r3.u64 << 32), 24) & 0xFFFFFC;
	// rlwinm r4,r4,2,20,29
	ctx.r4.u64 = __builtin_rotateleft64(ctx.r4.u32 | (ctx.r4.u64 << 32), 2) & 0xFFC;
	// rlwinm r3,r3,2,20,29
	ctx.r3.u64 = __builtin_rotateleft64(ctx.r3.u32 | (ctx.r3.u64 << 32), 2) & 0xFFC;
	// lwzx r6,r6,r27
	ctx.r6.u64 = REX_LOAD_U32(ctx.r6.u32 + ctx.r27.u32);
	// lwzx r31,r31,r11
	ctx.r31.u64 = REX_LOAD_U32(ctx.r31.u32 + ctx.r11.u32);
	// lwzx r4,r4,r26
	ctx.r4.u64 = REX_LOAD_U32(ctx.r4.u32 + ctx.r26.u32);
	// or r6,r6,r31
	ctx.r6.u64 = ctx.r6.u64 | ctx.r31.u64;
	// lwzx r3,r3,r23
	ctx.r3.u64 = REX_LOAD_U32(ctx.r3.u32 + ctx.r23.u32);
	// or r6,r6,r4
	ctx.r6.u64 = ctx.r6.u64 | ctx.r4.u64;
	// or r4,r6,r3
	ctx.r4.u64 = ctx.r6.u64 | ctx.r3.u64;
	// xor r8,r4,r8
	ctx.r8.u64 = ctx.r4.u64 ^ ctx.r8.u64;
	// bdnz 0x8b0be480
	--ctx.ctr.u64;
	if (ctx.ctr.u32 != 0) goto loc_8B0BE480;
loc_8B0BE574:
	// rlwinm r11,r8,24,8,31
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r8.u32 | (ctx.r8.u64 << 32), 24) & 0xFFFFFF;
	// stb r8,3(r5)
	REX_STORE_U8(ctx.r5.u32 + 3, ctx.r8.u8);
	// rlwinm r10,r9,24,8,31
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r9.u32 | (ctx.r9.u64 << 32), 24) & 0xFFFFFF;
	// stb r9,7(r5)
	REX_STORE_U8(ctx.r5.u32 + 7, ctx.r9.u8);
	// rlwinm r7,r11,24,8,31
	ctx.r7.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 24) & 0xFFFFFF;
	// stb r11,2(r5)
	REX_STORE_U8(ctx.r5.u32 + 2, ctx.r11.u8);
	// rlwinm r4,r10,24,8,31
	ctx.r4.u64 = __builtin_rotateleft64(ctx.r10.u32 | (ctx.r10.u64 << 32), 24) & 0xFFFFFF;
	// stb r10,6(r5)
	REX_STORE_U8(ctx.r5.u32 + 6, ctx.r10.u8);
	// stb r7,1(r5)
	REX_STORE_U8(ctx.r5.u32 + 1, ctx.r7.u8);
	// rlwinm r8,r7,24,24,31
	ctx.r8.u64 = __builtin_rotateleft64(ctx.r7.u32 | (ctx.r7.u64 << 32), 24) & 0xFF;
	// rlwinm r7,r4,24,24,31
	ctx.r7.u64 = __builtin_rotateleft64(ctx.r4.u32 | (ctx.r4.u64 << 32), 24) & 0xFF;
	// stb r4,5(r5)
	REX_STORE_U8(ctx.r5.u32 + 5, ctx.r4.u8);
	// stb r8,0(r5)
	REX_STORE_U8(ctx.r5.u32 + 0, ctx.r8.u8);
	// stb r7,4(r5)
	REX_STORE_U8(ctx.r5.u32 + 4, ctx.r7.u8);
	// b 0x8b0cb9f4
	__restgprlr_23(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0BEEE8) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// std r31,-16(r1)
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.r31.u64);
	// stwu r1,-96(r1)
	ea = -96 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0bef30
	if (ctx.cr6.eq) goto loc_8B0BEF30;
	// bl 0x8b0df568
	ctx.lr = 0x8B0BEF08;
	sub_8B0DF568(ctx, base);
	// lwz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r4,0(r31)
	ctx.r4.u64 = REX_LOAD_U32(ctx.r31.u32 + 0);
	// lwz r10,16(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 16);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B0BEF1C;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// addi r1,r1,96
	ctx.r1.s64 = ctx.r1.s64 + 96;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
loc_8B0BEF30:
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// addi r3,r11,1791
	ctx.r3.s64 = ctx.r11.s64 + 1791;
	// addi r1,r1,96
	ctx.r1.s64 = ctx.r1.s64 + 96;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0BF1A0) {
	REX_FUNC_PROLOGUE();
	// cmplwi cr6,r4,0
	ctx.cr6.compare<uint32_t>(ctx.r4.u32, 0, ctx.xer);
	// beqlr cr6
	if (ctx.cr6.eq) return;
	// lwz r11,24(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 24);
	// cmplw cr6,r11,r4
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, ctx.r4.u32, ctx.xer);
	// bne cr6,0x8b0bf1c8
	if (!ctx.cr6.eq) goto loc_8B0BF1C8;
	// lwz r11,20(r4)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r4.u32 + 20);
	// stw r11,24(r3)
	REX_STORE_U32(ctx.r3.u32 + 24, ctx.r11.u32);
	// li r11,0
	ctx.r11.s64 = 0;
	// stw r11,20(r4)
	REX_STORE_U32(ctx.r4.u32 + 20, ctx.r11.u32);
	// blr 
	return;
loc_8B0BF1C8:
	// addi r11,r11,20
	ctx.r11.s64 = ctx.r11.s64 + 20;
	// lwz r10,0(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 0);
	// cmplwi cr6,r10,0
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 0, ctx.xer);
	// beq cr6,0x8b0bf208
	if (ctx.cr6.eq) goto loc_8B0BF208;
loc_8B0BF1D8:
	// lwz r10,0(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 0);
	// cmplw cr6,r10,r4
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, ctx.r4.u32, ctx.xer);
	// beq cr6,0x8b0bf200
	if (ctx.cr6.eq) goto loc_8B0BF200;
	// lwz r9,20(r10)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r10.u32 + 20);
	// addi r11,r10,20
	ctx.r11.s64 = ctx.r10.s64 + 20;
	// cmplwi cr6,r9,0
	ctx.cr6.compare<uint32_t>(ctx.r9.u32, 0, ctx.xer);
	// bne cr6,0x8b0bf1d8
	if (!ctx.cr6.eq) goto loc_8B0BF1D8;
	// li r11,0
	ctx.r11.s64 = 0;
	// stw r11,20(r4)
	REX_STORE_U32(ctx.r4.u32 + 20, ctx.r11.u32);
	// blr 
	return;
loc_8B0BF200:
	// lwz r10,20(r4)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r4.u32 + 20);
	// stw r10,0(r11)
	REX_STORE_U32(ctx.r11.u32 + 0, ctx.r10.u32);
loc_8B0BF208:
	// li r11,0
	ctx.r11.s64 = 0;
	// stw r11,20(r4)
	REX_STORE_U32(ctx.r4.u32 + 20, ctx.r11.u32);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0BF2B8) {
	REX_FUNC_PROLOGUE();
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0bf2e8
	if (ctx.cr6.eq) goto loc_8B0BF2E8;
	// lwz r3,24(r3)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r3.u32 + 24);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0bf2e4
	if (ctx.cr6.eq) goto loc_8B0BF2E4;
loc_8B0BF2CC:
	// lbz r11,16(r3)
	ctx.r11.u64 = REX_LOAD_U8(ctx.r3.u32 + 16);
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// bne cr6,0x8b0bf2e4
	if (!ctx.cr6.eq) goto loc_8B0BF2E4;
	// lwz r3,20(r3)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r3.u32 + 20);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// bne cr6,0x8b0bf2cc
	if (!ctx.cr6.eq) goto loc_8B0BF2CC;
loc_8B0BF2E4:
	// blr 
	return;
loc_8B0BF2E8:
	// li r3,0
	ctx.r3.s64 = 0;
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0BF380) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9b8
	ctx.lr = 0x8B0BF388;
	__savegprlr_28(ctx, base);
	// stwu r1,-128(r1)
	ea = -128 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lwz r31,24(r3)
	ctx.r31.u64 = REX_LOAD_U32(ctx.r3.u32 + 24);
	// li r29,0
	ctx.r29.s64 = 0;
	// mr r28,r4
	ctx.r28.u64 = ctx.r4.u64;
	// mr r30,r29
	ctx.r30.u64 = ctx.r29.u64;
	// cmplwi cr6,r31,0
	ctx.cr6.compare<uint32_t>(ctx.r31.u32, 0, ctx.xer);
	// beq cr6,0x8b0bf3d4
	if (ctx.cr6.eq) goto loc_8B0BF3D4;
loc_8B0BF3A4:
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0c0298
	ctx.lr = 0x8B0BF3AC;
	sub_8B0C0298(ctx, base);
	// cmplwi cr6,r30,0
	ctx.cr6.compare<uint32_t>(ctx.r30.u32, 0, ctx.xer);
	// beq cr6,0x8b0bf3bc
	if (ctx.cr6.eq) goto loc_8B0BF3BC;
	// stw r3,20(r30)
	REX_STORE_U32(ctx.r30.u32 + 20, ctx.r3.u32);
	// b 0x8b0bf3c0
	goto loc_8B0BF3C0;
loc_8B0BF3BC:
	// stw r3,24(r28)
	REX_STORE_U32(ctx.r28.u32 + 24, ctx.r3.u32);
loc_8B0BF3C0:
	// stw r29,20(r3)
	REX_STORE_U32(ctx.r3.u32 + 20, ctx.r29.u32);
	// mr r30,r3
	ctx.r30.u64 = ctx.r3.u64;
	// lwz r31,20(r31)
	ctx.r31.u64 = REX_LOAD_U32(ctx.r31.u32 + 20);
	// cmplwi cr6,r31,0
	ctx.cr6.compare<uint32_t>(ctx.r31.u32, 0, ctx.xer);
	// bne cr6,0x8b0bf3a4
	if (!ctx.cr6.eq) goto loc_8B0BF3A4;
loc_8B0BF3D4:
	// addi r1,r1,128
	ctx.r1.s64 = ctx.r1.s64 + 128;
	// b 0x8b0cba08
	__restgprlr_28(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0BF488) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9bc
	ctx.lr = 0x8B0BF490;
	__savegprlr_29(ctx, base);
	// stwu r1,-112(r1)
	ea = -112 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lbz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U8(ctx.r3.u32 + 0);
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// mr r29,r4
	ctx.r29.u64 = ctx.r4.u64;
	// extsb r3,r11
	ctx.r3.s64 = ctx.r11.s8;
	// bl 0x8b0cc470
	ctx.lr = 0x8B0BF4A8;
	sub_8B0CC470(ctx, base);
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// beq cr6,0x8b0bf4c4
	if (ctx.cr6.eq) goto loc_8B0BF4C4;
loc_8B0BF4B0:
	// lbzu r11,1(r31)
	ea = 1 + ctx.r31.u32;
	ctx.r11.u64 = REX_LOAD_U8(ea);
	ctx.r31.u32 = ea;
	// extsb r3,r11
	ctx.r3.s64 = ctx.r11.s8;
	// bl 0x8b0cc470
	ctx.lr = 0x8B0BF4BC;
	sub_8B0CC470(ctx, base);
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// bne cr6,0x8b0bf4b0
	if (!ctx.cr6.eq) goto loc_8B0BF4B0;
loc_8B0BF4C4:
	// lbz r11,0(r31)
	ctx.r11.u64 = REX_LOAD_U8(ctx.r31.u32 + 0);
	// mr r30,r31
	ctx.r30.u64 = ctx.r31.u64;
	// extsb r3,r11
	ctx.r3.s64 = ctx.r11.s8;
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// beq cr6,0x8b0bf4f4
	if (ctx.cr6.eq) goto loc_8B0BF4F4;
loc_8B0BF4D8:
	// bl 0x8b0cc470
	ctx.lr = 0x8B0BF4DC;
	sub_8B0CC470(ctx, base);
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// bne cr6,0x8b0bf4f4
	if (!ctx.cr6.eq) goto loc_8B0BF4F4;
	// lbzu r11,1(r31)
	ea = 1 + ctx.r31.u32;
	ctx.r11.u64 = REX_LOAD_U8(ea);
	ctx.r31.u32 = ea;
	// extsb r3,r11
	ctx.r3.s64 = ctx.r11.s8;
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// bne cr6,0x8b0bf4d8
	if (!ctx.cr6.eq) goto loc_8B0BF4D8;
loc_8B0BF4F4:
	// cmplwi cr6,r29,0
	ctx.cr6.compare<uint32_t>(ctx.r29.u32, 0, ctx.xer);
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// beq cr6,0x8b0bf504
	if (ctx.cr6.eq) goto loc_8B0BF504;
	// stw r31,0(r29)
	REX_STORE_U32(ctx.r29.u32 + 0, ctx.r31.u32);
loc_8B0BF504:
	// addi r1,r1,112
	ctx.r1.s64 = ctx.r1.s64 + 112;
	// b 0x8b0cba0c
	__restgprlr_29(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0BF770) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// std r31,-16(r1)
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.r31.u64);
	// stwu r1,-96(r1)
	ea = -96 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// cmplwi cr6,r4,0
	ctx.cr6.compare<uint32_t>(ctx.r4.u32, 0, ctx.xer);
	// beq cr6,0x8b0bf7f4
	if (ctx.cr6.eq) goto loc_8B0BF7F4;
	// lwz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// mr r4,r5
	ctx.r4.u64 = ctx.r5.u64;
	// lwz r10,12(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 12);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B0BF7A0;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// clrlwi r9,r3,24
	ctx.r9.u64 = ctx.r3.u32 & 0xFF;
	// cmplwi cr6,r9,0
	ctx.cr6.compare<uint32_t>(ctx.r9.u32, 0, ctx.xer);
	// beq cr6,0x8b0bf7d8
	if (ctx.cr6.eq) goto loc_8B0BF7D8;
	// lwz r11,0(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 0);
	// lis r10,-29943
	ctx.r10.s64 = -1962344448;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// addi r4,r10,-28288
	ctx.r4.s64 = ctx.r10.s64 + -28288;
	// lwz r9,16(r11)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r11.u32 + 16);
	// mtctr r9
	ctx.ctr.u64 = ctx.r9.u64;
	// bctrl 
	ctx.lr = 0x8B0BF7C8;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// clrlwi r8,r3,24
	ctx.r8.u64 = ctx.r3.u32 & 0xFF;
	// li r11,1
	ctx.r11.s64 = 1;
	// cmplwi cr6,r8,0
	ctx.cr6.compare<uint32_t>(ctx.r8.u32, 0, ctx.xer);
	// bne cr6,0x8b0bf7dc
	if (!ctx.cr6.eq) goto loc_8B0BF7DC;
loc_8B0BF7D8:
	// li r11,0
	ctx.r11.s64 = 0;
loc_8B0BF7DC:
	// clrlwi r3,r11,24
	ctx.r3.u64 = ctx.r11.u32 & 0xFF;
	// addi r1,r1,96
	ctx.r1.s64 = ctx.r1.s64 + 96;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
loc_8B0BF7F4:
	// li r3,1
	ctx.r3.s64 = 1;
	// addi r1,r1,96
	ctx.r1.s64 = ctx.r1.s64 + 96;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0BF920) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// stwu r1,-96(r1)
	ea = -96 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lwz r3,4(r3)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r3.u32 + 4);
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// ble cr6,0x8b0bf95c
	if (!ctx.cr6.gt) goto loc_8B0BF95C;
	// mr r5,r4
	ctx.r5.u64 = ctx.r4.u64;
	// addi r4,r11,16512
	ctx.r4.s64 = ctx.r11.s64 + 16512;
	// bl 0x8b0df3a8
	ctx.lr = 0x8B0BF948;
	sub_8B0DF3A8(ctx, base);
	// li r3,1
	ctx.r3.s64 = 1;
	// addi r1,r1,96
	ctx.r1.s64 = ctx.r1.s64 + 96;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// blr 
	return;
loc_8B0BF95C:
	// addi r3,r11,16512
	ctx.r3.s64 = ctx.r11.s64 + 16512;
	// bl 0x8b0df3b8
	ctx.lr = 0x8B0BF964;
	sub_8B0DF3B8(ctx, base);
	// li r3,1
	ctx.r3.s64 = 1;
	// addi r1,r1,96
	ctx.r1.s64 = ctx.r1.s64 + 96;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0BFA88) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9ac
	ctx.lr = 0x8B0BFA90;
	__savegprlr_25(ctx, base);
	// stwu r1,-400(r1)
	ea = -400 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// mr r28,r3
	ctx.r28.u64 = ctx.r3.u64;
	// mr r31,r4
	ctx.r31.u64 = ctx.r4.u64;
	// mr r25,r5
	ctx.r25.u64 = ctx.r5.u64;
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// bne cr6,0x8b0bfab4
	if (!ctx.cr6.eq) goto loc_8B0BFAB4;
loc_8B0BFAA8:
	// li r3,0
	ctx.r3.s64 = 0;
	// addi r1,r1,400
	ctx.r1.s64 = ctx.r1.s64 + 400;
	// b 0x8b0cb9fc
	__restgprlr_25(ctx, base);
	return;
loc_8B0BFAB4:
	// cmplwi cr6,r31,0
	ctx.cr6.compare<uint32_t>(ctx.r31.u32, 0, ctx.xer);
	// beq cr6,0x8b0bfbf4
	if (ctx.cr6.eq) goto loc_8B0BFBF4;
	// lbz r11,0(r31)
	ctx.r11.u64 = REX_LOAD_U8(ctx.r31.u32 + 0);
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// beq cr6,0x8b0bfbf4
	if (ctx.cr6.eq) goto loc_8B0BFBF4;
	// li r4,47
	ctx.r4.s64 = 47;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0ccee0
	ctx.lr = 0x8B0BFAD4;
	sub_8B0CCEE0(ctx, base);
	// mr r26,r3
	ctx.r26.u64 = ctx.r3.u64;
	// li r27,0
	ctx.r27.s64 = 0;
	// mr r29,r31
	ctx.r29.u64 = ctx.r31.u64;
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0bfb08
	if (ctx.cr6.eq) goto loc_8B0BFB08;
	// subf r30,r31,r3
	ctx.r30.u64 = ctx.r3.u64 - ctx.r31.u64;
	// mr r4,r31
	ctx.r4.u64 = ctx.r31.u64;
	// mr r5,r30
	ctx.r5.u64 = ctx.r30.u64;
	// addi r3,r1,80
	ctx.r3.s64 = ctx.r1.s64 + 80;
	// bl 0x8b0cbb30
	ctx.lr = 0x8B0BFAFC;
	sub_8B0CBB30(ctx, base);
	// addi r11,r1,80
	ctx.r11.s64 = ctx.r1.s64 + 80;
	// addi r29,r1,80
	ctx.r29.s64 = ctx.r1.s64 + 80;
	// stbx r27,r30,r11
	REX_STORE_U8(ctx.r30.u32 + ctx.r11.u32, ctx.r27.u8);
loc_8B0BFB08:
	// bl 0x8b0df568
	ctx.lr = 0x8B0BFB0C;
	sub_8B0DF568(ctx, base);
	// lwz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// mr r5,r25
	ctx.r5.u64 = ctx.r25.u64;
	// mr r4,r29
	ctx.r4.u64 = ctx.r29.u64;
	// lwz r10,12(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 12);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B0BFB24;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// mr r11,r3
	ctx.r11.u64 = ctx.r3.u64;
	// cmpwi cr6,r3,-1
	ctx.cr6.compare<int32_t>(ctx.r3.s32, -1, ctx.xer);
	// beq cr6,0x8b0bfaa8
	if (ctx.cr6.eq) goto loc_8B0BFAA8;
	// lwz r3,24(r28)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r28.u32 + 24);
	// mr r30,r27
	ctx.r30.u64 = ctx.r27.u64;
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0bfb5c
	if (ctx.cr6.eq) goto loc_8B0BFB5C;
loc_8B0BFB40:
	// lwz r10,0(r3)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// mr r30,r3
	ctx.r30.u64 = ctx.r3.u64;
	// cmpw cr6,r10,r11
	ctx.cr6.compare<int32_t>(ctx.r10.s32, ctx.r11.s32, ctx.xer);
	// beq cr6,0x8b0bfbd8
	if (ctx.cr6.eq) goto loc_8B0BFBD8;
	// lwz r3,20(r3)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r3.u32 + 20);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// bne cr6,0x8b0bfb40
	if (!ctx.cr6.eq) goto loc_8B0BFB40;
loc_8B0BFB5C:
	// lwz r11,28(r28)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r28.u32 + 28);
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// beq cr6,0x8b0bfb78
	if (ctx.cr6.eq) goto loc_8B0BFB78;
	// li r5,0
	ctx.r5.s64 = 0;
	// mr r4,r31
	ctx.r4.u64 = ctx.r31.u64;
	// mr r3,r11
	ctx.r3.u64 = ctx.r11.u64;
	// bl 0x8b0bfa88
	ctx.lr = 0x8B0BFB78;
	sub_8B0BFA88(ctx, base);
loc_8B0BFB78:
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// bne cr6,0x8b0bfbd8
	if (!ctx.cr6.eq) goto loc_8B0BFBD8;
	// clrlwi r11,r25,24
	ctx.r11.u64 = ctx.r25.u32 & 0xFF;
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// beq cr6,0x8b0bfaa8
	if (ctx.cr6.eq) goto loc_8B0BFAA8;
	// bl 0x8b0df568
	ctx.lr = 0x8B0BFB90;
	sub_8B0DF568(ctx, base);
	// lwz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// li r4,36
	ctx.r4.s64 = 36;
	// lwz r10,4(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 4);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B0BFBA4;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0bfbb8
	if (ctx.cr6.eq) goto loc_8B0BFBB8;
	// mr r4,r29
	ctx.r4.u64 = ctx.r29.u64;
	// bl 0x8b0bf9f8
	ctx.lr = 0x8B0BFBB4;
	sub_8B0BF9F8(ctx, base);
	// b 0x8b0bfbbc
	goto loc_8B0BFBBC;
loc_8B0BFBB8:
	// mr r3,r27
	ctx.r3.u64 = ctx.r27.u64;
loc_8B0BFBBC:
	// cmplwi cr6,r30,0
	ctx.cr6.compare<uint32_t>(ctx.r30.u32, 0, ctx.xer);
	// beq cr6,0x8b0bfbcc
	if (ctx.cr6.eq) goto loc_8B0BFBCC;
	// stw r3,20(r30)
	REX_STORE_U32(ctx.r30.u32 + 20, ctx.r3.u32);
	// b 0x8b0bfbd0
	goto loc_8B0BFBD0;
loc_8B0BFBCC:
	// stw r3,24(r28)
	REX_STORE_U32(ctx.r28.u32 + 24, ctx.r3.u32);
loc_8B0BFBD0:
	// stw r27,20(r3)
	REX_STORE_U32(ctx.r3.u32 + 20, ctx.r27.u32);
	// stb r27,16(r28)
	REX_STORE_U8(ctx.r28.u32 + 16, ctx.r27.u8);
loc_8B0BFBD8:
	// cmplwi cr6,r26,0
	ctx.cr6.compare<uint32_t>(ctx.r26.u32, 0, ctx.xer);
	// beq cr6,0x8b0bfbf8
	if (ctx.cr6.eq) goto loc_8B0BFBF8;
	// mr r5,r25
	ctx.r5.u64 = ctx.r25.u64;
	// addi r4,r26,1
	ctx.r4.s64 = ctx.r26.s64 + 1;
	// bl 0x8b0bfa88
	ctx.lr = 0x8B0BFBEC;
	sub_8B0BFA88(ctx, base);
	// addi r1,r1,400
	ctx.r1.s64 = ctx.r1.s64 + 400;
	// b 0x8b0cb9fc
	__restgprlr_25(ctx, base);
	return;
loc_8B0BFBF4:
	// mr r3,r28
	ctx.r3.u64 = ctx.r28.u64;
loc_8B0BFBF8:
	// addi r1,r1,400
	ctx.r1.s64 = ctx.r1.s64 + 400;
	// b 0x8b0cb9fc
	__restgprlr_25(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0C0148) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// std r31,-16(r1)
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.r31.u64);
	// stwu r1,-96(r1)
	ea = -96 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// mr r31,r5
	ctx.r31.u64 = ctx.r5.u64;
	// li r5,1
	ctx.r5.s64 = 1;
	// bl 0x8b0bfa88
	ctx.lr = 0x8B0C0164;
	sub_8B0BFA88(ctx, base);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0c0178
	if (ctx.cr6.eq) goto loc_8B0C0178;
	// li r11,2
	ctx.r11.s64 = 2;
	// stw r31,12(r3)
	REX_STORE_U32(ctx.r3.u32 + 12, ctx.r31.u32);
	// stb r11,16(r3)
	REX_STORE_U8(ctx.r3.u32 + 16, ctx.r11.u8);
loc_8B0C0178:
	// addi r1,r1,96
	ctx.r1.s64 = ctx.r1.s64 + 96;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0C0208) {
	REX_FUNC_PROLOGUE();
	PPCRegister temp{};
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// stfd f31,-16(r1)
	ctx.fpscr.disableFlushMode();
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.f31.u64);
	// stwu r1,-96(r1)
	ea = -96 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// li r5,1
	ctx.r5.s64 = 1;
	// fmr f31,f1
	ctx.f31.f64 = ctx.f1.f64;
	// bl 0x8b0bfa88
	ctx.lr = 0x8B0C0224;
	sub_8B0BFA88(ctx, base);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0c0238
	if (ctx.cr6.eq) goto loc_8B0C0238;
	// li r11,3
	ctx.r11.s64 = 3;
	// stfs f31,12(r3)
	ctx.fpscr.disableFlushMode();
	temp.f32 = float(ctx.f31.f64);
	REX_STORE_U32(ctx.r3.u32 + 12, temp.u32);
	// stb r11,16(r3)
	REX_STORE_U8(ctx.r3.u32 + 16, ctx.r11.u8);
loc_8B0C0238:
	// addi r1,r1,96
	ctx.r1.s64 = ctx.r1.s64 + 96;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// lfd f31,-16(r1)
	ctx.fpscr.disableFlushMode();
	ctx.f31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0C0540) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9b0
	ctx.lr = 0x8B0C0548;
	__savegprlr_26(ctx, base);
	// stwu r1,-144(r1)
	ea = -144 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lwz r28,24(r4)
	ctx.r28.u64 = REX_LOAD_U32(ctx.r4.u32 + 24);
	// mr r27,r3
	ctx.r27.u64 = ctx.r3.u64;
	// cmplwi cr6,r28,0
	ctx.cr6.compare<uint32_t>(ctx.r28.u32, 0, ctx.xer);
	// beq cr6,0x8b0c0660
	if (ctx.cr6.eq) goto loc_8B0C0660;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// addi r26,r11,1791
	ctx.r26.s64 = ctx.r11.s64 + 1791;
loc_8B0C0564:
	// lwz r30,24(r27)
	ctx.r30.u64 = REX_LOAD_U32(ctx.r27.u32 + 24);
	// li r29,0
	ctx.r29.s64 = 0;
	// cmplwi cr6,r30,0
	ctx.cr6.compare<uint32_t>(ctx.r30.u32, 0, ctx.xer);
	// beq cr6,0x8b0c060c
	if (ctx.cr6.eq) goto loc_8B0C060C;
loc_8B0C0574:
	// bl 0x8b0df568
	ctx.lr = 0x8B0C0578;
	sub_8B0DF568(ctx, base);
	// lwz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r4,0(r30)
	ctx.r4.u64 = REX_LOAD_U32(ctx.r30.u32 + 0);
	// lwz r10,16(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 16);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B0C058C;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// cmplwi cr6,r28,0
	ctx.cr6.compare<uint32_t>(ctx.r28.u32, 0, ctx.xer);
	// beq cr6,0x8b0c05b8
	if (ctx.cr6.eq) goto loc_8B0C05B8;
	// bl 0x8b0df568
	ctx.lr = 0x8B0C059C;
	sub_8B0DF568(ctx, base);
	// lwz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r4,0(r28)
	ctx.r4.u64 = REX_LOAD_U32(ctx.r28.u32 + 0);
	// lwz r10,16(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 16);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B0C05B0;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// mr r11,r3
	ctx.r11.u64 = ctx.r3.u64;
	// b 0x8b0c05bc
	goto loc_8B0C05BC;
loc_8B0C05B8:
	// mr r11,r26
	ctx.r11.u64 = ctx.r26.u64;
loc_8B0C05BC:
	// mr r10,r31
	ctx.r10.u64 = ctx.r31.u64;
loc_8B0C05C0:
	// lbz r9,0(r11)
	ctx.r9.u64 = REX_LOAD_U8(ctx.r11.u32 + 0);
	// lbz r8,0(r10)
	ctx.r8.u64 = REX_LOAD_U8(ctx.r10.u32 + 0);
	// cmpwi cr6,r9,0
	ctx.cr6.compare<int32_t>(ctx.r9.s32, 0, ctx.xer);
	// subf r9,r8,r9
	ctx.r9.u64 = ctx.r9.u64 - ctx.r8.u64;
	// beq cr6,0x8b0c05e4
	if (ctx.cr6.eq) goto loc_8B0C05E4;
	// addi r11,r11,1
	ctx.r11.s64 = ctx.r11.s64 + 1;
	// addi r10,r10,1
	ctx.r10.s64 = ctx.r10.s64 + 1;
	// cmpwi cr6,r9,0
	ctx.cr6.compare<int32_t>(ctx.r9.s32, 0, ctx.xer);
	// beq cr6,0x8b0c05c0
	if (ctx.cr6.eq) goto loc_8B0C05C0;
loc_8B0C05E4:
	// cmpwi cr6,r9,0
	ctx.cr6.compare<int32_t>(ctx.r9.s32, 0, ctx.xer);
	// beq cr6,0x8b0c05fc
	if (ctx.cr6.eq) goto loc_8B0C05FC;
	// lwz r30,20(r30)
	ctx.r30.u64 = REX_LOAD_U32(ctx.r30.u32 + 20);
	// cmplwi cr6,r30,0
	ctx.cr6.compare<uint32_t>(ctx.r30.u32, 0, ctx.xer);
	// bne cr6,0x8b0c0574
	if (!ctx.cr6.eq) goto loc_8B0C0574;
	// b 0x8b0c060c
	goto loc_8B0C060C;
loc_8B0C05FC:
	// mr r4,r28
	ctx.r4.u64 = ctx.r28.u64;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// bl 0x8b0c0540
	ctx.lr = 0x8B0C0608;
	sub_8B0C0540(ctx, base);
	// li r29,1
	ctx.r29.s64 = 1;
loc_8B0C060C:
	// clrlwi r11,r29,24
	ctx.r11.u64 = ctx.r29.u32 & 0xFF;
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// bne cr6,0x8b0c0654
	if (!ctx.cr6.eq) goto loc_8B0C0654;
	// mr r3,r28
	ctx.r3.u64 = ctx.r28.u64;
	// bl 0x8b0c0298
	ctx.lr = 0x8B0C0620;
	sub_8B0C0298(ctx, base);
	// lwz r11,24(r27)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r27.u32 + 24);
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// bne cr6,0x8b0c063c
	if (!ctx.cr6.eq) goto loc_8B0C063C;
	// stw r3,24(r27)
	REX_STORE_U32(ctx.r27.u32 + 24, ctx.r3.u32);
	// b 0x8b0c0654
	goto loc_8B0C0654;
loc_8B0C0634:
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// beq cr6,0x8b0c0650
	if (ctx.cr6.eq) goto loc_8B0C0650;
loc_8B0C063C:
	// lwz r10,20(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 20);
	// cmplwi cr6,r10,0
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 0, ctx.xer);
	// beq cr6,0x8b0c0650
	if (ctx.cr6.eq) goto loc_8B0C0650;
	// mr r11,r10
	ctx.r11.u64 = ctx.r10.u64;
	// b 0x8b0c0634
	goto loc_8B0C0634;
loc_8B0C0650:
	// stw r3,20(r11)
	REX_STORE_U32(ctx.r11.u32 + 20, ctx.r3.u32);
loc_8B0C0654:
	// lwz r28,20(r28)
	ctx.r28.u64 = REX_LOAD_U32(ctx.r28.u32 + 20);
	// cmplwi cr6,r28,0
	ctx.cr6.compare<uint32_t>(ctx.r28.u32, 0, ctx.xer);
	// bne cr6,0x8b0c0564
	if (!ctx.cr6.eq) goto loc_8B0C0564;
loc_8B0C0660:
	// addi r1,r1,144
	ctx.r1.s64 = ctx.r1.s64 + 144;
	// b 0x8b0cba00
	__restgprlr_26(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0C0FC0) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// stwu r1,-96(r1)
	ea = -96 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// mr r11,r4
	ctx.r11.u64 = ctx.r4.u64;
	// mr r4,r5
	ctx.r4.u64 = ctx.r5.u64;
	// mr r10,r6
	ctx.r10.u64 = ctx.r6.u64;
	// cmpwi cr6,r6,0
	ctx.cr6.compare<int32_t>(ctx.r6.s32, 0, ctx.xer);
	// ble cr6,0x8b0c1070
	if (!ctx.cr6.gt) goto loc_8B0C1070;
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// beq cr6,0x8b0c1070
	if (ctx.cr6.eq) goto loc_8B0C1070;
	// cmplwi cr6,r5,0
	ctx.cr6.compare<uint32_t>(ctx.r5.u32, 0, ctx.xer);
	// bne cr6,0x8b0c0ff4
	if (!ctx.cr6.eq) goto loc_8B0C0FF4;
	// mr r4,r11
	ctx.r4.u64 = ctx.r11.u64;
loc_8B0C0FF4:
	// lwz r9,0(r3)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// rlwinm r8,r9,0,0,0
	ctx.r8.u64 = __builtin_rotateleft64(ctx.r9.u32 | (ctx.r9.u64 << 32), 0) & 0x80000000;
	// cmplwi cr6,r8,0
	ctx.cr6.compare<uint32_t>(ctx.r8.u32, 0, ctx.xer);
	// beq cr6,0x8b0c1054
	if (ctx.cr6.eq) goto loc_8B0C1054;
	// cmpwi cr6,r10,0
	ctx.cr6.compare<int32_t>(ctx.r10.s32, 0, ctx.xer);
	// ble cr6,0x8b0c1070
	if (!ctx.cr6.gt) goto loc_8B0C1070;
	// subf r9,r11,r4
	ctx.r9.u64 = ctx.r4.u64 - ctx.r11.u64;
	// addi r8,r1,80
	ctx.r8.s64 = ctx.r1.s64 + 80;
loc_8B0C1014:
	// lhz r7,0(r11)
	ctx.r7.u64 = REX_LOAD_U16(ctx.r11.u32 + 0);
	// addi r6,r1,80
	ctx.r6.s64 = ctx.r1.s64 + 80;
	// lhzx r5,r9,r11
	ctx.r5.u64 = REX_LOAD_U16(ctx.r9.u32 + ctx.r11.u32);
	// addic. r10,r10,-1
	ctx.xer.ca = ctx.r10.u32 > 0;
	ctx.r10.s64 = ctx.r10.s64 + -1;
	ctx.cr0.compare<int32_t>(ctx.r10.s32, 0, ctx.xer);
	// sth r7,80(r1)
	REX_STORE_U16(ctx.r1.u32 + 80, ctx.r7.u16);
	// sthbrx r5,0,r8
	REX_STORE_U16(ctx.r8.u32, __builtin_bswap16(ctx.r5.u16));
	// lbz r4,1(r6)
	ctx.r4.u64 = REX_LOAD_U8(ctx.r6.u32 + 1);
	// lbz r3,0(r6)
	ctx.r3.u64 = REX_LOAD_U8(ctx.r6.u32 + 0);
	// stb r3,0(r11)
	REX_STORE_U8(ctx.r11.u32 + 0, ctx.r3.u8);
	// stb r4,1(r11)
	REX_STORE_U8(ctx.r11.u32 + 1, ctx.r4.u8);
	// addi r11,r11,2
	ctx.r11.s64 = ctx.r11.s64 + 2;
	// bne 0x8b0c1014
	if (!ctx.cr0.eq) goto loc_8B0C1014;
	// addi r1,r1,96
	ctx.r1.s64 = ctx.r1.s64 + 96;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// blr 
	return;
loc_8B0C1054:
	// cmplwi cr6,r4,0
	ctx.cr6.compare<uint32_t>(ctx.r4.u32, 0, ctx.xer);
	// beq cr6,0x8b0c1070
	if (ctx.cr6.eq) goto loc_8B0C1070;
	// cmplw cr6,r11,r4
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, ctx.r4.u32, ctx.xer);
	// beq cr6,0x8b0c1070
	if (ctx.cr6.eq) goto loc_8B0C1070;
	// rlwinm r5,r10,1,0,30
	ctx.r5.u64 = __builtin_rotateleft64(ctx.r10.u32 | (ctx.r10.u64 << 32), 1) & 0xFFFFFFFE;
	// mr r3,r11
	ctx.r3.u64 = ctx.r11.u64;
	// bl 0x8b0cbb30
	ctx.lr = 0x8B0C1070;
	sub_8B0CBB30(ctx, base);
loc_8B0C1070:
	// addi r1,r1,96
	ctx.r1.s64 = ctx.r1.s64 + 96;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0C1238) {
	REX_FUNC_PROLOGUE();
	PPCRegister temp{};
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// std r31,-16(r1)
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.r31.u64);
	// stwu r1,-96(r1)
	ea = -96 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// li r4,4
	ctx.r4.s64 = 4;
	// stfs f1,124(r1)
	ctx.fpscr.disableFlushMode();
	temp.f32 = float(ctx.f1.f64);
	REX_STORE_U32(ctx.r1.u32 + 124, temp.u32);
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// bl 0x8b0c7d98
	ctx.lr = 0x8B0C1258;
	sub_8B0C7D98(ctx, base);
	// clrlwi r11,r3,24
	ctx.r11.u64 = ctx.r3.u32 & 0xFF;
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// beq cr6,0x8b0c12e8
	if (ctx.cr6.eq) goto loc_8B0C12E8;
	// lwz r11,44(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 44);
	// addi r3,r31,44
	ctx.r3.s64 = ctx.r31.s64 + 44;
	// rlwinm r10,r11,1,31,31
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 1) & 0x1;
	// cmplwi cr6,r10,0
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 0, ctx.xer);
	// beq cr6,0x8b0c1288
	if (ctx.cr6.eq) goto loc_8B0C1288;
	// li r6,1
	ctx.r6.s64 = 1;
	// addi r5,r1,124
	ctx.r5.s64 = ctx.r1.s64 + 124;
	// addi r4,r1,124
	ctx.r4.s64 = ctx.r1.s64 + 124;
	// bl 0x8b0c0ef0
	ctx.lr = 0x8B0C1288;
	sub_8B0C0EF0(ctx, base);
loc_8B0C1288:
	// lwz r11,32(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 32);
	// lwz r9,16(r31)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r31.u32 + 16);
	// lwz r10,0(r31)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r31.u32 + 0);
	// subf r11,r11,r9
	ctx.r11.u64 = ctx.r9.u64 - ctx.r11.u64;
	// add r11,r11,r10
	ctx.r11.u64 = ctx.r11.u64 + ctx.r10.u64;
	// clrlwi r8,r11,30
	ctx.r8.u64 = ctx.r11.u32 & 0x3;
	// cmplwi cr6,r8,0
	ctx.cr6.compare<uint32_t>(ctx.r8.u32, 0, ctx.xer);
	// beq cr6,0x8b0c12cc
	if (ctx.cr6.eq) goto loc_8B0C12CC;
	// lbz r10,124(r1)
	ctx.r10.u64 = REX_LOAD_U8(ctx.r1.u32 + 124);
	// lbz r9,125(r1)
	ctx.r9.u64 = REX_LOAD_U8(ctx.r1.u32 + 125);
	// lbz r8,126(r1)
	ctx.r8.u64 = REX_LOAD_U8(ctx.r1.u32 + 126);
	// lbz r7,127(r1)
	ctx.r7.u64 = REX_LOAD_U8(ctx.r1.u32 + 127);
	// stb r10,0(r11)
	REX_STORE_U8(ctx.r11.u32 + 0, ctx.r10.u8);
	// stb r9,1(r11)
	REX_STORE_U8(ctx.r11.u32 + 1, ctx.r9.u8);
	// stb r8,2(r11)
	REX_STORE_U8(ctx.r11.u32 + 2, ctx.r8.u8);
	// stb r7,3(r11)
	REX_STORE_U8(ctx.r11.u32 + 3, ctx.r7.u8);
	// b 0x8b0c12d4
	goto loc_8B0C12D4;
loc_8B0C12CC:
	// lfs f0,124(r1)
	ctx.fpscr.disableFlushMode();
	temp.u32 = REX_LOAD_U32(ctx.r1.u32 + 124);
	ctx.f0.f64 = double(temp.f32);
	// stfs f0,0(r11)
	temp.f32 = float(ctx.f0.f64);
	REX_STORE_U32(ctx.r11.u32 + 0, temp.u32);
loc_8B0C12D4:
	// lwz r11,16(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 16);
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// addi r11,r11,4
	ctx.r11.s64 = ctx.r11.s64 + 4;
	// stw r11,16(r31)
	REX_STORE_U32(ctx.r31.u32 + 16, ctx.r11.u32);
	// bl 0x8b0c7e48
	ctx.lr = 0x8B0C12E8;
	sub_8B0C7E48(ctx, base);
loc_8B0C12E8:
	// addi r1,r1,96
	ctx.r1.s64 = ctx.r1.s64 + 96;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0C1588) {
	REX_FUNC_PROLOGUE();
	PPCRegister temp{};
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9b8
	ctx.lr = 0x8B0C1590;
	__savegprlr_28(ctx, base);
	// stwu r1,-704(r1)
	ea = -704 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// mr r28,r5
	ctx.r28.u64 = ctx.r5.u64;
	// li r5,0
	ctx.r5.s64 = 0;
	// mr r30,r3
	ctx.r30.u64 = ctx.r3.u64;
	// mr r29,r4
	ctx.r29.u64 = ctx.r4.u64;
	// bl 0x8b0bfa88
	ctx.lr = 0x8B0C15A8;
	sub_8B0BFA88(ctx, base);
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0c16dc
	if (ctx.cr6.eq) goto loc_8B0C16DC;
	// lbz r11,16(r3)
	ctx.r11.u64 = REX_LOAD_U8(ctx.r3.u32 + 16);
	// addi r11,r11,-1
	ctx.r11.s64 = ctx.r11.s64 + -1;
	// cmplwi cr6,r11,6
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 6, ctx.xer);
	// bgt cr6,0x8b0c16dc
	if (ctx.cr6.gt) goto loc_8B0C16DC;
	// mtctr r11
	ctx.ctr.u64 = ctx.r11.u64;
	// cmpwi cr6,r11,0
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// beq cr6,0x8b0c16d0
	if (ctx.cr6.eq) goto loc_8B0C16D0;
	// bdz 0x8b0c1624
	--ctx.ctr.u64;
	if (ctx.ctr.u32 == 0) goto loc_8B0C1624;
	// bdz 0x8b0c15e8
	--ctx.ctr.u64;
	if (ctx.ctr.u32 == 0) goto loc_8B0C15E8;
	// bdz 0x8b0c1624
	--ctx.ctr.u64;
	if (ctx.ctr.u32 == 0) goto loc_8B0C1624;
	// bdz 0x8b0c1690
	--ctx.ctr.u64;
	if (ctx.ctr.u32 == 0) goto loc_8B0C1690;
	// bdz 0x8b0c16dc
	--ctx.ctr.u64;
	if (ctx.ctr.u32 == 0) goto loc_8B0C16DC;
	// b 0x8b0c1658
	goto loc_8B0C1658;
loc_8B0C15E8:
	// lfs f1,12(r31)
	ctx.fpscr.disableFlushMode();
	temp.u32 = REX_LOAD_U32(ctx.r31.u32 + 12);
	ctx.f1.f64 = double(temp.f32);
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// stfd f1,40(r1)
	REX_STORE_U64(ctx.r1.u32 + 40, ctx.f1.u64);
	// ld r6,40(r1)
	ctx.r6.u64 = REX_LOAD_U64(ctx.r1.u32 + 40);
	// addi r5,r11,16516
	ctx.r5.s64 = ctx.r11.s64 + 16516;
	// li r4,64
	ctx.r4.s64 = 64;
	// addi r3,r1,80
	ctx.r3.s64 = ctx.r1.s64 + 80;
	// bl 0x8b0c3fd8
	ctx.lr = 0x8B0C1608;
	sub_8B0C3FD8(ctx, base);
	// addi r5,r1,80
	ctx.r5.s64 = ctx.r1.s64 + 80;
	// mr r4,r29
	ctx.r4.u64 = ctx.r29.u64;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// bl 0x8b0c0010
	ctx.lr = 0x8B0C1618;
	sub_8B0C0010(ctx, base);
	// lwz r3,4(r31)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r31.u32 + 4);
	// addi r1,r1,704
	ctx.r1.s64 = ctx.r1.s64 + 704;
	// b 0x8b0cba08
	__restgprlr_28(ctx, base);
	return;
loc_8B0C1624:
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lwz r6,12(r31)
	ctx.r6.u64 = REX_LOAD_U32(ctx.r31.u32 + 12);
	// li r4,64
	ctx.r4.s64 = 64;
	// addi r5,r11,1788
	ctx.r5.s64 = ctx.r11.s64 + 1788;
	// addi r3,r1,80
	ctx.r3.s64 = ctx.r1.s64 + 80;
	// bl 0x8b0c3fd8
	ctx.lr = 0x8B0C163C;
	sub_8B0C3FD8(ctx, base);
	// addi r5,r1,80
	ctx.r5.s64 = ctx.r1.s64 + 80;
	// mr r4,r29
	ctx.r4.u64 = ctx.r29.u64;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// bl 0x8b0c0010
	ctx.lr = 0x8B0C164C;
	sub_8B0C0010(ctx, base);
	// lwz r3,4(r31)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r31.u32 + 4);
	// addi r1,r1,704
	ctx.r1.s64 = ctx.r1.s64 + 704;
	// b 0x8b0cba08
	__restgprlr_28(ctx, base);
	return;
loc_8B0C1658:
	// lwz r11,4(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 4);
	// lis r10,-29943
	ctx.r10.s64 = -1962344448;
	// li r4,64
	ctx.r4.s64 = 64;
	// addi r5,r10,-28256
	ctx.r5.s64 = ctx.r10.s64 + -28256;
	// addi r3,r1,80
	ctx.r3.s64 = ctx.r1.s64 + 80;
	// ld r6,0(r11)
	ctx.r6.u64 = REX_LOAD_U64(ctx.r11.u32 + 0);
	// bl 0x8b0c3fd8
	ctx.lr = 0x8B0C1674;
	sub_8B0C3FD8(ctx, base);
	// addi r5,r1,80
	ctx.r5.s64 = ctx.r1.s64 + 80;
	// mr r4,r29
	ctx.r4.u64 = ctx.r29.u64;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// bl 0x8b0c0010
	ctx.lr = 0x8B0C1684;
	sub_8B0C0010(ctx, base);
	// lwz r3,4(r31)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r31.u32 + 4);
	// addi r1,r1,704
	ctx.r1.s64 = ctx.r1.s64 + 704;
	// b 0x8b0cba08
	__restgprlr_28(ctx, base);
	return;
loc_8B0C1690:
	// lis r3,0
	ctx.r3.s64 = 0;
	// lwz r5,8(r31)
	ctx.r5.u64 = REX_LOAD_U32(ctx.r31.u32 + 8);
	// li r10,0
	ctx.r10.s64 = 0;
	// li r9,0
	ctx.r9.s64 = 0;
	// li r8,512
	ctx.r8.s64 = 512;
	// addi r7,r1,144
	ctx.r7.s64 = ctx.r1.s64 + 144;
	// li r6,-1
	ctx.r6.s64 = -1;
	// li r4,0
	ctx.r4.s64 = 0;
	// ori r3,r3,65001
	ctx.r3.u64 = ctx.r3.u64 | 65001;
	// bl 0x8b0dc1a0
	ctx.lr = 0x8B0C16B8;
	sub_8B0DC1A0(ctx, base);
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// beq cr6,0x8b0c16dc
	if (ctx.cr6.eq) goto loc_8B0C16DC;
	// addi r5,r1,144
	ctx.r5.s64 = ctx.r1.s64 + 144;
	// mr r4,r29
	ctx.r4.u64 = ctx.r29.u64;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// bl 0x8b0c0010
	ctx.lr = 0x8B0C16D0;
	sub_8B0C0010(ctx, base);
loc_8B0C16D0:
	// lwz r3,4(r31)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r31.u32 + 4);
	// addi r1,r1,704
	ctx.r1.s64 = ctx.r1.s64 + 704;
	// b 0x8b0cba08
	__restgprlr_28(ctx, base);
	return;
loc_8B0C16DC:
	// mr r3,r28
	ctx.r3.u64 = ctx.r28.u64;
	// addi r1,r1,704
	ctx.r1.s64 = ctx.r1.s64 + 704;
	// b 0x8b0cba08
	__restgprlr_28(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0C20F8) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// std r30,-24(r1)
	REX_STORE_U64(ctx.r1.u32 + -24, ctx.r30.u64);
	// std r31,-16(r1)
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.r31.u64);
	// stwu r1,-112(r1)
	ea = -112 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// mr r30,r4
	ctx.r30.u64 = ctx.r4.u64;
	// li r4,1
	ctx.r4.s64 = 1;
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// bl 0x8b0c7a58
	ctx.lr = 0x8B0C211C;
	sub_8B0C7A58(ctx, base);
	// clrlwi r11,r3,24
	ctx.r11.u64 = ctx.r3.u32 & 0xFF;
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// beq cr6,0x8b0c2150
	if (ctx.cr6.eq) goto loc_8B0C2150;
	// lwz r11,12(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 12);
	// lwz r10,32(r31)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r31.u32 + 32);
	// lwz r9,0(r31)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r31.u32 + 0);
	// subf r8,r10,r11
	ctx.r8.u64 = ctx.r11.u64 - ctx.r10.u64;
	// lbzx r7,r8,r9
	ctx.r7.u64 = REX_LOAD_U8(ctx.r8.u32 + ctx.r9.u32);
	// stb r7,0(r30)
	REX_STORE_U8(ctx.r30.u32 + 0, ctx.r7.u8);
	// lwz r11,12(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 12);
	// addi r6,r11,1
	ctx.r6.s64 = ctx.r11.s64 + 1;
	// stw r6,12(r31)
	REX_STORE_U32(ctx.r31.u32 + 12, ctx.r6.u32);
	// b 0x8b0c2158
	goto loc_8B0C2158;
loc_8B0C2150:
	// li r11,0
	ctx.r11.s64 = 0;
	// stb r11,0(r30)
	REX_STORE_U8(ctx.r30.u32 + 0, ctx.r11.u8);
loc_8B0C2158:
	// addi r1,r1,112
	ctx.r1.s64 = ctx.r1.s64 + 112;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// ld r30,-24(r1)
	ctx.r30.u64 = REX_LOAD_U64(ctx.r1.u32 + -24);
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0C2228) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// std r30,-24(r1)
	REX_STORE_U64(ctx.r1.u32 + -24, ctx.r30.u64);
	// std r31,-16(r1)
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.r31.u64);
	// stwu r1,-112(r1)
	ea = -112 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// mr r30,r4
	ctx.r30.u64 = ctx.r4.u64;
	// li r4,8
	ctx.r4.s64 = 8;
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// bl 0x8b0c7a58
	ctx.lr = 0x8B0C224C;
	sub_8B0C7A58(ctx, base);
	// clrlwi r11,r3,24
	ctx.r11.u64 = ctx.r3.u32 & 0xFF;
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// beq cr6,0x8b0c22c0
	if (ctx.cr6.eq) goto loc_8B0C22C0;
	// lwz r11,44(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 44);
	// addi r3,r31,44
	ctx.r3.s64 = ctx.r31.s64 + 44;
	// rlwinm r10,r11,1,31,31
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 1) & 0x1;
	// lwz r11,32(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 32);
	// cmplwi cr6,r10,0
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 0, ctx.xer);
	// beq cr6,0x8b0c229c
	if (ctx.cr6.eq) goto loc_8B0C229C;
	// lwz r9,12(r31)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r31.u32 + 12);
	// li r6,1
	ctx.r6.s64 = 1;
	// lwz r10,0(r31)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r31.u32 + 0);
	// mr r4,r30
	ctx.r4.u64 = ctx.r30.u64;
	// subf r11,r11,r9
	ctx.r11.u64 = ctx.r9.u64 - ctx.r11.u64;
	// add r5,r11,r10
	ctx.r5.u64 = ctx.r11.u64 + ctx.r10.u64;
	// bl 0x8b0c1080
	ctx.lr = 0x8B0C228C;
	sub_8B0C1080(ctx, base);
	// lwz r11,12(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 12);
	// addi r11,r11,8
	ctx.r11.s64 = ctx.r11.s64 + 8;
	// stw r11,12(r31)
	REX_STORE_U32(ctx.r31.u32 + 12, ctx.r11.u32);
	// b 0x8b0c22c8
	goto loc_8B0C22C8;
loc_8B0C229C:
	// lwz r10,12(r31)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r31.u32 + 12);
	// lwz r9,0(r31)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r31.u32 + 0);
	// subf r8,r11,r10
	ctx.r8.u64 = ctx.r10.u64 - ctx.r11.u64;
	// ldx r7,r8,r9
	ctx.r7.u64 = REX_LOAD_U64(ctx.r8.u32 + ctx.r9.u32);
	// std r7,0(r30)
	REX_STORE_U64(ctx.r30.u32 + 0, ctx.r7.u64);
	// lwz r11,12(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 12);
	// addi r11,r11,8
	ctx.r11.s64 = ctx.r11.s64 + 8;
	// stw r11,12(r31)
	REX_STORE_U32(ctx.r31.u32 + 12, ctx.r11.u32);
	// b 0x8b0c22c8
	goto loc_8B0C22C8;
loc_8B0C22C0:
	// li r11,0
	ctx.r11.s64 = 0;
	// std r11,0(r30)
	REX_STORE_U64(ctx.r30.u32 + 0, ctx.r11.u64);
loc_8B0C22C8:
	// addi r1,r1,112
	ctx.r1.s64 = ctx.r1.s64 + 112;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// ld r30,-24(r1)
	ctx.r30.u64 = REX_LOAD_U64(ctx.r1.u32 + -24);
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0C2398) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// std r30,-24(r1)
	REX_STORE_U64(ctx.r1.u32 + -24, ctx.r30.u64);
	// std r31,-16(r1)
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.r31.u64);
	// stwu r1,-112(r1)
	ea = -112 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// mr r30,r4
	ctx.r30.u64 = ctx.r4.u64;
	// sth r4,142(r1)
	REX_STORE_U16(ctx.r1.u32 + 142, ctx.r4.u16);
	// li r4,2
	ctx.r4.s64 = 2;
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// bl 0x8b0c7d98
	ctx.lr = 0x8B0C23C0;
	sub_8B0C7D98(ctx, base);
	// clrlwi r11,r3,24
	ctx.r11.u64 = ctx.r3.u32 & 0xFF;
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// beq cr6,0x8b0c2428
	if (ctx.cr6.eq) goto loc_8B0C2428;
	// lwz r11,44(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 44);
	// addi r3,r31,44
	ctx.r3.s64 = ctx.r31.s64 + 44;
	// rlwinm r10,r11,1,31,31
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 1) & 0x1;
	// lwz r11,32(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 32);
	// cmplwi cr6,r10,0
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 0, ctx.xer);
	// beq cr6,0x8b0c2404
	if (ctx.cr6.eq) goto loc_8B0C2404;
	// lwz r9,16(r31)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r31.u32 + 16);
	// li r6,1
	ctx.r6.s64 = 1;
	// lwz r10,0(r31)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r31.u32 + 0);
	// addi r5,r1,142
	ctx.r5.s64 = ctx.r1.s64 + 142;
	// subf r11,r11,r9
	ctx.r11.u64 = ctx.r9.u64 - ctx.r11.u64;
	// add r4,r11,r10
	ctx.r4.u64 = ctx.r11.u64 + ctx.r10.u64;
	// bl 0x8b0c0fc0
	ctx.lr = 0x8B0C2400;
	sub_8B0C0FC0(ctx, base);
	// b 0x8b0c2414
	goto loc_8B0C2414;
loc_8B0C2404:
	// lwz r10,16(r31)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r31.u32 + 16);
	// lwz r9,0(r31)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r31.u32 + 0);
	// subf r8,r11,r10
	ctx.r8.u64 = ctx.r10.u64 - ctx.r11.u64;
	// sthx r30,r8,r9
	REX_STORE_U16(ctx.r8.u32 + ctx.r9.u32, ctx.r30.u16);
loc_8B0C2414:
	// lwz r11,16(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 16);
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// addi r11,r11,2
	ctx.r11.s64 = ctx.r11.s64 + 2;
	// stw r11,16(r31)
	REX_STORE_U32(ctx.r31.u32 + 16, ctx.r11.u32);
	// bl 0x8b0c7e48
	ctx.lr = 0x8B0C2428;
	sub_8B0C7E48(ctx, base);
loc_8B0C2428:
	// addi r1,r1,112
	ctx.r1.s64 = ctx.r1.s64 + 112;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// ld r30,-24(r1)
	ctx.r30.u64 = REX_LOAD_U64(ctx.r1.u32 + -24);
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0C24E8) {
	REX_FUNC_PROLOGUE();
	PPCRegister temp{};
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// stwu r1,-96(r1)
	ea = -96 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lbz r11,21(r3)
	ctx.r11.u64 = REX_LOAD_U8(ctx.r3.u32 + 21);
	// clrlwi r10,r11,31
	ctx.r10.u64 = ctx.r11.u32 & 0x1;
	// cmplwi cr6,r10,0
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 0, ctx.xer);
	// bne cr6,0x8b0c2520
	if (!ctx.cr6.eq) goto loc_8B0C2520;
	// addi r4,r1,80
	ctx.r4.s64 = ctx.r1.s64 + 80;
	// bl 0x8b0c1160
	ctx.lr = 0x8B0C250C;
	sub_8B0C1160(ctx, base);
	// lfs f1,80(r1)
	ctx.fpscr.disableFlushMode();
	temp.u32 = REX_LOAD_U32(ctx.r1.u32 + 80);
	ctx.f1.f64 = double(temp.f32);
	// addi r1,r1,96
	ctx.r1.s64 = ctx.r1.s64 + 96;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// blr 
	return;
loc_8B0C2520:
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// addi r5,r1,80
	ctx.r5.s64 = ctx.r1.s64 + 80;
	// addi r4,r10,16516
	ctx.r4.s64 = ctx.r10.s64 + 16516;
	// lfs f0,8492(r11)
	ctx.fpscr.disableFlushMode();
	temp.u32 = REX_LOAD_U32(ctx.r11.u32 + 8492);
	ctx.f0.f64 = double(temp.f32);
	// stfs f0,80(r1)
	temp.f32 = float(ctx.f0.f64);
	REX_STORE_U32(ctx.r1.u32 + 80, temp.u32);
	// bl 0x8b0c95a8
	ctx.lr = 0x8B0C253C;
	sub_8B0C95A8(ctx, base);
	// lfs f1,80(r1)
	ctx.fpscr.disableFlushMode();
	temp.u32 = REX_LOAD_U32(ctx.r1.u32 + 80);
	ctx.f1.f64 = double(temp.f32);
	// addi r1,r1,96
	ctx.r1.s64 = ctx.r1.s64 + 96;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0C25A8) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// stwu r1,-96(r1)
	ea = -96 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lbz r11,21(r3)
	ctx.r11.u64 = REX_LOAD_U8(ctx.r3.u32 + 21);
	// clrlwi r10,r11,31
	ctx.r10.u64 = ctx.r11.u32 & 0x1;
	// cmplwi cr6,r10,0
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 0, ctx.xer);
	// bne cr6,0x8b0c25e0
	if (!ctx.cr6.eq) goto loc_8B0C25E0;
	// addi r4,r1,80
	ctx.r4.s64 = ctx.r1.s64 + 80;
	// bl 0x8b0c20f8
	ctx.lr = 0x8B0C25CC;
	sub_8B0C20F8(ctx, base);
	// lbz r3,80(r1)
	ctx.r3.u64 = REX_LOAD_U8(ctx.r1.u32 + 80);
	// addi r1,r1,96
	ctx.r1.s64 = ctx.r1.s64 + 96;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// blr 
	return;
loc_8B0C25E0:
	// li r11,0
	ctx.r11.s64 = 0;
	// lis r10,-29943
	ctx.r10.s64 = -1962344448;
	// stb r11,80(r1)
	REX_STORE_U8(ctx.r1.u32 + 80, ctx.r11.u8);
	// addi r5,r1,80
	ctx.r5.s64 = ctx.r1.s64 + 80;
	// addi r4,r10,-27852
	ctx.r4.s64 = ctx.r10.s64 + -27852;
	// bl 0x8b0c95a8
	ctx.lr = 0x8B0C25F8;
	sub_8B0C95A8(ctx, base);
	// lbz r3,80(r1)
	ctx.r3.u64 = REX_LOAD_U8(ctx.r1.u32 + 80);
	// addi r1,r1,96
	ctx.r1.s64 = ctx.r1.s64 + 96;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0C26E0) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// stwu r1,-96(r1)
	ea = -96 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lbz r11,21(r3)
	ctx.r11.u64 = REX_LOAD_U8(ctx.r3.u32 + 21);
	// clrlwi r10,r11,31
	ctx.r10.u64 = ctx.r11.u32 & 0x1;
	// cmplwi cr6,r10,0
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 0, ctx.xer);
	// bne cr6,0x8b0c2718
	if (!ctx.cr6.eq) goto loc_8B0C2718;
	// addi r4,r1,80
	ctx.r4.s64 = ctx.r1.s64 + 80;
	// bl 0x8b0c2228
	ctx.lr = 0x8B0C2704;
	sub_8B0C2228(ctx, base);
	// ld r3,80(r1)
	ctx.r3.u64 = REX_LOAD_U64(ctx.r1.u32 + 80);
	// addi r1,r1,96
	ctx.r1.s64 = ctx.r1.s64 + 96;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// blr 
	return;
loc_8B0C2718:
	// li r11,0
	ctx.r11.s64 = 0;
	// lis r10,-29943
	ctx.r10.s64 = -1962344448;
	// std r11,80(r1)
	REX_STORE_U64(ctx.r1.u32 + 80, ctx.r11.u64);
	// addi r5,r1,80
	ctx.r5.s64 = ctx.r1.s64 + 80;
	// addi r4,r10,-27844
	ctx.r4.s64 = ctx.r10.s64 + -27844;
	// bl 0x8b0c95a8
	ctx.lr = 0x8B0C2730;
	sub_8B0C95A8(ctx, base);
	// ld r3,80(r1)
	ctx.r3.u64 = REX_LOAD_U64(ctx.r1.u32 + 80);
	// addi r1,r1,96
	ctx.r1.s64 = ctx.r1.s64 + 96;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0C2CD8) {
	REX_FUNC_PROLOGUE();
	PPCRegister temp{};
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9a4
	ctx.lr = 0x8B0C2CE0;
	__savegprlr_23(ctx, base);
	// stwu r1,-1184(r1)
	ea = -1184 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lbz r11,21(r4)
	ctx.r11.u64 = REX_LOAD_U8(ctx.r4.u32 + 21);
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// mr r28,r4
	ctx.r28.u64 = ctx.r4.u64;
	// clrlwi r10,r11,31
	ctx.r10.u64 = ctx.r11.u32 & 0x1;
	// cmplwi cr6,r10,0
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 0, ctx.xer);
	// beq cr6,0x8b0c2d08
	if (ctx.cr6.eq) goto loc_8B0C2D08;
loc_8B0C2CFC:
	// li r3,0
	ctx.r3.s64 = 0;
	// addi r1,r1,1184
	ctx.r1.s64 = ctx.r1.s64 + 1184;
	// b 0x8b0cb9f4
	__restgprlr_23(ctx, base);
	return;
loc_8B0C2D08:
	// lbz r11,20(r28)
	ctx.r11.u64 = REX_LOAD_U8(ctx.r28.u32 + 20);
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// bne cr6,0x8b0c2cfc
	if (!ctx.cr6.eq) goto loc_8B0C2CFC;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0bee28
	ctx.lr = 0x8B0C2D1C;
	sub_8B0BEE28(ctx, base);
	// li r26,0
	ctx.r26.s64 = 0;
	// li r11,-1
	ctx.r11.s64 = -1;
	// stb r26,16(r31)
	REX_STORE_U8(ctx.r31.u32 + 16, ctx.r26.u8);
	// mr r3,r28
	ctx.r3.u64 = ctx.r28.u64;
	// stw r11,0(r31)
	REX_STORE_U32(ctx.r31.u32 + 0, ctx.r11.u32);
	// stw r26,24(r31)
	REX_STORE_U32(ctx.r31.u32 + 24, ctx.r26.u32);
	// stw r26,20(r31)
	REX_STORE_U32(ctx.r31.u32 + 20, ctx.r26.u32);
	// stw r26,28(r31)
	REX_STORE_U32(ctx.r31.u32 + 28, ctx.r26.u32);
	// stw r26,4(r31)
	REX_STORE_U32(ctx.r31.u32 + 4, ctx.r26.u32);
	// stw r26,8(r31)
	REX_STORE_U32(ctx.r31.u32 + 8, ctx.r26.u32);
	// stw r26,12(r31)
	REX_STORE_U32(ctx.r31.u32 + 12, ctx.r26.u32);
	// stb r26,17(r31)
	REX_STORE_U8(ctx.r31.u32 + 17, ctx.r26.u8);
	// stw r26,32(r31)
	REX_STORE_U32(ctx.r31.u32 + 32, ctx.r26.u32);
	// sth r26,18(r31)
	REX_STORE_U16(ctx.r31.u32 + 18, ctx.r26.u16);
	// bl 0x8b0c2610
	ctx.lr = 0x8B0C2D58;
	sub_8B0C2610(ctx, base);
	// clrlwi r30,r3,24
	ctx.r30.u64 = ctx.r3.u32 & 0xFF;
	// cmpwi cr6,r30,11
	ctx.cr6.compare<int32_t>(ctx.r30.s32, 11, ctx.xer);
	// beq cr6,0x8b0c2fc4
	if (ctx.cr6.eq) goto loc_8B0C2FC4;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lis r10,32767
	ctx.r10.s64 = 2147418112;
	// li r23,-1
	ctx.r23.s64 = -1;
	// ori r24,r10,65535
	ctx.r24.u64 = ctx.r10.u64 | 65535;
	// addi r25,r11,1791
	ctx.r25.s64 = ctx.r11.s64 + 1791;
loc_8B0C2D78:
	// stb r30,16(r31)
	REX_STORE_U8(ctx.r31.u32 + 16, ctx.r30.u8);
	// li r5,1023
	ctx.r5.s64 = 1023;
	// addi r4,r1,80
	ctx.r4.s64 = ctx.r1.s64 + 80;
	// mr r3,r28
	ctx.r3.u64 = ctx.r28.u64;
	// bl 0x8b0c8ca0
	ctx.lr = 0x8B0C2D8C;
	sub_8B0C8CA0(ctx, base);
	// stb r26,1103(r1)
	REX_STORE_U8(ctx.r1.u32 + 1103, ctx.r26.u8);
	// bl 0x8b0df568
	ctx.lr = 0x8B0C2D94;
	sub_8B0DF568(ctx, base);
	// lwz r10,0(r3)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// li r5,1
	ctx.r5.s64 = 1;
	// addi r4,r1,80
	ctx.r4.s64 = ctx.r1.s64 + 80;
	// lwz r9,12(r10)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r10.u32 + 12);
	// mtctr r9
	ctx.ctr.u64 = ctx.r9.u64;
	// bctrl 
	ctx.lr = 0x8B0C2DAC;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// stw r3,0(r31)
	REX_STORE_U32(ctx.r31.u32 + 0, ctx.r3.u32);
	// cmplwi cr6,r30,7
	ctx.cr6.compare<uint32_t>(ctx.r30.u32, 7, ctx.xer);
	// bgt cr6,0x8b0c2f60
	if (ctx.cr6.gt) goto loc_8B0C2F60;
	// mtctr r30
	ctx.ctr.u64 = ctx.r30.u64;
	// cmpwi cr6,r30,0
	ctx.cr6.compare<int32_t>(ctx.r30.s32, 0, ctx.xer);
	// bdzf 4*cr6+eq,0x8b0c2e28
	--ctx.ctr.u64;
	if (ctx.ctr.u32 == 0 && !ctx.cr6.eq) goto loc_8B0C2E28;
	// bdzf 4*cr6+eq,0x8b0c2ee4
	--ctx.ctr.u64;
	if (ctx.ctr.u32 == 0 && !ctx.cr6.eq) goto loc_8B0C2EE4;
	// bdzf 4*cr6+eq,0x8b0c2f10
	--ctx.ctr.u64;
	if (ctx.ctr.u32 == 0 && !ctx.cr6.eq) goto loc_8B0C2F10;
	// bdzf 4*cr6+eq,0x8b0c2f54
	--ctx.ctr.u64;
	if (ctx.ctr.u32 == 0 && !ctx.cr6.eq) goto loc_8B0C2F54;
	// bdzf 4*cr6+eq,0x8b0c2e80
	--ctx.ctr.u64;
	if (ctx.ctr.u32 == 0 && !ctx.cr6.eq) goto loc_8B0C2E80;
	// bdzf 4*cr6+eq,0x8b0c2f20
	--ctx.ctr.u64;
	if (ctx.ctr.u32 == 0 && !ctx.cr6.eq) goto loc_8B0C2F20;
	// bne cr6,0x8b0c2ef0
	if (!ctx.cr6.eq) goto loc_8B0C2EF0;
	// bl 0x8b0df568
	ctx.lr = 0x8B0C2DE0;
	sub_8B0DF568(ctx, base);
	// lwz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// li r4,36
	ctx.r4.s64 = 36;
	// lwz r10,4(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 4);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B0C2DF4;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0c2e14
	if (ctx.cr6.eq) goto loc_8B0C2E14;
	// mr r4,r25
	ctx.r4.u64 = ctx.r25.u64;
	// bl 0x8b0bf9f8
	ctx.lr = 0x8B0C2E04;
	sub_8B0BF9F8(ctx, base);
	// stw r3,24(r31)
	REX_STORE_U32(ctx.r31.u32 + 24, ctx.r3.u32);
	// mr r4,r28
	ctx.r4.u64 = ctx.r28.u64;
	// bl 0x8b0c2cd8
	ctx.lr = 0x8B0C2E10;
	sub_8B0C2CD8(ctx, base);
	// b 0x8b0c2f60
	goto loc_8B0C2F60;
loc_8B0C2E14:
	// stw r26,24(r31)
	REX_STORE_U32(ctx.r31.u32 + 24, ctx.r26.u32);
	// mr r3,r26
	ctx.r3.u64 = ctx.r26.u64;
	// mr r4,r28
	ctx.r4.u64 = ctx.r28.u64;
	// bl 0x8b0c2cd8
	ctx.lr = 0x8B0C2E24;
	sub_8B0C2CD8(ctx, base);
	// b 0x8b0c2f60
	goto loc_8B0C2F60;
loc_8B0C2E28:
	// li r5,1023
	ctx.r5.s64 = 1023;
	// addi r4,r1,80
	ctx.r4.s64 = ctx.r1.s64 + 80;
	// mr r3,r28
	ctx.r3.u64 = ctx.r28.u64;
	// bl 0x8b0c8ca0
	ctx.lr = 0x8B0C2E38;
	sub_8B0C8CA0(ctx, base);
	// addi r11,r1,80
	ctx.r11.s64 = ctx.r1.s64 + 80;
	// stb r26,1103(r1)
	REX_STORE_U8(ctx.r1.u32 + 1103, ctx.r26.u8);
	// mr r10,r11
	ctx.r10.u64 = ctx.r11.u64;
loc_8B0C2E44:
	// lbz r9,0(r11)
	ctx.r9.u64 = REX_LOAD_U8(ctx.r11.u32 + 0);
	// addi r11,r11,1
	ctx.r11.s64 = ctx.r11.s64 + 1;
	// cmplwi cr6,r9,0
	ctx.cr6.compare<uint32_t>(ctx.r9.u32, 0, ctx.xer);
	// bne cr6,0x8b0c2e44
	if (!ctx.cr6.eq) goto loc_8B0C2E44;
	// subf r11,r10,r11
	ctx.r11.u64 = ctx.r11.u64 - ctx.r10.u64;
	// addi r11,r11,-1
	ctx.r11.s64 = ctx.r11.s64 + -1;
	// rotlwi r11,r11,0
	ctx.r11.u64 = __builtin_rotateleft32(ctx.r11.u32, 0);
	// addi r30,r11,1
	ctx.r30.s64 = ctx.r11.s64 + 1;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// bl 0x8b090000
	ctx.lr = 0x8B0C2E6C;
	sub_8B090000(ctx, base);
	// stw r3,4(r31)
	REX_STORE_U32(ctx.r31.u32 + 4, ctx.r3.u32);
	// mr r5,r30
	ctx.r5.u64 = ctx.r30.u64;
	// addi r4,r1,80
	ctx.r4.s64 = ctx.r1.s64 + 80;
	// bl 0x8b0cbb30
	ctx.lr = 0x8B0C2E7C;
	sub_8B0CBB30(ctx, base);
	// b 0x8b0c2f60
	goto loc_8B0C2F60;
loc_8B0C2E80:
	// mr r3,r28
	ctx.r3.u64 = ctx.r28.u64;
	// bl 0x8b0c2678
	ctx.lr = 0x8B0C2E88;
	sub_8B0C2678(ctx, base);
	// extsh r27,r3
	ctx.r27.s64 = ctx.r3.s16;
	// addi r11,r27,1
	ctx.r11.s64 = ctx.r27.s64 + 1;
	// cmplw cr6,r11,r24
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, ctx.r24.u32, ctx.xer);
	// rlwinm r3,r11,1,0,30
	ctx.r3.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 1) & 0xFFFFFFFE;
	// ble cr6,0x8b0c2ea0
	if (!ctx.cr6.gt) goto loc_8B0C2EA0;
	// mr r3,r23
	ctx.r3.u64 = ctx.r23.u64;
loc_8B0C2EA0:
	// bl 0x8b090000
	ctx.lr = 0x8B0C2EA4;
	sub_8B090000(ctx, base);
	// stw r3,8(r31)
	REX_STORE_U32(ctx.r31.u32 + 8, ctx.r3.u32);
	// cmpwi cr6,r27,0
	ctx.cr6.compare<int32_t>(ctx.r27.s32, 0, ctx.xer);
	// ble cr6,0x8b0c2ed4
	if (!ctx.cr6.gt) goto loc_8B0C2ED4;
	// mr r29,r26
	ctx.r29.u64 = ctx.r26.u64;
	// mr r30,r27
	ctx.r30.u64 = ctx.r27.u64;
loc_8B0C2EB8:
	// mr r3,r28
	ctx.r3.u64 = ctx.r28.u64;
	// bl 0x8b0c2678
	ctx.lr = 0x8B0C2EC0;
	sub_8B0C2678(ctx, base);
	// lwz r11,8(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 8);
	// addic. r30,r30,-1
	ctx.xer.ca = ctx.r30.u32 > 0;
	ctx.r30.s64 = ctx.r30.s64 + -1;
	ctx.cr0.compare<int32_t>(ctx.r30.s32, 0, ctx.xer);
	// sthx r3,r29,r11
	REX_STORE_U16(ctx.r29.u32 + ctx.r11.u32, ctx.r3.u16);
	// addi r29,r29,2
	ctx.r29.s64 = ctx.r29.s64 + 2;
	// bne 0x8b0c2eb8
	if (!ctx.cr0.eq) goto loc_8B0C2EB8;
loc_8B0C2ED4:
	// lwz r11,8(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 8);
	// rlwinm r10,r27,1,0,30
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r27.u32 | (ctx.r27.u64 << 32), 1) & 0xFFFFFFFE;
	// sthx r26,r10,r11
	REX_STORE_U16(ctx.r10.u32 + ctx.r11.u32, ctx.r26.u16);
	// b 0x8b0c2f60
	goto loc_8B0C2F60;
loc_8B0C2EE4:
	// mr r3,r28
	ctx.r3.u64 = ctx.r28.u64;
	// bl 0x8b0ac368
	ctx.lr = 0x8B0C2EEC;
	sub_8B0AC368(ctx, base);
	// b 0x8b0c2f5c
	goto loc_8B0C2F5C;
loc_8B0C2EF0:
	// li r3,8
	ctx.r3.s64 = 8;
	// bl 0x8b090000
	ctx.lr = 0x8B0C2EF8;
	sub_8B090000(ctx, base);
	// stw r3,4(r31)
	REX_STORE_U32(ctx.r31.u32 + 4, ctx.r3.u32);
	// mr r3,r28
	ctx.r3.u64 = ctx.r28.u64;
	// bl 0x8b0c26e0
	ctx.lr = 0x8B0C2F04;
	sub_8B0C26E0(ctx, base);
	// lwz r11,4(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 4);
	// std r3,0(r11)
	REX_STORE_U64(ctx.r11.u32 + 0, ctx.r3.u64);
	// b 0x8b0c2f60
	goto loc_8B0C2F60;
loc_8B0C2F10:
	// mr r3,r28
	ctx.r3.u64 = ctx.r28.u64;
	// bl 0x8b0c24e8
	ctx.lr = 0x8B0C2F18;
	sub_8B0C24E8(ctx, base);
	// stfs f1,12(r31)
	ctx.fpscr.disableFlushMode();
	temp.f32 = float(ctx.f1.f64);
	REX_STORE_U32(ctx.r31.u32 + 12, temp.u32);
	// b 0x8b0c2f60
	goto loc_8B0C2F60;
loc_8B0C2F20:
	// mr r3,r28
	ctx.r3.u64 = ctx.r28.u64;
	// bl 0x8b0c2610
	ctx.lr = 0x8B0C2F28;
	sub_8B0C2610(ctx, base);
	// stb r3,12(r31)
	REX_STORE_U8(ctx.r31.u32 + 12, ctx.r3.u8);
	// mr r3,r28
	ctx.r3.u64 = ctx.r28.u64;
	// bl 0x8b0c2610
	ctx.lr = 0x8B0C2F34;
	sub_8B0C2610(ctx, base);
	// stb r3,13(r31)
	REX_STORE_U8(ctx.r31.u32 + 13, ctx.r3.u8);
	// mr r3,r28
	ctx.r3.u64 = ctx.r28.u64;
	// bl 0x8b0c2610
	ctx.lr = 0x8B0C2F40;
	sub_8B0C2610(ctx, base);
	// stb r3,14(r31)
	REX_STORE_U8(ctx.r31.u32 + 14, ctx.r3.u8);
	// mr r3,r28
	ctx.r3.u64 = ctx.r28.u64;
	// bl 0x8b0c2610
	ctx.lr = 0x8B0C2F4C;
	sub_8B0C2610(ctx, base);
	// stb r3,15(r31)
	REX_STORE_U8(ctx.r31.u32 + 15, ctx.r3.u8);
	// b 0x8b0c2f60
	goto loc_8B0C2F60;
loc_8B0C2F54:
	// mr r3,r28
	ctx.r3.u64 = ctx.r28.u64;
	// bl 0x8b0c2748
	ctx.lr = 0x8B0C2F5C;
	sub_8B0C2748(ctx, base);
loc_8B0C2F5C:
	// stw r3,12(r31)
	REX_STORE_U32(ctx.r31.u32 + 12, ctx.r3.u32);
loc_8B0C2F60:
	// lbz r11,20(r28)
	ctx.r11.u64 = REX_LOAD_U8(ctx.r28.u32 + 20);
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// bne cr6,0x8b0c2cfc
	if (!ctx.cr6.eq) goto loc_8B0C2CFC;
	// mr r3,r28
	ctx.r3.u64 = ctx.r28.u64;
	// bl 0x8b0c2610
	ctx.lr = 0x8B0C2F74;
	sub_8B0C2610(ctx, base);
	// clrlwi r30,r3,24
	ctx.r30.u64 = ctx.r3.u32 & 0xFF;
	// cmpwi cr6,r30,11
	ctx.cr6.compare<int32_t>(ctx.r30.s32, 11, ctx.xer);
	// beq cr6,0x8b0c2fc4
	if (ctx.cr6.eq) goto loc_8B0C2FC4;
	// bl 0x8b0df568
	ctx.lr = 0x8B0C2F84;
	sub_8B0DF568(ctx, base);
	// lwz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// li r4,36
	ctx.r4.s64 = 36;
	// lwz r10,4(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 4);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B0C2F98;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0c2fb4
	if (ctx.cr6.eq) goto loc_8B0C2FB4;
	// mr r4,r25
	ctx.r4.u64 = ctx.r25.u64;
	// bl 0x8b0bf9f8
	ctx.lr = 0x8B0C2FA8;
	sub_8B0BF9F8(ctx, base);
	// stw r3,20(r31)
	REX_STORE_U32(ctx.r31.u32 + 20, ctx.r3.u32);
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// b 0x8b0c2d78
	goto loc_8B0C2D78;
loc_8B0C2FB4:
	// stw r26,20(r31)
	REX_STORE_U32(ctx.r31.u32 + 20, ctx.r26.u32);
	// mr r3,r26
	ctx.r3.u64 = ctx.r26.u64;
	// mr r31,r26
	ctx.r31.u64 = ctx.r26.u64;
	// b 0x8b0c2d78
	goto loc_8B0C2D78;
loc_8B0C2FC4:
	// lbz r11,20(r28)
	ctx.r11.u64 = REX_LOAD_U8(ctx.r28.u32 + 20);
	// cntlzw r10,r11
	ctx.r10.u64 = ctx.r11.u32 == 0 ? 32 : __builtin_clz(ctx.r11.u32);
	// rlwinm r3,r10,27,31,31
	ctx.r3.u64 = __builtin_rotateleft64(ctx.r10.u32 | (ctx.r10.u64 << 32), 27) & 0x1;
	// addi r1,r1,1184
	ctx.r1.s64 = ctx.r1.s64 + 1184;
	// b 0x8b0cb9f4
	__restgprlr_23(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0C3C00) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9bc
	ctx.lr = 0x8B0C3C08;
	__savegprlr_29(ctx, base);
	// stwu r1,-112(r1)
	ea = -112 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// mr r30,r4
	ctx.r30.u64 = ctx.r4.u64;
	// lis r4,255
	ctx.r4.s64 = 16711680;
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// ori r4,r4,65535
	ctx.r4.u64 = ctx.r4.u64 | 65535;
	// mr r29,r5
	ctx.r29.u64 = ctx.r5.u64;
	// bl 0x8b0df518
	ctx.lr = 0x8B0C3C24;
	sub_8B0DF518(ctx, base);
	// lis r4,255
	ctx.r4.s64 = 16711680;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// ori r4,r4,65535
	ctx.r4.u64 = ctx.r4.u64 | 65535;
	// bl 0x8b0df518
	ctx.lr = 0x8B0C3C34;
	sub_8B0DF518(ctx, base);
	// mr r5,r29
	ctx.r5.u64 = ctx.r29.u64;
	// mr r4,r30
	ctx.r4.u64 = ctx.r30.u64;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0c3b40
	ctx.lr = 0x8B0C3C44;
	sub_8B0C3B40(ctx, base);
	// addi r1,r1,112
	ctx.r1.s64 = ctx.r1.s64 + 112;
	// b 0x8b0cba0c
	__restgprlr_29(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0C3C50) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9b8
	ctx.lr = 0x8B0C3C58;
	__savegprlr_28(ctx, base);
	// stwu r1,-128(r1)
	ea = -128 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// mr r31,r4
	ctx.r31.u64 = ctx.r4.u64;
	// lis r4,255
	ctx.r4.s64 = 16711680;
	// mr r30,r3
	ctx.r30.u64 = ctx.r3.u64;
	// ori r4,r4,65535
	ctx.r4.u64 = ctx.r4.u64 | 65535;
	// bl 0x8b0df518
	ctx.lr = 0x8B0C3C70;
	sub_8B0DF518(ctx, base);
	// lis r4,255
	ctx.r4.s64 = 16711680;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// ori r4,r4,65535
	ctx.r4.u64 = ctx.r4.u64 | 65535;
	// bl 0x8b0df518
	ctx.lr = 0x8B0C3C80;
	sub_8B0DF518(ctx, base);
loc_8B0C3C80:
	// lbz r11,0(r31)
	ctx.r11.u64 = REX_LOAD_U8(ctx.r31.u32 + 0);
	// extsb r3,r11
	ctx.r3.s64 = ctx.r11.s8;
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// beq cr6,0x8b0c3cc4
	if (ctx.cr6.eq) goto loc_8B0C3CC4;
	// lbz r11,0(r30)
	ctx.r11.u64 = REX_LOAD_U8(ctx.r30.u32 + 0);
	// extsb r29,r11
	ctx.r29.s64 = ctx.r11.s8;
	// bl 0x8b0cc3f8
	ctx.lr = 0x8B0C3C9C;
	sub_8B0CC3F8(ctx, base);
	// mr r28,r3
	ctx.r28.u64 = ctx.r3.u64;
	// mr r3,r29
	ctx.r3.u64 = ctx.r29.u64;
	// bl 0x8b0cc3f8
	ctx.lr = 0x8B0C3CA8;
	sub_8B0CC3F8(ctx, base);
	// cmpw cr6,r3,r28
	ctx.cr6.compare<int32_t>(ctx.r3.s32, ctx.r28.s32, ctx.xer);
	// addi r31,r31,1
	ctx.r31.s64 = ctx.r31.s64 + 1;
	// addi r30,r30,1
	ctx.r30.s64 = ctx.r30.s64 + 1;
	// beq cr6,0x8b0c3c80
	if (ctx.cr6.eq) goto loc_8B0C3C80;
	// li r3,0
	ctx.r3.s64 = 0;
	// addi r1,r1,128
	ctx.r1.s64 = ctx.r1.s64 + 128;
	// b 0x8b0cba08
	__restgprlr_28(ctx, base);
	return;
loc_8B0C3CC4:
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// addi r1,r1,128
	ctx.r1.s64 = ctx.r1.s64 + 128;
	// b 0x8b0cba08
	__restgprlr_28(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0C3EE0) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// lbz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U8(ctx.r3.u32 + 0);
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// beqlr cr6
	if (ctx.cr6.eq) return;
loc_8B0C3EEC:
	// lbz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U8(ctx.r3.u32 + 0);
	// extsb r11,r11
	ctx.r11.s64 = ctx.r11.s8;
	// cmpwi cr6,r11,47
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 47, ctx.xer);
	// beq cr6,0x8b0c3f04
	if (ctx.cr6.eq) goto loc_8B0C3F04;
	// cmpwi cr6,r11,92
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 92, ctx.xer);
	// bne cr6,0x8b0c3f08
	if (!ctx.cr6.eq) goto loc_8B0C3F08;
loc_8B0C3F04:
	// stb r4,0(r3)
	REX_STORE_U8(ctx.r3.u32 + 0, ctx.r4.u8);
loc_8B0C3F08:
	// lbzu r11,1(r3)
	ea = 1 + ctx.r3.u32;
	ctx.r11.u64 = REX_LOAD_U8(ea);
	ctx.r3.u32 = ea;
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// bne cr6,0x8b0c3eec
	if (!ctx.cr6.eq) goto loc_8B0C3EEC;
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0C3F78) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9bc
	ctx.lr = 0x8B0C3F80;
	__savegprlr_29(ctx, base);
	// stwu r1,-112(r1)
	ea = -112 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// mr r29,r4
	ctx.r29.u64 = ctx.r4.u64;
	// mr r4,r5
	ctx.r4.u64 = ctx.r5.u64;
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// mr r30,r5
	ctx.r30.u64 = ctx.r5.u64;
	// bl 0x8b0df528
	ctx.lr = 0x8B0C3F98;
	sub_8B0DF528(ctx, base);
	// mr r3,r29
	ctx.r3.u64 = ctx.r29.u64;
	// li r4,1
	ctx.r4.s64 = 1;
	// bl 0x8b0df538
	ctx.lr = 0x8B0C3FA4;
	sub_8B0DF538(ctx, base);
	// rlwinm r30,r30,31,1,31
	ctx.r30.u64 = __builtin_rotateleft64(ctx.r30.u32 | (ctx.r30.u64 << 32), 31) & 0x7FFFFFFF;
	// mr r4,r29
	ctx.r4.u64 = ctx.r29.u64;
	// mr r5,r30
	ctx.r5.u64 = ctx.r30.u64;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0ce858
	ctx.lr = 0x8B0C3FB8;
	sub_8B0CE858(ctx, base);
	// cmpwi cr6,r30,0
	ctx.cr6.compare<int32_t>(ctx.r30.s32, 0, ctx.xer);
	// beq cr6,0x8b0c3fd0
	if (ctx.cr6.eq) goto loc_8B0C3FD0;
	// rlwinm r11,r30,1,0,30
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r30.u32 | (ctx.r30.u64 << 32), 1) & 0xFFFFFFFE;
	// li r10,0
	ctx.r10.s64 = 0;
	// add r9,r11,r31
	ctx.r9.u64 = ctx.r11.u64 + ctx.r31.u64;
	// sth r10,-2(r9)
	REX_STORE_U16(ctx.r9.u32 + -2, ctx.r10.u16);
loc_8B0C3FD0:
	// addi r1,r1,112
	ctx.r1.s64 = ctx.r1.s64 + 112;
	// b 0x8b0cba0c
	__restgprlr_29(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0C4210) {
	REX_FUNC_PROLOGUE();
	PPCRegister temp{};
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// std r30,-24(r1)
	REX_STORE_U64(ctx.r1.u32 + -24, ctx.r30.u64);
	// std r31,-16(r1)
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.r31.u64);
	// stwu r1,-112(r1)
	ea = -112 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// mr r11,r4
	ctx.r11.u64 = ctx.r4.u64;
	// lwz r4,8(r3)
	ctx.r4.u64 = REX_LOAD_U32(ctx.r3.u32 + 8);
	// mr r30,r3
	ctx.r30.u64 = ctx.r3.u64;
	// cmpwi cr6,r4,0
	ctx.cr6.compare<int32_t>(ctx.r4.s32, 0, ctx.xer);
	// blt cr6,0x8b0c42f0
	if (ctx.cr6.lt) goto loc_8B0C42F0;
	// lwz r3,4(r3)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r3.u32 + 4);
	// li r6,12
	ctx.r6.s64 = 12;
	// add r31,r3,r11
	ctx.r31.u64 = ctx.r3.u64 + ctx.r11.u64;
	// mr r5,r31
	ctx.r5.u64 = ctx.r31.u64;
	// bl 0x8b090160
	ctx.lr = 0x8B0C424C;
	sub_8B090160(ctx, base);
	// clrlwi r11,r3,16
	ctx.r11.u64 = ctx.r3.u32 & 0xFFFF;
	// cmpw cr6,r11,r31
	ctx.cr6.compare<int32_t>(ctx.r11.s32, ctx.r31.s32, ctx.xer);
	// bge cr6,0x8b0c42a0
	if (!ctx.cr6.lt) goto loc_8B0C42A0;
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// bne cr6,0x8b0c427c
	if (!ctx.cr6.eq) goto loc_8B0C427C;
	// addis r11,r3,1
	ctx.r11.s64 = ctx.r3.s64 + 65536;
	// addi r11,r11,-1
	ctx.r11.s64 = ctx.r11.s64 + -1;
	// clrlwi r10,r11,16
	ctx.r10.u64 = ctx.r11.u32 & 0xFFFF;
	// cmpw cr6,r10,r31
	ctx.cr6.compare<int32_t>(ctx.r10.s32, ctx.r31.s32, ctx.xer);
	// blt cr6,0x8b0c427c
	if (ctx.cr6.lt) goto loc_8B0C427C;
	// addi r3,r3,-1
	ctx.r3.s64 = ctx.r3.s64 + -1;
	// b 0x8b0c42a0
	goto loc_8B0C42A0;
loc_8B0C427C:
	// clrlwi r11,r31,16
	ctx.r11.u64 = ctx.r31.u32 & 0xFFFF;
	// cmpw cr6,r11,r31
	ctx.cr6.compare<int32_t>(ctx.r11.s32, ctx.r31.s32, ctx.xer);
	// bne cr6,0x8b0c42f0
	if (!ctx.cr6.eq) goto loc_8B0C42F0;
loc_8B0C4288:
	// add r11,r3,r31
	ctx.r11.u64 = ctx.r3.u64 + ctx.r31.u64;
	// srawi r10,r11,1
	ctx.xer.ca = (ctx.r11.s32 < 0) & ((ctx.r11.u32 & 0x1) != 0);
	ctx.r10.s64 = ctx.r11.s32 >> 1;
	// addze r3,r10
	temp.s64 = ctx.r10.s64 + ctx.xer.ca;
	ctx.xer.ca = temp.u32 < ctx.r10.u32;
	ctx.r3.s64 = temp.s64;
	// clrlwi r9,r3,16
	ctx.r9.u64 = ctx.r3.u32 & 0xFFFF;
	// cmpw cr6,r9,r31
	ctx.cr6.compare<int32_t>(ctx.r9.s32, ctx.r31.s32, ctx.xer);
	// blt cr6,0x8b0c4288
	if (ctx.cr6.lt) goto loc_8B0C4288;
loc_8B0C42A0:
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// stw r3,4(r30)
	REX_STORE_U32(ctx.r30.u32 + 4, ctx.r3.u32);
	// rlwinm r11,r3,1,0,30
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r3.u32 | (ctx.r3.u64 << 32), 1) & 0xFFFFFFFE;
	// lwz r4,0(r30)
	ctx.r4.u64 = REX_LOAD_U32(ctx.r30.u32 + 0);
	// add r9,r3,r11
	ctx.r9.u64 = ctx.r3.u64 + ctx.r11.u64;
	// cmplwi cr6,r4,0
	ctx.cr6.compare<uint32_t>(ctx.r4.u32, 0, ctx.xer);
	// lwz r11,1144(r10)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r10.u32 + 1144);
	// lwz r3,0(r11)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r11.u32 + 0);
	// lwz r8,0(r3)
	ctx.r8.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// beq cr6,0x8b0c42dc
	if (ctx.cr6.eq) goto loc_8B0C42DC;
	// lwz r7,12(r8)
	ctx.r7.u64 = REX_LOAD_U32(ctx.r8.u32 + 12);
	// rlwinm r5,r9,2,0,29
	ctx.r5.u64 = __builtin_rotateleft64(ctx.r9.u32 | (ctx.r9.u64 << 32), 2) & 0xFFFFFFFC;
	// mtctr r7
	ctx.ctr.u64 = ctx.r7.u64;
	// bctrl 
	ctx.lr = 0x8B0C42D8;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// b 0x8b0c42ec
	goto loc_8B0C42EC;
loc_8B0C42DC:
	// lwz r7,4(r8)
	ctx.r7.u64 = REX_LOAD_U32(ctx.r8.u32 + 4);
	// rlwinm r4,r9,2,0,29
	ctx.r4.u64 = __builtin_rotateleft64(ctx.r9.u32 | (ctx.r9.u64 << 32), 2) & 0xFFFFFFFC;
	// mtctr r7
	ctx.ctr.u64 = ctx.r7.u64;
	// bctrl 
	ctx.lr = 0x8B0C42EC;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
loc_8B0C42EC:
	// stw r3,0(r30)
	REX_STORE_U32(ctx.r30.u32 + 0, ctx.r3.u32);
loc_8B0C42F0:
	// addi r1,r1,112
	ctx.r1.s64 = ctx.r1.s64 + 112;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// ld r30,-24(r1)
	ctx.r30.u64 = REX_LOAD_U64(ctx.r1.u32 + -24);
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0C4660) {
	REX_FUNC_PROLOGUE();
	PPCRegister temp{};
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// stwu r1,-96(r1)
	ea = -96 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lhz r11,0(r4)
	ctx.r11.u64 = REX_LOAD_U16(ctx.r4.u32 + 0);
	// mr r9,r3
	ctx.r9.u64 = ctx.r3.u64;
	// cmplwi cr6,r11,65535
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 65535, ctx.xer);
	// bne cr6,0x8b0c468c
	if (!ctx.cr6.eq) goto loc_8B0C468C;
	// lhz r10,2(r4)
	ctx.r10.u64 = REX_LOAD_U16(ctx.r4.u32 + 2);
	// cmplwi cr6,r10,65535
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 65535, ctx.xer);
	// li r10,1
	ctx.r10.s64 = 1;
	// beq cr6,0x8b0c4690
	if (ctx.cr6.eq) goto loc_8B0C4690;
loc_8B0C468C:
	// li r10,0
	ctx.r10.s64 = 0;
loc_8B0C4690:
	// clrlwi r10,r10,24
	ctx.r10.u64 = ctx.r10.u32 & 0xFF;
	// cmplwi cr6,r10,0
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 0, ctx.xer);
	// beq cr6,0x8b0c46a8
	if (ctx.cr6.eq) goto loc_8B0C46A8;
	// lwz r3,32(r9)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r9.u32 + 32);
	// lhz r10,30(r9)
	ctx.r10.u64 = REX_LOAD_U16(ctx.r9.u32 + 30);
	// b 0x8b0c46c8
	goto loc_8B0C46C8;
loc_8B0C46A8:
	// lwz r10,36(r9)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r9.u32 + 36);
	// rlwinm r8,r11,2,0,29
	ctx.r8.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 2) & 0xFFFFFFFC;
	// lhz r11,2(r4)
	ctx.r11.u64 = REX_LOAD_U16(ctx.r4.u32 + 2);
	// lwzx r10,r8,r10
	ctx.r10.u64 = REX_LOAD_U32(ctx.r8.u32 + ctx.r10.u32);
	// add r11,r10,r11
	ctx.r11.u64 = ctx.r10.u64 + ctx.r11.u64;
	// addi r11,r11,8
	ctx.r11.s64 = ctx.r11.s64 + 8;
	// addi r3,r11,2
	ctx.r3.s64 = ctx.r11.s64 + 2;
	// lhz r10,0(r11)
	ctx.r10.u64 = REX_LOAD_U16(ctx.r11.u32 + 0);
loc_8B0C46C8:
	// lhz r11,0(r5)
	ctx.r11.u64 = REX_LOAD_U16(ctx.r5.u32 + 0);
	// cmplwi cr6,r11,65535
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 65535, ctx.xer);
	// bne cr6,0x8b0c46e4
	if (!ctx.cr6.eq) goto loc_8B0C46E4;
	// lhz r8,2(r5)
	ctx.r8.u64 = REX_LOAD_U16(ctx.r5.u32 + 2);
	// cmplwi cr6,r8,65535
	ctx.cr6.compare<uint32_t>(ctx.r8.u32, 65535, ctx.xer);
	// li r8,1
	ctx.r8.s64 = 1;
	// beq cr6,0x8b0c46e8
	if (ctx.cr6.eq) goto loc_8B0C46E8;
loc_8B0C46E4:
	// li r8,0
	ctx.r8.s64 = 0;
loc_8B0C46E8:
	// clrlwi r8,r8,24
	ctx.r8.u64 = ctx.r8.u32 & 0xFF;
	// cmplwi cr6,r8,0
	ctx.cr6.compare<uint32_t>(ctx.r8.u32, 0, ctx.xer);
	// beq cr6,0x8b0c4700
	if (ctx.cr6.eq) goto loc_8B0C4700;
	// lwz r4,32(r9)
	ctx.r4.u64 = REX_LOAD_U32(ctx.r9.u32 + 32);
	// lhz r8,30(r9)
	ctx.r8.u64 = REX_LOAD_U16(ctx.r9.u32 + 30);
	// b 0x8b0c4720
	goto loc_8B0C4720;
loc_8B0C4700:
	// lwz r7,36(r9)
	ctx.r7.u64 = REX_LOAD_U32(ctx.r9.u32 + 36);
	// rlwinm r6,r11,2,0,29
	ctx.r6.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 2) & 0xFFFFFFFC;
	// lhz r8,2(r5)
	ctx.r8.u64 = REX_LOAD_U16(ctx.r5.u32 + 2);
	// lwzx r11,r6,r7
	ctx.r11.u64 = REX_LOAD_U32(ctx.r6.u32 + ctx.r7.u32);
	// add r11,r11,r8
	ctx.r11.u64 = ctx.r11.u64 + ctx.r8.u64;
	// addi r11,r11,8
	ctx.r11.s64 = ctx.r11.s64 + 8;
	// addi r4,r11,2
	ctx.r4.s64 = ctx.r11.s64 + 2;
	// lhz r8,0(r11)
	ctx.r8.u64 = REX_LOAD_U16(ctx.r11.u32 + 0);
loc_8B0C4720:
	// clrlwi r11,r8,16
	ctx.r11.u64 = ctx.r8.u32 & 0xFFFF;
	// clrlwi r10,r10,16
	ctx.r10.u64 = ctx.r10.u32 & 0xFFFF;
	// cmplw cr6,r10,r11
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, ctx.r11.u32, ctx.xer);
	// bne cr6,0x8b0c4794
	if (!ctx.cr6.eq) goto loc_8B0C4794;
	// lbz r11,28(r9)
	ctx.r11.u64 = REX_LOAD_U8(ctx.r9.u32 + 28);
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// bne cr6,0x8b0c477c
	if (!ctx.cr6.eq) goto loc_8B0C477C;
	// mr r10,r4
	ctx.r10.u64 = ctx.r4.u64;
	// mr r11,r3
	ctx.r11.u64 = ctx.r3.u64;
loc_8B0C4744:
	// lbz r9,0(r11)
	ctx.r9.u64 = REX_LOAD_U8(ctx.r11.u32 + 0);
	// lbz r8,0(r10)
	ctx.r8.u64 = REX_LOAD_U8(ctx.r10.u32 + 0);
	// cmpwi cr6,r9,0
	ctx.cr6.compare<int32_t>(ctx.r9.s32, 0, ctx.xer);
	// subf r9,r8,r9
	ctx.r9.u64 = ctx.r9.u64 - ctx.r8.u64;
	// beq cr6,0x8b0c4768
	if (ctx.cr6.eq) goto loc_8B0C4768;
	// addi r11,r11,1
	ctx.r11.s64 = ctx.r11.s64 + 1;
	// addi r10,r10,1
	ctx.r10.s64 = ctx.r10.s64 + 1;
	// cmpwi cr6,r9,0
	ctx.cr6.compare<int32_t>(ctx.r9.s32, 0, ctx.xer);
	// beq cr6,0x8b0c4744
	if (ctx.cr6.eq) goto loc_8B0C4744;
loc_8B0C4768:
	// rlwinm r3,r9,1,31,31
	ctx.r3.u64 = __builtin_rotateleft64(ctx.r9.u32 | (ctx.r9.u64 << 32), 1) & 0x1;
	// addi r1,r1,96
	ctx.r1.s64 = ctx.r1.s64 + 96;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// blr 
	return;
loc_8B0C477C:
	// bl 0x8b0cea10
	ctx.lr = 0x8B0C4780;
	sub_8B0CEA10(ctx, base);
	// rlwinm r3,r3,1,31,31
	ctx.r3.u64 = __builtin_rotateleft64(ctx.r3.u32 | (ctx.r3.u64 << 32), 1) & 0x1;
	// addi r1,r1,96
	ctx.r1.s64 = ctx.r1.s64 + 96;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// blr 
	return;
loc_8B0C4794:
	// subfc r11,r11,r10
	ctx.xer.ca = ctx.r10.u32 >= ctx.r11.u32;
	ctx.r11.u64 = ctx.r10.u64 - ctx.r11.u64;
	// subfe r9,r10,r10
	temp.u8 = (~ctx.r10.u32 + ctx.r10.u32 < ~ctx.r10.u32) | (~ctx.r10.u32 + ctx.r10.u32 + ctx.xer.ca < ctx.xer.ca);
	ctx.r9.u64 = ~ctx.r10.u64 + ctx.r10.u64 + ctx.xer.ca;
	ctx.xer.ca = temp.u8;
	// clrlwi r3,r9,31
	ctx.r3.u64 = ctx.r9.u32 & 0x1;
	// addi r1,r1,96
	ctx.r1.s64 = ctx.r1.s64 + 96;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0C4AC8) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9b0
	ctx.lr = 0x8B0C4AD0;
	__savegprlr_26(ctx, base);
	// stwu r1,-144(r1)
	ea = -144 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// mr r30,r4
	ctx.r30.u64 = ctx.r4.u64;
	// bl 0x8b0c45e8
	ctx.lr = 0x8B0C4AE0;
	sub_8B0C45E8(ctx, base);
	// mr r11,r3
	ctx.r11.u64 = ctx.r3.u64;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// lhz r29,0(r11)
	ctx.r29.u64 = REX_LOAD_U16(ctx.r11.u32 + 0);
	// mr r4,r29
	ctx.r4.u64 = ctx.r29.u64;
	// bl 0x8b0c45e8
	ctx.lr = 0x8B0C4AF4;
	sub_8B0C45E8(ctx, base);
	// rlwinm r11,r30,1,15,30
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r30.u32 | (ctx.r30.u64 << 32), 1) & 0x1FFFE;
	// clrlwi r27,r30,16
	ctx.r27.u64 = ctx.r30.u32 & 0xFFFF;
	// lhz r10,2(r3)
	ctx.r10.u64 = REX_LOAD_U16(ctx.r3.u32 + 2);
	// lwz r9,4(r31)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r31.u32 + 4);
	// mr r4,r29
	ctx.r4.u64 = ctx.r29.u64;
	// add r8,r27,r11
	ctx.r8.u64 = ctx.r27.u64 + ctx.r11.u64;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// rlwinm r26,r8,2,0,29
	ctx.r26.u64 = __builtin_rotateleft64(ctx.r8.u32 | (ctx.r8.u64 << 32), 2) & 0xFFFFFFFC;
	// sthx r10,r9,r26
	REX_STORE_U16(ctx.r9.u32 + ctx.r26.u32, ctx.r10.u16);
	// bl 0x8b0c45e8
	ctx.lr = 0x8B0C4B1C;
	sub_8B0C45E8(ctx, base);
	// lhz r7,2(r3)
	ctx.r7.u64 = REX_LOAD_U16(ctx.r3.u32 + 2);
	// cmplwi cr6,r7,65535
	ctx.cr6.compare<uint32_t>(ctx.r7.u32, 65535, ctx.xer);
	// beq cr6,0x8b0c4b50
	if (ctx.cr6.eq) goto loc_8B0C4B50;
	// mr r4,r29
	ctx.r4.u64 = ctx.r29.u64;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0c45e8
	ctx.lr = 0x8B0C4B34;
	sub_8B0C45E8(ctx, base);
	// lhz r10,2(r3)
	ctx.r10.u64 = REX_LOAD_U16(ctx.r3.u32 + 2);
	// lwz r9,4(r31)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r31.u32 + 4);
	// rotlwi r11,r10,1
	ctx.r11.u64 = __builtin_rotateleft32(ctx.r10.u32, 1);
	// add r8,r10,r11
	ctx.r8.u64 = ctx.r10.u64 + ctx.r11.u64;
	// rlwinm r11,r8,2,0,29
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r8.u32 | (ctx.r8.u64 << 32), 2) & 0xFFFFFFFC;
	// add r7,r11,r9
	ctx.r7.u64 = ctx.r11.u64 + ctx.r9.u64;
	// sth r30,4(r7)
	REX_STORE_U16(ctx.r7.u32 + 4, ctx.r30.u16);
loc_8B0C4B50:
	// clrlwi r28,r29,16
	ctx.r28.u64 = ctx.r29.u32 & 0xFFFF;
	// cmplwi cr6,r28,65535
	ctx.cr6.compare<uint32_t>(ctx.r28.u32, 65535, ctx.xer);
	// beq cr6,0x8b0c4b84
	if (ctx.cr6.eq) goto loc_8B0C4B84;
	// mr r4,r30
	ctx.r4.u64 = ctx.r30.u64;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0c45e8
	ctx.lr = 0x8B0C4B68;
	sub_8B0C45E8(ctx, base);
	// rlwinm r11,r28,1,0,30
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r28.u32 | (ctx.r28.u64 << 32), 1) & 0xFFFFFFFE;
	// lwz r10,4(r31)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r31.u32 + 4);
	// add r11,r28,r11
	ctx.r11.u64 = ctx.r28.u64 + ctx.r11.u64;
	// lhz r9,4(r3)
	ctx.r9.u64 = REX_LOAD_U16(ctx.r3.u32 + 4);
	// rlwinm r11,r11,2,0,29
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 2) & 0xFFFFFFFC;
	// add r8,r11,r10
	ctx.r8.u64 = ctx.r11.u64 + ctx.r10.u64;
	// sth r9,4(r8)
	REX_STORE_U16(ctx.r8.u32 + 4, ctx.r9.u16);
loc_8B0C4B84:
	// lhz r11,16(r31)
	ctx.r11.u64 = REX_LOAD_U16(ctx.r31.u32 + 16);
	// cmplw cr6,r27,r11
	ctx.cr6.compare<uint32_t>(ctx.r27.u32, ctx.r11.u32, ctx.xer);
	// beq cr6,0x8b0c4c04
	if (ctx.cr6.eq) goto loc_8B0C4C04;
	// mr r4,r30
	ctx.r4.u64 = ctx.r30.u64;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0c45e8
	ctx.lr = 0x8B0C4B9C;
	sub_8B0C45E8(ctx, base);
	// lhz r4,4(r3)
	ctx.r4.u64 = REX_LOAD_U16(ctx.r3.u32 + 4);
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0c45e8
	ctx.lr = 0x8B0C4BA8;
	sub_8B0C45E8(ctx, base);
	// lhz r11,2(r3)
	ctx.r11.u64 = REX_LOAD_U16(ctx.r3.u32 + 2);
	// mr r4,r30
	ctx.r4.u64 = ctx.r30.u64;
	// cmplw cr6,r11,r27
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, ctx.r27.u32, ctx.xer);
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bne cr6,0x8b0c4be0
	if (!ctx.cr6.eq) goto loc_8B0C4BE0;
	// bl 0x8b0c45e8
	ctx.lr = 0x8B0C4BC0;
	sub_8B0C45E8(ctx, base);
	// lhz r9,4(r3)
	ctx.r9.u64 = REX_LOAD_U16(ctx.r3.u32 + 4);
	// lwz r10,4(r31)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r31.u32 + 4);
	// rotlwi r11,r9,1
	ctx.r11.u64 = __builtin_rotateleft32(ctx.r9.u32, 1);
	// add r8,r9,r11
	ctx.r8.u64 = ctx.r9.u64 + ctx.r11.u64;
	// rlwinm r11,r8,2,0,29
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r8.u32 | (ctx.r8.u64 << 32), 2) & 0xFFFFFFFC;
	// add r7,r11,r10
	ctx.r7.u64 = ctx.r11.u64 + ctx.r10.u64;
	// sth r29,2(r7)
	REX_STORE_U16(ctx.r7.u32 + 2, ctx.r29.u16);
	// b 0x8b0c4c08
	goto loc_8B0C4C08;
loc_8B0C4BE0:
	// bl 0x8b0c45e8
	ctx.lr = 0x8B0C4BE4;
	sub_8B0C45E8(ctx, base);
	// lhz r10,4(r3)
	ctx.r10.u64 = REX_LOAD_U16(ctx.r3.u32 + 4);
	// lwz r9,4(r31)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r31.u32 + 4);
	// mr r11,r10
	ctx.r11.u64 = ctx.r10.u64;
	// rotlwi r10,r10,1
	ctx.r10.u64 = __builtin_rotateleft32(ctx.r10.u32, 1);
	// add r8,r11,r10
	ctx.r8.u64 = ctx.r11.u64 + ctx.r10.u64;
	// rlwinm r7,r8,2,0,29
	ctx.r7.u64 = __builtin_rotateleft64(ctx.r8.u32 | (ctx.r8.u64 << 32), 2) & 0xFFFFFFFC;
	// sthx r29,r7,r9
	REX_STORE_U16(ctx.r7.u32 + ctx.r9.u32, ctx.r29.u16);
	// b 0x8b0c4c08
	goto loc_8B0C4C08;
loc_8B0C4C04:
	// sth r29,16(r31)
	REX_STORE_U16(ctx.r31.u32 + 16, ctx.r29.u16);
loc_8B0C4C08:
	// rlwinm r11,r28,1,0,30
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r28.u32 | (ctx.r28.u64 << 32), 1) & 0xFFFFFFFE;
	// lwz r10,4(r31)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r31.u32 + 4);
	// cmplwi cr6,r27,65535
	ctx.cr6.compare<uint32_t>(ctx.r27.u32, 65535, ctx.xer);
	// add r11,r28,r11
	ctx.r11.u64 = ctx.r28.u64 + ctx.r11.u64;
	// rlwinm r11,r11,2,0,29
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 2) & 0xFFFFFFFC;
	// add r10,r11,r10
	ctx.r10.u64 = ctx.r11.u64 + ctx.r10.u64;
	// sth r30,2(r10)
	REX_STORE_U16(ctx.r10.u32 + 2, ctx.r30.u16);
	// beq cr6,0x8b0c4c34
	if (ctx.cr6.eq) goto loc_8B0C4C34;
	// lwz r11,4(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 4);
	// add r11,r11,r26
	ctx.r11.u64 = ctx.r11.u64 + ctx.r26.u64;
	// sth r29,4(r11)
	REX_STORE_U16(ctx.r11.u32 + 4, ctx.r29.u16);
loc_8B0C4C34:
	// addi r1,r1,144
	ctx.r1.s64 = ctx.r1.s64 + 144;
	// b 0x8b0cba00
	__restgprlr_26(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0C5918) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9bc
	ctx.lr = 0x8B0C5920;
	__savegprlr_29(ctx, base);
	// stwu r1,-112(r1)
	ea = -112 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// bl 0x8b0c5888
	ctx.lr = 0x8B0C592C;
	sub_8B0C5888(ctx, base);
	// li r11,0
	ctx.r11.s64 = 0;
	// addi r30,r31,36
	ctx.r30.s64 = ctx.r31.s64 + 36;
	// stw r11,48(r31)
	REX_STORE_U32(ctx.r31.u32 + 48, ctx.r11.u32);
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// bl 0x8b0906a8
	ctx.lr = 0x8B0C5940;
	sub_8B0906A8(ctx, base);
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// bl 0x8b0906a8
	ctx.lr = 0x8B0C5948;
	sub_8B0906A8(ctx, base);
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0c4d98
	ctx.lr = 0x8B0C5950;
	sub_8B0C4D98(ctx, base);
	// lis r10,0
	ctx.r10.s64 = 0;
	// addi r29,r31,4
	ctx.r29.s64 = ctx.r31.s64 + 4;
	// ori r30,r10,65535
	ctx.r30.u64 = ctx.r10.u64 | 65535;
	// mr r3,r29
	ctx.r3.u64 = ctx.r29.u64;
	// sth r30,20(r31)
	REX_STORE_U16(ctx.r31.u32 + 20, ctx.r30.u16);
	// bl 0x8b0906a8
	ctx.lr = 0x8B0C5968;
	sub_8B0906A8(ctx, base);
	// sth r30,22(r31)
	REX_STORE_U16(ctx.r31.u32 + 22, ctx.r30.u16);
	// mr r3,r29
	ctx.r3.u64 = ctx.r29.u64;
	// bl 0x8b0906a8
	ctx.lr = 0x8B0C5974;
	sub_8B0906A8(ctx, base);
	// addi r1,r1,112
	ctx.r1.s64 = ctx.r1.s64 + 112;
	// b 0x8b0cba0c
	__restgprlr_29(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0C5A88) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9b0
	ctx.lr = 0x8B0C5A90;
	__savegprlr_26(ctx, base);
	// stwu r1,-144(r1)
	ea = -144 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// mr r26,r3
	ctx.r26.u64 = ctx.r3.u64;
	// mr r29,r4
	ctx.r29.u64 = ctx.r4.u64;
	// mr r31,r5
	ctx.r31.u64 = ctx.r5.u64;
	// cmplwi cr6,r5,0
	ctx.cr6.compare<uint32_t>(ctx.r5.u32, 0, ctx.xer);
	// bne cr6,0x8b0c5abc
	if (!ctx.cr6.eq) goto loc_8B0C5ABC;
	// li r11,-1
	ctx.r11.s64 = -1;
loc_8B0C5AAC:
	// sth r11,0(r26)
	REX_STORE_U16(ctx.r26.u32 + 0, ctx.r11.u16);
	// mr r3,r26
	ctx.r3.u64 = ctx.r26.u64;
	// addi r1,r1,144
	ctx.r1.s64 = ctx.r1.s64 + 144;
	// b 0x8b0cba00
	__restgprlr_26(ctx, base);
	return;
loc_8B0C5ABC:
	// mr r5,r31
	ctx.r5.u64 = ctx.r31.u64;
	// mr r4,r29
	ctx.r4.u64 = ctx.r29.u64;
	// addi r3,r1,80
	ctx.r3.s64 = ctx.r1.s64 + 80;
	// bl 0x8b0c5770
	ctx.lr = 0x8B0C5ACC;
	sub_8B0C5770(ctx, base);
	// lhz r11,80(r1)
	ctx.r11.u64 = REX_LOAD_U16(ctx.r1.u32 + 80);
	// cmplwi cr6,r11,65535
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 65535, ctx.xer);
	// bne cr6,0x8b0c5aac
	if (!ctx.cr6.eq) goto loc_8B0C5AAC;
	// mr r11,r31
	ctx.r11.u64 = ctx.r31.u64;
loc_8B0C5ADC:
	// lbz r10,0(r11)
	ctx.r10.u64 = REX_LOAD_U8(ctx.r11.u32 + 0);
	// addi r11,r11,1
	ctx.r11.s64 = ctx.r11.s64 + 1;
	// cmplwi cr6,r10,0
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 0, ctx.xer);
	// bne cr6,0x8b0c5adc
	if (!ctx.cr6.eq) goto loc_8B0C5ADC;
	// subf r11,r31,r11
	ctx.r11.u64 = ctx.r11.u64 - ctx.r31.u64;
	// mr r3,r29
	ctx.r3.u64 = ctx.r29.u64;
	// addi r11,r11,-1
	ctx.r11.s64 = ctx.r11.s64 + -1;
	// rotlwi r11,r11,0
	ctx.r11.u64 = __builtin_rotateleft32(ctx.r11.u32, 0);
	// addi r27,r11,1
	ctx.r27.s64 = ctx.r11.s64 + 1;
	// addi r10,r27,3
	ctx.r10.s64 = ctx.r27.s64 + 3;
	// rlwinm r28,r10,0,0,30
	ctx.r28.u64 = __builtin_rotateleft64(ctx.r10.u32 | (ctx.r10.u64 << 32), 0) & 0xFFFFFFFE;
	// mr r4,r28
	ctx.r4.u64 = ctx.r28.u64;
	// bl 0x8b0c47b0
	ctx.lr = 0x8B0C5B10;
	sub_8B0C47B0(ctx, base);
	// mr r30,r3
	ctx.r30.u64 = ctx.r3.u64;
	// cmpwi cr6,r3,-1
	ctx.cr6.compare<int32_t>(ctx.r3.s32, -1, ctx.xer);
	// bne cr6,0x8b0c5b78
	if (!ctx.cr6.eq) goto loc_8B0C5B78;
	// addi r30,r28,12
	ctx.r30.s64 = ctx.r28.s64 + 12;
	// cmplwi cr6,r30,2048
	ctx.cr6.compare<uint32_t>(ctx.r30.u32, 2048, ctx.xer);
	// bgt cr6,0x8b0c5b2c
	if (ctx.cr6.gt) goto loc_8B0C5B2C;
	// li r30,2048
	ctx.r30.s64 = 2048;
loc_8B0C5B2C:
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// mr r4,r30
	ctx.r4.u64 = ctx.r30.u64;
	// lwz r11,1144(r11)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r11.u32 + 1144);
	// lwz r3,0(r11)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r11.u32 + 0);
	// lwz r10,0(r3)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r9,4(r10)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r10.u32 + 4);
	// mtctr r9
	ctx.ctr.u64 = ctx.r9.u64;
	// bctrl 
	ctx.lr = 0x8B0C5B4C;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// mr r11,r3
	ctx.r11.u64 = ctx.r3.u64;
	// stw r3,80(r1)
	REX_STORE_U32(ctx.r1.u32 + 80, ctx.r3.u32);
	// addi r8,r30,-12
	ctx.r8.s64 = ctx.r30.s64 + -12;
	// li r7,0
	ctx.r7.s64 = 0;
	// addi r3,r29,36
	ctx.r3.s64 = ctx.r29.s64 + 36;
	// addi r5,r1,80
	ctx.r5.s64 = ctx.r1.s64 + 80;
	// stw r8,0(r11)
	REX_STORE_U32(ctx.r11.u32 + 0, ctx.r8.u32);
	// stw r7,4(r11)
	REX_STORE_U32(ctx.r11.u32 + 4, ctx.r7.u32);
	// lwz r4,48(r29)
	ctx.r4.u64 = REX_LOAD_U32(ctx.r29.u32 + 48);
	// bl 0x8b09f3f8
	ctx.lr = 0x8B0C5B74;
	sub_8B09F3F8(ctx, base);
	// mr r30,r3
	ctx.r30.u64 = ctx.r3.u64;
loc_8B0C5B78:
	// lbz r11,28(r29)
	ctx.r11.u64 = REX_LOAD_U8(ctx.r29.u32 + 28);
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// beq cr6,0x8b0c5b90
	if (ctx.cr6.eq) goto loc_8B0C5B90;
	// bl 0x8b0cafe8
	ctx.lr = 0x8B0C5B8C;
	sub_8B0CAFE8(ctx, base);
	// b 0x8b0c5b94
	goto loc_8B0C5B94;
loc_8B0C5B90:
	// bl 0x8b0caf80
	ctx.lr = 0x8B0C5B94;
	sub_8B0CAF80(ctx, base);
loc_8B0C5B94:
	// lwz r11,36(r29)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r29.u32 + 36);
	// rlwinm r10,r30,2,0,29
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r30.u32 | (ctx.r30.u64 << 32), 2) & 0xFFFFFFFC;
	// mr r4,r31
	ctx.r4.u64 = ctx.r31.u64;
	// mr r9,r3
	ctx.r9.u64 = ctx.r3.u64;
	// mr r5,r27
	ctx.r5.u64 = ctx.r27.u64;
	// lwzx r31,r10,r11
	ctx.r31.u64 = REX_LOAD_U32(ctx.r10.u32 + ctx.r11.u32);
	// lwz r10,4(r31)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r31.u32 + 4);
	// add r11,r10,r31
	ctx.r11.u64 = ctx.r10.u64 + ctx.r31.u64;
	// mr r27,r10
	ctx.r27.u64 = ctx.r10.u64;
	// addi r10,r11,8
	ctx.r10.s64 = ctx.r11.s64 + 8;
	// addi r3,r10,2
	ctx.r3.s64 = ctx.r10.s64 + 2;
	// sth r9,8(r11)
	REX_STORE_U16(ctx.r11.u32 + 8, ctx.r9.u16);
	// bl 0x8b0cbb30
	ctx.lr = 0x8B0C5BC8;
	sub_8B0CBB30(ctx, base);
	// lwz r11,4(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 4);
	// sth r27,82(r1)
	REX_STORE_U16(ctx.r1.u32 + 82, ctx.r27.u16);
	// addi r4,r1,80
	ctx.r4.s64 = ctx.r1.s64 + 80;
	// add r7,r11,r28
	ctx.r7.u64 = ctx.r11.u64 + ctx.r28.u64;
	// sth r30,80(r1)
	REX_STORE_U16(ctx.r1.u32 + 80, ctx.r30.u16);
	// mr r3,r29
	ctx.r3.u64 = ctx.r29.u64;
	// stw r7,4(r31)
	REX_STORE_U32(ctx.r31.u32 + 4, ctx.r7.u32);
	// bl 0x8b0c5980
	ctx.lr = 0x8B0C5BE8;
	sub_8B0C5980(ctx, base);
	// sth r3,0(r26)
	REX_STORE_U16(ctx.r26.u32 + 0, ctx.r3.u16);
	// mr r3,r26
	ctx.r3.u64 = ctx.r26.u64;
	// addi r1,r1,144
	ctx.r1.s64 = ctx.r1.s64 + 144;
	// b 0x8b0cba00
	__restgprlr_26(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0C5FA8) {
	REX_FUNC_PROLOGUE();
	// lbz r3,8(r3)
	ctx.r3.u64 = REX_LOAD_U8(ctx.r3.u32 + 8);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0C60B8) {
	REX_FUNC_PROLOGUE();
	// lis r11,-29943
	ctx.r11.s64 = -1962344448;
	// addi r10,r11,-27640
	ctx.r10.s64 = ctx.r11.s64 + -27640;
	// stw r10,0(r3)
	REX_STORE_U32(ctx.r3.u32 + 0, ctx.r10.u32);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0C6148) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// std r31,-16(r1)
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.r31.u64);
	// stwu r1,-96(r1)
	ea = -96 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// lwz r3,36(r3)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r3.u32 + 36);
	// lis r11,-29943
	ctx.r11.s64 = -1962344448;
	// lis r10,-29943
	ctx.r10.s64 = -1962344448;
	// addi r9,r11,-27484
	ctx.r9.s64 = ctx.r11.s64 + -27484;
	// addi r8,r10,-27524
	ctx.r8.s64 = ctx.r10.s64 + -27524;
	// stw r9,0(r31)
	REX_STORE_U32(ctx.r31.u32 + 0, ctx.r9.u32);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// stw r8,24(r31)
	REX_STORE_U32(ctx.r31.u32 + 24, ctx.r8.u32);
	// beq cr6,0x8b0c618c
	if (ctx.cr6.eq) goto loc_8B0C618C;
	// bl 0x8b090020
	ctx.lr = 0x8B0C6184;
	sub_8B090020(ctx, base);
	// li r11,0
	ctx.r11.s64 = 0;
	// stw r11,36(r31)
	REX_STORE_U32(ctx.r31.u32 + 36, ctx.r11.u32);
loc_8B0C618C:
	// lis r11,-29943
	ctx.r11.s64 = -1962344448;
	// addi r10,r11,-27640
	ctx.r10.s64 = ctx.r11.s64 + -27640;
	// stw r10,0(r31)
	REX_STORE_U32(ctx.r31.u32 + 0, ctx.r10.u32);
	// addi r1,r1,96
	ctx.r1.s64 = ctx.r1.s64 + 96;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0C6210) {
	REX_FUNC_PROLOGUE();
	// lwz r11,28(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 28);
	// lwz r3,12(r11)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r11.u32 + 12);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0C63D0) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9b4
	ctx.lr = 0x8B0C63D8;
	__savegprlr_27(ctx, base);
	// stfd f31,-56(r1)
	ctx.fpscr.disableFlushMode();
	REX_STORE_U64(ctx.r1.u32 + -56, ctx.f31.u64);
	// addi r31,r1,-144
	ctx.r31.s64 = ctx.r1.s64 + -144;
	// stwu r1,-144(r1)
	ea = -144 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lwz r5,40(r3)
	ctx.r5.u64 = REX_LOAD_U32(ctx.r3.u32 + 40);
	// mr r30,r3
	ctx.r30.u64 = ctx.r3.u64;
	// mr r28,r4
	ctx.r28.u64 = ctx.r4.u64;
	// fmr f31,f1
	ctx.f31.f64 = ctx.f1.f64;
	// addi r11,r5,15
	ctx.r11.s64 = ctx.r5.s64 + 15;
	// rlwinm r10,r11,0,0,27
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 0) & 0xFFFFFFF0;
	// neg r9,r10
	ctx.r9.s64 = static_cast<int64_t>(-ctx.r10.u64);
	// rlwinm r12,r9,0,0,27
	ctx.r12.u64 = __builtin_rotateleft64(ctx.r9.u32 | (ctx.r9.u64 << 32), 0) & 0xFFFFFFF0;
	// bl 0x8b0ccf24
	ctx.lr = 0x8B0C6408;
	sub_8B0CCF24(ctx, base);
	// lwz r8,0(r1)
	ctx.r8.u64 = REX_LOAD_U32(ctx.r1.u32 + 0);
	// lwz r4,36(r3)
	ctx.r4.u64 = REX_LOAD_U32(ctx.r3.u32 + 36);
	// stwux r8,r1,r12
	ea = ctx.r1.u32 + ctx.r12.u32;
	REX_STORE_U32(ea, ctx.r8.u32);
	ctx.r1.u32 = ea;
	// addi r27,r1,80
	ctx.r27.s64 = ctx.r1.s64 + 80;
	// mr r3,r27
	ctx.r3.u64 = ctx.r27.u64;
	// bl 0x8b0cbb30
	ctx.lr = 0x8B0C6420;
	sub_8B0CBB30(ctx, base);
	// mr r11,r28
	ctx.r11.u64 = ctx.r28.u64;
loc_8B0C6424:
	// lbz r10,0(r11)
	ctx.r10.u64 = REX_LOAD_U8(ctx.r11.u32 + 0);
	// addi r11,r11,1
	ctx.r11.s64 = ctx.r11.s64 + 1;
	// cmplwi cr6,r10,0
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 0, ctx.xer);
	// bne cr6,0x8b0c6424
	if (!ctx.cr6.eq) goto loc_8B0C6424;
	// subf r11,r28,r11
	ctx.r11.u64 = ctx.r11.u64 - ctx.r28.u64;
	// lwz r10,40(r30)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r30.u32 + 40);
	// addi r9,r11,-1
	ctx.r9.s64 = ctx.r11.s64 + -1;
	// rotlwi r11,r9,0
	ctx.r11.u64 = __builtin_rotateleft32(ctx.r9.u32, 0);
	// addi r29,r11,1
	ctx.r29.s64 = ctx.r11.s64 + 1;
	// cmpw cr6,r29,r10
	ctx.cr6.compare<int32_t>(ctx.r29.s32, ctx.r10.s32, ctx.xer);
	// ble cr6,0x8b0c6470
	if (!ctx.cr6.gt) goto loc_8B0C6470;
	// lwz r3,36(r30)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r30.u32 + 36);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0c6460
	if (ctx.cr6.eq) goto loc_8B0C6460;
	// bl 0x8b090020
	ctx.lr = 0x8B0C6460;
	sub_8B090020(ctx, base);
loc_8B0C6460:
	// mr r3,r29
	ctx.r3.u64 = ctx.r29.u64;
	// bl 0x8b090000
	ctx.lr = 0x8B0C6468;
	sub_8B090000(ctx, base);
	// stw r3,36(r30)
	REX_STORE_U32(ctx.r30.u32 + 36, ctx.r3.u32);
	// stw r29,40(r30)
	REX_STORE_U32(ctx.r30.u32 + 40, ctx.r29.u32);
loc_8B0C6470:
	// mr r5,r29
	ctx.r5.u64 = ctx.r29.u64;
	// lwz r3,36(r30)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r30.u32 + 36);
	// mr r4,r28
	ctx.r4.u64 = ctx.r28.u64;
	// bl 0x8b0cbb30
	ctx.lr = 0x8B0C6480;
	sub_8B0CBB30(ctx, base);
	// lwz r11,68(r30)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r30.u32 + 68);
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// beq cr6,0x8b0c64a0
	if (ctx.cr6.eq) goto loc_8B0C64A0;
	// mr r4,r27
	ctx.r4.u64 = ctx.r27.u64;
	// fmr f1,f31
	ctx.fpscr.disableFlushMode();
	ctx.f1.f64 = ctx.f31.f64;
	// addi r3,r30,24
	ctx.r3.s64 = ctx.r30.s64 + 24;
	// mtctr r11
	ctx.ctr.u64 = ctx.r11.u64;
	// bctrl 
	ctx.lr = 0x8B0C64A0;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
loc_8B0C64A0:
	// lis r11,-29936
	ctx.r11.s64 = -1961885696;
	// lwz r3,-27244(r11)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r11.u32 + -27244);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0c64cc
	if (ctx.cr6.eq) goto loc_8B0C64CC;
	// lwz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// mr r5,r27
	ctx.r5.u64 = ctx.r27.u64;
	// mr r4,r30
	ctx.r4.u64 = ctx.r30.u64;
	// fmr f1,f31
	ctx.fpscr.disableFlushMode();
	ctx.f1.f64 = ctx.f31.f64;
	// lwz r10,72(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 72);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B0C64CC;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
loc_8B0C64CC:
	// addi r1,r31,144
	ctx.r1.s64 = ctx.r31.s64 + 144;
	// lfd f31,-56(r1)
	ctx.fpscr.disableFlushMode();
	ctx.f31.u64 = REX_LOAD_U64(ctx.r1.u32 + -56);
	// b 0x8b0cba04
	__restgprlr_27(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0C6790) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// stwu r1,-96(r1)
	ea = -96 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// stw r4,124(r1)
	REX_STORE_U32(ctx.r1.u32 + 124, ctx.r4.u32);
	// lbz r9,125(r1)
	ctx.r9.u64 = REX_LOAD_U8(ctx.r1.u32 + 125);
	// lbz r8,126(r1)
	ctx.r8.u64 = REX_LOAD_U8(ctx.r1.u32 + 126);
	// lbz r7,127(r1)
	ctx.r7.u64 = REX_LOAD_U8(ctx.r1.u32 + 127);
	// lbz r10,124(r1)
	ctx.r10.u64 = REX_LOAD_U8(ctx.r1.u32 + 124);
	// stb r10,80(r1)
	REX_STORE_U8(ctx.r1.u32 + 80, ctx.r10.u8);
	// lwz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// stb r9,81(r1)
	REX_STORE_U8(ctx.r1.u32 + 81, ctx.r9.u8);
	// stb r8,82(r1)
	REX_STORE_U8(ctx.r1.u32 + 82, ctx.r8.u8);
	// stb r7,83(r1)
	REX_STORE_U8(ctx.r1.u32 + 83, ctx.r7.u8);
	// lwz r4,80(r1)
	ctx.r4.u64 = REX_LOAD_U32(ctx.r1.u32 + 80);
	// lwz r6,56(r11)
	ctx.r6.u64 = REX_LOAD_U32(ctx.r11.u32 + 56);
	// mtctr r6
	ctx.ctr.u64 = ctx.r6.u64;
	// bctrl 
	ctx.lr = 0x8B0C67D4;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// addi r1,r1,96
	ctx.r1.s64 = ctx.r1.s64 + 96;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0C67E8) {
	REX_FUNC_PROLOGUE();
	PPCRegister temp{};
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9b4
	ctx.lr = 0x8B0C67F0;
	__savegprlr_27(ctx, base);
	// stfd f31,-56(r1)
	ctx.fpscr.disableFlushMode();
	REX_STORE_U64(ctx.r1.u32 + -56, ctx.f31.u64);
	// stwu r1,-144(r1)
	ea = -144 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// stw r3,28(r3)
	REX_STORE_U32(ctx.r3.u32 + 28, ctx.r3.u32);
	// mr r28,r4
	ctx.r28.u64 = ctx.r4.u64;
	// mr r9,r5
	ctx.r9.u64 = ctx.r5.u64;
	// mr r30,r6
	ctx.r30.u64 = ctx.r6.u64;
	// mr r27,r7
	ctx.r27.u64 = ctx.r7.u64;
	// cmplwi cr6,r5,0
	ctx.cr6.compare<uint32_t>(ctx.r5.u32, 0, ctx.xer);
	// bne cr6,0x8b0c6820
	if (!ctx.cr6.eq) goto loc_8B0C6820;
	// lis r11,-29938
	ctx.r11.s64 = -1962016768;
	// lwz r9,9284(r11)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r11.u32 + 9284);
loc_8B0C6820:
	// lwz r7,236(r1)
	ctx.r7.u64 = REX_LOAD_U32(ctx.r1.u32 + 236);
	// stfs f1,56(r31)
	ctx.fpscr.disableFlushMode();
	temp.f32 = float(ctx.f1.f64);
	REX_STORE_U32(ctx.r31.u32 + 56, temp.u32);
	// stfs f2,64(r31)
	temp.f32 = float(ctx.f2.f64);
	REX_STORE_U32(ctx.r31.u32 + 64, temp.u32);
	// stw r9,32(r31)
	REX_STORE_U32(ctx.r31.u32 + 32, ctx.r9.u32);
	// mr r11,r9
	ctx.r11.u64 = ctx.r9.u64;
	// stb r8,52(r31)
	REX_STORE_U8(ctx.r31.u32 + 52, ctx.r8.u8);
	// stb r10,60(r31)
	REX_STORE_U8(ctx.r31.u32 + 60, ctx.r10.u8);
	// stw r7,68(r31)
	REX_STORE_U32(ctx.r31.u32 + 68, ctx.r7.u32);
loc_8B0C6840:
	// lbz r10,0(r11)
	ctx.r10.u64 = REX_LOAD_U8(ctx.r11.u32 + 0);
	// addi r11,r11,1
	ctx.r11.s64 = ctx.r11.s64 + 1;
	// cmplwi cr6,r10,0
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 0, ctx.xer);
	// bne cr6,0x8b0c6840
	if (!ctx.cr6.eq) goto loc_8B0C6840;
	// subf r11,r9,r11
	ctx.r11.u64 = ctx.r11.u64 - ctx.r9.u64;
	// addi r11,r11,-1
	ctx.r11.s64 = ctx.r11.s64 + -1;
	// rotlwi r11,r11,0
	ctx.r11.u64 = __builtin_rotateleft32(ctx.r11.u32, 0);
	// addi r3,r11,1
	ctx.r3.s64 = ctx.r11.s64 + 1;
	// stw r3,40(r31)
	REX_STORE_U32(ctx.r31.u32 + 40, ctx.r3.u32);
	// bl 0x8b090000
	ctx.lr = 0x8B0C6868;
	sub_8B090000(ctx, base);
	// stw r3,36(r31)
	REX_STORE_U32(ctx.r31.u32 + 36, ctx.r3.u32);
	// lwz r5,40(r31)
	ctx.r5.u64 = REX_LOAD_U32(ctx.r31.u32 + 40);
	// lwz r4,32(r31)
	ctx.r4.u64 = REX_LOAD_U32(ctx.r31.u32 + 32);
	// bl 0x8b0cbb30
	ctx.lr = 0x8B0C6878;
	sub_8B0CBB30(ctx, base);
	// lwz r3,36(r31)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r31.u32 + 36);
	// bl 0x8b0ce2d8
	ctx.lr = 0x8B0C6880;
	sub_8B0CE2D8(ctx, base);
	// frsp f0,f1
	ctx.fpscr.disableFlushMode();
	ctx.f0.f64 = double(float(ctx.f1.f64));
	// lis r10,-29943
	ctx.r10.s64 = -1962344448;
	// stfs f0,44(r31)
	temp.f32 = float(ctx.f0.f64);
	REX_STORE_U32(ctx.r31.u32 + 44, temp.u32);
	// li r29,0
	ctx.r29.s64 = 0;
	// lfs f31,-27648(r10)
	temp.u32 = REX_LOAD_U32(ctx.r10.u32 + -27648);
	ctx.f31.f64 = double(temp.f32);
	// fcmpu cr6,f0,f0
	ctx.cr6.compare(ctx.f0.f64, ctx.f0.f64);
	// bne cr6,0x8b0c68ac
	if (!ctx.cr6.eq) goto loc_8B0C68AC;
	// fabs f0,f0
	ctx.f0.u64 = ctx.f0.u64 & ~0x8000000000000000;
	// li r11,1
	ctx.r11.s64 = 1;
	// fcmpu cr6,f0,f31
	ctx.cr6.compare(ctx.f0.f64, ctx.f31.f64);
	// ble cr6,0x8b0c68b0
	if (!ctx.cr6.gt) goto loc_8B0C68B0;
loc_8B0C68AC:
	// mr r11,r29
	ctx.r11.u64 = ctx.r29.u64;
loc_8B0C68B0:
	// clrlwi r11,r11,24
	ctx.r11.u64 = ctx.r11.u32 & 0xFF;
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// bne cr6,0x8b0c68d4
	if (!ctx.cr6.eq) goto loc_8B0C68D4;
	// lis r11,-29943
	ctx.r11.s64 = -1962344448;
	// lwz r5,36(r31)
	ctx.r5.u64 = REX_LOAD_U32(ctx.r31.u32 + 36);
	// mr r4,r28
	ctx.r4.u64 = ctx.r28.u64;
	// addi r3,r11,-27356
	ctx.r3.s64 = ctx.r11.s64 + -27356;
	// bl 0x8b0df2a8
	ctx.lr = 0x8B0C68D0;
	sub_8B0DF2A8(ctx, base);
	// stfs f31,44(r31)
	ctx.fpscr.disableFlushMode();
	temp.f32 = float(ctx.f31.f64);
	REX_STORE_U32(ctx.r31.u32 + 44, temp.u32);
loc_8B0C68D4:
	// li r11,48
	ctx.r11.s64 = 48;
	// lfs f0,44(r31)
	ctx.fpscr.disableFlushMode();
	temp.u32 = REX_LOAD_U32(ctx.r31.u32 + 44);
	ctx.f0.f64 = double(temp.f32);
	// rlwinm r10,r30,0,17,17
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r30.u32 | (ctx.r30.u64 << 32), 0) & 0x4000;
	// fctiwz f13,f0
	ctx.f13.s64 = std::isnan(ctx.f0.f64) ? int64_t(0x80000000U) : (ctx.f0.f64 >= double(INT_MAX)) ? INT_MAX : simde_mm_cvttsd_si32(simde_mm_load_sd(&ctx.f0.f64));
	// cmpwi cr6,r10,0
	ctx.cr6.compare<int32_t>(ctx.r10.s32, 0, ctx.xer);
	// stfiwx f13,r31,r11
	REX_STORE_U32(ctx.r31.u32 + ctx.r11.u32, ctx.f13.u32);
	// bne cr6,0x8b0c6918
	if (!ctx.cr6.eq) goto loc_8B0C6918;
	// rlwinm r11,r30,0,24,24
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r30.u32 | (ctx.r30.u64 << 32), 0) & 0x80;
	// cmpwi cr6,r11,0
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// bne cr6,0x8b0c6918
	if (!ctx.cr6.eq) goto loc_8B0C6918;
	// rlwinm r11,r30,0,12,12
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r30.u32 | (ctx.r30.u64 << 32), 0) & 0x80000;
	// cmpwi cr6,r11,0
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// bne cr6,0x8b0c6918
	if (!ctx.cr6.eq) goto loc_8B0C6918;
	// rlwinm r11,r30,0,22,22
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r30.u32 | (ctx.r30.u64 << 32), 0) & 0x200;
	// cmpwi cr6,r11,0
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// bne cr6,0x8b0c6918
	if (!ctx.cr6.eq) goto loc_8B0C6918;
	// ori r30,r30,2
	ctx.r30.u64 = ctx.r30.u64 | 2;
loc_8B0C6918:
	// stw r28,12(r31)
	REX_STORE_U32(ctx.r31.u32 + 12, ctx.r28.u32);
	// cmplwi cr6,r27,0
	ctx.cr6.compare<uint32_t>(ctx.r27.u32, 0, ctx.xer);
	// stb r29,8(r31)
	REX_STORE_U8(ctx.r31.u32 + 8, ctx.r29.u8);
	// beq cr6,0x8b0c6930
	if (ctx.cr6.eq) goto loc_8B0C6930;
	// mr r11,r27
	ctx.r11.u64 = ctx.r27.u64;
	// b 0x8b0c6938
	goto loc_8B0C6938;
loc_8B0C6930:
	// lis r11,-29938
	ctx.r11.s64 = -1962016768;
	// lwz r11,9204(r11)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r11.u32 + 9204);
loc_8B0C6938:
	// clrlwi r10,r30,31
	ctx.r10.u64 = ctx.r30.u32 & 0x1;
	// stw r11,16(r31)
	REX_STORE_U32(ctx.r31.u32 + 16, ctx.r11.u32);
	// stw r30,20(r31)
	REX_STORE_U32(ctx.r31.u32 + 20, ctx.r30.u32);
	// cmpwi cr6,r10,0
	ctx.cr6.compare<int32_t>(ctx.r10.s32, 0, ctx.xer);
	// bne cr6,0x8b0c6960
	if (!ctx.cr6.eq) goto loc_8B0C6960;
	// lis r10,-29936
	ctx.r10.s64 = -1961885696;
	// lwz r11,-27544(r10)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r10.u32 + -27544);
	// stw r11,4(r31)
	REX_STORE_U32(ctx.r31.u32 + 4, ctx.r11.u32);
	// stw r31,-27544(r10)
	REX_STORE_U32(ctx.r10.u32 + -27544, ctx.r31.u32);
	// b 0x8b0c6964
	goto loc_8B0C6964;
loc_8B0C6960:
	// stw r29,4(r31)
	REX_STORE_U32(ctx.r31.u32 + 4, ctx.r29.u32);
loc_8B0C6964:
	// lis r11,-29936
	ctx.r11.s64 = -1961885696;
	// lwz r11,-27540(r11)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r11.u32 + -27540);
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// beq cr6,0x8b0c6988
	if (ctx.cr6.eq) goto loc_8B0C6988;
	// lwz r11,0(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 0);
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// lwz r10,44(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 44);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B0C6988;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
loc_8B0C6988:
	// addi r1,r1,144
	ctx.r1.s64 = ctx.r1.s64 + 144;
	// lfd f31,-56(r1)
	ctx.fpscr.disableFlushMode();
	ctx.f31.u64 = REX_LOAD_U64(ctx.r1.u32 + -56);
	// b 0x8b0cba04
	__restgprlr_27(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0C6F58) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// std r31,-16(r1)
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.r31.u64);
	// stwu r1,-96(r1)
	ea = -96 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// li r5,0
	ctx.r5.s64 = 0;
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// bl 0x8b0c6c58
	ctx.lr = 0x8B0C6F74;
	sub_8B0C6C58(ctx, base);
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// addi r1,r1,96
	ctx.r1.s64 = ctx.r1.s64 + 96;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0C6FF8) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9bc
	ctx.lr = 0x8B0C7000;
	__savegprlr_29(ctx, base);
	// stwu r1,-112(r1)
	ea = -112 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lwz r10,12(r3)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r3.u32 + 12);
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// lwz r11,4(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 4);
	// mr r30,r4
	ctx.r30.u64 = ctx.r4.u64;
	// addi r9,r10,1
	ctx.r9.s64 = ctx.r10.s64 + 1;
	// mr r29,r5
	ctx.r29.u64 = ctx.r5.u64;
	// cmpw cr6,r9,r11
	ctx.cr6.compare<int32_t>(ctx.r9.s32, ctx.r11.s32, ctx.xer);
	// ble cr6,0x8b0c7030
	if (!ctx.cr6.gt) goto loc_8B0C7030;
	// subf r11,r11,r10
	ctx.r11.u64 = ctx.r10.u64 - ctx.r11.u64;
	// addi r4,r11,1
	ctx.r4.s64 = ctx.r11.s64 + 1;
	// bl 0x8b0c6e80
	ctx.lr = 0x8B0C7030;
	sub_8B0C6E80(ctx, base);
loc_8B0C7030:
	// lwz r11,12(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 12);
	// addi r11,r11,1
	ctx.r11.s64 = ctx.r11.s64 + 1;
	// subf r10,r30,r11
	ctx.r10.u64 = ctx.r11.u64 - ctx.r30.u64;
	// stw r11,12(r31)
	REX_STORE_U32(ctx.r31.u32 + 12, ctx.r11.u32);
	// addic. r11,r10,-1
	ctx.xer.ca = ctx.r10.u32 > 0;
	ctx.r11.s64 = ctx.r10.s64 + -1;
	ctx.cr0.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// ble 0x8b0c7060
	if (!ctx.cr0.gt) goto loc_8B0C7060;
	// lwz r9,0(r31)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r31.u32 + 0);
	// rlwinm r10,r30,4,0,27
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r30.u32 | (ctx.r30.u64 << 32), 4) & 0xFFFFFFF0;
	// rlwinm r5,r11,4,0,27
	ctx.r5.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 4) & 0xFFFFFFF0;
	// add r4,r10,r9
	ctx.r4.u64 = ctx.r10.u64 + ctx.r9.u64;
	// addi r3,r4,16
	ctx.r3.s64 = ctx.r4.s64 + 16;
	// bl 0x8b0cc060
	ctx.lr = 0x8B0C7060;
	sub_8B0CC060(ctx, base);
loc_8B0C7060:
	// lwz r10,0(r31)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r31.u32 + 0);
	// rlwinm r11,r30,4,0,27
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r30.u32 | (ctx.r30.u64 << 32), 4) & 0xFFFFFFF0;
	// add. r3,r11,r10
	ctx.r3.u64 = ctx.r11.u64 + ctx.r10.u64;
	ctx.cr0.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// beq 0x8b0c7078
	if (ctx.cr0.eq) goto loc_8B0C7078;
	// mr r4,r29
	ctx.r4.u64 = ctx.r29.u64;
	// bl 0x8b0cb170
	ctx.lr = 0x8B0C7078;
	sub_8B0CB170(ctx, base);
loc_8B0C7078:
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// addi r1,r1,112
	ctx.r1.s64 = ctx.r1.s64 + 112;
	// b 0x8b0cba0c
	__restgprlr_29(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0C73C0) {
	REX_FUNC_PROLOGUE();
	// li r11,-1
	ctx.r11.s64 = -1;
	// stw r11,0(r3)
	REX_STORE_U32(ctx.r3.u32 + 0, ctx.r11.u32);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0C73D0) {
	REX_FUNC_PROLOGUE();
	// lwz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// not r10,r11
	ctx.r10.u64 = ~ctx.r11.u64;
	// stw r10,0(r3)
	REX_STORE_U32(ctx.r3.u32 + 0, ctx.r10.u32);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0C73E0) {
	REX_FUNC_PROLOGUE();
	// lis r10,-29943
	ctx.r10.s64 = -1962344448;
	// lwz r9,0(r3)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// mr r11,r4
	ctx.r11.u64 = ctx.r4.u64;
	// addi r10,r10,-27048
	ctx.r10.s64 = ctx.r10.s64 + -27048;
loc_8B0C73F0:
	// cmplwi cr6,r5,7
	ctx.cr6.compare<uint32_t>(ctx.r5.u32, 7, ctx.xer);
	// bgt cr6,0x8b0c7420
	if (ctx.cr6.gt) goto loc_8B0C7420;
	// mtctr r5
	ctx.ctr.u64 = ctx.r5.u64;
	// cmpwi cr6,r5,0
	ctx.cr6.compare<int32_t>(ctx.r5.s32, 0, ctx.xer);
	// beq cr6,0x8b0c767c
	if (ctx.cr6.eq) goto loc_8B0C767C;
	// bdz 0x8b0c7660
	--ctx.ctr.u64;
	if (ctx.ctr.u32 == 0) goto loc_8B0C7660;
	// bdz 0x8b0c7640
	--ctx.ctr.u64;
	if (ctx.ctr.u32 == 0) goto loc_8B0C7640;
	// bdz 0x8b0c7620
	--ctx.ctr.u64;
	if (ctx.ctr.u32 == 0) goto loc_8B0C7620;
	// bdz 0x8b0c75c4
	--ctx.ctr.u64;
	if (ctx.ctr.u32 == 0) goto loc_8B0C75C4;
	// bdz 0x8b0c75a4
	--ctx.ctr.u64;
	if (ctx.ctr.u32 == 0) goto loc_8B0C75A4;
	// bdz 0x8b0c7584
	--ctx.ctr.u64;
	if (ctx.ctr.u32 == 0) goto loc_8B0C7584;
	// b 0x8b0c7564
	goto loc_8B0C7564;
loc_8B0C7420:
	// clrlwi r8,r11,30
	ctx.r8.u64 = ctx.r11.u32 & 0x3;
	// subf r7,r8,r5
	ctx.r7.u64 = ctx.r5.u64 - ctx.r8.u64;
	// cmplwi cr6,r8,1
	ctx.cr6.compare<uint32_t>(ctx.r8.u32, 1, ctx.xer);
	// beq cr6,0x8b0c7480
	if (ctx.cr6.eq) goto loc_8B0C7480;
	// cmplwi cr6,r8,2
	ctx.cr6.compare<uint32_t>(ctx.r8.u32, 2, ctx.xer);
	// beq cr6,0x8b0c7460
	if (ctx.cr6.eq) goto loc_8B0C7460;
	// cmplwi cr6,r8,3
	ctx.cr6.compare<uint32_t>(ctx.r8.u32, 3, ctx.xer);
	// bne cr6,0x8b0c74a0
	if (!ctx.cr6.eq) goto loc_8B0C74A0;
	// lbz r8,0(r11)
	ctx.r8.u64 = REX_LOAD_U8(ctx.r11.u32 + 0);
	// clrlwi r6,r9,24
	ctx.r6.u64 = ctx.r9.u32 & 0xFF;
	// rlwinm r5,r9,24,8,31
	ctx.r5.u64 = __builtin_rotateleft64(ctx.r9.u32 | (ctx.r9.u64 << 32), 24) & 0xFFFFFF;
	// xor r4,r6,r8
	ctx.r4.u64 = ctx.r6.u64 ^ ctx.r8.u64;
	// addi r11,r11,1
	ctx.r11.s64 = ctx.r11.s64 + 1;
	// rlwinm r9,r4,2,0,29
	ctx.r9.u64 = __builtin_rotateleft64(ctx.r4.u32 | (ctx.r4.u64 << 32), 2) & 0xFFFFFFFC;
	// lwzx r8,r9,r10
	ctx.r8.u64 = REX_LOAD_U32(ctx.r9.u32 + ctx.r10.u32);
	// xor r9,r8,r5
	ctx.r9.u64 = ctx.r8.u64 ^ ctx.r5.u64;
loc_8B0C7460:
	// lbz r8,0(r11)
	ctx.r8.u64 = REX_LOAD_U8(ctx.r11.u32 + 0);
	// clrlwi r6,r9,24
	ctx.r6.u64 = ctx.r9.u32 & 0xFF;
	// rlwinm r5,r9,24,8,31
	ctx.r5.u64 = __builtin_rotateleft64(ctx.r9.u32 | (ctx.r9.u64 << 32), 24) & 0xFFFFFF;
	// xor r4,r6,r8
	ctx.r4.u64 = ctx.r6.u64 ^ ctx.r8.u64;
	// addi r11,r11,1
	ctx.r11.s64 = ctx.r11.s64 + 1;
	// rlwinm r9,r4,2,0,29
	ctx.r9.u64 = __builtin_rotateleft64(ctx.r4.u32 | (ctx.r4.u64 << 32), 2) & 0xFFFFFFFC;
	// lwzx r8,r9,r10
	ctx.r8.u64 = REX_LOAD_U32(ctx.r9.u32 + ctx.r10.u32);
	// xor r9,r8,r5
	ctx.r9.u64 = ctx.r8.u64 ^ ctx.r5.u64;
loc_8B0C7480:
	// lbz r8,0(r11)
	ctx.r8.u64 = REX_LOAD_U8(ctx.r11.u32 + 0);
	// clrlwi r6,r9,24
	ctx.r6.u64 = ctx.r9.u32 & 0xFF;
	// rlwinm r5,r9,24,8,31
	ctx.r5.u64 = __builtin_rotateleft64(ctx.r9.u32 | (ctx.r9.u64 << 32), 24) & 0xFFFFFF;
	// xor r4,r6,r8
	ctx.r4.u64 = ctx.r6.u64 ^ ctx.r8.u64;
	// addi r11,r11,1
	ctx.r11.s64 = ctx.r11.s64 + 1;
	// rlwinm r9,r4,2,0,29
	ctx.r9.u64 = __builtin_rotateleft64(ctx.r4.u32 | (ctx.r4.u64 << 32), 2) & 0xFFFFFFFC;
	// lwzx r8,r9,r10
	ctx.r8.u64 = REX_LOAD_U32(ctx.r9.u32 + ctx.r10.u32);
	// xor r9,r8,r5
	ctx.r9.u64 = ctx.r8.u64 ^ ctx.r5.u64;
loc_8B0C74A0:
	// srawi. r8,r7,3
	ctx.xer.ca = (ctx.r7.s32 < 0) & ((ctx.r7.u32 & 0x7) != 0);
	ctx.r8.s64 = ctx.r7.s32 >> 3;
	ctx.cr0.compare<int32_t>(ctx.r8.s32, 0, ctx.xer);
	// beq 0x8b0c755c
	if (ctx.cr0.eq) goto loc_8B0C755C;
	// mtctr r8
	ctx.ctr.u64 = ctx.r8.u64;
	// addi r8,r1,-16
	ctx.r8.s64 = ctx.r1.s64 + -16;
loc_8B0C74B0:
	// lwz r6,0(r11)
	ctx.r6.u64 = REX_LOAD_U32(ctx.r11.u32 + 0);
	// addi r5,r1,-12
	ctx.r5.s64 = ctx.r1.s64 + -12;
	// lwz r4,4(r11)
	ctx.r4.u64 = REX_LOAD_U32(ctx.r11.u32 + 4);
	// addi r11,r11,8
	ctx.r11.s64 = ctx.r11.s64 + 8;
	// stwbrx r6,0,r8
	REX_STORE_U32(ctx.r8.u32, __builtin_bswap32(ctx.r6.u32));
	// lwz r6,-16(r1)
	ctx.r6.u64 = REX_LOAD_U32(ctx.r1.u32 + -16);
	// stwbrx r4,0,r5
	REX_STORE_U32(ctx.r5.u32, __builtin_bswap32(ctx.r4.u32));
	// xor r5,r6,r9
	ctx.r5.u64 = ctx.r6.u64 ^ ctx.r9.u64;
	// lwz r4,-12(r1)
	ctx.r4.u64 = REX_LOAD_U32(ctx.r1.u32 + -12);
	// rlwinm r9,r5,2,22,29
	ctx.r9.u64 = __builtin_rotateleft64(ctx.r5.u32 | (ctx.r5.u64 << 32), 2) & 0x3FC;
	// rlwinm r6,r5,24,8,31
	ctx.r6.u64 = __builtin_rotateleft64(ctx.r5.u32 | (ctx.r5.u64 << 32), 24) & 0xFFFFFF;
	// lwzx r5,r9,r10
	ctx.r5.u64 = REX_LOAD_U32(ctx.r9.u32 + ctx.r10.u32);
	// xor r9,r5,r6
	ctx.r9.u64 = ctx.r5.u64 ^ ctx.r6.u64;
	// rlwinm r6,r9,2,22,29
	ctx.r6.u64 = __builtin_rotateleft64(ctx.r9.u32 | (ctx.r9.u64 << 32), 2) & 0x3FC;
	// rlwinm r5,r9,24,8,31
	ctx.r5.u64 = __builtin_rotateleft64(ctx.r9.u32 | (ctx.r9.u64 << 32), 24) & 0xFFFFFF;
	// lwzx r9,r6,r10
	ctx.r9.u64 = REX_LOAD_U32(ctx.r6.u32 + ctx.r10.u32);
	// xor r6,r9,r5
	ctx.r6.u64 = ctx.r9.u64 ^ ctx.r5.u64;
	// rlwinm r5,r6,2,22,29
	ctx.r5.u64 = __builtin_rotateleft64(ctx.r6.u32 | (ctx.r6.u64 << 32), 2) & 0x3FC;
	// rlwinm r9,r6,24,8,31
	ctx.r9.u64 = __builtin_rotateleft64(ctx.r6.u32 | (ctx.r6.u64 << 32), 24) & 0xFFFFFF;
	// lwzx r6,r5,r10
	ctx.r6.u64 = REX_LOAD_U32(ctx.r5.u32 + ctx.r10.u32);
	// xor r5,r6,r9
	ctx.r5.u64 = ctx.r6.u64 ^ ctx.r9.u64;
	// rlwinm r9,r5,2,22,29
	ctx.r9.u64 = __builtin_rotateleft64(ctx.r5.u32 | (ctx.r5.u64 << 32), 2) & 0x3FC;
	// rlwinm r6,r5,24,8,31
	ctx.r6.u64 = __builtin_rotateleft64(ctx.r5.u32 | (ctx.r5.u64 << 32), 24) & 0xFFFFFF;
	// lwzx r5,r9,r10
	ctx.r5.u64 = REX_LOAD_U32(ctx.r9.u32 + ctx.r10.u32);
	// xor r9,r5,r6
	ctx.r9.u64 = ctx.r5.u64 ^ ctx.r6.u64;
	// xor r6,r9,r4
	ctx.r6.u64 = ctx.r9.u64 ^ ctx.r4.u64;
	// rlwinm r5,r6,2,22,29
	ctx.r5.u64 = __builtin_rotateleft64(ctx.r6.u32 | (ctx.r6.u64 << 32), 2) & 0x3FC;
	// rlwinm r4,r6,24,8,31
	ctx.r4.u64 = __builtin_rotateleft64(ctx.r6.u32 | (ctx.r6.u64 << 32), 24) & 0xFFFFFF;
	// lwzx r9,r5,r10
	ctx.r9.u64 = REX_LOAD_U32(ctx.r5.u32 + ctx.r10.u32);
	// xor r6,r9,r4
	ctx.r6.u64 = ctx.r9.u64 ^ ctx.r4.u64;
	// rlwinm r5,r6,2,22,29
	ctx.r5.u64 = __builtin_rotateleft64(ctx.r6.u32 | (ctx.r6.u64 << 32), 2) & 0x3FC;
	// rlwinm r4,r6,24,8,31
	ctx.r4.u64 = __builtin_rotateleft64(ctx.r6.u32 | (ctx.r6.u64 << 32), 24) & 0xFFFFFF;
	// lwzx r9,r5,r10
	ctx.r9.u64 = REX_LOAD_U32(ctx.r5.u32 + ctx.r10.u32);
	// xor r6,r9,r4
	ctx.r6.u64 = ctx.r9.u64 ^ ctx.r4.u64;
	// rlwinm r5,r6,2,22,29
	ctx.r5.u64 = __builtin_rotateleft64(ctx.r6.u32 | (ctx.r6.u64 << 32), 2) & 0x3FC;
	// rlwinm r4,r6,24,8,31
	ctx.r4.u64 = __builtin_rotateleft64(ctx.r6.u32 | (ctx.r6.u64 << 32), 24) & 0xFFFFFF;
	// lwzx r9,r5,r10
	ctx.r9.u64 = REX_LOAD_U32(ctx.r5.u32 + ctx.r10.u32);
	// xor r6,r9,r4
	ctx.r6.u64 = ctx.r9.u64 ^ ctx.r4.u64;
	// rlwinm r5,r6,2,22,29
	ctx.r5.u64 = __builtin_rotateleft64(ctx.r6.u32 | (ctx.r6.u64 << 32), 2) & 0x3FC;
	// rlwinm r4,r6,24,8,31
	ctx.r4.u64 = __builtin_rotateleft64(ctx.r6.u32 | (ctx.r6.u64 << 32), 24) & 0xFFFFFF;
	// lwzx r9,r5,r10
	ctx.r9.u64 = REX_LOAD_U32(ctx.r5.u32 + ctx.r10.u32);
	// xor r9,r9,r4
	ctx.r9.u64 = ctx.r9.u64 ^ ctx.r4.u64;
	// bdnz 0x8b0c74b0
	--ctx.ctr.u64;
	if (ctx.ctr.u32 != 0) goto loc_8B0C74B0;
loc_8B0C755C:
	// clrlwi r5,r7,29
	ctx.r5.u64 = ctx.r7.u32 & 0x7;
	// b 0x8b0c73f0
	goto loc_8B0C73F0;
loc_8B0C7564:
	// lbz r8,0(r11)
	ctx.r8.u64 = REX_LOAD_U8(ctx.r11.u32 + 0);
	// clrlwi r7,r9,24
	ctx.r7.u64 = ctx.r9.u32 & 0xFF;
	// rlwinm r6,r9,24,8,31
	ctx.r6.u64 = __builtin_rotateleft64(ctx.r9.u32 | (ctx.r9.u64 << 32), 24) & 0xFFFFFF;
	// xor r5,r7,r8
	ctx.r5.u64 = ctx.r7.u64 ^ ctx.r8.u64;
	// addi r11,r11,1
	ctx.r11.s64 = ctx.r11.s64 + 1;
	// rlwinm r4,r5,2,0,29
	ctx.r4.u64 = __builtin_rotateleft64(ctx.r5.u32 | (ctx.r5.u64 << 32), 2) & 0xFFFFFFFC;
	// lwzx r9,r4,r10
	ctx.r9.u64 = REX_LOAD_U32(ctx.r4.u32 + ctx.r10.u32);
	// xor r9,r9,r6
	ctx.r9.u64 = ctx.r9.u64 ^ ctx.r6.u64;
loc_8B0C7584:
	// lbz r8,0(r11)
	ctx.r8.u64 = REX_LOAD_U8(ctx.r11.u32 + 0);
	// clrlwi r7,r9,24
	ctx.r7.u64 = ctx.r9.u32 & 0xFF;
	// rlwinm r6,r9,24,8,31
	ctx.r6.u64 = __builtin_rotateleft64(ctx.r9.u32 | (ctx.r9.u64 << 32), 24) & 0xFFFFFF;
	// xor r5,r7,r8
	ctx.r5.u64 = ctx.r7.u64 ^ ctx.r8.u64;
	// addi r11,r11,1
	ctx.r11.s64 = ctx.r11.s64 + 1;
	// rlwinm r4,r5,2,0,29
	ctx.r4.u64 = __builtin_rotateleft64(ctx.r5.u32 | (ctx.r5.u64 << 32), 2) & 0xFFFFFFFC;
	// lwzx r9,r4,r10
	ctx.r9.u64 = REX_LOAD_U32(ctx.r4.u32 + ctx.r10.u32);
	// xor r9,r9,r6
	ctx.r9.u64 = ctx.r9.u64 ^ ctx.r6.u64;
loc_8B0C75A4:
	// lbz r8,0(r11)
	ctx.r8.u64 = REX_LOAD_U8(ctx.r11.u32 + 0);
	// clrlwi r7,r9,24
	ctx.r7.u64 = ctx.r9.u32 & 0xFF;
	// rlwinm r6,r9,24,8,31
	ctx.r6.u64 = __builtin_rotateleft64(ctx.r9.u32 | (ctx.r9.u64 << 32), 24) & 0xFFFFFF;
	// xor r5,r7,r8
	ctx.r5.u64 = ctx.r7.u64 ^ ctx.r8.u64;
	// addi r11,r11,1
	ctx.r11.s64 = ctx.r11.s64 + 1;
	// rlwinm r4,r5,2,0,29
	ctx.r4.u64 = __builtin_rotateleft64(ctx.r5.u32 | (ctx.r5.u64 << 32), 2) & 0xFFFFFFFC;
	// lwzx r9,r4,r10
	ctx.r9.u64 = REX_LOAD_U32(ctx.r4.u32 + ctx.r10.u32);
	// xor r9,r9,r6
	ctx.r9.u64 = ctx.r9.u64 ^ ctx.r6.u64;
loc_8B0C75C4:
	// lwz r11,0(r11)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r11.u32 + 0);
	// addi r8,r1,-12
	ctx.r8.s64 = ctx.r1.s64 + -12;
	// stwbrx r11,0,r8
	REX_STORE_U32(ctx.r8.u32, __builtin_bswap32(ctx.r11.u32));
	// lwz r7,-12(r1)
	ctx.r7.u64 = REX_LOAD_U32(ctx.r1.u32 + -12);
	// xor r6,r7,r9
	ctx.r6.u64 = ctx.r7.u64 ^ ctx.r9.u64;
	// rlwinm r5,r6,2,22,29
	ctx.r5.u64 = __builtin_rotateleft64(ctx.r6.u32 | (ctx.r6.u64 << 32), 2) & 0x3FC;
	// rlwinm r4,r6,24,8,31
	ctx.r4.u64 = __builtin_rotateleft64(ctx.r6.u32 | (ctx.r6.u64 << 32), 24) & 0xFFFFFF;
	// lwzx r11,r5,r10
	ctx.r11.u64 = REX_LOAD_U32(ctx.r5.u32 + ctx.r10.u32);
	// xor r9,r11,r4
	ctx.r9.u64 = ctx.r11.u64 ^ ctx.r4.u64;
	// rlwinm r8,r9,2,22,29
	ctx.r8.u64 = __builtin_rotateleft64(ctx.r9.u32 | (ctx.r9.u64 << 32), 2) & 0x3FC;
	// rlwinm r7,r9,24,8,31
	ctx.r7.u64 = __builtin_rotateleft64(ctx.r9.u32 | (ctx.r9.u64 << 32), 24) & 0xFFFFFF;
	// lwzx r6,r8,r10
	ctx.r6.u64 = REX_LOAD_U32(ctx.r8.u32 + ctx.r10.u32);
	// xor r5,r6,r7
	ctx.r5.u64 = ctx.r6.u64 ^ ctx.r7.u64;
	// rlwinm r4,r5,2,22,29
	ctx.r4.u64 = __builtin_rotateleft64(ctx.r5.u32 | (ctx.r5.u64 << 32), 2) & 0x3FC;
	// rlwinm r11,r5,24,8,31
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r5.u32 | (ctx.r5.u64 << 32), 24) & 0xFFFFFF;
	// lwzx r9,r4,r10
	ctx.r9.u64 = REX_LOAD_U32(ctx.r4.u32 + ctx.r10.u32);
	// xor r8,r9,r11
	ctx.r8.u64 = ctx.r9.u64 ^ ctx.r11.u64;
	// rlwinm r7,r8,2,22,29
	ctx.r7.u64 = __builtin_rotateleft64(ctx.r8.u32 | (ctx.r8.u64 << 32), 2) & 0x3FC;
	// rlwinm r6,r8,24,8,31
	ctx.r6.u64 = __builtin_rotateleft64(ctx.r8.u32 | (ctx.r8.u64 << 32), 24) & 0xFFFFFF;
	// lwzx r5,r7,r10
	ctx.r5.u64 = REX_LOAD_U32(ctx.r7.u32 + ctx.r10.u32);
	// xor r4,r5,r6
	ctx.r4.u64 = ctx.r5.u64 ^ ctx.r6.u64;
	// stw r4,0(r3)
	REX_STORE_U32(ctx.r3.u32 + 0, ctx.r4.u32);
	// blr 
	return;
loc_8B0C7620:
	// lbz r8,0(r11)
	ctx.r8.u64 = REX_LOAD_U8(ctx.r11.u32 + 0);
	// clrlwi r7,r9,24
	ctx.r7.u64 = ctx.r9.u32 & 0xFF;
	// rlwinm r6,r9,24,8,31
	ctx.r6.u64 = __builtin_rotateleft64(ctx.r9.u32 | (ctx.r9.u64 << 32), 24) & 0xFFFFFF;
	// xor r5,r7,r8
	ctx.r5.u64 = ctx.r7.u64 ^ ctx.r8.u64;
	// addi r11,r11,1
	ctx.r11.s64 = ctx.r11.s64 + 1;
	// rlwinm r4,r5,2,0,29
	ctx.r4.u64 = __builtin_rotateleft64(ctx.r5.u32 | (ctx.r5.u64 << 32), 2) & 0xFFFFFFFC;
	// lwzx r9,r4,r10
	ctx.r9.u64 = REX_LOAD_U32(ctx.r4.u32 + ctx.r10.u32);
	// xor r9,r9,r6
	ctx.r9.u64 = ctx.r9.u64 ^ ctx.r6.u64;
loc_8B0C7640:
	// lbz r8,0(r11)
	ctx.r8.u64 = REX_LOAD_U8(ctx.r11.u32 + 0);
	// clrlwi r7,r9,24
	ctx.r7.u64 = ctx.r9.u32 & 0xFF;
	// rlwinm r6,r9,24,8,31
	ctx.r6.u64 = __builtin_rotateleft64(ctx.r9.u32 | (ctx.r9.u64 << 32), 24) & 0xFFFFFF;
	// xor r5,r7,r8
	ctx.r5.u64 = ctx.r7.u64 ^ ctx.r8.u64;
	// addi r11,r11,1
	ctx.r11.s64 = ctx.r11.s64 + 1;
	// rlwinm r4,r5,2,0,29
	ctx.r4.u64 = __builtin_rotateleft64(ctx.r5.u32 | (ctx.r5.u64 << 32), 2) & 0xFFFFFFFC;
	// lwzx r9,r4,r10
	ctx.r9.u64 = REX_LOAD_U32(ctx.r4.u32 + ctx.r10.u32);
	// xor r9,r9,r6
	ctx.r9.u64 = ctx.r9.u64 ^ ctx.r6.u64;
loc_8B0C7660:
	// lbz r11,0(r11)
	ctx.r11.u64 = REX_LOAD_U8(ctx.r11.u32 + 0);
	// clrlwi r8,r9,24
	ctx.r8.u64 = ctx.r9.u32 & 0xFF;
	// rlwinm r7,r9,24,8,31
	ctx.r7.u64 = __builtin_rotateleft64(ctx.r9.u32 | (ctx.r9.u64 << 32), 24) & 0xFFFFFF;
	// xor r6,r8,r11
	ctx.r6.u64 = ctx.r8.u64 ^ ctx.r11.u64;
	// rlwinm r5,r6,2,0,29
	ctx.r5.u64 = __builtin_rotateleft64(ctx.r6.u32 | (ctx.r6.u64 << 32), 2) & 0xFFFFFFFC;
	// lwzx r4,r5,r10
	ctx.r4.u64 = REX_LOAD_U32(ctx.r5.u32 + ctx.r10.u32);
	// xor r9,r4,r7
	ctx.r9.u64 = ctx.r4.u64 ^ ctx.r7.u64;
loc_8B0C767C:
	// stw r9,0(r3)
	REX_STORE_U32(ctx.r3.u32 + 0, ctx.r9.u32);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0C81C0) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9bc
	ctx.lr = 0x8B0C81C8;
	__savegprlr_29(ctx, base);
	// stwu r1,-112(r1)
	ea = -112 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// mr r29,r4
	ctx.r29.u64 = ctx.r4.u64;
	// mr r4,r5
	ctx.r4.u64 = ctx.r5.u64;
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// mr r30,r5
	ctx.r30.u64 = ctx.r5.u64;
	// bl 0x8b0c7a58
	ctx.lr = 0x8B0C81E0;
	sub_8B0C7A58(ctx, base);
	// clrlwi r11,r3,24
	ctx.r11.u64 = ctx.r3.u32 & 0xFF;
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// beq cr6,0x8b0c8218
	if (ctx.cr6.eq) goto loc_8B0C8218;
	// lwz r11,12(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 12);
	// mr r5,r30
	ctx.r5.u64 = ctx.r30.u64;
	// lwz r9,32(r31)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r31.u32 + 32);
	// mr r3,r29
	ctx.r3.u64 = ctx.r29.u64;
	// lwz r10,0(r31)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r31.u32 + 0);
	// subf r11,r9,r11
	ctx.r11.u64 = ctx.r11.u64 - ctx.r9.u64;
	// add r4,r11,r10
	ctx.r4.u64 = ctx.r11.u64 + ctx.r10.u64;
	// bl 0x8b0cbb30
	ctx.lr = 0x8B0C820C;
	sub_8B0CBB30(ctx, base);
	// lwz r11,12(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 12);
	// add r8,r11,r30
	ctx.r8.u64 = ctx.r11.u64 + ctx.r30.u64;
	// stw r8,12(r31)
	REX_STORE_U32(ctx.r31.u32 + 12, ctx.r8.u32);
loc_8B0C8218:
	// addi r1,r1,112
	ctx.r1.s64 = ctx.r1.s64 + 112;
	// b 0x8b0cba0c
	__restgprlr_29(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0C82C0) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// std r30,-24(r1)
	REX_STORE_U64(ctx.r1.u32 + -24, ctx.r30.u64);
	// std r31,-16(r1)
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.r31.u64);
	// stwu r1,-112(r1)
	ea = -112 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lbz r11,21(r3)
	ctx.r11.u64 = REX_LOAD_U8(ctx.r3.u32 + 21);
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// mr r30,r4
	ctx.r30.u64 = ctx.r4.u64;
	// clrlwi r10,r11,31
	ctx.r10.u64 = ctx.r11.u32 & 0x1;
	// cmplwi cr6,r10,0
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 0, ctx.xer);
	// beq cr6,0x8b0c836c
	if (ctx.cr6.eq) goto loc_8B0C836C;
	// lbz r11,20(r3)
	ctx.r11.u64 = REX_LOAD_U8(ctx.r3.u32 + 20);
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// bne cr6,0x8b0c836c
	if (!ctx.cr6.eq) goto loc_8B0C836C;
loc_8B0C82F8:
	// lbz r11,20(r31)
	ctx.r11.u64 = REX_LOAD_U8(ctx.r31.u32 + 20);
	// rlwinm r10,r11,0,30,30
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 0) & 0x2;
	// cmplwi cr6,r10,0
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 0, ctx.xer);
	// beq cr6,0x8b0c8310
	if (ctx.cr6.eq) goto loc_8B0C8310;
	// li r3,0
	ctx.r3.s64 = 0;
	// b 0x8b0c832c
	goto loc_8B0C832C;
loc_8B0C8310:
	// addi r4,r30,1
	ctx.r4.s64 = ctx.r30.s64 + 1;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0c7a58
	ctx.lr = 0x8B0C831C;
	sub_8B0C7A58(ctx, base);
	// lbz r11,20(r31)
	ctx.r11.u64 = REX_LOAD_U8(ctx.r31.u32 + 20);
	// clrlwi r10,r11,24
	ctx.r10.u64 = ctx.r11.u32 & 0xFF;
	// rlwinm r10,r10,0,31,29
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r10.u32 | (ctx.r10.u64 << 32), 0) & 0xFFFFFFFFFFFFFFFD;
	// stb r10,20(r31)
	REX_STORE_U8(ctx.r31.u32 + 20, ctx.r10.u8);
loc_8B0C832C:
	// clrlwi r11,r3,24
	ctx.r11.u64 = ctx.r3.u32 & 0xFF;
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// beq cr6,0x8b0c8364
	if (ctx.cr6.eq) goto loc_8B0C8364;
	// lwz r11,12(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 12);
	// lwz r9,32(r31)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r31.u32 + 32);
	// lwz r10,0(r31)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r31.u32 + 0);
	// subf r11,r9,r11
	ctx.r11.u64 = ctx.r11.u64 - ctx.r9.u64;
	// add r11,r11,r10
	ctx.r11.u64 = ctx.r11.u64 + ctx.r10.u64;
	// lbzx r3,r11,r30
	ctx.r3.u64 = REX_LOAD_U8(ctx.r11.u32 + ctx.r30.u32);
	// bl 0x8b0cc470
	ctx.lr = 0x8B0C8354;
	sub_8B0CC470(ctx, base);
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// beq cr6,0x8b0c8364
	if (ctx.cr6.eq) goto loc_8B0C8364;
	// addi r30,r30,1
	ctx.r30.s64 = ctx.r30.s64 + 1;
	// b 0x8b0c82f8
	goto loc_8B0C82F8;
loc_8B0C8364:
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// b 0x8b0c8370
	goto loc_8B0C8370;
loc_8B0C836C:
	// li r3,0
	ctx.r3.s64 = 0;
loc_8B0C8370:
	// addi r1,r1,112
	ctx.r1.s64 = ctx.r1.s64 + 112;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// ld r30,-24(r1)
	ctx.r30.u64 = REX_LOAD_U64(ctx.r1.u32 + -24);
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0C8798) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9bc
	ctx.lr = 0x8B0C87A0;
	__savegprlr_29(ctx, base);
	// stwu r1,-112(r1)
	ea = -112 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lbz r11,21(r3)
	ctx.r11.u64 = REX_LOAD_U8(ctx.r3.u32 + 21);
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// rlwinm r10,r11,0,27,27
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 0) & 0x10;
	// li r11,0
	ctx.r11.s64 = 0;
	// cmplwi cr6,r10,0
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 0, ctx.xer);
	// bne cr6,0x8b0c87c0
	if (!ctx.cr6.eq) goto loc_8B0C87C0;
	// lwz r11,24(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 24);
loc_8B0C87C0:
	// addic. r29,r11,-1
	ctx.xer.ca = ctx.r11.u32 > 0;
	ctx.r29.s64 = ctx.r11.s64 + -1;
	ctx.cr0.compare<int32_t>(ctx.r29.s32, 0, ctx.xer);
	// blt 0x8b0c8814
	if (ctx.cr0.lt) goto loc_8B0C8814;
	// li r30,9
	ctx.r30.s64 = 9;
loc_8B0C87CC:
	// li r4,1
	ctx.r4.s64 = 1;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0c7d98
	ctx.lr = 0x8B0C87D8;
	sub_8B0C7D98(ctx, base);
	// clrlwi r11,r3,24
	ctx.r11.u64 = ctx.r3.u32 & 0xFF;
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// beq cr6,0x8b0c880c
	if (ctx.cr6.eq) goto loc_8B0C880C;
	// lwz r11,0(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 0);
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// lwz r10,32(r31)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r31.u32 + 32);
	// lwz r9,16(r31)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r31.u32 + 16);
	// subf r8,r10,r11
	ctx.r8.u64 = ctx.r11.u64 - ctx.r10.u64;
	// stbx r30,r8,r9
	REX_STORE_U8(ctx.r8.u32 + ctx.r9.u32, ctx.r30.u8);
	// lwz r11,16(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 16);
	// addi r7,r11,1
	ctx.r7.s64 = ctx.r11.s64 + 1;
	// stw r7,16(r31)
	REX_STORE_U32(ctx.r31.u32 + 16, ctx.r7.u32);
	// bl 0x8b0c7e48
	ctx.lr = 0x8B0C880C;
	sub_8B0C7E48(ctx, base);
loc_8B0C880C:
	// addic. r29,r29,-1
	ctx.xer.ca = ctx.r29.u32 > 0;
	ctx.r29.s64 = ctx.r29.s64 + -1;
	ctx.cr0.compare<int32_t>(ctx.r29.s32, 0, ctx.xer);
	// bge 0x8b0c87cc
	if (!ctx.cr0.lt) goto loc_8B0C87CC;
loc_8B0C8814:
	// addi r1,r1,112
	ctx.r1.s64 = ctx.r1.s64 + 112;
	// b 0x8b0cba0c
	__restgprlr_29(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0C89D0) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9b8
	ctx.lr = 0x8B0C89D8;
	__savegprlr_28(ctx, base);
	// stwu r1,-128(r1)
	ea = -128 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lbz r11,21(r3)
	ctx.r11.u64 = REX_LOAD_U8(ctx.r3.u32 + 21);
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// mr r30,r4
	ctx.r30.u64 = ctx.r4.u64;
	// clrlwi r10,r11,31
	ctx.r10.u64 = ctx.r11.u32 & 0x1;
	// cmplwi cr6,r10,0
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 0, ctx.xer);
	// bne cr6,0x8b0c8a48
	if (!ctx.cr6.eq) goto loc_8B0C8A48;
	// cmplwi cr6,r4,0
	ctx.cr6.compare<uint32_t>(ctx.r4.u32, 0, ctx.xer);
	// beq cr6,0x8b0c8a34
	if (ctx.cr6.eq) goto loc_8B0C8A34;
	// mr r11,r4
	ctx.r11.u64 = ctx.r4.u64;
loc_8B0C8A00:
	// lbz r10,0(r11)
	ctx.r10.u64 = REX_LOAD_U8(ctx.r11.u32 + 0);
	// addi r11,r11,1
	ctx.r11.s64 = ctx.r11.s64 + 1;
	// cmplwi cr6,r10,0
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 0, ctx.xer);
	// bne cr6,0x8b0c8a00
	if (!ctx.cr6.eq) goto loc_8B0C8A00;
	// subf r11,r30,r11
	ctx.r11.u64 = ctx.r11.u64 - ctx.r30.u64;
	// mr r4,r30
	ctx.r4.u64 = ctx.r30.u64;
	// addi r11,r11,-1
	ctx.r11.s64 = ctx.r11.s64 + -1;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// rotlwi r11,r11,0
	ctx.r11.u64 = __builtin_rotateleft32(ctx.r11.u32, 0);
	// addi r5,r11,1
	ctx.r5.s64 = ctx.r11.s64 + 1;
	// bl 0x8b0c8588
	ctx.lr = 0x8B0C8A2C;
	sub_8B0C8588(ctx, base);
	// addi r1,r1,128
	ctx.r1.s64 = ctx.r1.s64 + 128;
	// b 0x8b0cba08
	__restgprlr_28(ctx, base);
	return;
loc_8B0C8A34:
	// li r4,0
	ctx.r4.s64 = 0;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0c8728
	ctx.lr = 0x8B0C8A40;
	sub_8B0C8728(ctx, base);
	// addi r1,r1,128
	ctx.r1.s64 = ctx.r1.s64 + 128;
	// b 0x8b0cba08
	__restgprlr_28(ctx, base);
	return;
loc_8B0C8A48:
	// cmplwi cr6,r30,0
	ctx.cr6.compare<uint32_t>(ctx.r30.u32, 0, ctx.xer);
	// beq cr6,0x8b0c8b58
	if (ctx.cr6.eq) goto loc_8B0C8B58;
	// rlwinm r11,r11,0,27,27
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 0) & 0x10;
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// bne cr6,0x8b0c8b24
	if (!ctx.cr6.eq) goto loc_8B0C8B24;
	// lwz r11,24(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 24);
	// cmpwi cr6,r11,0
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// ble cr6,0x8b0c8b24
	if (!ctx.cr6.gt) goto loc_8B0C8B24;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0c7a00
	ctx.lr = 0x8B0C8A70;
	sub_8B0C7A00(ctx, base);
	// clrlwi r11,r3,24
	ctx.r11.u64 = ctx.r3.u32 & 0xFF;
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// beq cr6,0x8b0c8a84
	if (ctx.cr6.eq) goto loc_8B0C8A84;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0c8798
	ctx.lr = 0x8B0C8A84;
	sub_8B0C8798(ctx, base);
loc_8B0C8A84:
	// li r4,10
	ctx.r4.s64 = 10;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// bl 0x8b0ccee0
	ctx.lr = 0x8B0C8A90;
	sub_8B0CCEE0(ctx, base);
	// mr r28,r3
	ctx.r28.u64 = ctx.r3.u64;
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0c8b24
	if (ctx.cr6.eq) goto loc_8B0C8B24;
loc_8B0C8A9C:
	// subf r11,r30,r28
	ctx.r11.u64 = ctx.r28.u64 - ctx.r30.u64;
	// addic. r29,r11,1
	ctx.xer.ca = ctx.r11.u32 > 4294967294;
	ctx.r29.s64 = ctx.r11.s64 + 1;
	ctx.cr0.compare<int32_t>(ctx.r29.s32, 0, ctx.xer);
	// beq 0x8b0c8af4
	if (ctx.cr0.eq) goto loc_8B0C8AF4;
	// mr r4,r29
	ctx.r4.u64 = ctx.r29.u64;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0c7d98
	ctx.lr = 0x8B0C8AB4;
	sub_8B0C7D98(ctx, base);
	// clrlwi r11,r3,24
	ctx.r11.u64 = ctx.r3.u32 & 0xFF;
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// beq cr6,0x8b0c8af4
	if (ctx.cr6.eq) goto loc_8B0C8AF4;
	// lwz r11,16(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 16);
	// mr r5,r29
	ctx.r5.u64 = ctx.r29.u64;
	// lwz r9,32(r31)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r31.u32 + 32);
	// mr r4,r30
	ctx.r4.u64 = ctx.r30.u64;
	// lwz r10,0(r31)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r31.u32 + 0);
	// subf r11,r9,r11
	ctx.r11.u64 = ctx.r11.u64 - ctx.r9.u64;
	// add r3,r11,r10
	ctx.r3.u64 = ctx.r11.u64 + ctx.r10.u64;
	// bl 0x8b0cbb30
	ctx.lr = 0x8B0C8AE0;
	sub_8B0CBB30(ctx, base);
	// lwz r11,16(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 16);
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// add r8,r11,r29
	ctx.r8.u64 = ctx.r11.u64 + ctx.r29.u64;
	// stw r8,16(r31)
	REX_STORE_U32(ctx.r31.u32 + 16, ctx.r8.u32);
	// bl 0x8b0c7e48
	ctx.lr = 0x8B0C8AF4;
	sub_8B0C7E48(ctx, base);
loc_8B0C8AF4:
	// lbz r11,1(r28)
	ctx.r11.u64 = REX_LOAD_U8(ctx.r28.u32 + 1);
	// addi r30,r28,1
	ctx.r30.s64 = ctx.r28.s64 + 1;
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// beq cr6,0x8b0c8b24
	if (ctx.cr6.eq) goto loc_8B0C8B24;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0c8798
	ctx.lr = 0x8B0C8B0C;
	sub_8B0C8798(ctx, base);
	// li r4,10
	ctx.r4.s64 = 10;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// bl 0x8b0ccee0
	ctx.lr = 0x8B0C8B18;
	sub_8B0CCEE0(ctx, base);
	// mr r28,r3
	ctx.r28.u64 = ctx.r3.u64;
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// bne cr6,0x8b0c8a9c
	if (!ctx.cr6.eq) goto loc_8B0C8A9C;
loc_8B0C8B24:
	// mr r11,r30
	ctx.r11.u64 = ctx.r30.u64;
loc_8B0C8B28:
	// lbz r10,0(r11)
	ctx.r10.u64 = REX_LOAD_U8(ctx.r11.u32 + 0);
	// addi r11,r11,1
	ctx.r11.s64 = ctx.r11.s64 + 1;
	// cmplwi cr6,r10,0
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 0, ctx.xer);
	// bne cr6,0x8b0c8b28
	if (!ctx.cr6.eq) goto loc_8B0C8B28;
	// subf r11,r30,r11
	ctx.r11.u64 = ctx.r11.u64 - ctx.r30.u64;
	// addi r11,r11,-1
	ctx.r11.s64 = ctx.r11.s64 + -1;
	// rotlwi r5,r11,0
	ctx.r5.u64 = __builtin_rotateleft32(ctx.r11.u32, 0);
	// cmplwi cr6,r5,0
	ctx.cr6.compare<uint32_t>(ctx.r5.u32, 0, ctx.xer);
	// beq cr6,0x8b0c8b58
	if (ctx.cr6.eq) goto loc_8B0C8B58;
	// mr r4,r30
	ctx.r4.u64 = ctx.r30.u64;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0c8588
	ctx.lr = 0x8B0C8B58;
	sub_8B0C8588(ctx, base);
loc_8B0C8B58:
	// addi r1,r1,128
	ctx.r1.s64 = ctx.r1.s64 + 128;
	// b 0x8b0cba08
	__restgprlr_28(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0C95A8) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// std r5,32(r1)
	REX_STORE_U64(ctx.r1.u32 + 32, ctx.r5.u64);
	// std r6,40(r1)
	REX_STORE_U64(ctx.r1.u32 + 40, ctx.r6.u64);
	// std r7,48(r1)
	REX_STORE_U64(ctx.r1.u32 + 48, ctx.r7.u64);
	// std r8,56(r1)
	REX_STORE_U64(ctx.r1.u32 + 56, ctx.r8.u64);
	// std r9,64(r1)
	REX_STORE_U64(ctx.r1.u32 + 64, ctx.r9.u64);
	// std r10,72(r1)
	REX_STORE_U64(ctx.r1.u32 + 72, ctx.r10.u64);
	// stwu r1,-96(r1)
	ea = -96 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// addi r11,r1,80
	ctx.r11.s64 = ctx.r1.s64 + 80;
	// addi r10,r1,128
	ctx.r10.s64 = ctx.r1.s64 + 128;
	// stw r10,0(r11)
	REX_STORE_U32(ctx.r11.u32 + 0, ctx.r10.u32);
	// lwz r5,80(r1)
	ctx.r5.u64 = REX_LOAD_U32(ctx.r1.u32 + 80);
	// bl 0x8b0c9130
	ctx.lr = 0x8B0C95E0;
	sub_8B0C9130(ctx, base);
	// addi r1,r1,96
	ctx.r1.s64 = ctx.r1.s64 + 96;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0C97B8) {
	REX_FUNC_PROLOGUE();
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9a8
	ctx.lr = 0x8B0C97C0;
	__savegprlr_24(ctx, base);
	// li r30,0
	ctx.r30.s64 = 0;
	// lis r11,-29943
	ctx.r11.s64 = -1962344448;
	// mr r26,r30
	ctx.r26.u64 = ctx.r30.u64;
	// mr r29,r30
	ctx.r29.u64 = ctx.r30.u64;
	// li r27,32
	ctx.r27.s64 = 32;
	// li r31,1
	ctx.r31.s64 = 1;
	// addi r28,r11,-25896
	ctx.r28.s64 = ctx.r11.s64 + -25896;
loc_8B0C97DC:
	// lwz r11,20(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 20);
	// cmpwi cr6,r11,8
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 8, ctx.xer);
	// blt cr6,0x8b0c9870
	if (ctx.cr6.lt) goto loc_8B0C9870;
	// addic. r11,r11,-8
	ctx.xer.ca = ctx.r11.u32 > 7;
	ctx.r11.s64 = ctx.r11.s64 + -8;
	ctx.cr0.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// stw r11,20(r3)
	REX_STORE_U32(ctx.r3.u32 + 20, ctx.r11.u32);
	// lwz r11,16(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 16);
	// clrlwi r9,r11,24
	ctx.r9.u64 = ctx.r11.u32 & 0xFF;
	// beq 0x8b0c980c
	if (ctx.cr0.eq) goto loc_8B0C980C;
	// rlwinm r11,r11,24,8,31
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 24) & 0xFFFFFF;
	// stw r11,16(r3)
	REX_STORE_U32(ctx.r3.u32 + 16, ctx.r11.u32);
	// mr r11,r9
	ctx.r11.u64 = ctx.r9.u64;
	// b 0x8b0c9904
	goto loc_8B0C9904;
loc_8B0C980C:
	// lwz r10,28(r3)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r3.u32 + 28);
	// lwz r11,24(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 24);
	// stw r27,20(r3)
	REX_STORE_U32(ctx.r3.u32 + 20, ctx.r27.u32);
	// cmplw cr6,r11,r10
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, ctx.r10.u32, ctx.xer);
	// bne cr6,0x8b0c9838
	if (!ctx.cr6.eq) goto loc_8B0C9838;
	// addi r11,r11,4
	ctx.r11.s64 = ctx.r11.s64 + 4;
	// stw r31,20(r3)
	REX_STORE_U32(ctx.r3.u32 + 20, ctx.r31.u32);
	// stw r30,16(r3)
	REX_STORE_U32(ctx.r3.u32 + 16, ctx.r30.u32);
	// stw r11,24(r3)
	REX_STORE_U32(ctx.r3.u32 + 24, ctx.r11.u32);
	// mr r11,r9
	ctx.r11.u64 = ctx.r9.u64;
	// b 0x8b0c9904
	goto loc_8B0C9904;
loc_8B0C9838:
	// ble cr6,0x8b0c984c
	if (!ctx.cr6.gt) goto loc_8B0C984C;
	// stb r31,4(r3)
	REX_STORE_U8(ctx.r3.u32 + 4, ctx.r31.u8);
	// mr r11,r9
	ctx.r11.u64 = ctx.r9.u64;
	// stw r30,16(r3)
	REX_STORE_U32(ctx.r3.u32 + 16, ctx.r30.u32);
	// b 0x8b0c9904
	goto loc_8B0C9904;
loc_8B0C984C:
	// lwz r10,0(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 0);
	// addi r8,r1,-80
	ctx.r8.s64 = ctx.r1.s64 + -80;
	// addi r11,r11,4
	ctx.r11.s64 = ctx.r11.s64 + 4;
	// stw r11,24(r3)
	REX_STORE_U32(ctx.r3.u32 + 24, ctx.r11.u32);
	// mr r11,r9
	ctx.r11.u64 = ctx.r9.u64;
	// stwbrx r10,0,r8
	REX_STORE_U32(ctx.r8.u32, __builtin_bswap32(ctx.r10.u32));
	// lwz r10,-80(r1)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r1.u32 + -80);
	// stw r10,16(r3)
	REX_STORE_U32(ctx.r3.u32 + 16, ctx.r10.u32);
	// b 0x8b0c9904
	goto loc_8B0C9904;
loc_8B0C9870:
	// subfic r9,r11,8
	ctx.xer.ca = ctx.r11.u32 <= 8;
	ctx.r9.u64 = static_cast<uint64_t>(8) - ctx.r11.u64;
	// lwz r10,28(r3)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r3.u32 + 28);
	// lwz r11,24(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 24);
	// lwz r8,16(r3)
	ctx.r8.u64 = REX_LOAD_U32(ctx.r3.u32 + 16);
	// cmplw cr6,r11,r10
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, ctx.r10.u32, ctx.xer);
	// bne cr6,0x8b0c9898
	if (!ctx.cr6.eq) goto loc_8B0C9898;
	// stw r31,20(r3)
	REX_STORE_U32(ctx.r3.u32 + 20, ctx.r31.u32);
	// stw r30,16(r3)
	REX_STORE_U32(ctx.r3.u32 + 16, ctx.r30.u32);
	// stb r31,4(r3)
	REX_STORE_U8(ctx.r3.u32 + 4, ctx.r31.u8);
	// b 0x8b0c98bc
	goto loc_8B0C98BC;
loc_8B0C9898:
	// ble cr6,0x8b0c98a8
	if (!ctx.cr6.gt) goto loc_8B0C98A8;
	// stb r31,4(r3)
	REX_STORE_U8(ctx.r3.u32 + 4, ctx.r31.u8);
	// stw r30,16(r3)
	REX_STORE_U32(ctx.r3.u32 + 16, ctx.r30.u32);
	// b 0x8b0c98c4
	goto loc_8B0C98C4;
loc_8B0C98A8:
	// lwz r10,0(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 0);
	// addi r25,r1,-76
	ctx.r25.s64 = ctx.r1.s64 + -76;
	// stwbrx r10,0,r25
	REX_STORE_U32(ctx.r25.u32, __builtin_bswap32(ctx.r10.u32));
	// lwz r10,-76(r1)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r1.u32 + -76);
	// stw r10,16(r3)
	REX_STORE_U32(ctx.r3.u32 + 16, ctx.r10.u32);
loc_8B0C98BC:
	// addi r11,r11,4
	ctx.r11.s64 = ctx.r11.s64 + 4;
	// stw r11,24(r3)
	REX_STORE_U32(ctx.r3.u32 + 24, ctx.r11.u32);
loc_8B0C98C4:
	// lbz r11,4(r3)
	ctx.r11.u64 = REX_LOAD_U8(ctx.r3.u32 + 4);
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// beq cr6,0x8b0c98d8
	if (ctx.cr6.eq) goto loc_8B0C98D8;
	// mr r11,r30
	ctx.r11.u64 = ctx.r30.u64;
	// b 0x8b0c9904
	goto loc_8B0C9904;
loc_8B0C98D8:
	// rlwinm r11,r9,2,0,29
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r9.u32 | (ctx.r9.u64 << 32), 2) & 0xFFFFFFFC;
	// lwz r10,16(r3)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r3.u32 + 16);
	// subfic r24,r9,32
	ctx.xer.ca = ctx.r9.u32 <= 32;
	ctx.r24.u64 = static_cast<uint64_t>(32) - ctx.r9.u64;
	// lwz r25,20(r3)
	ctx.r25.u64 = REX_LOAD_U32(ctx.r3.u32 + 20);
	// srw r9,r10,r9
	ctx.r9.u64 = ctx.r9.u8 & 0x20 ? 0 : (ctx.r10.u32 >> (ctx.r9.u8 & 0x3F));
	// lwzx r11,r11,r28
	ctx.r11.u64 = REX_LOAD_U32(ctx.r11.u32 + ctx.r28.u32);
	// stw r9,16(r3)
	REX_STORE_U32(ctx.r3.u32 + 16, ctx.r9.u32);
	// and r10,r11,r10
	ctx.r10.u64 = ctx.r11.u64 & ctx.r10.u64;
	// stw r24,20(r3)
	REX_STORE_U32(ctx.r3.u32 + 20, ctx.r24.u32);
	// slw r9,r10,r25
	ctx.r9.u64 = ctx.r25.u8 & 0x20 ? 0 : (ctx.r10.u32 << (ctx.r25.u8 & 0x3F));
	// or r11,r9,r8
	ctx.r11.u64 = ctx.r9.u64 | ctx.r8.u64;
loc_8B0C9904:
	// extsb r10,r11
	ctx.r10.s64 = ctx.r11.s8;
	// mr r11,r10
	ctx.r11.u64 = ctx.r10.u64;
	// cmpwi cr6,r10,0
	ctx.cr6.compare<int32_t>(ctx.r10.s32, 0, ctx.xer);
	// beq cr6,0x8b0c9948
	if (ctx.cr6.eq) goto loc_8B0C9948;
	// clrlwi r9,r6,24
	ctx.r9.u64 = ctx.r6.u32 & 0xFF;
	// cmplwi cr6,r9,0
	ctx.cr6.compare<uint32_t>(ctx.r9.u32, 0, ctx.xer);
	// beq cr6,0x8b0c9928
	if (ctx.cr6.eq) goto loc_8B0C9928;
	// cmpwi cr6,r10,10
	ctx.cr6.compare<int32_t>(ctx.r10.s32, 10, ctx.xer);
	// beq cr6,0x8b0c9948
	if (ctx.cr6.eq) goto loc_8B0C9948;
loc_8B0C9928:
	// addi r11,r5,-1
	ctx.r11.s64 = ctx.r5.s64 + -1;
	// cmpw cr6,r29,r11
	ctx.cr6.compare<int32_t>(ctx.r29.s32, ctx.r11.s32, ctx.xer);
	// bge cr6,0x8b0c9940
	if (!ctx.cr6.lt) goto loc_8B0C9940;
	// stbx r10,r29,r4
	REX_STORE_U8(ctx.r29.u32 + ctx.r4.u32, ctx.r10.u8);
	// addi r29,r29,1
	ctx.r29.s64 = ctx.r29.s64 + 1;
	// b 0x8b0c97dc
	goto loc_8B0C97DC;
loc_8B0C9940:
	// mr r26,r31
	ctx.r26.u64 = ctx.r31.u64;
	// b 0x8b0c97dc
	goto loc_8B0C97DC;
loc_8B0C9948:
	// cmplwi cr6,r7,0
	ctx.cr6.compare<uint32_t>(ctx.r7.u32, 0, ctx.xer);
	// stbx r30,r29,r4
	REX_STORE_U8(ctx.r29.u32 + ctx.r4.u32, ctx.r30.u8);
	// beq cr6,0x8b0c9958
	if (ctx.cr6.eq) goto loc_8B0C9958;
	// stw r29,0(r7)
	REX_STORE_U32(ctx.r7.u32 + 0, ctx.r29.u32);
loc_8B0C9958:
	// lbz r11,4(r3)
	ctx.r11.u64 = REX_LOAD_U8(ctx.r3.u32 + 4);
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// bne cr6,0x8b0c9974
	if (!ctx.cr6.eq) goto loc_8B0C9974;
	// clrlwi r11,r26,24
	ctx.r11.u64 = ctx.r26.u32 & 0xFF;
	// clrlwi r3,r31,24
	ctx.r3.u64 = ctx.r31.u32 & 0xFF;
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// beq cr6,0x8b0c9978
	if (ctx.cr6.eq) goto loc_8B0C9978;
loc_8B0C9974:
	// clrlwi r3,r30,24
	ctx.r3.u64 = ctx.r30.u32 & 0xFF;
loc_8B0C9978:
	// b 0x8b0cb9f8
	__restgprlr_24(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0CA028) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9b4
	ctx.lr = 0x8B0CA030;
	__savegprlr_27(ctx, base);
	// stwu r1,-144(r1)
	ea = -144 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lwz r11,12(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 12);
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// lwz r10,8(r3)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r3.u32 + 8);
	// mr r30,r4
	ctx.r30.u64 = ctx.r4.u64;
	// add r9,r5,r11
	ctx.r9.u64 = ctx.r5.u64 + ctx.r11.u64;
	// mr r29,r5
	ctx.r29.u64 = ctx.r5.u64;
	// cmpw cr6,r9,r10
	ctx.cr6.compare<int32_t>(ctx.r9.s32, ctx.r10.s32, ctx.xer);
	// ble cr6,0x8b0ca068
	if (!ctx.cr6.gt) goto loc_8B0CA068;
	// li r11,1
	ctx.r11.s64 = 1;
	// li r3,0
	ctx.r3.s64 = 0;
	// stb r11,16(r31)
	REX_STORE_U8(ctx.r31.u32 + 16, ctx.r11.u8);
	// addi r1,r1,144
	ctx.r1.s64 = ctx.r1.s64 + 144;
	// b 0x8b0cba04
	__restgprlr_27(ctx, base);
	return;
loc_8B0CA068:
	// clrlwi r11,r4,30
	ctx.r11.u64 = ctx.r4.u32 & 0x3;
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// beq cr6,0x8b0ca0a4
	if (ctx.cr6.eq) goto loc_8B0CA0A4;
loc_8B0CA074:
	// cmpwi cr6,r29,8
	ctx.cr6.compare<int32_t>(ctx.r29.s32, 8, ctx.xer);
	// blt cr6,0x8b0ca0a4
	if (ctx.cr6.lt) goto loc_8B0CA0A4;
	// li r6,0
	ctx.r6.s64 = 0;
	// lbz r4,0(r30)
	ctx.r4.u64 = REX_LOAD_U8(ctx.r30.u32 + 0);
	// li r5,8
	ctx.r5.s64 = 8;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0a6c10
	ctx.lr = 0x8B0CA090;
	sub_8B0A6C10(ctx, base);
	// addi r30,r30,1
	ctx.r30.s64 = ctx.r30.s64 + 1;
	// addi r29,r29,-8
	ctx.r29.s64 = ctx.r29.s64 + -8;
	// clrlwi r11,r30,30
	ctx.r11.u64 = ctx.r30.u32 & 0x3;
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// bne cr6,0x8b0ca074
	if (!ctx.cr6.eq) goto loc_8B0CA074;
loc_8B0CA0A4:
	// cmpwi cr6,r29,32
	ctx.cr6.compare<int32_t>(ctx.r29.s32, 32, ctx.xer);
	// blt cr6,0x8b0ca1c8
	if (ctx.cr6.lt) goto loc_8B0CA1C8;
	// lwz r11,12(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 12);
	// clrlwi r10,r11,29
	ctx.r10.u64 = ctx.r11.u32 & 0x7;
	// cmpwi cr6,r10,0
	ctx.cr6.compare<int32_t>(ctx.r10.s32, 0, ctx.xer);
	// bne cr6,0x8b0ca0f4
	if (!ctx.cr6.eq) goto loc_8B0CA0F4;
	// srawi r28,r29,3
	ctx.xer.ca = (ctx.r29.s32 < 0) & ((ctx.r29.u32 & 0x7) != 0);
	ctx.r28.s64 = ctx.r29.s32 >> 3;
	// lwz r10,0(r31)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r31.u32 + 0);
	// srawi r11,r11,3
	ctx.xer.ca = (ctx.r11.s32 < 0) & ((ctx.r11.u32 & 0x7) != 0);
	ctx.r11.s64 = ctx.r11.s32 >> 3;
	// mr r5,r28
	ctx.r5.u64 = ctx.r28.u64;
	// mr r4,r30
	ctx.r4.u64 = ctx.r30.u64;
	// add r3,r11,r10
	ctx.r3.u64 = ctx.r11.u64 + ctx.r10.u64;
	// rlwinm r27,r28,3,0,28
	ctx.r27.u64 = __builtin_rotateleft64(ctx.r28.u32 | (ctx.r28.u64 << 32), 3) & 0xFFFFFFF8;
	// bl 0x8b0cbb30
	ctx.lr = 0x8B0CA0DC;
	sub_8B0CBB30(ctx, base);
	// lwz r11,12(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 12);
	// add r30,r28,r30
	ctx.r30.u64 = ctx.r28.u64 + ctx.r30.u64;
	// add r11,r27,r11
	ctx.r11.u64 = ctx.r27.u64 + ctx.r11.u64;
	// subf r29,r27,r29
	ctx.r29.u64 = ctx.r29.u64 - ctx.r27.u64;
	// stw r11,12(r31)
	REX_STORE_U32(ctx.r31.u32 + 12, ctx.r11.u32);
	// b 0x8b0ca1c8
	goto loc_8B0CA1C8;
loc_8B0CA0F4:
	// clrlwi r7,r11,27
	ctx.r7.u64 = ctx.r11.u32 & 0x1F;
	// lwz r9,0(r31)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r31.u32 + 0);
	// lis r8,-29936
	ctx.r8.s64 = -1961885696;
	// subfic r6,r7,32
	ctx.xer.ca = ctx.r7.u32 <= 32;
	ctx.r6.u64 = static_cast<uint64_t>(32) - ctx.r7.u64;
	// addi r10,r8,-22272
	ctx.r10.s64 = ctx.r8.s64 + -22272;
	// srawi r11,r11,5
	ctx.xer.ca = (ctx.r11.s32 < 0) & ((ctx.r11.u32 & 0x1F) != 0);
	ctx.r11.s64 = ctx.r11.s32 >> 5;
	// addi r5,r10,128
	ctx.r5.s64 = ctx.r10.s64 + 128;
	// mulli r4,r7,132
	ctx.r4.s64 = static_cast<int64_t>(ctx.r7.u64 * static_cast<uint64_t>(132));
	// lwzx r3,r4,r5
	ctx.r3.u64 = REX_LOAD_U32(ctx.r4.u32 + ctx.r5.u32);
	// rlwinm r8,r11,2,0,29
	ctx.r8.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 2) & 0xFFFFFFFC;
	// addi r10,r6,32
	ctx.r10.s64 = ctx.r6.s64 + 32;
	// cmpw cr6,r29,r10
	ctx.cr6.compare<int32_t>(ctx.r29.s32, ctx.r10.s32, ctx.xer);
	// lwbrx r5,r8,r9
	ctx.r5.u64 = __builtin_bswap32(REX_LOAD_U32(ctx.r8.u32 + ctx.r9.u32));
	// and r9,r5,r3
	ctx.r9.u64 = ctx.r5.u64 & ctx.r3.u64;
	// blt cr6,0x8b0ca18c
	if (ctx.cr6.lt) goto loc_8B0CA18C;
	// subf r10,r10,r29
	ctx.r10.u64 = ctx.r29.u64 - ctx.r10.u64;
	// addi r5,r1,80
	ctx.r5.s64 = ctx.r1.s64 + 80;
	// rlwinm r8,r10,27,5,31
	ctx.r8.u64 = __builtin_rotateleft64(ctx.r10.u32 | (ctx.r10.u64 << 32), 27) & 0x7FFFFFF;
	// rlwinm r10,r11,2,0,29
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 2) & 0xFFFFFFFC;
	// addi r8,r8,1
	ctx.r8.s64 = ctx.r8.s64 + 1;
	// rlwinm r4,r8,5,0,26
	ctx.r4.u64 = __builtin_rotateleft64(ctx.r8.u32 | (ctx.r8.u64 << 32), 5) & 0xFFFFFFE0;
	// subf r29,r4,r29
	ctx.r29.u64 = ctx.r29.u64 - ctx.r4.u64;
	// mtctr r8
	ctx.ctr.u64 = ctx.r8.u64;
loc_8B0CA150:
	// lwz r8,0(r30)
	ctx.r8.u64 = REX_LOAD_U32(ctx.r30.u32 + 0);
	// addi r11,r11,1
	ctx.r11.s64 = ctx.r11.s64 + 1;
	// lwz r4,0(r31)
	ctx.r4.u64 = REX_LOAD_U32(ctx.r31.u32 + 0);
	// addi r30,r30,4
	ctx.r30.s64 = ctx.r30.s64 + 4;
	// stwbrx r8,0,r5
	REX_STORE_U32(ctx.r5.u32, __builtin_bswap32(ctx.r8.u32));
	// lwz r8,80(r1)
	ctx.r8.u64 = REX_LOAD_U32(ctx.r1.u32 + 80);
	// slw r3,r8,r7
	ctx.r3.u64 = ctx.r7.u8 & 0x20 ? 0 : (ctx.r8.u32 << (ctx.r7.u8 & 0x3F));
	// or r3,r3,r9
	ctx.r3.u64 = ctx.r3.u64 | ctx.r9.u64;
	// srw r9,r8,r6
	ctx.r9.u64 = ctx.r6.u8 & 0x20 ? 0 : (ctx.r8.u32 >> (ctx.r6.u8 & 0x3F));
	// stwbrx r3,r10,r4
	REX_STORE_U32(ctx.r10.u32 + ctx.r4.u32, __builtin_bswap32(ctx.r3.u32));
	// rlwinm r10,r11,2,0,29
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 2) & 0xFFFFFFFC;
	// lwz r8,12(r31)
	ctx.r8.u64 = REX_LOAD_U32(ctx.r31.u32 + 12);
	// addi r8,r8,32
	ctx.r8.s64 = ctx.r8.s64 + 32;
	// stw r8,12(r31)
	REX_STORE_U32(ctx.r31.u32 + 12, ctx.r8.u32);
	// bdnz 0x8b0ca150
	--ctx.ctr.u64;
	if (ctx.ctr.u32 != 0) goto loc_8B0CA150;
loc_8B0CA18C:
	// lwz r10,0(r31)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r31.u32 + 0);
	// rlwinm r8,r11,2,0,29
	ctx.r8.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 2) & 0xFFFFFFFC;
	// cmpwi cr6,r29,32
	ctx.cr6.compare<int32_t>(ctx.r29.s32, 32, ctx.xer);
	// stwbrx r9,r8,r10
	REX_STORE_U32(ctx.r8.u32 + ctx.r10.u32, __builtin_bswap32(ctx.r9.u32));
	// blt cr6,0x8b0ca1c8
	if (ctx.cr6.lt) goto loc_8B0CA1C8;
	// lwz r11,0(r30)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r30.u32 + 0);
	// addi r10,r1,80
	ctx.r10.s64 = ctx.r1.s64 + 80;
	// li r6,0
	ctx.r6.s64 = 0;
	// li r5,32
	ctx.r5.s64 = 32;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// stwbrx r11,0,r10
	REX_STORE_U32(ctx.r10.u32, __builtin_bswap32(ctx.r11.u32));
	// lwz r4,80(r1)
	ctx.r4.u64 = REX_LOAD_U32(ctx.r1.u32 + 80);
	// bl 0x8b0a6c10
	ctx.lr = 0x8B0CA1C0;
	sub_8B0A6C10(ctx, base);
	// addi r30,r30,4
	ctx.r30.s64 = ctx.r30.s64 + 4;
	// addi r29,r29,-32
	ctx.r29.s64 = ctx.r29.s64 + -32;
loc_8B0CA1C8:
	// cmpwi cr6,r29,8
	ctx.cr6.compare<int32_t>(ctx.r29.s32, 8, ctx.xer);
	// blt cr6,0x8b0ca1fc
	if (ctx.cr6.lt) goto loc_8B0CA1FC;
	// rlwinm r11,r29,0,0,28
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r29.u32 | (ctx.r29.u64 << 32), 0) & 0xFFFFFFF8;
	// rlwinm r28,r29,29,3,31
	ctx.r28.u64 = __builtin_rotateleft64(ctx.r29.u32 | (ctx.r29.u64 << 32), 29) & 0x1FFFFFFF;
	// subf r29,r11,r29
	ctx.r29.u64 = ctx.r29.u64 - ctx.r11.u64;
loc_8B0CA1DC:
	// li r6,0
	ctx.r6.s64 = 0;
	// lbz r4,0(r30)
	ctx.r4.u64 = REX_LOAD_U8(ctx.r30.u32 + 0);
	// li r5,8
	ctx.r5.s64 = 8;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0a6c10
	ctx.lr = 0x8B0CA1F0;
	sub_8B0A6C10(ctx, base);
	// addic. r28,r28,-1
	ctx.xer.ca = ctx.r28.u32 > 0;
	ctx.r28.s64 = ctx.r28.s64 + -1;
	ctx.cr0.compare<int32_t>(ctx.r28.s32, 0, ctx.xer);
	// addi r30,r30,1
	ctx.r30.s64 = ctx.r30.s64 + 1;
	// bne 0x8b0ca1dc
	if (!ctx.cr0.eq) goto loc_8B0CA1DC;
loc_8B0CA1FC:
	// cmpwi cr6,r29,0
	ctx.cr6.compare<int32_t>(ctx.r29.s32, 0, ctx.xer);
	// beq cr6,0x8b0ca218
	if (ctx.cr6.eq) goto loc_8B0CA218;
	// li r6,0
	ctx.r6.s64 = 0;
	// lbz r4,0(r30)
	ctx.r4.u64 = REX_LOAD_U8(ctx.r30.u32 + 0);
	// mr r5,r29
	ctx.r5.u64 = ctx.r29.u64;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0a6c10
	ctx.lr = 0x8B0CA218;
	sub_8B0A6C10(ctx, base);
loc_8B0CA218:
	// lbz r11,16(r31)
	ctx.r11.u64 = REX_LOAD_U8(ctx.r31.u32 + 16);
	// cntlzw r10,r11
	ctx.r10.u64 = ctx.r11.u32 == 0 ? 32 : __builtin_clz(ctx.r11.u32);
	// rlwinm r3,r10,27,31,31
	ctx.r3.u64 = __builtin_rotateleft64(ctx.r10.u32 | (ctx.r10.u64 << 32), 27) & 0x1;
	// addi r1,r1,144
	ctx.r1.s64 = ctx.r1.s64 + 144;
	// b 0x8b0cba04
	__restgprlr_27(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0CAA18) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// std r31,-16(r1)
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.r31.u64);
	// stwu r1,-352(r1)
	ea = -352 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// extsb r5,r5
	ctx.r5.s64 = ctx.r5.s8;
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// cmpwi cr6,r5,124
	ctx.cr6.compare<int32_t>(ctx.r5.s32, 124, ctx.xer);
	// beq cr6,0x8b0caa60
	if (ctx.cr6.eq) goto loc_8B0CAA60;
	// cmpwi cr6,r5,38
	ctx.cr6.compare<int32_t>(ctx.r5.s32, 38, ctx.xer);
	// beq cr6,0x8b0caa60
	if (ctx.cr6.eq) goto loc_8B0CAA60;
	// li r11,0
	ctx.r11.s64 = 0;
loc_8B0CAA44:
	// stb r11,0(r4)
	REX_STORE_U8(ctx.r4.u32 + 0, ctx.r11.u8);
loc_8B0CAA48:
	// li r3,1
	ctx.r3.s64 = 1;
	// addi r1,r1,352
	ctx.r1.s64 = ctx.r1.s64 + 352;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
loc_8B0CAA60:
	// lwz r11,12(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 12);
	// extsb r8,r5
	ctx.r8.s64 = ctx.r5.s8;
	// lwz r9,8(r31)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r31.u32 + 8);
	// addi r7,r11,1
	ctx.r7.s64 = ctx.r11.s64 + 1;
	// lbzx r6,r9,r11
	ctx.r6.u64 = REX_LOAD_U8(ctx.r9.u32 + ctx.r11.u32);
	// stw r7,12(r31)
	REX_STORE_U32(ctx.r31.u32 + 12, ctx.r7.u32);
	// extsb r6,r6
	ctx.r6.s64 = ctx.r6.s8;
	// and r10,r6,r8
	ctx.r10.u64 = ctx.r6.u64 & ctx.r8.u64;
	// cmpw cr6,r10,r5
	ctx.cr6.compare<int32_t>(ctx.r10.s32, ctx.r5.s32, ctx.xer);
	// bne cr6,0x8b0caa90
	if (!ctx.cr6.eq) goto loc_8B0CAA90;
	// li r11,1
	ctx.r11.s64 = 1;
	// b 0x8b0caa44
	goto loc_8B0CAA44;
loc_8B0CAA90:
	// lwz r11,148(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 148);
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// beq cr6,0x8b0caa48
	if (ctx.cr6.eq) goto loc_8B0CAA48;
	// lis r11,-29943
	ctx.r11.s64 = -1962344448;
	// addi r3,r1,80
	ctx.r3.s64 = ctx.r1.s64 + 80;
	// addi r4,r11,-25424
	ctx.r4.s64 = ctx.r11.s64 + -25424;
	// bl 0x8b090220
	ctx.lr = 0x8B0CAAAC;
	sub_8B090220(ctx, base);
	// lwz r10,148(r31)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r31.u32 + 148);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bctrl 
	ctx.lr = 0x8B0CAAB8;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// li r3,0
	ctx.r3.s64 = 0;
	// addi r1,r1,352
	ctx.r1.s64 = ctx.r1.s64 + 352;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0CAE10) {
	REX_FUNC_PROLOGUE();
	// lwz r11,12(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 12);
	// lwz r10,8(r3)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r3.u32 + 8);
	// lbzx r9,r10,r11
	ctx.r9.u64 = REX_LOAD_U8(ctx.r10.u32 + ctx.r11.u32);
	// cmplwi cr6,r9,32
	ctx.cr6.compare<uint32_t>(ctx.r9.u32, 32, ctx.xer);
	// bne cr6,0x8b0cae44
	if (!ctx.cr6.eq) goto loc_8B0CAE44;
loc_8B0CAE24:
	// lwz r11,12(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 12);
	// addi r11,r11,1
	ctx.r11.s64 = ctx.r11.s64 + 1;
	// stw r11,12(r3)
	REX_STORE_U32(ctx.r3.u32 + 12, ctx.r11.u32);
	// rotlwi r8,r11,0
	ctx.r8.u64 = __builtin_rotateleft32(ctx.r11.u32, 0);
	// lwz r9,8(r3)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r3.u32 + 8);
	// lbzx r7,r9,r8
	ctx.r7.u64 = REX_LOAD_U8(ctx.r9.u32 + ctx.r8.u32);
	// cmplwi cr6,r7,32
	ctx.cr6.compare<uint32_t>(ctx.r7.u32, 32, ctx.xer);
	// beq cr6,0x8b0cae24
	if (ctx.cr6.eq) goto loc_8B0CAE24;
loc_8B0CAE44:
	// lwz r11,12(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 12);
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// addi r9,r11,1
	ctx.r9.s64 = ctx.r11.s64 + 1;
	// lbzx r8,r10,r11
	ctx.r8.u64 = REX_LOAD_U8(ctx.r10.u32 + ctx.r11.u32);
	// stw r9,12(r3)
	REX_STORE_U32(ctx.r3.u32 + 12, ctx.r9.u32);
	// stb r8,4(r3)
	REX_STORE_U8(ctx.r3.u32 + 4, ctx.r8.u8);
	// b 0x8b0cacf8
	sub_8B0CACF8(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0CAE60) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9b0
	ctx.lr = 0x8B0CAE68;
	__savegprlr_26(ctx, base);
	// stwu r1,-656(r1)
	ea = -656 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// mr r30,r3
	ctx.r30.u64 = ctx.r3.u64;
	// mr r26,r4
	ctx.r26.u64 = ctx.r4.u64;
	// mr r29,r6
	ctx.r29.u64 = ctx.r6.u64;
	// mr r27,r7
	ctx.r27.u64 = ctx.r7.u64;
	// cmplwi cr6,r5,0
	ctx.cr6.compare<uint32_t>(ctx.r5.u32, 0, ctx.xer);
	// bne cr6,0x8b0cae90
	if (!ctx.cr6.eq) goto loc_8B0CAE90;
	// li r3,0
	ctx.r3.s64 = 0;
	// addi r1,r1,656
	ctx.r1.s64 = ctx.r1.s64 + 656;
	// b 0x8b0cba00
	__restgprlr_26(ctx, base);
	return;
loc_8B0CAE90:
	// lbz r11,0(r5)
	ctx.r11.u64 = REX_LOAD_U8(ctx.r5.u32 + 0);
	// li r28,0
	ctx.r28.s64 = 0;
	// cmplwi cr6,r11,91
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 91, ctx.xer);
	// bne cr6,0x8b0caef0
	if (!ctx.cr6.eq) goto loc_8B0CAEF0;
	// mr r11,r5
	ctx.r11.u64 = ctx.r5.u64;
loc_8B0CAEA4:
	// lbz r10,0(r11)
	ctx.r10.u64 = REX_LOAD_U8(ctx.r11.u32 + 0);
	// addi r11,r11,1
	ctx.r11.s64 = ctx.r11.s64 + 1;
	// cmplwi cr6,r10,0
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 0, ctx.xer);
	// bne cr6,0x8b0caea4
	if (!ctx.cr6.eq) goto loc_8B0CAEA4;
	// subf r11,r5,r11
	ctx.r11.u64 = ctx.r11.u64 - ctx.r5.u64;
	// addi r4,r5,1
	ctx.r4.s64 = ctx.r5.s64 + 1;
	// addi r11,r11,-1
	ctx.r11.s64 = ctx.r11.s64 + -1;
	// addi r3,r1,80
	ctx.r3.s64 = ctx.r1.s64 + 80;
	// rotlwi r31,r11,0
	ctx.r31.u64 = __builtin_rotateleft32(ctx.r11.u32, 0);
	// mr r5,r31
	ctx.r5.u64 = ctx.r31.u64;
	// bl 0x8b0c3f18
	ctx.lr = 0x8B0CAED0;
	sub_8B0C3F18(ctx, base);
	// addi r10,r1,80
	ctx.r10.s64 = ctx.r1.s64 + 80;
	// addi r11,r31,-1
	ctx.r11.s64 = ctx.r31.s64 + -1;
	// add r11,r11,r10
	ctx.r11.u64 = ctx.r11.u64 + ctx.r10.u64;
	// lbz r10,-1(r11)
	ctx.r10.u64 = REX_LOAD_U8(ctx.r11.u32 + -1);
	// cmplwi cr6,r10,93
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 93, ctx.xer);
	// bne cr6,0x8b0caeec
	if (!ctx.cr6.eq) goto loc_8B0CAEEC;
	// stb r28,-1(r11)
	REX_STORE_U8(ctx.r11.u32 + -1, ctx.r28.u8);
loc_8B0CAEEC:
	// addi r5,r1,80
	ctx.r5.s64 = ctx.r1.s64 + 80;
loc_8B0CAEF0:
	// stw r5,8(r30)
	REX_STORE_U32(ctx.r30.u32 + 8, ctx.r5.u32);
	// cmplwi cr6,r29,0
	ctx.cr6.compare<uint32_t>(ctx.r29.u32, 0, ctx.xer);
	// beq cr6,0x8b0caf04
	if (ctx.cr6.eq) goto loc_8B0CAF04;
	// mr r11,r29
	ctx.r11.u64 = ctx.r29.u64;
	// b 0x8b0caf0c
	goto loc_8B0CAF0C;
loc_8B0CAF04:
	// lis r11,-29939
	ctx.r11.s64 = -1962082304;
	// addi r11,r11,-23048
	ctx.r11.s64 = ctx.r11.s64 + -23048;
loc_8B0CAF0C:
	// stw r11,144(r30)
	REX_STORE_U32(ctx.r30.u32 + 144, ctx.r11.u32);
	// cmplwi cr6,r27,0
	ctx.cr6.compare<uint32_t>(ctx.r27.u32, 0, ctx.xer);
	// beq cr6,0x8b0caf20
	if (ctx.cr6.eq) goto loc_8B0CAF20;
	// mr r11,r27
	ctx.r11.u64 = ctx.r27.u64;
	// b 0x8b0caf28
	goto loc_8B0CAF28;
loc_8B0CAF20:
	// lis r11,-29939
	ctx.r11.s64 = -1962082304;
	// addi r11,r11,-23792
	ctx.r11.s64 = ctx.r11.s64 + -23792;
loc_8B0CAF28:
	// stw r11,148(r30)
	REX_STORE_U32(ctx.r30.u32 + 148, ctx.r11.u32);
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// stw r28,0(r30)
	REX_STORE_U32(ctx.r30.u32 + 0, ctx.r28.u32);
	// stw r28,12(r30)
	REX_STORE_U32(ctx.r30.u32 + 12, ctx.r28.u32);
	// stb r28,4(r30)
	REX_STORE_U8(ctx.r30.u32 + 4, ctx.r28.u8);
	// bl 0x8b0cae10
	ctx.lr = 0x8B0CAF40;
	sub_8B0CAE10(ctx, base);
	// clrlwi r11,r3,24
	ctx.r11.u64 = ctx.r3.u32 & 0xFF;
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// beq cr6,0x8b0caf60
	if (ctx.cr6.eq) goto loc_8B0CAF60;
	// mr r4,r30
	ctx.r4.u64 = ctx.r30.u64;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// bl 0x8b0ca518
	ctx.lr = 0x8B0CAF5C;
	sub_8B0CA518(ctx, base);
	// stb r3,0(r26)
	REX_STORE_U8(ctx.r26.u32 + 0, ctx.r3.u8);
loc_8B0CAF60:
	// mr r4,r30
	ctx.r4.u64 = ctx.r30.u64;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// bl 0x8b0ca380
	ctx.lr = 0x8B0CAF6C;
	sub_8B0CA380(ctx, base);
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// stw r28,0(r30)
	REX_STORE_U32(ctx.r30.u32 + 0, ctx.r28.u32);
	// addi r1,r1,656
	ctx.r1.s64 = ctx.r1.s64 + 656;
	// b 0x8b0cba00
	__restgprlr_26(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0CB200) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb980
	ctx.lr = 0x8B0CB208;
	__savegprlr_14(ctx, base);
	// stwu r1,-304(r1)
	ea = -304 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// cmpwi cr6,r4,0
	ctx.cr6.compare<int32_t>(ctx.r4.s32, 0, ctx.xer);
	// ble cr6,0x8b0cb570
	if (!ctx.cr6.gt) goto loc_8B0CB570;
	// lis r31,-29943
	ctx.r31.s64 = -1962344448;
	// stw r4,80(r1)
	REX_STORE_U32(ctx.r1.u32 + 80, ctx.r4.u32);
	// lis r26,-29936
	ctx.r26.s64 = -1961885696;
	// addi r31,r31,-25052
	ctx.r31.s64 = ctx.r31.s64 + -25052;
	// lis r11,-29943
	ctx.r11.s64 = -1962344448;
	// stw r26,100(r1)
	REX_STORE_U32(ctx.r1.u32 + 100, ctx.r26.u32);
	// stw r31,104(r1)
	REX_STORE_U32(ctx.r1.u32 + 104, ctx.r31.u32);
	// lis r31,-29936
	ctx.r31.s64 = -1961885696;
	// mr r25,r3
	ctx.r25.u64 = ctx.r3.u64;
	// lis r28,-29936
	ctx.r28.s64 = -1961885696;
	// stw r31,96(r1)
	REX_STORE_U32(ctx.r1.u32 + 96, ctx.r31.u32);
	// lis r26,-29936
	ctx.r26.s64 = -1961885696;
	// addi r11,r11,-25076
	ctx.r11.s64 = ctx.r11.s64 + -25076;
	// stw r28,108(r1)
	REX_STORE_U32(ctx.r1.u32 + 108, ctx.r28.u32);
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// stw r26,88(r1)
	REX_STORE_U32(ctx.r1.u32 + 88, ctx.r26.u32);
	// lis r9,-29943
	ctx.r9.s64 = -1962344448;
	// stw r11,144(r1)
	REX_STORE_U32(ctx.r1.u32 + 144, ctx.r11.u32);
	// lis r8,-29943
	ctx.r8.s64 = -1962344448;
	// lis r7,-29943
	ctx.r7.s64 = -1962344448;
	// lis r6,-29943
	ctx.r6.s64 = -1962344448;
	// lis r5,-29943
	ctx.r5.s64 = -1962344448;
	// lis r4,-29943
	ctx.r4.s64 = -1962344448;
	// lis r3,-29943
	ctx.r3.s64 = -1962344448;
	// lis r29,-29943
	ctx.r29.s64 = -1962344448;
	// lis r31,-29936
	ctx.r31.s64 = -1961885696;
	// lis r27,-29943
	ctx.r27.s64 = -1962344448;
	// lis r30,-29943
	ctx.r30.s64 = -1962344448;
	// stw r31,84(r1)
	REX_STORE_U32(ctx.r1.u32 + 84, ctx.r31.u32);
	// lis r28,-29943
	ctx.r28.s64 = -1962344448;
	// lis r26,-29943
	ctx.r26.s64 = -1962344448;
	// addi r10,r10,11092
	ctx.r10.s64 = ctx.r10.s64 + 11092;
	// addi r9,r9,-25096
	ctx.r9.s64 = ctx.r9.s64 + -25096;
	// addi r8,r8,-25124
	ctx.r8.s64 = ctx.r8.s64 + -25124;
	// stw r10,140(r1)
	REX_STORE_U32(ctx.r1.u32 + 140, ctx.r10.u32);
	// addi r7,r7,-25148
	ctx.r7.s64 = ctx.r7.s64 + -25148;
	// stw r9,136(r1)
	REX_STORE_U32(ctx.r1.u32 + 136, ctx.r9.u32);
	// addi r6,r6,-25160
	ctx.r6.s64 = ctx.r6.s64 + -25160;
	// stw r8,132(r1)
	REX_STORE_U32(ctx.r1.u32 + 132, ctx.r8.u32);
	// addi r5,r5,-25168
	ctx.r5.s64 = ctx.r5.s64 + -25168;
	// stw r7,128(r1)
	REX_STORE_U32(ctx.r1.u32 + 128, ctx.r7.u32);
	// addi r4,r4,-25196
	ctx.r4.s64 = ctx.r4.s64 + -25196;
	// stw r6,124(r1)
	REX_STORE_U32(ctx.r1.u32 + 124, ctx.r6.u32);
	// addi r3,r3,-25216
	ctx.r3.s64 = ctx.r3.s64 + -25216;
	// stw r5,120(r1)
	REX_STORE_U32(ctx.r1.u32 + 120, ctx.r5.u32);
	// addi r11,r29,-25240
	ctx.r11.s64 = ctx.r29.s64 + -25240;
	// stw r4,116(r1)
	REX_STORE_U32(ctx.r1.u32 + 116, ctx.r4.u32);
	// addi r31,r27,-25260
	ctx.r31.s64 = ctx.r27.s64 + -25260;
	// stw r3,112(r1)
	REX_STORE_U32(ctx.r1.u32 + 112, ctx.r3.u32);
	// lis r20,-29936
	ctx.r20.s64 = -1961885696;
	// stw r11,92(r1)
	REX_STORE_U32(ctx.r1.u32 + 92, ctx.r11.u32);
	// lis r19,-29936
	ctx.r19.s64 = -1961885696;
	// lis r23,-29936
	ctx.r23.s64 = -1961885696;
	// lis r18,-29936
	ctx.r18.s64 = -1961885696;
	// lis r17,-29936
	ctx.r17.s64 = -1961885696;
	// lis r16,-29936
	ctx.r16.s64 = -1961885696;
	// lis r15,-29936
	ctx.r15.s64 = -1961885696;
	// lis r14,-29936
	ctx.r14.s64 = -1961885696;
	// lis r22,-29936
	ctx.r22.s64 = -1961885696;
	// lis r24,-29936
	ctx.r24.s64 = -1961885696;
	// lis r21,-29936
	ctx.r21.s64 = -1961885696;
	// addi r30,r30,-25292
	ctx.r30.s64 = ctx.r30.s64 + -25292;
	// addi r28,r28,-25316
	ctx.r28.s64 = ctx.r28.s64 + -25316;
	// addi r27,r26,-25332
	ctx.r27.s64 = ctx.r26.s64 + -25332;
loc_8B0CB314:
	// lwz r11,-17852(r21)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r21.u32 + -17852);
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// bne cr6,0x8b0cb338
	if (!ctx.cr6.eq) goto loc_8B0CB338;
	// lwz r11,0(r25)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r25.u32 + 0);
	// mr r3,r27
	ctx.r3.u64 = ctx.r27.u64;
	// li r4,0
	ctx.r4.s64 = 0;
	// mtctr r11
	ctx.ctr.u64 = ctx.r11.u64;
	// bctrl 
	ctx.lr = 0x8B0CB334;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// stw r3,-17852(r21)
	REX_STORE_U32(ctx.r21.u32 + -17852, ctx.r3.u32);
loc_8B0CB338:
	// lwz r11,-17848(r24)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r24.u32 + -17848);
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// bne cr6,0x8b0cb364
	if (!ctx.cr6.eq) goto loc_8B0CB364;
	// lwz r11,0(r25)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r25.u32 + 0);
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// li r4,0
	ctx.r4.s64 = 0;
	// mtctr r11
	ctx.ctr.u64 = ctx.r11.u64;
	// bctrl 
	ctx.lr = 0x8B0CB358;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// rotlwi r11,r3,0
	ctx.r11.u64 = __builtin_rotateleft32(ctx.r3.u32, 0);
	// stw r3,-17848(r24)
	REX_STORE_U32(ctx.r24.u32 + -17848, ctx.r3.u32);
	// stw r11,-17844(r22)
	REX_STORE_U32(ctx.r22.u32 + -17844, ctx.r11.u32);
loc_8B0CB364:
	// lwz r29,84(r1)
	ctx.r29.u64 = REX_LOAD_U32(ctx.r1.u32 + 84);
	// lwz r11,-17840(r29)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r29.u32 + -17840);
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// bne cr6,0x8b0cb38c
	if (!ctx.cr6.eq) goto loc_8B0CB38C;
	// lwz r11,0(r25)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r25.u32 + 0);
	// mr r3,r28
	ctx.r3.u64 = ctx.r28.u64;
	// li r4,0
	ctx.r4.s64 = 0;
	// mtctr r11
	ctx.ctr.u64 = ctx.r11.u64;
	// bctrl 
	ctx.lr = 0x8B0CB388;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// stw r3,-17840(r29)
	REX_STORE_U32(ctx.r29.u32 + -17840, ctx.r3.u32);
loc_8B0CB38C:
	// lwz r29,88(r1)
	ctx.r29.u64 = REX_LOAD_U32(ctx.r1.u32 + 88);
	// lwz r11,-17836(r29)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r29.u32 + -17836);
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// bne cr6,0x8b0cb3b4
	if (!ctx.cr6.eq) goto loc_8B0CB3B4;
	// lwz r11,0(r25)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r25.u32 + 0);
	// li r4,0
	ctx.r4.s64 = 0;
	// lwz r3,92(r1)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r1.u32 + 92);
	// mtctr r11
	ctx.ctr.u64 = ctx.r11.u64;
	// bctrl 
	ctx.lr = 0x8B0CB3B0;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// stw r3,-17836(r29)
	REX_STORE_U32(ctx.r29.u32 + -17836, ctx.r3.u32);
loc_8B0CB3B4:
	// lwz r29,96(r1)
	ctx.r29.u64 = REX_LOAD_U32(ctx.r1.u32 + 96);
	// lwz r11,-17832(r29)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r29.u32 + -17832);
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// bne cr6,0x8b0cb3dc
	if (!ctx.cr6.eq) goto loc_8B0CB3DC;
	// lwz r11,0(r25)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r25.u32 + 0);
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// li r4,0
	ctx.r4.s64 = 0;
	// mtctr r11
	ctx.ctr.u64 = ctx.r11.u64;
	// bctrl 
	ctx.lr = 0x8B0CB3D8;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// stw r3,-17832(r29)
	REX_STORE_U32(ctx.r29.u32 + -17832, ctx.r3.u32);
loc_8B0CB3DC:
	// lwz r29,100(r1)
	ctx.r29.u64 = REX_LOAD_U32(ctx.r1.u32 + 100);
	// lwz r11,-17828(r29)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r29.u32 + -17828);
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// bne cr6,0x8b0cb404
	if (!ctx.cr6.eq) goto loc_8B0CB404;
	// lwz r11,0(r25)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r25.u32 + 0);
	// li r4,0
	ctx.r4.s64 = 0;
	// lwz r3,104(r1)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r1.u32 + 104);
	// mtctr r11
	ctx.ctr.u64 = ctx.r11.u64;
	// bctrl 
	ctx.lr = 0x8B0CB400;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// stw r3,-17828(r29)
	REX_STORE_U32(ctx.r29.u32 + -17828, ctx.r3.u32);
loc_8B0CB404:
	// lwz r29,108(r1)
	ctx.r29.u64 = REX_LOAD_U32(ctx.r1.u32 + 108);
	// lwz r11,-17824(r29)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r29.u32 + -17824);
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// bne cr6,0x8b0cb42c
	if (!ctx.cr6.eq) goto loc_8B0CB42C;
	// lwz r11,0(r25)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r25.u32 + 0);
	// li r4,0
	ctx.r4.s64 = 0;
	// lwz r3,112(r1)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r1.u32 + 112);
	// mtctr r11
	ctx.ctr.u64 = ctx.r11.u64;
	// bctrl 
	ctx.lr = 0x8B0CB428;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// stw r3,-17824(r29)
	REX_STORE_U32(ctx.r29.u32 + -17824, ctx.r3.u32);
loc_8B0CB42C:
	// lwz r11,-17820(r14)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r14.u32 + -17820);
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// bne cr6,0x8b0cb450
	if (!ctx.cr6.eq) goto loc_8B0CB450;
	// lwz r11,0(r25)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r25.u32 + 0);
	// li r4,0
	ctx.r4.s64 = 0;
	// lwz r3,116(r1)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r1.u32 + 116);
	// mtctr r11
	ctx.ctr.u64 = ctx.r11.u64;
	// bctrl 
	ctx.lr = 0x8B0CB44C;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// stw r3,-17820(r14)
	REX_STORE_U32(ctx.r14.u32 + -17820, ctx.r3.u32);
loc_8B0CB450:
	// lwz r11,-17816(r15)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r15.u32 + -17816);
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// bne cr6,0x8b0cb474
	if (!ctx.cr6.eq) goto loc_8B0CB474;
	// lwz r11,0(r25)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r25.u32 + 0);
	// li r4,0
	ctx.r4.s64 = 0;
	// lwz r3,120(r1)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r1.u32 + 120);
	// mtctr r11
	ctx.ctr.u64 = ctx.r11.u64;
	// bctrl 
	ctx.lr = 0x8B0CB470;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// stw r3,-17816(r15)
	REX_STORE_U32(ctx.r15.u32 + -17816, ctx.r3.u32);
loc_8B0CB474:
	// lwz r11,-17812(r16)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r16.u32 + -17812);
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// bne cr6,0x8b0cb498
	if (!ctx.cr6.eq) goto loc_8B0CB498;
	// lwz r11,0(r25)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r25.u32 + 0);
	// li r4,0
	ctx.r4.s64 = 0;
	// lwz r3,124(r1)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r1.u32 + 124);
	// mtctr r11
	ctx.ctr.u64 = ctx.r11.u64;
	// bctrl 
	ctx.lr = 0x8B0CB494;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// stw r3,-17812(r16)
	REX_STORE_U32(ctx.r16.u32 + -17812, ctx.r3.u32);
loc_8B0CB498:
	// lwz r11,-17808(r17)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r17.u32 + -17808);
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// bne cr6,0x8b0cb4bc
	if (!ctx.cr6.eq) goto loc_8B0CB4BC;
	// lwz r11,0(r25)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r25.u32 + 0);
	// li r4,0
	ctx.r4.s64 = 0;
	// lwz r3,128(r1)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r1.u32 + 128);
	// mtctr r11
	ctx.ctr.u64 = ctx.r11.u64;
	// bctrl 
	ctx.lr = 0x8B0CB4B8;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// stw r3,-17808(r17)
	REX_STORE_U32(ctx.r17.u32 + -17808, ctx.r3.u32);
loc_8B0CB4BC:
	// lwz r11,-17804(r18)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r18.u32 + -17804);
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// bne cr6,0x8b0cb4e0
	if (!ctx.cr6.eq) goto loc_8B0CB4E0;
	// lwz r11,0(r25)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r25.u32 + 0);
	// li r4,0
	ctx.r4.s64 = 0;
	// lwz r3,132(r1)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r1.u32 + 132);
	// mtctr r11
	ctx.ctr.u64 = ctx.r11.u64;
	// bctrl 
	ctx.lr = 0x8B0CB4DC;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// stw r3,-17804(r18)
	REX_STORE_U32(ctx.r18.u32 + -17804, ctx.r3.u32);
loc_8B0CB4E0:
	// lwz r11,-17800(r23)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r23.u32 + -17800);
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// bne cr6,0x8b0cb514
	if (!ctx.cr6.eq) goto loc_8B0CB514;
	// lwz r11,0(r25)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r25.u32 + 0);
	// li r4,0
	ctx.r4.s64 = 0;
	// lwz r3,136(r1)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r1.u32 + 136);
	// mtctr r11
	ctx.ctr.u64 = ctx.r11.u64;
	// bctrl 
	ctx.lr = 0x8B0CB500;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// rotlwi r10,r3,0
	ctx.r10.u64 = __builtin_rotateleft32(ctx.r3.u32, 0);
	// stw r3,-17800(r23)
	REX_STORE_U32(ctx.r23.u32 + -17800, ctx.r3.u32);
	// cmplwi cr6,r10,0
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 0, ctx.xer);
	// beq cr6,0x8b0cb514
	if (ctx.cr6.eq) goto loc_8B0CB514;
	// bl 0x8b0cb600
	ctx.lr = 0x8B0CB514;
	sub_8B0CB600(ctx, base);
loc_8B0CB514:
	// lwz r11,-17796(r19)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r19.u32 + -17796);
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// bne cr6,0x8b0cb538
	if (!ctx.cr6.eq) goto loc_8B0CB538;
	// lwz r11,0(r25)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r25.u32 + 0);
	// li r4,0
	ctx.r4.s64 = 0;
	// lwz r3,140(r1)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r1.u32 + 140);
	// mtctr r11
	ctx.ctr.u64 = ctx.r11.u64;
	// bctrl 
	ctx.lr = 0x8B0CB534;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// stw r3,-17796(r19)
	REX_STORE_U32(ctx.r19.u32 + -17796, ctx.r3.u32);
loc_8B0CB538:
	// lwz r11,-17792(r20)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r20.u32 + -17792);
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// bne cr6,0x8b0cb55c
	if (!ctx.cr6.eq) goto loc_8B0CB55C;
	// lwz r11,0(r25)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r25.u32 + 0);
	// li r4,0
	ctx.r4.s64 = 0;
	// lwz r3,144(r1)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r1.u32 + 144);
	// mtctr r11
	ctx.ctr.u64 = ctx.r11.u64;
	// bctrl 
	ctx.lr = 0x8B0CB558;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// stw r3,-17792(r20)
	REX_STORE_U32(ctx.r20.u32 + -17792, ctx.r3.u32);
loc_8B0CB55C:
	// lwz r11,80(r1)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r1.u32 + 80);
	// addi r25,r25,4
	ctx.r25.s64 = ctx.r25.s64 + 4;
	// addic. r11,r11,-1
	ctx.xer.ca = ctx.r11.u32 > 0;
	ctx.r11.s64 = ctx.r11.s64 + -1;
	ctx.cr0.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// stw r11,80(r1)
	REX_STORE_U32(ctx.r1.u32 + 80, ctx.r11.u32);
	// bne 0x8b0cb314
	if (!ctx.cr0.eq) goto loc_8B0CB314;
loc_8B0CB570:
	// addi r1,r1,304
	ctx.r1.s64 = ctx.r1.s64 + 304;
	// b 0x8b0cb9d0
	__restgprlr_14(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0CC120) {
	REX_FUNC_PROLOGUE();
	// std r30,-16(r1)
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.r30.u64);
	// std r31,-8(r1)
	REX_STORE_U64(ctx.r1.u32 + -8, ctx.r31.u64);
	// lis r8,-29938
	ctx.r8.s64 = -1962016768;
	// lis r11,-29939
	ctx.r11.s64 = -1962082304;
	// addi r30,r8,12048
	ctx.r30.s64 = ctx.r8.s64 + 12048;
	// addi r11,r11,4384
	ctx.r11.s64 = ctx.r11.s64 + 4384;
	// lis r10,-29939
	ctx.r10.s64 = -1962082304;
	// lis r9,-29939
	ctx.r9.s64 = -1962082304;
	// stw r11,12048(r8)
	REX_STORE_U32(ctx.r8.u32 + 12048, ctx.r11.u32);
	// lis r31,-29939
	ctx.r31.s64 = -1962082304;
	// addi r10,r10,1336
	ctx.r10.s64 = ctx.r10.s64 + 1336;
	// addi r9,r9,1320
	ctx.r9.s64 = ctx.r9.s64 + 1320;
	// addi r11,r31,1328
	ctx.r11.s64 = ctx.r31.s64 + 1328;
	// stw r10,4(r30)
	REX_STORE_U32(ctx.r30.u32 + 4, ctx.r10.u32);
	// lis r3,-29939
	ctx.r3.s64 = -1962082304;
	// stw r9,8(r30)
	REX_STORE_U32(ctx.r30.u32 + 8, ctx.r9.u32);
	// lis r4,-29939
	ctx.r4.s64 = -1962082304;
	// stw r11,12(r30)
	REX_STORE_U32(ctx.r30.u32 + 12, ctx.r11.u32);
	// lis r5,-29939
	ctx.r5.s64 = -1962082304;
	// addi r10,r3,1192
	ctx.r10.s64 = ctx.r3.s64 + 1192;
	// addi r9,r4,4384
	ctx.r9.s64 = ctx.r4.s64 + 4384;
	// addi r11,r5,4304
	ctx.r11.s64 = ctx.r5.s64 + 4304;
	// stw r10,16(r30)
	REX_STORE_U32(ctx.r30.u32 + 16, ctx.r10.u32);
	// lis r6,-29939
	ctx.r6.s64 = -1962082304;
	// stw r9,20(r30)
	REX_STORE_U32(ctx.r30.u32 + 20, ctx.r9.u32);
	// lis r7,-29939
	ctx.r7.s64 = -1962082304;
	// stw r11,24(r30)
	REX_STORE_U32(ctx.r30.u32 + 24, ctx.r11.u32);
	// lis r8,-29939
	ctx.r8.s64 = -1962082304;
	// addi r10,r6,1224
	ctx.r10.s64 = ctx.r6.s64 + 1224;
	// addi r9,r7,1024
	ctx.r9.s64 = ctx.r7.s64 + 1024;
	// addi r11,r8,872
	ctx.r11.s64 = ctx.r8.s64 + 872;
	// stw r10,28(r30)
	REX_STORE_U32(ctx.r30.u32 + 28, ctx.r10.u32);
	// stw r9,32(r30)
	REX_STORE_U32(ctx.r30.u32 + 32, ctx.r9.u32);
	// stw r11,36(r30)
	REX_STORE_U32(ctx.r30.u32 + 36, ctx.r11.u32);
	// ld r30,-16(r1)
	ctx.r30.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// ld r31,-8(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -8);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0CC1B8) {
	REX_FUNC_PROLOGUE();
	// b 0x8b0cc120
	sub_8B0CC120(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0CC1C0) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// std r30,-24(r1)
	REX_STORE_U64(ctx.r1.u32 + -24, ctx.r30.u64);
	// std r31,-16(r1)
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.r31.u64);
	// stwu r1,-112(r1)
	ea = -112 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lis r11,-29943
	ctx.r11.s64 = -1962344448;
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// addi r11,r11,-25020
	ctx.r11.s64 = ctx.r11.s64 + -25020;
	// mr r30,r4
	ctx.r30.u64 = ctx.r4.u64;
	// stw r11,0(r3)
	REX_STORE_U32(ctx.r3.u32 + 0, ctx.r11.u32);
	// bl 0x8b0d1180
	ctx.lr = 0x8B0CC1EC;
	sub_8B0D1180(ctx, base);
	// clrlwi. r11,r30,31
	ctx.r11.u64 = ctx.r30.u32 & 0x1;
	ctx.cr0.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// beq 0x8b0cc1fc
	if (ctx.cr0.eq) goto loc_8B0CC1FC;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b090020
	ctx.lr = 0x8B0CC1FC;
	sub_8B090020(ctx, base);
loc_8B0CC1FC:
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// addi r1,r1,112
	ctx.r1.s64 = ctx.r1.s64 + 112;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// ld r30,-24(r1)
	ctx.r30.u64 = REX_LOAD_U64(ctx.r1.u32 + -24);
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0CC3D0) {
	REX_FUNC_PROLOGUE();
	PPCRegister temp{};
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// stwu r1,-96(r1)
	ea = -96 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// bl 0x8b0cc2c8
	ctx.lr = 0x8B0CC3E0;
	sub_8B0CC2C8(ctx, base);
	// addic r11,r3,-1
	ctx.xer.ca = ctx.r3.u32 > 0;
	ctx.r11.s64 = ctx.r3.s64 + -1;
	// subfe r3,r11,r11
	temp.u8 = (~ctx.r11.u32 + ctx.r11.u32 < ~ctx.r11.u32) | (~ctx.r11.u32 + ctx.r11.u32 + ctx.xer.ca < ctx.xer.ca);
	ctx.r3.u64 = ~ctx.r11.u64 + ctx.r11.u64 + ctx.xer.ca;
	ctx.xer.ca = temp.u8;
	// addi r1,r1,96
	ctx.r1.s64 = ctx.r1.s64 + 96;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0CC470) {
	REX_FUNC_PROLOGUE();
	// lis r11,-29938
	ctx.r11.s64 = -1962016768;
	// rlwinm r10,r3,1,0,30
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r3.u32 | (ctx.r3.u64 << 32), 1) & 0xFFFFFFFE;
	// addi r11,r11,12288
	ctx.r11.s64 = ctx.r11.s64 + 12288;
	// lwz r11,200(r11)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r11.u32 + 200);
	// lhzx r11,r10,r11
	ctx.r11.u64 = REX_LOAD_U16(ctx.r10.u32 + ctx.r11.u32);
	// rlwinm r3,r11,0,28,28
	ctx.r3.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 0) & 0x8;
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0CC598) {
	REX_FUNC_PROLOGUE();
	// li r5,10
	ctx.r5.s64 = 10;
	// li r4,0
	ctx.r4.s64 = 0;
	// b 0x8b0ce798
	sub_8B0CE798(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0CC5A8) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9bc
	ctx.lr = 0x8B0CC5B0;
	__savegprlr_29(ctx, base);
	// stwu r1,-112(r1)
	ea = -112 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lis r11,-29943
	ctx.r11.s64 = -1962344448;
	// mr r30,r3
	ctx.r30.u64 = ctx.r3.u64;
	// addi r11,r11,-24996
	ctx.r11.s64 = ctx.r11.s64 + -24996;
	// mr r29,r4
	ctx.r29.u64 = ctx.r4.u64;
	// stw r11,0(r3)
	REX_STORE_U32(ctx.r3.u32 + 0, ctx.r11.u32);
	// lwz r11,0(r4)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r4.u32 + 0);
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// beq cr6,0x8b0cc61c
	if (ctx.cr6.eq) goto loc_8B0CC61C;
	// mr r10,r11
	ctx.r10.u64 = ctx.r11.u64;
loc_8B0CC5D8:
	// lbz r9,0(r10)
	ctx.r9.u64 = REX_LOAD_U8(ctx.r10.u32 + 0);
	// addi r10,r10,1
	ctx.r10.s64 = ctx.r10.s64 + 1;
	// cmplwi cr6,r9,0
	ctx.cr6.compare<uint32_t>(ctx.r9.u32, 0, ctx.xer);
	// bne cr6,0x8b0cc5d8
	if (!ctx.cr6.eq) goto loc_8B0CC5D8;
	// subf r11,r11,r10
	ctx.r11.u64 = ctx.r10.u64 - ctx.r11.u64;
	// addi r11,r11,-1
	ctx.r11.s64 = ctx.r11.s64 + -1;
	// rotlwi r11,r11,0
	ctx.r11.u64 = __builtin_rotateleft32(ctx.r11.u32, 0);
	// addi r31,r11,1
	ctx.r31.s64 = ctx.r11.s64 + 1;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b090000
	ctx.lr = 0x8B0CC600;
	sub_8B090000(ctx, base);
	// stw r3,4(r30)
	REX_STORE_U32(ctx.r30.u32 + 4, ctx.r3.u32);
	// cmplwi r3,0
	ctx.cr0.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq 0x8b0cc624
	if (ctx.cr0.eq) goto loc_8B0CC624;
	// mr r4,r31
	ctx.r4.u64 = ctx.r31.u64;
	// lwz r5,0(r29)
	ctx.r5.u64 = REX_LOAD_U32(ctx.r29.u32 + 0);
	// bl 0x8b0d13e0
	ctx.lr = 0x8B0CC618;
	sub_8B0D13E0(ctx, base);
	// b 0x8b0cc624
	goto loc_8B0CC624;
loc_8B0CC61C:
	// li r11,0
	ctx.r11.s64 = 0;
	// stw r11,4(r30)
	REX_STORE_U32(ctx.r30.u32 + 4, ctx.r11.u32);
loc_8B0CC624:
	// li r11,1
	ctx.r11.s64 = 1;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// stw r11,8(r30)
	REX_STORE_U32(ctx.r30.u32 + 8, ctx.r11.u32);
	// addi r1,r1,112
	ctx.r1.s64 = ctx.r1.s64 + 112;
	// b 0x8b0cba0c
	__restgprlr_29(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0CC770) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9bc
	ctx.lr = 0x8B0CC778;
	__savegprlr_29(ctx, base);
	// stwu r1,-112(r1)
	ea = -112 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lis r11,-29943
	ctx.r11.s64 = -1962344448;
	// mr r30,r3
	ctx.r30.u64 = ctx.r3.u64;
	// addi r11,r11,-24996
	ctx.r11.s64 = ctx.r11.s64 + -24996;
	// mr r29,r4
	ctx.r29.u64 = ctx.r4.u64;
	// stw r11,0(r3)
	REX_STORE_U32(ctx.r3.u32 + 0, ctx.r11.u32);
	// lwz r11,8(r4)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r4.u32 + 8);
	// cmpwi cr6,r11,0
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// stw r11,8(r3)
	REX_STORE_U32(ctx.r3.u32 + 8, ctx.r11.u32);
	// beq cr6,0x8b0cc7fc
	if (ctx.cr6.eq) goto loc_8B0CC7FC;
	// lwz r10,4(r4)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r4.u32 + 4);
	// cmplwi cr6,r10,0
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 0, ctx.xer);
	// beq cr6,0x8b0cc7f4
	if (ctx.cr6.eq) goto loc_8B0CC7F4;
	// mr r11,r10
	ctx.r11.u64 = ctx.r10.u64;
loc_8B0CC7B0:
	// lbz r9,0(r11)
	ctx.r9.u64 = REX_LOAD_U8(ctx.r11.u32 + 0);
	// addi r11,r11,1
	ctx.r11.s64 = ctx.r11.s64 + 1;
	// cmplwi cr6,r9,0
	ctx.cr6.compare<uint32_t>(ctx.r9.u32, 0, ctx.xer);
	// bne cr6,0x8b0cc7b0
	if (!ctx.cr6.eq) goto loc_8B0CC7B0;
	// subf r11,r10,r11
	ctx.r11.u64 = ctx.r11.u64 - ctx.r10.u64;
	// addi r11,r11,-1
	ctx.r11.s64 = ctx.r11.s64 + -1;
	// rotlwi r11,r11,0
	ctx.r11.u64 = __builtin_rotateleft32(ctx.r11.u32, 0);
	// addi r31,r11,1
	ctx.r31.s64 = ctx.r11.s64 + 1;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b090000
	ctx.lr = 0x8B0CC7D8;
	sub_8B090000(ctx, base);
	// stw r3,4(r30)
	REX_STORE_U32(ctx.r30.u32 + 4, ctx.r3.u32);
	// cmplwi r3,0
	ctx.cr0.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq 0x8b0cc804
	if (ctx.cr0.eq) goto loc_8B0CC804;
	// mr r4,r31
	ctx.r4.u64 = ctx.r31.u64;
	// lwz r5,4(r29)
	ctx.r5.u64 = REX_LOAD_U32(ctx.r29.u32 + 4);
	// bl 0x8b0d13e0
	ctx.lr = 0x8B0CC7F0;
	sub_8B0D13E0(ctx, base);
	// b 0x8b0cc804
	goto loc_8B0CC804;
loc_8B0CC7F4:
	// li r11,0
	ctx.r11.s64 = 0;
	// b 0x8b0cc800
	goto loc_8B0CC800;
loc_8B0CC7FC:
	// lwz r11,4(r29)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r29.u32 + 4);
loc_8B0CC800:
	// stw r11,4(r30)
	REX_STORE_U32(ctx.r30.u32 + 4, ctx.r11.u32);
loc_8B0CC804:
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// addi r1,r1,112
	ctx.r1.s64 = ctx.r1.s64 + 112;
	// b 0x8b0cba0c
	__restgprlr_29(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0CCD08) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9bc
	ctx.lr = 0x8B0CCD10;
	__savegprlr_29(ctx, base);
	// addi r31,r1,-144
	ctx.r31.s64 = ctx.r1.s64 + -144;
	// stwu r1,-144(r1)
	ea = -144 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// mr r9,r5
	ctx.r9.u64 = ctx.r5.u64;
	// mr r5,r6
	ctx.r5.u64 = ctx.r6.u64;
	// mr r29,r7
	ctx.r29.u64 = ctx.r7.u64;
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0cce68
	if (ctx.cr6.eq) goto loc_8B0CCE68;
	// nop 
	// mr r8,r8
	ctx.r8.u64 = ctx.r8.u64;
	// mr r8,r8
	ctx.r8.u64 = ctx.r8.u64;
	// lwz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r11,-4(r11)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r11.u32 + -4);
	// lwz r8,4(r11)
	ctx.r8.u64 = REX_LOAD_U32(ctx.r11.u32 + 4);
	// lwz r10,8(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 8);
	// subf r30,r8,r3
	ctx.r30.u64 = ctx.r3.u64 - ctx.r8.u64;
	// stw r11,88(r31)
	REX_STORE_U32(ctx.r31.u32 + 88, ctx.r11.u32);
	// cmplwi cr6,r10,0
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 0, ctx.xer);
	// stw r30,84(r31)
	REX_STORE_U32(ctx.r31.u32 + 84, ctx.r30.u32);
	// beq cr6,0x8b0ccd6c
	if (ctx.cr6.eq) goto loc_8B0CCD6C;
	// subf r10,r10,r3
	ctx.r10.u64 = ctx.r3.u64 - ctx.r10.u64;
	// lwz r10,0(r10)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r10.u32 + 0);
	// subf r30,r10,r30
	ctx.r30.u64 = ctx.r30.u64 - ctx.r10.u64;
	// stw r30,84(r31)
	REX_STORE_U32(ctx.r31.u32 + 84, ctx.r30.u32);
loc_8B0CCD6C:
	// lwz r10,16(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + 16);
	// subf r8,r4,r3
	ctx.r8.u64 = ctx.r3.u64 - ctx.r4.u64;
	// subf r6,r30,r8
	ctx.r6.u64 = ctx.r8.u64 - ctx.r30.u64;
	// lwz r10,4(r10)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r10.u32 + 4);
	// clrlwi. r8,r10,31
	ctx.r8.u64 = ctx.r10.u32 & 0x1;
	ctx.cr0.compare<int32_t>(ctx.r8.s32, 0, ctx.xer);
	// bne 0x8b0ccd94
	if (!ctx.cr0.eq) goto loc_8B0CCD94;
	// mr r4,r9
	ctx.r4.u64 = ctx.r9.u64;
	// mr r3,r11
	ctx.r3.u64 = ctx.r11.u64;
	// bl 0x8b0cc810
	ctx.lr = 0x8B0CCD90;
	sub_8B0CC810(ctx, base);
	// b 0x8b0ccdb8
	goto loc_8B0CCDB8;
loc_8B0CCD94:
	// rlwinm. r10,r10,0,30,30
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r10.u32 | (ctx.r10.u64 << 32), 0) & 0x2;
	ctx.cr0.compare<int32_t>(ctx.r10.s32, 0, ctx.xer);
	// mr r7,r5
	ctx.r7.u64 = ctx.r5.u64;
	// mr r4,r11
	ctx.r4.u64 = ctx.r11.u64;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// mr r5,r9
	ctx.r5.u64 = ctx.r9.u64;
	// bne 0x8b0ccdb4
	if (!ctx.cr0.eq) goto loc_8B0CCDB4;
	// bl 0x8b0cc910
	ctx.lr = 0x8B0CCDB0;
	sub_8B0CC910(ctx, base);
	// b 0x8b0ccdb8
	goto loc_8B0CCDB8;
loc_8B0CCDB4:
	// bl 0x8b0ccac8
	ctx.lr = 0x8B0CCDB8;
	sub_8B0CCAC8(ctx, base);
loc_8B0CCDB8:
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0ccdf8
	if (ctx.cr6.eq) goto loc_8B0CCDF8;
	// lwz r11,12(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 12);
	// li r10,0
	ctx.r10.s64 = 0;
	// cmpwi cr6,r11,0
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// blt cr6,0x8b0ccde4
	if (ctx.cr6.lt) goto loc_8B0CCDE4;
	// lwzx r10,r11,r30
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + ctx.r30.u32);
	// lwz r9,16(r3)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r3.u32 + 16);
	// stw r11,88(r31)
	REX_STORE_U32(ctx.r31.u32 + 88, ctx.r11.u32);
	// lwzx r10,r10,r9
	ctx.r10.u64 = REX_LOAD_U32(ctx.r10.u32 + ctx.r9.u32);
	// add r10,r10,r11
	ctx.r10.u64 = ctx.r10.u64 + ctx.r11.u64;
loc_8B0CCDE4:
	// lwz r11,8(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 8);
	// add r11,r11,r10
	ctx.r11.u64 = ctx.r11.u64 + ctx.r10.u64;
	// add r30,r11,r30
	ctx.r30.u64 = ctx.r11.u64 + ctx.r30.u64;
	// stw r30,80(r31)
	REX_STORE_U32(ctx.r31.u32 + 80, ctx.r30.u32);
	// b 0x8b0cce2c
	goto loc_8B0CCE2C;
loc_8B0CCDF8:
	// li r30,0
	ctx.r30.s64 = 0;
	// cmpwi cr6,r29,0
	ctx.cr6.compare<int32_t>(ctx.r29.s32, 0, ctx.xer);
	// stw r30,80(r31)
	REX_STORE_U32(ctx.r31.u32 + 80, ctx.r30.u32);
	// beq cr6,0x8b0cce2c
	if (ctx.cr6.eq) goto loc_8B0CCE2C;
	// lis r11,-29943
	ctx.r11.s64 = -1962344448;
	// addi r3,r31,96
	ctx.r3.s64 = ctx.r31.s64 + 96;
	// addi r4,r11,-24952
	ctx.r4.s64 = ctx.r11.s64 + -24952;
	// bl 0x8b0cc650
	ctx.lr = 0x8B0CCE18;
	sub_8B0CC650(ctx, base);
	// lis r11,-29943
	ctx.r11.s64 = -1962344448;
	// addi r3,r31,96
	ctx.r3.s64 = ctx.r31.s64 + 96;
	// addi r4,r11,-8520
	ctx.r4.s64 = ctx.r11.s64 + -8520;
	// bl 0x8b0d14c0
	ctx.lr = 0x8B0CCE28;
	sub_8B0D14C0(ctx, base);
	// mr r8,r8
	ctx.r8.u64 = ctx.r8.u64;
loc_8B0CCE2C:
	// mr r8,r8
	ctx.r8.u64 = ctx.r8.u64;
	// mr r8,r8
	ctx.r8.u64 = ctx.r8.u64;
	// mr r8,r8
	ctx.r8.u64 = ctx.r8.u64;
	// b 0x8b0cce64
	goto loc_8B0CCE64;
loc_8B0CCE64:
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
loc_8B0CCE68:
	// addi r1,r31,144
	ctx.r1.s64 = ctx.r31.s64 + 144;
	// b 0x8b0cba0c
	__restgprlr_29(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0CCF20) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// neg r12,r3
	ctx.r12.s64 = static_cast<int64_t>(-ctx.r3.u64);
	// neg r11,r12
	ctx.r11.s64 = static_cast<int64_t>(-ctx.r12.u64);
	// addi r0,r11,4095
	ctx.r0.s64 = ctx.r11.s64 + 4095;
	// srawi. r0,r0,12
	ctx.xer.ca = (ctx.r0.s32 < 0) & ((ctx.r0.u32 & 0xFFF) != 0);
	ctx.r0.s64 = ctx.r0.s32 >> 12;
	ctx.cr0.compare<int32_t>(ctx.r0.s32, 0, ctx.xer);
	// blelr 
	if (!ctx.cr0.gt) return;
	// mr r11,r1
	ctx.r11.u64 = ctx.r1.u64;
	// mtctr r0
	ctx.ctr.u64 = ctx.r0.u64;
loc_8B0CCF3C:
	// lwzu r0,-4096(r11)
	ea = -4096 + ctx.r11.u32;
	ctx.r0.u64 = REX_LOAD_U32(ea);
	ctx.r11.u32 = ea;
	// bdnz 0x8b0ccf3c
	--ctx.ctr.u64;
	if (ctx.ctr.u32 != 0) goto loc_8B0CCF3C;
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0CD008) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// std r5,32(r1)
	REX_STORE_U64(ctx.r1.u32 + 32, ctx.r5.u64);
	// std r6,40(r1)
	REX_STORE_U64(ctx.r1.u32 + 40, ctx.r6.u64);
	// std r7,48(r1)
	REX_STORE_U64(ctx.r1.u32 + 48, ctx.r7.u64);
	// std r8,56(r1)
	REX_STORE_U64(ctx.r1.u32 + 56, ctx.r8.u64);
	// std r9,64(r1)
	REX_STORE_U64(ctx.r1.u32 + 64, ctx.r9.u64);
	// std r10,72(r1)
	REX_STORE_U64(ctx.r1.u32 + 72, ctx.r10.u64);
	// stwu r1,-96(r1)
	ea = -96 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// addi r11,r1,80
	ctx.r11.s64 = ctx.r1.s64 + 80;
	// lis r10,-29939
	ctx.r10.s64 = -1962082304;
	// mr r5,r4
	ctx.r5.u64 = ctx.r4.u64;
	// addi r9,r1,128
	ctx.r9.s64 = ctx.r1.s64 + 128;
	// mr r4,r3
	ctx.r4.u64 = ctx.r3.u64;
	// li r6,0
	ctx.r6.s64 = 0;
	// stw r9,0(r11)
	REX_STORE_U32(ctx.r11.u32 + 0, ctx.r9.u32);
	// addi r3,r10,5608
	ctx.r3.s64 = ctx.r10.s64 + 5608;
	// lwz r7,80(r1)
	ctx.r7.u64 = REX_LOAD_U32(ctx.r1.u32 + 80);
	// bl 0x8b0ccf48
	ctx.lr = 0x8B0CD054;
	sub_8B0CCF48(ctx, base);
	// addi r1,r1,96
	ctx.r1.s64 = ctx.r1.s64 + 96;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0CD400) {
	REX_FUNC_PROLOGUE();
	PPCRegister temp{};
	// stfd f30,-16(r1)
	ctx.fpscr.disableFlushMode();
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.f30.u64);
	// stfd f31,-8(r1)
	REX_STORE_U64(ctx.r1.u32 + -8, ctx.f31.u64);
	// fabs f0,f1
	ctx.f0.u64 = ctx.f1.u64 & ~0x8000000000000000;
	// lis r11,-29938
	ctx.r11.s64 = -1962016768;
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// stfd f0,-24(r1)
	REX_STORE_U64(ctx.r1.u32 + -24, ctx.f0.u64);
	// addi r11,r11,11384
	ctx.r11.s64 = ctx.r11.s64 + 11384;
	// lfd f30,17272(r10)
	ctx.f30.u64 = REX_LOAD_U64(ctx.r10.u32 + 17272);
	// lfd f11,8(r11)
	ctx.f11.u64 = REX_LOAD_U64(ctx.r11.u32 + 8);
	// lfs f12,32(r11)
	temp.u32 = REX_LOAD_U32(ctx.r11.u32 + 32);
	ctx.f12.f64 = double(temp.f32);
	// lfd f10,40(r11)
	ctx.f10.u64 = REX_LOAD_U64(ctx.r11.u32 + 40);
	// fmul f13,f11,f0
	ctx.f13.f64 = ctx.f11.f64 * ctx.f0.f64;
	// lfd f9,48(r11)
	ctx.f9.u64 = REX_LOAD_U64(ctx.r11.u32 + 48);
	// lfd f8,112(r11)
	ctx.f8.u64 = REX_LOAD_U64(ctx.r11.u32 + 112);
	// lfd f7,104(r11)
	ctx.f7.u64 = REX_LOAD_U64(ctx.r11.u32 + 104);
	// lfd f6,96(r11)
	ctx.f6.u64 = REX_LOAD_U64(ctx.r11.u32 + 96);
	// lfd f5,88(r11)
	ctx.f5.u64 = REX_LOAD_U64(ctx.r11.u32 + 88);
	// lfd f4,80(r11)
	ctx.f4.u64 = REX_LOAD_U64(ctx.r11.u32 + 80);
	// lfd f3,72(r11)
	ctx.f3.u64 = REX_LOAD_U64(ctx.r11.u32 + 72);
	// lfd f2,64(r11)
	ctx.f2.u64 = REX_LOAD_U64(ctx.r11.u32 + 64);
	// lfd f31,56(r11)
	ctx.f31.u64 = REX_LOAD_U64(ctx.r11.u32 + 56);
	// fctid f11,f13
	ctx.f11.s64 = std::isnan(ctx.f13.f64) ? int64_t(0x8000000000000000ULL) : (ctx.f13.f64 > double(LLONG_MAX)) ? LLONG_MAX : simde_mm_cvtsd_si64(simde_mm_load_sd(&ctx.f13.f64));
	// lfs f13,28(r11)
	temp.u32 = REX_LOAD_U32(ctx.r11.u32 + 28);
	ctx.f13.f64 = double(temp.f32);
	// fsel f12,f1,f13,f12
	ctx.f12.f64 = ctx.f1.f64 >= 0.0 ? ctx.f13.f64 : ctx.f12.f64;
	// fcfid f13,f11
	ctx.f13.f64 = double(ctx.f11.s64);
	// fnmsub f11,f10,f13,f0
	ctx.f11.f64 = -std::fma(ctx.f10.f64, ctx.f13.f64, -ctx.f0.f64);
	// fctidz f10,f13
	ctx.f10.s64 = std::isnan(ctx.f13.f64) ? int64_t(0x8000000000000000ULL) : (ctx.f13.f64 > double(LLONG_MAX)) ? LLONG_MAX : simde_mm_cvttsd_si64(simde_mm_load_sd(&ctx.f13.f64));
	// stfd f10,-32(r1)
	REX_STORE_U64(ctx.r1.u32 + -32, ctx.f10.u64);
	// ld r9,-32(r1)
	ctx.r9.u64 = REX_LOAD_U64(ctx.r1.u32 + -32);
	// clrldi r8,r9,63
	ctx.r8.u64 = ctx.r9.u64 & 0x1;
	// fnmsub f9,f9,f13,f11
	ctx.f9.f64 = -std::fma(ctx.f9.f64, ctx.f13.f64, -ctx.f11.f64);
	// cmpdi cr6,r8,0
	ctx.cr6.compare<int64_t>(ctx.r8.s64, 0, ctx.xer);
	// fmul f13,f9,f9
	ctx.f13.f64 = ctx.f9.f64 * ctx.f9.f64;
	// fmadd f11,f8,f13,f7
	ctx.f11.f64 = std::fma(ctx.f8.f64, ctx.f13.f64, ctx.f7.f64);
	// fmadd f10,f11,f13,f6
	ctx.f10.f64 = std::fma(ctx.f11.f64, ctx.f13.f64, ctx.f6.f64);
	// fmadd f8,f10,f13,f5
	ctx.f8.f64 = std::fma(ctx.f10.f64, ctx.f13.f64, ctx.f5.f64);
	// fmadd f7,f8,f13,f4
	ctx.f7.f64 = std::fma(ctx.f8.f64, ctx.f13.f64, ctx.f4.f64);
	// fmadd f6,f7,f13,f3
	ctx.f6.f64 = std::fma(ctx.f7.f64, ctx.f13.f64, ctx.f3.f64);
	// fmadd f5,f6,f13,f2
	ctx.f5.f64 = std::fma(ctx.f6.f64, ctx.f13.f64, ctx.f2.f64);
	// fmadd f4,f5,f13,f31
	ctx.f4.f64 = std::fma(ctx.f5.f64, ctx.f13.f64, ctx.f31.f64);
	// fmadd f3,f4,f13,f30
	ctx.f3.f64 = std::fma(ctx.f4.f64, ctx.f13.f64, ctx.f30.f64);
	// fmul f13,f3,f9
	ctx.f13.f64 = ctx.f3.f64 * ctx.f9.f64;
	// beq cr6,0x8b0cd4b0
	if (ctx.cr6.eq) goto loc_8B0CD4B0;
	// fneg f13,f13
	ctx.f13.u64 = ctx.f13.u64 ^ 0x8000000000000000;
loc_8B0CD4B0:
	// ld r10,-24(r1)
	ctx.r10.u64 = REX_LOAD_U64(ctx.r1.u32 + -24);
	// fmul f12,f13,f12
	ctx.fpscr.disableFlushMode();
	ctx.f12.f64 = ctx.f13.f64 * ctx.f12.f64;
	// cmpdi cr6,r10,0
	ctx.cr6.compare<int64_t>(ctx.r10.s64, 0, ctx.xer);
	// beq cr6,0x8b0cd4d4
	if (ctx.cr6.eq) goto loc_8B0CD4D4;
	// lfd f13,16(r11)
	ctx.f13.u64 = REX_LOAD_U64(ctx.r11.u32 + 16);
	// lis r11,-29938
	ctx.r11.s64 = -1962016768;
	// fsub f13,f0,f13
	ctx.f13.f64 = ctx.f0.f64 - ctx.f13.f64;
	// lfd f0,12528(r11)
	ctx.f0.u64 = REX_LOAD_U64(ctx.r11.u32 + 12528);
	// fsel f1,f13,f0,f12
	ctx.f1.f64 = ctx.f13.f64 >= 0.0 ? ctx.f0.f64 : ctx.f12.f64;
loc_8B0CD4D4:
	// lfd f30,-16(r1)
	ctx.fpscr.disableFlushMode();
	ctx.f30.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// lfd f31,-8(r1)
	ctx.f31.u64 = REX_LOAD_U64(ctx.r1.u32 + -8);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0CD948) {
	REX_FUNC_PROLOGUE();
	PPCRegister temp{};
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// std r31,-16(r1)
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.r31.u64);
	// addi r12,r1,-16
	ctx.r12.s64 = ctx.r1.s64 + -16;
	// bl 0x8b0cde5c
	ctx.lr = 0x8B0CD95C;
	__savefpr_25(ctx, base);
	// stwu r1,-176(r1)
	ea = -176 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lis r11,-29943
	ctx.r11.s64 = -1962344448;
	// stfd f1,192(r1)
	ctx.fpscr.disableFlushMode();
	REX_STORE_U64(ctx.r1.u32 + 192, ctx.f1.u64);
	// stfd f2,200(r1)
	REX_STORE_U64(ctx.r1.u32 + 200, ctx.f2.u64);
	// fmr f28,f1
	ctx.f28.f64 = ctx.f1.f64;
	// fmr f29,f2
	ctx.f29.f64 = ctx.f2.f64;
	// lfd f27,-32656(r11)
	ctx.f27.u64 = REX_LOAD_U64(ctx.r11.u32 + -32656);
	// fcmpu cr6,f2,f27
	ctx.cr6.compare(ctx.f2.f64, ctx.f27.f64);
	// bne cr6,0x8b0cd98c
	if (!ctx.cr6.eq) goto loc_8B0CD98C;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lfd f1,17272(r11)
	ctx.f1.u64 = REX_LOAD_U64(ctx.r11.u32 + 17272);
	// b 0x8b0cde10
	goto loc_8B0CDE10;
loc_8B0CD98C:
	// fcmpu cr6,f28,f27
	ctx.fpscr.disableFlushMode();
	ctx.cr6.compare(ctx.f28.f64, ctx.f27.f64);
	// bne cr6,0x8b0cd9e0
	if (!ctx.cr6.eq) goto loc_8B0CD9E0;
	// fmr f1,f29
	ctx.f1.f64 = ctx.f29.f64;
	// bl 0x8b0cd750
	ctx.lr = 0x8B0CD99C;
	sub_8B0CD750(ctx, base);
	// fcmpu cr6,f29,f27
	ctx.fpscr.disableFlushMode();
	ctx.cr6.compare(ctx.f29.f64, ctx.f27.f64);
	// bge cr6,0x8b0cd9c0
	if (!ctx.cr6.lt) goto loc_8B0CD9C0;
	// lis r11,-29938
	ctx.r11.s64 = -1962016768;
	// cmpwi cr6,r3,1
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 1, ctx.xer);
	// lfd f1,12520(r11)
	ctx.f1.u64 = REX_LOAD_U64(ctx.r11.u32 + 12520);
	// bne cr6,0x8b0cde10
	if (!ctx.cr6.eq) goto loc_8B0CDE10;
	// fmr f2,f28
	ctx.f2.f64 = ctx.f28.f64;
	// bl 0x8b0d2988
	ctx.lr = 0x8B0CD9BC;
	sub_8B0D2988(ctx, base);
	// b 0x8b0cde10
	goto loc_8B0CDE10;
loc_8B0CD9C0:
	// fcmpu cr6,f29,f27
	ctx.fpscr.disableFlushMode();
	ctx.cr6.compare(ctx.f29.f64, ctx.f27.f64);
	// ble cr6,0x8b0cd9e0
	if (!ctx.cr6.gt) goto loc_8B0CD9E0;
	// cmpwi cr6,r3,1
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 1, ctx.xer);
	// bne cr6,0x8b0cd9d8
	if (!ctx.cr6.eq) goto loc_8B0CD9D8;
	// fmr f1,f28
	ctx.f1.f64 = ctx.f28.f64;
	// b 0x8b0cde10
	goto loc_8B0CDE10;
loc_8B0CD9D8:
	// fmr f1,f27
	ctx.fpscr.disableFlushMode();
	ctx.f1.f64 = ctx.f27.f64;
	// b 0x8b0cde10
	goto loc_8B0CDE10;
loc_8B0CD9E0:
	// lhz r11,192(r1)
	ctx.r11.u64 = REX_LOAD_U16(ctx.r1.u32 + 192);
	// lhz r9,200(r1)
	ctx.r9.u64 = REX_LOAD_U16(ctx.r1.u32 + 200);
	// rlwinm r10,r11,0,17,27
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 0) & 0x7FF0;
	// cmplwi cr6,r10,32752
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 32752, ctx.xer);
	// beq cr6,0x8b0cdd9c
	if (ctx.cr6.eq) goto loc_8B0CDD9C;
	// rlwinm r10,r9,0,17,27
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r9.u32 | (ctx.r9.u64 << 32), 0) & 0x7FF0;
	// cmplwi cr6,r10,32752
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 32752, ctx.xer);
	// beq cr6,0x8b0cdd9c
	if (ctx.cr6.eq) goto loc_8B0CDD9C;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// fcmpu cr6,f28,f27
	ctx.fpscr.disableFlushMode();
	ctx.cr6.compare(ctx.f28.f64, ctx.f27.f64);
	// lfd f26,17272(r11)
	ctx.f26.u64 = REX_LOAD_U64(ctx.r11.u32 + 17272);
	// fmr f25,f26
	ctx.f25.f64 = ctx.f26.f64;
	// bge cr6,0x8b0cda44
	if (!ctx.cr6.lt) goto loc_8B0CDA44;
	// fmr f1,f29
	ctx.f1.f64 = ctx.f29.f64;
	// bl 0x8b0cd750
	ctx.lr = 0x8B0CDA1C;
	sub_8B0CD750(ctx, base);
	// cmpwi cr6,r3,1
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 1, ctx.xer);
	// beq cr6,0x8b0cda38
	if (ctx.cr6.eq) goto loc_8B0CDA38;
	// cmpwi cr6,r3,2
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 2, ctx.xer);
	// beq cr6,0x8b0cda40
	if (ctx.cr6.eq) goto loc_8B0CDA40;
	// lis r11,-29938
	ctx.r11.s64 = -1962016768;
	// lfd f1,12528(r11)
	ctx.fpscr.disableFlushMode();
	ctx.f1.u64 = REX_LOAD_U64(ctx.r11.u32 + 12528);
	// b 0x8b0cde10
	goto loc_8B0CDE10;
loc_8B0CDA38:
	// lis r11,-29943
	ctx.r11.s64 = -1962344448;
	// lfd f25,-24432(r11)
	ctx.fpscr.disableFlushMode();
	ctx.f25.u64 = REX_LOAD_U64(ctx.r11.u32 + -24432);
loc_8B0CDA40:
	// fneg f28,f28
	ctx.fpscr.disableFlushMode();
	ctx.f28.u64 = ctx.f28.u64 ^ 0x8000000000000000;
loc_8B0CDA44:
	// fabs f13,f29
	ctx.fpscr.disableFlushMode();
	ctx.f13.u64 = ctx.f29.u64 & ~0x8000000000000000;
	// lis r11,-29938
	ctx.r11.s64 = -1962016768;
	// lfd f0,11616(r11)
	ctx.f0.u64 = REX_LOAD_U64(ctx.r11.u32 + 11616);
	// fcmpu cr6,f13,f0
	ctx.cr6.compare(ctx.f13.f64, ctx.f0.f64);
	// ble cr6,0x8b0cda94
	if (!ctx.cr6.gt) goto loc_8B0CDA94;
	// fcmpu cr6,f29,f27
	ctx.cr6.compare(ctx.f29.f64, ctx.f27.f64);
	// bge cr6,0x8b0cda64
	if (!ctx.cr6.lt) goto loc_8B0CDA64;
	// fdiv f28,f26,f28
	ctx.f28.f64 = ctx.f26.f64 / ctx.f28.f64;
loc_8B0CDA64:
	// fcmpu cr6,f28,f26
	ctx.fpscr.disableFlushMode();
	ctx.cr6.compare(ctx.f28.f64, ctx.f26.f64);
	// ble cr6,0x8b0cda7c
	if (!ctx.cr6.gt) goto loc_8B0CDA7C;
loc_8B0CDA6C:
	// lis r11,-29938
	ctx.r11.s64 = -1962016768;
	// lfd f0,12520(r11)
	ctx.fpscr.disableFlushMode();
	ctx.f0.u64 = REX_LOAD_U64(ctx.r11.u32 + 12520);
loc_8B0CDA74:
	// fmul f1,f0,f25
	ctx.fpscr.disableFlushMode();
	ctx.f1.f64 = ctx.f0.f64 * ctx.f25.f64;
	// b 0x8b0cde10
	goto loc_8B0CDE10;
loc_8B0CDA7C:
	// fcmpu cr6,f28,f26
	ctx.fpscr.disableFlushMode();
	ctx.cr6.compare(ctx.f28.f64, ctx.f26.f64);
	// bge cr6,0x8b0cda8c
	if (!ctx.cr6.lt) goto loc_8B0CDA8C;
loc_8B0CDA84:
	// fmul f1,f25,f27
	ctx.fpscr.disableFlushMode();
	ctx.f1.f64 = ctx.f25.f64 * ctx.f27.f64;
	// b 0x8b0cde10
	goto loc_8B0CDE10;
loc_8B0CDA8C:
	// fmr f1,f25
	ctx.fpscr.disableFlushMode();
	ctx.f1.f64 = ctx.f25.f64;
	// b 0x8b0cde10
	goto loc_8B0CDE10;
loc_8B0CDA94:
	// addi r4,r1,80
	ctx.r4.s64 = ctx.r1.s64 + 80;
	// fmr f1,f28
	ctx.fpscr.disableFlushMode();
	ctx.f1.f64 = ctx.f28.f64;
	// bl 0x8b0d2848
	ctx.lr = 0x8B0CDAA0;
	sub_8B0D2848(ctx, base);
	// lis r11,-29943
	ctx.r11.s64 = -1962344448;
	// fmr f30,f1
	ctx.fpscr.disableFlushMode();
	ctx.f30.f64 = ctx.f1.f64;
	// lfd f0,-24440(r11)
	ctx.f0.u64 = REX_LOAD_U64(ctx.r11.u32 + -24440);
	// fcmpu cr6,f29,f0
	ctx.cr6.compare(ctx.f29.f64, ctx.f0.f64);
	// bgt cr6,0x8b0cdb4c
	if (ctx.cr6.gt) goto loc_8B0CDB4C;
	// fmr f1,f28
	ctx.f1.f64 = ctx.f28.f64;
	// bl 0x8b0cd750
	ctx.lr = 0x8B0CDABC;
	sub_8B0CD750(ctx, base);
	// cmpwi r3,0
	ctx.cr0.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// beq 0x8b0cdb4c
	if (ctx.cr0.eq) goto loc_8B0CDB4C;
	// fmr f1,f29
	ctx.fpscr.disableFlushMode();
	ctx.f1.f64 = ctx.f29.f64;
	// bl 0x8b0cd750
	ctx.lr = 0x8B0CDACC;
	sub_8B0CD750(ctx, base);
	// cmpwi r3,0
	ctx.cr0.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// beq 0x8b0cdb4c
	if (ctx.cr0.eq) goto loc_8B0CDB4C;
	// fcmpu cr6,f29,f27
	ctx.fpscr.disableFlushMode();
	ctx.cr6.compare(ctx.f29.f64, ctx.f27.f64);
	// ble cr6,0x8b0cdb4c
	if (!ctx.cr6.gt) goto loc_8B0CDB4C;
	// lwz r10,80(r1)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r1.u32 + 80);
	// fctiwz f0,f29
	ctx.f0.s64 = std::isnan(ctx.f29.f64) ? int64_t(0x80000000U) : (ctx.f29.f64 >= double(INT_MAX)) ? INT_MAX : simde_mm_cvttsd_si32(simde_mm_load_sd(&ctx.f29.f64));
	// stfd f0,88(r1)
	REX_STORE_U64(ctx.r1.u32 + 88, ctx.f0.u64);
	// lwz r11,92(r1)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r1.u32 + 92);
	// fmr f31,f26
	ctx.f31.f64 = ctx.f26.f64;
	// cmpwi cr6,r11,0
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// mullw r31,r11,r10
	ctx.r31.s64 = int64_t(ctx.r11.s32) * int64_t(ctx.r10.s32);
	// beq cr6,0x8b0cdb14
	if (ctx.cr6.eq) goto loc_8B0CDB14;
loc_8B0CDAFC:
	// clrlwi. r10,r11,31
	ctx.r10.u64 = ctx.r11.u32 & 0x1;
	ctx.cr0.compare<int32_t>(ctx.r10.s32, 0, ctx.xer);
	// beq 0x8b0cdb08
	if (ctx.cr0.eq) goto loc_8B0CDB08;
	// fmul f31,f31,f30
	ctx.fpscr.disableFlushMode();
	ctx.f31.f64 = ctx.f31.f64 * ctx.f30.f64;
loc_8B0CDB08:
	// srawi. r11,r11,1
	ctx.xer.ca = (ctx.r11.s32 < 0) & ((ctx.r11.u32 & 0x1) != 0);
	ctx.r11.s64 = ctx.r11.s32 >> 1;
	ctx.cr0.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// fmul f30,f30,f30
	ctx.fpscr.disableFlushMode();
	ctx.f30.f64 = ctx.f30.f64 * ctx.f30.f64;
	// bne 0x8b0cdafc
	if (!ctx.cr0.eq) goto loc_8B0CDAFC;
loc_8B0CDB14:
	// fmr f1,f31
	ctx.fpscr.disableFlushMode();
	ctx.f1.f64 = ctx.f31.f64;
	// bl 0x8b0d2830
	ctx.lr = 0x8B0CDB1C;
	sub_8B0D2830(ctx, base);
	// add r4,r3,r31
	ctx.r4.u64 = ctx.r3.u64 + ctx.r31.u64;
	// cmpwi cr6,r4,2560
	ctx.cr6.compare<int32_t>(ctx.r4.s32, 2560, ctx.xer);
	// ble cr6,0x8b0cdb38
	if (!ctx.cr6.gt) goto loc_8B0CDB38;
	// lis r11,-29938
	ctx.r11.s64 = -1962016768;
	// lfd f0,12520(r11)
	ctx.fpscr.disableFlushMode();
	ctx.f0.u64 = REX_LOAD_U64(ctx.r11.u32 + 12520);
	// fmul f0,f0,f31
	ctx.f0.f64 = ctx.f0.f64 * ctx.f31.f64;
	// b 0x8b0cda74
	goto loc_8B0CDA74;
loc_8B0CDB38:
	// cmpwi cr6,r4,-2557
	ctx.cr6.compare<int32_t>(ctx.r4.s32, -2557, ctx.xer);
	// bge cr6,0x8b0cdd7c
	if (!ctx.cr6.lt) goto loc_8B0CDD7C;
	// fmul f0,f31,f25
	ctx.fpscr.disableFlushMode();
	ctx.f0.f64 = ctx.f31.f64 * ctx.f25.f64;
	// fmul f1,f0,f27
	ctx.f1.f64 = ctx.f0.f64 * ctx.f27.f64;
	// b 0x8b0cde10
	goto loc_8B0CDE10;
loc_8B0CDB4C:
	// lis r10,-29943
	ctx.r10.s64 = -1962344448;
	// li r11,1
	ctx.r11.s64 = 1;
	// addi r31,r10,-24784
	ctx.r31.s64 = ctx.r10.s64 + -24784;
	// lfd f0,72(r31)
	ctx.fpscr.disableFlushMode();
	ctx.f0.u64 = REX_LOAD_U64(ctx.r31.u32 + 72);
	// fcmpu cr6,f30,f0
	ctx.cr6.compare(ctx.f30.f64, ctx.f0.f64);
	// bgt cr6,0x8b0cdb68
	if (ctx.cr6.gt) goto loc_8B0CDB68;
	// li r11,9
	ctx.r11.s64 = 9;
loc_8B0CDB68:
	// rlwinm r10,r11,3,0,28
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 3) & 0xFFFFFFF8;
	// addi r9,r31,32
	ctx.r9.s64 = ctx.r31.s64 + 32;
	// lfdx f0,r10,r9
	ctx.fpscr.disableFlushMode();
	ctx.f0.u64 = REX_LOAD_U64(ctx.r10.u32 + ctx.r9.u32);
	// fcmpu cr6,f30,f0
	ctx.cr6.compare(ctx.f30.f64, ctx.f0.f64);
	// bgt cr6,0x8b0cdb80
	if (ctx.cr6.gt) goto loc_8B0CDB80;
	// addi r11,r11,4
	ctx.r11.s64 = ctx.r11.s64 + 4;
loc_8B0CDB80:
	// rlwinm r10,r11,3,0,28
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 3) & 0xFFFFFFF8;
	// addi r9,r31,16
	ctx.r9.s64 = ctx.r31.s64 + 16;
	// lfdx f0,r10,r9
	ctx.fpscr.disableFlushMode();
	ctx.f0.u64 = REX_LOAD_U64(ctx.r10.u32 + ctx.r9.u32);
	// fcmpu cr6,f30,f0
	ctx.cr6.compare(ctx.f30.f64, ctx.f0.f64);
	// bgt cr6,0x8b0cdb98
	if (ctx.cr6.gt) goto loc_8B0CDB98;
	// addi r11,r11,2
	ctx.r11.s64 = ctx.r11.s64 + 2;
loc_8B0CDB98:
	// lwz r10,80(r1)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r1.u32 + 80);
	// rlwinm r10,r10,4,0,27
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r10.u32 | (ctx.r10.u64 << 32), 4) & 0xFFFFFFF0;
	// subf. r9,r11,r10
	ctx.r9.u64 = ctx.r10.u64 - ctx.r11.u64;
	ctx.cr0.compare<int32_t>(ctx.r9.s32, 0, ctx.xer);
	// subf r10,r10,r11
	ctx.r10.u64 = ctx.r11.u64 - ctx.r10.u64;
	// blt 0x8b0cdbb0
	if (ctx.cr0.lt) goto loc_8B0CDBB0;
	// mr r10,r9
	ctx.r10.u64 = ctx.r9.u64;
loc_8B0CDBB0:
	// lis r8,-29943
	ctx.r8.s64 = -1962344448;
	// cmpwi cr6,r10,1
	ctx.cr6.compare<int32_t>(ctx.r10.s32, 1, ctx.xer);
	// lfd f31,-24448(r8)
	ctx.fpscr.disableFlushMode();
	ctx.f31.u64 = REX_LOAD_U64(ctx.r8.u32 + -24448);
	// bne cr6,0x8b0cdbd8
	if (!ctx.cr6.eq) goto loc_8B0CDBD8;
	// fmr f1,f28
	ctx.f1.f64 = ctx.f28.f64;
	// bl 0x8b0cd5c0
	ctx.lr = 0x8B0CDBC8;
	sub_8B0CD5C0(ctx, base);
	// lfd f0,216(r31)
	ctx.fpscr.disableFlushMode();
	ctx.f0.u64 = REX_LOAD_U64(ctx.r31.u32 + 216);
	// fmr f13,f27
	ctx.f13.f64 = ctx.f27.f64;
	// fmul f0,f1,f0
	ctx.f0.f64 = ctx.f1.f64 * ctx.f0.f64;
	// b 0x8b0cdc68
	goto loc_8B0CDC68;
loc_8B0CDBD8:
	// rlwinm r10,r11,3,0,28
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 3) & 0xFFFFFFF8;
	// lfd f11,256(r31)
	ctx.fpscr.disableFlushMode();
	ctx.f11.u64 = REX_LOAD_U64(ctx.r31.u32 + 256);
	// addi r8,r31,8
	ctx.r8.s64 = ctx.r31.s64 + 8;
	// lfd f10,248(r31)
	ctx.f10.u64 = REX_LOAD_U64(ctx.r31.u32 + 248);
	// addi r11,r11,1
	ctx.r11.s64 = ctx.r11.s64 + 1;
	// lfd f9,240(r31)
	ctx.f9.u64 = REX_LOAD_U64(ctx.r31.u32 + 240);
	// addi r7,r31,144
	ctx.r7.s64 = ctx.r31.s64 + 144;
	// lfd f8,232(r31)
	ctx.f8.u64 = REX_LOAD_U64(ctx.r31.u32 + 232);
	// srawi r11,r11,1
	ctx.xer.ca = (ctx.r11.s32 < 0) & ((ctx.r11.u32 & 0x1) != 0);
	ctx.r11.s64 = ctx.r11.s32 >> 1;
	// lfd f12,224(r31)
	ctx.f12.u64 = REX_LOAD_U64(ctx.r31.u32 + 224);
	// lis r6,-29943
	ctx.r6.s64 = -1962344448;
	// lfd f7,216(r31)
	ctx.f7.u64 = REX_LOAD_U64(ctx.r31.u32 + 216);
	// lfdx f0,r10,r8
	ctx.f0.u64 = REX_LOAD_U64(ctx.r10.u32 + ctx.r8.u32);
	// addze r11,r11
	temp.s64 = ctx.r11.s64 + ctx.xer.ca;
	ctx.xer.ca = temp.u32 < ctx.r11.u32;
	ctx.r11.s64 = temp.s64;
	// fsub f6,f30,f0
	ctx.f6.f64 = ctx.f30.f64 - ctx.f0.f64;
	// extsw r10,r9
	ctx.r10.s64 = ctx.r9.s32;
	// rlwinm r11,r11,3,0,28
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 3) & 0xFFFFFFF8;
	// fadd f5,f0,f30
	ctx.f5.f64 = ctx.f0.f64 + ctx.f30.f64;
	// std r10,88(r1)
	REX_STORE_U64(ctx.r1.u32 + 88, ctx.r10.u64);
	// lfd f0,88(r1)
	ctx.f0.u64 = REX_LOAD_U64(ctx.r1.u32 + 88);
	// lfd f13,-29616(r6)
	ctx.f13.u64 = REX_LOAD_U64(ctx.r6.u32 + -29616);
	// fcfid f0,f0
	ctx.f0.f64 = double(ctx.f0.s64);
	// lfdx f4,r11,r7
	ctx.f4.u64 = REX_LOAD_U64(ctx.r11.u32 + ctx.r7.u32);
	// fmul f0,f0,f31
	ctx.f0.f64 = ctx.f0.f64 * ctx.f31.f64;
	// fsub f6,f6,f4
	ctx.f6.f64 = ctx.f6.f64 - ctx.f4.f64;
	// fdiv f6,f6,f5
	ctx.f6.f64 = ctx.f6.f64 / ctx.f5.f64;
	// fmul f13,f6,f13
	ctx.f13.f64 = ctx.f6.f64 * ctx.f13.f64;
	// fmul f6,f13,f13
	ctx.f6.f64 = ctx.f13.f64 * ctx.f13.f64;
	// fmul f12,f13,f12
	ctx.f12.f64 = ctx.f13.f64 * ctx.f12.f64;
	// fmadd f11,f6,f11,f10
	ctx.f11.f64 = std::fma(ctx.f6.f64, ctx.f11.f64, ctx.f10.f64);
	// fmadd f11,f11,f6,f9
	ctx.f11.f64 = std::fma(ctx.f11.f64, ctx.f6.f64, ctx.f9.f64);
	// fmadd f11,f11,f6,f8
	ctx.f11.f64 = std::fma(ctx.f11.f64, ctx.f6.f64, ctx.f8.f64);
	// fmul f11,f11,f6
	ctx.f11.f64 = ctx.f11.f64 * ctx.f6.f64;
	// fmul f11,f11,f13
	ctx.f11.f64 = ctx.f11.f64 * ctx.f13.f64;
	// fmadd f12,f11,f7,f12
	ctx.f12.f64 = std::fma(ctx.f11.f64, ctx.f7.f64, ctx.f12.f64);
	// fadd f13,f12,f13
	ctx.f13.f64 = ctx.f12.f64 + ctx.f13.f64;
loc_8B0CDC68:
	// lis r11,-29943
	ctx.r11.s64 = -1962344448;
	// fmul f11,f13,f29
	ctx.fpscr.disableFlushMode();
	ctx.f11.f64 = ctx.f13.f64 * ctx.f29.f64;
	// lfd f12,320(r31)
	ctx.f12.u64 = REX_LOAD_U64(ctx.r31.u32 + 320);
	// lfd f13,-27672(r11)
	ctx.f13.u64 = REX_LOAD_U64(ctx.r11.u32 + -27672);
	// fmul f10,f29,f13
	ctx.f10.f64 = ctx.f29.f64 * ctx.f13.f64;
	// fctid f10,f10
	ctx.f10.s64 = std::isnan(ctx.f10.f64) ? int64_t(0x8000000000000000ULL) : (ctx.f10.f64 > double(LLONG_MAX)) ? LLONG_MAX : simde_mm_cvtsd_si64(simde_mm_load_sd(&ctx.f10.f64));
	// fcfid f10,f10
	ctx.f10.f64 = double(ctx.f10.s64);
	// fmul f10,f10,f31
	ctx.f10.f64 = ctx.f10.f64 * ctx.f31.f64;
	// fsub f9,f29,f10
	ctx.f9.f64 = ctx.f29.f64 - ctx.f10.f64;
	// fmadd f11,f9,f0,f11
	ctx.f11.f64 = std::fma(ctx.f9.f64, ctx.f0.f64, ctx.f11.f64);
	// fmul f9,f11,f13
	ctx.f9.f64 = ctx.f11.f64 * ctx.f13.f64;
	// fctid f9,f9
	ctx.f9.s64 = std::isnan(ctx.f9.f64) ? int64_t(0x8000000000000000ULL) : (ctx.f9.f64 > double(LLONG_MAX)) ? LLONG_MAX : simde_mm_cvtsd_si64(simde_mm_load_sd(&ctx.f9.f64));
	// fcfid f9,f9
	ctx.f9.f64 = double(ctx.f9.s64);
	// fmul f9,f9,f31
	ctx.f9.f64 = ctx.f9.f64 * ctx.f31.f64;
	// fmadd f0,f10,f0,f9
	ctx.f0.f64 = std::fma(ctx.f10.f64, ctx.f0.f64, ctx.f9.f64);
	// fsub f11,f11,f9
	ctx.f11.f64 = ctx.f11.f64 - ctx.f9.f64;
	// fmul f10,f0,f13
	ctx.f10.f64 = ctx.f0.f64 * ctx.f13.f64;
	// fctid f10,f10
	ctx.f10.s64 = std::isnan(ctx.f10.f64) ? int64_t(0x8000000000000000ULL) : (ctx.f10.f64 > double(LLONG_MAX)) ? LLONG_MAX : simde_mm_cvtsd_si64(simde_mm_load_sd(&ctx.f10.f64));
	// fcfid f10,f10
	ctx.f10.f64 = double(ctx.f10.s64);
	// fmul f10,f10,f31
	ctx.f10.f64 = ctx.f10.f64 * ctx.f31.f64;
	// fsub f0,f0,f10
	ctx.f0.f64 = ctx.f0.f64 - ctx.f10.f64;
	// fadd f0,f0,f11
	ctx.f0.f64 = ctx.f0.f64 + ctx.f11.f64;
	// fmul f11,f0,f13
	ctx.f11.f64 = ctx.f0.f64 * ctx.f13.f64;
	// fctid f11,f11
	ctx.f11.s64 = std::isnan(ctx.f11.f64) ? int64_t(0x8000000000000000ULL) : (ctx.f11.f64 > double(LLONG_MAX)) ? LLONG_MAX : simde_mm_cvtsd_si64(simde_mm_load_sd(&ctx.f11.f64));
	// fcfid f11,f11
	ctx.f11.f64 = double(ctx.f11.s64);
	// fmul f11,f11,f31
	ctx.f11.f64 = ctx.f11.f64 * ctx.f31.f64;
	// fadd f10,f10,f11
	ctx.f10.f64 = ctx.f10.f64 + ctx.f11.f64;
	// fsub f0,f0,f11
	ctx.f0.f64 = ctx.f0.f64 - ctx.f11.f64;
	// fmul f13,f10,f13
	ctx.f13.f64 = ctx.f10.f64 * ctx.f13.f64;
	// fcmpu cr6,f13,f12
	ctx.cr6.compare(ctx.f13.f64, ctx.f12.f64);
	// bgt cr6,0x8b0cda6c
	if (ctx.cr6.gt) goto loc_8B0CDA6C;
	// lfd f12,328(r31)
	ctx.f12.u64 = REX_LOAD_U64(ctx.r31.u32 + 328);
	// fcmpu cr6,f13,f12
	ctx.cr6.compare(ctx.f13.f64, ctx.f12.f64);
	// blt cr6,0x8b0cda84
	if (ctx.cr6.lt) goto loc_8B0CDA84;
	// fctiwz f13,f13
	ctx.f13.s64 = std::isnan(ctx.f13.f64) ? int64_t(0x80000000U) : (ctx.f13.f64 >= double(INT_MAX)) ? INT_MAX : simde_mm_cvttsd_si32(simde_mm_load_sd(&ctx.f13.f64));
	// stfd f13,88(r1)
	REX_STORE_U64(ctx.r1.u32 + 88, ctx.f13.u64);
	// fcmpu cr6,f0,f27
	ctx.cr6.compare(ctx.f0.f64, ctx.f27.f64);
	// lwz r11,92(r1)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r1.u32 + 92);
	// ble cr6,0x8b0cdd0c
	if (!ctx.cr6.gt) goto loc_8B0CDD0C;
	// addi r11,r11,1
	ctx.r11.s64 = ctx.r11.s64 + 1;
	// fsub f0,f0,f31
	ctx.f0.f64 = ctx.f0.f64 - ctx.f31.f64;
loc_8B0CDD0C:
	// lfd f13,312(r31)
	ctx.fpscr.disableFlushMode();
	ctx.f13.u64 = REX_LOAD_U64(ctx.r31.u32 + 312);
	// srawi r10,r11,4
	ctx.xer.ca = (ctx.r11.s32 < 0) & ((ctx.r11.u32 & 0xF) != 0);
	ctx.r10.s64 = ctx.r11.s32 >> 4;
	// lfd f12,304(r31)
	ctx.f12.u64 = REX_LOAD_U64(ctx.r31.u32 + 304);
	// rlwinm r9,r11,1,31,31
	ctx.r9.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 1) & 0x1;
	// fmadd f8,f0,f13,f12
	ctx.f8.f64 = std::fma(ctx.f0.f64, ctx.f13.f64, ctx.f12.f64);
	// lfd f13,296(r31)
	ctx.f13.u64 = REX_LOAD_U64(ctx.r31.u32 + 296);
	// lfd f12,288(r31)
	ctx.f12.u64 = REX_LOAD_U64(ctx.r31.u32 + 288);
	// addze r10,r10
	temp.s64 = ctx.r10.s64 + ctx.xer.ca;
	ctx.xer.ca = temp.u32 < ctx.r10.u32;
	ctx.r10.s64 = temp.s64;
	// lfd f11,280(r31)
	ctx.f11.u64 = REX_LOAD_U64(ctx.r31.u32 + 280);
	// xori r9,r9,1
	ctx.r9.u64 = ctx.r9.u64 ^ 1;
	// lfd f10,272(r31)
	ctx.f10.u64 = REX_LOAD_U64(ctx.r31.u32 + 272);
	// addi r8,r31,8
	ctx.r8.s64 = ctx.r31.s64 + 8;
	// lfd f9,264(r31)
	ctx.f9.u64 = REX_LOAD_U64(ctx.r31.u32 + 264);
	// add r31,r9,r10
	ctx.r31.u64 = ctx.r9.u64 + ctx.r10.u64;
	// rlwinm r10,r31,4,0,27
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r31.u32 | (ctx.r31.u64 << 32), 4) & 0xFFFFFFF0;
	// subf r11,r11,r10
	ctx.r11.u64 = ctx.r10.u64 - ctx.r11.u64;
	// fmadd f13,f8,f0,f13
	ctx.f13.f64 = std::fma(ctx.f8.f64, ctx.f0.f64, ctx.f13.f64);
	// rlwinm r11,r11,3,0,28
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 3) & 0xFFFFFFF8;
	// lfdx f8,r11,r8
	ctx.f8.u64 = REX_LOAD_U64(ctx.r11.u32 + ctx.r8.u32);
	// fmadd f13,f13,f0,f12
	ctx.f13.f64 = std::fma(ctx.f13.f64, ctx.f0.f64, ctx.f12.f64);
	// fmadd f13,f13,f0,f11
	ctx.f13.f64 = std::fma(ctx.f13.f64, ctx.f0.f64, ctx.f11.f64);
	// fmadd f13,f13,f0,f10
	ctx.f13.f64 = std::fma(ctx.f13.f64, ctx.f0.f64, ctx.f10.f64);
	// fmadd f13,f13,f0,f9
	ctx.f13.f64 = std::fma(ctx.f13.f64, ctx.f0.f64, ctx.f9.f64);
	// fmadd f0,f13,f0,f26
	ctx.f0.f64 = std::fma(ctx.f13.f64, ctx.f0.f64, ctx.f26.f64);
	// fmul f31,f0,f8
	ctx.f31.f64 = ctx.f0.f64 * ctx.f8.f64;
	// fmr f1,f31
	ctx.f1.f64 = ctx.f31.f64;
	// bl 0x8b0d2830
	ctx.lr = 0x8B0CDD78;
	sub_8B0D2830(ctx, base);
	// add r4,r3,r31
	ctx.r4.u64 = ctx.r3.u64 + ctx.r31.u64;
loc_8B0CDD7C:
	// cmpwi cr6,r4,1024
	ctx.cr6.compare<int32_t>(ctx.r4.s32, 1024, ctx.xer);
	// bgt cr6,0x8b0cda6c
	if (ctx.cr6.gt) goto loc_8B0CDA6C;
	// cmpwi cr6,r4,-1021
	ctx.cr6.compare<int32_t>(ctx.r4.s32, -1021, ctx.xer);
	// blt cr6,0x8b0cda84
	if (ctx.cr6.lt) goto loc_8B0CDA84;
	// fmr f1,f31
	ctx.fpscr.disableFlushMode();
	ctx.f1.f64 = ctx.f31.f64;
	// bl 0x8b0d2808
	ctx.lr = 0x8B0CDD94;
	sub_8B0D2808(ctx, base);
	// fmul f1,f1,f25
	ctx.fpscr.disableFlushMode();
	ctx.f1.f64 = ctx.f1.f64 * ctx.f25.f64;
	// b 0x8b0cde10
	goto loc_8B0CDE10;
loc_8B0CDD9C:
	// rlwinm r10,r11,0,17,28
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 0) & 0x7FF8;
	// cmplwi cr6,r10,32752
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 32752, ctx.xer);
	// bne cr6,0x8b0cddc0
	if (!ctx.cr6.eq) goto loc_8B0CDDC0;
	// lwz r11,192(r1)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r1.u32 + 192);
	// clrlwi. r11,r11,13
	ctx.r11.u64 = ctx.r11.u32 & 0x7FFFF;
	ctx.cr0.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// bne 0x8b0cde0c
	if (!ctx.cr0.eq) goto loc_8B0CDE0C;
	// lwz r11,196(r1)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r1.u32 + 196);
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// bne cr6,0x8b0cde0c
	if (!ctx.cr6.eq) goto loc_8B0CDE0C;
loc_8B0CDDC0:
	// rlwinm r11,r9,0,17,28
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r9.u32 | (ctx.r9.u64 << 32), 0) & 0x7FF8;
	// cmplwi cr6,r11,32752
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 32752, ctx.xer);
	// bne cr6,0x8b0cdde4
	if (!ctx.cr6.eq) goto loc_8B0CDDE4;
	// lwz r9,200(r1)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r1.u32 + 200);
	// clrlwi. r9,r9,13
	ctx.r9.u64 = ctx.r9.u32 & 0x7FFFF;
	ctx.cr0.compare<int32_t>(ctx.r9.s32, 0, ctx.xer);
	// bne 0x8b0cde0c
	if (!ctx.cr0.eq) goto loc_8B0CDE0C;
	// lwz r9,204(r1)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r1.u32 + 204);
	// cmplwi cr6,r9,0
	ctx.cr6.compare<uint32_t>(ctx.r9.u32, 0, ctx.xer);
	// bne cr6,0x8b0cde0c
	if (!ctx.cr6.eq) goto loc_8B0CDE0C;
loc_8B0CDDE4:
	// cmplwi cr6,r10,32760
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 32760, ctx.xer);
	// beq cr6,0x8b0cde0c
	if (ctx.cr6.eq) goto loc_8B0CDE0C;
	// cmplwi cr6,r11,32760
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 32760, ctx.xer);
	// beq cr6,0x8b0cde0c
	if (ctx.cr6.eq) goto loc_8B0CDE0C;
	// addi r5,r1,88
	ctx.r5.s64 = ctx.r1.s64 + 88;
	// fmr f2,f29
	ctx.fpscr.disableFlushMode();
	ctx.f2.f64 = ctx.f29.f64;
	// fmr f1,f28
	ctx.f1.f64 = ctx.f28.f64;
	// bl 0x8b0cd7c0
	ctx.lr = 0x8B0CDE04;
	sub_8B0CD7C0(ctx, base);
	// lfd f1,88(r1)
	ctx.fpscr.disableFlushMode();
	ctx.f1.u64 = REX_LOAD_U64(ctx.r1.u32 + 88);
	// b 0x8b0cde10
	goto loc_8B0CDE10;
loc_8B0CDE0C:
	// fadd f1,f28,f29
	ctx.fpscr.disableFlushMode();
	ctx.f1.f64 = ctx.f28.f64 + ctx.f29.f64;
loc_8B0CDE10:
	// addi r1,r1,176
	ctx.r1.s64 = ctx.r1.s64 + 176;
	// addi r12,r1,-16
	ctx.r12.s64 = ctx.r1.s64 + -16;
	// bl 0x8b0cdea8
	ctx.lr = 0x8B0CDE1C;
	__restfpr_25(ctx, base);
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0CEC8C) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// std r31,-8(r1)
	REX_STORE_U64(ctx.r1.u32 + -8, ctx.r31.u64);
	// addi r31,r12,-176
	ctx.r31.s64 = ctx.r12.s64 + -176;
	// std r24,-16(r1)
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.r24.u64);
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-24(r1)
	REX_STORE_U32(ctx.r1.u32 + -24, ctx.r12.u32);
	// stwu r1,-112(r1)
	ea = -112 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lwz r24,204(r31)
	ctx.r24.u64 = REX_LOAD_U32(ctx.r31.u32 + 204);
	// b 0x8b0cecc4
	goto loc_8B0CECC4;
loc_8B0CECC4:
	// cmpwi cr6,r24,0
	ctx.cr6.compare<int32_t>(ctx.r24.s32, 0, ctx.xer);
	// beq cr6,0x8b0cecd4
	if (ctx.cr6.eq) goto loc_8B0CECD4;
	// li r3,8
	ctx.r3.s64 = 8;
	// bl 0x8b0d5e60
	ctx.lr = 0x8B0CECD4;
	sub_8B0D5E60(ctx, base);
loc_8B0CECD4:
	// lwz r1,0(r1)
	ctx.r1.u64 = REX_LOAD_U32(ctx.r1.u32 + 0);
	// ld r31,-8(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -8);
	// ld r24,-16(r1)
	ctx.r24.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// lwz r12,-24(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -24);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0CED70) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// std r31,-16(r1)
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.r31.u64);
	// stwu r1,-96(r1)
	ea = -96 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lis r31,-29938
	ctx.r31.s64 = -1962016768;
	// lwz r3,11652(r31)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r31.u32 + 11652);
	// cmpwi cr6,r3,-1
	ctx.cr6.compare<int32_t>(ctx.r3.s32, -1, ctx.xer);
	// beq cr6,0x8b0ced9c
	if (ctx.cr6.eq) goto loc_8B0CED9C;
	// bl 0x8b0df608
	ctx.lr = 0x8B0CED94;
	__imp__KeTlsFree(ctx, base);
	// li r11,-1
	ctx.r11.s64 = -1;
	// stw r11,11652(r31)
	REX_STORE_U32(ctx.r31.u32 + 11652, ctx.r11.u32);
loc_8B0CED9C:
	// bl 0x8b0d5df0
	ctx.lr = 0x8B0CEDA0;
	sub_8B0D5DF0(ctx, base);
	// addi r1,r1,96
	ctx.r1.s64 = ctx.r1.s64 + 96;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0CEEC8) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// std r31,-16(r1)
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.r31.u64);
	// stwu r1,-96(r1)
	ea = -96 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0cef74
	if (ctx.cr6.eq) goto loc_8B0CEF74;
	// lwz r3,36(r3)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r3.u32 + 36);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0ceef4
	if (ctx.cr6.eq) goto loc_8B0CEEF4;
	// bl 0x8b090020
	ctx.lr = 0x8B0CEEF4;
	sub_8B090020(ctx, base);
loc_8B0CEEF4:
	// lwz r3,44(r31)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r31.u32 + 44);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0cef04
	if (ctx.cr6.eq) goto loc_8B0CEF04;
	// bl 0x8b090020
	ctx.lr = 0x8B0CEF04;
	sub_8B090020(ctx, base);
loc_8B0CEF04:
	// lwz r3,52(r31)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r31.u32 + 52);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0cef14
	if (ctx.cr6.eq) goto loc_8B0CEF14;
	// bl 0x8b090020
	ctx.lr = 0x8B0CEF14;
	sub_8B090020(ctx, base);
loc_8B0CEF14:
	// lwz r3,60(r31)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r31.u32 + 60);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0cef24
	if (ctx.cr6.eq) goto loc_8B0CEF24;
	// bl 0x8b090020
	ctx.lr = 0x8B0CEF24;
	sub_8B090020(ctx, base);
loc_8B0CEF24:
	// lwz r3,64(r31)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r31.u32 + 64);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0cef34
	if (ctx.cr6.eq) goto loc_8B0CEF34;
	// bl 0x8b090020
	ctx.lr = 0x8B0CEF34;
	sub_8B090020(ctx, base);
loc_8B0CEF34:
	// lwz r3,68(r31)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r31.u32 + 68);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0cef44
	if (ctx.cr6.eq) goto loc_8B0CEF44;
	// bl 0x8b090020
	ctx.lr = 0x8B0CEF44;
	sub_8B090020(ctx, base);
loc_8B0CEF44:
	// lwz r3,72(r31)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r31.u32 + 72);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0cef54
	if (ctx.cr6.eq) goto loc_8B0CEF54;
	// bl 0x8b090020
	ctx.lr = 0x8B0CEF54;
	sub_8B090020(ctx, base);
loc_8B0CEF54:
	// lis r11,-29943
	ctx.r11.s64 = -1962344448;
	// lwz r3,92(r31)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r31.u32 + 92);
	// addi r11,r11,-24336
	ctx.r11.s64 = ctx.r11.s64 + -24336;
	// cmplw cr6,r3,r11
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, ctx.r11.u32, ctx.xer);
	// beq cr6,0x8b0cef6c
	if (ctx.cr6.eq) goto loc_8B0CEF6C;
	// bl 0x8b090020
	ctx.lr = 0x8B0CEF6C;
	sub_8B090020(ctx, base);
loc_8B0CEF6C:
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b090020
	ctx.lr = 0x8B0CEF74;
	sub_8B090020(ctx, base);
loc_8B0CEF74:
	// addi r1,r1,96
	ctx.r1.s64 = ctx.r1.s64 + 96;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0CF550) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9b8
	ctx.lr = 0x8B0CF558;
	__savegprlr_28(ctx, base);
	// stwu r1,-128(r1)
	ea = -128 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lwz r11,12(r5)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r5.u32 + 12);
	// mr r30,r4
	ctx.r30.u64 = ctx.r4.u64;
	// mr r29,r5
	ctx.r29.u64 = ctx.r5.u64;
	// mr r31,r6
	ctx.r31.u64 = ctx.r6.u64;
	// rlwinm. r11,r11,0,25,25
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 0) & 0x40;
	ctx.cr0.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// beq 0x8b0cf590
	if (ctx.cr0.eq) goto loc_8B0CF590;
	// lwz r11,8(r5)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r5.u32 + 8);
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// bne cr6,0x8b0cf590
	if (!ctx.cr6.eq) goto loc_8B0CF590;
	// lwz r11,0(r6)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r6.u32 + 0);
	// add r11,r11,r4
	ctx.r11.u64 = ctx.r11.u64 + ctx.r4.u64;
	// stw r11,0(r6)
	REX_STORE_U32(ctx.r6.u32 + 0, ctx.r11.u32);
	// b 0x8b0cf5e4
	goto loc_8B0CF5E4;
loc_8B0CF590:
	// cmpwi cr6,r30,0
	ctx.cr6.compare<int32_t>(ctx.r30.s32, 0, ctx.xer);
	// ble cr6,0x8b0cf5e4
	if (!ctx.cr6.gt) goto loc_8B0CF5E4;
	// addi r28,r3,-1
	ctx.r28.s64 = ctx.r3.s64 + -1;
loc_8B0CF59C:
	// mr r5,r31
	ctx.r5.u64 = ctx.r31.u64;
	// lbzu r3,1(r28)
	ea = 1 + ctx.r28.u32;
	ctx.r3.u64 = REX_LOAD_U8(ea);
	ctx.r28.u32 = ea;
	// mr r4,r29
	ctx.r4.u64 = ctx.r29.u64;
	// addi r30,r30,-1
	ctx.r30.s64 = ctx.r30.s64 + -1;
	// bl 0x8b0cf4b8
	ctx.lr = 0x8B0CF5B0;
	sub_8B0CF4B8(ctx, base);
	// lwz r11,0(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 0);
	// cmpwi cr6,r11,-1
	ctx.cr6.compare<int32_t>(ctx.r11.s32, -1, ctx.xer);
	// bne cr6,0x8b0cf5dc
	if (!ctx.cr6.eq) goto loc_8B0CF5DC;
	// bl 0x8b0d0288
	ctx.lr = 0x8B0CF5C0;
	sub_8B0D0288(ctx, base);
	// lwz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// cmpwi cr6,r11,42
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 42, ctx.xer);
	// bne cr6,0x8b0cf5e4
	if (!ctx.cr6.eq) goto loc_8B0CF5E4;
	// mr r5,r31
	ctx.r5.u64 = ctx.r31.u64;
	// mr r4,r29
	ctx.r4.u64 = ctx.r29.u64;
	// li r3,63
	ctx.r3.s64 = 63;
	// bl 0x8b0cf4b8
	ctx.lr = 0x8B0CF5DC;
	sub_8B0CF4B8(ctx, base);
loc_8B0CF5DC:
	// cmpwi cr6,r30,0
	ctx.cr6.compare<int32_t>(ctx.r30.s32, 0, ctx.xer);
	// bgt cr6,0x8b0cf59c
	if (ctx.cr6.gt) goto loc_8B0CF59C;
loc_8B0CF5E4:
	// addi r1,r1,128
	ctx.r1.s64 = ctx.r1.s64 + 128;
	// b 0x8b0cba08
	__restgprlr_28(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0D0190) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// stwu r1,-2816(r1)
	ea = -2816 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// li r11,0
	ctx.r11.s64 = 0;
	// li r5,76
	ctx.r5.s64 = 76;
	// li r4,0
	ctx.r4.s64 = 0;
	// stw r11,96(r1)
	REX_STORE_U32(ctx.r1.u32 + 96, ctx.r11.u32);
	// addi r3,r1,100
	ctx.r3.s64 = ctx.r1.s64 + 100;
	// bl 0x8b0cb8e0
	ctx.lr = 0x8B0D01B4;
	sub_8B0CB8E0(ctx, base);
	// addi r11,r1,96
	ctx.r11.s64 = ctx.r1.s64 + 96;
	// addi r10,r1,176
	ctx.r10.s64 = ctx.r1.s64 + 176;
	// li r5,2624
	ctx.r5.s64 = 2624;
	// stw r11,80(r1)
	REX_STORE_U32(ctx.r1.u32 + 80, ctx.r11.u32);
	// li r4,0
	ctx.r4.s64 = 0;
	// stw r10,84(r1)
	REX_STORE_U32(ctx.r1.u32 + 84, ctx.r10.u32);
	// addi r3,r1,176
	ctx.r3.s64 = ctx.r1.s64 + 176;
	// bl 0x8b0cb8e0
	ctx.lr = 0x8B0D01D4;
	sub_8B0CB8E0(ctx, base);
	// lwz r9,2808(r1)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r1.u32 + 2808);
	// lis r11,-16384
	ctx.r11.s64 = -1073741824;
	// li r10,1
	ctx.r10.s64 = 1;
	// ori r11,r11,1047
	ctx.r11.u64 = ctx.r11.u64 | 1047;
	// stw r10,100(r1)
	REX_STORE_U32(ctx.r1.u32 + 100, ctx.r10.u32);
	// li r3,0
	ctx.r3.s64 = 0;
	// stw r11,96(r1)
	REX_STORE_U32(ctx.r1.u32 + 96, ctx.r11.u32);
	// stw r9,108(r1)
	REX_STORE_U32(ctx.r1.u32 + 108, ctx.r9.u32);
	// bl 0x8b0dc690
	ctx.lr = 0x8B0D01F8;
	sub_8B0DC690(ctx, base);
	// addi r3,r1,80
	ctx.r3.s64 = ctx.r1.s64 + 80;
	// bl 0x8b0dc6a8
	ctx.lr = 0x8B0D0200;
	sub_8B0DC6A8(ctx, base);
	// cmplwi r3,0
	ctx.cr0.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// bne 0x8b0d0210
	if (!ctx.cr0.eq) goto loc_8B0D0210;
	// li r3,2
	ctx.r3.s64 = 2;
	// bl 0x8b0d6e38
	ctx.lr = 0x8B0D0210;
	sub_8B0D6E38(ctx, base);
loc_8B0D0210:
	// li r3,30
	ctx.r3.s64 = 30;
	// bl 0x8b0df5c8
	ctx.lr = 0x8B0D0218;
	__imp__KeBugCheck(ctx, base);
}

DEFINE_REX_FUNC(sub_8B0D0288) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// stwu r1,-96(r1)
	ea = -96 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// bl 0x8b0cedb8
	ctx.lr = 0x8B0D0298;
	sub_8B0CEDB8(ctx, base);
	// cmplwi r3,0
	ctx.cr0.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// bne 0x8b0d02ac
	if (!ctx.cr0.eq) goto loc_8B0D02AC;
	// lis r11,-29938
	ctx.r11.s64 = -1962016768;
	// addi r3,r11,12040
	ctx.r3.s64 = ctx.r11.s64 + 12040;
	// b 0x8b0d02b0
	goto loc_8B0D02B0;
loc_8B0D02AC:
	// addi r3,r3,8
	ctx.r3.s64 = ctx.r3.s64 + 8;
loc_8B0D02B0:
	// addi r1,r1,96
	ctx.r1.s64 = ctx.r1.s64 + 96;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0D02F8) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// std r30,-24(r1)
	REX_STORE_U64(ctx.r1.u32 + -24, ctx.r30.u64);
	// std r31,-16(r1)
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.r31.u64);
	// stwu r1,-112(r1)
	ea = -112 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// mr r30,r3
	ctx.r30.u64 = ctx.r3.u64;
	// bl 0x8b0cedb8
	ctx.lr = 0x8B0D0314;
	sub_8B0CEDB8(ctx, base);
	// lis r11,-29938
	ctx.r11.s64 = -1962016768;
	// cmplwi r3,0
	ctx.cr0.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// addi r31,r11,12040
	ctx.r31.s64 = ctx.r11.s64 + 12040;
	// addi r11,r31,4
	ctx.r11.s64 = ctx.r31.s64 + 4;
	// beq 0x8b0d032c
	if (ctx.cr0.eq) goto loc_8B0D032C;
	// addi r11,r3,12
	ctx.r11.s64 = ctx.r3.s64 + 12;
loc_8B0D032C:
	// stw r30,0(r11)
	REX_STORE_U32(ctx.r11.u32 + 0, ctx.r30.u32);
	// bl 0x8b0cedb8
	ctx.lr = 0x8B0D0334;
	sub_8B0CEDB8(ctx, base);
	// cmplwi r3,0
	ctx.cr0.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// mr r7,r31
	ctx.r7.u64 = ctx.r31.u64;
	// beq 0x8b0d0344
	if (ctx.cr0.eq) goto loc_8B0D0344;
	// addi r7,r3,8
	ctx.r7.s64 = ctx.r3.s64 + 8;
loc_8B0D0344:
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// bl 0x8b0d0218
	ctx.lr = 0x8B0D034C;
	sub_8B0D0218(ctx, base);
	// stw r3,0(r7)
	REX_STORE_U32(ctx.r7.u32 + 0, ctx.r3.u32);
	// addi r1,r1,112
	ctx.r1.s64 = ctx.r1.s64 + 112;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// ld r30,-24(r1)
	ctx.r30.u64 = REX_LOAD_U64(ctx.r1.u32 + -24);
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0D04A8) {
	REX_FUNC_PROLOGUE();
	// lis r11,-29943
	ctx.r11.s64 = -1962344448;
	// lfd f13,0(r3)
	ctx.fpscr.disableFlushMode();
	ctx.f13.u64 = REX_LOAD_U64(ctx.r3.u32 + 0);
	// li r3,1
	ctx.r3.s64 = 1;
	// lfd f0,-32656(r11)
	ctx.f0.u64 = REX_LOAD_U64(ctx.r11.u32 + -32656);
	// fcmpu cr6,f13,f0
	ctx.cr6.compare(ctx.f13.f64, ctx.f0.f64);
	// bgelr cr6
	if (!ctx.cr6.lt) return;
	// li r3,0
	ctx.r3.s64 = 0;
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0D0528) {
	REX_FUNC_PROLOGUE();
	// li r6,0
	ctx.r6.s64 = 0;
	// b 0x8b0d04c8
	sub_8B0D04C8(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0D0530) {
	REX_FUNC_PROLOGUE();
	// li r4,0
	ctx.r4.s64 = 0;
	// b 0x8b0d0368
	sub_8B0D0368(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0D0538) {
	REX_FUNC_PROLOGUE();
	// li r4,0
	ctx.r4.s64 = 0;
	// b 0x8b0d0400
	sub_8B0D0400(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0D0540) {
	REX_FUNC_PROLOGUE();
	PPCRegister temp{};
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9ac
	ctx.lr = 0x8B0D0548;
	__savegprlr_25(ctx, base);
	// stwu r1,-144(r1)
	ea = -144 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// mr r30,r3
	ctx.r30.u64 = ctx.r3.u64;
	// mr r29,r4
	ctx.r29.u64 = ctx.r4.u64;
	// mr r31,r5
	ctx.r31.u64 = ctx.r5.u64;
	// mr r25,r6
	ctx.r25.u64 = ctx.r6.u64;
	// mr r27,r7
	ctx.r27.u64 = ctx.r7.u64;
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// bne cr6,0x8b0d0594
	if (!ctx.cr6.eq) goto loc_8B0D0594;
	// bl 0x8b0d0288
	ctx.lr = 0x8B0D056C;
	sub_8B0D0288(ctx, base);
	// li r11,22
	ctx.r11.s64 = 22;
	// li r7,0
	ctx.r7.s64 = 0;
	// stw r11,0(r3)
	REX_STORE_U32(ctx.r3.u32 + 0, ctx.r11.u32);
	// li r6,0
	ctx.r6.s64 = 0;
	// li r5,0
	ctx.r5.s64 = 0;
	// li r4,0
	ctx.r4.s64 = 0;
	// li r3,0
	ctx.r3.s64 = 0;
	// bl 0x8b0d0148
	ctx.lr = 0x8B0D058C;
	sub_8B0D0148(ctx, base);
	// li r3,22
	ctx.r3.s64 = 22;
	// b 0x8b0d07ac
	goto loc_8B0D07AC;
loc_8B0D0594:
	// cmplwi cr6,r29,0
	ctx.cr6.compare<uint32_t>(ctx.r29.u32, 0, ctx.xer);
	// bne cr6,0x8b0d05c8
	if (!ctx.cr6.eq) goto loc_8B0D05C8;
	// bl 0x8b0d0288
	ctx.lr = 0x8B0D05A0;
	sub_8B0D0288(ctx, base);
	// li r31,22
	ctx.r31.s64 = 22;
loc_8B0D05A4:
	// stw r31,0(r3)
	REX_STORE_U32(ctx.r3.u32 + 0, ctx.r31.u32);
	// li r7,0
	ctx.r7.s64 = 0;
	// li r6,0
	ctx.r6.s64 = 0;
	// li r5,0
	ctx.r5.s64 = 0;
	// li r4,0
	ctx.r4.s64 = 0;
	// li r3,0
	ctx.r3.s64 = 0;
	// bl 0x8b0d0148
	ctx.lr = 0x8B0D05C0;
	sub_8B0D0148(ctx, base);
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// b 0x8b0d07ac
	goto loc_8B0D07AC;
loc_8B0D05C8:
	// subfic r11,r31,0
	ctx.xer.ca = ctx.r31.u32 <= 0;
	ctx.r11.u64 = static_cast<uint64_t>(0) - ctx.r31.u64;
	// rlwinm r11,r31,1,31,31
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r31.u32 | (ctx.r31.u64 << 32), 1) & 0x1;
	// addme r11,r11
	temp.u8 = (ctx.r11.u32 + 0xFFFFFFFFu < ctx.r11.u32) | (ctx.r11.u32 + 0xFFFFFFFFu + ctx.xer.ca < ctx.xer.ca);
	ctx.r11.u64 = ctx.r11.u64 + ctx.xer.ca + 0xFFFFFFFFFFFFFFFFull;
	ctx.xer.ca = temp.u8;
	// and r11,r11,r31
	ctx.r11.u64 = ctx.r11.u64 & ctx.r31.u64;
	// addi r11,r11,9
	ctx.r11.s64 = ctx.r11.s64 + 9;
	// cmplw cr6,r29,r11
	ctx.cr6.compare<uint32_t>(ctx.r29.u32, ctx.r11.u32, ctx.xer);
	// bgt cr6,0x8b0d05f0
	if (ctx.cr6.gt) goto loc_8B0D05F0;
	// bl 0x8b0d0288
	ctx.lr = 0x8B0D05E8;
	sub_8B0D0288(ctx, base);
	// li r31,34
	ctx.r31.s64 = 34;
	// b 0x8b0d05a4
	goto loc_8B0D05A4;
loc_8B0D05F0:
	// extsb. r28,r8
	ctx.r28.s64 = ctx.r8.s8;
	ctx.cr0.compare<int32_t>(ctx.r28.s32, 0, ctx.xer);
	// beq 0x8b0d0640
	if (ctx.cr0.eq) goto loc_8B0D0640;
	// lwz r11,0(r27)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r27.u32 + 0);
	// cmpwi cr6,r31,0
	ctx.cr6.compare<int32_t>(ctx.r31.s32, 0, ctx.xer);
	// addi r11,r11,-45
	ctx.r11.s64 = ctx.r11.s64 + -45;
	// cntlzw r11,r11
	ctx.r11.u64 = ctx.r11.u32 == 0 ? 32 : __builtin_clz(ctx.r11.u32);
	// rlwinm r11,r11,27,31,31
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 27) & 0x1;
	// add r4,r11,r30
	ctx.r4.u64 = ctx.r11.u64 + ctx.r30.u64;
	// ble cr6,0x8b0d0640
	if (!ctx.cr6.gt) goto loc_8B0D0640;
	// mr r11,r4
	ctx.r11.u64 = ctx.r4.u64;
loc_8B0D0618:
	// lbz r10,0(r11)
	ctx.r10.u64 = REX_LOAD_U8(ctx.r11.u32 + 0);
	// addi r11,r11,1
	ctx.r11.s64 = ctx.r11.s64 + 1;
	// cmplwi cr6,r10,0
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 0, ctx.xer);
	// bne cr6,0x8b0d0618
	if (!ctx.cr6.eq) goto loc_8B0D0618;
	// subf r11,r4,r11
	ctx.r11.u64 = ctx.r11.u64 - ctx.r4.u64;
	// addi r3,r4,1
	ctx.r3.s64 = ctx.r4.s64 + 1;
	// addi r11,r11,-1
	ctx.r11.s64 = ctx.r11.s64 + -1;
	// rotlwi r11,r11,0
	ctx.r11.u64 = __builtin_rotateleft32(ctx.r11.u32, 0);
	// addi r5,r11,1
	ctx.r5.s64 = ctx.r11.s64 + 1;
	// bl 0x8b0cc060
	ctx.lr = 0x8B0D0640;
	sub_8B0CC060(ctx, base);
loc_8B0D0640:
	// lwz r10,0(r27)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r27.u32 + 0);
	// mr r11,r30
	ctx.r11.u64 = ctx.r30.u64;
	// li r26,45
	ctx.r26.s64 = 45;
	// cmpwi cr6,r10,45
	ctx.cr6.compare<int32_t>(ctx.r10.s32, 45, ctx.xer);
	// bne cr6,0x8b0d065c
	if (!ctx.cr6.eq) goto loc_8B0D065C;
	// addi r11,r30,1
	ctx.r11.s64 = ctx.r30.s64 + 1;
	// stb r26,0(r30)
	REX_STORE_U8(ctx.r30.u32 + 0, ctx.r26.u8);
loc_8B0D065C:
	// cmpwi cr6,r31,0
	ctx.cr6.compare<int32_t>(ctx.r31.s32, 0, ctx.xer);
	// ble cr6,0x8b0d0688
	if (!ctx.cr6.gt) goto loc_8B0D0688;
	// lbz r9,1(r11)
	ctx.r9.u64 = REX_LOAD_U8(ctx.r11.u32 + 1);
	// lis r8,-29938
	ctx.r8.s64 = -1962016768;
	// addi r10,r11,1
	ctx.r10.s64 = ctx.r11.s64 + 1;
	// stb r9,0(r11)
	REX_STORE_U8(ctx.r11.u32 + 0, ctx.r9.u8);
	// mr r11,r10
	ctx.r11.u64 = ctx.r10.u64;
	// lwz r9,13620(r8)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r8.u32 + 13620);
	// lwz r9,0(r9)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r9.u32 + 0);
	// lbz r9,0(r9)
	ctx.r9.u64 = REX_LOAD_U8(ctx.r9.u32 + 0);
	// stb r9,0(r10)
	REX_STORE_U8(ctx.r10.u32 + 0, ctx.r9.u8);
loc_8B0D0688:
	// cntlzw r10,r28
	ctx.r10.u64 = ctx.r28.u32 == 0 ? 32 : __builtin_clz(ctx.r28.u32);
	// cmpwi cr6,r29,-1
	ctx.cr6.compare<int32_t>(ctx.r29.s32, -1, ctx.xer);
	// rlwinm r10,r10,27,31,31
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r10.u32 | (ctx.r10.u64 << 32), 27) & 0x1;
	// add r11,r10,r11
	ctx.r11.u64 = ctx.r10.u64 + ctx.r11.u64;
	// add r31,r11,r31
	ctx.r31.u64 = ctx.r11.u64 + ctx.r31.u64;
	// bne cr6,0x8b0d06a8
	if (!ctx.cr6.eq) goto loc_8B0D06A8;
	// li r4,-1
	ctx.r4.s64 = -1;
	// b 0x8b0d06b0
	goto loc_8B0D06B0;
loc_8B0D06A8:
	// subf r11,r31,r30
	ctx.r11.u64 = ctx.r30.u64 - ctx.r31.u64;
	// add r4,r11,r29
	ctx.r4.u64 = ctx.r11.u64 + ctx.r29.u64;
loc_8B0D06B0:
	// lis r11,-29943
	ctx.r11.s64 = -1962344448;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// addi r5,r11,-23976
	ctx.r5.s64 = ctx.r11.s64 + -23976;
	// bl 0x8b0d13e0
	ctx.lr = 0x8B0D06C0;
	sub_8B0D13E0(ctx, base);
	// cmpwi r3,0
	ctx.cr0.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// beq 0x8b0d06e0
	if (ctx.cr0.eq) goto loc_8B0D06E0;
	// li r7,0
	ctx.r7.s64 = 0;
	// li r6,0
	ctx.r6.s64 = 0;
	// li r5,0
	ctx.r5.s64 = 0;
	// li r4,0
	ctx.r4.s64 = 0;
	// li r3,0
	ctx.r3.s64 = 0;
	// bl 0x8b0d0190
	ctx.lr = 0x8B0D06E0;
	sub_8B0D0190(ctx, base);
loc_8B0D06E0:
	// addi r3,r31,2
	ctx.r3.s64 = ctx.r31.s64 + 2;
	// cmpwi cr6,r25,0
	ctx.cr6.compare<int32_t>(ctx.r25.s32, 0, ctx.xer);
	// beq cr6,0x8b0d06f4
	if (ctx.cr6.eq) goto loc_8B0D06F4;
	// li r11,69
	ctx.r11.s64 = 69;
	// stb r11,0(r31)
	REX_STORE_U8(ctx.r31.u32 + 0, ctx.r11.u8);
loc_8B0D06F4:
	// lwz r11,12(r27)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r27.u32 + 12);
	// addi r10,r31,1
	ctx.r10.s64 = ctx.r31.s64 + 1;
	// lbz r11,0(r11)
	ctx.r11.u64 = REX_LOAD_U8(ctx.r11.u32 + 0);
	// cmplwi cr6,r11,48
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 48, ctx.xer);
	// beq cr6,0x8b0d0780
	if (ctx.cr6.eq) goto loc_8B0D0780;
	// lwz r11,4(r27)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r27.u32 + 4);
	// addic. r11,r11,-1
	ctx.xer.ca = ctx.r11.u32 > 0;
	ctx.r11.s64 = ctx.r11.s64 + -1;
	ctx.cr0.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// bge 0x8b0d071c
	if (!ctx.cr0.lt) goto loc_8B0D071C;
	// neg r11,r11
	ctx.r11.s64 = static_cast<int64_t>(-ctx.r11.u64);
	// stb r26,0(r10)
	REX_STORE_U8(ctx.r10.u32 + 0, ctx.r26.u8);
loc_8B0D071C:
	// addi r10,r10,1
	ctx.r10.s64 = ctx.r10.s64 + 1;
	// cmpwi cr6,r11,100
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 100, ctx.xer);
	// blt cr6,0x8b0d0748
	if (ctx.cr6.lt) goto loc_8B0D0748;
	// li r7,100
	ctx.r7.s64 = 100;
	// lbz r8,0(r10)
	ctx.r8.u64 = REX_LOAD_U8(ctx.r10.u32 + 0);
	// divw r9,r11,r7
	ctx.r9.u64 = uint32_t((ctx.r7.s32 && !(ctx.r11.s32 == INT32_MIN && ctx.r7.s32 == -1)) ? ctx.r11.s32 / ctx.r7.s32 : 0);
	// divw r7,r11,r7
	ctx.r7.u64 = uint32_t((ctx.r7.s32 && !(ctx.r11.s32 == INT32_MIN && ctx.r7.s32 == -1)) ? ctx.r11.s32 / ctx.r7.s32 : 0);
	// add r9,r9,r8
	ctx.r9.u64 = ctx.r9.u64 + ctx.r8.u64;
	// mulli r8,r7,100
	ctx.r8.s64 = static_cast<int64_t>(ctx.r7.u64 * static_cast<uint64_t>(100));
	// stb r9,0(r10)
	REX_STORE_U8(ctx.r10.u32 + 0, ctx.r9.u8);
	// subf r11,r8,r11
	ctx.r11.u64 = ctx.r11.u64 - ctx.r8.u64;
loc_8B0D0748:
	// addi r10,r10,1
	ctx.r10.s64 = ctx.r10.s64 + 1;
	// cmpwi cr6,r11,10
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 10, ctx.xer);
	// blt cr6,0x8b0d0774
	if (ctx.cr6.lt) goto loc_8B0D0774;
	// li r7,10
	ctx.r7.s64 = 10;
	// lbz r8,0(r10)
	ctx.r8.u64 = REX_LOAD_U8(ctx.r10.u32 + 0);
	// divw r9,r11,r7
	ctx.r9.u64 = uint32_t((ctx.r7.s32 && !(ctx.r11.s32 == INT32_MIN && ctx.r7.s32 == -1)) ? ctx.r11.s32 / ctx.r7.s32 : 0);
	// divw r7,r11,r7
	ctx.r7.u64 = uint32_t((ctx.r7.s32 && !(ctx.r11.s32 == INT32_MIN && ctx.r7.s32 == -1)) ? ctx.r11.s32 / ctx.r7.s32 : 0);
	// add r9,r9,r8
	ctx.r9.u64 = ctx.r9.u64 + ctx.r8.u64;
	// mulli r8,r7,10
	ctx.r8.s64 = static_cast<int64_t>(ctx.r7.u64 * static_cast<uint64_t>(10));
	// stb r9,0(r10)
	REX_STORE_U8(ctx.r10.u32 + 0, ctx.r9.u8);
	// subf r11,r8,r11
	ctx.r11.u64 = ctx.r11.u64 - ctx.r8.u64;
loc_8B0D0774:
	// lbzu r9,1(r10)
	ea = 1 + ctx.r10.u32;
	ctx.r9.u64 = REX_LOAD_U8(ea);
	ctx.r10.u32 = ea;
	// add r11,r9,r11
	ctx.r11.u64 = ctx.r9.u64 + ctx.r11.u64;
	// stb r11,0(r10)
	REX_STORE_U8(ctx.r10.u32 + 0, ctx.r11.u8);
loc_8B0D0780:
	// lis r11,-29936
	ctx.r11.s64 = -1961885696;
	// lwz r11,-17232(r11)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r11.u32 + -17232);
	// clrlwi. r11,r11,31
	ctx.r11.u64 = ctx.r11.u32 & 0x1;
	ctx.cr0.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// beq 0x8b0d07a8
	if (ctx.cr0.eq) goto loc_8B0D07A8;
	// lbz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U8(ctx.r3.u32 + 0);
	// cmplwi cr6,r11,48
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 48, ctx.xer);
	// bne cr6,0x8b0d07a8
	if (!ctx.cr6.eq) goto loc_8B0D07A8;
	// addi r4,r3,1
	ctx.r4.s64 = ctx.r3.s64 + 1;
	// li r5,3
	ctx.r5.s64 = 3;
	// bl 0x8b0cc060
	ctx.lr = 0x8B0D07A8;
	sub_8B0CC060(ctx, base);
loc_8B0D07A8:
	// li r3,0
	ctx.r3.s64 = 0;
loc_8B0D07AC:
	// addi r1,r1,144
	ctx.r1.s64 = ctx.r1.s64 + 144;
	// b 0x8b0cb9fc
	__restgprlr_25(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0D1180) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// std r30,-24(r1)
	REX_STORE_U64(ctx.r1.u32 + -24, ctx.r30.u64);
	// std r31,-16(r1)
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.r31.u64);
	// addi r31,r1,-112
	ctx.r31.s64 = ctx.r1.s64 + -112;
	// stwu r1,-112(r1)
	ea = -112 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// mr r30,r3
	ctx.r30.u64 = ctx.r3.u64;
	// li r3,14
	ctx.r3.s64 = 14;
	// bl 0x8b0d5fc0
	ctx.lr = 0x8B0D11A4;
	sub_8B0D5FC0(ctx, base);
	// mr r8,r8
	ctx.r8.u64 = ctx.r8.u64;
	// lwz r10,4(r30)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r30.u32 + 4);
	// cmplwi cr6,r10,0
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 0, ctx.xer);
	// beq cr6,0x8b0d1204
	if (ctx.cr6.eq) goto loc_8B0D1204;
	// lis r11,-29936
	ctx.r11.s64 = -1961885696;
	// addi r9,r11,-17692
	ctx.r9.s64 = ctx.r11.s64 + -17692;
	// mr r11,r9
	ctx.r11.u64 = ctx.r9.u64;
	// lwz r3,4(r9)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r9.u32 + 4);
loc_8B0D11C4:
	// stw r3,80(r31)
	REX_STORE_U32(ctx.r31.u32 + 80, ctx.r3.u32);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0d11f4
	if (ctx.cr6.eq) goto loc_8B0D11F4;
	// lwz r9,0(r3)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// cmplw cr6,r9,r10
	ctx.cr6.compare<uint32_t>(ctx.r9.u32, ctx.r10.u32, ctx.xer);
	// beq cr6,0x8b0d11e8
	if (ctx.cr6.eq) goto loc_8B0D11E8;
	// mr r11,r3
	ctx.r11.u64 = ctx.r3.u64;
	// mr r8,r8
	ctx.r8.u64 = ctx.r8.u64;
	// b 0x8b0d11c4
	goto loc_8B0D11C4;
loc_8B0D11E8:
	// lwz r10,4(r3)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r3.u32 + 4);
	// stw r10,4(r11)
	REX_STORE_U32(ctx.r11.u32 + 4, ctx.r10.u32);
	// bl 0x8b090020
	ctx.lr = 0x8B0D11F4;
	sub_8B090020(ctx, base);
loc_8B0D11F4:
	// lwz r3,4(r30)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r30.u32 + 4);
	// bl 0x8b090020
	ctx.lr = 0x8B0D11FC;
	sub_8B090020(ctx, base);
	// li r11,0
	ctx.r11.s64 = 0;
	// stw r11,4(r30)
	REX_STORE_U32(ctx.r30.u32 + 4, ctx.r11.u32);
loc_8B0D1204:
	// mr r8,r8
	ctx.r8.u64 = ctx.r8.u64;
	// addi r12,r31,112
	ctx.r12.s64 = ctx.r31.s64 + 112;
	// bl 0x8b0d1228
	ctx.lr = 0x8B0D1210;
	sub_8B0D1228(ctx, base);
	// addi r1,r31,112
	ctx.r1.s64 = ctx.r31.s64 + 112;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// ld r30,-24(r1)
	ctx.r30.u64 = REX_LOAD_U64(ctx.r1.u32 + -24);
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0D1320) {
	REX_FUNC_PROLOGUE();
	// lis r10,-29938
	ctx.r10.s64 = -1962016768;
	// li r11,0
	ctx.r11.s64 = 0;
	// addi r9,r10,12096
	ctx.r9.s64 = ctx.r10.s64 + 12096;
	// mr r10,r9
	ctx.r10.u64 = ctx.r9.u64;
loc_8B0D1330:
	// lwz r8,0(r10)
	ctx.r8.u64 = REX_LOAD_U32(ctx.r10.u32 + 0);
	// cmpw cr6,r3,r8
	ctx.cr6.compare<int32_t>(ctx.r3.s32, ctx.r8.s32, ctx.xer);
	// beq cr6,0x8b0d134c
	if (ctx.cr6.eq) goto loc_8B0D134C;
	// addi r11,r11,1
	ctx.r11.s64 = ctx.r11.s64 + 1;
	// addi r10,r10,8
	ctx.r10.s64 = ctx.r10.s64 + 8;
	// cmplwi cr6,r11,23
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 23, ctx.xer);
	// blt cr6,0x8b0d1330
	if (ctx.cr6.lt) goto loc_8B0D1330;
loc_8B0D134C:
	// cmplwi cr6,r11,23
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 23, ctx.xer);
	// bgelr cr6
	if (!ctx.cr6.lt) return;
	// rlwinm r11,r11,3,0,28
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 3) & 0xFFFFFFF8;
	// addi r10,r9,4
	ctx.r10.s64 = ctx.r9.s64 + 4;
	// lwzx r3,r11,r10
	ctx.r3.u64 = REX_LOAD_U32(ctx.r11.u32 + ctx.r10.u32);
	// b 0x8b0dc650
	sub_8B0DC650(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0D13A8) {
	REX_FUNC_PROLOGUE();
	// cmpwi cr6,r3,-1
	ctx.cr6.compare<int32_t>(ctx.r3.s32, -1, ctx.xer);
	// blt cr6,0x8b0d13d4
	if (ctx.cr6.lt) goto loc_8B0D13D4;
	// cmpwi cr6,r3,255
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 255, ctx.xer);
	// bgt cr6,0x8b0d13d4
	if (ctx.cr6.gt) goto loc_8B0D13D4;
	// lis r11,-29938
	ctx.r11.s64 = -1962016768;
	// rlwinm r10,r3,1,0,30
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r3.u32 | (ctx.r3.u64 << 32), 1) & 0xFFFFFFFE;
	// lwz r11,12512(r11)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r11.u32 + 12512);
	// lwz r11,200(r11)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r11.u32 + 200);
	// lhzx r11,r11,r10
	ctx.r11.u64 = REX_LOAD_U16(ctx.r11.u32 + ctx.r10.u32);
	// and r3,r11,r4
	ctx.r3.u64 = ctx.r11.u64 & ctx.r4.u64;
	// blr 
	return;
loc_8B0D13D4:
	// li r3,0
	ctx.r3.s64 = 0;
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0D1548) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9b8
	ctx.lr = 0x8B0D1550;
	__savegprlr_28(ctx, base);
	// stwu r1,-128(r1)
	ea = -128 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lwz r11,0(r4)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r4.u32 + 0);
	// mr r31,r4
	ctx.r31.u64 = ctx.r4.u64;
	// mr r30,r5
	ctx.r30.u64 = ctx.r5.u64;
	// mr r29,r6
	ctx.r29.u64 = ctx.r6.u64;
	// mr r28,r7
	ctx.r28.u64 = ctx.r7.u64;
	// cmplw cr6,r3,r11
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, ctx.r11.u32, ctx.xer);
	// bne cr6,0x8b0d15dc
	if (!ctx.cr6.eq) goto loc_8B0D15DC;
	// lwz r3,0(r5)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r5.u32 + 0);
	// cmplw cr6,r3,r6
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, ctx.r6.u32, ctx.xer);
	// bne cr6,0x8b0d15b8
	if (!ctx.cr6.eq) goto loc_8B0D15B8;
	// li r4,2
	ctx.r4.s64 = 2;
	// mr r3,r11
	ctx.r3.u64 = ctx.r11.u64;
	// bl 0x8b090068
	ctx.lr = 0x8B0D1588;
	sub_8B090068(ctx, base);
	// stw r3,0(r30)
	REX_STORE_U32(ctx.r30.u32 + 0, ctx.r3.u32);
	// cmplwi r3,0
	ctx.cr0.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// bne 0x8b0d159c
	if (!ctx.cr0.eq) goto loc_8B0D159C;
loc_8B0D1594:
	// li r3,0
	ctx.r3.s64 = 0;
	// b 0x8b0d15e0
	goto loc_8B0D15E0;
loc_8B0D159C:
	// li r11,1
	ctx.r11.s64 = 1;
	// mr r4,r29
	ctx.r4.u64 = ctx.r29.u64;
	// stw r11,0(r28)
	REX_STORE_U32(ctx.r28.u32 + 0, ctx.r11.u32);
	// lwz r5,0(r31)
	ctx.r5.u64 = REX_LOAD_U32(ctx.r31.u32 + 0);
	// lwz r3,0(r30)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r30.u32 + 0);
	// bl 0x8b0cbb30
	ctx.lr = 0x8B0D15B4;
	sub_8B0CBB30(ctx, base);
	// b 0x8b0d15d0
	goto loc_8B0D15D0;
loc_8B0D15B8:
	// li r5,2
	ctx.r5.s64 = 2;
	// mr r4,r11
	ctx.r4.u64 = ctx.r11.u64;
	// bl 0x8b0900d0
	ctx.lr = 0x8B0D15C4;
	sub_8B0900D0(ctx, base);
	// cmplwi r3,0
	ctx.cr0.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq 0x8b0d1594
	if (ctx.cr0.eq) goto loc_8B0D1594;
	// stw r3,0(r30)
	REX_STORE_U32(ctx.r30.u32 + 0, ctx.r3.u32);
loc_8B0D15D0:
	// lwz r11,0(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 0);
	// rlwinm r11,r11,1,0,30
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 1) & 0xFFFFFFFE;
	// stw r11,0(r31)
	REX_STORE_U32(ctx.r31.u32 + 0, ctx.r11.u32);
loc_8B0D15DC:
	// li r3,1
	ctx.r3.s64 = 1;
loc_8B0D15E0:
	// addi r1,r1,128
	ctx.r1.s64 = ctx.r1.s64 + 128;
	// b 0x8b0cba08
	__restgprlr_28(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0D2830) {
	REX_FUNC_PROLOGUE();
	// stfd f1,16(r1)
	ctx.fpscr.disableFlushMode();
	REX_STORE_U64(ctx.r1.u32 + 16, ctx.f1.u64);
	// lhz r11,16(r1)
	ctx.r11.u64 = REX_LOAD_U16(ctx.r1.u32 + 16);
	// rlwinm r11,r11,28,21,31
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 28) & 0x7FF;
	// addi r11,r11,-1022
	ctx.r11.s64 = ctx.r11.s64 + -1022;
	// extsh r3,r11
	ctx.r3.s64 = ctx.r11.s16;
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0D2848) {
	REX_FUNC_PROLOGUE();
	// lis r11,-29943
	ctx.r11.s64 = -1962344448;
	// stfd f1,16(r1)
	ctx.fpscr.disableFlushMode();
	REX_STORE_U64(ctx.r1.u32 + 16, ctx.f1.u64);
	// lfd f0,-32656(r11)
	ctx.f0.u64 = REX_LOAD_U64(ctx.r11.u32 + -32656);
	// fcmpu cr6,f1,f0
	ctx.cr6.compare(ctx.f1.f64, ctx.f0.f64);
	// bne cr6,0x8b0d2864
	if (!ctx.cr6.eq) goto loc_8B0D2864;
	// li r9,0
	ctx.r9.s64 = 0;
	// b 0x8b0d2934
	goto loc_8B0D2934;
loc_8B0D2864:
	// lhz r11,16(r1)
	ctx.r11.u64 = REX_LOAD_U16(ctx.r1.u32 + 16);
	// rlwinm. r9,r11,0,17,27
	ctx.r9.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 0) & 0x7FF0;
	ctx.cr0.compare<int32_t>(ctx.r9.s32, 0, ctx.xer);
	// bne 0x8b0d290c
	if (!ctx.cr0.eq) goto loc_8B0D290C;
	// lwz r8,16(r1)
	ctx.r8.u64 = REX_LOAD_U32(ctx.r1.u32 + 16);
	// lwz r10,20(r1)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r1.u32 + 20);
	// clrlwi. r7,r8,12
	ctx.r7.u64 = ctx.r8.u32 & 0xFFFFF;
	ctx.cr0.compare<int32_t>(ctx.r7.s32, 0, ctx.xer);
	// bne 0x8b0d2888
	if (!ctx.cr0.eq) goto loc_8B0D2888;
	// cmplwi cr6,r10,0
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 0, ctx.xer);
	// beq cr6,0x8b0d290c
	if (ctx.cr6.eq) goto loc_8B0D290C;
loc_8B0D2888:
	// li r9,-1021
	ctx.r9.s64 = -1021;
	// fcmpu cr6,f1,f0
	ctx.fpscr.disableFlushMode();
	ctx.cr6.compare(ctx.f1.f64, ctx.f0.f64);
	// li r7,1
	ctx.r7.s64 = 1;
	// blt cr6,0x8b0d289c
	if (ctx.cr6.lt) goto loc_8B0D289C;
	// li r7,0
	ctx.r7.s64 = 0;
loc_8B0D289C:
	// rlwinm. r6,r11,0,27,27
	ctx.r6.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 0) & 0x10;
	ctx.cr0.compare<int32_t>(ctx.r6.s32, 0, ctx.xer);
	// bne 0x8b0d28d4
	if (!ctx.cr0.eq) goto loc_8B0D28D4;
loc_8B0D28A4:
	// rlwinm r8,r8,1,0,30
	ctx.r8.u64 = __builtin_rotateleft64(ctx.r8.u32 | (ctx.r8.u64 << 32), 1) & 0xFFFFFFFE;
	// rlwinm. r11,r10,0,0,0
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r10.u32 | (ctx.r10.u64 << 32), 0) & 0x80000000;
	ctx.cr0.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// stw r8,16(r1)
	REX_STORE_U32(ctx.r1.u32 + 16, ctx.r8.u32);
	// beq 0x8b0d28bc
	if (ctx.cr0.eq) goto loc_8B0D28BC;
	// ori r8,r8,1
	ctx.r8.u64 = ctx.r8.u64 | 1;
	// stw r8,16(r1)
	REX_STORE_U32(ctx.r1.u32 + 16, ctx.r8.u32);
loc_8B0D28BC:
	// lhz r11,16(r1)
	ctx.r11.u64 = REX_LOAD_U16(ctx.r1.u32 + 16);
	// rlwinm r10,r10,1,0,30
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r10.u32 | (ctx.r10.u64 << 32), 1) & 0xFFFFFFFE;
	// addi r9,r9,-1
	ctx.r9.s64 = ctx.r9.s64 + -1;
	// rlwinm. r6,r11,0,27,27
	ctx.r6.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 0) & 0x10;
	ctx.cr0.compare<int32_t>(ctx.r6.s32, 0, ctx.xer);
	// beq 0x8b0d28a4
	if (ctx.cr0.eq) goto loc_8B0D28A4;
	// stw r10,20(r1)
	REX_STORE_U32(ctx.r1.u32 + 20, ctx.r10.u32);
loc_8B0D28D4:
	// andi. r11,r11,65519
	ctx.r11.u64 = ctx.r11.u64 & 65519;
	ctx.cr0.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// cmpwi cr6,r7,0
	ctx.cr6.compare<int32_t>(ctx.r7.s32, 0, ctx.xer);
	// sth r11,16(r1)
	REX_STORE_U16(ctx.r1.u32 + 16, ctx.r11.u16);
	// beq cr6,0x8b0d28ec
	if (ctx.cr6.eq) goto loc_8B0D28EC;
	// ori r11,r11,32768
	ctx.r11.u64 = ctx.r11.u64 | 32768;
	// sth r11,16(r1)
	REX_STORE_U16(ctx.r1.u32 + 16, ctx.r11.u16);
loc_8B0D28EC:
	// lfd f0,16(r1)
	ctx.fpscr.disableFlushMode();
	ctx.f0.u64 = REX_LOAD_U64(ctx.r1.u32 + 16);
	// stfd f0,-16(r1)
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.f0.u64);
	// lhz r11,-16(r1)
	ctx.r11.u64 = REX_LOAD_U16(ctx.r1.u32 + -16);
	// andi. r11,r11,32783
	ctx.r11.u64 = ctx.r11.u64 & 32783;
	ctx.cr0.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// stfd f0,-16(r1)
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.f0.u64);
	// ori r11,r11,16352
	ctx.r11.u64 = ctx.r11.u64 | 16352;
	// sth r11,-16(r1)
	REX_STORE_U16(ctx.r1.u32 + -16, ctx.r11.u16);
	// b 0x8b0d2930
	goto loc_8B0D2930;
loc_8B0D290C:
	// stfd f1,-16(r1)
	ctx.fpscr.disableFlushMode();
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.f1.u64);
	// lhz r11,-16(r1)
	ctx.r11.u64 = REX_LOAD_U16(ctx.r1.u32 + -16);
	// andi. r11,r11,32783
	ctx.r11.u64 = ctx.r11.u64 & 32783;
	ctx.cr0.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// stfd f1,-16(r1)
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.f1.u64);
	// ori r11,r11,16352
	ctx.r11.u64 = ctx.r11.u64 | 16352;
	// rlwinm r10,r9,28,20,31
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r9.u32 | (ctx.r9.u64 << 32), 28) & 0xFFF;
	// sth r11,-16(r1)
	REX_STORE_U16(ctx.r1.u32 + -16, ctx.r11.u16);
	// mr r11,r10
	ctx.r11.u64 = ctx.r10.u64;
	// addi r9,r10,-1022
	ctx.r9.s64 = ctx.r10.s64 + -1022;
loc_8B0D2930:
	// lfd f1,-16(r1)
	ctx.fpscr.disableFlushMode();
	ctx.f1.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
loc_8B0D2934:
	// stw r9,0(r4)
	REX_STORE_U32(ctx.r4.u32 + 0, ctx.r9.u32);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0D3538) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9a4
	ctx.lr = 0x8B0D3540;
	__savegprlr_23(ctx, base);
	// stwu r1,-160(r1)
	ea = -160 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// mr r25,r3
	ctx.r25.u64 = ctx.r3.u64;
	// mr r23,r4
	ctx.r23.u64 = ctx.r4.u64;
	// mr r28,r5
	ctx.r28.u64 = ctx.r5.u64;
	// mr r24,r6
	ctx.r24.u64 = ctx.r6.u64;
	// cmplwi cr6,r4,0
	ctx.cr6.compare<uint32_t>(ctx.r4.u32, 0, ctx.xer);
	// beq cr6,0x8b0d3560
	if (ctx.cr6.eq) goto loc_8B0D3560;
	// stw r3,0(r4)
	REX_STORE_U32(ctx.r4.u32 + 0, ctx.r3.u32);
loc_8B0D3560:
	// cmplwi cr6,r25,0
	ctx.cr6.compare<uint32_t>(ctx.r25.u32, 0, ctx.xer);
	// bne cr6,0x8b0d3594
	if (!ctx.cr6.eq) goto loc_8B0D3594;
loc_8B0D3568:
	// bl 0x8b0d0288
	ctx.lr = 0x8B0D356C;
	sub_8B0D0288(ctx, base);
	// li r11,22
	ctx.r11.s64 = 22;
	// li r7,0
	ctx.r7.s64 = 0;
	// stw r11,0(r3)
	REX_STORE_U32(ctx.r3.u32 + 0, ctx.r11.u32);
	// li r6,0
	ctx.r6.s64 = 0;
	// li r5,0
	ctx.r5.s64 = 0;
	// li r4,0
	ctx.r4.s64 = 0;
	// li r3,0
	ctx.r3.s64 = 0;
	// bl 0x8b0d0148
	ctx.lr = 0x8B0D358C;
	sub_8B0D0148(ctx, base);
	// li r3,0
	ctx.r3.s64 = 0;
	// b 0x8b0d37cc
	goto loc_8B0D37CC;
loc_8B0D3594:
	// cmpwi cr6,r28,0
	ctx.cr6.compare<int32_t>(ctx.r28.s32, 0, ctx.xer);
	// beq cr6,0x8b0d35ac
	if (ctx.cr6.eq) goto loc_8B0D35AC;
	// cmpwi cr6,r28,2
	ctx.cr6.compare<int32_t>(ctx.r28.s32, 2, ctx.xer);
	// blt cr6,0x8b0d3568
	if (ctx.cr6.lt) goto loc_8B0D3568;
	// cmpwi cr6,r28,36
	ctx.cr6.compare<int32_t>(ctx.r28.s32, 36, ctx.xer);
	// bgt cr6,0x8b0d3568
	if (ctx.cr6.gt) goto loc_8B0D3568;
loc_8B0D35AC:
	// lis r11,-29938
	ctx.r11.s64 = -1962016768;
	// lhz r31,0(r25)
	ctx.r31.u64 = REX_LOAD_U16(ctx.r25.u32 + 0);
	// li r27,0
	ctx.r27.s64 = 0;
	// addi r30,r11,12512
	ctx.r30.s64 = ctx.r11.s64 + 12512;
	// addi r29,r25,2
	ctx.r29.s64 = ctx.r25.s64 + 2;
	// b 0x8b0d35cc
	goto loc_8B0D35CC;
loc_8B0D35C4:
	// lhz r31,0(r29)
	ctx.r31.u64 = REX_LOAD_U16(ctx.r29.u32 + 0);
	// addi r29,r29,2
	ctx.r29.s64 = ctx.r29.s64 + 2;
loc_8B0D35CC:
	// mr r5,r30
	ctx.r5.u64 = ctx.r30.u64;
	// li r4,8
	ctx.r4.s64 = 8;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0d4990
	ctx.lr = 0x8B0D35DC;
	sub_8B0D4990(ctx, base);
	// cmpwi r3,0
	ctx.cr0.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// bne 0x8b0d35c4
	if (!ctx.cr0.eq) goto loc_8B0D35C4;
	// clrlwi r11,r31,16
	ctx.r11.u64 = ctx.r31.u32 & 0xFFFF;
	// cmplwi cr6,r11,45
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 45, ctx.xer);
	// bne cr6,0x8b0d35f8
	if (!ctx.cr6.eq) goto loc_8B0D35F8;
	// ori r24,r24,2
	ctx.r24.u64 = ctx.r24.u64 | 2;
	// b 0x8b0d3600
	goto loc_8B0D3600;
loc_8B0D35F8:
	// cmplwi cr6,r11,43
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 43, ctx.xer);
	// bne cr6,0x8b0d3608
	if (!ctx.cr6.eq) goto loc_8B0D3608;
loc_8B0D3600:
	// lhz r31,0(r29)
	ctx.r31.u64 = REX_LOAD_U16(ctx.r29.u32 + 0);
	// addi r29,r29,2
	ctx.r29.s64 = ctx.r29.s64 + 2;
loc_8B0D3608:
	// cmpwi cr6,r28,0
	ctx.cr6.compare<int32_t>(ctx.r28.s32, 0, ctx.xer);
	// bne cr6,0x8b0d3648
	if (!ctx.cr6.eq) goto loc_8B0D3648;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0d7e30
	ctx.lr = 0x8B0D3618;
	sub_8B0D7E30(ctx, base);
	// cmpwi r3,0
	ctx.cr0.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// beq 0x8b0d3628
	if (ctx.cr0.eq) goto loc_8B0D3628;
	// li r28,10
	ctx.r28.s64 = 10;
	// b 0x8b0d367c
	goto loc_8B0D367C;
loc_8B0D3628:
	// lhz r11,0(r29)
	ctx.r11.u64 = REX_LOAD_U16(ctx.r29.u32 + 0);
	// cmplwi cr6,r11,120
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 120, ctx.xer);
	// beq cr6,0x8b0d3644
	if (ctx.cr6.eq) goto loc_8B0D3644;
	// cmplwi cr6,r11,88
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 88, ctx.xer);
	// beq cr6,0x8b0d3644
	if (ctx.cr6.eq) goto loc_8B0D3644;
	// li r28,8
	ctx.r28.s64 = 8;
	// b 0x8b0d367c
	goto loc_8B0D367C;
loc_8B0D3644:
	// li r28,16
	ctx.r28.s64 = 16;
loc_8B0D3648:
	// cmpwi cr6,r28,16
	ctx.cr6.compare<int32_t>(ctx.r28.s32, 16, ctx.xer);
	// bne cr6,0x8b0d367c
	if (!ctx.cr6.eq) goto loc_8B0D367C;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0d7e30
	ctx.lr = 0x8B0D3658;
	sub_8B0D7E30(ctx, base);
	// cmpwi r3,0
	ctx.cr0.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// bne 0x8b0d367c
	if (!ctx.cr0.eq) goto loc_8B0D367C;
	// lhz r11,0(r29)
	ctx.r11.u64 = REX_LOAD_U16(ctx.r29.u32 + 0);
	// cmplwi cr6,r11,120
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 120, ctx.xer);
	// beq cr6,0x8b0d3674
	if (ctx.cr6.eq) goto loc_8B0D3674;
	// cmplwi cr6,r11,88
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 88, ctx.xer);
	// bne cr6,0x8b0d367c
	if (!ctx.cr6.eq) goto loc_8B0D367C;
loc_8B0D3674:
	// lhzu r31,2(r29)
	ea = 2 + ctx.r29.u32;
	ctx.r31.u64 = REX_LOAD_U16(ea);
	ctx.r29.u32 = ea;
	// addi r29,r29,2
	ctx.r29.s64 = ctx.r29.s64 + 2;
loc_8B0D367C:
	// li r26,-1
	ctx.r26.s64 = -1;
	// twllei r28,0
	if (ctx.r28.s32 == 0 || ctx.r28.u32 < 0u) ppc_trap(ctx, base, 0);
	// divwu r30,r26,r28
	ctx.r30.u64 = uint32_t(ctx.r28.u32 ? ctx.r26.u32 / ctx.r28.u32 : 0);
loc_8B0D3688:
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0d7e30
	ctx.lr = 0x8B0D3690;
	sub_8B0D7E30(ctx, base);
	// cmpwi cr6,r3,-1
	ctx.cr6.compare<int32_t>(ctx.r3.s32, -1, ctx.xer);
	// bne cr6,0x8b0d36d4
	if (!ctx.cr6.eq) goto loc_8B0D36D4;
	// clrlwi r11,r31,16
	ctx.r11.u64 = ctx.r31.u32 & 0xFFFF;
	// cmplwi cr6,r11,65
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 65, ctx.xer);
	// blt cr6,0x8b0d36ac
	if (ctx.cr6.lt) goto loc_8B0D36AC;
	// cmplwi cr6,r11,90
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 90, ctx.xer);
	// ble cr6,0x8b0d36bc
	if (!ctx.cr6.gt) goto loc_8B0D36BC;
loc_8B0D36AC:
	// cmplwi cr6,r11,97
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 97, ctx.xer);
	// blt cr6,0x8b0d3714
	if (ctx.cr6.lt) goto loc_8B0D3714;
	// cmplwi cr6,r11,122
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 122, ctx.xer);
	// bgt cr6,0x8b0d3714
	if (ctx.cr6.gt) goto loc_8B0D3714;
loc_8B0D36BC:
	// cmplwi cr6,r11,97
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 97, ctx.xer);
	// blt cr6,0x8b0d36d0
	if (ctx.cr6.lt) goto loc_8B0D36D0;
	// cmplwi cr6,r11,122
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 122, ctx.xer);
	// bgt cr6,0x8b0d36d0
	if (ctx.cr6.gt) goto loc_8B0D36D0;
	// addi r11,r11,-32
	ctx.r11.s64 = ctx.r11.s64 + -32;
loc_8B0D36D0:
	// addi r3,r11,-55
	ctx.r3.s64 = ctx.r11.s64 + -55;
loc_8B0D36D4:
	// cmplw cr6,r3,r28
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, ctx.r28.u32, ctx.xer);
	// bge cr6,0x8b0d3714
	if (!ctx.cr6.lt) goto loc_8B0D3714;
	// ori r24,r24,8
	ctx.r24.u64 = ctx.r24.u64 | 8;
	// cmplw cr6,r27,r30
	ctx.cr6.compare<uint32_t>(ctx.r27.u32, ctx.r30.u32, ctx.xer);
	// blt cr6,0x8b0d3734
	if (ctx.cr6.lt) goto loc_8B0D3734;
	// bne cr6,0x8b0d3708
	if (!ctx.cr6.eq) goto loc_8B0D3708;
	// divwu r10,r26,r28
	ctx.r10.u64 = uint32_t(ctx.r28.u32 ? ctx.r26.u32 / ctx.r28.u32 : 0);
	// mr r11,r26
	ctx.r11.u64 = ctx.r26.u64;
	// mullw r10,r10,r28
	ctx.r10.s64 = int64_t(ctx.r10.s32) * int64_t(ctx.r28.s32);
	// subf r11,r10,r11
	ctx.r11.u64 = ctx.r11.u64 - ctx.r10.u64;
	// twllei r28,0
	if (ctx.r28.s32 == 0 || ctx.r28.u32 < 0u) ppc_trap(ctx, base, 0);
	// cmplw cr6,r3,r11
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, ctx.r11.u32, ctx.xer);
	// ble cr6,0x8b0d3734
	if (!ctx.cr6.gt) goto loc_8B0D3734;
loc_8B0D3708:
	// ori r24,r24,4
	ctx.r24.u64 = ctx.r24.u64 | 4;
	// cmplwi cr6,r23,0
	ctx.cr6.compare<uint32_t>(ctx.r23.u32, 0, ctx.xer);
	// bne cr6,0x8b0d373c
	if (!ctx.cr6.eq) goto loc_8B0D373C;
loc_8B0D3714:
	// rlwinm. r11,r24,0,28,28
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r24.u32 | (ctx.r24.u64 << 32), 0) & 0x8;
	ctx.cr0.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// addi r30,r29,-2
	ctx.r30.s64 = ctx.r29.s64 + -2;
	// bne 0x8b0d3748
	if (!ctx.cr0.eq) goto loc_8B0D3748;
	// cmplwi cr6,r23,0
	ctx.cr6.compare<uint32_t>(ctx.r23.u32, 0, ctx.xer);
	// beq cr6,0x8b0d372c
	if (ctx.cr6.eq) goto loc_8B0D372C;
	// mr r30,r25
	ctx.r30.u64 = ctx.r25.u64;
loc_8B0D372C:
	// li r27,0
	ctx.r27.s64 = 0;
	// b 0x8b0d37b0
	goto loc_8B0D37B0;
loc_8B0D3734:
	// mullw r11,r27,r28
	ctx.r11.s64 = int64_t(ctx.r27.s32) * int64_t(ctx.r28.s32);
	// add r27,r11,r3
	ctx.r27.u64 = ctx.r11.u64 + ctx.r3.u64;
loc_8B0D373C:
	// lhz r31,0(r29)
	ctx.r31.u64 = REX_LOAD_U16(ctx.r29.u32 + 0);
	// addi r29,r29,2
	ctx.r29.s64 = ctx.r29.s64 + 2;
	// b 0x8b0d3688
	goto loc_8B0D3688;
loc_8B0D3748:
	// lis r10,32767
	ctx.r10.s64 = 2147418112;
	// rlwinm. r11,r24,0,29,29
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r24.u32 | (ctx.r24.u64 << 32), 0) & 0x4;
	ctx.cr0.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// ori r31,r10,65535
	ctx.r31.u64 = ctx.r10.u64 | 65535;
	// bne 0x8b0d3784
	if (!ctx.cr0.eq) goto loc_8B0D3784;
	// clrlwi. r11,r24,31
	ctx.r11.u64 = ctx.r24.u32 & 0x1;
	ctx.cr0.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// bne 0x8b0d37b0
	if (!ctx.cr0.eq) goto loc_8B0D37B0;
	// rlwinm. r11,r24,0,30,30
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r24.u32 | (ctx.r24.u64 << 32), 0) & 0x2;
	ctx.cr0.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// beq 0x8b0d3774
	if (ctx.cr0.eq) goto loc_8B0D3774;
	// lis r10,-32768
	ctx.r10.s64 = -2147483648;
	// cmplw cr6,r27,r10
	ctx.cr6.compare<uint32_t>(ctx.r27.u32, ctx.r10.u32, ctx.xer);
	// bgt cr6,0x8b0d3784
	if (ctx.cr6.gt) goto loc_8B0D3784;
loc_8B0D3774:
	// cmpwi cr6,r11,0
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// bne cr6,0x8b0d37b0
	if (!ctx.cr6.eq) goto loc_8B0D37B0;
	// cmplw cr6,r27,r31
	ctx.cr6.compare<uint32_t>(ctx.r27.u32, ctx.r31.u32, ctx.xer);
	// ble cr6,0x8b0d37b0
	if (!ctx.cr6.gt) goto loc_8B0D37B0;
loc_8B0D3784:
	// bl 0x8b0d0288
	ctx.lr = 0x8B0D3788;
	sub_8B0D0288(ctx, base);
	// li r11,34
	ctx.r11.s64 = 34;
	// clrlwi. r10,r24,31
	ctx.r10.u64 = ctx.r24.u32 & 0x1;
	ctx.cr0.compare<int32_t>(ctx.r10.s32, 0, ctx.xer);
	// stw r11,0(r3)
	REX_STORE_U32(ctx.r3.u32 + 0, ctx.r11.u32);
	// beq 0x8b0d37a0
	if (ctx.cr0.eq) goto loc_8B0D37A0;
	// mr r27,r26
	ctx.r27.u64 = ctx.r26.u64;
	// b 0x8b0d37b0
	goto loc_8B0D37B0;
loc_8B0D37A0:
	// rlwinm. r11,r24,0,30,30
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r24.u32 | (ctx.r24.u64 << 32), 0) & 0x2;
	ctx.cr0.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// lis r27,-32768
	ctx.r27.s64 = -2147483648;
	// bne 0x8b0d37b0
	if (!ctx.cr0.eq) goto loc_8B0D37B0;
	// mr r27,r31
	ctx.r27.u64 = ctx.r31.u64;
loc_8B0D37B0:
	// cmplwi cr6,r23,0
	ctx.cr6.compare<uint32_t>(ctx.r23.u32, 0, ctx.xer);
	// beq cr6,0x8b0d37bc
	if (ctx.cr6.eq) goto loc_8B0D37BC;
	// stw r30,0(r23)
	REX_STORE_U32(ctx.r23.u32 + 0, ctx.r30.u32);
loc_8B0D37BC:
	// rlwinm. r11,r24,0,30,30
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r24.u32 | (ctx.r24.u64 << 32), 0) & 0x2;
	ctx.cr0.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// beq 0x8b0d37c8
	if (ctx.cr0.eq) goto loc_8B0D37C8;
	// neg r27,r27
	ctx.r27.s64 = static_cast<int64_t>(-ctx.r27.u64);
loc_8B0D37C8:
	// mr r3,r27
	ctx.r3.u64 = ctx.r27.u64;
loc_8B0D37CC:
	// addi r1,r1,160
	ctx.r1.s64 = ctx.r1.s64 + 160;
	// b 0x8b0cb9f4
	__restgprlr_23(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0D48D8) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9b4
	ctx.lr = 0x8B0D48E0;
	__savegprlr_27(ctx, base);
	// stwu r1,-160(r1)
	ea = -160 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// mr r29,r3
	ctx.r29.u64 = ctx.r3.u64;
	// mr r28,r4
	ctx.r28.u64 = ctx.r4.u64;
	// mr r10,r8
	ctx.r10.u64 = ctx.r8.u64;
	// mr r5,r4
	ctx.r5.u64 = ctx.r4.u64;
	// li r27,0
	ctx.r27.s64 = 0;
	// li r9,0
	ctx.r9.s64 = 0;
	// li r8,0
	ctx.r8.s64 = 0;
	// li r7,0
	ctx.r7.s64 = 0;
	// li r6,0
	ctx.r6.s64 = 0;
	// addi r4,r1,80
	ctx.r4.s64 = ctx.r1.s64 + 80;
	// addi r3,r1,96
	ctx.r3.s64 = ctx.r1.s64 + 96;
	// mr r30,r27
	ctx.r30.u64 = ctx.r27.u64;
	// bl 0x8b0d4a10
	ctx.lr = 0x8B0D4918;
	sub_8B0D4A10(ctx, base);
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// rlwinm. r11,r3,0,29,29
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r3.u32 | (ctx.r3.u64 << 32), 0) & 0x4;
	ctx.cr0.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// beq 0x8b0d4934
	if (ctx.cr0.eq) goto loc_8B0D4934;
	// li r30,512
	ctx.r30.s64 = 512;
	// stw r27,88(r1)
	REX_STORE_U32(ctx.r1.u32 + 88, ctx.r27.u32);
	// stw r27,92(r1)
	REX_STORE_U32(ctx.r1.u32 + 92, ctx.r27.u32);
	// b 0x8b0d4968
	goto loc_8B0D4968;
loc_8B0D4934:
	// addi r4,r1,88
	ctx.r4.s64 = ctx.r1.s64 + 88;
	// addi r3,r1,96
	ctx.r3.s64 = ctx.r1.s64 + 96;
	// bl 0x8b0d8908
	ctx.lr = 0x8B0D4940;
	sub_8B0D8908(ctx, base);
	// rlwinm. r11,r31,0,30,30
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r31.u32 | (ctx.r31.u64 << 32), 0) & 0x2;
	ctx.cr0.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// bne 0x8b0d4950
	if (!ctx.cr0.eq) goto loc_8B0D4950;
	// cmpwi cr6,r3,1
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 1, ctx.xer);
	// bne cr6,0x8b0d4954
	if (!ctx.cr6.eq) goto loc_8B0D4954;
loc_8B0D4950:
	// li r30,128
	ctx.r30.s64 = 128;
loc_8B0D4954:
	// clrlwi. r11,r31,31
	ctx.r11.u64 = ctx.r31.u32 & 0x1;
	ctx.cr0.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// bne 0x8b0d4964
	if (!ctx.cr0.eq) goto loc_8B0D4964;
	// cmpwi cr6,r3,2
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 2, ctx.xer);
	// bne cr6,0x8b0d4968
	if (!ctx.cr6.eq) goto loc_8B0D4968;
loc_8B0D4964:
	// ori r30,r30,256
	ctx.r30.u64 = ctx.r30.u64 | 256;
loc_8B0D4968:
	// lwz r11,80(r1)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r1.u32 + 80);
	// mr r3,r29
	ctx.r3.u64 = ctx.r29.u64;
	// ld r10,88(r1)
	ctx.r10.u64 = REX_LOAD_U64(ctx.r1.u32 + 88);
	// subf r11,r28,r11
	ctx.r11.u64 = ctx.r11.u64 - ctx.r28.u64;
	// stw r30,0(r29)
	REX_STORE_U32(ctx.r29.u32 + 0, ctx.r30.u32);
	// srawi r11,r11,1
	ctx.xer.ca = (ctx.r11.s32 < 0) & ((ctx.r11.u32 & 0x1) != 0);
	ctx.r11.s64 = ctx.r11.s32 >> 1;
	// std r10,16(r29)
	REX_STORE_U64(ctx.r29.u32 + 16, ctx.r10.u64);
	// stw r11,4(r29)
	REX_STORE_U32(ctx.r29.u32 + 4, ctx.r11.u32);
	// addi r1,r1,160
	ctx.r1.s64 = ctx.r1.s64 + 160;
	// b 0x8b0cba04
	__restgprlr_27(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0D4990) {
	REX_FUNC_PROLOGUE();
	// clrlwi r11,r3,16
	ctx.r11.u64 = ctx.r3.u32 & 0xFFFF;
	// cmplwi cr6,r11,65535
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 65535, ctx.xer);
	// beq cr6,0x8b0d49c0
	if (ctx.cr6.eq) goto loc_8B0D49C0;
	// cmplwi cr6,r11,256
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 256, ctx.xer);
	// bge cr6,0x8b0d49c0
	if (!ctx.cr6.lt) goto loc_8B0D49C0;
	// lis r10,-29938
	ctx.r10.s64 = -1962016768;
	// rlwinm r9,r11,1,0,30
	ctx.r9.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 1) & 0xFFFFFFFE;
	// clrlwi r8,r4,16
	ctx.r8.u64 = ctx.r4.u32 & 0xFFFF;
	// lwz r11,14352(r10)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r10.u32 + 14352);
	// lhzx r11,r9,r11
	ctx.r11.u64 = REX_LOAD_U16(ctx.r9.u32 + ctx.r11.u32);
	// and r11,r11,r8
	ctx.r11.u64 = ctx.r11.u64 & ctx.r8.u64;
	// b 0x8b0d49c4
	goto loc_8B0D49C4;
loc_8B0D49C0:
	// li r11,0
	ctx.r11.s64 = 0;
loc_8B0D49C4:
	// clrlwi r11,r11,16
	ctx.r11.u64 = ctx.r11.u32 & 0xFFFF;
	// clrlwi r10,r4,16
	ctx.r10.u64 = ctx.r4.u32 & 0xFFFF;
	// and r3,r11,r10
	ctx.r3.u64 = ctx.r11.u64 & ctx.r10.u64;
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0D49D8) {
	REX_FUNC_PROLOGUE();
	// clrlwi r11,r3,16
	ctx.r11.u64 = ctx.r3.u32 & 0xFFFF;
	// cmplwi cr6,r11,65535
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 65535, ctx.xer);
	// beq cr6,0x8b0d4a08
	if (ctx.cr6.eq) goto loc_8B0D4A08;
	// cmplwi cr6,r11,256
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 256, ctx.xer);
	// bge cr6,0x8b0d4a08
	if (!ctx.cr6.lt) goto loc_8B0D4A08;
	// lis r10,-29938
	ctx.r10.s64 = -1962016768;
	// rlwinm r9,r11,1,0,30
	ctx.r9.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 1) & 0xFFFFFFFE;
	// clrlwi r8,r4,16
	ctx.r8.u64 = ctx.r4.u32 & 0xFFFF;
	// lwz r11,14352(r10)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r10.u32 + 14352);
	// lhzx r11,r9,r11
	ctx.r11.u64 = REX_LOAD_U16(ctx.r9.u32 + ctx.r11.u32);
	// and r3,r11,r8
	ctx.r3.u64 = ctx.r11.u64 & ctx.r8.u64;
	// blr 
	return;
loc_8B0D4A08:
	// li r3,0
	ctx.r3.s64 = 0;
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0D4A10) {
	REX_FUNC_PROLOGUE();
	PPCRegister temp{};
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb994
	ctx.lr = 0x8B0D4A18;
	__savegprlr_19(ctx, base);
	// stwu r1,-272(r1)
	ea = -272 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// li r22,0
	ctx.r22.s64 = 0;
	// mr r20,r3
	ctx.r20.u64 = ctx.r3.u64;
	// mr r23,r6
	ctx.r23.u64 = ctx.r6.u64;
	// mr r25,r7
	ctx.r25.u64 = ctx.r7.u64;
	// mr r24,r8
	ctx.r24.u64 = ctx.r8.u64;
	// addi r3,r1,128
	ctx.r3.s64 = ctx.r1.s64 + 128;
	// mr r19,r22
	ctx.r19.u64 = ctx.r22.u64;
	// mr r6,r22
	ctx.r6.u64 = ctx.r22.u64;
	// mr r30,r22
	ctx.r30.u64 = ctx.r22.u64;
	// mr r26,r22
	ctx.r26.u64 = ctx.r22.u64;
	// mr r28,r22
	ctx.r28.u64 = ctx.r22.u64;
	// mr r29,r22
	ctx.r29.u64 = ctx.r22.u64;
	// mr r31,r22
	ctx.r31.u64 = ctx.r22.u64;
	// li r27,1
	ctx.r27.s64 = 1;
	// mr r11,r22
	ctx.r11.u64 = ctx.r22.u64;
	// cmplwi cr6,r10,0
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 0, ctx.xer);
	// bne cr6,0x8b0d4a8c
	if (!ctx.cr6.eq) goto loc_8B0D4A8C;
	// bl 0x8b0d0288
	ctx.lr = 0x8B0D4A64;
	sub_8B0D0288(ctx, base);
	// li r11,22
	ctx.r11.s64 = 22;
	// li r7,0
	ctx.r7.s64 = 0;
	// stw r11,0(r3)
	REX_STORE_U32(ctx.r3.u32 + 0, ctx.r11.u32);
	// li r6,0
	ctx.r6.s64 = 0;
	// li r5,0
	ctx.r5.s64 = 0;
	// li r4,0
	ctx.r4.s64 = 0;
	// li r3,0
	ctx.r3.s64 = 0;
	// bl 0x8b0d0148
	ctx.lr = 0x8B0D4A84;
	sub_8B0D0148(ctx, base);
	// li r3,0
	ctx.r3.s64 = 0;
	// b 0x8b0d534c
	goto loc_8B0D534C;
loc_8B0D4A8C:
	// mr r8,r5
	ctx.r8.u64 = ctx.r5.u64;
loc_8B0D4A90:
	// lhz r10,0(r8)
	ctx.r10.u64 = REX_LOAD_U16(ctx.r8.u32 + 0);
	// cmplwi cr6,r10,32
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 32, ctx.xer);
	// beq cr6,0x8b0d4ab4
	if (ctx.cr6.eq) goto loc_8B0D4AB4;
	// cmplwi cr6,r10,9
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 9, ctx.xer);
	// beq cr6,0x8b0d4ab4
	if (ctx.cr6.eq) goto loc_8B0D4AB4;
	// cmplwi cr6,r10,10
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 10, ctx.xer);
	// beq cr6,0x8b0d4ab4
	if (ctx.cr6.eq) goto loc_8B0D4AB4;
	// cmplwi cr6,r10,13
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 13, ctx.xer);
	// bne cr6,0x8b0d4abc
	if (!ctx.cr6.eq) goto loc_8B0D4ABC;
loc_8B0D4AB4:
	// addi r8,r8,2
	ctx.r8.s64 = ctx.r8.s64 + 2;
	// b 0x8b0d4a90
	goto loc_8B0D4A90;
loc_8B0D4ABC:
	// lis r10,-29938
	ctx.r10.s64 = -1962016768;
	// lis r7,0
	ctx.r7.s64 = 0;
	// ori r21,r7,32768
	ctx.r21.u64 = ctx.r7.u64 | 32768;
	// lwz r7,13620(r10)
	ctx.r7.u64 = REX_LOAD_U32(ctx.r10.u32 + 13620);
loc_8B0D4ACC:
	// lhz r10,0(r8)
	ctx.r10.u64 = REX_LOAD_U16(ctx.r8.u32 + 0);
	// addi r8,r8,2
	ctx.r8.s64 = ctx.r8.s64 + 2;
	// cmplwi cr6,r11,11
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 11, ctx.xer);
	// bgt cr6,0x8b0d4e38
	if (ctx.cr6.gt) goto loc_8B0D4E38;
	// lis r12,-29943
	ctx.r12.s64 = -1962344448;
	// addi r12,r12,-22144
	ctx.r12.s64 = ctx.r12.s64 + -22144;
	// lbzx r0,r12,r11
	ctx.r0.u64 = REX_LOAD_U8(ctx.r12.u32 + ctx.r11.u32);
	// rlwinm r0,r0,2,0,29
	ctx.r0.u64 = __builtin_rotateleft64(ctx.r0.u32 | (ctx.r0.u64 << 32), 2) & 0xFFFFFFFC;
	// lis r12,-29939
	ctx.r12.s64 = -1962082304;
	// nop 
	// addi r12,r12,19204
	ctx.r12.s64 = ctx.r12.s64 + 19204;
	// add r12,r12,r0
	ctx.r12.u64 = ctx.r12.u64 + ctx.r0.u64;
	// mtctr r12
	ctx.ctr.u64 = ctx.r12.u64;
	// bctr 
	switch (ctx.r11.u32) {
	case 0:
		goto loc_8B0D4B04;
	case 1:
		goto loc_8B0D4B78;
	case 2:
		goto loc_8B0D4BF8;
	case 3:
		goto loc_8B0D4C74;
	case 4:
		goto loc_8B0D4CE0;
	case 5:
		goto loc_8B0D4D50;
	case 6:
		goto loc_8B0D4D70;
	case 7:
		goto loc_8B0D4DEC;
	case 8:
		goto loc_8B0D4DB8;
	case 9:
		goto loc_8B0D4E44;
	case 10:
		goto loc_8B0D4E38;
	case 11:
		goto loc_8B0D4E04;
	default:
		__builtin_trap(); // Switch case out of range
	}
loc_8B0D4B04:
	// clrlwi r11,r10,16
	ctx.r11.u64 = ctx.r10.u32 & 0xFFFF;
	// cmplwi cr6,r11,49
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 49, ctx.xer);
	// blt cr6,0x8b0d4b24
	if (ctx.cr6.lt) goto loc_8B0D4B24;
	// cmplwi cr6,r11,57
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 57, ctx.xer);
	// bgt cr6,0x8b0d4b24
	if (ctx.cr6.gt) goto loc_8B0D4B24;
loc_8B0D4B18:
	// li r11,3
	ctx.r11.s64 = 3;
loc_8B0D4B1C:
	// addi r8,r8,-2
	ctx.r8.s64 = ctx.r8.s64 + -2;
	// b 0x8b0d4acc
	goto loc_8B0D4ACC;
loc_8B0D4B24:
	// lwz r10,0(r7)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r7.u32 + 0);
	// lbz r10,0(r10)
	ctx.r10.u64 = REX_LOAD_U8(ctx.r10.u32 + 0);
	// extsb r10,r10
	ctx.r10.s64 = ctx.r10.s8;
	// cmpw cr6,r11,r10
	ctx.cr6.compare<int32_t>(ctx.r11.s32, ctx.r10.s32, ctx.xer);
	// bne cr6,0x8b0d4b40
	if (!ctx.cr6.eq) goto loc_8B0D4B40;
loc_8B0D4B38:
	// li r11,5
	ctx.r11.s64 = 5;
	// b 0x8b0d4acc
	goto loc_8B0D4ACC;
loc_8B0D4B40:
	// cmpwi cr6,r11,43
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 43, ctx.xer);
	// beq cr6,0x8b0d4b6c
	if (ctx.cr6.eq) goto loc_8B0D4B6C;
	// cmpwi cr6,r11,45
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 45, ctx.xer);
	// beq cr6,0x8b0d4b60
	if (ctx.cr6.eq) goto loc_8B0D4B60;
	// cmpwi cr6,r11,48
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 48, ctx.xer);
	// bne cr6,0x8b0d4de4
	if (!ctx.cr6.eq) goto loc_8B0D4DE4;
loc_8B0D4B58:
	// li r11,1
	ctx.r11.s64 = 1;
	// b 0x8b0d4acc
	goto loc_8B0D4ACC;
loc_8B0D4B60:
	// li r11,2
	ctx.r11.s64 = 2;
	// mr r19,r21
	ctx.r19.u64 = ctx.r21.u64;
	// b 0x8b0d4acc
	goto loc_8B0D4ACC;
loc_8B0D4B6C:
	// li r11,2
	ctx.r11.s64 = 2;
	// mr r19,r22
	ctx.r19.u64 = ctx.r22.u64;
	// b 0x8b0d4acc
	goto loc_8B0D4ACC;
loc_8B0D4B78:
	// clrlwi r11,r10,16
	ctx.r11.u64 = ctx.r10.u32 & 0xFFFF;
	// li r30,1
	ctx.r30.s64 = 1;
	// cmplwi cr6,r11,49
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 49, ctx.xer);
	// blt cr6,0x8b0d4b90
	if (ctx.cr6.lt) goto loc_8B0D4B90;
	// cmplwi cr6,r11,57
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 57, ctx.xer);
	// ble cr6,0x8b0d4b18
	if (!ctx.cr6.gt) goto loc_8B0D4B18;
loc_8B0D4B90:
	// lwz r10,0(r7)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r7.u32 + 0);
	// lbz r10,0(r10)
	ctx.r10.u64 = REX_LOAD_U8(ctx.r10.u32 + 0);
	// extsb r10,r10
	ctx.r10.s64 = ctx.r10.s8;
	// cmpw cr6,r11,r10
	ctx.cr6.compare<int32_t>(ctx.r11.s32, ctx.r10.s32, ctx.xer);
	// bne cr6,0x8b0d4bac
	if (!ctx.cr6.eq) goto loc_8B0D4BAC;
loc_8B0D4BA4:
	// li r11,4
	ctx.r11.s64 = 4;
	// b 0x8b0d4acc
	goto loc_8B0D4ACC;
loc_8B0D4BAC:
	// cmpwi cr6,r11,43
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 43, ctx.xer);
	// beq cr6,0x8b0d4bec
	if (ctx.cr6.eq) goto loc_8B0D4BEC;
	// cmpwi cr6,r11,45
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 45, ctx.xer);
	// beq cr6,0x8b0d4bec
	if (ctx.cr6.eq) goto loc_8B0D4BEC;
	// cmpwi cr6,r11,48
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 48, ctx.xer);
	// beq cr6,0x8b0d4b58
	if (ctx.cr6.eq) goto loc_8B0D4B58;
loc_8B0D4BC4:
	// cmpwi cr6,r11,67
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 67, ctx.xer);
	// ble cr6,0x8b0d4de4
	if (!ctx.cr6.gt) goto loc_8B0D4DE4;
	// cmpwi cr6,r11,69
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 69, ctx.xer);
	// ble cr6,0x8b0d4be4
	if (!ctx.cr6.gt) goto loc_8B0D4BE4;
	// cmpwi cr6,r11,99
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 99, ctx.xer);
	// ble cr6,0x8b0d4de4
	if (!ctx.cr6.gt) goto loc_8B0D4DE4;
	// cmpwi cr6,r11,101
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 101, ctx.xer);
	// bgt cr6,0x8b0d4de4
	if (ctx.cr6.gt) goto loc_8B0D4DE4;
loc_8B0D4BE4:
	// li r11,6
	ctx.r11.s64 = 6;
	// b 0x8b0d4acc
	goto loc_8B0D4ACC;
loc_8B0D4BEC:
	// addi r8,r8,-2
	ctx.r8.s64 = ctx.r8.s64 + -2;
	// li r11,11
	ctx.r11.s64 = 11;
	// b 0x8b0d4acc
	goto loc_8B0D4ACC;
loc_8B0D4BF8:
	// clrlwi r11,r10,16
	ctx.r11.u64 = ctx.r10.u32 & 0xFFFF;
	// cmplwi cr6,r11,49
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 49, ctx.xer);
	// blt cr6,0x8b0d4c0c
	if (ctx.cr6.lt) goto loc_8B0D4C0C;
	// cmplwi cr6,r11,57
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 57, ctx.xer);
	// ble cr6,0x8b0d4b18
	if (!ctx.cr6.gt) goto loc_8B0D4B18;
loc_8B0D4C0C:
	// lwz r10,0(r7)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r7.u32 + 0);
	// lbz r10,0(r10)
	ctx.r10.u64 = REX_LOAD_U8(ctx.r10.u32 + 0);
	// extsb r10,r10
	ctx.r10.s64 = ctx.r10.s8;
	// cmpw cr6,r11,r10
	ctx.cr6.compare<int32_t>(ctx.r11.s32, ctx.r10.s32, ctx.xer);
	// beq cr6,0x8b0d4b38
	if (ctx.cr6.eq) goto loc_8B0D4B38;
	// cmpwi cr6,r11,48
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 48, ctx.xer);
	// beq cr6,0x8b0d4b58
	if (ctx.cr6.eq) goto loc_8B0D4B58;
loc_8B0D4C28:
	// mr r8,r5
	ctx.r8.u64 = ctx.r5.u64;
loc_8B0D4C2C:
	// stw r8,0(r4)
	REX_STORE_U32(ctx.r4.u32 + 0, ctx.r8.u32);
	// cmpwi cr6,r30,0
	ctx.cr6.compare<int32_t>(ctx.r30.s32, 0, ctx.xer);
	// beq cr6,0x8b0d52e8
	if (ctx.cr6.eq) goto loc_8B0D52E8;
	// cmplwi cr6,r6,24
	ctx.cr6.compare<uint32_t>(ctx.r6.u32, 24, ctx.xer);
	// ble cr6,0x8b0d4c64
	if (!ctx.cr6.gt) goto loc_8B0D4C64;
	// lbz r11,151(r1)
	ctx.r11.u64 = REX_LOAD_U8(ctx.r1.u32 + 151);
	// extsb r11,r11
	ctx.r11.s64 = ctx.r11.s8;
	// cmpwi cr6,r11,5
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 5, ctx.xer);
	// blt cr6,0x8b0d4c58
	if (ctx.cr6.lt) goto loc_8B0D4C58;
	// addi r11,r11,1
	ctx.r11.s64 = ctx.r11.s64 + 1;
	// stb r11,151(r1)
	REX_STORE_U8(ctx.r1.u32 + 151, ctx.r11.u8);
loc_8B0D4C58:
	// li r6,24
	ctx.r6.s64 = 24;
	// addi r3,r3,-1
	ctx.r3.s64 = ctx.r3.s64 + -1;
	// addi r31,r31,1
	ctx.r31.s64 = ctx.r31.s64 + 1;
loc_8B0D4C64:
	// cmplwi cr6,r6,0
	ctx.cr6.compare<uint32_t>(ctx.r6.u32, 0, ctx.xer);
	// beq cr6,0x8b0d52d4
	if (ctx.cr6.eq) goto loc_8B0D52D4;
	// lbzu r11,-1(r3)
	ea = -1 + ctx.r3.u32;
	ctx.r11.u64 = REX_LOAD_U8(ea);
	ctx.r3.u32 = ea;
	// b 0x8b0d4eb8
	goto loc_8B0D4EB8;
loc_8B0D4C74:
	// clrlwi r11,r10,16
	ctx.r11.u64 = ctx.r10.u32 & 0xFFFF;
	// li r30,1
	ctx.r30.s64 = 1;
	// b 0x8b0d4cb0
	goto loc_8B0D4CB0;
loc_8B0D4C80:
	// cmplwi cr6,r11,57
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 57, ctx.xer);
	// bgt cr6,0x8b0d4cb8
	if (ctx.cr6.gt) goto loc_8B0D4CB8;
	// cmplwi cr6,r6,25
	ctx.cr6.compare<uint32_t>(ctx.r6.u32, 25, ctx.xer);
	// bge cr6,0x8b0d4ca4
	if (!ctx.cr6.lt) goto loc_8B0D4CA4;
	// addi r11,r11,-48
	ctx.r11.s64 = ctx.r11.s64 + -48;
	// addi r6,r6,1
	ctx.r6.s64 = ctx.r6.s64 + 1;
	// stb r11,0(r3)
	REX_STORE_U8(ctx.r3.u32 + 0, ctx.r11.u8);
	// addi r3,r3,1
	ctx.r3.s64 = ctx.r3.s64 + 1;
	// b 0x8b0d4ca8
	goto loc_8B0D4CA8;
loc_8B0D4CA4:
	// addi r31,r31,1
	ctx.r31.s64 = ctx.r31.s64 + 1;
loc_8B0D4CA8:
	// lhz r11,0(r8)
	ctx.r11.u64 = REX_LOAD_U16(ctx.r8.u32 + 0);
	// addi r8,r8,2
	ctx.r8.s64 = ctx.r8.s64 + 2;
loc_8B0D4CB0:
	// cmplwi cr6,r11,48
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 48, ctx.xer);
	// bge cr6,0x8b0d4c80
	if (!ctx.cr6.lt) goto loc_8B0D4C80;
loc_8B0D4CB8:
	// lwz r10,0(r7)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r7.u32 + 0);
	// lbz r10,0(r10)
	ctx.r10.u64 = REX_LOAD_U8(ctx.r10.u32 + 0);
	// extsb r10,r10
	ctx.r10.s64 = ctx.r10.s8;
	// cmpw cr6,r11,r10
	ctx.cr6.compare<int32_t>(ctx.r11.s32, ctx.r10.s32, ctx.xer);
	// beq cr6,0x8b0d4ba4
	if (ctx.cr6.eq) goto loc_8B0D4BA4;
loc_8B0D4CCC:
	// cmpwi cr6,r11,43
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 43, ctx.xer);
	// beq cr6,0x8b0d4bec
	if (ctx.cr6.eq) goto loc_8B0D4BEC;
	// cmpwi cr6,r11,45
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 45, ctx.xer);
	// beq cr6,0x8b0d4bec
	if (ctx.cr6.eq) goto loc_8B0D4BEC;
	// b 0x8b0d4bc4
	goto loc_8B0D4BC4;
loc_8B0D4CE0:
	// li r30,1
	ctx.r30.s64 = 1;
	// li r26,1
	ctx.r26.s64 = 1;
	// cmplwi cr6,r6,0
	ctx.cr6.compare<uint32_t>(ctx.r6.u32, 0, ctx.xer);
	// bne cr6,0x8b0d4d10
	if (!ctx.cr6.eq) goto loc_8B0D4D10;
	// clrlwi r11,r10,16
	ctx.r11.u64 = ctx.r10.u32 & 0xFFFF;
	// cmplwi cr6,r11,48
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 48, ctx.xer);
	// bne cr6,0x8b0d4d10
	if (!ctx.cr6.eq) goto loc_8B0D4D10;
loc_8B0D4CFC:
	// lhz r10,0(r8)
	ctx.r10.u64 = REX_LOAD_U16(ctx.r8.u32 + 0);
	// addi r31,r31,-1
	ctx.r31.s64 = ctx.r31.s64 + -1;
	// addi r8,r8,2
	ctx.r8.s64 = ctx.r8.s64 + 2;
	// cmplwi cr6,r10,48
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 48, ctx.xer);
	// beq cr6,0x8b0d4cfc
	if (ctx.cr6.eq) goto loc_8B0D4CFC;
loc_8B0D4D10:
	// clrlwi r11,r10,16
	ctx.r11.u64 = ctx.r10.u32 & 0xFFFF;
	// b 0x8b0d4d44
	goto loc_8B0D4D44;
loc_8B0D4D18:
	// cmplwi cr6,r11,57
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 57, ctx.xer);
	// bgt cr6,0x8b0d4ccc
	if (ctx.cr6.gt) goto loc_8B0D4CCC;
	// cmplwi cr6,r6,25
	ctx.cr6.compare<uint32_t>(ctx.r6.u32, 25, ctx.xer);
	// bge cr6,0x8b0d4d3c
	if (!ctx.cr6.lt) goto loc_8B0D4D3C;
	// addi r11,r11,-48
	ctx.r11.s64 = ctx.r11.s64 + -48;
	// addi r6,r6,1
	ctx.r6.s64 = ctx.r6.s64 + 1;
	// stb r11,0(r3)
	REX_STORE_U8(ctx.r3.u32 + 0, ctx.r11.u8);
	// addi r31,r31,-1
	ctx.r31.s64 = ctx.r31.s64 + -1;
	// addi r3,r3,1
	ctx.r3.s64 = ctx.r3.s64 + 1;
loc_8B0D4D3C:
	// lhz r11,0(r8)
	ctx.r11.u64 = REX_LOAD_U16(ctx.r8.u32 + 0);
	// addi r8,r8,2
	ctx.r8.s64 = ctx.r8.s64 + 2;
loc_8B0D4D44:
	// cmplwi cr6,r11,48
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 48, ctx.xer);
	// bge cr6,0x8b0d4d18
	if (!ctx.cr6.lt) goto loc_8B0D4D18;
	// b 0x8b0d4ccc
	goto loc_8B0D4CCC;
loc_8B0D4D50:
	// clrlwi r11,r10,16
	ctx.r11.u64 = ctx.r10.u32 & 0xFFFF;
	// li r26,1
	ctx.r26.s64 = 1;
	// cmplwi cr6,r11,48
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 48, ctx.xer);
	// blt cr6,0x8b0d4c28
	if (ctx.cr6.lt) goto loc_8B0D4C28;
	// cmplwi cr6,r11,57
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 57, ctx.xer);
	// bgt cr6,0x8b0d4c28
	if (ctx.cr6.gt) goto loc_8B0D4C28;
	// li r11,4
	ctx.r11.s64 = 4;
	// b 0x8b0d4b1c
	goto loc_8B0D4B1C;
loc_8B0D4D70:
	// clrlwi r11,r10,16
	ctx.r11.u64 = ctx.r10.u32 & 0xFFFF;
	// addi r5,r8,-4
	ctx.r5.s64 = ctx.r8.s64 + -4;
	// cmplwi cr6,r11,49
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 49, ctx.xer);
	// blt cr6,0x8b0d4d90
	if (ctx.cr6.lt) goto loc_8B0D4D90;
	// cmplwi cr6,r11,57
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 57, ctx.xer);
	// bgt cr6,0x8b0d4d90
	if (ctx.cr6.gt) goto loc_8B0D4D90;
loc_8B0D4D88:
	// li r11,9
	ctx.r11.s64 = 9;
	// b 0x8b0d4b1c
	goto loc_8B0D4B1C;
loc_8B0D4D90:
	// cmpwi cr6,r11,43
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 43, ctx.xer);
	// beq cr6,0x8b0d4db0
	if (ctx.cr6.eq) goto loc_8B0D4DB0;
	// cmpwi cr6,r11,45
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 45, ctx.xer);
	// beq cr6,0x8b0d4e24
	if (ctx.cr6.eq) goto loc_8B0D4E24;
loc_8B0D4DA0:
	// cmpwi cr6,r11,48
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 48, ctx.xer);
	// bne cr6,0x8b0d4c28
	if (!ctx.cr6.eq) goto loc_8B0D4C28;
	// li r11,8
	ctx.r11.s64 = 8;
	// b 0x8b0d4acc
	goto loc_8B0D4ACC;
loc_8B0D4DB0:
	// li r11,7
	ctx.r11.s64 = 7;
	// b 0x8b0d4acc
	goto loc_8B0D4ACC;
loc_8B0D4DB8:
	// clrlwi r11,r10,16
	ctx.r11.u64 = ctx.r10.u32 & 0xFFFF;
	// li r28,1
	ctx.r28.s64 = 1;
	// b 0x8b0d4dcc
	goto loc_8B0D4DCC;
loc_8B0D4DC4:
	// lhz r11,0(r8)
	ctx.r11.u64 = REX_LOAD_U16(ctx.r8.u32 + 0);
	// addi r8,r8,2
	ctx.r8.s64 = ctx.r8.s64 + 2;
loc_8B0D4DCC:
	// cmplwi cr6,r11,48
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 48, ctx.xer);
	// beq cr6,0x8b0d4dc4
	if (ctx.cr6.eq) goto loc_8B0D4DC4;
	// cmplwi cr6,r11,49
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 49, ctx.xer);
	// blt cr6,0x8b0d4de4
	if (ctx.cr6.lt) goto loc_8B0D4DE4;
	// cmplwi cr6,r11,57
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 57, ctx.xer);
	// ble cr6,0x8b0d4d88
	if (!ctx.cr6.gt) goto loc_8B0D4D88;
loc_8B0D4DE4:
	// addi r8,r8,-2
	ctx.r8.s64 = ctx.r8.s64 + -2;
	// b 0x8b0d4c2c
	goto loc_8B0D4C2C;
loc_8B0D4DEC:
	// clrlwi r11,r10,16
	ctx.r11.u64 = ctx.r10.u32 & 0xFFFF;
	// cmplwi cr6,r11,49
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 49, ctx.xer);
	// blt cr6,0x8b0d4da0
	if (ctx.cr6.lt) goto loc_8B0D4DA0;
	// cmplwi cr6,r11,57
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 57, ctx.xer);
	// ble cr6,0x8b0d4d88
	if (!ctx.cr6.gt) goto loc_8B0D4D88;
	// b 0x8b0d4da0
	goto loc_8B0D4DA0;
loc_8B0D4E04:
	// cmpwi cr6,r9,0
	ctx.cr6.compare<int32_t>(ctx.r9.s32, 0, ctx.xer);
	// beq cr6,0x8b0d4e30
	if (ctx.cr6.eq) goto loc_8B0D4E30;
	// clrlwi r11,r10,16
	ctx.r11.u64 = ctx.r10.u32 & 0xFFFF;
	// addi r5,r8,-2
	ctx.r5.s64 = ctx.r8.s64 + -2;
	// cmpwi cr6,r11,43
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 43, ctx.xer);
	// beq cr6,0x8b0d4db0
	if (ctx.cr6.eq) goto loc_8B0D4DB0;
	// cmpwi cr6,r11,45
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 45, ctx.xer);
	// bne cr6,0x8b0d4c28
	if (!ctx.cr6.eq) goto loc_8B0D4C28;
loc_8B0D4E24:
	// li r11,7
	ctx.r11.s64 = 7;
	// li r27,-1
	ctx.r27.s64 = -1;
	// b 0x8b0d4acc
	goto loc_8B0D4ACC;
loc_8B0D4E30:
	// li r11,10
	ctx.r11.s64 = 10;
	// addi r8,r8,-2
	ctx.r8.s64 = ctx.r8.s64 + -2;
loc_8B0D4E38:
	// cmpwi cr6,r11,10
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 10, ctx.xer);
	// bne cr6,0x8b0d4acc
	if (!ctx.cr6.eq) goto loc_8B0D4ACC;
	// b 0x8b0d4c2c
	goto loc_8B0D4C2C;
loc_8B0D4E44:
	// clrlwi r11,r10,16
	ctx.r11.u64 = ctx.r10.u32 & 0xFFFF;
	// li r28,1
	ctx.r28.s64 = 1;
	// mr r10,r22
	ctx.r10.u64 = ctx.r22.u64;
	// b 0x8b0d4e78
	goto loc_8B0D4E78;
loc_8B0D4E54:
	// cmplwi cr6,r11,57
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 57, ctx.xer);
	// bgt cr6,0x8b0d4e88
	if (ctx.cr6.gt) goto loc_8B0D4E88;
	// mulli r10,r10,10
	ctx.r10.s64 = static_cast<int64_t>(ctx.r10.u64 * static_cast<uint64_t>(10));
	// add r10,r10,r11
	ctx.r10.u64 = ctx.r10.u64 + ctx.r11.u64;
	// addi r10,r10,-48
	ctx.r10.s64 = ctx.r10.s64 + -48;
	// cmpwi cr6,r10,5200
	ctx.cr6.compare<int32_t>(ctx.r10.s32, 5200, ctx.xer);
	// bgt cr6,0x8b0d4e84
	if (ctx.cr6.gt) goto loc_8B0D4E84;
	// lhz r11,0(r8)
	ctx.r11.u64 = REX_LOAD_U16(ctx.r8.u32 + 0);
	// addi r8,r8,2
	ctx.r8.s64 = ctx.r8.s64 + 2;
loc_8B0D4E78:
	// cmplwi cr6,r11,48
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 48, ctx.xer);
	// bge cr6,0x8b0d4e54
	if (!ctx.cr6.lt) goto loc_8B0D4E54;
	// b 0x8b0d4e88
	goto loc_8B0D4E88;
loc_8B0D4E84:
	// li r10,5201
	ctx.r10.s64 = 5201;
loc_8B0D4E88:
	// mr r29,r10
	ctx.r29.u64 = ctx.r10.u64;
	// b 0x8b0d4ea0
	goto loc_8B0D4EA0;
loc_8B0D4E90:
	// cmplwi cr6,r11,57
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 57, ctx.xer);
	// bgt cr6,0x8b0d4de4
	if (ctx.cr6.gt) goto loc_8B0D4DE4;
	// lhz r11,0(r8)
	ctx.r11.u64 = REX_LOAD_U16(ctx.r8.u32 + 0);
	// addi r8,r8,2
	ctx.r8.s64 = ctx.r8.s64 + 2;
loc_8B0D4EA0:
	// cmplwi cr6,r11,48
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 48, ctx.xer);
	// bge cr6,0x8b0d4e90
	if (!ctx.cr6.lt) goto loc_8B0D4E90;
	// b 0x8b0d4de4
	goto loc_8B0D4DE4;
loc_8B0D4EAC:
	// lbzu r11,-1(r3)
	ea = -1 + ctx.r3.u32;
	ctx.r11.u64 = REX_LOAD_U8(ea);
	ctx.r3.u32 = ea;
	// addi r6,r6,-1
	ctx.r6.s64 = ctx.r6.s64 + -1;
	// addi r31,r31,1
	ctx.r31.s64 = ctx.r31.s64 + 1;
loc_8B0D4EB8:
	// cmplwi r11,0
	ctx.cr0.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// beq 0x8b0d4eac
	if (ctx.cr0.eq) goto loc_8B0D4EAC;
	// addi r5,r1,96
	ctx.r5.s64 = ctx.r1.s64 + 96;
	// mr r4,r6
	ctx.r4.u64 = ctx.r6.u64;
	// addi r3,r1,128
	ctx.r3.s64 = ctx.r1.s64 + 128;
	// bl 0x8b0d9738
	ctx.lr = 0x8B0D4ED0;
	sub_8B0D9738(ctx, base);
	// cmpwi cr6,r27,0
	ctx.cr6.compare<int32_t>(ctx.r27.s32, 0, ctx.xer);
	// bge cr6,0x8b0d4edc
	if (!ctx.cr6.lt) goto loc_8B0D4EDC;
	// neg r29,r29
	ctx.r29.s64 = static_cast<int64_t>(-ctx.r29.u64);
loc_8B0D4EDC:
	// add r11,r31,r29
	ctx.r11.u64 = ctx.r31.u64 + ctx.r29.u64;
	// cmpwi cr6,r28,0
	ctx.cr6.compare<int32_t>(ctx.r28.s32, 0, ctx.xer);
	// bne cr6,0x8b0d4eec
	if (!ctx.cr6.eq) goto loc_8B0D4EEC;
	// add r11,r11,r25
	ctx.r11.u64 = ctx.r11.u64 + ctx.r25.u64;
loc_8B0D4EEC:
	// cmpwi cr6,r26,0
	ctx.cr6.compare<int32_t>(ctx.r26.s32, 0, ctx.xer);
	// bne cr6,0x8b0d4ef8
	if (!ctx.cr6.eq) goto loc_8B0D4EF8;
	// subf r11,r24,r11
	ctx.r11.u64 = ctx.r11.u64 - ctx.r24.u64;
loc_8B0D4EF8:
	// cmpwi cr6,r11,5200
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 5200, ctx.xer);
	// bgt cr6,0x8b0d5300
	if (ctx.cr6.gt) goto loc_8B0D5300;
	// cmpwi cr6,r11,-5200
	ctx.cr6.compare<int32_t>(ctx.r11.s32, -5200, ctx.xer);
	// blt cr6,0x8b0d5318
	if (ctx.cr6.lt) goto loc_8B0D5318;
	// lis r10,-29938
	ctx.r10.s64 = -1962016768;
	// mr r26,r11
	ctx.r26.u64 = ctx.r11.u64;
	// addi r10,r10,14640
	ctx.r10.s64 = ctx.r10.s64 + 14640;
	// cmpwi cr6,r11,0
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// addi r25,r10,-96
	ctx.r25.s64 = ctx.r10.s64 + -96;
	// beq cr6,0x8b0d52c0
	if (ctx.cr6.eq) goto loc_8B0D52C0;
	// bge cr6,0x8b0d4f34
	if (!ctx.cr6.lt) goto loc_8B0D4F34;
	// lis r10,-29938
	ctx.r10.s64 = -1962016768;
	// neg r26,r11
	ctx.r26.s64 = static_cast<int64_t>(-ctx.r11.u64);
	// addi r11,r10,14992
	ctx.r11.s64 = ctx.r10.s64 + 14992;
	// addi r25,r11,-96
	ctx.r25.s64 = ctx.r11.s64 + -96;
loc_8B0D4F34:
	// subfic r11,r23,0
	ctx.xer.ca = ctx.r23.u32 <= 0;
	ctx.r11.u64 = static_cast<uint64_t>(0) - ctx.r23.u64;
	// lhz r10,106(r1)
	ctx.r10.u64 = REX_LOAD_U16(ctx.r1.u32 + 106);
	// cmpwi cr6,r26,0
	ctx.cr6.compare<int32_t>(ctx.r26.s32, 0, ctx.xer);
	// subfe r11,r11,r11
	temp.u8 = (~ctx.r11.u32 + ctx.r11.u32 < ~ctx.r11.u32) | (~ctx.r11.u32 + ctx.r11.u32 + ctx.xer.ca < ctx.xer.ca);
	ctx.r11.u64 = ~ctx.r11.u64 + ctx.r11.u64 + ctx.xer.ca;
	ctx.xer.ca = temp.u8;
	// and r11,r11,r10
	ctx.r11.u64 = ctx.r11.u64 & ctx.r10.u64;
	// sth r11,106(r1)
	REX_STORE_U16(ctx.r1.u32 + 106, ctx.r11.u16);
	// beq cr6,0x8b0d52c0
	if (ctx.cr6.eq) goto loc_8B0D52C0;
	// lis r11,0
	ctx.r11.s64 = 0;
	// lis r10,32767
	ctx.r10.s64 = 2147418112;
	// ori r27,r11,65535
	ctx.r27.u64 = ctx.r11.u64 | 65535;
	// li r24,-32768
	ctx.r24.s64 = -32768;
	// ori r23,r10,32768
	ctx.r23.u64 = ctx.r10.u64 | 32768;
loc_8B0D4F64:
	// clrlwi. r11,r26,29
	ctx.r11.u64 = ctx.r26.u32 & 0x7;
	ctx.cr0.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// addi r25,r25,84
	ctx.r25.s64 = ctx.r25.s64 + 84;
	// srawi r26,r26,3
	ctx.xer.ca = (ctx.r26.s32 < 0) & ((ctx.r26.u32 & 0x7) != 0);
	ctx.r26.s64 = ctx.r26.s32 >> 3;
	// beq 0x8b0d52b8
	if (ctx.cr0.eq) goto loc_8B0D52B8;
	// mulli r11,r11,12
	ctx.r11.s64 = static_cast<int64_t>(ctx.r11.u64 * static_cast<uint64_t>(12));
	// add r4,r11,r25
	ctx.r4.u64 = ctx.r11.u64 + ctx.r25.u64;
	// lhz r11,10(r4)
	ctx.r11.u64 = REX_LOAD_U16(ctx.r4.u32 + 10);
	// cmplwi cr6,r11,32768
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 32768, ctx.xer);
	// blt cr6,0x8b0d4fa4
	if (ctx.cr6.lt) goto loc_8B0D4FA4;
	// addi r3,r1,112
	ctx.r3.s64 = ctx.r1.s64 + 112;
	// li r5,12
	ctx.r5.s64 = 12;
	// bl 0x8b0cbb30
	ctx.lr = 0x8B0D4F94;
	sub_8B0CBB30(ctx, base);
	// lwz r11,118(r1)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r1.u32 + 118);
	// addi r4,r1,112
	ctx.r4.s64 = ctx.r1.s64 + 112;
	// addi r11,r11,-1
	ctx.r11.s64 = ctx.r11.s64 + -1;
	// stw r11,118(r1)
	REX_STORE_U32(ctx.r1.u32 + 118, ctx.r11.u32);
loc_8B0D4FA4:
	// lhz r10,96(r1)
	ctx.r10.u64 = REX_LOAD_U16(ctx.r1.u32 + 96);
	// mr r29,r22
	ctx.r29.u64 = ctx.r22.u64;
	// stw r22,88(r1)
	REX_STORE_U32(ctx.r1.u32 + 88, ctx.r22.u32);
	// stw r22,84(r1)
	REX_STORE_U32(ctx.r1.u32 + 84, ctx.r22.u32);
	// clrlwi r11,r10,17
	ctx.r11.u64 = ctx.r10.u32 & 0x7FFF;
	// stw r22,80(r1)
	REX_STORE_U32(ctx.r1.u32 + 80, ctx.r22.u32);
	// mr r9,r10
	ctx.r9.u64 = ctx.r10.u64;
	// lhz r8,0(r4)
	ctx.r8.u64 = REX_LOAD_U16(ctx.r4.u32 + 0);
	// clrlwi r10,r8,17
	ctx.r10.u64 = ctx.r8.u32 & 0x7FFF;
	// xor r8,r9,r8
	ctx.r8.u64 = ctx.r9.u64 ^ ctx.r8.u64;
	// add r7,r11,r10
	ctx.r7.u64 = ctx.r11.u64 + ctx.r10.u64;
	// mr r9,r11
	ctx.r9.u64 = ctx.r11.u64;
	// cmplwi cr6,r11,32767
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 32767, ctx.xer);
	// rlwinm r28,r8,0,16,16
	ctx.r28.u64 = __builtin_rotateleft64(ctx.r8.u32 | (ctx.r8.u64 << 32), 0) & 0x8000;
	// clrlwi r30,r7,16
	ctx.r30.u64 = ctx.r7.u32 & 0xFFFF;
	// bge cr6,0x8b0d52a0
	if (!ctx.cr6.lt) goto loc_8B0D52A0;
	// cmplwi cr6,r10,32767
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 32767, ctx.xer);
	// bge cr6,0x8b0d52a0
	if (!ctx.cr6.lt) goto loc_8B0D52A0;
	// clrlwi r11,r30,16
	ctx.r11.u64 = ctx.r30.u32 & 0xFFFF;
	// cmplwi cr6,r11,49149
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 49149, ctx.xer);
	// bgt cr6,0x8b0d52a0
	if (ctx.cr6.gt) goto loc_8B0D52A0;
	// cmplwi cr6,r11,16319
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 16319, ctx.xer);
	// bgt cr6,0x8b0d5008
	if (ctx.cr6.gt) goto loc_8B0D5008;
loc_8B0D5000:
	// stw r22,96(r1)
	REX_STORE_U32(ctx.r1.u32 + 96, ctx.r22.u32);
	// b 0x8b0d52b0
	goto loc_8B0D52B0;
loc_8B0D5008:
	// cmplwi cr6,r9,0
	ctx.cr6.compare<uint32_t>(ctx.r9.u32, 0, ctx.xer);
	// bne cr6,0x8b0d5044
	if (!ctx.cr6.eq) goto loc_8B0D5044;
	// lwz r9,96(r1)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r1.u32 + 96);
	// addi r11,r11,1
	ctx.r11.s64 = ctx.r11.s64 + 1;
	// clrlwi. r9,r9,1
	ctx.r9.u64 = ctx.r9.u32 & 0x7FFFFFFF;
	ctx.cr0.compare<int32_t>(ctx.r9.s32, 0, ctx.xer);
	// clrlwi r30,r11,16
	ctx.r30.u64 = ctx.r11.u32 & 0xFFFF;
	// bne 0x8b0d5044
	if (!ctx.cr0.eq) goto loc_8B0D5044;
	// lwz r11,100(r1)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r1.u32 + 100);
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// bne cr6,0x8b0d5044
	if (!ctx.cr6.eq) goto loc_8B0D5044;
	// lwz r11,104(r1)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r1.u32 + 104);
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// bne cr6,0x8b0d5044
	if (!ctx.cr6.eq) goto loc_8B0D5044;
	// sth r22,96(r1)
	REX_STORE_U16(ctx.r1.u32 + 96, ctx.r22.u16);
	// b 0x8b0d52b8
	goto loc_8B0D52B8;
loc_8B0D5044:
	// cmplwi cr6,r10,0
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 0, ctx.xer);
	// bne cr6,0x8b0d507c
	if (!ctx.cr6.eq) goto loc_8B0D507C;
	// clrlwi r11,r30,16
	ctx.r11.u64 = ctx.r30.u32 & 0xFFFF;
	// lwz r10,0(r4)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r4.u32 + 0);
	// addi r11,r11,1
	ctx.r11.s64 = ctx.r11.s64 + 1;
	// clrlwi. r10,r10,1
	ctx.r10.u64 = ctx.r10.u32 & 0x7FFFFFFF;
	ctx.cr0.compare<int32_t>(ctx.r10.s32, 0, ctx.xer);
	// clrlwi r30,r11,16
	ctx.r30.u64 = ctx.r11.u32 & 0xFFFF;
	// bne 0x8b0d507c
	if (!ctx.cr0.eq) goto loc_8B0D507C;
	// lwz r11,4(r4)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r4.u32 + 4);
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// bne cr6,0x8b0d507c
	if (!ctx.cr6.eq) goto loc_8B0D507C;
	// lwz r11,8(r4)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r4.u32 + 8);
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// beq cr6,0x8b0d5000
	if (ctx.cr6.eq) goto loc_8B0D5000;
loc_8B0D507C:
	// mr r31,r22
	ctx.r31.u64 = ctx.r22.u64;
	// addi r8,r1,86
	ctx.r8.s64 = ctx.r1.s64 + 86;
	// li r3,5
	ctx.r3.s64 = 5;
loc_8B0D5088:
	// rlwinm r11,r31,1,0,30
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r31.u32 | (ctx.r31.u64 << 32), 1) & 0xFFFFFFFE;
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// ble cr6,0x8b0d50f4
	if (!ctx.cr6.gt) goto loc_8B0D50F4;
	// addi r10,r1,106
	ctx.r10.s64 = ctx.r1.s64 + 106;
	// mtctr r3
	ctx.ctr.u64 = ctx.r3.u64;
	// addi r5,r4,2
	ctx.r5.s64 = ctx.r4.s64 + 2;
	// subf r6,r11,r10
	ctx.r6.u64 = ctx.r10.u64 - ctx.r11.u64;
loc_8B0D50A4:
	// lhz r10,0(r6)
	ctx.r10.u64 = REX_LOAD_U16(ctx.r6.u32 + 0);
	// mr r7,r22
	ctx.r7.u64 = ctx.r22.u64;
	// lhz r9,0(r5)
	ctx.r9.u64 = REX_LOAD_U16(ctx.r5.u32 + 0);
	// lwz r11,2(r8)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r8.u32 + 2);
	// mullw r9,r9,r10
	ctx.r9.s64 = int64_t(ctx.r9.s32) * int64_t(ctx.r10.s32);
	// add r10,r11,r9
	ctx.r10.u64 = ctx.r11.u64 + ctx.r9.u64;
	// cmplw cr6,r10,r11
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, ctx.r11.u32, ctx.xer);
	// blt cr6,0x8b0d50cc
	if (ctx.cr6.lt) goto loc_8B0D50CC;
	// cmplw cr6,r10,r9
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, ctx.r9.u32, ctx.xer);
	// bge cr6,0x8b0d50d0
	if (!ctx.cr6.lt) goto loc_8B0D50D0;
loc_8B0D50CC:
	// li r7,1
	ctx.r7.s64 = 1;
loc_8B0D50D0:
	// stw r10,2(r8)
	REX_STORE_U32(ctx.r8.u32 + 2, ctx.r10.u32);
	// cmpwi cr6,r7,0
	ctx.cr6.compare<int32_t>(ctx.r7.s32, 0, ctx.xer);
	// beq cr6,0x8b0d50e8
	if (ctx.cr6.eq) goto loc_8B0D50E8;
	// lhz r11,0(r8)
	ctx.r11.u64 = REX_LOAD_U16(ctx.r8.u32 + 0);
	// addi r11,r11,1
	ctx.r11.s64 = ctx.r11.s64 + 1;
	// sth r11,0(r8)
	REX_STORE_U16(ctx.r8.u32 + 0, ctx.r11.u16);
loc_8B0D50E8:
	// addi r6,r6,-2
	ctx.r6.s64 = ctx.r6.s64 + -2;
	// addi r5,r5,2
	ctx.r5.s64 = ctx.r5.s64 + 2;
	// bdnz 0x8b0d50a4
	--ctx.ctr.u64;
	if (ctx.ctr.u32 != 0) goto loc_8B0D50A4;
loc_8B0D50F4:
	// addic. r3,r3,-1
	ctx.xer.ca = ctx.r3.u32 > 0;
	ctx.r3.s64 = ctx.r3.s64 + -1;
	ctx.cr0.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// addi r8,r8,-2
	ctx.r8.s64 = ctx.r8.s64 + -2;
	// addi r31,r31,1
	ctx.r31.s64 = ctx.r31.s64 + 1;
	// bgt 0x8b0d5088
	if (ctx.cr0.gt) goto loc_8B0D5088;
	// clrlwi r11,r30,16
	ctx.r11.u64 = ctx.r30.u32 & 0xFFFF;
	// lwz r10,88(r1)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r1.u32 + 88);
	// addis r11,r11,1
	ctx.r11.s64 = ctx.r11.s64 + 65536;
	// addi r11,r11,-16382
	ctx.r11.s64 = ctx.r11.s64 + -16382;
loc_8B0D5114:
	// clrlwi r11,r11,16
	ctx.r11.u64 = ctx.r11.u32 & 0xFFFF;
	// extsh. r9,r11
	ctx.r9.s64 = ctx.r11.s16;
	ctx.cr0.compare<int32_t>(ctx.r9.s32, 0, ctx.xer);
	// ble 0x8b0d5164
	if (!ctx.cr0.gt) goto loc_8B0D5164;
	// lwz r8,80(r1)
	ctx.r8.u64 = REX_LOAD_U32(ctx.r1.u32 + 80);
	// rlwinm. r7,r8,0,0,0
	ctx.r7.u64 = __builtin_rotateleft64(ctx.r8.u32 | (ctx.r8.u64 << 32), 0) & 0x80000000;
	ctx.cr0.compare<int32_t>(ctx.r7.s32, 0, ctx.xer);
	// bne 0x8b0d5164
	if (!ctx.cr0.eq) goto loc_8B0D5164;
	// lwz r9,84(r1)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r1.u32 + 84);
	// rlwinm r7,r10,1,31,31
	ctx.r7.u64 = __builtin_rotateleft64(ctx.r10.u32 | (ctx.r10.u64 << 32), 1) & 0x1;
	// rlwinm r8,r8,1,0,30
	ctx.r8.u64 = __builtin_rotateleft64(ctx.r8.u32 | (ctx.r8.u64 << 32), 1) & 0xFFFFFFFE;
	// rlwinm r6,r9,1,31,31
	ctx.r6.u64 = __builtin_rotateleft64(ctx.r9.u32 | (ctx.r9.u64 << 32), 1) & 0x1;
	// rlwinm r5,r9,1,0,30
	ctx.r5.u64 = __builtin_rotateleft64(ctx.r9.u32 | (ctx.r9.u64 << 32), 1) & 0xFFFFFFFE;
	// clrlwi r11,r11,16
	ctx.r11.u64 = ctx.r11.u32 & 0xFFFF;
	// rlwinm r10,r10,1,0,30
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r10.u32 | (ctx.r10.u64 << 32), 1) & 0xFFFFFFFE;
	// or r7,r5,r7
	ctx.r7.u64 = ctx.r5.u64 | ctx.r7.u64;
	// or r8,r8,r6
	ctx.r8.u64 = ctx.r8.u64 | ctx.r6.u64;
	// stw r10,88(r1)
	REX_STORE_U32(ctx.r1.u32 + 88, ctx.r10.u32);
	// add r11,r11,r27
	ctx.r11.u64 = ctx.r11.u64 + ctx.r27.u64;
	// stw r7,84(r1)
	REX_STORE_U32(ctx.r1.u32 + 84, ctx.r7.u32);
	// stw r8,80(r1)
	REX_STORE_U32(ctx.r1.u32 + 80, ctx.r8.u32);
	// b 0x8b0d5114
	goto loc_8B0D5114;
loc_8B0D5164:
	// cmpwi cr6,r9,0
	ctx.cr6.compare<int32_t>(ctx.r9.s32, 0, ctx.xer);
	// bgt cr6,0x8b0d51ec
	if (ctx.cr6.gt) goto loc_8B0D51EC;
	// clrlwi r11,r11,16
	ctx.r11.u64 = ctx.r11.u32 & 0xFFFF;
	// add r11,r11,r27
	ctx.r11.u64 = ctx.r11.u64 + ctx.r27.u64;
	// clrlwi r11,r11,16
	ctx.r11.u64 = ctx.r11.u32 & 0xFFFF;
	// extsh. r9,r11
	ctx.r9.s64 = ctx.r11.s16;
	ctx.cr0.compare<int32_t>(ctx.r9.s32, 0, ctx.xer);
	// bge 0x8b0d51ec
	if (!ctx.cr0.lt) goto loc_8B0D51EC;
	// lwz r8,80(r1)
	ctx.r8.u64 = REX_LOAD_U32(ctx.r1.u32 + 80);
	// lwz r9,84(r1)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r1.u32 + 84);
loc_8B0D5188:
	// lhz r7,90(r1)
	ctx.r7.u64 = REX_LOAD_U16(ctx.r1.u32 + 90);
	// clrlwi. r7,r7,31
	ctx.r7.u64 = ctx.r7.u32 & 0x1;
	ctx.cr0.compare<int32_t>(ctx.r7.s32, 0, ctx.xer);
	// beq 0x8b0d5198
	if (ctx.cr0.eq) goto loc_8B0D5198;
	// addi r29,r29,1
	ctx.r29.s64 = ctx.r29.s64 + 1;
loc_8B0D5198:
	// clrlwi r11,r11,16
	ctx.r11.u64 = ctx.r11.u32 & 0xFFFF;
	// rlwinm r7,r9,31,0,0
	ctx.r7.u64 = __builtin_rotateleft64(ctx.r9.u32 | (ctx.r9.u64 << 32), 31) & 0x80000000;
	// addi r11,r11,1
	ctx.r11.s64 = ctx.r11.s64 + 1;
	// rlwinm r10,r10,31,1,31
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r10.u32 | (ctx.r10.u64 << 32), 31) & 0x7FFFFFFF;
	// rlwinm r6,r8,31,0,0
	ctx.r6.u64 = __builtin_rotateleft64(ctx.r8.u32 | (ctx.r8.u64 << 32), 31) & 0x80000000;
	// clrlwi r11,r11,16
	ctx.r11.u64 = ctx.r11.u32 & 0xFFFF;
	// rlwinm r9,r9,31,1,31
	ctx.r9.u64 = __builtin_rotateleft64(ctx.r9.u32 | (ctx.r9.u64 << 32), 31) & 0x7FFFFFFF;
	// or r10,r10,r7
	ctx.r10.u64 = ctx.r10.u64 | ctx.r7.u64;
	// extsh. r5,r11
	ctx.r5.s64 = ctx.r11.s16;
	ctx.cr0.compare<int32_t>(ctx.r5.s32, 0, ctx.xer);
	// rlwinm r8,r8,31,1,31
	ctx.r8.u64 = __builtin_rotateleft64(ctx.r8.u32 | (ctx.r8.u64 << 32), 31) & 0x7FFFFFFF;
	// stw r10,88(r1)
	REX_STORE_U32(ctx.r1.u32 + 88, ctx.r10.u32);
	// or r9,r9,r6
	ctx.r9.u64 = ctx.r9.u64 | ctx.r6.u64;
	// blt 0x8b0d5188
	if (ctx.cr0.lt) goto loc_8B0D5188;
	// stw r9,84(r1)
	REX_STORE_U32(ctx.r1.u32 + 84, ctx.r9.u32);
	// cmpwi cr6,r29,0
	ctx.cr6.compare<int32_t>(ctx.r29.s32, 0, ctx.xer);
	// stw r8,80(r1)
	REX_STORE_U32(ctx.r1.u32 + 80, ctx.r8.u32);
	// beq cr6,0x8b0d51ec
	if (ctx.cr6.eq) goto loc_8B0D51EC;
	// lhz r10,90(r1)
	ctx.r10.u64 = REX_LOAD_U16(ctx.r1.u32 + 90);
	// ori r10,r10,1
	ctx.r10.u64 = ctx.r10.u64 | 1;
	// sth r10,90(r1)
	REX_STORE_U16(ctx.r1.u32 + 90, ctx.r10.u16);
	// lwz r10,88(r1)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r1.u32 + 88);
loc_8B0D51EC:
	// lhz r9,90(r1)
	ctx.r9.u64 = REX_LOAD_U16(ctx.r1.u32 + 90);
	// cmplwi cr6,r9,32768
	ctx.cr6.compare<uint32_t>(ctx.r9.u32, 32768, ctx.xer);
	// bgt cr6,0x8b0d520c
	if (ctx.cr6.gt) goto loc_8B0D520C;
	// lis r9,1
	ctx.r9.s64 = 65536;
	// clrlwi r10,r10,15
	ctx.r10.u64 = ctx.r10.u32 & 0x1FFFF;
	// ori r9,r9,32768
	ctx.r9.u64 = ctx.r9.u64 | 32768;
	// cmplw cr6,r10,r9
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, ctx.r9.u32, ctx.xer);
	// bne cr6,0x8b0d526c
	if (!ctx.cr6.eq) goto loc_8B0D526C;
loc_8B0D520C:
	// lwz r10,86(r1)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r1.u32 + 86);
	// cmpwi cr6,r10,-1
	ctx.cr6.compare<int32_t>(ctx.r10.s32, -1, ctx.xer);
	// bne cr6,0x8b0d5264
	if (!ctx.cr6.eq) goto loc_8B0D5264;
	// lwz r10,82(r1)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r1.u32 + 82);
	// stw r22,86(r1)
	REX_STORE_U32(ctx.r1.u32 + 86, ctx.r22.u32);
	// cmpwi cr6,r10,-1
	ctx.cr6.compare<int32_t>(ctx.r10.s32, -1, ctx.xer);
	// bne cr6,0x8b0d5258
	if (!ctx.cr6.eq) goto loc_8B0D5258;
	// lhz r10,80(r1)
	ctx.r10.u64 = REX_LOAD_U16(ctx.r1.u32 + 80);
	// stw r22,82(r1)
	REX_STORE_U32(ctx.r1.u32 + 82, ctx.r22.u32);
	// cmplwi cr6,r10,65535
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 65535, ctx.xer);
	// bne cr6,0x8b0d524c
	if (!ctx.cr6.eq) goto loc_8B0D524C;
	// clrlwi r11,r11,16
	ctx.r11.u64 = ctx.r11.u32 & 0xFFFF;
	// sth r21,80(r1)
	REX_STORE_U16(ctx.r1.u32 + 80, ctx.r21.u16);
	// addi r11,r11,1
	ctx.r11.s64 = ctx.r11.s64 + 1;
	// clrlwi r11,r11,16
	ctx.r11.u64 = ctx.r11.u32 & 0xFFFF;
	// b 0x8b0d526c
	goto loc_8B0D526C;
loc_8B0D524C:
	// addi r10,r10,1
	ctx.r10.s64 = ctx.r10.s64 + 1;
	// sth r10,80(r1)
	REX_STORE_U16(ctx.r1.u32 + 80, ctx.r10.u16);
	// b 0x8b0d526c
	goto loc_8B0D526C;
loc_8B0D5258:
	// addi r10,r10,1
	ctx.r10.s64 = ctx.r10.s64 + 1;
	// stw r10,82(r1)
	REX_STORE_U32(ctx.r1.u32 + 82, ctx.r10.u32);
	// b 0x8b0d526c
	goto loc_8B0D526C;
loc_8B0D5264:
	// addi r10,r10,1
	ctx.r10.s64 = ctx.r10.s64 + 1;
	// stw r10,86(r1)
	REX_STORE_U32(ctx.r1.u32 + 86, ctx.r10.u32);
loc_8B0D526C:
	// clrlwi r11,r11,16
	ctx.r11.u64 = ctx.r11.u32 & 0xFFFF;
	// cmplwi cr6,r11,32767
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 32767, ctx.xer);
	// bge cr6,0x8b0d52a0
	if (!ctx.cr6.lt) goto loc_8B0D52A0;
	// lhz r9,88(r1)
	ctx.r9.u64 = REX_LOAD_U16(ctx.r1.u32 + 88);
	// clrlwi r10,r28,16
	ctx.r10.u64 = ctx.r28.u32 & 0xFFFF;
	// lwz r8,84(r1)
	ctx.r8.u64 = REX_LOAD_U32(ctx.r1.u32 + 84);
	// lwz r7,80(r1)
	ctx.r7.u64 = REX_LOAD_U32(ctx.r1.u32 + 80);
	// or r11,r10,r11
	ctx.r11.u64 = ctx.r10.u64 | ctx.r11.u64;
	// sth r11,96(r1)
	REX_STORE_U16(ctx.r1.u32 + 96, ctx.r11.u16);
	// sth r9,106(r1)
	REX_STORE_U16(ctx.r1.u32 + 106, ctx.r9.u16);
	// stw r8,102(r1)
	REX_STORE_U32(ctx.r1.u32 + 102, ctx.r8.u32);
	// stw r7,98(r1)
	REX_STORE_U32(ctx.r1.u32 + 98, ctx.r7.u32);
	// b 0x8b0d52b8
	goto loc_8B0D52B8;
loc_8B0D52A0:
	// stw r24,96(r1)
	REX_STORE_U32(ctx.r1.u32 + 96, ctx.r24.u32);
	// clrlwi. r11,r28,16
	ctx.r11.u64 = ctx.r28.u32 & 0xFFFF;
	ctx.cr0.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// bne 0x8b0d52b0
	if (!ctx.cr0.eq) goto loc_8B0D52B0;
	// stw r23,96(r1)
	REX_STORE_U32(ctx.r1.u32 + 96, ctx.r23.u32);
loc_8B0D52B0:
	// stw r22,104(r1)
	REX_STORE_U32(ctx.r1.u32 + 104, ctx.r22.u32);
	// stw r22,100(r1)
	REX_STORE_U32(ctx.r1.u32 + 100, ctx.r22.u32);
loc_8B0D52B8:
	// cmpwi cr6,r26,0
	ctx.cr6.compare<int32_t>(ctx.r26.s32, 0, ctx.xer);
	// bne cr6,0x8b0d4f64
	if (!ctx.cr6.eq) goto loc_8B0D4F64;
loc_8B0D52C0:
	// lhz r11,106(r1)
	ctx.r11.u64 = REX_LOAD_U16(ctx.r1.u32 + 106);
	// lwz r8,102(r1)
	ctx.r8.u64 = REX_LOAD_U32(ctx.r1.u32 + 102);
	// lwz r9,98(r1)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r1.u32 + 98);
	// lhz r10,96(r1)
	ctx.r10.u64 = REX_LOAD_U16(ctx.r1.u32 + 96);
	// b 0x8b0d532c
	goto loc_8B0D532C;
loc_8B0D52D4:
	// mr r11,r22
	ctx.r11.u64 = ctx.r22.u64;
	// mr r10,r22
	ctx.r10.u64 = ctx.r22.u64;
	// mr r9,r22
	ctx.r9.u64 = ctx.r22.u64;
	// mr r8,r22
	ctx.r8.u64 = ctx.r22.u64;
	// b 0x8b0d532c
	goto loc_8B0D532C;
loc_8B0D52E8:
	// mr r11,r22
	ctx.r11.u64 = ctx.r22.u64;
	// mr r10,r22
	ctx.r10.u64 = ctx.r22.u64;
	// mr r9,r22
	ctx.r9.u64 = ctx.r22.u64;
	// mr r8,r22
	ctx.r8.u64 = ctx.r22.u64;
	// li r22,4
	ctx.r22.s64 = 4;
	// b 0x8b0d532c
	goto loc_8B0D532C;
loc_8B0D5300:
	// mr r8,r22
	ctx.r8.u64 = ctx.r22.u64;
	// mr r11,r22
	ctx.r11.u64 = ctx.r22.u64;
	// li r10,32767
	ctx.r10.s64 = 32767;
	// lis r9,-32768
	ctx.r9.s64 = -2147483648;
	// li r22,2
	ctx.r22.s64 = 2;
	// b 0x8b0d532c
	goto loc_8B0D532C;
loc_8B0D5318:
	// mr r11,r22
	ctx.r11.u64 = ctx.r22.u64;
	// mr r10,r22
	ctx.r10.u64 = ctx.r22.u64;
	// mr r9,r22
	ctx.r9.u64 = ctx.r22.u64;
	// mr r8,r22
	ctx.r8.u64 = ctx.r22.u64;
	// li r22,1
	ctx.r22.s64 = 1;
loc_8B0D532C:
	// sth r11,10(r20)
	REX_STORE_U16(ctx.r20.u32 + 10, ctx.r11.u16);
	// clrlwi r10,r10,16
	ctx.r10.u64 = ctx.r10.u32 & 0xFFFF;
	// clrlwi r11,r19,16
	ctx.r11.u64 = ctx.r19.u32 & 0xFFFF;
	// stw r8,6(r20)
	REX_STORE_U32(ctx.r20.u32 + 6, ctx.r8.u32);
	// stw r9,2(r20)
	REX_STORE_U32(ctx.r20.u32 + 2, ctx.r9.u32);
	// mr r3,r22
	ctx.r3.u64 = ctx.r22.u64;
	// or r11,r10,r11
	ctx.r11.u64 = ctx.r10.u64 | ctx.r11.u64;
	// sth r11,0(r20)
	REX_STORE_U16(ctx.r20.u32 + 0, ctx.r11.u16);
loc_8B0D534C:
	// addi r1,r1,272
	ctx.r1.s64 = ctx.r1.s64 + 272;
	// b 0x8b0cb9e4
	__restgprlr_19(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0D6028) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// std r31,-16(r1)
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.r31.u64);
	// addi r31,r1,-96
	ctx.r31.s64 = ctx.r1.s64 + -96;
	// stwu r1,-96(r1)
	ea = -96 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// bl 0x8b0cee88
	ctx.lr = 0x8B0D6040;
	sub_8B0CEE88(ctx, base);
	// lwz r11,108(r3)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r3.u32 + 108);
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// beq cr6,0x8b0d6068
	if (ctx.cr6.eq) goto loc_8B0D6068;
	// mr r8,r8
	ctx.r8.u64 = ctx.r8.u64;
	// mr r8,r8
	ctx.r8.u64 = ctx.r8.u64;
	// mtctr r11
	ctx.ctr.u64 = ctx.r11.u64;
	// bctrl 
	ctx.lr = 0x8B0D605C;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// mr r8,r8
	ctx.r8.u64 = ctx.r8.u64;
	// mr r8,r8
	ctx.r8.u64 = ctx.r8.u64;
	// mr r8,r8
	ctx.r8.u64 = ctx.r8.u64;
loc_8B0D6068:
	// lis r3,-16384
	ctx.r3.s64 = -1073741824;
	// ori r3,r3,324
	ctx.r3.u64 = ctx.r3.u64 | 324;
	// bl 0x8b0df5c8
	ctx.lr = 0x8B0D6074;
	__imp__KeBugCheck(ctx, base);
}

DEFINE_REX_FUNC(sub_8B0D6098) {
	REX_FUNC_PROLOGUE();
	// lis r11,-29936
	ctx.r11.s64 = -1961885696;
	// stw r3,-17252(r11)
	REX_STORE_U32(ctx.r11.u32 + -17252, ctx.r3.u32);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0D6120) {
	REX_FUNC_PROLOGUE();
	// lis r11,-16384
	ctx.r11.s64 = -1073741824;
	// ori r11,r11,23
	ctx.r11.u64 = ctx.r11.u64 | 23;
	// lwz r10,0(r3)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r3.u32 + 0);
	// lwz r10,0(r10)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r10.u32 + 0);
	// subf r11,r10,r11
	ctx.r11.u64 = ctx.r11.u64 - ctx.r10.u64;
	// cntlzw r11,r11
	ctx.r11.u64 = ctx.r11.u32 == 0 ? 32 : __builtin_clz(ctx.r11.u32);
	// rlwinm r3,r11,27,31,31
	ctx.r3.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 27) & 0x1;
	// mr r8,r8
	ctx.r8.u64 = ctx.r8.u64;
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0D6148) {
	REX_FUNC_PROLOGUE();
	// lis r11,-29936
	ctx.r11.s64 = -1961885696;
	// stw r3,-17248(r11)
	REX_STORE_U32(ctx.r11.u32 + -17248, ctx.r3.u32);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0D6158) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// stwu r1,-96(r1)
	ea = -96 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// beq cr6,0x8b0d618c
	if (ctx.cr6.eq) goto loc_8B0D618C;
	// lis r11,-29943
	ctx.r11.s64 = -1962344448;
	// lwz r10,-25028(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + -25028);
	// cmplwi cr6,r10,0
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 0, ctx.xer);
	// beq cr6,0x8b0d61b0
	if (ctx.cr6.eq) goto loc_8B0D61B0;
	// rotlwi r11,r10,0
	ctx.r11.u64 = __builtin_rotateleft32(ctx.r10.u32, 0);
	// mtctr r11
	ctx.ctr.u64 = ctx.r11.u64;
	// bctrl 
	ctx.lr = 0x8B0D6188;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// b 0x8b0d61b0
	goto loc_8B0D61B0;
loc_8B0D618C:
	// lis r11,-29943
	ctx.r11.s64 = -1962344448;
	// lwz r10,-25024(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + -25024);
	// cmplwi cr6,r10,0
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 0, ctx.xer);
	// beq cr6,0x8b0d61a8
	if (ctx.cr6.eq) goto loc_8B0D61A8;
	// rotlwi r11,r10,0
	ctx.r11.u64 = __builtin_rotateleft32(ctx.r10.u32, 0);
	// mtctr r11
	ctx.ctr.u64 = ctx.r11.u64;
	// bctrl 
	ctx.lr = 0x8B0D61A8;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
loc_8B0D61A8:
	// li r3,0
	ctx.r3.s64 = 0;
	// bl 0x8b0cef88
	ctx.lr = 0x8B0D61B0;
	sub_8B0CEF88(ctx, base);
loc_8B0D61B0:
	// addi r1,r1,96
	ctx.r1.s64 = ctx.r1.s64 + 96;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0D6290) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9a8
	ctx.lr = 0x8B0D6298;
	__savegprlr_24(ctx, base);
	// addi r31,r1,-160
	ctx.r31.s64 = ctx.r1.s64 + -160;
	// stwu r1,-160(r1)
	ea = -160 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// mr r30,r3
	ctx.r30.u64 = ctx.r3.u64;
	// stw r3,180(r31)
	REX_STORE_U32(ctx.r31.u32 + 180, ctx.r3.u32);
	// li r24,-1
	ctx.r24.s64 = -1;
	// mr r26,r4
	ctx.r26.u64 = ctx.r4.u64;
	// mr r25,r5
	ctx.r25.u64 = ctx.r5.u64;
	// std r24,80(r31)
	REX_STORE_U64(ctx.r31.u32 + 80, ctx.r24.u64);
	// cmpwi cr6,r3,-2
	ctx.cr6.compare<int32_t>(ctx.r3.s32, -2, ctx.xer);
	// bne cr6,0x8b0d62e4
	if (!ctx.cr6.eq) goto loc_8B0D62E4;
	// bl 0x8b0d02c0
	ctx.lr = 0x8B0D62C4;
	sub_8B0D02C0(ctx, base);
	// li r11,0
	ctx.r11.s64 = 0;
	// stw r11,0(r3)
	REX_STORE_U32(ctx.r3.u32 + 0, ctx.r11.u32);
	// bl 0x8b0d0288
	ctx.lr = 0x8B0D62D0;
	sub_8B0D0288(ctx, base);
	// mr r11,r3
	ctx.r11.u64 = ctx.r3.u64;
	// li r10,9
	ctx.r10.s64 = 9;
	// li r3,-1
	ctx.r3.s64 = -1;
	// stw r10,0(r11)
	REX_STORE_U32(ctx.r11.u32 + 0, ctx.r10.u32);
	// b 0x8b0d63c4
	goto loc_8B0D63C4;
loc_8B0D62E4:
	// cmpwi cr6,r30,0
	ctx.cr6.compare<int32_t>(ctx.r30.s32, 0, ctx.xer);
	// blt cr6,0x8b0d62fc
	if (ctx.cr6.lt) goto loc_8B0D62FC;
	// lis r11,-29936
	ctx.r11.s64 = -1961885696;
	// lwz r11,-16892(r11)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r11.u32 + -16892);
	// cmplw cr6,r30,r11
	ctx.cr6.compare<uint32_t>(ctx.r30.u32, ctx.r11.u32, ctx.xer);
	// blt cr6,0x8b0d6334
	if (ctx.cr6.lt) goto loc_8B0D6334;
loc_8B0D62FC:
	// bl 0x8b0d02c0
	ctx.lr = 0x8B0D6300;
	sub_8B0D02C0(ctx, base);
	// li r11,0
	ctx.r11.s64 = 0;
	// stw r11,0(r3)
	REX_STORE_U32(ctx.r3.u32 + 0, ctx.r11.u32);
	// bl 0x8b0d0288
	ctx.lr = 0x8B0D630C;
	sub_8B0D0288(ctx, base);
	// li r11,9
	ctx.r11.s64 = 9;
	// li r7,0
	ctx.r7.s64 = 0;
	// stw r11,0(r3)
	REX_STORE_U32(ctx.r3.u32 + 0, ctx.r11.u32);
	// li r6,0
	ctx.r6.s64 = 0;
	// li r5,0
	ctx.r5.s64 = 0;
	// li r4,0
	ctx.r4.s64 = 0;
	// li r3,0
	ctx.r3.s64 = 0;
	// bl 0x8b0d0148
	ctx.lr = 0x8B0D632C;
	sub_8B0D0148(ctx, base);
	// li r3,-1
	ctx.r3.s64 = -1;
	// b 0x8b0d63c4
	goto loc_8B0D63C4;
loc_8B0D6334:
	// srawi r11,r30,5
	ctx.xer.ca = (ctx.r30.s32 < 0) & ((ctx.r30.u32 & 0x1F) != 0);
	ctx.r11.s64 = ctx.r30.s32 >> 5;
	// lis r10,-29936
	ctx.r10.s64 = -1961885696;
	// rlwinm r27,r11,2,0,29
	ctx.r27.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 2) & 0xFFFFFFFC;
	// addi r28,r10,-16864
	ctx.r28.s64 = ctx.r10.s64 + -16864;
	// clrlwi r11,r30,27
	ctx.r11.u64 = ctx.r30.u32 & 0x1F;
	// mulli r29,r11,72
	ctx.r29.s64 = static_cast<int64_t>(ctx.r11.u64 * static_cast<uint64_t>(72));
	// lwzx r11,r27,r28
	ctx.r11.u64 = REX_LOAD_U32(ctx.r27.u32 + ctx.r28.u32);
	// add r11,r11,r29
	ctx.r11.u64 = ctx.r11.u64 + ctx.r29.u64;
	// lbz r11,4(r11)
	ctx.r11.u64 = REX_LOAD_U8(ctx.r11.u32 + 4);
	// clrlwi. r11,r11,31
	ctx.r11.u64 = ctx.r11.u32 & 0x1;
	ctx.cr0.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// beq 0x8b0d62fc
	if (ctx.cr0.eq) goto loc_8B0D62FC;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// bl 0x8b0d9b38
	ctx.lr = 0x8B0D6368;
	sub_8B0D9B38(ctx, base);
	// mr r8,r8
	ctx.r8.u64 = ctx.r8.u64;
	// lwzx r11,r27,r28
	ctx.r11.u64 = REX_LOAD_U32(ctx.r27.u32 + ctx.r28.u32);
	// add r11,r11,r29
	ctx.r11.u64 = ctx.r11.u64 + ctx.r29.u64;
	// lbz r11,4(r11)
	ctx.r11.u64 = REX_LOAD_U8(ctx.r11.u32 + 4);
	// clrlwi. r11,r11,31
	ctx.r11.u64 = ctx.r11.u32 & 0x1;
	ctx.cr0.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// beq 0x8b0d6398
	if (ctx.cr0.eq) goto loc_8B0D6398;
	// mr r5,r25
	ctx.r5.u64 = ctx.r25.u64;
	// mr r4,r26
	ctx.r4.u64 = ctx.r26.u64;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// bl 0x8b0d61c0
	ctx.lr = 0x8B0D6390;
	sub_8B0D61C0(ctx, base);
	// std r3,80(r31)
	REX_STORE_U64(ctx.r31.u32 + 80, ctx.r3.u64);
	// b 0x8b0d63b4
	goto loc_8B0D63B4;
loc_8B0D6398:
	// bl 0x8b0d0288
	ctx.lr = 0x8B0D639C;
	sub_8B0D0288(ctx, base);
	// li r11,9
	ctx.r11.s64 = 9;
	// stw r11,0(r3)
	REX_STORE_U32(ctx.r3.u32 + 0, ctx.r11.u32);
	// bl 0x8b0d02c0
	ctx.lr = 0x8B0D63A8;
	sub_8B0D02C0(ctx, base);
	// li r11,0
	ctx.r11.s64 = 0;
	// stw r11,0(r3)
	REX_STORE_U32(ctx.r3.u32 + 0, ctx.r11.u32);
	// std r24,80(r31)
	REX_STORE_U64(ctx.r31.u32 + 80, ctx.r24.u64);
loc_8B0D63B4:
	// mr r8,r8
	ctx.r8.u64 = ctx.r8.u64;
	// addi r12,r31,160
	ctx.r12.s64 = ctx.r31.s64 + 160;
	// bl 0x8b0d63ec
	ctx.lr = 0x8B0D63C0;
	sub_8B0D63EC(ctx, base);
	// ld r3,80(r31)
	ctx.r3.u64 = REX_LOAD_U64(ctx.r31.u32 + 80);
loc_8B0D63C4:
	// addi r1,r31,160
	ctx.r1.s64 = ctx.r31.s64 + 160;
	// b 0x8b0cb9f8
	__restgprlr_24(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0D6558) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb99c
	ctx.lr = 0x8B0D6560;
	__savegprlr_21(ctx, base);
	// ld r12,-4096(r1)
	ctx.r12.u64 = REX_LOAD_U64(ctx.r1.u32 + -4096);
	// stwu r1,-5312(r1)
	ea = -5312 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// li r21,0
	ctx.r21.s64 = 0;
	// mr r24,r4
	ctx.r24.u64 = ctx.r4.u64;
	// mr r29,r5
	ctx.r29.u64 = ctx.r5.u64;
	// cmplwi cr6,r5,0
	ctx.cr6.compare<uint32_t>(ctx.r5.u32, 0, ctx.xer);
	// mr r23,r21
	ctx.r23.u64 = ctx.r21.u64;
	// mr r22,r21
	ctx.r22.u64 = ctx.r21.u64;
	// bne cr6,0x8b0d658c
	if (!ctx.cr6.eq) goto loc_8B0D658C;
loc_8B0D6584:
	// li r3,0
	ctx.r3.s64 = 0;
	// b 0x8b0d67a4
	goto loc_8B0D67A4;
loc_8B0D658C:
	// cmplwi cr6,r24,0
	ctx.cr6.compare<uint32_t>(ctx.r24.u32, 0, ctx.xer);
	// bne cr6,0x8b0d65c8
	if (!ctx.cr6.eq) goto loc_8B0D65C8;
loc_8B0D6594:
	// bl 0x8b0d02c0
	ctx.lr = 0x8B0D6598;
	sub_8B0D02C0(ctx, base);
	// stw r21,0(r3)
	REX_STORE_U32(ctx.r3.u32 + 0, ctx.r21.u32);
	// bl 0x8b0d0288
	ctx.lr = 0x8B0D65A0;
	sub_8B0D0288(ctx, base);
	// li r11,22
	ctx.r11.s64 = 22;
	// li r7,0
	ctx.r7.s64 = 0;
	// stw r11,0(r3)
	REX_STORE_U32(ctx.r3.u32 + 0, ctx.r11.u32);
	// li r6,0
	ctx.r6.s64 = 0;
	// li r5,0
	ctx.r5.s64 = 0;
	// li r4,0
	ctx.r4.s64 = 0;
	// li r3,0
	ctx.r3.s64 = 0;
	// bl 0x8b0d0148
	ctx.lr = 0x8B0D65C0;
	sub_8B0D0148(ctx, base);
loc_8B0D65C0:
	// li r3,-1
	ctx.r3.s64 = -1;
	// b 0x8b0d67a4
	goto loc_8B0D67A4;
loc_8B0D65C8:
	// srawi r11,r3,5
	ctx.xer.ca = (ctx.r3.s32 < 0) & ((ctx.r3.u32 & 0x1F) != 0);
	ctx.r11.s64 = ctx.r3.s32 >> 5;
	// lis r10,-29936
	ctx.r10.s64 = -1961885696;
	// rlwinm r26,r11,2,0,29
	ctx.r26.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 2) & 0xFFFFFFFC;
	// addi r27,r10,-16864
	ctx.r27.s64 = ctx.r10.s64 + -16864;
	// clrlwi r11,r3,27
	ctx.r11.u64 = ctx.r3.u32 & 0x1F;
	// mulli r28,r11,72
	ctx.r28.s64 = static_cast<int64_t>(ctx.r11.u64 * static_cast<uint64_t>(72));
	// lwzx r11,r26,r27
	ctx.r11.u64 = REX_LOAD_U32(ctx.r26.u32 + ctx.r27.u32);
	// add r10,r11,r28
	ctx.r10.u64 = ctx.r11.u64 + ctx.r28.u64;
	// lbz r11,40(r10)
	ctx.r11.u64 = REX_LOAD_U8(ctx.r10.u32 + 40);
	// rotlwi r11,r11,24
	ctx.r11.u64 = __builtin_rotateleft32(ctx.r11.u32, 24);
	// srawi r11,r11,25
	ctx.xer.ca = (ctx.r11.s32 < 0) & ((ctx.r11.u32 & 0x1FFFFFF) != 0);
	ctx.r11.s64 = ctx.r11.s32 >> 25;
	// extsb r11,r11
	ctx.r11.s64 = ctx.r11.s8;
	// cmpwi cr6,r11,2
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 2, ctx.xer);
	// beq cr6,0x8b0d6608
	if (ctx.cr6.eq) goto loc_8B0D6608;
	// cmpwi cr6,r11,1
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 1, ctx.xer);
	// bne cr6,0x8b0d6614
	if (!ctx.cr6.eq) goto loc_8B0D6614;
loc_8B0D6608:
	// not r11,r29
	ctx.r11.u64 = ~ctx.r29.u64;
	// clrlwi. r11,r11,31
	ctx.r11.u64 = ctx.r11.u32 & 0x1;
	ctx.cr0.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// beq 0x8b0d6594
	if (ctx.cr0.eq) goto loc_8B0D6594;
loc_8B0D6614:
	// lbz r11,4(r10)
	ctx.r11.u64 = REX_LOAD_U8(ctx.r10.u32 + 4);
	// rlwinm. r11,r11,0,26,26
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 0) & 0x20;
	ctx.cr0.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// beq 0x8b0d662c
	if (ctx.cr0.eq) goto loc_8B0D662C;
	// li r5,2
	ctx.r5.s64 = 2;
	// li r4,0
	ctx.r4.s64 = 0;
	// bl 0x8b0d61c0
	ctx.lr = 0x8B0D662C;
	sub_8B0D61C0(ctx, base);
loc_8B0D662C:
	// lwzx r11,r26,r27
	ctx.r11.u64 = REX_LOAD_U32(ctx.r26.u32 + ctx.r27.u32);
	// add r11,r11,r28
	ctx.r11.u64 = ctx.r11.u64 + ctx.r28.u64;
	// lbz r10,4(r11)
	ctx.r10.u64 = REX_LOAD_U8(ctx.r11.u32 + 4);
	// rlwinm. r10,r10,0,0,24
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r10.u32 | (ctx.r10.u64 << 32), 0) & 0xFFFFFF80;
	ctx.cr0.compare<int32_t>(ctx.r10.s32, 0, ctx.xer);
	// beq 0x8b0d66ec
	if (ctx.cr0.eq) goto loc_8B0D66EC;
	// mr r25,r21
	ctx.r25.u64 = ctx.r21.u64;
	// mr r30,r24
	ctx.r30.u64 = ctx.r24.u64;
	// cmplwi cr6,r29,0
	ctx.cr6.compare<uint32_t>(ctx.r29.u32, 0, ctx.xer);
	// beq cr6,0x8b0d6760
	if (ctx.cr6.eq) goto loc_8B0D6760;
loc_8B0D6650:
	// addi r11,r1,96
	ctx.r11.s64 = ctx.r1.s64 + 96;
	// mr r10,r21
	ctx.r10.u64 = ctx.r21.u64;
	// subf r9,r24,r30
	ctx.r9.u64 = ctx.r30.u64 - ctx.r24.u64;
loc_8B0D665C:
	// cmplw cr6,r9,r29
	ctx.cr6.compare<uint32_t>(ctx.r9.u32, ctx.r29.u32, ctx.xer);
	// bge cr6,0x8b0d66a0
	if (!ctx.cr6.lt) goto loc_8B0D66A0;
	// lbz r8,0(r30)
	ctx.r8.u64 = REX_LOAD_U8(ctx.r30.u32 + 0);
	// addi r30,r30,1
	ctx.r30.s64 = ctx.r30.s64 + 1;
	// addi r9,r9,1
	ctx.r9.s64 = ctx.r9.s64 + 1;
	// cmplwi cr6,r8,10
	ctx.cr6.compare<uint32_t>(ctx.r8.u32, 10, ctx.xer);
	// bne cr6,0x8b0d668c
	if (!ctx.cr6.eq) goto loc_8B0D668C;
	// li r7,13
	ctx.r7.s64 = 13;
	// addi r22,r22,1
	ctx.r22.s64 = ctx.r22.s64 + 1;
	// stb r7,0(r11)
	REX_STORE_U8(ctx.r11.u32 + 0, ctx.r7.u8);
	// addi r11,r11,1
	ctx.r11.s64 = ctx.r11.s64 + 1;
	// addi r10,r10,1
	ctx.r10.s64 = ctx.r10.s64 + 1;
loc_8B0D668C:
	// addi r10,r10,1
	ctx.r10.s64 = ctx.r10.s64 + 1;
	// stb r8,0(r11)
	REX_STORE_U8(ctx.r11.u32 + 0, ctx.r8.u8);
	// addi r11,r11,1
	ctx.r11.s64 = ctx.r11.s64 + 1;
	// cmplwi cr6,r10,5119
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 5119, ctx.xer);
	// blt cr6,0x8b0d665c
	if (ctx.cr6.lt) goto loc_8B0D665C;
loc_8B0D66A0:
	// addi r10,r1,96
	ctx.r10.s64 = ctx.r1.s64 + 96;
	// lwzx r9,r26,r27
	ctx.r9.u64 = REX_LOAD_U32(ctx.r26.u32 + ctx.r27.u32);
	// li r7,0
	ctx.r7.s64 = 0;
	// subf r31,r10,r11
	ctx.r31.u64 = ctx.r11.u64 - ctx.r10.u64;
	// addi r6,r1,80
	ctx.r6.s64 = ctx.r1.s64 + 80;
	// mr r5,r31
	ctx.r5.u64 = ctx.r31.u64;
	// addi r4,r1,96
	ctx.r4.s64 = ctx.r1.s64 + 96;
	// lwzx r3,r9,r28
	ctx.r3.u64 = REX_LOAD_U32(ctx.r9.u32 + ctx.r28.u32);
	// bl 0x8b0dc998
	ctx.lr = 0x8B0D66C4;
	sub_8B0DC998(ctx, base);
	// cmpwi r3,0
	ctx.cr0.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// beq 0x8b0d6718
	if (ctx.cr0.eq) goto loc_8B0D6718;
	// lwz r11,80(r1)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r1.u32 + 80);
	// add r23,r11,r23
	ctx.r23.u64 = ctx.r11.u64 + ctx.r23.u64;
	// cmpw cr6,r11,r31
	ctx.cr6.compare<int32_t>(ctx.r11.s32, ctx.r31.s32, ctx.xer);
	// blt cr6,0x8b0d6720
	if (ctx.cr6.lt) goto loc_8B0D6720;
	// subf r11,r24,r30
	ctx.r11.u64 = ctx.r30.u64 - ctx.r24.u64;
	// cmplw cr6,r11,r29
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, ctx.r29.u32, ctx.xer);
	// blt cr6,0x8b0d6650
	if (ctx.cr6.lt) goto loc_8B0D6650;
	// b 0x8b0d6720
	goto loc_8B0D6720;
loc_8B0D66EC:
	// li r7,0
	ctx.r7.s64 = 0;
	// lwz r3,0(r11)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r11.u32 + 0);
	// addi r6,r1,80
	ctx.r6.s64 = ctx.r1.s64 + 80;
	// mr r5,r29
	ctx.r5.u64 = ctx.r29.u64;
	// mr r4,r24
	ctx.r4.u64 = ctx.r24.u64;
	// bl 0x8b0dc998
	ctx.lr = 0x8B0D6704;
	sub_8B0DC998(ctx, base);
	// cmpwi r3,0
	ctx.cr0.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// beq 0x8b0d6718
	if (ctx.cr0.eq) goto loc_8B0D6718;
	// lwz r23,80(r1)
	ctx.r23.u64 = REX_LOAD_U32(ctx.r1.u32 + 80);
	// mr r25,r21
	ctx.r25.u64 = ctx.r21.u64;
	// b 0x8b0d6720
	goto loc_8B0D6720;
loc_8B0D6718:
	// bl 0x8b0dc5d8
	ctx.lr = 0x8B0D671C;
	sub_8B0DC5D8(ctx, base);
	// mr r25,r3
	ctx.r25.u64 = ctx.r3.u64;
loc_8B0D6720:
	// cmpwi cr6,r23,0
	ctx.cr6.compare<int32_t>(ctx.r23.s32, 0, ctx.xer);
	// bne cr6,0x8b0d67a0
	if (!ctx.cr6.eq) goto loc_8B0D67A0;
	// cmplwi cr6,r25,0
	ctx.cr6.compare<uint32_t>(ctx.r25.u32, 0, ctx.xer);
	// beq cr6,0x8b0d6760
	if (ctx.cr6.eq) goto loc_8B0D6760;
	// cmplwi cr6,r25,5
	ctx.cr6.compare<uint32_t>(ctx.r25.u32, 5, ctx.xer);
	// bne cr6,0x8b0d6754
	if (!ctx.cr6.eq) goto loc_8B0D6754;
	// bl 0x8b0d0288
	ctx.lr = 0x8B0D673C;
	sub_8B0D0288(ctx, base);
	// li r11,9
	ctx.r11.s64 = 9;
	// stw r11,0(r3)
	REX_STORE_U32(ctx.r3.u32 + 0, ctx.r11.u32);
	// bl 0x8b0d02c0
	ctx.lr = 0x8B0D6748;
	sub_8B0D02C0(ctx, base);
	// li r11,5
	ctx.r11.s64 = 5;
	// stw r11,0(r3)
	REX_STORE_U32(ctx.r3.u32 + 0, ctx.r11.u32);
	// b 0x8b0d65c0
	goto loc_8B0D65C0;
loc_8B0D6754:
	// mr r3,r25
	ctx.r3.u64 = ctx.r25.u64;
	// bl 0x8b0d02f8
	ctx.lr = 0x8B0D675C;
	sub_8B0D02F8(ctx, base);
	// b 0x8b0d65c0
	goto loc_8B0D65C0;
loc_8B0D6760:
	// lwzx r11,r26,r27
	ctx.r11.u64 = REX_LOAD_U32(ctx.r26.u32 + ctx.r27.u32);
	// add r11,r11,r28
	ctx.r11.u64 = ctx.r11.u64 + ctx.r28.u64;
	// lbz r11,4(r11)
	ctx.r11.u64 = REX_LOAD_U8(ctx.r11.u32 + 4);
	// rlwinm. r11,r11,0,25,25
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 0) & 0x40;
	ctx.cr0.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// beq 0x8b0d6780
	if (ctx.cr0.eq) goto loc_8B0D6780;
	// lbz r11,0(r24)
	ctx.r11.u64 = REX_LOAD_U8(ctx.r24.u32 + 0);
	// cmplwi cr6,r11,26
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 26, ctx.xer);
	// beq cr6,0x8b0d6584
	if (ctx.cr6.eq) goto loc_8B0D6584;
loc_8B0D6780:
	// bl 0x8b0d0288
	ctx.lr = 0x8B0D6784;
	sub_8B0D0288(ctx, base);
	// li r11,28
	ctx.r11.s64 = 28;
	// stw r11,0(r3)
	REX_STORE_U32(ctx.r3.u32 + 0, ctx.r11.u32);
	// bl 0x8b0d02c0
	ctx.lr = 0x8B0D6790;
	sub_8B0D02C0(ctx, base);
	// mr r11,r3
	ctx.r11.u64 = ctx.r3.u64;
	// li r3,-1
	ctx.r3.s64 = -1;
	// stw r21,0(r11)
	REX_STORE_U32(ctx.r11.u32 + 0, ctx.r21.u32);
	// b 0x8b0d67a4
	goto loc_8B0D67A4;
loc_8B0D67A0:
	// subf r3,r22,r23
	ctx.r3.u64 = ctx.r23.u64 - ctx.r22.u64;
loc_8B0D67A4:
	// addi r1,r1,5312
	ctx.r1.s64 = ctx.r1.s64 + 5312;
	// b 0x8b0cb9ec
	__restgprlr_21(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0D6E10) {
	REX_FUNC_PROLOGUE();
	// li r7,0
	ctx.r7.s64 = 0;
	// b 0x8b0d6cf0
	sub_8B0D6CF0(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0D6E18) {
	REX_FUNC_PROLOGUE();
	// lis r11,-29938
	ctx.r11.s64 = -1962016768;
	// rlwinm r10,r3,1,23,30
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r3.u32 | (ctx.r3.u64 << 32), 1) & 0x1FE;
	// lwz r11,12512(r11)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r11.u32 + 12512);
	// lwz r11,200(r11)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r11.u32 + 200);
	// lhzx r11,r10,r11
	ctx.r11.u64 = REX_LOAD_U16(ctx.r10.u32 + ctx.r11.u32);
	// rlwinm r3,r11,0,0,16
	ctx.r3.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 0) & 0xFFFF8000;
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0D6FF8) {
	REX_FUNC_PROLOGUE();
	PPCRegister temp{};
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// std r31,-16(r1)
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.r31.u64);
	// stwu r1,-96(r1)
	ea = -96 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lwz r9,12(r6)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r6.u32 + 12);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// bne cr6,0x8b0d7040
	if (!ctx.cr6.eq) goto loc_8B0D7040;
	// bl 0x8b0d0288
	ctx.lr = 0x8B0D7018;
	sub_8B0D0288(ctx, base);
	// li r11,22
	ctx.r11.s64 = 22;
	// li r7,0
	ctx.r7.s64 = 0;
	// stw r11,0(r3)
	REX_STORE_U32(ctx.r3.u32 + 0, ctx.r11.u32);
	// li r6,0
	ctx.r6.s64 = 0;
	// li r5,0
	ctx.r5.s64 = 0;
	// li r4,0
	ctx.r4.s64 = 0;
	// li r3,0
	ctx.r3.s64 = 0;
	// bl 0x8b0d0148
	ctx.lr = 0x8B0D7038;
	sub_8B0D0148(ctx, base);
	// li r3,22
	ctx.r3.s64 = 22;
	// b 0x8b0d716c
	goto loc_8B0D716C;
loc_8B0D7040:
	// cmplwi cr6,r4,0
	ctx.cr6.compare<uint32_t>(ctx.r4.u32, 0, ctx.xer);
	// bne cr6,0x8b0d7074
	if (!ctx.cr6.eq) goto loc_8B0D7074;
	// bl 0x8b0d0288
	ctx.lr = 0x8B0D704C;
	sub_8B0D0288(ctx, base);
	// li r31,22
	ctx.r31.s64 = 22;
loc_8B0D7050:
	// stw r31,0(r3)
	REX_STORE_U32(ctx.r3.u32 + 0, ctx.r31.u32);
	// li r7,0
	ctx.r7.s64 = 0;
	// li r6,0
	ctx.r6.s64 = 0;
	// li r5,0
	ctx.r5.s64 = 0;
	// li r4,0
	ctx.r4.s64 = 0;
	// li r3,0
	ctx.r3.s64 = 0;
	// bl 0x8b0d0148
	ctx.lr = 0x8B0D706C;
	sub_8B0D0148(ctx, base);
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// b 0x8b0d716c
	goto loc_8B0D716C;
loc_8B0D7074:
	// subfic r11,r5,0
	ctx.xer.ca = ctx.r5.u32 <= 0;
	ctx.r11.u64 = static_cast<uint64_t>(0) - ctx.r5.u64;
	// rlwinm r11,r5,1,31,31
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r5.u32 | (ctx.r5.u64 << 32), 1) & 0x1;
	// li r8,0
	ctx.r8.s64 = 0;
	// addme r11,r11
	temp.u8 = (ctx.r11.u32 + 0xFFFFFFFFu < ctx.r11.u32) | (ctx.r11.u32 + 0xFFFFFFFFu + ctx.xer.ca < ctx.xer.ca);
	ctx.r11.u64 = ctx.r11.u64 + ctx.xer.ca + 0xFFFFFFFFFFFFFFFFull;
	ctx.xer.ca = temp.u8;
	// stb r8,0(r3)
	REX_STORE_U8(ctx.r3.u32 + 0, ctx.r8.u8);
	// and r11,r11,r5
	ctx.r11.u64 = ctx.r11.u64 & ctx.r5.u64;
	// addi r11,r11,1
	ctx.r11.s64 = ctx.r11.s64 + 1;
	// cmplw cr6,r4,r11
	ctx.cr6.compare<uint32_t>(ctx.r4.u32, ctx.r11.u32, ctx.xer);
	// bgt cr6,0x8b0d70a4
	if (ctx.cr6.gt) goto loc_8B0D70A4;
	// bl 0x8b0d0288
	ctx.lr = 0x8B0D709C;
	sub_8B0D0288(ctx, base);
	// li r31,34
	ctx.r31.s64 = 34;
	// b 0x8b0d7050
	goto loc_8B0D7050;
loc_8B0D70A4:
	// li r7,48
	ctx.r7.s64 = 48;
	// addi r4,r3,1
	ctx.r4.s64 = ctx.r3.s64 + 1;
	// stb r7,0(r3)
	REX_STORE_U8(ctx.r3.u32 + 0, ctx.r7.u8);
	// cmpwi cr6,r5,0
	ctx.cr6.compare<int32_t>(ctx.r5.s32, 0, ctx.xer);
	// mr r11,r4
	ctx.r11.u64 = ctx.r4.u64;
	// ble cr6,0x8b0d70e8
	if (!ctx.cr6.gt) goto loc_8B0D70E8;
	// mtctr r5
	ctx.ctr.u64 = ctx.r5.u64;
	// mr r5,r8
	ctx.r5.u64 = ctx.r8.u64;
loc_8B0D70C4:
	// lbz r10,0(r9)
	ctx.r10.u64 = REX_LOAD_U8(ctx.r9.u32 + 0);
	// cmplwi r10,0
	ctx.cr0.compare<uint32_t>(ctx.r10.u32, 0, ctx.xer);
	// beq 0x8b0d70d8
	if (ctx.cr0.eq) goto loc_8B0D70D8;
	// addi r9,r9,1
	ctx.r9.s64 = ctx.r9.s64 + 1;
	// b 0x8b0d70dc
	goto loc_8B0D70DC;
loc_8B0D70D8:
	// mr r10,r7
	ctx.r10.u64 = ctx.r7.u64;
loc_8B0D70DC:
	// stb r10,0(r11)
	REX_STORE_U8(ctx.r11.u32 + 0, ctx.r10.u8);
	// addi r11,r11,1
	ctx.r11.s64 = ctx.r11.s64 + 1;
	// bdnz 0x8b0d70c4
	--ctx.ctr.u64;
	if (ctx.ctr.u32 != 0) goto loc_8B0D70C4;
loc_8B0D70E8:
	// cmpwi cr6,r5,0
	ctx.cr6.compare<int32_t>(ctx.r5.s32, 0, ctx.xer);
	// stb r8,0(r11)
	REX_STORE_U8(ctx.r11.u32 + 0, ctx.r8.u8);
	// blt cr6,0x8b0d7124
	if (ctx.cr6.lt) goto loc_8B0D7124;
	// lbz r10,0(r9)
	ctx.r10.u64 = REX_LOAD_U8(ctx.r9.u32 + 0);
	// extsb r10,r10
	ctx.r10.s64 = ctx.r10.s8;
	// cmpwi cr6,r10,53
	ctx.cr6.compare<int32_t>(ctx.r10.s32, 53, ctx.xer);
	// blt cr6,0x8b0d7124
	if (ctx.cr6.lt) goto loc_8B0D7124;
	// b 0x8b0d710c
	goto loc_8B0D710C;
loc_8B0D7108:
	// stb r7,0(r11)
	REX_STORE_U8(ctx.r11.u32 + 0, ctx.r7.u8);
loc_8B0D710C:
	// lbzu r10,-1(r11)
	ea = -1 + ctx.r11.u32;
	ctx.r10.u64 = REX_LOAD_U8(ea);
	ctx.r11.u32 = ea;
	// cmplwi cr6,r10,57
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 57, ctx.xer);
	// beq cr6,0x8b0d7108
	if (ctx.cr6.eq) goto loc_8B0D7108;
	// lbz r10,0(r11)
	ctx.r10.u64 = REX_LOAD_U8(ctx.r11.u32 + 0);
	// addi r10,r10,1
	ctx.r10.s64 = ctx.r10.s64 + 1;
	// stb r10,0(r11)
	REX_STORE_U8(ctx.r11.u32 + 0, ctx.r10.u8);
loc_8B0D7124:
	// lbz r11,0(r3)
	ctx.r11.u64 = REX_LOAD_U8(ctx.r3.u32 + 0);
	// cmplwi cr6,r11,49
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 49, ctx.xer);
	// bne cr6,0x8b0d7140
	if (!ctx.cr6.eq) goto loc_8B0D7140;
	// lwz r11,4(r6)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r6.u32 + 4);
	// addi r11,r11,1
	ctx.r11.s64 = ctx.r11.s64 + 1;
	// stw r11,4(r6)
	REX_STORE_U32(ctx.r6.u32 + 4, ctx.r11.u32);
	// b 0x8b0d7168
	goto loc_8B0D7168;
loc_8B0D7140:
	// mr r11,r4
	ctx.r11.u64 = ctx.r4.u64;
loc_8B0D7144:
	// lbz r10,0(r11)
	ctx.r10.u64 = REX_LOAD_U8(ctx.r11.u32 + 0);
	// addi r11,r11,1
	ctx.r11.s64 = ctx.r11.s64 + 1;
	// cmplwi cr6,r10,0
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 0, ctx.xer);
	// bne cr6,0x8b0d7144
	if (!ctx.cr6.eq) goto loc_8B0D7144;
	// subf r11,r4,r11
	ctx.r11.u64 = ctx.r11.u64 - ctx.r4.u64;
	// addi r11,r11,-1
	ctx.r11.s64 = ctx.r11.s64 + -1;
	// rotlwi r11,r11,0
	ctx.r11.u64 = __builtin_rotateleft32(ctx.r11.u32, 0);
	// addi r5,r11,1
	ctx.r5.s64 = ctx.r11.s64 + 1;
	// bl 0x8b0cc060
	ctx.lr = 0x8B0D7168;
	sub_8B0CC060(ctx, base);
loc_8B0D7168:
	// li r3,0
	ctx.r3.s64 = 0;
loc_8B0D716C:
	// addi r1,r1,96
	ctx.r1.s64 = ctx.r1.s64 + 96;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0D7A88) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// std r31,-8(r1)
	REX_STORE_U64(ctx.r1.u32 + -8, ctx.r31.u64);
	// addi r31,r12,-128
	ctx.r31.s64 = ctx.r12.s64 + -128;
	// std r30,-16(r1)
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.r30.u64);
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-24(r1)
	REX_STORE_U32(ctx.r1.u32 + -24, ctx.r12.u32);
	// stwu r1,-112(r1)
	ea = -112 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lwz r30,156(r31)
	ctx.r30.u64 = REX_LOAD_U32(ctx.r31.u32 + 156);
	// b 0x8b0d7ac0
	goto loc_8B0D7AC0;
loc_8B0D7AC0:
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// bl 0x8b0d6c08
	ctx.lr = 0x8B0D7AC8;
	sub_8B0D6C08(ctx, base);
	// lwz r1,0(r1)
	ctx.r1.u64 = REX_LOAD_U32(ctx.r1.u32 + 0);
	// ld r31,-8(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -8);
	// ld r30,-16(r1)
	ctx.r30.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// lwz r12,-24(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -24);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0D7AA8) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// std r31,-8(r1)
	REX_STORE_U64(ctx.r1.u32 + -8, ctx.r31.u64);
	// addi r31,r12,-128
	ctx.r31.s64 = ctx.r12.s64 + -128;
	// std r30,-16(r1)
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.r30.u64);
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-24(r1)
	REX_STORE_U32(ctx.r1.u32 + -24, ctx.r12.u32);
	// stwu r1,-112(r1)
	ea = -112 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// bl 0x8b0d6c08
	ctx.lr = 0x8B0D7AC8;
	sub_8B0D6C08(ctx, base);
	// lwz r1,0(r1)
	ctx.r1.u64 = REX_LOAD_U32(ctx.r1.u32 + 0);
	// ld r31,-8(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -8);
	// ld r30,-16(r1)
	ctx.r30.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// lwz r12,-24(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -24);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0D7B30) {
	REX_FUNC_PROLOGUE();
	// mffs f0
	ctx.f0.u64 = ctx.fpscr.loadFromHost();
	// stfd f0,-8(r1)
	ctx.fpscr.disableFlushMode();
	REX_STORE_U64(ctx.r1.u32 + -8, ctx.f0.u64);
	// xori r5,r3,248
	ctx.r5.u64 = ctx.r3.u64 ^ 248;
	// lwz r3,-4(r1)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r1.u32 + -4);
	// and r5,r5,r4
	ctx.r5.u64 = ctx.r5.u64 & ctx.r4.u64;
	// andc r6,r3,r4
	ctx.r6.u64 = ctx.r3.u64 & ~ctx.r4.u64;
	// or r6,r5,r6
	ctx.r6.u64 = ctx.r5.u64 | ctx.r6.u64;
	// stw r6,-4(r1)
	REX_STORE_U32(ctx.r1.u32 + -4, ctx.r6.u32);
	// lfd f0,-8(r1)
	ctx.f0.u64 = REX_LOAD_U64(ctx.r1.u32 + -8);
	// xori r3,r3,248
	ctx.r3.u64 = ctx.r3.u64 ^ 248;
	// mtfsf 255,f0
	ctx.fpscr.storeFromGuest(ctx.f0.u32);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0D7B70) {
	REX_FUNC_PROLOGUE();
	// mffs f0
	ctx.f0.u64 = ctx.fpscr.loadFromHost();
	// li r3,4
	ctx.r3.s64 = 4;
	// stfd f0,-8(r1)
	ctx.fpscr.disableFlushMode();
	REX_STORE_U64(ctx.r1.u32 + -8, ctx.f0.u64);
	// lwz r5,-4(r1)
	ctx.r5.u64 = REX_LOAD_U32(ctx.r1.u32 + -4);
	// and r5,r3,r5
	ctx.r5.u64 = ctx.r3.u64 & ctx.r5.u64;
	// stw r5,-4(r1)
	REX_STORE_U32(ctx.r1.u32 + -4, ctx.r5.u32);
	// lfd f1,-8(r1)
	ctx.f1.u64 = REX_LOAD_U64(ctx.r1.u32 + -8);
	// mtfsf 255,f1
	ctx.fpscr.storeFromGuest(ctx.f1.u32);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0D7BB4) {
	REX_FUNC_PROLOGUE();
	// stw r3,-4(r1)
	REX_STORE_U32(ctx.r1.u32 + -4, ctx.r3.u32);
	// lfd f1,-8(r1)
	ctx.fpscr.disableFlushMode();
	ctx.f1.u64 = REX_LOAD_U64(ctx.r1.u32 + -8);
	// mtfsf 255,f1
	ctx.fpscr.storeFromGuest(ctx.f1.u32);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0D7BD8) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9b4
	ctx.lr = 0x8B0D7BE0;
	__savegprlr_27(ctx, base);
	// stwu r1,-144(r1)
	ea = -144 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// mr r27,r3
	ctx.r27.u64 = ctx.r3.u64;
	// mr r31,r4
	ctx.r31.u64 = ctx.r4.u64;
	// bl 0x8b0d69d0
	ctx.lr = 0x8B0D7BF0;
	sub_8B0D69D0(ctx, base);
	// addi r11,r3,32
	ctx.r11.s64 = ctx.r3.s64 + 32;
	// cmplw cr6,r31,r11
	ctx.cr6.compare<uint32_t>(ctx.r31.u32, ctx.r11.u32, ctx.xer);
	// beq cr6,0x8b0d7e10
	if (ctx.cr6.eq) goto loc_8B0D7E10;
	// bl 0x8b0d69d0
	ctx.lr = 0x8B0D7C00;
	sub_8B0D69D0(ctx, base);
	// addi r11,r3,64
	ctx.r11.s64 = ctx.r3.s64 + 64;
	// cmplw cr6,r31,r11
	ctx.cr6.compare<uint32_t>(ctx.r31.u32, ctx.r11.u32, ctx.xer);
	// beq cr6,0x8b0d7e10
	if (ctx.cr6.eq) goto loc_8B0D7E10;
	// lwz r11,12(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 12);
	// rlwinm. r11,r11,0,25,25
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 0) & 0x40;
	ctx.cr0.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// bne 0x8b0d7dd4
	if (!ctx.cr0.eq) goto loc_8B0D7DD4;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0d6c70
	ctx.lr = 0x8B0D7C20;
	sub_8B0D6C70(ctx, base);
	// lis r10,-29936
	ctx.r10.s64 = -1961885696;
	// lis r11,-29938
	ctx.r11.s64 = -1962016768;
	// cmpwi cr6,r3,-1
	ctx.cr6.compare<int32_t>(ctx.r3.s32, -1, ctx.xer);
	// addi r30,r10,-16864
	ctx.r30.s64 = ctx.r10.s64 + -16864;
	// addi r28,r11,12856
	ctx.r28.s64 = ctx.r11.s64 + 12856;
	// beq cr6,0x8b0d7c74
	if (ctx.cr6.eq) goto loc_8B0D7C74;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0d6c70
	ctx.lr = 0x8B0D7C40;
	sub_8B0D6C70(ctx, base);
	// cmpwi cr6,r3,-2
	ctx.cr6.compare<int32_t>(ctx.r3.s32, -2, ctx.xer);
	// beq cr6,0x8b0d7c74
	if (ctx.cr6.eq) goto loc_8B0D7C74;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0d6c70
	ctx.lr = 0x8B0D7C50;
	sub_8B0D6C70(ctx, base);
	// srawi r11,r3,5
	ctx.xer.ca = (ctx.r3.s32 < 0) & ((ctx.r3.u32 & 0x1F) != 0);
	ctx.r11.s64 = ctx.r3.s32 >> 5;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// rlwinm r29,r11,2,0,29
	ctx.r29.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 2) & 0xFFFFFFFC;
	// bl 0x8b0d6c70
	ctx.lr = 0x8B0D7C60;
	sub_8B0D6C70(ctx, base);
	// clrlwi r11,r3,27
	ctx.r11.u64 = ctx.r3.u32 & 0x1F;
	// lwzx r10,r29,r30
	ctx.r10.u64 = REX_LOAD_U32(ctx.r29.u32 + ctx.r30.u32);
	// mulli r11,r11,72
	ctx.r11.s64 = static_cast<int64_t>(ctx.r11.u64 * static_cast<uint64_t>(72));
	// add r11,r11,r10
	ctx.r11.u64 = ctx.r11.u64 + ctx.r10.u64;
	// b 0x8b0d7c78
	goto loc_8B0D7C78;
loc_8B0D7C74:
	// mr r11,r28
	ctx.r11.u64 = ctx.r28.u64;
loc_8B0D7C78:
	// lbz r11,40(r11)
	ctx.r11.u64 = REX_LOAD_U8(ctx.r11.u32 + 40);
	// rlwinm r11,r11,0,0,30
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 0) & 0xFFFFFFFE;
	// cmplwi cr6,r11,4
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 4, ctx.xer);
	// beq cr6,0x8b0d7dd4
	if (ctx.cr6.eq) goto loc_8B0D7DD4;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0d6c70
	ctx.lr = 0x8B0D7C90;
	sub_8B0D6C70(ctx, base);
	// cmpwi cr6,r3,-1
	ctx.cr6.compare<int32_t>(ctx.r3.s32, -1, ctx.xer);
	// beq cr6,0x8b0d7cd4
	if (ctx.cr6.eq) goto loc_8B0D7CD4;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0d6c70
	ctx.lr = 0x8B0D7CA0;
	sub_8B0D6C70(ctx, base);
	// cmpwi cr6,r3,-2
	ctx.cr6.compare<int32_t>(ctx.r3.s32, -2, ctx.xer);
	// beq cr6,0x8b0d7cd4
	if (ctx.cr6.eq) goto loc_8B0D7CD4;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0d6c70
	ctx.lr = 0x8B0D7CB0;
	sub_8B0D6C70(ctx, base);
	// srawi r11,r3,5
	ctx.xer.ca = (ctx.r3.s32 < 0) & ((ctx.r3.u32 & 0x1F) != 0);
	ctx.r11.s64 = ctx.r3.s32 >> 5;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// rlwinm r29,r11,2,0,29
	ctx.r29.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 2) & 0xFFFFFFFC;
	// bl 0x8b0d6c70
	ctx.lr = 0x8B0D7CC0;
	sub_8B0D6C70(ctx, base);
	// clrlwi r11,r3,27
	ctx.r11.u64 = ctx.r3.u32 & 0x1F;
	// lwzx r10,r29,r30
	ctx.r10.u64 = REX_LOAD_U32(ctx.r29.u32 + ctx.r30.u32);
	// mulli r11,r11,72
	ctx.r11.s64 = static_cast<int64_t>(ctx.r11.u64 * static_cast<uint64_t>(72));
	// add r11,r11,r10
	ctx.r11.u64 = ctx.r11.u64 + ctx.r10.u64;
	// b 0x8b0d7cd8
	goto loc_8B0D7CD8;
loc_8B0D7CD4:
	// mr r11,r28
	ctx.r11.u64 = ctx.r28.u64;
loc_8B0D7CD8:
	// lbz r11,40(r11)
	ctx.r11.u64 = REX_LOAD_U8(ctx.r11.u32 + 40);
	// rlwinm r11,r11,0,0,30
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 0) & 0xFFFFFFFE;
	// cmplwi cr6,r11,2
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 2, ctx.xer);
	// beq cr6,0x8b0d7dd4
	if (ctx.cr6.eq) goto loc_8B0D7DD4;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0d6c70
	ctx.lr = 0x8B0D7CF0;
	sub_8B0D6C70(ctx, base);
	// cmpwi cr6,r3,-1
	ctx.cr6.compare<int32_t>(ctx.r3.s32, -1, ctx.xer);
	// beq cr6,0x8b0d7d34
	if (ctx.cr6.eq) goto loc_8B0D7D34;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0d6c70
	ctx.lr = 0x8B0D7D00;
	sub_8B0D6C70(ctx, base);
	// cmpwi cr6,r3,-2
	ctx.cr6.compare<int32_t>(ctx.r3.s32, -2, ctx.xer);
	// beq cr6,0x8b0d7d34
	if (ctx.cr6.eq) goto loc_8B0D7D34;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0d6c70
	ctx.lr = 0x8B0D7D10;
	sub_8B0D6C70(ctx, base);
	// srawi r11,r3,5
	ctx.xer.ca = (ctx.r3.s32 < 0) & ((ctx.r3.u32 & 0x1F) != 0);
	ctx.r11.s64 = ctx.r3.s32 >> 5;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// rlwinm r29,r11,2,0,29
	ctx.r29.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 2) & 0xFFFFFFFC;
	// bl 0x8b0d6c70
	ctx.lr = 0x8B0D7D20;
	sub_8B0D6C70(ctx, base);
	// clrlwi r11,r3,27
	ctx.r11.u64 = ctx.r3.u32 & 0x1F;
	// lwzx r10,r29,r30
	ctx.r10.u64 = REX_LOAD_U32(ctx.r29.u32 + ctx.r30.u32);
	// mulli r11,r11,72
	ctx.r11.s64 = static_cast<int64_t>(ctx.r11.u64 * static_cast<uint64_t>(72));
	// add r11,r11,r10
	ctx.r11.u64 = ctx.r11.u64 + ctx.r10.u64;
	// b 0x8b0d7d38
	goto loc_8B0D7D38;
loc_8B0D7D34:
	// mr r11,r28
	ctx.r11.u64 = ctx.r28.u64;
loc_8B0D7D38:
	// lbz r11,4(r11)
	ctx.r11.u64 = REX_LOAD_U8(ctx.r11.u32 + 4);
	// rlwinm. r11,r11,0,0,24
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 0) & 0xFFFFFF80;
	ctx.cr0.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// beq 0x8b0d7dd4
	if (ctx.cr0.eq) goto loc_8B0D7DD4;
	// mr r6,r27
	ctx.r6.u64 = ctx.r27.u64;
	// li r5,5
	ctx.r5.s64 = 5;
	// addi r4,r1,84
	ctx.r4.s64 = ctx.r1.s64 + 84;
	// addi r3,r1,80
	ctx.r3.s64 = ctx.r1.s64 + 80;
	// bl 0x8b0d6e10
	ctx.lr = 0x8B0D7D58;
	sub_8B0D6E10(ctx, base);
	// cmpwi r3,0
	ctx.cr0.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// beq 0x8b0d7d68
	if (ctx.cr0.eq) goto loc_8B0D7D68;
loc_8B0D7D60:
	// li r3,-1
	ctx.r3.s64 = -1;
	// b 0x8b0d7e28
	goto loc_8B0D7E28;
loc_8B0D7D68:
	// lwz r11,80(r1)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r1.u32 + 80);
	// li r30,0
	ctx.r30.s64 = 0;
	// cmpwi cr6,r11,0
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// ble cr6,0x8b0d7e24
	if (!ctx.cr6.gt) goto loc_8B0D7E24;
loc_8B0D7D78:
	// lwz r11,4(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 4);
	// addic. r11,r11,-1
	ctx.xer.ca = ctx.r11.u32 > 0;
	ctx.r11.s64 = ctx.r11.s64 + -1;
	ctx.cr0.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// stw r11,4(r31)
	REX_STORE_U32(ctx.r31.u32 + 4, ctx.r11.u32);
	// addi r11,r1,84
	ctx.r11.s64 = ctx.r1.s64 + 84;
	// lbzx r11,r30,r11
	ctx.r11.u64 = REX_LOAD_U8(ctx.r30.u32 + ctx.r11.u32);
	// blt 0x8b0d7dac
	if (ctx.cr0.lt) goto loc_8B0D7DAC;
	// lwz r10,0(r31)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r31.u32 + 0);
	// stb r11,0(r10)
	REX_STORE_U8(ctx.r10.u32 + 0, ctx.r11.u8);
	// lwz r11,0(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 0);
	// addi r10,r11,1
	ctx.r10.s64 = ctx.r11.s64 + 1;
	// lbz r3,0(r11)
	ctx.r3.u64 = REX_LOAD_U8(ctx.r11.u32 + 0);
	// stw r10,0(r31)
	REX_STORE_U32(ctx.r31.u32 + 0, ctx.r10.u32);
	// b 0x8b0d7db8
	goto loc_8B0D7DB8;
loc_8B0D7DAC:
	// mr r4,r31
	ctx.r4.u64 = ctx.r31.u64;
	// extsb r3,r11
	ctx.r3.s64 = ctx.r11.s8;
	// bl 0x8b0cf2e0
	ctx.lr = 0x8B0D7DB8;
	sub_8B0CF2E0(ctx, base);
loc_8B0D7DB8:
	// cmpwi cr6,r3,-1
	ctx.cr6.compare<int32_t>(ctx.r3.s32, -1, ctx.xer);
	// beq cr6,0x8b0d7d60
	if (ctx.cr6.eq) goto loc_8B0D7D60;
	// lwz r11,80(r1)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r1.u32 + 80);
	// addi r30,r30,1
	ctx.r30.s64 = ctx.r30.s64 + 1;
	// cmpw cr6,r30,r11
	ctx.cr6.compare<int32_t>(ctx.r30.s32, ctx.r11.s32, ctx.xer);
	// blt cr6,0x8b0d7d78
	if (ctx.cr6.lt) goto loc_8B0D7D78;
	// b 0x8b0d7e24
	goto loc_8B0D7E24;
loc_8B0D7DD4:
	// lwz r11,4(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 4);
	// addic. r11,r11,-2
	ctx.xer.ca = ctx.r11.u32 > 1;
	ctx.r11.s64 = ctx.r11.s64 + -2;
	ctx.cr0.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// stw r11,4(r31)
	REX_STORE_U32(ctx.r31.u32 + 4, ctx.r11.u32);
	// blt 0x8b0d7dfc
	if (ctx.cr0.lt) goto loc_8B0D7DFC;
	// lwz r11,0(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 0);
	// sth r27,0(r11)
	REX_STORE_U16(ctx.r11.u32 + 0, ctx.r27.u16);
	// lwz r11,0(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 0);
	// addi r11,r11,2
	ctx.r11.s64 = ctx.r11.s64 + 2;
	// stw r11,0(r31)
	REX_STORE_U32(ctx.r31.u32 + 0, ctx.r11.u32);
	// b 0x8b0d7e24
	goto loc_8B0D7E24;
loc_8B0D7DFC:
	// mr r4,r31
	ctx.r4.u64 = ctx.r31.u64;
	// clrlwi r3,r27,16
	ctx.r3.u64 = ctx.r27.u32 & 0xFFFF;
	// bl 0x8b0db3f0
	ctx.lr = 0x8B0D7E08;
	sub_8B0DB3F0(ctx, base);
	// clrlwi r3,r3,16
	ctx.r3.u64 = ctx.r3.u32 & 0xFFFF;
	// b 0x8b0d7e28
	goto loc_8B0D7E28;
loc_8B0D7E10:
	// li r11,0
	ctx.r11.s64 = 0;
	// sth r27,80(r1)
	REX_STORE_U16(ctx.r1.u32 + 80, ctx.r27.u16);
	// addi r3,r1,80
	ctx.r3.s64 = ctx.r1.s64 + 80;
	// sth r11,82(r1)
	REX_STORE_U16(ctx.r1.u32 + 82, ctx.r11.u16);
	// bl 0x8b0dc7b8
	ctx.lr = 0x8B0D7E24;
	sub_8B0DC7B8(ctx, base);
loc_8B0D7E24:
	// mr r3,r27
	ctx.r3.u64 = ctx.r27.u64;
loc_8B0D7E28:
	// addi r1,r1,144
	ctx.r1.s64 = ctx.r1.s64 + 144;
	// b 0x8b0cba04
	__restgprlr_27(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0D8900) {
	REX_FUNC_PROLOGUE();
	// li r8,0
	ctx.r8.s64 = 0;
	// b 0x8b0d87b0
	sub_8B0D87B0(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0D8908) {
	REX_FUNC_PROLOGUE();
	PPCRegister temp{};
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb994
	ctx.lr = 0x8B0D8910;
	__savegprlr_19(ctx, base);
	// lhz r9,0(r3)
	ctx.r9.u64 = REX_LOAD_U16(ctx.r3.u32 + 0);
	// lis r10,-29938
	ctx.r10.s64 = -1962016768;
	// lhz r8,10(r3)
	ctx.r8.u64 = REX_LOAD_U16(ctx.r3.u32 + 10);
	// li r23,0
	ctx.r23.s64 = 0;
	// clrlwi r11,r9,17
	ctx.r11.u64 = ctx.r9.u32 & 0x7FFF;
	// lwz r7,2(r3)
	ctx.r7.u64 = REX_LOAD_U32(ctx.r3.u32 + 2);
	// lwz r6,6(r3)
	ctx.r6.u64 = REX_LOAD_U32(ctx.r3.u32 + 6);
	// addi r20,r10,14592
	ctx.r20.s64 = ctx.r10.s64 + 14592;
	// addi r30,r11,-16383
	ctx.r30.s64 = ctx.r11.s64 + -16383;
	// rotlwi r11,r8,16
	ctx.r11.u64 = __builtin_rotateleft32(ctx.r8.u32, 16);
	// rlwinm r19,r9,0,0,16
	ctx.r19.u64 = __builtin_rotateleft64(ctx.r9.u32 | (ctx.r9.u64 << 32), 0) & 0xFFFF8000;
	// stw r7,-152(r1)
	REX_STORE_U32(ctx.r1.u32 + -152, ctx.r7.u32);
	// cmpwi cr6,r30,-16383
	ctx.cr6.compare<int32_t>(ctx.r30.s32, -16383, ctx.xer);
	// lwz r21,12(r20)
	ctx.r21.u64 = REX_LOAD_U32(ctx.r20.u32 + 12);
	// addi r10,r1,-152
	ctx.r10.s64 = ctx.r1.s64 + -152;
	// stw r6,-148(r1)
	REX_STORE_U32(ctx.r1.u32 + -148, ctx.r6.u32);
	// mr r5,r23
	ctx.r5.u64 = ctx.r23.u64;
	// stw r11,-144(r1)
	REX_STORE_U32(ctx.r1.u32 + -144, ctx.r11.u32);
	// bne cr6,0x8b0d8998
	if (!ctx.cr6.eq) goto loc_8B0D8998;
	// mr r11,r23
	ctx.r11.u64 = ctx.r23.u64;
loc_8B0D8960:
	// lwz r9,0(r10)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r10.u32 + 0);
	// cmplwi cr6,r9,0
	ctx.cr6.compare<uint32_t>(ctx.r9.u32, 0, ctx.xer);
	// bne cr6,0x8b0d8980
	if (!ctx.cr6.eq) goto loc_8B0D8980;
	// addi r11,r11,1
	ctx.r11.s64 = ctx.r11.s64 + 1;
	// addi r10,r10,4
	ctx.r10.s64 = ctx.r10.s64 + 4;
	// cmpwi cr6,r11,3
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 3, ctx.xer);
	// blt cr6,0x8b0d8960
	if (ctx.cr6.lt) goto loc_8B0D8960;
	// b 0x8b0d8fcc
	goto loc_8B0D8FCC;
loc_8B0D8980:
	// addi r11,r1,-152
	ctx.r11.s64 = ctx.r1.s64 + -152;
	// li r3,2
	ctx.r3.s64 = 2;
	// stw r23,0(r11)
	REX_STORE_U32(ctx.r11.u32 + 0, ctx.r23.u32);
	// stw r23,4(r11)
	REX_STORE_U32(ctx.r11.u32 + 4, ctx.r23.u32);
	// stw r23,8(r11)
	REX_STORE_U32(ctx.r11.u32 + 8, ctx.r23.u32);
	// b 0x8b0d8fd0
	goto loc_8B0D8FD0;
loc_8B0D8998:
	// lwz r25,8(r20)
	ctx.r25.u64 = REX_LOAD_U32(ctx.r20.u32 + 8);
	// addi r8,r1,-136
	ctx.r8.s64 = ctx.r1.s64 + -136;
	// lwz r9,0(r10)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r10.u32 + 0);
	// addi r28,r1,-152
	ctx.r28.s64 = ctx.r1.s64 + -152;
	// addi r26,r25,-1
	ctx.r26.s64 = ctx.r25.s64 + -1;
	// lwz r6,4(r10)
	ctx.r6.u64 = REX_LOAD_U32(ctx.r10.u32 + 4);
	// lwz r10,8(r10)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r10.u32 + 8);
	// li r3,1
	ctx.r3.s64 = 1;
	// addi r11,r26,1
	ctx.r11.s64 = ctx.r26.s64 + 1;
	// li r22,-1
	ctx.r22.s64 = -1;
	// srawi r7,r11,5
	ctx.xer.ca = (ctx.r11.s32 < 0) & ((ctx.r11.u32 & 0x1F) != 0);
	ctx.r7.s64 = ctx.r11.s32 >> 5;
	// stw r9,0(r8)
	REX_STORE_U32(ctx.r8.u32 + 0, ctx.r9.u32);
	// stw r6,4(r8)
	REX_STORE_U32(ctx.r8.u32 + 4, ctx.r6.u32);
	// mr r24,r30
	ctx.r24.u64 = ctx.r30.u64;
	// addze r31,r7
	temp.s64 = ctx.r7.s64 + ctx.xer.ca;
	ctx.xer.ca = temp.u32 < ctx.r7.u32;
	ctx.r31.s64 = temp.s64;
	// stw r10,8(r8)
	REX_STORE_U32(ctx.r8.u32 + 8, ctx.r10.u32);
	// srawi r7,r11,5
	ctx.xer.ca = (ctx.r11.s32 < 0) & ((ctx.r11.u32 & 0x1F) != 0);
	ctx.r7.s64 = ctx.r11.s32 >> 5;
	// rlwinm r27,r31,2,0,29
	ctx.r27.u64 = __builtin_rotateleft64(ctx.r31.u32 | (ctx.r31.u64 << 32), 2) & 0xFFFFFFFC;
	// addze r9,r7
	temp.s64 = ctx.r7.s64 + ctx.xer.ca;
	ctx.xer.ca = temp.u32 < ctx.r7.u32;
	ctx.r9.s64 = temp.s64;
	// rlwinm r10,r9,5,0,26
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r9.u32 | (ctx.r9.u64 << 32), 5) & 0xFFFFFFE0;
	// subf r11,r10,r11
	ctx.r11.u64 = ctx.r11.u64 - ctx.r10.u64;
	// lwzx r10,r27,r28
	ctx.r10.u64 = REX_LOAD_U32(ctx.r27.u32 + ctx.r28.u32);
	// subfic r29,r11,31
	ctx.xer.ca = ctx.r11.u32 <= 31;
	ctx.r29.u64 = static_cast<uint64_t>(31) - ctx.r11.u64;
	// slw r11,r3,r29
	ctx.r11.u64 = ctx.r29.u8 & 0x20 ? 0 : (ctx.r3.u32 << (ctx.r29.u8 & 0x3F));
	// and. r11,r11,r10
	ctx.r11.u64 = ctx.r11.u64 & ctx.r10.u64;
	ctx.cr0.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// beq 0x8b0d8ae4
	if (ctx.cr0.eq) goto loc_8B0D8AE4;
	// rlwinm r11,r31,2,0,29
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r31.u32 | (ctx.r31.u64 << 32), 2) & 0xFFFFFFFC;
	// addi r10,r1,-152
	ctx.r10.s64 = ctx.r1.s64 + -152;
	// slw r9,r22,r29
	ctx.r9.u64 = ctx.r29.u8 & 0x20 ? 0 : (ctx.r22.u32 << (ctx.r29.u8 & 0x3F));
	// lwzx r11,r11,r10
	ctx.r11.u64 = REX_LOAD_U32(ctx.r11.u32 + ctx.r10.u32);
	// andc. r11,r11,r9
	ctx.r11.u64 = ctx.r11.u64 & ~ctx.r9.u64;
	ctx.cr0.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// bne 0x8b0d8a50
	if (!ctx.cr0.eq) goto loc_8B0D8A50;
	// addi r11,r31,1
	ctx.r11.s64 = ctx.r31.s64 + 1;
	// cmpwi cr6,r11,3
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 3, ctx.xer);
	// bge cr6,0x8b0d8ae4
	if (!ctx.cr6.lt) goto loc_8B0D8AE4;
	// rlwinm r9,r11,2,0,29
	ctx.r9.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 2) & 0xFFFFFFFC;
	// addi r10,r1,-152
	ctx.r10.s64 = ctx.r1.s64 + -152;
	// add r10,r9,r10
	ctx.r10.u64 = ctx.r9.u64 + ctx.r10.u64;
loc_8B0D8A30:
	// lwz r9,0(r10)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r10.u32 + 0);
	// cmplwi cr6,r9,0
	ctx.cr6.compare<uint32_t>(ctx.r9.u32, 0, ctx.xer);
	// bne cr6,0x8b0d8a50
	if (!ctx.cr6.eq) goto loc_8B0D8A50;
	// addi r11,r11,1
	ctx.r11.s64 = ctx.r11.s64 + 1;
	// addi r10,r10,4
	ctx.r10.s64 = ctx.r10.s64 + 4;
	// cmpwi cr6,r11,3
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 3, ctx.xer);
	// blt cr6,0x8b0d8a30
	if (ctx.cr6.lt) goto loc_8B0D8A30;
	// b 0x8b0d8ae4
	goto loc_8B0D8AE4;
loc_8B0D8A50:
	// srawi r11,r26,5
	ctx.xer.ca = (ctx.r26.s32 < 0) & ((ctx.r26.u32 & 0x1F) != 0);
	ctx.r11.s64 = ctx.r26.s32 >> 5;
	// addi r8,r1,-152
	ctx.r8.s64 = ctx.r1.s64 + -152;
	// addze r9,r11
	temp.s64 = ctx.r11.s64 + ctx.xer.ca;
	ctx.xer.ca = temp.u32 < ctx.r11.u32;
	ctx.r9.s64 = temp.s64;
	// srawi r11,r26,5
	ctx.xer.ca = (ctx.r26.s32 < 0) & ((ctx.r26.u32 & 0x1F) != 0);
	ctx.r11.s64 = ctx.r26.s32 >> 5;
	// rlwinm r7,r9,2,0,29
	ctx.r7.u64 = __builtin_rotateleft64(ctx.r9.u32 | (ctx.r9.u64 << 32), 2) & 0xFFFFFFFC;
	// addze r11,r11
	temp.s64 = ctx.r11.s64 + ctx.xer.ca;
	ctx.xer.ca = temp.u32 < ctx.r11.u32;
	ctx.r11.s64 = temp.s64;
	// mr r5,r23
	ctx.r5.u64 = ctx.r23.u64;
	// rlwinm r11,r11,5,0,26
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 5) & 0xFFFFFFE0;
	// subf r10,r11,r26
	ctx.r10.u64 = ctx.r26.u64 - ctx.r11.u64;
	// lwzx r11,r7,r8
	ctx.r11.u64 = REX_LOAD_U32(ctx.r7.u32 + ctx.r8.u32);
	// subfic r10,r10,31
	ctx.xer.ca = ctx.r10.u32 <= 31;
	ctx.r10.u64 = static_cast<uint64_t>(31) - ctx.r10.u64;
	// slw r6,r3,r10
	ctx.r6.u64 = ctx.r10.u8 & 0x20 ? 0 : (ctx.r3.u32 << (ctx.r10.u8 & 0x3F));
	// add r10,r11,r6
	ctx.r10.u64 = ctx.r11.u64 + ctx.r6.u64;
	// cmplw cr6,r10,r11
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, ctx.r11.u32, ctx.xer);
	// blt cr6,0x8b0d8a94
	if (ctx.cr6.lt) goto loc_8B0D8A94;
	// cmplw cr6,r10,r6
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, ctx.r6.u32, ctx.xer);
	// bge cr6,0x8b0d8a98
	if (!ctx.cr6.lt) goto loc_8B0D8A98;
loc_8B0D8A94:
	// mr r5,r3
	ctx.r5.u64 = ctx.r3.u64;
loc_8B0D8A98:
	// addic. r11,r9,-1
	ctx.xer.ca = ctx.r9.u32 > 0;
	ctx.r11.s64 = ctx.r9.s64 + -1;
	ctx.cr0.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// stwx r10,r7,r8
	REX_STORE_U32(ctx.r7.u32 + ctx.r8.u32, ctx.r10.u32);
	// blt 0x8b0d8ae4
	if (ctx.cr0.lt) goto loc_8B0D8AE4;
	// rlwinm r9,r11,2,0,29
	ctx.r9.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 2) & 0xFFFFFFFC;
	// addi r10,r1,-148
	ctx.r10.s64 = ctx.r1.s64 + -148;
	// add r10,r9,r10
	ctx.r10.u64 = ctx.r9.u64 + ctx.r10.u64;
loc_8B0D8AB0:
	// cmpwi cr6,r5,0
	ctx.cr6.compare<int32_t>(ctx.r5.s32, 0, ctx.xer);
	// beq cr6,0x8b0d8ae4
	if (ctx.cr6.eq) goto loc_8B0D8AE4;
	// lwz r9,-4(r10)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r10.u32 + -4);
	// mr r5,r23
	ctx.r5.u64 = ctx.r23.u64;
	// addi r8,r9,1
	ctx.r8.s64 = ctx.r9.s64 + 1;
	// cmplw cr6,r8,r9
	ctx.cr6.compare<uint32_t>(ctx.r8.u32, ctx.r9.u32, ctx.xer);
	// blt cr6,0x8b0d8ad4
	if (ctx.cr6.lt) goto loc_8B0D8AD4;
	// cmplwi cr6,r8,1
	ctx.cr6.compare<uint32_t>(ctx.r8.u32, 1, ctx.xer);
	// bge cr6,0x8b0d8ad8
	if (!ctx.cr6.lt) goto loc_8B0D8AD8;
loc_8B0D8AD4:
	// mr r5,r3
	ctx.r5.u64 = ctx.r3.u64;
loc_8B0D8AD8:
	// addic. r11,r11,-1
	ctx.xer.ca = ctx.r11.u32 > 0;
	ctx.r11.s64 = ctx.r11.s64 + -1;
	ctx.cr0.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// stwu r8,-4(r10)
	ea = -4 + ctx.r10.u32;
	REX_STORE_U32(ea, ctx.r8.u32);
	ctx.r10.u32 = ea;
	// bge 0x8b0d8ab0
	if (!ctx.cr0.lt) goto loc_8B0D8AB0;
loc_8B0D8AE4:
	// lwzx r10,r27,r28
	ctx.r10.u64 = REX_LOAD_U32(ctx.r27.u32 + ctx.r28.u32);
	// slw r9,r22,r29
	ctx.r9.u64 = ctx.r29.u8 & 0x20 ? 0 : (ctx.r22.u32 << (ctx.r29.u8 & 0x3F));
	// addi r11,r31,1
	ctx.r11.s64 = ctx.r31.s64 + 1;
	// and r10,r9,r10
	ctx.r10.u64 = ctx.r9.u64 & ctx.r10.u64;
	// cmpwi cr6,r11,3
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 3, ctx.xer);
	// stwx r10,r27,r28
	REX_STORE_U32(ctx.r27.u32 + ctx.r28.u32, ctx.r10.u32);
	// bge cr6,0x8b0d8b2c
	if (!ctx.cr6.lt) goto loc_8B0D8B2C;
	// rlwinm r9,r11,2,0,29
	ctx.r9.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 2) & 0xFFFFFFFC;
	// addi r10,r1,-152
	ctx.r10.s64 = ctx.r1.s64 + -152;
	// subfic r11,r11,3
	ctx.xer.ca = ctx.r11.u32 <= 3;
	ctx.r11.u64 = static_cast<uint64_t>(3) - ctx.r11.u64;
	// add r10,r9,r10
	ctx.r10.u64 = ctx.r9.u64 + ctx.r10.u64;
	// mr r9,r23
	ctx.r9.u64 = ctx.r23.u64;
	// addi r10,r10,-4
	ctx.r10.s64 = ctx.r10.s64 + -4;
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// beq cr6,0x8b0d8b2c
	if (ctx.cr6.eq) goto loc_8B0D8B2C;
	// mtctr r11
	ctx.ctr.u64 = ctx.r11.u64;
loc_8B0D8B24:
	// stwu r9,4(r10)
	ea = 4 + ctx.r10.u32;
	REX_STORE_U32(ea, ctx.r9.u32);
	ctx.r10.u32 = ea;
	// bdnz 0x8b0d8b24
	--ctx.ctr.u64;
	if (ctx.ctr.u32 != 0) goto loc_8B0D8B24;
loc_8B0D8B2C:
	// cmpwi cr6,r5,0
	ctx.cr6.compare<int32_t>(ctx.r5.s32, 0, ctx.xer);
	// beq cr6,0x8b0d8b38
	if (ctx.cr6.eq) goto loc_8B0D8B38;
	// addi r30,r30,1
	ctx.r30.s64 = ctx.r30.s64 + 1;
loc_8B0D8B38:
	// lwz r11,4(r20)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r20.u32 + 4);
	// subf r10,r25,r11
	ctx.r10.u64 = ctx.r11.u64 - ctx.r25.u64;
	// cmpw cr6,r30,r10
	ctx.cr6.compare<int32_t>(ctx.r30.s32, ctx.r10.s32, ctx.xer);
	// bge cr6,0x8b0d8b64
	if (!ctx.cr6.lt) goto loc_8B0D8B64;
	// addi r11,r1,-152
	ctx.r11.s64 = ctx.r1.s64 + -152;
	// mr r5,r23
	ctx.r5.u64 = ctx.r23.u64;
	// li r3,2
	ctx.r3.s64 = 2;
	// stw r23,0(r11)
	REX_STORE_U32(ctx.r11.u32 + 0, ctx.r23.u32);
	// stw r23,4(r11)
	REX_STORE_U32(ctx.r11.u32 + 4, ctx.r23.u32);
	// stw r23,8(r11)
	REX_STORE_U32(ctx.r11.u32 + 8, ctx.r23.u32);
	// b 0x8b0d8fd0
	goto loc_8B0D8FD0;
loc_8B0D8B64:
	// li r10,3
	ctx.r10.s64 = 3;
	// cmpw cr6,r30,r11
	ctx.cr6.compare<int32_t>(ctx.r30.s32, ctx.r11.s32, ctx.xer);
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// bgt cr6,0x8b0d8e4c
	if (ctx.cr6.gt) goto loc_8B0D8E4C;
	// subf r11,r24,r11
	ctx.r11.u64 = ctx.r11.u64 - ctx.r24.u64;
	// addi r9,r1,-136
	ctx.r9.s64 = ctx.r1.s64 + -136;
	// srawi r8,r11,5
	ctx.xer.ca = (ctx.r11.s32 < 0) & ((ctx.r11.u32 & 0x1F) != 0);
	ctx.r8.s64 = ctx.r11.s32 >> 5;
	// addi r6,r1,-152
	ctx.r6.s64 = ctx.r1.s64 + -152;
	// addze r5,r8
	temp.s64 = ctx.r8.s64 + ctx.xer.ca;
	ctx.xer.ca = temp.u32 < ctx.r8.u32;
	ctx.r5.s64 = temp.s64;
	// srawi r8,r11,5
	ctx.xer.ca = (ctx.r11.s32 < 0) & ((ctx.r11.u32 & 0x1F) != 0);
	ctx.r8.s64 = ctx.r11.s32 >> 5;
	// lwz r7,0(r9)
	ctx.r7.u64 = REX_LOAD_U32(ctx.r9.u32 + 0);
	// li r27,-1
	ctx.r27.s64 = -1;
	// addze r8,r8
	temp.s64 = ctx.r8.s64 + ctx.xer.ca;
	ctx.xer.ca = temp.u32 < ctx.r8.u32;
	ctx.r8.s64 = temp.s64;
	// lwz r31,4(r9)
	ctx.r31.u64 = REX_LOAD_U32(ctx.r9.u32 + 4);
	// lwz r30,8(r9)
	ctx.r30.u64 = REX_LOAD_U32(ctx.r9.u32 + 8);
	// addi r9,r1,-152
	ctx.r9.s64 = ctx.r1.s64 + -152;
	// rlwinm r8,r8,5,0,26
	ctx.r8.u64 = __builtin_rotateleft64(ctx.r8.u32 | (ctx.r8.u64 << 32), 5) & 0xFFFFFFE0;
	// subf r11,r8,r11
	ctx.r11.u64 = ctx.r11.u64 - ctx.r8.u64;
	// stw r7,0(r6)
	REX_STORE_U32(ctx.r6.u32 + 0, ctx.r7.u32);
	// stw r31,4(r6)
	REX_STORE_U32(ctx.r6.u32 + 4, ctx.r31.u32);
	// mr r8,r23
	ctx.r8.u64 = ctx.r23.u64;
	// slw r10,r27,r11
	ctx.r10.u64 = ctx.r11.u8 & 0x20 ? 0 : (ctx.r27.u32 << (ctx.r11.u8 & 0x3F));
	// stw r30,8(r6)
	REX_STORE_U32(ctx.r6.u32 + 8, ctx.r30.u32);
	// not r7,r10
	ctx.r7.u64 = ~ctx.r10.u64;
	// subfic r6,r11,32
	ctx.xer.ca = ctx.r11.u32 <= 32;
	ctx.r6.u64 = static_cast<uint64_t>(32) - ctx.r11.u64;
	// addi r10,r9,-4
	ctx.r10.s64 = ctx.r9.s64 + -4;
loc_8B0D8BCC:
	// lwz r9,4(r10)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r10.u32 + 4);
	// and r31,r9,r7
	ctx.r31.u64 = ctx.r9.u64 & ctx.r7.u64;
	// stw r31,-160(r1)
	REX_STORE_U32(ctx.r1.u32 + -160, ctx.r31.u32);
	// srw r9,r9,r11
	ctx.r9.u64 = ctx.r11.u8 & 0x20 ? 0 : (ctx.r9.u32 >> (ctx.r11.u8 & 0x3F));
	// or r9,r9,r8
	ctx.r9.u64 = ctx.r9.u64 | ctx.r8.u64;
	// stwu r9,4(r10)
	ea = 4 + ctx.r10.u32;
	REX_STORE_U32(ea, ctx.r9.u32);
	ctx.r10.u32 = ea;
	// lwz r9,-160(r1)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r1.u32 + -160);
	// slw r8,r9,r6
	ctx.r8.u64 = ctx.r6.u8 & 0x20 ? 0 : (ctx.r9.u32 << (ctx.r6.u8 & 0x3F));
	// bdnz 0x8b0d8bcc
	--ctx.ctr.u64;
	if (ctx.ctr.u32 != 0) goto loc_8B0D8BCC;
	// li r10,3
	ctx.r10.s64 = 3;
	// rlwinm r8,r5,2,0,29
	ctx.r8.u64 = __builtin_rotateleft64(ctx.r5.u32 | (ctx.r5.u64 << 32), 2) & 0xFFFFFFFC;
	// addi r7,r1,-144
	ctx.r7.s64 = ctx.r1.s64 + -144;
	// li r9,2
	ctx.r9.s64 = 2;
	// addi r11,r1,-144
	ctx.r11.s64 = ctx.r1.s64 + -144;
	// subf r8,r8,r7
	ctx.r8.u64 = ctx.r7.u64 - ctx.r8.u64;
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
loc_8B0D8C0C:
	// cmpw cr6,r9,r5
	ctx.cr6.compare<int32_t>(ctx.r9.s32, ctx.r5.s32, ctx.xer);
	// blt cr6,0x8b0d8c20
	if (ctx.cr6.lt) goto loc_8B0D8C20;
	// lwz r10,0(r8)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r8.u32 + 0);
	// stw r10,0(r11)
	REX_STORE_U32(ctx.r11.u32 + 0, ctx.r10.u32);
	// b 0x8b0d8c24
	goto loc_8B0D8C24;
loc_8B0D8C20:
	// stw r23,0(r11)
	REX_STORE_U32(ctx.r11.u32 + 0, ctx.r23.u32);
loc_8B0D8C24:
	// addi r9,r9,-1
	ctx.r9.s64 = ctx.r9.s64 + -1;
	// addi r8,r8,-4
	ctx.r8.s64 = ctx.r8.s64 + -4;
	// addi r11,r11,-4
	ctx.r11.s64 = ctx.r11.s64 + -4;
	// bdnz 0x8b0d8c0c
	--ctx.ctr.u64;
	if (ctx.ctr.u32 != 0) goto loc_8B0D8C0C;
	// addi r11,r26,1
	ctx.r11.s64 = ctx.r26.s64 + 1;
	// addi r29,r1,-152
	ctx.r29.s64 = ctx.r1.s64 + -152;
	// srawi r10,r11,5
	ctx.xer.ca = (ctx.r11.s32 < 0) & ((ctx.r11.u32 & 0x1F) != 0);
	ctx.r10.s64 = ctx.r11.s32 >> 5;
	// addze r31,r10
	temp.s64 = ctx.r10.s64 + ctx.xer.ca;
	ctx.xer.ca = temp.u32 < ctx.r10.u32;
	ctx.r31.s64 = temp.s64;
	// srawi r10,r11,5
	ctx.xer.ca = (ctx.r11.s32 < 0) & ((ctx.r11.u32 & 0x1F) != 0);
	ctx.r10.s64 = ctx.r11.s32 >> 5;
	// rlwinm r28,r31,2,0,29
	ctx.r28.u64 = __builtin_rotateleft64(ctx.r31.u32 | (ctx.r31.u64 << 32), 2) & 0xFFFFFFFC;
	// addze r10,r10
	temp.s64 = ctx.r10.s64 + ctx.xer.ca;
	ctx.xer.ca = temp.u32 < ctx.r10.u32;
	ctx.r10.s64 = temp.s64;
	// rlwinm r10,r10,5,0,26
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r10.u32 | (ctx.r10.u64 << 32), 5) & 0xFFFFFFE0;
	// subf r11,r10,r11
	ctx.r11.u64 = ctx.r11.u64 - ctx.r10.u64;
	// lwzx r10,r28,r29
	ctx.r10.u64 = REX_LOAD_U32(ctx.r28.u32 + ctx.r29.u32);
	// subfic r30,r11,31
	ctx.xer.ca = ctx.r11.u32 <= 31;
	ctx.r30.u64 = static_cast<uint64_t>(31) - ctx.r11.u64;
	// slw r11,r3,r30
	ctx.r11.u64 = ctx.r30.u8 & 0x20 ? 0 : (ctx.r3.u32 << (ctx.r30.u8 & 0x3F));
	// and. r11,r11,r10
	ctx.r11.u64 = ctx.r11.u64 & ctx.r10.u64;
	ctx.cr0.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// beq 0x8b0d8d54
	if (ctx.cr0.eq) goto loc_8B0D8D54;
	// rlwinm r11,r31,2,0,29
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r31.u32 | (ctx.r31.u64 << 32), 2) & 0xFFFFFFFC;
	// addi r10,r1,-152
	ctx.r10.s64 = ctx.r1.s64 + -152;
	// slw r9,r22,r30
	ctx.r9.u64 = ctx.r30.u8 & 0x20 ? 0 : (ctx.r22.u32 << (ctx.r30.u8 & 0x3F));
	// lwzx r11,r11,r10
	ctx.r11.u64 = REX_LOAD_U32(ctx.r11.u32 + ctx.r10.u32);
	// andc. r11,r11,r9
	ctx.r11.u64 = ctx.r11.u64 & ~ctx.r9.u64;
	ctx.cr0.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// bne 0x8b0d8cbc
	if (!ctx.cr0.eq) goto loc_8B0D8CBC;
	// addi r11,r31,1
	ctx.r11.s64 = ctx.r31.s64 + 1;
	// cmpwi cr6,r11,3
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 3, ctx.xer);
	// bge cr6,0x8b0d8d54
	if (!ctx.cr6.lt) goto loc_8B0D8D54;
	// rlwinm r9,r11,2,0,29
	ctx.r9.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 2) & 0xFFFFFFFC;
	// addi r10,r1,-152
	ctx.r10.s64 = ctx.r1.s64 + -152;
	// add r10,r9,r10
	ctx.r10.u64 = ctx.r9.u64 + ctx.r10.u64;
loc_8B0D8C9C:
	// lwz r9,0(r10)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r10.u32 + 0);
	// cmplwi cr6,r9,0
	ctx.cr6.compare<uint32_t>(ctx.r9.u32, 0, ctx.xer);
	// bne cr6,0x8b0d8cbc
	if (!ctx.cr6.eq) goto loc_8B0D8CBC;
	// addi r11,r11,1
	ctx.r11.s64 = ctx.r11.s64 + 1;
	// addi r10,r10,4
	ctx.r10.s64 = ctx.r10.s64 + 4;
	// cmpwi cr6,r11,3
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 3, ctx.xer);
	// blt cr6,0x8b0d8c9c
	if (ctx.cr6.lt) goto loc_8B0D8C9C;
	// b 0x8b0d8d54
	goto loc_8B0D8D54;
loc_8B0D8CBC:
	// srawi r11,r26,5
	ctx.xer.ca = (ctx.r26.s32 < 0) & ((ctx.r26.u32 & 0x1F) != 0);
	ctx.r11.s64 = ctx.r26.s32 >> 5;
	// addi r8,r1,-152
	ctx.r8.s64 = ctx.r1.s64 + -152;
	// addze r9,r11
	temp.s64 = ctx.r11.s64 + ctx.xer.ca;
	ctx.xer.ca = temp.u32 < ctx.r11.u32;
	ctx.r9.s64 = temp.s64;
	// srawi r11,r26,5
	ctx.xer.ca = (ctx.r26.s32 < 0) & ((ctx.r26.u32 & 0x1F) != 0);
	ctx.r11.s64 = ctx.r26.s32 >> 5;
	// rlwinm r7,r9,2,0,29
	ctx.r7.u64 = __builtin_rotateleft64(ctx.r9.u32 | (ctx.r9.u64 << 32), 2) & 0xFFFFFFFC;
	// addze r11,r11
	temp.s64 = ctx.r11.s64 + ctx.xer.ca;
	ctx.xer.ca = temp.u32 < ctx.r11.u32;
	ctx.r11.s64 = temp.s64;
	// mr r5,r23
	ctx.r5.u64 = ctx.r23.u64;
	// rlwinm r11,r11,5,0,26
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 5) & 0xFFFFFFE0;
	// subf r10,r11,r26
	ctx.r10.u64 = ctx.r26.u64 - ctx.r11.u64;
	// lwzx r11,r7,r8
	ctx.r11.u64 = REX_LOAD_U32(ctx.r7.u32 + ctx.r8.u32);
	// subfic r10,r10,31
	ctx.xer.ca = ctx.r10.u32 <= 31;
	ctx.r10.u64 = static_cast<uint64_t>(31) - ctx.r10.u64;
	// slw r6,r3,r10
	ctx.r6.u64 = ctx.r10.u8 & 0x20 ? 0 : (ctx.r3.u32 << (ctx.r10.u8 & 0x3F));
	// add r10,r11,r6
	ctx.r10.u64 = ctx.r11.u64 + ctx.r6.u64;
	// cmplw cr6,r10,r11
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, ctx.r11.u32, ctx.xer);
	// blt cr6,0x8b0d8d00
	if (ctx.cr6.lt) goto loc_8B0D8D00;
	// cmplw cr6,r10,r6
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, ctx.r6.u32, ctx.xer);
	// bge cr6,0x8b0d8d04
	if (!ctx.cr6.lt) goto loc_8B0D8D04;
loc_8B0D8D00:
	// mr r5,r3
	ctx.r5.u64 = ctx.r3.u64;
loc_8B0D8D04:
	// stwx r10,r7,r8
	REX_STORE_U32(ctx.r7.u32 + ctx.r8.u32, ctx.r10.u32);
	// addic. r11,r9,-1
	ctx.xer.ca = ctx.r9.u32 > 0;
	ctx.r11.s64 = ctx.r9.s64 + -1;
	ctx.cr0.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// mr r7,r5
	ctx.r7.u64 = ctx.r5.u64;
	// blt 0x8b0d8d54
	if (ctx.cr0.lt) goto loc_8B0D8D54;
	// rlwinm r9,r11,2,0,29
	ctx.r9.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 2) & 0xFFFFFFFC;
	// addi r10,r1,-148
	ctx.r10.s64 = ctx.r1.s64 + -148;
	// add r10,r9,r10
	ctx.r10.u64 = ctx.r9.u64 + ctx.r10.u64;
loc_8B0D8D20:
	// cmpwi cr6,r7,0
	ctx.cr6.compare<int32_t>(ctx.r7.s32, 0, ctx.xer);
	// beq cr6,0x8b0d8d54
	if (ctx.cr6.eq) goto loc_8B0D8D54;
	// lwz r9,-4(r10)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r10.u32 + -4);
	// mr r7,r23
	ctx.r7.u64 = ctx.r23.u64;
	// addi r8,r9,1
	ctx.r8.s64 = ctx.r9.s64 + 1;
	// cmplw cr6,r8,r9
	ctx.cr6.compare<uint32_t>(ctx.r8.u32, ctx.r9.u32, ctx.xer);
	// blt cr6,0x8b0d8d44
	if (ctx.cr6.lt) goto loc_8B0D8D44;
	// cmplwi cr6,r8,1
	ctx.cr6.compare<uint32_t>(ctx.r8.u32, 1, ctx.xer);
	// bge cr6,0x8b0d8d48
	if (!ctx.cr6.lt) goto loc_8B0D8D48;
loc_8B0D8D44:
	// mr r7,r3
	ctx.r7.u64 = ctx.r3.u64;
loc_8B0D8D48:
	// addic. r11,r11,-1
	ctx.xer.ca = ctx.r11.u32 > 0;
	ctx.r11.s64 = ctx.r11.s64 + -1;
	ctx.cr0.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// stwu r8,-4(r10)
	ea = -4 + ctx.r10.u32;
	REX_STORE_U32(ea, ctx.r8.u32);
	ctx.r10.u32 = ea;
	// bge 0x8b0d8d20
	if (!ctx.cr0.lt) goto loc_8B0D8D20;
loc_8B0D8D54:
	// lwzx r10,r28,r29
	ctx.r10.u64 = REX_LOAD_U32(ctx.r28.u32 + ctx.r29.u32);
	// slw r9,r22,r30
	ctx.r9.u64 = ctx.r30.u8 & 0x20 ? 0 : (ctx.r22.u32 << (ctx.r30.u8 & 0x3F));
	// addi r11,r31,1
	ctx.r11.s64 = ctx.r31.s64 + 1;
	// and r10,r9,r10
	ctx.r10.u64 = ctx.r9.u64 & ctx.r10.u64;
	// cmpwi cr6,r11,3
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 3, ctx.xer);
	// stwx r10,r28,r29
	REX_STORE_U32(ctx.r28.u32 + ctx.r29.u32, ctx.r10.u32);
	// bge cr6,0x8b0d8d9c
	if (!ctx.cr6.lt) goto loc_8B0D8D9C;
	// rlwinm r9,r11,2,0,29
	ctx.r9.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 2) & 0xFFFFFFFC;
	// addi r10,r1,-152
	ctx.r10.s64 = ctx.r1.s64 + -152;
	// subfic r11,r11,3
	ctx.xer.ca = ctx.r11.u32 <= 3;
	ctx.r11.u64 = static_cast<uint64_t>(3) - ctx.r11.u64;
	// add r10,r9,r10
	ctx.r10.u64 = ctx.r9.u64 + ctx.r10.u64;
	// mr r9,r23
	ctx.r9.u64 = ctx.r23.u64;
	// addi r10,r10,-4
	ctx.r10.s64 = ctx.r10.s64 + -4;
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// beq cr6,0x8b0d8d9c
	if (ctx.cr6.eq) goto loc_8B0D8D9C;
	// mtctr r11
	ctx.ctr.u64 = ctx.r11.u64;
loc_8B0D8D94:
	// stwu r9,4(r10)
	ea = 4 + ctx.r10.u32;
	REX_STORE_U32(ea, ctx.r9.u32);
	ctx.r10.u32 = ea;
	// bdnz 0x8b0d8d94
	--ctx.ctr.u64;
	if (ctx.ctr.u32 != 0) goto loc_8B0D8D94;
loc_8B0D8D9C:
	// addi r11,r21,1
	ctx.r11.s64 = ctx.r21.s64 + 1;
	// li r10,3
	ctx.r10.s64 = 3;
	// srawi r8,r11,5
	ctx.xer.ca = (ctx.r11.s32 < 0) & ((ctx.r11.u32 & 0x1F) != 0);
	ctx.r8.s64 = ctx.r11.s32 >> 5;
	// addi r9,r1,-152
	ctx.r9.s64 = ctx.r1.s64 + -152;
	// addze r6,r8
	temp.s64 = ctx.r8.s64 + ctx.xer.ca;
	ctx.xer.ca = temp.u32 < ctx.r8.u32;
	ctx.r6.s64 = temp.s64;
	// srawi r8,r11,5
	ctx.xer.ca = (ctx.r11.s32 < 0) & ((ctx.r11.u32 & 0x1F) != 0);
	ctx.r8.s64 = ctx.r11.s32 >> 5;
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
	// addi r10,r9,-4
	ctx.r10.s64 = ctx.r9.s64 + -4;
	// addze r9,r8
	temp.s64 = ctx.r8.s64 + ctx.xer.ca;
	ctx.xer.ca = temp.u32 < ctx.r8.u32;
	ctx.r9.s64 = temp.s64;
	// mr r8,r23
	ctx.r8.u64 = ctx.r23.u64;
	// rlwinm r9,r9,5,0,26
	ctx.r9.u64 = __builtin_rotateleft64(ctx.r9.u32 | (ctx.r9.u64 << 32), 5) & 0xFFFFFFE0;
	// subf r11,r9,r11
	ctx.r11.u64 = ctx.r11.u64 - ctx.r9.u64;
	// slw r9,r27,r11
	ctx.r9.u64 = ctx.r11.u8 & 0x20 ? 0 : (ctx.r27.u32 << (ctx.r11.u8 & 0x3F));
	// not r9,r9
	ctx.r9.u64 = ~ctx.r9.u64;
	// subfic r7,r11,32
	ctx.xer.ca = ctx.r11.u32 <= 32;
	ctx.r7.u64 = static_cast<uint64_t>(32) - ctx.r11.u64;
loc_8B0D8DD8:
	// lwz r5,4(r10)
	ctx.r5.u64 = REX_LOAD_U32(ctx.r10.u32 + 4);
	// and r3,r5,r9
	ctx.r3.u64 = ctx.r5.u64 & ctx.r9.u64;
	// stw r3,-160(r1)
	REX_STORE_U32(ctx.r1.u32 + -160, ctx.r3.u32);
	// srw r5,r5,r11
	ctx.r5.u64 = ctx.r11.u8 & 0x20 ? 0 : (ctx.r5.u32 >> (ctx.r11.u8 & 0x3F));
	// or r8,r5,r8
	ctx.r8.u64 = ctx.r5.u64 | ctx.r8.u64;
	// stwu r8,4(r10)
	ea = 4 + ctx.r10.u32;
	REX_STORE_U32(ea, ctx.r8.u32);
	ctx.r10.u32 = ea;
	// lwz r8,-160(r1)
	ctx.r8.u64 = REX_LOAD_U32(ctx.r1.u32 + -160);
	// slw r8,r8,r7
	ctx.r8.u64 = ctx.r7.u8 & 0x20 ? 0 : (ctx.r8.u32 << (ctx.r7.u8 & 0x3F));
	// bdnz 0x8b0d8dd8
	--ctx.ctr.u64;
	if (ctx.ctr.u32 != 0) goto loc_8B0D8DD8;
	// li r10,3
	ctx.r10.s64 = 3;
	// rlwinm r8,r6,2,0,29
	ctx.r8.u64 = __builtin_rotateleft64(ctx.r6.u32 | (ctx.r6.u64 << 32), 2) & 0xFFFFFFFC;
	// addi r7,r1,-144
	ctx.r7.s64 = ctx.r1.s64 + -144;
	// li r9,2
	ctx.r9.s64 = 2;
	// addi r11,r1,-144
	ctx.r11.s64 = ctx.r1.s64 + -144;
	// subf r8,r8,r7
	ctx.r8.u64 = ctx.r7.u64 - ctx.r8.u64;
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
loc_8B0D8E18:
	// cmpw cr6,r9,r6
	ctx.cr6.compare<int32_t>(ctx.r9.s32, ctx.r6.s32, ctx.xer);
	// blt cr6,0x8b0d8e2c
	if (ctx.cr6.lt) goto loc_8B0D8E2C;
	// lwz r10,0(r8)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r8.u32 + 0);
	// stw r10,0(r11)
	REX_STORE_U32(ctx.r11.u32 + 0, ctx.r10.u32);
	// b 0x8b0d8e30
	goto loc_8B0D8E30;
loc_8B0D8E2C:
	// stw r23,0(r11)
	REX_STORE_U32(ctx.r11.u32 + 0, ctx.r23.u32);
loc_8B0D8E30:
	// addi r9,r9,-1
	ctx.r9.s64 = ctx.r9.s64 + -1;
	// addi r8,r8,-4
	ctx.r8.s64 = ctx.r8.s64 + -4;
	// addi r11,r11,-4
	ctx.r11.s64 = ctx.r11.s64 + -4;
	// bdnz 0x8b0d8e18
	--ctx.ctr.u64;
	if (ctx.ctr.u32 != 0) goto loc_8B0D8E18;
	// mr r5,r23
	ctx.r5.u64 = ctx.r23.u64;
	// li r3,2
	ctx.r3.s64 = 2;
	// b 0x8b0d8fd0
	goto loc_8B0D8FD0;
loc_8B0D8E4C:
	// lwz r5,0(r20)
	ctx.r5.u64 = REX_LOAD_U32(ctx.r20.u32 + 0);
	// cmpw cr6,r30,r5
	ctx.cr6.compare<int32_t>(ctx.r30.s32, ctx.r5.s32, ctx.xer);
	// blt cr6,0x8b0d8f1c
	if (ctx.cr6.lt) goto loc_8B0D8F1C;
	// addi r11,r1,-152
	ctx.r11.s64 = ctx.r1.s64 + -152;
	// srawi r9,r21,5
	ctx.xer.ca = (ctx.r21.s32 < 0) & ((ctx.r21.u32 & 0x1F) != 0);
	ctx.r9.s64 = ctx.r21.s32 >> 5;
	// li r7,-1
	ctx.r7.s64 = -1;
	// addze r6,r9
	temp.s64 = ctx.r9.s64 + ctx.xer.ca;
	ctx.xer.ca = temp.u32 < ctx.r9.u32;
	ctx.r6.s64 = temp.s64;
	// srawi r9,r21,5
	ctx.xer.ca = (ctx.r21.s32 < 0) & ((ctx.r21.u32 & 0x1F) != 0);
	ctx.r9.s64 = ctx.r21.s32 >> 5;
	// stw r23,0(r11)
	REX_STORE_U32(ctx.r11.u32 + 0, ctx.r23.u32);
	// stw r23,4(r11)
	REX_STORE_U32(ctx.r11.u32 + 4, ctx.r23.u32);
	// addze r8,r9
	temp.s64 = ctx.r9.s64 + ctx.xer.ca;
	ctx.xer.ca = temp.u32 < ctx.r9.u32;
	ctx.r8.s64 = temp.s64;
	// stw r23,8(r11)
	REX_STORE_U32(ctx.r11.u32 + 8, ctx.r23.u32);
	// rlwinm r11,r8,5,0,26
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r8.u32 | (ctx.r8.u64 << 32), 5) & 0xFFFFFFE0;
	// addi r9,r1,-152
	ctx.r9.s64 = ctx.r1.s64 + -152;
	// subf r11,r11,r21
	ctx.r11.u64 = ctx.r21.u64 - ctx.r11.u64;
	// addi r10,r9,-4
	ctx.r10.s64 = ctx.r9.s64 + -4;
	// slw r9,r7,r11
	ctx.r9.u64 = ctx.r11.u8 & 0x20 ? 0 : (ctx.r7.u32 << (ctx.r11.u8 & 0x3F));
	// lwz r31,-152(r1)
	ctx.r31.u64 = REX_LOAD_U32(ctx.r1.u32 + -152);
	// mr r8,r23
	ctx.r8.u64 = ctx.r23.u64;
	// not r9,r9
	ctx.r9.u64 = ~ctx.r9.u64;
	// oris r31,r31,32768
	ctx.r31.u64 = ctx.r31.u64 | 2147483648;
	// subfic r7,r11,32
	ctx.xer.ca = ctx.r11.u32 <= 32;
	ctx.r7.u64 = static_cast<uint64_t>(32) - ctx.r11.u64;
	// stw r31,-152(r1)
	REX_STORE_U32(ctx.r1.u32 + -152, ctx.r31.u32);
loc_8B0D8EA8:
	// lwz r31,4(r10)
	ctx.r31.u64 = REX_LOAD_U32(ctx.r10.u32 + 4);
	// and r30,r31,r9
	ctx.r30.u64 = ctx.r31.u64 & ctx.r9.u64;
	// stw r30,-160(r1)
	REX_STORE_U32(ctx.r1.u32 + -160, ctx.r30.u32);
	// srw r31,r31,r11
	ctx.r31.u64 = ctx.r11.u8 & 0x20 ? 0 : (ctx.r31.u32 >> (ctx.r11.u8 & 0x3F));
	// or r8,r31,r8
	ctx.r8.u64 = ctx.r31.u64 | ctx.r8.u64;
	// stwu r8,4(r10)
	ea = 4 + ctx.r10.u32;
	REX_STORE_U32(ea, ctx.r8.u32);
	ctx.r10.u32 = ea;
	// lwz r8,-160(r1)
	ctx.r8.u64 = REX_LOAD_U32(ctx.r1.u32 + -160);
	// slw r8,r8,r7
	ctx.r8.u64 = ctx.r7.u8 & 0x20 ? 0 : (ctx.r8.u32 << (ctx.r7.u8 & 0x3F));
	// bdnz 0x8b0d8ea8
	--ctx.ctr.u64;
	if (ctx.ctr.u32 != 0) goto loc_8B0D8EA8;
	// li r10,3
	ctx.r10.s64 = 3;
	// rlwinm r8,r6,2,0,29
	ctx.r8.u64 = __builtin_rotateleft64(ctx.r6.u32 | (ctx.r6.u64 << 32), 2) & 0xFFFFFFFC;
	// addi r7,r1,-144
	ctx.r7.s64 = ctx.r1.s64 + -144;
	// li r9,2
	ctx.r9.s64 = 2;
	// addi r11,r1,-144
	ctx.r11.s64 = ctx.r1.s64 + -144;
	// subf r8,r8,r7
	ctx.r8.u64 = ctx.r7.u64 - ctx.r8.u64;
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
loc_8B0D8EE8:
	// cmpw cr6,r9,r6
	ctx.cr6.compare<int32_t>(ctx.r9.s32, ctx.r6.s32, ctx.xer);
	// blt cr6,0x8b0d8efc
	if (ctx.cr6.lt) goto loc_8B0D8EFC;
	// lwz r10,0(r8)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r8.u32 + 0);
	// stw r10,0(r11)
	REX_STORE_U32(ctx.r11.u32 + 0, ctx.r10.u32);
	// b 0x8b0d8f00
	goto loc_8B0D8F00;
loc_8B0D8EFC:
	// stw r23,0(r11)
	REX_STORE_U32(ctx.r11.u32 + 0, ctx.r23.u32);
loc_8B0D8F00:
	// addi r9,r9,-1
	ctx.r9.s64 = ctx.r9.s64 + -1;
	// addi r8,r8,-4
	ctx.r8.s64 = ctx.r8.s64 + -4;
	// addi r11,r11,-4
	ctx.r11.s64 = ctx.r11.s64 + -4;
	// bdnz 0x8b0d8ee8
	--ctx.ctr.u64;
	if (ctx.ctr.u32 != 0) goto loc_8B0D8EE8;
	// lwz r11,20(r20)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r20.u32 + 20);
	// add r5,r11,r5
	ctx.r5.u64 = ctx.r11.u64 + ctx.r5.u64;
	// b 0x8b0d8fd0
	goto loc_8B0D8FD0;
loc_8B0D8F1C:
	// srawi r11,r21,5
	ctx.xer.ca = (ctx.r21.s32 < 0) & ((ctx.r21.u32 & 0x1F) != 0);
	ctx.r11.s64 = ctx.r21.s32 >> 5;
	// lwz r7,-152(r1)
	ctx.r7.u64 = REX_LOAD_U32(ctx.r1.u32 + -152);
	// li r6,-1
	ctx.r6.s64 = -1;
	// lwz r9,20(r20)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r20.u32 + 20);
	// addze r3,r11
	temp.s64 = ctx.r11.s64 + ctx.xer.ca;
	ctx.xer.ca = temp.u32 < ctx.r11.u32;
	ctx.r3.s64 = temp.s64;
	// srawi r11,r21,5
	ctx.xer.ca = (ctx.r21.s32 < 0) & ((ctx.r21.u32 & 0x1F) != 0);
	ctx.r11.s64 = ctx.r21.s32 >> 5;
	// clrlwi r10,r7,1
	ctx.r10.u64 = ctx.r7.u32 & 0x7FFFFFFF;
	// addze r11,r11
	temp.s64 = ctx.r11.s64 + ctx.xer.ca;
	ctx.xer.ca = temp.u32 < ctx.r11.u32;
	ctx.r11.s64 = temp.s64;
	// stw r10,-152(r1)
	REX_STORE_U32(ctx.r1.u32 + -152, ctx.r10.u32);
	// addi r8,r1,-152
	ctx.r8.s64 = ctx.r1.s64 + -152;
	// rlwinm r11,r11,5,0,26
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 5) & 0xFFFFFFE0;
	// add r5,r9,r30
	ctx.r5.u64 = ctx.r9.u64 + ctx.r30.u64;
	// subf r11,r11,r21
	ctx.r11.u64 = ctx.r21.u64 - ctx.r11.u64;
	// mr r9,r23
	ctx.r9.u64 = ctx.r23.u64;
	// slw r10,r6,r11
	ctx.r10.u64 = ctx.r11.u8 & 0x20 ? 0 : (ctx.r6.u32 << (ctx.r11.u8 & 0x3F));
	// not r7,r10
	ctx.r7.u64 = ~ctx.r10.u64;
	// subfic r6,r11,32
	ctx.xer.ca = ctx.r11.u32 <= 32;
	ctx.r6.u64 = static_cast<uint64_t>(32) - ctx.r11.u64;
	// addi r10,r8,-4
	ctx.r10.s64 = ctx.r8.s64 + -4;
loc_8B0D8F64:
	// lwz r8,4(r10)
	ctx.r8.u64 = REX_LOAD_U32(ctx.r10.u32 + 4);
	// and r31,r8,r7
	ctx.r31.u64 = ctx.r8.u64 & ctx.r7.u64;
	// stw r31,-160(r1)
	REX_STORE_U32(ctx.r1.u32 + -160, ctx.r31.u32);
	// srw r8,r8,r11
	ctx.r8.u64 = ctx.r11.u8 & 0x20 ? 0 : (ctx.r8.u32 >> (ctx.r11.u8 & 0x3F));
	// or r9,r8,r9
	ctx.r9.u64 = ctx.r8.u64 | ctx.r9.u64;
	// stwu r9,4(r10)
	ea = 4 + ctx.r10.u32;
	REX_STORE_U32(ea, ctx.r9.u32);
	ctx.r10.u32 = ea;
	// lwz r9,-160(r1)
	ctx.r9.u64 = REX_LOAD_U32(ctx.r1.u32 + -160);
	// slw r9,r9,r6
	ctx.r9.u64 = ctx.r6.u8 & 0x20 ? 0 : (ctx.r9.u32 << (ctx.r6.u8 & 0x3F));
	// bdnz 0x8b0d8f64
	--ctx.ctr.u64;
	if (ctx.ctr.u32 != 0) goto loc_8B0D8F64;
	// li r10,3
	ctx.r10.s64 = 3;
	// rlwinm r8,r3,2,0,29
	ctx.r8.u64 = __builtin_rotateleft64(ctx.r3.u32 | (ctx.r3.u64 << 32), 2) & 0xFFFFFFFC;
	// addi r7,r1,-144
	ctx.r7.s64 = ctx.r1.s64 + -144;
	// li r9,2
	ctx.r9.s64 = 2;
	// addi r11,r1,-144
	ctx.r11.s64 = ctx.r1.s64 + -144;
	// subf r8,r8,r7
	ctx.r8.u64 = ctx.r7.u64 - ctx.r8.u64;
	// mtctr r10
	ctx.ctr.u64 = ctx.r10.u64;
loc_8B0D8FA4:
	// cmpw cr6,r9,r3
	ctx.cr6.compare<int32_t>(ctx.r9.s32, ctx.r3.s32, ctx.xer);
	// blt cr6,0x8b0d8fb8
	if (ctx.cr6.lt) goto loc_8B0D8FB8;
	// lwz r10,0(r8)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r8.u32 + 0);
	// stw r10,0(r11)
	REX_STORE_U32(ctx.r11.u32 + 0, ctx.r10.u32);
	// b 0x8b0d8fbc
	goto loc_8B0D8FBC;
loc_8B0D8FB8:
	// stw r23,0(r11)
	REX_STORE_U32(ctx.r11.u32 + 0, ctx.r23.u32);
loc_8B0D8FBC:
	// addi r9,r9,-1
	ctx.r9.s64 = ctx.r9.s64 + -1;
	// addi r8,r8,-4
	ctx.r8.s64 = ctx.r8.s64 + -4;
	// addi r11,r11,-4
	ctx.r11.s64 = ctx.r11.s64 + -4;
	// bdnz 0x8b0d8fa4
	--ctx.ctr.u64;
	if (ctx.ctr.u32 != 0) goto loc_8B0D8FA4;
loc_8B0D8FCC:
	// mr r3,r23
	ctx.r3.u64 = ctx.r23.u64;
loc_8B0D8FD0:
	// subfic r10,r21,31
	ctx.xer.ca = ctx.r21.u32 <= 31;
	ctx.r10.u64 = static_cast<uint64_t>(31) - ctx.r21.u64;
	// lwz r11,16(r20)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r20.u32 + 16);
	// subfic r9,r19,0
	ctx.xer.ca = ctx.r19.u32 <= 0;
	ctx.r9.u64 = static_cast<uint64_t>(0) - ctx.r19.u64;
	// lwz r8,-152(r1)
	ctx.r8.u64 = REX_LOAD_U32(ctx.r1.u32 + -152);
	// lis r7,-32768
	ctx.r7.s64 = -2147483648;
	// subfe r9,r9,r9
	temp.u8 = (~ctx.r9.u32 + ctx.r9.u32 < ~ctx.r9.u32) | (~ctx.r9.u32 + ctx.r9.u32 + ctx.xer.ca < ctx.xer.ca);
	ctx.r9.u64 = ~ctx.r9.u64 + ctx.r9.u64 + ctx.xer.ca;
	ctx.xer.ca = temp.u8;
	// slw r10,r5,r10
	ctx.r10.u64 = ctx.r10.u8 & 0x20 ? 0 : (ctx.r5.u32 << (ctx.r10.u8 & 0x3F));
	// and r9,r9,r7
	ctx.r9.u64 = ctx.r9.u64 & ctx.r7.u64;
	// cmpwi cr6,r11,64
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 64, ctx.xer);
	// or r10,r10,r9
	ctx.r10.u64 = ctx.r10.u64 | ctx.r9.u64;
	// or r10,r10,r8
	ctx.r10.u64 = ctx.r10.u64 | ctx.r8.u64;
	// bne cr6,0x8b0d900c
	if (!ctx.cr6.eq) goto loc_8B0D900C;
	// lwz r11,-148(r1)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r1.u32 + -148);
	// stw r11,4(r4)
	REX_STORE_U32(ctx.r4.u32 + 4, ctx.r11.u32);
	// b 0x8b0d9014
	goto loc_8B0D9014;
loc_8B0D900C:
	// cmpwi cr6,r11,32
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 32, ctx.xer);
	// bne cr6,0x8b0d9018
	if (!ctx.cr6.eq) goto loc_8B0D9018;
loc_8B0D9014:
	// stw r10,0(r4)
	REX_STORE_U32(ctx.r4.u32 + 0, ctx.r10.u32);
loc_8B0D9018:
	// b 0x8b0cb9e4
	__restgprlr_19(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0DB5D8) {
	REX_FUNC_PROLOGUE();
	PPCRegister temp{};
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9bc
	ctx.lr = 0x8B0DB5E0;
	__savegprlr_29(ctx, base);
	// stwu r1,-112(r1)
	ea = -112 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// bne cr6,0x8b0db618
	if (!ctx.cr6.eq) goto loc_8B0DB618;
	// bl 0x8b0d0288
	ctx.lr = 0x8B0DB5F4;
	sub_8B0D0288(ctx, base);
	// li r11,22
	ctx.r11.s64 = 22;
	// li r7,0
	ctx.r7.s64 = 0;
	// stw r11,0(r3)
	REX_STORE_U32(ctx.r3.u32 + 0, ctx.r11.u32);
	// li r6,0
	ctx.r6.s64 = 0;
	// li r5,0
	ctx.r5.s64 = 0;
	// li r4,0
	ctx.r4.s64 = 0;
	// li r3,0
	ctx.r3.s64 = 0;
	// bl 0x8b0d0148
	ctx.lr = 0x8B0DB614;
	sub_8B0D0148(ctx, base);
	// b 0x8b0db794
	goto loc_8B0DB794;
loc_8B0DB618:
	// lwz r11,12(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 12);
	// andi. r10,r11,131
	ctx.r10.u64 = ctx.r11.u64 & 131;
	ctx.cr0.compare<int32_t>(ctx.r10.s32, 0, ctx.xer);
	// cmpwi r10,0
	ctx.cr0.compare<int32_t>(ctx.r10.s32, 0, ctx.xer);
	// beq 0x8b0db794
	if (ctx.cr0.eq) goto loc_8B0DB794;
	// rlwinm. r10,r11,0,25,25
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 0) & 0x40;
	ctx.cr0.compare<int32_t>(ctx.r10.s32, 0, ctx.xer);
	// bne 0x8b0db794
	if (!ctx.cr0.eq) goto loc_8B0DB794;
	// rlwinm. r10,r11,0,30,30
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 0) & 0x2;
	ctx.cr0.compare<int32_t>(ctx.r10.s32, 0, ctx.xer);
	// beq 0x8b0db640
	if (ctx.cr0.eq) goto loc_8B0DB640;
	// ori r11,r11,32
	ctx.r11.u64 = ctx.r11.u64 | 32;
	// b 0x8b0db790
	goto loc_8B0DB790;
loc_8B0DB640:
	// ori r11,r11,1
	ctx.r11.u64 = ctx.r11.u64 | 1;
	// andi. r10,r11,268
	ctx.r10.u64 = ctx.r11.u64 & 268;
	ctx.cr0.compare<int32_t>(ctx.r10.s32, 0, ctx.xer);
	// stw r11,12(r31)
	REX_STORE_U32(ctx.r31.u32 + 12, ctx.r11.u32);
	// cmpwi r10,0
	ctx.cr0.compare<int32_t>(ctx.r10.s32, 0, ctx.xer);
	// bne 0x8b0db660
	if (!ctx.cr0.eq) goto loc_8B0DB660;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0d6948
	ctx.lr = 0x8B0DB65C;
	sub_8B0D6948(ctx, base);
	// b 0x8b0db668
	goto loc_8B0DB668;
loc_8B0DB660:
	// lwz r11,8(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 8);
	// stw r11,0(r31)
	REX_STORE_U32(ctx.r31.u32 + 0, ctx.r11.u32);
loc_8B0DB668:
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// lwz r30,8(r31)
	ctx.r30.u64 = REX_LOAD_U32(ctx.r31.u32 + 8);
	// lwz r29,24(r31)
	ctx.r29.u64 = REX_LOAD_U32(ctx.r31.u32 + 24);
	// bl 0x8b0d6c70
	ctx.lr = 0x8B0DB678;
	sub_8B0D6C70(ctx, base);
	// mr r4,r30
	ctx.r4.u64 = ctx.r30.u64;
	// mr r5,r29
	ctx.r5.u64 = ctx.r29.u64;
	// bl 0x8b0db230
	ctx.lr = 0x8B0DB684;
	sub_8B0DB230(ctx, base);
	// cmpwi r3,0
	ctx.cr0.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// stw r3,4(r31)
	REX_STORE_U32(ctx.r31.u32 + 4, ctx.r3.u32);
	// beq 0x8b0db770
	if (ctx.cr0.eq) goto loc_8B0DB770;
	// cmpwi cr6,r3,1
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 1, ctx.xer);
	// beq cr6,0x8b0db770
	if (ctx.cr6.eq) goto loc_8B0DB770;
	// cmpwi cr6,r3,-1
	ctx.cr6.compare<int32_t>(ctx.r3.s32, -1, ctx.xer);
	// beq cr6,0x8b0db770
	if (ctx.cr6.eq) goto loc_8B0DB770;
	// lwz r11,12(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 12);
	// andi. r11,r11,130
	ctx.r11.u64 = ctx.r11.u64 & 130;
	ctx.cr0.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// cmpwi r11,0
	ctx.cr0.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// bne 0x8b0db728
	if (!ctx.cr0.eq) goto loc_8B0DB728;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0d6c70
	ctx.lr = 0x8B0DB6B8;
	sub_8B0D6C70(ctx, base);
	// cmpwi cr6,r3,-1
	ctx.cr6.compare<int32_t>(ctx.r3.s32, -1, ctx.xer);
	// beq cr6,0x8b0db704
	if (ctx.cr6.eq) goto loc_8B0DB704;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0d6c70
	ctx.lr = 0x8B0DB6C8;
	sub_8B0D6C70(ctx, base);
	// cmpwi cr6,r3,-2
	ctx.cr6.compare<int32_t>(ctx.r3.s32, -2, ctx.xer);
	// beq cr6,0x8b0db704
	if (ctx.cr6.eq) goto loc_8B0DB704;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0d6c70
	ctx.lr = 0x8B0DB6D8;
	sub_8B0D6C70(ctx, base);
	// srawi r11,r3,5
	ctx.xer.ca = (ctx.r3.s32 < 0) & ((ctx.r3.u32 & 0x1F) != 0);
	ctx.r11.s64 = ctx.r3.s32 >> 5;
	// lis r10,-29936
	ctx.r10.s64 = -1961885696;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// rlwinm r29,r11,2,0,29
	ctx.r29.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 2) & 0xFFFFFFFC;
	// addi r30,r10,-16864
	ctx.r30.s64 = ctx.r10.s64 + -16864;
	// bl 0x8b0d6c70
	ctx.lr = 0x8B0DB6F0;
	sub_8B0D6C70(ctx, base);
	// clrlwi r10,r3,27
	ctx.r10.u64 = ctx.r3.u32 & 0x1F;
	// lwzx r11,r29,r30
	ctx.r11.u64 = REX_LOAD_U32(ctx.r29.u32 + ctx.r30.u32);
	// mulli r10,r10,72
	ctx.r10.s64 = static_cast<int64_t>(ctx.r10.u64 * static_cast<uint64_t>(72));
	// add r11,r10,r11
	ctx.r11.u64 = ctx.r10.u64 + ctx.r11.u64;
	// b 0x8b0db70c
	goto loc_8B0DB70C;
loc_8B0DB704:
	// lis r11,-29938
	ctx.r11.s64 = -1962016768;
	// addi r11,r11,12856
	ctx.r11.s64 = ctx.r11.s64 + 12856;
loc_8B0DB70C:
	// lbz r11,4(r11)
	ctx.r11.u64 = REX_LOAD_U8(ctx.r11.u32 + 4);
	// andi. r11,r11,130
	ctx.r11.u64 = ctx.r11.u64 & 130;
	ctx.cr0.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// cmplwi cr6,r11,130
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 130, ctx.xer);
	// bne cr6,0x8b0db728
	if (!ctx.cr6.eq) goto loc_8B0DB728;
	// lwz r11,12(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 12);
	// ori r11,r11,8192
	ctx.r11.u64 = ctx.r11.u64 | 8192;
	// stw r11,12(r31)
	REX_STORE_U32(ctx.r31.u32 + 12, ctx.r11.u32);
loc_8B0DB728:
	// lwz r11,24(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 24);
	// cmpwi cr6,r11,512
	ctx.cr6.compare<int32_t>(ctx.r11.s32, 512, ctx.xer);
	// bne cr6,0x8b0db750
	if (!ctx.cr6.eq) goto loc_8B0DB750;
	// lwz r11,12(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 12);
	// rlwinm. r10,r11,0,28,28
	ctx.r10.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 0) & 0x8;
	ctx.cr0.compare<int32_t>(ctx.r10.s32, 0, ctx.xer);
	// beq 0x8b0db750
	if (ctx.cr0.eq) goto loc_8B0DB750;
	// rlwinm. r11,r11,0,21,21
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 0) & 0x400;
	ctx.cr0.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// bne 0x8b0db750
	if (!ctx.cr0.eq) goto loc_8B0DB750;
	// li r11,4096
	ctx.r11.s64 = 4096;
	// stw r11,24(r31)
	REX_STORE_U32(ctx.r31.u32 + 24, ctx.r11.u32);
loc_8B0DB750:
	// lwz r10,4(r31)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r31.u32 + 4);
	// lwz r11,0(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 0);
	// addi r10,r10,-2
	ctx.r10.s64 = ctx.r10.s64 + -2;
	// addi r9,r11,2
	ctx.r9.s64 = ctx.r11.s64 + 2;
	// stw r10,4(r31)
	REX_STORE_U32(ctx.r31.u32 + 4, ctx.r10.u32);
	// lhz r3,0(r11)
	ctx.r3.u64 = REX_LOAD_U16(ctx.r11.u32 + 0);
	// stw r9,0(r31)
	REX_STORE_U32(ctx.r31.u32 + 0, ctx.r9.u32);
	// b 0x8b0db79c
	goto loc_8B0DB79C;
loc_8B0DB770:
	// subfic r11,r3,0
	ctx.xer.ca = ctx.r3.u32 <= 0;
	ctx.r11.u64 = static_cast<uint64_t>(0) - ctx.r3.u64;
	// lwz r10,12(r31)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r31.u32 + 12);
	// li r9,0
	ctx.r9.s64 = 0;
	// subfe r11,r11,r11
	temp.u8 = (~ctx.r11.u32 + ctx.r11.u32 < ~ctx.r11.u32) | (~ctx.r11.u32 + ctx.r11.u32 + ctx.xer.ca < ctx.xer.ca);
	ctx.r11.u64 = ~ctx.r11.u64 + ctx.r11.u64 + ctx.xer.ca;
	ctx.xer.ca = temp.u8;
	// stw r9,4(r31)
	REX_STORE_U32(ctx.r31.u32 + 4, ctx.r9.u32);
	// rlwinm r11,r11,0,27,27
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 0) & 0x10;
	// addi r11,r11,16
	ctx.r11.s64 = ctx.r11.s64 + 16;
	// or r11,r11,r10
	ctx.r11.u64 = ctx.r11.u64 | ctx.r10.u64;
loc_8B0DB790:
	// stw r11,12(r31)
	REX_STORE_U32(ctx.r31.u32 + 12, ctx.r11.u32);
loc_8B0DB794:
	// lis r3,0
	ctx.r3.s64 = 0;
	// ori r3,r3,65535
	ctx.r3.u64 = ctx.r3.u64 | 65535;
loc_8B0DB79C:
	// addi r1,r1,112
	ctx.r1.s64 = ctx.r1.s64 + 112;
	// b 0x8b0cba0c
	__restgprlr_29(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0DBBE8) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9b4
	ctx.lr = 0x8B0DBBF0;
	__savegprlr_27(ctx, base);
	// addi r31,r1,-144
	ctx.r31.s64 = ctx.r1.s64 + -144;
	// stwu r1,-144(r1)
	ea = -144 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// mr r30,r3
	ctx.r30.u64 = ctx.r3.u64;
	// stw r3,164(r31)
	REX_STORE_U32(ctx.r31.u32 + 164, ctx.r3.u32);
	// cmpwi cr6,r3,-2
	ctx.cr6.compare<int32_t>(ctx.r3.s32, -2, ctx.xer);
	// bne cr6,0x8b0dbc2c
	if (!ctx.cr6.eq) goto loc_8B0DBC2C;
	// bl 0x8b0d02c0
	ctx.lr = 0x8B0DBC0C;
	sub_8B0D02C0(ctx, base);
	// li r11,0
	ctx.r11.s64 = 0;
	// stw r11,0(r3)
	REX_STORE_U32(ctx.r3.u32 + 0, ctx.r11.u32);
	// bl 0x8b0d0288
	ctx.lr = 0x8B0DBC18;
	sub_8B0D0288(ctx, base);
	// mr r11,r3
	ctx.r11.u64 = ctx.r3.u64;
	// li r10,9
	ctx.r10.s64 = 9;
	// li r3,-1
	ctx.r3.s64 = -1;
	// stw r10,0(r11)
	REX_STORE_U32(ctx.r11.u32 + 0, ctx.r10.u32);
	// b 0x8b0dbcfc
	goto loc_8B0DBCFC;
loc_8B0DBC2C:
	// cmpwi cr6,r30,0
	ctx.cr6.compare<int32_t>(ctx.r30.s32, 0, ctx.xer);
	// blt cr6,0x8b0dbc44
	if (ctx.cr6.lt) goto loc_8B0DBC44;
	// lis r11,-29936
	ctx.r11.s64 = -1961885696;
	// lwz r11,-16892(r11)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r11.u32 + -16892);
	// cmplw cr6,r30,r11
	ctx.cr6.compare<uint32_t>(ctx.r30.u32, ctx.r11.u32, ctx.xer);
	// blt cr6,0x8b0dbc7c
	if (ctx.cr6.lt) goto loc_8B0DBC7C;
loc_8B0DBC44:
	// bl 0x8b0d02c0
	ctx.lr = 0x8B0DBC48;
	sub_8B0D02C0(ctx, base);
	// li r11,0
	ctx.r11.s64 = 0;
	// stw r11,0(r3)
	REX_STORE_U32(ctx.r3.u32 + 0, ctx.r11.u32);
	// bl 0x8b0d0288
	ctx.lr = 0x8B0DBC54;
	sub_8B0D0288(ctx, base);
	// li r11,9
	ctx.r11.s64 = 9;
	// li r7,0
	ctx.r7.s64 = 0;
	// stw r11,0(r3)
	REX_STORE_U32(ctx.r3.u32 + 0, ctx.r11.u32);
	// li r6,0
	ctx.r6.s64 = 0;
	// li r5,0
	ctx.r5.s64 = 0;
	// li r4,0
	ctx.r4.s64 = 0;
	// li r3,0
	ctx.r3.s64 = 0;
	// bl 0x8b0d0148
	ctx.lr = 0x8B0DBC74;
	sub_8B0D0148(ctx, base);
	// li r3,-1
	ctx.r3.s64 = -1;
	// b 0x8b0dbcfc
	goto loc_8B0DBCFC;
loc_8B0DBC7C:
	// srawi r11,r30,5
	ctx.xer.ca = (ctx.r30.s32 < 0) & ((ctx.r30.u32 & 0x1F) != 0);
	ctx.r11.s64 = ctx.r30.s32 >> 5;
	// lis r10,-29936
	ctx.r10.s64 = -1961885696;
	// rlwinm r27,r11,2,0,29
	ctx.r27.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 2) & 0xFFFFFFFC;
	// addi r28,r10,-16864
	ctx.r28.s64 = ctx.r10.s64 + -16864;
	// clrlwi r11,r30,27
	ctx.r11.u64 = ctx.r30.u32 & 0x1F;
	// mulli r29,r11,72
	ctx.r29.s64 = static_cast<int64_t>(ctx.r11.u64 * static_cast<uint64_t>(72));
	// lwzx r11,r27,r28
	ctx.r11.u64 = REX_LOAD_U32(ctx.r27.u32 + ctx.r28.u32);
	// add r11,r11,r29
	ctx.r11.u64 = ctx.r11.u64 + ctx.r29.u64;
	// lbz r11,4(r11)
	ctx.r11.u64 = REX_LOAD_U8(ctx.r11.u32 + 4);
	// clrlwi. r11,r11,31
	ctx.r11.u64 = ctx.r11.u32 & 0x1;
	ctx.cr0.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// beq 0x8b0dbc44
	if (ctx.cr0.eq) goto loc_8B0DBC44;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// bl 0x8b0d9b38
	ctx.lr = 0x8B0DBCB0;
	sub_8B0D9B38(ctx, base);
	// mr r8,r8
	ctx.r8.u64 = ctx.r8.u64;
	// lwzx r11,r27,r28
	ctx.r11.u64 = REX_LOAD_U32(ctx.r27.u32 + ctx.r28.u32);
	// add r11,r11,r29
	ctx.r11.u64 = ctx.r11.u64 + ctx.r29.u64;
	// lbz r11,4(r11)
	ctx.r11.u64 = REX_LOAD_U8(ctx.r11.u32 + 4);
	// clrlwi. r11,r11,31
	ctx.r11.u64 = ctx.r11.u32 & 0x1;
	ctx.cr0.compare<int32_t>(ctx.r11.s32, 0, ctx.xer);
	// beq 0x8b0dbcd8
	if (ctx.cr0.eq) goto loc_8B0DBCD8;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// bl 0x8b0dbb00
	ctx.lr = 0x8B0DBCD0;
	sub_8B0DBB00(ctx, base);
	// stw r3,80(r31)
	REX_STORE_U32(ctx.r31.u32 + 80, ctx.r3.u32);
	// b 0x8b0dbcec
	goto loc_8B0DBCEC;
loc_8B0DBCD8:
	// bl 0x8b0d0288
	ctx.lr = 0x8B0DBCDC;
	sub_8B0D0288(ctx, base);
	// li r11,9
	ctx.r11.s64 = 9;
	// li r10,-1
	ctx.r10.s64 = -1;
	// stw r11,0(r3)
	REX_STORE_U32(ctx.r3.u32 + 0, ctx.r11.u32);
	// stw r10,80(r31)
	REX_STORE_U32(ctx.r31.u32 + 80, ctx.r10.u32);
loc_8B0DBCEC:
	// mr r8,r8
	ctx.r8.u64 = ctx.r8.u64;
	// addi r12,r31,144
	ctx.r12.s64 = ctx.r31.s64 + 144;
	// bl 0x8b0dbd24
	ctx.lr = 0x8B0DBCF8;
	sub_8B0DBD24(ctx, base);
	// lwz r3,80(r31)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r31.u32 + 80);
loc_8B0DBCFC:
	// addi r1,r31,144
	ctx.r1.s64 = ctx.r31.s64 + 144;
	// b 0x8b0cba04
	__restgprlr_27(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0DC110) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// stwu r1,-96(r1)
	ea = -96 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// li r11,0
	ctx.r11.s64 = 0;
	// addi r7,r1,80
	ctx.r7.s64 = ctx.r1.s64 + 80;
	// sth r11,80(r1)
	REX_STORE_U16(ctx.r1.u32 + 80, ctx.r11.u16);
	// li r6,4
	ctx.r6.s64 = 4;
	// addi r5,r1,84
	ctx.r5.s64 = ctx.r1.s64 + 84;
	// li r4,9
	ctx.r4.s64 = 9;
	// li r3,3
	ctx.r3.s64 = 3;
	// bl 0x8b0df638
	ctx.lr = 0x8B0DC13C;
	__imp__ExGetXConfigSetting(ctx, base);
	// rlwinm r11,r3,1,31,31
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r3.u32 | (ctx.r3.u64 << 32), 1) & 0x1;
	// lwz r10,84(r1)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r1.u32 + 84);
	// addi r11,r11,-1
	ctx.r11.s64 = ctx.r11.s64 + -1;
	// and r3,r11,r10
	ctx.r3.u64 = ctx.r11.u64 & ctx.r10.u64;
	// stw r3,84(r1)
	REX_STORE_U32(ctx.r1.u32 + 84, ctx.r3.u32);
	// cmplwi cr6,r3,0
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 0, ctx.xer);
	// beq cr6,0x8b0dc160
	if (ctx.cr6.eq) goto loc_8B0DC160;
	// cmplwi cr6,r3,12
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 12, ctx.xer);
	// ble cr6,0x8b0dc18c
	if (!ctx.cr6.gt) goto loc_8B0DC18C;
loc_8B0DC160:
	// bl 0x8b0df588
	ctx.lr = 0x8B0DC164;
	__imp__XGetGameRegion(ctx, base);
	// rlwinm r11,r3,0,16,23
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r3.u32 | (ctx.r3.u64 << 32), 0) & 0xFF00;
	// cmplwi cr6,r11,256
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 256, ctx.xer);
	// bne cr6,0x8b0dc188
	if (!ctx.cr6.eq) goto loc_8B0DC188;
	// cmplwi cr6,r3,257
	ctx.cr6.compare<uint32_t>(ctx.r3.u32, 257, ctx.xer);
	// bne cr6,0x8b0dc180
	if (!ctx.cr6.eq) goto loc_8B0DC180;
	// li r3,2
	ctx.r3.s64 = 2;
	// b 0x8b0dc18c
	goto loc_8B0DC18C;
loc_8B0DC180:
	// li r3,7
	ctx.r3.s64 = 7;
	// b 0x8b0dc18c
	goto loc_8B0DC18C;
loc_8B0DC188:
	// li r3,1
	ctx.r3.s64 = 1;
loc_8B0DC18C:
	// addi r1,r1,96
	ctx.r1.s64 = ctx.r1.s64 + 96;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0DC338) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// std r30,-24(r1)
	REX_STORE_U64(ctx.r1.u32 + -24, ctx.r30.u64);
	// std r31,-16(r1)
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.r31.u64);
	// stwu r1,-112(r1)
	ea = -112 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lis r11,-29943
	ctx.r11.s64 = -1962344448;
	// lwz r10,-25032(r11)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r11.u32 + -25032);
	// cmplwi cr6,r10,0
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, 0, ctx.xer);
	// beq cr6,0x8b0dc368
	if (ctx.cr6.eq) goto loc_8B0DC368;
	// rotlwi r11,r10,0
	ctx.r11.u64 = __builtin_rotateleft32(ctx.r10.u32, 0);
	// mtctr r11
	ctx.ctr.u64 = ctx.r11.u64;
	// bctrl 
	ctx.lr = 0x8B0DC368;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
loc_8B0DC368:
	// lis r10,-29938
	ctx.r10.s64 = -1962016768;
	// lis r11,-29938
	ctx.r11.s64 = -1962016768;
	// addi r10,r10,392
	ctx.r10.s64 = ctx.r10.s64 + 392;
	// addi r30,r11,404
	ctx.r30.s64 = ctx.r11.s64 + 404;
	// mr r31,r10
	ctx.r31.u64 = ctx.r10.u64;
	// li r3,0
	ctx.r3.s64 = 0;
	// cmplw cr6,r10,r30
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, ctx.r30.u32, ctx.xer);
	// bge cr6,0x8b0dc3b8
	if (!ctx.cr6.lt) goto loc_8B0DC3B8;
loc_8B0DC388:
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// bne cr6,0x8b0dc400
	if (!ctx.cr6.eq) goto loc_8B0DC400;
	// lwz r11,0(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 0);
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// beq cr6,0x8b0dc3a4
	if (ctx.cr6.eq) goto loc_8B0DC3A4;
	// mtctr r11
	ctx.ctr.u64 = ctx.r11.u64;
	// bctrl 
	ctx.lr = 0x8B0DC3A4;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
loc_8B0DC3A4:
	// addi r31,r31,4
	ctx.r31.s64 = ctx.r31.s64 + 4;
	// cmplw cr6,r31,r30
	ctx.cr6.compare<uint32_t>(ctx.r31.u32, ctx.r30.u32, ctx.xer);
	// blt cr6,0x8b0dc388
	if (ctx.cr6.lt) goto loc_8B0DC388;
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// bne cr6,0x8b0dc400
	if (!ctx.cr6.eq) goto loc_8B0DC400;
loc_8B0DC3B8:
	// lis r10,-29938
	ctx.r10.s64 = -1962016768;
	// lis r11,-29938
	ctx.r11.s64 = -1962016768;
	// addi r10,r10,16
	ctx.r10.s64 = ctx.r10.s64 + 16;
	// addi r30,r11,388
	ctx.r30.s64 = ctx.r11.s64 + 388;
	// mr r31,r10
	ctx.r31.u64 = ctx.r10.u64;
	// cmplw cr6,r10,r30
	ctx.cr6.compare<uint32_t>(ctx.r10.u32, ctx.r30.u32, ctx.xer);
	// bge cr6,0x8b0dc3fc
	if (!ctx.cr6.lt) goto loc_8B0DC3FC;
loc_8B0DC3D4:
	// lwz r11,0(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 0);
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// beq cr6,0x8b0dc3f0
	if (ctx.cr6.eq) goto loc_8B0DC3F0;
	// cmpwi cr6,r11,-1
	ctx.cr6.compare<int32_t>(ctx.r11.s32, -1, ctx.xer);
	// beq cr6,0x8b0dc3f0
	if (ctx.cr6.eq) goto loc_8B0DC3F0;
	// mtctr r11
	ctx.ctr.u64 = ctx.r11.u64;
	// bctrl 
	ctx.lr = 0x8B0DC3F0;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
loc_8B0DC3F0:
	// addi r31,r31,4
	ctx.r31.s64 = ctx.r31.s64 + 4;
	// cmplw cr6,r31,r30
	ctx.cr6.compare<uint32_t>(ctx.r31.u32, ctx.r30.u32, ctx.xer);
	// blt cr6,0x8b0dc3d4
	if (ctx.cr6.lt) goto loc_8B0DC3D4;
loc_8B0DC3FC:
	// li r3,0
	ctx.r3.s64 = 0;
loc_8B0DC400:
	// addi r1,r1,112
	ctx.r1.s64 = ctx.r1.s64 + 112;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// ld r30,-24(r1)
	ctx.r30.u64 = REX_LOAD_U64(ctx.r1.u32 + -24);
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0DC5C8) {
	REX_FUNC_PROLOGUE();
	// lwz r11,256(r13)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r13.u32 + 256);
	// lwz r3,332(r11)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r11.u32 + 332);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0DC5D8) {
	REX_FUNC_PROLOGUE();
	// b 0x8b095650
	sub_8B095650(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0DC5E0) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9bc
	ctx.lr = 0x8B0DC5E8;
	__savegprlr_29(ctx, base);
	// stwu r1,-112(r1)
	ea = -112 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lis r11,-29938
	ctx.r11.s64 = -1962016768;
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// addi r30,r11,15884
	ctx.r30.s64 = ctx.r11.s64 + 15884;
	// mr r29,r4
	ctx.r29.u64 = ctx.r4.u64;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// bl 0x8b0df218
	ctx.lr = 0x8B0DC604;
	__imp__RtlEnterCriticalSection(ctx, base);
	// cmpwi cr6,r29,0
	ctx.cr6.compare<int32_t>(ctx.r29.s32, 0, ctx.xer);
	// beq cr6,0x8b0dc62c
	if (ctx.cr6.eq) goto loc_8B0DC62C;
	// lis r11,-29938
	ctx.r11.s64 = -1962016768;
	// addi r10,r11,15912
	ctx.r10.s64 = ctx.r11.s64 + 15912;
	// lwz r11,4(r10)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r10.u32 + 4);
	// stw r10,0(r31)
	REX_STORE_U32(ctx.r31.u32 + 0, ctx.r10.u32);
	// stw r11,4(r31)
	REX_STORE_U32(ctx.r31.u32 + 4, ctx.r11.u32);
	// stw r31,0(r11)
	REX_STORE_U32(ctx.r11.u32 + 0, ctx.r31.u32);
	// stw r31,4(r10)
	REX_STORE_U32(ctx.r10.u32 + 4, ctx.r31.u32);
	// b 0x8b0dc63c
	goto loc_8B0DC63C;
loc_8B0DC62C:
	// lwz r11,0(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 0);
	// lwz r10,4(r31)
	ctx.r10.u64 = REX_LOAD_U32(ctx.r31.u32 + 4);
	// stw r11,0(r10)
	REX_STORE_U32(ctx.r10.u32 + 0, ctx.r11.u32);
	// stw r10,4(r11)
	REX_STORE_U32(ctx.r11.u32 + 4, ctx.r10.u32);
loc_8B0DC63C:
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// bl 0x8b0df208
	ctx.lr = 0x8B0DC644;
	__imp__RtlLeaveCriticalSection(ctx, base);
	// addi r1,r1,112
	ctx.r1.s64 = ctx.r1.s64 + 112;
	// b 0x8b0cba0c
	__restgprlr_29(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0DC738) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// stwu r1,-176(r1)
	ea = -176 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lis r9,-29938
	ctx.r9.s64 = -1962016768;
	// stw r3,80(r1)
	REX_STORE_U32(ctx.r1.u32 + 80, ctx.r3.u32);
	// li r10,0
	ctx.r10.s64 = 0;
	// clrlwi r8,r4,31
	ctx.r8.u64 = ctx.r4.u32 & 0x1;
	// addi r9,r9,-14536
	ctx.r9.s64 = ctx.r9.s64 + -14536;
	// stw r10,88(r1)
	REX_STORE_U32(ctx.r1.u32 + 88, ctx.r10.u32);
	// mr r11,r5
	ctx.r11.u64 = ctx.r5.u64;
	// stw r8,84(r1)
	REX_STORE_U32(ctx.r1.u32 + 84, ctx.r8.u32);
	// cmplwi cr6,r6,0
	ctx.cr6.compare<uint32_t>(ctx.r6.u32, 0, ctx.xer);
	// stw r9,92(r1)
	REX_STORE_U32(ctx.r1.u32 + 92, ctx.r9.u32);
	// beq cr6,0x8b0dc79c
	if (ctx.cr6.eq) goto loc_8B0DC79C;
	// cmplwi cr6,r5,15
	ctx.cr6.compare<uint32_t>(ctx.r5.u32, 15, ctx.xer);
	// ble cr6,0x8b0dc77c
	if (!ctx.cr6.gt) goto loc_8B0DC77C;
	// li r11,15
	ctx.r11.s64 = 15;
loc_8B0DC77C:
	// stw r11,96(r1)
	REX_STORE_U32(ctx.r1.u32 + 96, ctx.r11.u32);
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// beq cr6,0x8b0dc7a0
	if (ctx.cr6.eq) goto loc_8B0DC7A0;
	// mr r4,r6
	ctx.r4.u64 = ctx.r6.u64;
	// addi r3,r1,100
	ctx.r3.s64 = ctx.r1.s64 + 100;
	// rlwinm r5,r11,2,0,29
	ctx.r5.u64 = __builtin_rotateleft64(ctx.r11.u32 | (ctx.r11.u64 << 32), 2) & 0xFFFFFFFC;
	// bl 0x8b0cbfb8
	ctx.lr = 0x8B0DC798;
	sub_8B0CBFB8(ctx, base);
	// b 0x8b0dc7a0
	goto loc_8B0DC7A0;
loc_8B0DC79C:
	// stw r10,96(r1)
	REX_STORE_U32(ctx.r1.u32 + 96, ctx.r10.u32);
loc_8B0DC7A0:
	// addi r3,r1,80
	ctx.r3.s64 = ctx.r1.s64 + 80;
	// bl 0x8b0df288
	ctx.lr = 0x8B0DC7A8;
	__imp__RtlRaiseException(ctx, base);
	// addi r1,r1,176
	ctx.r1.s64 = ctx.r1.s64 + 176;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0DCAC0) {
	REX_FUNC_PROLOGUE();
	PPCRegister temp{};
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9b8
	ctx.lr = 0x8B0DCAC8;
	__savegprlr_28(ctx, base);
	// stwu r1,-144(r1)
	ea = -144 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// mr r30,r3
	ctx.r30.u64 = ctx.r3.u64;
	// mr r8,r4
	ctx.r8.u64 = ctx.r4.u64;
	// mr r9,r5
	ctx.r9.u64 = ctx.r5.u64;
	// mr r29,r6
	ctx.r29.u64 = ctx.r6.u64;
	// mr r31,r7
	ctx.r31.u64 = ctx.r7.u64;
	// li r28,0
	ctx.r28.s64 = 0;
	// cmplwi cr6,r6,0
	ctx.cr6.compare<uint32_t>(ctx.r6.u32, 0, ctx.xer);
	// beq cr6,0x8b0dcaf0
	if (ctx.cr6.eq) goto loc_8B0DCAF0;
	// stw r28,0(r6)
	REX_STORE_U32(ctx.r6.u32 + 0, ctx.r28.u32);
loc_8B0DCAF0:
	// cmplwi cr6,r31,0
	ctx.cr6.compare<uint32_t>(ctx.r31.u32, 0, ctx.xer);
	// lis r11,-29938
	ctx.r11.s64 = -1962016768;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// beq cr6,0x8b0dcb94
	if (ctx.cr6.eq) goto loc_8B0DCB94;
	// li r6,259
	ctx.r6.s64 = 259;
	// lwz r7,8(r31)
	ctx.r7.u64 = REX_LOAD_U32(ctx.r31.u32 + 8);
	// lwz r5,12(r31)
	ctx.r5.u64 = REX_LOAD_U32(ctx.r31.u32 + 12);
	// addi r10,r1,88
	ctx.r10.s64 = ctx.r1.s64 + 88;
	// stw r6,0(r31)
	REX_STORE_U32(ctx.r31.u32 + 0, ctx.r6.u32);
	// lwz r11,15968(r11)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r11.u32 + 15968);
	// lwz r4,16(r31)
	ctx.r4.u64 = REX_LOAD_U32(ctx.r31.u32 + 16);
	// stw r7,92(r1)
	REX_STORE_U32(ctx.r1.u32 + 92, ctx.r7.u32);
	// stw r5,88(r1)
	REX_STORE_U32(ctx.r1.u32 + 88, ctx.r5.u32);
	// clrlwi r6,r4,31
	ctx.r6.u64 = ctx.r4.u32 & 0x1;
	// li r5,0
	ctx.r5.s64 = 0;
	// addic r7,r6,-1
	ctx.xer.ca = ctx.r6.u32 > 0;
	ctx.r7.s64 = ctx.r6.s64 + -1;
	// mr r7,r31
	ctx.r7.u64 = ctx.r31.u64;
	// subfe r6,r6,r6
	temp.u8 = (~ctx.r6.u32 + ctx.r6.u32 < ~ctx.r6.u32) | (~ctx.r6.u32 + ctx.r6.u32 + ctx.xer.ca < ctx.xer.ca);
	ctx.r6.u64 = ~ctx.r6.u64 + ctx.r6.u64 + ctx.xer.ca;
	ctx.xer.ca = temp.u8;
	// and r6,r6,r31
	ctx.r6.u64 = ctx.r6.u64 & ctx.r31.u64;
	// lwz r11,16(r11)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r11.u32 + 16);
	// mtctr r11
	ctx.ctr.u64 = ctx.r11.u64;
	// bctrl 
	ctx.lr = 0x8B0DCB48;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// cmpwi r3,0
	ctx.cr0.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// blt 0x8b0dcb70
	if (ctx.cr0.lt) goto loc_8B0DCB70;
	// cmpwi cr6,r3,259
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 259, ctx.xer);
	// beq cr6,0x8b0dcb70
	if (ctx.cr6.eq) goto loc_8B0DCB70;
	// cmplwi cr6,r29,0
	ctx.cr6.compare<uint32_t>(ctx.r29.u32, 0, ctx.xer);
	// beq cr6,0x8b0dcb68
	if (ctx.cr6.eq) goto loc_8B0DCB68;
	// lwz r11,4(r31)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r31.u32 + 4);
	// stw r11,0(r29)
	REX_STORE_U32(ctx.r29.u32 + 0, ctx.r11.u32);
loc_8B0DCB68:
	// li r3,1
	ctx.r3.s64 = 1;
	// b 0x8b0dcc34
	goto loc_8B0DCC34;
loc_8B0DCB70:
	// lis r11,-16384
	ctx.r11.s64 = -1073741824;
	// ori r11,r11,17
	ctx.r11.u64 = ctx.r11.u64 | 17;
	// cmpw cr6,r3,r11
	ctx.cr6.compare<int32_t>(ctx.r3.s32, ctx.r11.s32, ctx.xer);
	// bne cr6,0x8b0dcc2c
	if (!ctx.cr6.eq) goto loc_8B0DCC2C;
	// cmplwi cr6,r29,0
	ctx.cr6.compare<uint32_t>(ctx.r29.u32, 0, ctx.xer);
	// beq cr6,0x8b0dcb8c
	if (ctx.cr6.eq) goto loc_8B0DCB8C;
	// stw r28,0(r29)
	REX_STORE_U32(ctx.r29.u32 + 0, ctx.r28.u32);
loc_8B0DCB8C:
	// mr r3,r11
	ctx.r3.u64 = ctx.r11.u64;
	// b 0x8b0dcc2c
	goto loc_8B0DCC2C;
loc_8B0DCB94:
	// lwz r11,15968(r11)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r11.u32 + 15968);
	// li r10,0
	ctx.r10.s64 = 0;
	// addi r7,r1,80
	ctx.r7.s64 = ctx.r1.s64 + 80;
	// li r6,0
	ctx.r6.s64 = 0;
	// li r5,0
	ctx.r5.s64 = 0;
	// li r4,0
	ctx.r4.s64 = 0;
	// lwz r11,16(r11)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r11.u32 + 16);
	// mtctr r11
	ctx.ctr.u64 = ctx.r11.u64;
	// bctrl 
	ctx.lr = 0x8B0DCBB8;
	REX_CALL_INDIRECT_FUNC(ctx.ctr.u32);
	// cmpwi cr6,r3,259
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 259, ctx.xer);
	// bne cr6,0x8b0dcbe0
	if (!ctx.cr6.eq) goto loc_8B0DCBE0;
	// li r6,0
	ctx.r6.s64 = 0;
	// li r5,0
	ctx.r5.s64 = 0;
	// li r4,1
	ctx.r4.s64 = 1;
	// mr r3,r30
	ctx.r3.u64 = ctx.r30.u64;
	// bl 0x8b0df6b8
	ctx.lr = 0x8B0DCBD4;
	__imp__NtWaitForSingleObjectEx(ctx, base);
	// cmpwi r3,0
	ctx.cr0.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// blt 0x8b0dcbf8
	if (ctx.cr0.lt) goto loc_8B0DCBF8;
	// lwz r3,80(r1)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r1.u32 + 80);
loc_8B0DCBE0:
	// cmpwi cr6,r3,0
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// blt cr6,0x8b0dcbf8
	if (ctx.cr6.lt) goto loc_8B0DCBF8;
	// lwz r11,84(r1)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r1.u32 + 84);
	// li r3,1
	ctx.r3.s64 = 1;
	// stw r11,0(r29)
	REX_STORE_U32(ctx.r29.u32 + 0, ctx.r11.u32);
	// b 0x8b0dcc34
	goto loc_8B0DCC34;
loc_8B0DCBF8:
	// lis r11,-16384
	ctx.r11.s64 = -1073741824;
	// ori r11,r11,17
	ctx.r11.u64 = ctx.r11.u64 | 17;
	// cmpw cr6,r3,r11
	ctx.cr6.compare<int32_t>(ctx.r3.s32, ctx.r11.s32, ctx.xer);
	// bne cr6,0x8b0dcc14
	if (!ctx.cr6.eq) goto loc_8B0DCC14;
	// li r3,1
	ctx.r3.s64 = 1;
	// stw r28,0(r29)
	REX_STORE_U32(ctx.r29.u32 + 0, ctx.r28.u32);
	// b 0x8b0dcc34
	goto loc_8B0DCC34;
loc_8B0DCC14:
	// rlwinm r11,r3,0,0,1
	ctx.r11.u64 = __builtin_rotateleft64(ctx.r3.u32 | (ctx.r3.u64 << 32), 0) & 0xC0000000;
	// lis r10,-32768
	ctx.r10.s64 = -2147483648;
	// cmplw cr6,r11,r10
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, ctx.r10.u32, ctx.xer);
	// bne cr6,0x8b0dcc2c
	if (!ctx.cr6.eq) goto loc_8B0DCC2C;
	// lwz r11,84(r1)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r1.u32 + 84);
	// stw r11,0(r29)
	REX_STORE_U32(ctx.r29.u32 + 0, ctx.r11.u32);
loc_8B0DCC2C:
	// bl 0x8b095618
	ctx.lr = 0x8B0DCC30;
	sub_8B095618(ctx, base);
	// li r3,0
	ctx.r3.s64 = 0;
loc_8B0DCC34:
	// addi r1,r1,144
	ctx.r1.s64 = ctx.r1.s64 + 144;
	// b 0x8b0cba08
	__restgprlr_28(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0DD058) {
	REX_FUNC_PROLOGUE();
	// lhz r4,0(r3)
	ctx.r4.u64 = REX_LOAD_U16(ctx.r3.u32 + 0);
	// lwz r3,4(r3)
	ctx.r3.u64 = REX_LOAD_U32(ctx.r3.u32 + 4);
	// b 0x8b0dd0d0
	sub_8B0DD0D0(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0DD068) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// bl 0x8b0cb9b8
	ctx.lr = 0x8B0DD070;
	__savegprlr_28(ctx, base);
	// stwu r1,-128(r1)
	ea = -128 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// mr r31,r3
	ctx.r31.u64 = ctx.r3.u64;
	// addi r3,r1,80
	ctx.r3.s64 = ctx.r1.s64 + 80;
	// mr r28,r5
	ctx.r28.u64 = ctx.r5.u64;
	// bl 0x8b0dd0d8
	ctx.lr = 0x8B0DD084;
	sub_8B0DD0D8(ctx, base);
	// mr r30,r3
	ctx.r30.u64 = ctx.r3.u64;
	// clrlwi r29,r28,24
	ctx.r29.u64 = ctx.r28.u32 & 0xFF;
loc_8B0DD08C:
	// mr r6,r30
	ctx.r6.u64 = ctx.r30.u64;
	// mr r5,r29
	ctx.r5.u64 = ctx.r29.u64;
	// li r4,1
	ctx.r4.s64 = 1;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0df6b8
	ctx.lr = 0x8B0DD0A0;
	__imp__NtWaitForSingleObjectEx(ctx, base);
	// cmpwi r3,0
	ctx.cr0.compare<int32_t>(ctx.r3.s32, 0, ctx.xer);
	// blt 0x8b0dd0bc
	if (ctx.cr0.lt) goto loc_8B0DD0BC;
	// cmpwi cr6,r28,0
	ctx.cr6.compare<int32_t>(ctx.r28.s32, 0, ctx.xer);
	// beq cr6,0x8b0dd0c4
	if (ctx.cr6.eq) goto loc_8B0DD0C4;
	// cmpwi cr6,r3,257
	ctx.cr6.compare<int32_t>(ctx.r3.s32, 257, ctx.xer);
	// beq cr6,0x8b0dd08c
	if (ctx.cr6.eq) goto loc_8B0DD08C;
	// b 0x8b0dd0c4
	goto loc_8B0DD0C4;
loc_8B0DD0BC:
	// bl 0x8b095618
	ctx.lr = 0x8B0DD0C0;
	sub_8B095618(ctx, base);
	// li r3,-1
	ctx.r3.s64 = -1;
loc_8B0DD0C4:
	// addi r1,r1,128
	ctx.r1.s64 = ctx.r1.s64 + 128;
	// b 0x8b0cba08
	__restgprlr_28(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0DD130) {
	REX_FUNC_PROLOGUE();
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lis r10,-29943
	ctx.r10.s64 = -1962344448;
	// lis r9,-29938
	ctx.r9.s64 = -1962016768;
	// addi r5,r11,3252
	ctx.r5.s64 = ctx.r11.s64 + 3252;
	// addi r3,r9,16332
	ctx.r3.s64 = ctx.r9.s64 + 16332;
	// addi r4,r10,496
	ctx.r4.s64 = ctx.r10.s64 + 496;
	// b 0x8b0c5c80
	sub_8B0C5C80(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0DD150) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// stwu r1,-96(r1)
	ea = -96 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lis r8,-29938
	ctx.r8.s64 = -1962016768;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lis r10,-29943
	ctx.r10.s64 = -1962344448;
	// lis r9,-29944
	ctx.r9.s64 = -1962409984;
	// addi r3,r8,16380
	ctx.r3.s64 = ctx.r8.s64 + 16380;
	// addi r6,r11,3296
	ctx.r6.s64 = ctx.r11.s64 + 3296;
	// addi r4,r9,3280
	ctx.r4.s64 = ctx.r9.s64 + 3280;
	// li r8,0
	ctx.r8.s64 = 0;
	// li r7,0
	ctx.r7.s64 = 0;
	// addi r5,r10,4512
	ctx.r5.s64 = ctx.r10.s64 + 4512;
	// bl 0x8b0c5fb8
	ctx.lr = 0x8B0DD188;
	sub_8B0C5FB8(ctx, base);
	// lis r7,-29938
	ctx.r7.s64 = -1962016768;
	// addi r3,r7,-6008
	ctx.r3.s64 = ctx.r7.s64 + -6008;
	// bl 0x8b0cc3d0
	ctx.lr = 0x8B0DD194;
	sub_8B0CC3D0(ctx, base);
	// addi r1,r1,96
	ctx.r1.s64 = ctx.r1.s64 + 96;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0DD290) {
	REX_FUNC_PROLOGUE();
	// b 0x8b0a6e90
	sub_8B0A6E90(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0DD2D0) {
	REX_FUNC_PROLOGUE();
	// lis r11,-29938
	ctx.r11.s64 = -1962016768;
	// lis r10,-29938
	ctx.r10.s64 = -1962016768;
	// lwz r11,1108(r11)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r11.u32 + 1108);
	// stw r11,16928(r10)
	REX_STORE_U32(ctx.r10.u32 + 16928, ctx.r11.u32);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0DD2E8) {
	REX_FUNC_PROLOGUE();
	// lis r11,-29938
	ctx.r11.s64 = -1962016768;
	// lis r10,-29938
	ctx.r10.s64 = -1962016768;
	// lwz r11,1108(r11)
	ctx.r11.u64 = REX_LOAD_U32(ctx.r11.u32 + 1108);
	// cmplwi cr6,r11,0
	ctx.cr6.compare<uint32_t>(ctx.r11.u32, 0, ctx.xer);
	// addi r11,r11,4
	ctx.r11.s64 = ctx.r11.s64 + 4;
	// bne cr6,0x8b0dd304
	if (!ctx.cr6.eq) goto loc_8B0DD304;
	// li r11,0
	ctx.r11.s64 = 0;
loc_8B0DD304:
	// stw r11,16920(r10)
	REX_STORE_U32(ctx.r10.u32 + 16920, ctx.r11.u32);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0DD398) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// stwu r1,-96(r1)
	ea = -96 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// lis r9,-29944
	ctx.r9.s64 = -1962409984;
	// lis r8,-29938
	ctx.r8.s64 = -1962016768;
	// addi r7,r11,9456
	ctx.r7.s64 = ctx.r11.s64 + 9456;
	// addi r5,r10,9452
	ctx.r5.s64 = ctx.r10.s64 + 9452;
	// addi r4,r9,9416
	ctx.r4.s64 = ctx.r9.s64 + 9416;
	// addi r3,r8,17392
	ctx.r3.s64 = ctx.r8.s64 + 17392;
	// li r6,2
	ctx.r6.s64 = 2;
	// bl 0x8b0c6b30
	ctx.lr = 0x8B0DD3CC;
	sub_8B0C6B30(ctx, base);
	// lis r7,-29938
	ctx.r7.s64 = -1962016768;
	// addi r3,r7,-5808
	ctx.r3.s64 = ctx.r7.s64 + -5808;
	// bl 0x8b0cc3d0
	ctx.lr = 0x8B0DD3D8;
	sub_8B0CC3D0(ctx, base);
	// addi r1,r1,96
	ctx.r1.s64 = ctx.r1.s64 + 96;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0DD4B8) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// stwu r1,-96(r1)
	ea = -96 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// lis r9,-29944
	ctx.r9.s64 = -1962409984;
	// lis r8,-29938
	ctx.r8.s64 = -1962016768;
	// addi r7,r11,10616
	ctx.r7.s64 = ctx.r11.s64 + 10616;
	// addi r5,r10,4620
	ctx.r5.s64 = ctx.r10.s64 + 4620;
	// addi r4,r9,10588
	ctx.r4.s64 = ctx.r9.s64 + 10588;
	// addi r3,r8,17712
	ctx.r3.s64 = ctx.r8.s64 + 17712;
	// li r6,0
	ctx.r6.s64 = 0;
	// bl 0x8b0c6b30
	ctx.lr = 0x8B0DD4EC;
	sub_8B0C6B30(ctx, base);
	// lis r7,-29938
	ctx.r7.s64 = -1962016768;
	// addi r3,r7,-5760
	ctx.r3.s64 = ctx.r7.s64 + -5760;
	// bl 0x8b0cc3d0
	ctx.lr = 0x8B0DD4F8;
	sub_8B0CC3D0(ctx, base);
	// addi r1,r1,96
	ctx.r1.s64 = ctx.r1.s64 + 96;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0DD558) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// stwu r1,-96(r1)
	ea = -96 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// lis r9,-29944
	ctx.r9.s64 = -1962409984;
	// lis r8,-29938
	ctx.r8.s64 = -1962016768;
	// addi r7,r11,10772
	ctx.r7.s64 = ctx.r11.s64 + 10772;
	// addi r5,r10,10764
	ctx.r5.s64 = ctx.r10.s64 + 10764;
	// addi r4,r9,10736
	ctx.r4.s64 = ctx.r9.s64 + 10736;
	// addi r3,r8,17568
	ctx.r3.s64 = ctx.r8.s64 + 17568;
	// li r6,0
	ctx.r6.s64 = 0;
	// bl 0x8b0c6b30
	ctx.lr = 0x8B0DD58C;
	sub_8B0C6B30(ctx, base);
	// lis r7,-29938
	ctx.r7.s64 = -1962016768;
	// addi r3,r7,-5728
	ctx.r3.s64 = ctx.r7.s64 + -5728;
	// bl 0x8b0cc3d0
	ctx.lr = 0x8B0DD598;
	sub_8B0CC3D0(ctx, base);
	// addi r1,r1,96
	ctx.r1.s64 = ctx.r1.s64 + 96;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0DD6E0) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// stwu r1,-96(r1)
	ea = -96 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// lis r9,-29938
	ctx.r9.s64 = -1962016768;
	// addi r5,r11,1791
	ctx.r5.s64 = ctx.r11.s64 + 1791;
	// addi r4,r10,9636
	ctx.r4.s64 = ctx.r10.s64 + 9636;
	// addi r3,r9,17784
	ctx.r3.s64 = ctx.r9.s64 + 17784;
	// li r6,0
	ctx.r6.s64 = 0;
	// bl 0x8b0c6aa8
	ctx.lr = 0x8B0DD70C;
	sub_8B0C6AA8(ctx, base);
	// lis r8,-29938
	ctx.r8.s64 = -1962016768;
	// addi r3,r8,-5648
	ctx.r3.s64 = ctx.r8.s64 + -5648;
	// bl 0x8b0cc3d0
	ctx.lr = 0x8B0DD718;
	sub_8B0CC3D0(ctx, base);
	// addi r1,r1,96
	ctx.r1.s64 = ctx.r1.s64 + 96;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0DD820) {
	REX_FUNC_PROLOGUE();
	// lis r11,-29938
	ctx.r11.s64 = -1962016768;
	// addi r3,r11,-5584
	ctx.r3.s64 = ctx.r11.s64 + -5584;
	// b 0x8b0cc3d0
	sub_8B0CC3D0(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0DD840) {
	REX_FUNC_PROLOGUE();
	// lis r11,-29938
	ctx.r11.s64 = -1962016768;
	// addi r3,r11,-5440
	ctx.r3.s64 = ctx.r11.s64 + -5440;
	// b 0x8b0cc3d0
	sub_8B0CC3D0(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0DD8A8) {
	REX_FUNC_PROLOGUE();
	// lis r11,-29938
	ctx.r11.s64 = -1962016768;
	// addi r3,r11,-5248
	ctx.r3.s64 = ctx.r11.s64 + -5248;
	// b 0x8b0cc3d0
	sub_8B0CC3D0(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0DD958) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// stwu r1,-96(r1)
	ea = -96 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// lis r9,-29938
	ctx.r9.s64 = -1962016768;
	// lis r6,8
	ctx.r6.s64 = 524288;
	// addi r5,r11,4620
	ctx.r5.s64 = ctx.r11.s64 + 4620;
	// addi r4,r10,15640
	ctx.r4.s64 = ctx.r10.s64 + 15640;
	// addi r3,r9,18896
	ctx.r3.s64 = ctx.r9.s64 + 18896;
	// ori r6,r6,128
	ctx.r6.u64 = ctx.r6.u64 | 128;
	// bl 0x8b0c6aa8
	ctx.lr = 0x8B0DD988;
	sub_8B0C6AA8(ctx, base);
	// lis r8,-29938
	ctx.r8.s64 = -1962016768;
	// addi r3,r8,-5176
	ctx.r3.s64 = ctx.r8.s64 + -5176;
	// bl 0x8b0cc3d0
	ctx.lr = 0x8B0DD994;
	sub_8B0CC3D0(ctx, base);
	// addi r1,r1,96
	ctx.r1.s64 = ctx.r1.s64 + 96;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0DDAE8) {
	REX_FUNC_PROLOGUE();
	// lis r11,-29938
	ctx.r11.s64 = -1962016768;
	// addi r3,r11,-4944
	ctx.r3.s64 = ctx.r11.s64 + -4944;
	// b 0x8b0cc3d0
	sub_8B0CC3D0(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0DDB30) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// stwu r1,-96(r1)
	ea = -96 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// lis r9,-29938
	ctx.r9.s64 = -1962016768;
	// addi r5,r11,23740
	ctx.r5.s64 = ctx.r11.s64 + 23740;
	// addi r4,r10,23716
	ctx.r4.s64 = ctx.r10.s64 + 23716;
	// addi r3,r9,19676
	ctx.r3.s64 = ctx.r9.s64 + 19676;
	// li r6,2
	ctx.r6.s64 = 2;
	// bl 0x8b0c6aa8
	ctx.lr = 0x8B0DDB5C;
	sub_8B0C6AA8(ctx, base);
	// lis r8,-29938
	ctx.r8.s64 = -1962016768;
	// addi r3,r8,-4856
	ctx.r3.s64 = ctx.r8.s64 + -4856;
	// bl 0x8b0cc3d0
	ctx.lr = 0x8B0DDB68;
	sub_8B0CC3D0(ctx, base);
	// addi r1,r1,96
	ctx.r1.s64 = ctx.r1.s64 + 96;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0DDCD0) {
	REX_FUNC_PROLOGUE();
	// lis r11,-29938
	ctx.r11.s64 = -1962016768;
	// li r10,0
	ctx.r10.s64 = 0;
	// addi r11,r11,5656
	ctx.r11.s64 = ctx.r11.s64 + 5656;
	// lis r9,-29938
	ctx.r9.s64 = -1962016768;
	// addi r3,r9,-4680
	ctx.r3.s64 = ctx.r9.s64 + -4680;
	// stw r10,24(r11)
	REX_STORE_U32(ctx.r11.u32 + 24, ctx.r10.u32);
	// b 0x8b0cc3d0
	sub_8B0CC3D0(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0DDCF0) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// stwu r1,-96(r1)
	ea = -96 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lis r8,-29938
	ctx.r8.s64 = -1962016768;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lis r10,-29941
	ctx.r10.s64 = -1962213376;
	// lis r9,-29944
	ctx.r9.s64 = -1962409984;
	// addi r3,r8,19936
	ctx.r3.s64 = ctx.r8.s64 + 19936;
	// addi r6,r11,25648
	ctx.r6.s64 = ctx.r11.s64 + 25648;
	// addi r4,r9,25620
	ctx.r4.s64 = ctx.r9.s64 + 25620;
	// li r8,0
	ctx.r8.s64 = 0;
	// li r7,0
	ctx.r7.s64 = 0;
	// addi r5,r10,-15800
	ctx.r5.s64 = ctx.r10.s64 + -15800;
	// bl 0x8b0c5fb8
	ctx.lr = 0x8B0DDD28;
	sub_8B0C5FB8(ctx, base);
	// lis r7,-29938
	ctx.r7.s64 = -1962016768;
	// addi r3,r7,-4696
	ctx.r3.s64 = ctx.r7.s64 + -4696;
	// bl 0x8b0cc3d0
	ctx.lr = 0x8B0DDD34;
	sub_8B0CC3D0(ctx, base);
	// addi r1,r1,96
	ctx.r1.s64 = ctx.r1.s64 + 96;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0DDE88) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// stwu r1,-96(r1)
	ea = -96 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// lis r9,-29944
	ctx.r9.s64 = -1962409984;
	// lis r8,-29938
	ctx.r8.s64 = -1962016768;
	// addi r7,r11,9456
	ctx.r7.s64 = ctx.r11.s64 + 9456;
	// addi r5,r10,26192
	ctx.r5.s64 = ctx.r10.s64 + 26192;
	// addi r4,r9,26156
	ctx.r4.s64 = ctx.r9.s64 + 26156;
	// addi r3,r8,20364
	ctx.r3.s64 = ctx.r8.s64 + 20364;
	// li r6,2
	ctx.r6.s64 = 2;
	// bl 0x8b0c6b30
	ctx.lr = 0x8B0DDEBC;
	sub_8B0C6B30(ctx, base);
	// lis r7,-29938
	ctx.r7.s64 = -1962016768;
	// addi r3,r7,-4600
	ctx.r3.s64 = ctx.r7.s64 + -4600;
	// bl 0x8b0cc3d0
	ctx.lr = 0x8B0DDEC8;
	sub_8B0CC3D0(ctx, base);
	// addi r1,r1,96
	ctx.r1.s64 = ctx.r1.s64 + 96;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0DE048) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// stwu r1,-96(r1)
	ea = -96 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// lis r9,-29938
	ctx.r9.s64 = -1962016768;
	// addi r5,r11,5768
	ctx.r5.s64 = ctx.r11.s64 + 5768;
	// addi r4,r10,29912
	ctx.r4.s64 = ctx.r10.s64 + 29912;
	// addi r3,r9,20904
	ctx.r3.s64 = ctx.r9.s64 + 20904;
	// li r6,2
	ctx.r6.s64 = 2;
	// bl 0x8b0c6aa8
	ctx.lr = 0x8B0DE074;
	sub_8B0C6AA8(ctx, base);
	// lis r8,-29938
	ctx.r8.s64 = -1962016768;
	// addi r3,r8,-4472
	ctx.r3.s64 = ctx.r8.s64 + -4472;
	// bl 0x8b0cc3d0
	ctx.lr = 0x8B0DE080;
	sub_8B0CC3D0(ctx, base);
	// addi r1,r1,96
	ctx.r1.s64 = ctx.r1.s64 + 96;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0DE1E0) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// stwu r1,-96(r1)
	ea = -96 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// lis r9,-29944
	ctx.r9.s64 = -1962409984;
	// lis r8,-29938
	ctx.r8.s64 = -1962016768;
	// addi r7,r11,31728
	ctx.r7.s64 = ctx.r11.s64 + 31728;
	// addi r5,r10,9376
	ctx.r5.s64 = ctx.r10.s64 + 9376;
	// addi r4,r9,31692
	ctx.r4.s64 = ctx.r9.s64 + 31692;
	// addi r3,r8,21248
	ctx.r3.s64 = ctx.r8.s64 + 21248;
	// li r6,2
	ctx.r6.s64 = 2;
	// bl 0x8b0c6b30
	ctx.lr = 0x8B0DE214;
	sub_8B0C6B30(ctx, base);
	// lis r7,-29938
	ctx.r7.s64 = -1962016768;
	// addi r3,r7,-4304
	ctx.r3.s64 = ctx.r7.s64 + -4304;
	// bl 0x8b0cc3d0
	ctx.lr = 0x8B0DE220;
	sub_8B0CC3D0(ctx, base);
	// addi r1,r1,96
	ctx.r1.s64 = ctx.r1.s64 + 96;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0DE350) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// stwu r1,-96(r1)
	ea = -96 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lis r11,-29943
	ctx.r11.s64 = -1962344448;
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// lis r9,-29943
	ctx.r9.s64 = -1962344448;
	// lis r8,-29938
	ctx.r8.s64 = -1962016768;
	// addi r7,r11,-31744
	ctx.r7.s64 = ctx.r11.s64 + -31744;
	// addi r5,r10,26004
	ctx.r5.s64 = ctx.r10.s64 + 26004;
	// addi r4,r9,-31768
	ctx.r4.s64 = ctx.r9.s64 + -31768;
	// addi r3,r8,21740
	ctx.r3.s64 = ctx.r8.s64 + 21740;
	// li r6,2
	ctx.r6.s64 = 2;
	// bl 0x8b0c6b30
	ctx.lr = 0x8B0DE384;
	sub_8B0C6B30(ctx, base);
	// lis r7,-29938
	ctx.r7.s64 = -1962016768;
	// addi r3,r7,-4064
	ctx.r3.s64 = ctx.r7.s64 + -4064;
	// bl 0x8b0cc3d0
	ctx.lr = 0x8B0DE390;
	sub_8B0CC3D0(ctx, base);
	// addi r1,r1,96
	ctx.r1.s64 = ctx.r1.s64 + 96;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0DE4E0) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// stwu r1,-96(r1)
	ea = -96 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lis r11,-29943
	ctx.r11.s64 = -1962344448;
	// lis r10,-29944
	ctx.r10.s64 = -1962409984;
	// lis r9,-29943
	ctx.r9.s64 = -1962344448;
	// lis r8,-29938
	ctx.r8.s64 = -1962016768;
	// addi r7,r11,-30460
	ctx.r7.s64 = ctx.r11.s64 + -30460;
	// addi r5,r10,1791
	ctx.r5.s64 = ctx.r10.s64 + 1791;
	// addi r4,r9,-30476
	ctx.r4.s64 = ctx.r9.s64 + -30476;
	// addi r3,r8,22000
	ctx.r3.s64 = ctx.r8.s64 + 22000;
	// li r6,2
	ctx.r6.s64 = 2;
	// bl 0x8b0c6b30
	ctx.lr = 0x8B0DE514;
	sub_8B0C6B30(ctx, base);
	// lis r7,-29938
	ctx.r7.s64 = -1962016768;
	// addi r3,r7,-3984
	ctx.r3.s64 = ctx.r7.s64 + -3984;
	// bl 0x8b0cc3d0
	ctx.lr = 0x8B0DE520;
	sub_8B0CC3D0(ctx, base);
	// addi r1,r1,96
	ctx.r1.s64 = ctx.r1.s64 + 96;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0DE650) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// stwu r1,-96(r1)
	ea = -96 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lis r11,-29943
	ctx.r11.s64 = -1962344448;
	// lis r10,-29943
	ctx.r10.s64 = -1962344448;
	// lis r9,-29938
	ctx.r9.s64 = -1962016768;
	// addi r5,r11,-29668
	ctx.r5.s64 = ctx.r11.s64 + -29668;
	// addi r4,r10,-29700
	ctx.r4.s64 = ctx.r10.s64 + -29700;
	// addi r3,r9,22596
	ctx.r3.s64 = ctx.r9.s64 + 22596;
	// li r6,2
	ctx.r6.s64 = 2;
	// bl 0x8b0c6aa8
	ctx.lr = 0x8B0DE67C;
	sub_8B0C6AA8(ctx, base);
	// lis r8,-29938
	ctx.r8.s64 = -1962016768;
	// addi r3,r8,-3904
	ctx.r3.s64 = ctx.r8.s64 + -3904;
	// bl 0x8b0cc3d0
	ctx.lr = 0x8B0DE688;
	sub_8B0CC3D0(ctx, base);
	// addi r1,r1,96
	ctx.r1.s64 = ctx.r1.s64 + 96;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0DE888) {
	REX_FUNC_PROLOGUE();
	// lis r11,-29938
	ctx.r11.s64 = -1962016768;
	// addi r3,r11,16380
	ctx.r3.s64 = ctx.r11.s64 + 16380;
	// b 0x8b0c60b8
	sub_8B0C60B8(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0DE8A8) {
	REX_FUNC_PROLOGUE();
	// lis r11,-29938
	ctx.r11.s64 = -1962016768;
	// addi r3,r11,16416
	ctx.r3.s64 = ctx.r11.s64 + 16416;
	// b 0x8b090778
	sub_8B090778(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0DE8C8) {
	REX_FUNC_PROLOGUE();
	// lis r11,-29938
	ctx.r11.s64 = -1962016768;
	// addi r3,r11,16748
	ctx.r3.s64 = ctx.r11.s64 + 16748;
	// b 0x8b0c6148
	sub_8B0C6148(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0DE8E8) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// std r31,-16(r1)
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.r31.u64);
	// stwu r1,-96(r1)
	ea = -96 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lis r10,-29938
	ctx.r10.s64 = -1962016768;
	// lis r11,-29944
	ctx.r11.s64 = -1962409984;
	// addi r31,r10,17096
	ctx.r31.s64 = ctx.r10.s64 + 17096;
	// addi r11,r11,8692
	ctx.r11.s64 = ctx.r11.s64 + 8692;
	// addi r3,r31,20
	ctx.r3.s64 = ctx.r31.s64 + 20;
	// stw r11,17096(r10)
	REX_STORE_U32(ctx.r10.u32 + 17096, ctx.r11.u32);
	// bl 0x8b0c5918
	ctx.lr = 0x8B0DE914;
	sub_8B0C5918(ctx, base);
	// li r11,0
	ctx.r11.s64 = 0;
	// addi r3,r31,4
	ctx.r3.s64 = ctx.r31.s64 + 4;
	// stw r11,16(r31)
	REX_STORE_U32(ctx.r31.u32 + 16, ctx.r11.u32);
	// bl 0x8b0906a8
	ctx.lr = 0x8B0DE924;
	sub_8B0906A8(ctx, base);
	// addi r3,r31,4
	ctx.r3.s64 = ctx.r31.s64 + 4;
	// bl 0x8b0906a8
	ctx.lr = 0x8B0DE92C;
	sub_8B0906A8(ctx, base);
	// addi r1,r1,96
	ctx.r1.s64 = ctx.r1.s64 + 96;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0DEA10) {
	REX_FUNC_PROLOGUE();
	// lis r11,-29938
	ctx.r11.s64 = -1962016768;
	// addi r3,r11,17856
	ctx.r3.s64 = ctx.r11.s64 + 17856;
	// b 0x8b0c60b8
	sub_8B0C60B8(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0DEB08) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// std r31,-16(r1)
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.r31.u64);
	// stwu r1,-96(r1)
	ea = -96 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lis r10,-29938
	ctx.r10.s64 = -1962016768;
	// li r11,0
	ctx.r11.s64 = 0;
	// addi r31,r10,18576
	ctx.r31.s64 = ctx.r10.s64 + 18576;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// stw r11,12(r31)
	REX_STORE_U32(ctx.r31.u32 + 12, ctx.r11.u32);
	// bl 0x8b0906a8
	ctx.lr = 0x8B0DEB30;
	sub_8B0906A8(ctx, base);
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0906a8
	ctx.lr = 0x8B0DEB38;
	sub_8B0906A8(ctx, base);
	// addi r1,r1,96
	ctx.r1.s64 = ctx.r1.s64 + 96;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0DEC38) {
	REX_FUNC_PROLOGUE();
	// lis r11,-29938
	ctx.r11.s64 = -1962016768;
	// addi r3,r11,4512
	ctx.r3.s64 = ctx.r11.s64 + 4512;
	// b 0x8b09f590
	sub_8B09F590(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0DEC68) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// std r31,-16(r1)
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.r31.u64);
	// stwu r1,-96(r1)
	ea = -96 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lis r10,-29938
	ctx.r10.s64 = -1962016768;
	// li r11,0
	ctx.r11.s64 = 0;
	// addi r31,r10,19100
	ctx.r31.s64 = ctx.r10.s64 + 19100;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// stw r11,12(r31)
	REX_STORE_U32(ctx.r31.u32 + 12, ctx.r11.u32);
	// bl 0x8b0906a8
	ctx.lr = 0x8B0DEC90;
	sub_8B0906A8(ctx, base);
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0906a8
	ctx.lr = 0x8B0DEC98;
	sub_8B0906A8(ctx, base);
	// addi r1,r1,96
	ctx.r1.s64 = ctx.r1.s64 + 96;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0DEDA8) {
	REX_FUNC_PROLOGUE();
	// lis r11,-29938
	ctx.r11.s64 = -1962016768;
	// addi r3,r11,19936
	ctx.r3.s64 = ctx.r11.s64 + 19936;
	// b 0x8b0c60b8
	sub_8B0C60B8(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0DEDE8) {
	REX_FUNC_PROLOGUE();
	// lis r11,-29938
	ctx.r11.s64 = -1962016768;
	// addi r3,r11,20216
	ctx.r3.s64 = ctx.r11.s64 + 20216;
	// b 0x8b0c6148
	sub_8B0C6148(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0DEE28) {
	REX_FUNC_PROLOGUE();
	// lis r11,-29938
	ctx.r11.s64 = -1962016768;
	// addi r3,r11,20292
	ctx.r3.s64 = ctx.r11.s64 + 20292;
	// b 0x8b0c6148
	sub_8B0C6148(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0DEE78) {
	REX_FUNC_PROLOGUE();
	// lis r11,-29938
	ctx.r11.s64 = -1962016768;
	// addi r3,r11,20832
	ctx.r3.s64 = ctx.r11.s64 + 20832;
	// b 0x8b0c6148
	sub_8B0C6148(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0DEF00) {
	REX_FUNC_PROLOGUE();
	// lis r11,-29938
	ctx.r11.s64 = -1962016768;
	// addi r3,r11,21320
	ctx.r3.s64 = ctx.r11.s64 + 21320;
	// b 0x8b0c6148
	sub_8B0C6148(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0DEF40) {
	REX_FUNC_PROLOGUE();
	// lis r11,-29938
	ctx.r11.s64 = -1962016768;
	// addi r3,r11,21100
	ctx.r3.s64 = ctx.r11.s64 + 21100;
	// b 0x8b0c6148
	sub_8B0C6148(ctx, base);
	return;
}

DEFINE_REX_FUNC(sub_8B0DEFD8) {
	REX_FUNC_PROLOGUE();
	uint32_t ea{};
	// mflr r12
	ctx.r12.u64 = ctx.lr;
	// stw r12,-8(r1)
	REX_STORE_U32(ctx.r1.u32 + -8, ctx.r12.u32);
	// std r31,-16(r1)
	REX_STORE_U64(ctx.r1.u32 + -16, ctx.r31.u64);
	// stwu r1,-96(r1)
	ea = -96 + ctx.r1.u32;
	REX_STORE_U32(ea, ctx.r1.u32);
	ctx.r1.u32 = ea;
	// lis r10,-29938
	ctx.r10.s64 = -1962016768;
	// li r11,0
	ctx.r11.s64 = 0;
	// addi r31,r10,21524
	ctx.r31.s64 = ctx.r10.s64 + 21524;
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// stw r11,12(r31)
	REX_STORE_U32(ctx.r31.u32 + 12, ctx.r11.u32);
	// bl 0x8b0906a8
	ctx.lr = 0x8B0DF000;
	sub_8B0906A8(ctx, base);
	// mr r3,r31
	ctx.r3.u64 = ctx.r31.u64;
	// bl 0x8b0906a8
	ctx.lr = 0x8B0DF008;
	sub_8B0906A8(ctx, base);
	// addi r1,r1,96
	ctx.r1.s64 = ctx.r1.s64 + 96;
	// lwz r12,-8(r1)
	ctx.r12.u64 = REX_LOAD_U32(ctx.r1.u32 + -8);
	// mtlr r12
	ctx.lr = ctx.r12.u64;
	// ld r31,-16(r1)
	ctx.r31.u64 = REX_LOAD_U64(ctx.r1.u32 + -16);
	// blr 
	return;
}

DEFINE_REX_FUNC(sub_8B0DF0D0) {
	REX_FUNC_PROLOGUE();
	// lis r11,-29936
	ctx.r11.s64 = -1961885696;
	// addi r3,r11,-29048
	ctx.r3.s64 = ctx.r11.s64 + -29048;
	// b 0x8b0ca9c0
	sub_8B0CA9C0(ctx, base);
	return;
}

