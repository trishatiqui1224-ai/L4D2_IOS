E:/Project/L4D2\ IOS/generated/vstdlib_360/codegen.build.stamp: \
  E:/Project/L4D2\ IOS/Left\ 4\ Dead\ 2\ (World)\ (En,Ja,Fr,De,Es,It,Pt,Zh,Ko,Pl,Ru)/bin/vstdlib_360.dll \
  E:/Project/L4D2\ IOS/configs/l4d2_vstdlib.toml
