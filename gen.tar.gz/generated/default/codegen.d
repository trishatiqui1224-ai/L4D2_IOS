E:/Project/L4D2\ IOS/generated/default/codegen.build.stamp: \
  E:/Project/L4D2\ IOS/Left\ 4\ Dead\ 2\ (World)\ (En,Ja,Fr,De,Es,It,Pt,Zh,Ko,Pl,Ru)/default.xex \
  E:/Project/L4D2\ IOS/configs/l4d2_default.toml
